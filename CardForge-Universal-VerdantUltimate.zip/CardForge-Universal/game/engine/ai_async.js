import { getPlannerDebug } from './ai.js';

let plannerWorker = null;
let requestSequence = 0;
const pendingRequests = new Map();

function failPending(error) {
  pendingRequests.forEach(({ reject, timer }) => {
    clearTimeout(timer);
    reject(error);
  });
  pendingRequests.clear();
}

function resetPlannerWorker(error = null) {
  const worker = plannerWorker;
  plannerWorker = null;
  if (worker) worker.terminate();
  if (error) failPending(error);
}

function ensurePlannerWorker() {
  if (plannerWorker) return plannerWorker;
  const worker = new Worker(new URL('./ai_worker.js', import.meta.url), { type: 'module' });
  worker.onmessage = ({ data }) => {
    const requestId = Number(data?.requestId ?? 0);
    const pending = pendingRequests.get(requestId);
    if (!pending) return;
    pendingRequests.delete(requestId);
    clearTimeout(pending.timer);
    if (data?.error) pending.reject(new Error(data.error));
    else pending.resolve(data);
  };
  worker.onerror = (event) => {
    event.preventDefault();
    resetPlannerWorker(new Error(event.message || 'AI planner worker failed.'));
  };
  plannerWorker = worker;
  return worker;
}

function requestFromWorker(payload, timeoutMs = 2200) {
  return new Promise((resolve, reject) => {
    const worker = ensurePlannerWorker();
    const requestId = ++requestSequence;
    const timer = setTimeout(() => {
      pendingRequests.delete(requestId);
      resetPlannerWorker();
      reject(new Error('Planner exceeded its worker time budget.'));
    }, timeoutMs);
    pendingRequests.set(requestId, { resolve, reject, timer });
    try {
      // postMessage already provides the structured clone required by the worker boundary.
      worker.postMessage({ ...payload, requestId });
    } catch (error) {
      pendingRequests.delete(requestId);
      clearTimeout(timer);
      reject(error);
    }
  });
}

function cardCost(card) {
  const explicit = Number(card?.manaCost ?? card?.cost);
  if (Number.isFinite(explicit)) return Math.max(0, Math.floor(explicit));
  return Math.max(1, Math.floor(Number(card?.level ?? 1)));
}

function emergencyPlan(state) {
  const actions = [];
  const mana = Math.max(0, Number(state?.enemyMana ?? state?.maxMana ?? 0));
  const boardColumns = Math.max(4, Number(state?.boardColumns ?? 4));
  const capacity = boardColumns * 2;
  const occupied = new Set((state?.enemyMinions ?? []).map((unit) => Number(unit?.slot)).filter(Number.isInteger));
  const openSlot = Array.from({ length: capacity }, (_, index) => index).find((index) => !occupied.has(index));
  const affordable = (state?.enemyDeck ?? [])
    .map((card, deckIndex) => ({ card, deckIndex, cost: cardCost(card) }))
    .filter(({ cost }) => cost <= mana)
    .sort((a, b) => ((b.card?.attack ?? 0) + (b.card?.health ?? 0)) - ((a.card?.attack ?? 0) + (a.card?.health ?? 0)));

  if (openSlot != null && affordable.length) {
    actions.push({
      type: 'summon',
      deckIndex: affordable[0].deckIndex,
      slot: openSlot,
      trace: 'emergency-worker-fallback:summon',
    });
  }

  const defenders = state?.playerMinions ?? [];
  const guard = defenders.find((unit) => unit?.taunt) ?? defenders[0] ?? null;
  for (const attacker of state?.enemyMinions ?? []) {
    if (attacker?.summoningSick || attacker?.hasAttacked || attacker?.health <= 0 || attacker?.attack <= 0) continue;
    actions.push(guard
      ? { type: 'attack-minion', attackerId: attacker.id, targetId: guard.id, trace: 'emergency-worker-fallback:attack-unit' }
      : { type: 'attack-hero', attackerId: attacker.id, trace: 'emergency-worker-fallback:attack-core' });
  }

  return actions.length ? actions : [{ type: 'pass', trace: 'emergency-worker-fallback:pass' }];
}

export async function warmPlannerWorker() {
  try {
    await requestFromWorker({ type: 'warmup' }, 1800);
    return true;
  } catch (error) {
    console.warn('AI planner worker warm-up failed.', error.message);
    return false;
  }
}

// The browser owns the only clone through postMessage; neural work never runs on the UI thread.
export async function planTurnAsync(state, profile) {
  await new Promise((resolve) => requestAnimationFrame(resolve));
  const startedAt = performance.now();
  try {
    const result = await requestFromWorker({
      type: 'plan',
      state,
      profile,
      memory: getPlannerDebug(profile?.id ?? profile?.name),
    });
    return { ...result, workerElapsedMs: performance.now() - startedAt };
  } catch (error) {
    console.warn('AI worker unavailable; using emergency non-search plan.', error.message);
    return {
      plan: emergencyPlan(state),
      debug: null,
      fallback: true,
      workerElapsedMs: performance.now() - startedAt,
    };
  }
}

window.addEventListener('pagehide', () => resetPlannerWorker());
