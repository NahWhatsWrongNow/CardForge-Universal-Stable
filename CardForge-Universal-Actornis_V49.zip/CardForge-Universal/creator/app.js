import { Registry } from '../core/registry.js';
import { loadPlugins } from '../core/loader.js';
import { raceIconGlyph, raceMeta, RACE_LIBRARY } from '../game/engine/race_logic.js';

const registry = new Registry();

const STORAGE = {
  customCards: 'cardforge.creator.customCards.v1',
  profile: 'cardforge.profile.v1',
  projectDraft: 'cardforge.creator.studio.project.v2',
  userTemplates: 'cardforge.creator.studio.userTemplates.v2',
  versions: 'cardforge.creator.studio.versions.v2',
  recentCards: 'cardforge.creator.studio.recent.v2',
  uiPrefs: 'cardforge.creator.studio.ui.v2',
};

const RARITIES = ['common', 'rare', 'epic', 'legendary'];
const DUEL_TYPES = ['minion', 'spell', 'relic', 'field', 'trap', 'structure', 'token'];
const CONQUEST_TYPES = ['unit', 'building', 'facility', 'turret', 'barricade', 'equipment', 'upgrade', 'tactic', 'support'];
const HYBRID_TYPES = [...new Set([...DUEL_TYPES, ...CONQUEST_TYPES])];
const PREVIEW_MODES = ['full', 'hand', 'board', 'conquest'];
const DUEL_FAMILIES = RACE_LIBRARY
  .map((entry) => entry.id)
  .filter((id) => !['token', 'ship'].includes(id));
const ABILITY_TRIGGER_OPTIONS = ['battlecry', 'on_play', 'start_turn', 'end_turn', 'on_summon_friendly', 'on_minion_death', 'aura', 'passive'];
const ABILITY_TARGET_OPTIONS = ['self', 'friendly_minion', 'enemy_minion', 'all_friendly', 'all_enemy', 'hero', 'friendly_hand', 'friendly_deck'];
const ABILITY_EFFECT_OPTIONS = ['dealDamage', 'buffAttack', 'buffHealth', 'gainStats', 'draw', 'summon', 'reduceCost', 'gainFamiliarity', 'spendFamiliarity', 'transform', 'copy', 'revive'];
const ABILITY_ZONE_OPTIONS = ['board', 'hand', 'deck', 'graveyard'];

const KEYWORD_DEFS = [
  { key: 'taunt', label: 'Taunt' },
  { key: 'stealth', label: 'Stealth' },
  { key: 'charge', label: 'Charge' },
  { key: 'lifesteal', label: 'Lifesteal' },
  { key: 'flying', label: 'Flying' },
  { key: 'immune', label: 'Immune' },
  { key: 'horde', label: 'Horde' },
  { key: 'giant', label: 'Giant' },
  { key: 'siege', label: 'Siege' },
  { key: 'ranged', label: 'Ranged' },
  { key: 'antiAir', label: 'Anti-Air' },
  { key: 'structure', label: 'Structure' },
  { key: 'facility', label: 'Facility' },
  { key: 'turret', label: 'Turret' },
  { key: 'barricade', label: 'Barricade' },
  { key: 'vehicle', label: 'Vehicle' },
  { key: 'mech', label: 'Mech' },
  { key: 'command', label: 'Command' },
  { key: 'upgrade', label: 'Upgrade' },
  { key: 'equipment', label: 'Equipment' },
  { key: 'repair', label: 'Repair' },
];

const CONQUEST_SOURCES = [
  'training',
  'blacksmith',
  'factory',
  'command',
  'vehicle',
  'ordnance',
  'air_support',
  'power_shield',
  'recovery',
  'experimental',
];

const FALLBACK_ABILITY_TEMPLATES = [
  { id: 'tribal-board-buff', name: 'Race Board Scaling', category: 'race', trigger: 'battlecry', target: 'self', effect: { action: 'gainStats', amount: 1 }, family: 'dragon', familyZone: 'board', notes: 'For every Dragon you control, gain +1/+1.' },
  { id: 'tribal-threshold-draw', name: 'Race Threshold Draw', category: 'race', trigger: 'end_turn', target: 'self', effect: { action: 'draw', amount: 1 }, family: 'spirit', familyZone: 'board', threshold: 3, notes: 'If you control 3 or more Spirits, draw 1.' },
  { id: 'hand-family-discount', name: 'Family Hand Discount', category: 'cost', trigger: 'passive', target: 'self', effect: { action: 'reduceCost', amount: 1 }, family: 'dragon', familyZone: 'hand', notes: 'Costs (1) less for each Dragon in your hand.' },
  { id: 'gain-familiarity', name: 'Gain Familiarity', category: 'familiarity', trigger: 'on_summon_friendly', target: 'self', effect: { action: 'gainFamiliarity', amount: 1 }, family: 'beast', notes: 'Whenever you summon a Beast, gain 1 Beast Familiarity.' },
  { id: 'familiarity-threshold', name: 'Familiarity Threshold', category: 'familiarity', trigger: 'passive', target: 'friendly_minion', effect: { action: 'buffHealth', amount: 1 }, familiarityRace: 'human', familiarityThreshold: 3, notes: 'Human Familiarity 3: your followers get +1 Health.' },
  { id: 'dragon-brood-token', name: 'Dragon Brood Summon', category: 'dragon', trigger: 'battlecry', target: 'self', effect: { action: 'summon', amount: 1 }, family: 'dragonkin', tokenRace: 'dragonkin', notes: 'Battlecry: summon a Dragonkin token.' },
];

const RACE_ARCHETYPE_PRESETS = {
  dragon_flight: {
    label: 'Dragon Flight',
    races: ['dragon'],
    synergy: 'dragon,flying,fire,hoard',
    role: 'Dragon finisher / aerial threat',
    keywords: { flying: true },
  },
  brood_swarm: {
    label: 'Brood Swarm',
    races: ['dragonkin', 'dragon'],
    synergy: 'dragonkin,tokens,brood,tempo',
    role: 'Brood swarm / hatchling engine',
  },
  spirit_choir: {
    label: 'Spirit Choir',
    races: ['spirit', 'wraith'],
    synergy: 'spirit,death,value,echo',
    role: 'Spirit recursion / threshold payoff',
  },
  beast_pack: {
    label: 'Beast Pack',
    races: ['beast'],
    synergy: 'beast,pack,tempo,heal',
    role: 'Beast pressure / familiarity payoff',
  },
};

const BUILTIN_TEMPLATES = [
  {
    id: 'tmpl-basic-minion',
    label: 'Basic Minion',
    mode: 'duel',
    type: 'minion',
    summary: 'Simple baseline creature.',
    patch: { cost: { mana: 2 }, stats: { attack: 2, health: 2 }, text: 'No text.' },
  },
  {
    id: 'tmpl-spell-buff',
    label: 'Buff Spell',
    mode: 'duel',
    type: 'spell',
    summary: 'Targeted buff spell shell.',
    patch: { cost: { mana: 2 }, normal: { damage: 0 }, text: 'Give a friendly minion +2/+2 this turn.' },
  },
  {
    id: 'tmpl-relic',
    label: 'Relic Engine',
    mode: 'duel',
    type: 'relic',
    summary: 'Passive relic setup.',
    patch: { cost: { mana: 3 }, text: 'At the end of your turn, trigger a small effect.' },
  },
  {
    id: 'tmpl-field',
    label: 'Field Rule',
    mode: 'duel',
    type: 'field',
    summary: 'Board-wide continuous rule.',
    patch: { cost: { mana: 4 }, text: 'At end of turn, apply a board effect.' },
  },
  {
    id: 'tmpl-dragon-hatchling',
    label: 'Dragon Hatchling',
    mode: 'duel',
    type: 'minion',
    summary: 'Low-cost dragonkin setup piece.',
    patch: { cost: { mana: 1 }, stats: { attack: 1, health: 2 }, normal: { race: 'dragonkin', races: 'dragonkin, dragon' }, metadata: { role: 'Dragon opener' }, text: 'Battlecry: gain 1 Dragon Familiarity.' },
  },
  {
    id: 'tmpl-elder-dragon',
    label: 'Elder Dragon',
    mode: 'duel',
    type: 'minion',
    summary: 'Legendary dragon finisher shell.',
    patch: { rarity: 'legendary', cost: { mana: 8 }, stats: { attack: 7, health: 9 }, keywords: { flying: true }, normal: { race: 'dragon', races: 'dragon, ancient' }, metadata: { role: 'Dragon finisher' }, text: 'Battlecry: deal 3 damage split among enemies.' },
  },
  {
    id: 'tmpl-race-lord',
    label: 'Race Lord',
    mode: 'duel',
    type: 'minion',
    summary: 'Board-wide race champion shell.',
    patch: { cost: { mana: 4 }, stats: { attack: 3, health: 5 }, normal: { race: 'beast', races: 'beast' }, metadata: { role: 'Race lord' }, text: 'Aura: Your chosen race has +1 Attack.' },
  },
  {
    id: 'tmpl-conquest-unit',
    label: 'Conquest Unit',
    mode: 'conquest',
    type: 'unit',
    summary: 'Frontline conquest unit shell.',
    patch: { cost: { wheat: 2, iron: 1 }, stats: { attack: 2, health: 3, range: 1, movement: 1 }, conquest: { side: 'defender', productionSource: 'training' } },
  },
  {
    id: 'tmpl-conquest-building',
    label: 'Conquest Building',
    mode: 'conquest',
    type: 'building',
    summary: 'Production/utility structure.',
    patch: { cost: { wheat: 2, iron: 2 }, stats: { attack: 0, health: 6 }, conquest: { isBuilding: true, productionSource: 'factory' } },
  },
  {
    id: 'tmpl-turret',
    label: 'Turret',
    mode: 'conquest',
    type: 'turret',
    summary: 'Ranged defensive emplacement.',
    patch: { cost: { wheat: 1, iron: 3 }, stats: { attack: 3, health: 4, range: 2 }, conquest: { isBuilding: true, isTurret: true, productionSource: 'factory' }, keywords: { turret: true, ranged: true } },
  },
  {
    id: 'tmpl-barricade',
    label: 'Barricade',
    mode: 'conquest',
    type: 'barricade',
    summary: 'Lane blocking fortification.',
    patch: { cost: { wheat: 2, iron: 2 }, stats: { attack: 0, health: 8 }, conquest: { isBuilding: true, isBarricade: true, productionSource: 'command' }, keywords: { barricade: true, structure: true } },
  },
  {
    id: 'tmpl-weapon-upgrade',
    label: 'Weapon Upgrade',
    mode: 'conquest',
    type: 'upgrade',
    summary: 'Blacksmith upgrade shell.',
    patch: { cost: { wheat: 0, iron: 3 }, conquest: { isUpgrade: true, productionSource: 'blacksmith' }, keywords: { upgrade: true }, text: 'Attach to a unit. Gain +2 attack.' },
  },
  {
    id: 'tmpl-armour',
    label: 'Armour Equipment',
    mode: 'conquest',
    type: 'equipment',
    summary: 'Durability-focused equipment.',
    patch: { cost: { wheat: 1, iron: 2 }, conquest: { isEquipment: true, productionSource: 'blacksmith' }, keywords: { equipment: true }, text: 'Equip to friendly unit. Gain +0/+3.' },
  },
  {
    id: 'tmpl-horde',
    label: 'Horde Unit',
    mode: 'conquest',
    type: 'unit',
    summary: 'Low-cost swarm attacker.',
    patch: { cost: { wheat: 2, iron: 0 }, stats: { attack: 1, health: 2 }, keywords: { horde: true }, conquest: { side: 'attacker', productionSource: 'training' } },
  },
  {
    id: 'tmpl-giant',
    label: 'Giant Unit',
    mode: 'conquest',
    type: 'unit',
    summary: 'Large lane breaker.',
    patch: { cost: { wheat: 4, iron: 5 }, stats: { attack: 7, health: 10, range: 1, movement: 1 }, keywords: { giant: true, siege: true } },
  },
  {
    id: 'tmpl-flying',
    label: 'Flying Unit',
    mode: 'hybrid',
    type: 'unit',
    summary: 'Mobility-focused flyer.',
    patch: { cost: { mana: 4, wheat: 2, iron: 2 }, stats: { attack: 4, health: 3, range: 2 }, keywords: { flying: true, ranged: true } },
  },
  {
    id: 'tmpl-summon-spell',
    label: 'Summon Spell',
    mode: 'duel',
    type: 'spell',
    summary: 'Token generator spell shell.',
    patch: { cost: { mana: 3 }, text: 'Summon two 1/1 tokens.' },
  },
  {
    id: 'tmpl-heal-spell',
    label: 'Healing Spell',
    mode: 'duel',
    type: 'spell',
    summary: 'Single target healing.',
    patch: { cost: { mana: 2 }, text: 'Restore 4 Health to a friendly character.' },
  },
  {
    id: 'tmpl-legendary-buildaround',
    label: 'Legendary Build-around',
    mode: 'hybrid',
    type: 'minion',
    summary: 'High complexity legendary shell.',
    patch: { rarity: 'legendary', cost: { mana: 7, wheat: 4, iron: 4 }, stats: { attack: 6, health: 8 }, text: 'Build-around payoff effect.' },
  },
  {
    id: 'tmpl-conquest-support',
    label: 'Conquest Support',
    mode: 'conquest',
    type: 'support',
    summary: 'Command support action.',
    patch: { cost: { wheat: 3, iron: 1 }, conquest: { productionSource: 'command' }, keywords: { command: true }, text: 'Support your lane with tactical orders.' },
  },
];

const state = {
  ready: false,
  ui: {
    mode: 'duel',
    experience: 'beginner',
    workspace: 'balanced',
    moduleSearch: '',
    commandQuery: '',
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    moduleOrder: [],
    moduleCollapsed: {},
    modulePinned: {},
    abilityCollapsed: {},
    activeModule: 'identity',
    previewMode: 'full',
    previewShowTags: true,
    previewZoom: 1,
    bottomTab: 'activity',
    commandOpen: false,
  },
  draft: null,
  activity: [],
  validation: { errors: [], warnings: [] },
  abilityTemplates: [],
  pluginTemplates: [],
  userTemplates: [],
  cardLibrary: {},
  profile: {},
  versions: [],
  recentCards: [],
  history: { stack: [], index: -1 },
  autosave: { pending: null, label: 'Autosave idle', at: 0 },
};

function safeClone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function uid(prefix = 'id') {
  if (globalThis.crypto?.randomUUID) return `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
  return `${prefix}-${Math.random().toString(16).slice(2, 10)}`;
}

function num(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function bool(value) {
  return !!value;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function slug(value = '') {
  return String(value).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function parseCsv(value = '') {
  return String(value || '')
    .split(',')
    .map((entry) => slug(entry))
    .filter(Boolean);
}

function normalizeFamilyId(value = '') {
  return DUEL_FAMILIES.includes(slug(value)) ? slug(value) : '';
}

function draftRaceList() {
  const races = new Set(parseCsv(state.draft?.normal?.races || ''));
  const primary = normalizeFamilyId(state.draft?.normal?.race || '');
  if (primary) races.add(primary);
  return [...races];
}

function setDraftRaceList(nextList = []) {
  const clean = [...new Set(nextList.map((entry) => normalizeFamilyId(entry)).filter(Boolean))];
  state.draft.normal.races = clean.join(', ');
  state.draft.normal.race = clean[0] ?? '';
}

function familiarityLabel(family = '') {
  const meta = raceMeta(family || 'dragon');
  return `${raceIconGlyph(meta.id)} ${meta.label}`;
}

function selectedRaceSummary() {
  const races = draftRaceList();
  return races.length ? races.map((entry) => raceMeta(entry).label).join(' / ') : 'Neutral';
}

function generatedRulesText() {
  const manual = String(state.draft.text || '').trim();
  const abilityText = state.draft.abilities.map((ability) => abilitySummary(ability)).filter(Boolean);
  return [manual, ...abilityText].filter(Boolean).join('\n');
}

function archetypeSuggestion() {
  const races = draftRaceList();
  if (races.includes('dragon')) return 'Dragon pressure / flying payoff';
  if (races.includes('spirit')) return 'Spirit threshold / echo value';
  if (races.includes('beast')) return 'Beast curve / familiarity tempo';
  if (races.includes('construct')) return 'Construct board-control shell';
  return state.draft.metadata.role || 'Flexible custom archetype';
}

function loadJsonStorage(key, fallback) {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) || '');
    return parsed && typeof parsed === 'object' ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function saveJsonStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function byPathGet(obj, path, fallback = undefined) {
  const parts = String(path || '').split('.').filter(Boolean);
  let ref = obj;
  for (const part of parts) {
    if (!ref || typeof ref !== 'object') return fallback;
    ref = ref[part];
  }
  return ref === undefined ? fallback : ref;
}

function byPathSet(obj, path, value) {
  const parts = String(path || '').split('.').filter(Boolean);
  if (!parts.length) return;
  let ref = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const key = parts[i];
    if (!ref[key] || typeof ref[key] !== 'object') ref[key] = {};
    ref = ref[key];
  }
  ref[parts[parts.length - 1]] = value;
}

function mergeDeep(target, patch) {
  if (!patch || typeof patch !== 'object') return target;
  Object.entries(patch).forEach(([key, value]) => {
    if (Array.isArray(value)) target[key] = value.slice();
    else if (value && typeof value === 'object') {
      target[key] = target[key] && typeof target[key] === 'object' ? target[key] : {};
      mergeDeep(target[key], value);
    } else target[key] = value;
  });
  return target;
}

function parseGenVersion(tags = []) {
  for (const tag of Array.isArray(tags) ? tags : []) {
    const match = String(tag).toUpperCase().match(/^GEN(\d+)$/);
    if (match) return Number(match[1]);
  }
  return 1;
}

function persistCustomCard(card) {
  if (!card?.id) return { savedCard: card, isNew: false };
  const library = loadJsonStorage(STORAGE.customCards, {});
  const existing = library[card.id] ?? null;
  const now = Date.now();
  const nextGen = existing ? Number(existing.genVersion ?? 1) + 1 : parseGenVersion(card.tags ?? []);
  const sourceTags = new Set([...(card.tags ?? []), 'custom-made']);
  const savedCard = {
    ...existing,
    ...card,
    tags: [...sourceTags],
    genVersion: nextGen,
    customMade: true,
    sourceType: 'custom-made',
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };
  library[card.id] = savedCard;
  saveJsonStorage(STORAGE.customCards, library);

  const profile = loadJsonStorage(STORAGE.profile, {});
  profile.collection = profile.collection ?? {};
  profile.collection[savedCard.id] = Number(profile.collection[savedCard.id] ?? 0);
  if (!existing) profile.collection[savedCard.id] += 1;
  saveJsonStorage(STORAGE.profile, profile);
  state.cardLibrary = library;
  state.profile = profile;
  return { savedCard, isNew: !existing };
}

function typeOptionsForMode(mode = state.ui.mode) {
  if (mode === 'duel') return DUEL_TYPES;
  if (mode === 'conquest') return CONQUEST_TYPES;
  return HYBRID_TYPES;
}

function createAbilityBlock(preset = null) {
  return {
    id: uid('ability'),
    name: preset?.name ?? 'New Ability',
    trigger: preset?.trigger ?? 'battlecry',
    target: preset?.target ?? 'enemy_minion',
    condition: '',
    effect: preset?.effect?.action ?? 'dealDamage',
    amount: num(preset?.effect?.amount, 1),
    duration: 1,
    filters: '',
    scope: 'single',
    family: preset?.family ?? '',
    familyZone: preset?.familyZone ?? 'board',
    sourceFamily: preset?.sourceFamily ?? '',
    targetFamily: preset?.targetFamily ?? '',
    controllerFamily: preset?.controllerFamily ?? '',
    deadFamily: preset?.deadFamily ?? '',
    threshold: num(preset?.threshold, 0),
    familiarityRace: preset?.familiarityRace ?? '',
    familiarityAmount: num(preset?.familiarityAmount, 0),
    familiarityThreshold: num(preset?.familiarityThreshold, 0),
    deckRule: '',
    tokenRace: preset?.tokenRace ?? '',
    counterKey: '',
    timing: 'instant',
    oncePerTurn: false,
    cooldown: 0,
    charges: 0,
    notes: '',
    script: '',
    templateId: preset?.id ?? '',
  };
}

function createDefaultDraft(mode = 'duel') {
  return {
    id: '',
    name: '',
    mode,
    type: mode === 'conquest' ? 'unit' : 'minion',
    rarity: 'common',
    text: '',
    cost: { mana: 1, wheat: 0, iron: 0 },
    stats: { attack: 1, health: 1, defense: 0, range: 1, movement: 1 },
    keywords: Object.fromEntries(KEYWORD_DEFS.map((entry) => [entry.key, false])),
    targeting: {
      source: 'any',
      scope: 'single',
      team: 'enemy',
      placement: '',
      requirement: '',
      filters: '',
      lineOfFire: '',
    },
    art: {
      src: '',
      fit: 'cover',
      x: 50,
      y: 50,
      zoom: 1,
      overlay: '',
      frameTheme: 'default',
      frameTint: '#3ad4c6',
      background: '',
      emblem: '',
      rarityBadge: true,
      notes: '',
    },
    metadata: {
      collection: '',
      packName: 'Gen 4 Booster',
      world: '',
      generation: 'Gen 4',
      tags: '',
      productionSource: '',
      role: '',
      notes: '',
      creatorTags: '',
    },
    normal: {
      race: '',
      races: '',
      element: '',
      damage: 0,
      synergy: '',
      familiarityRace: '',
      familiarityStart: 0,
      familiarityThreshold: 0,
      familiarityReward: '',
      familiarityNotes: '',
      battleCompatibility: 'both',
      requiredModes: '',
      localExclusive: false,
      homeDimension: '',
      includeInPacks: true,
      packType: 'booster',
      catchLimit: 0,
    },
    conquest: {
      side: 'defender',
      productionSource: 'training',
      buildingType: '',
      isBuilding: false,
      isTurret: false,
      isBarricade: false,
      isFacility: false,
      isUpgrade: false,
      isEquipment: false,
      homestead: false,
      pylon: false,
      horde: false,
      giant: false,
      flying: false,
      siege: false,
      attackRange: 1,
      movement: 1,
      battleCompatibility: 'both',
      requiredModes: '',
      producible: true,
    },
    tokenLinks: {
      summons: '',
      generatedBy: '',
      upgradesInto: '',
      equippedBy: '',
    },
    abilities: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    creatorStudioVersion: 2,
  };
}

function applyModeDefaults(mode) {
  state.ui.mode = mode;
  state.draft.mode = mode;
  const options = typeOptionsForMode(mode);
  if (!options.includes(state.draft.type)) state.draft.type = options[0];
}

function pushHistory(reason = 'change') {
  const snapshot = {
    draft: safeClone(state.draft),
    ui: {
      mode: state.ui.mode,
      experience: state.ui.experience,
      workspace: state.ui.workspace,
      previewMode: state.ui.previewMode,
      previewShowTags: state.ui.previewShowTags,
      previewZoom: state.ui.previewZoom,
      moduleCollapsed: { ...state.ui.moduleCollapsed },
      modulePinned: { ...state.ui.modulePinned },
      moduleOrder: state.ui.moduleOrder.slice(),
    },
    reason,
    at: Date.now(),
  };
  state.history.stack = state.history.stack.slice(0, state.history.index + 1);
  state.history.stack.push(snapshot);
  if (state.history.stack.length > 120) state.history.stack.shift();
  state.history.index = state.history.stack.length - 1;
}

function restoreHistory(index) {
  const snap = state.history.stack[index];
  if (!snap) return;
  state.history.index = index;
  state.draft = safeClone(snap.draft);
  state.ui.mode = snap.ui.mode;
  state.ui.experience = snap.ui.experience;
  state.ui.workspace = snap.ui.workspace;
  state.ui.previewMode = snap.ui.previewMode;
  state.ui.previewShowTags = snap.ui.previewShowTags;
  state.ui.previewZoom = snap.ui.previewZoom;
  state.ui.moduleCollapsed = { ...snap.ui.moduleCollapsed };
  state.ui.modulePinned = { ...snap.ui.modulePinned };
  state.ui.moduleOrder = snap.ui.moduleOrder.slice();
  queueAutosave();
  validateDraft();
  renderAll();
  logActivity(`History restored (${snap.reason}).`);
}

function undo() {
  if (state.history.index <= 0) return;
  restoreHistory(state.history.index - 1);
}

function redo() {
  if (state.history.index >= state.history.stack.length - 1) return;
  restoreHistory(state.history.index + 1);
}

function queueAutosave() {
  if (state.autosave.pending) clearTimeout(state.autosave.pending);
  state.autosave.label = 'Autosave pending...';
  renderStatusRow();
  state.autosave.pending = setTimeout(() => {
    state.autosave.pending = null;
    saveProjectDraft();
  }, 550);
}

function saveProjectDraft() {
  const payload = {
    draft: state.draft,
    ui: {
      mode: state.ui.mode,
      experience: state.ui.experience,
      workspace: state.ui.workspace,
      moduleOrder: state.ui.moduleOrder,
      moduleCollapsed: state.ui.moduleCollapsed,
      modulePinned: state.ui.modulePinned,
      previewMode: state.ui.previewMode,
      previewShowTags: state.ui.previewShowTags,
      previewZoom: state.ui.previewZoom,
      bottomTab: state.ui.bottomTab,
    },
    updatedAt: Date.now(),
  };
  saveJsonStorage(STORAGE.projectDraft, payload);
  state.autosave.at = Date.now();
  state.autosave.label = `Autosaved ${new Date(state.autosave.at).toLocaleTimeString()}`;
  renderStatusRow();
}

function loadProjectDraft() {
  const payload = loadJsonStorage(STORAGE.projectDraft, null);
  if (!payload?.draft) return false;
  state.draft = mergeDeep(createDefaultDraft(payload.ui?.mode ?? state.ui.mode), safeClone(payload.draft));
  if (payload.ui) {
    state.ui.mode = payload.ui.mode ?? state.ui.mode;
    state.ui.experience = payload.ui.experience ?? state.ui.experience;
    state.ui.workspace = payload.ui.workspace ?? state.ui.workspace;
    state.ui.moduleOrder = Array.isArray(payload.ui.moduleOrder) ? payload.ui.moduleOrder.slice() : state.ui.moduleOrder;
    state.ui.moduleCollapsed = payload.ui.moduleCollapsed ?? state.ui.moduleCollapsed;
    state.ui.modulePinned = payload.ui.modulePinned ?? state.ui.modulePinned;
    state.ui.previewMode = payload.ui.previewMode ?? state.ui.previewMode;
    state.ui.previewShowTags = payload.ui.previewShowTags ?? state.ui.previewShowTags;
    state.ui.previewZoom = payload.ui.previewZoom ?? state.ui.previewZoom;
    state.ui.bottomTab = payload.ui.bottomTab ?? state.ui.bottomTab;
  }
  return true;
}

function complexityScore() {
  const keywordCount = KEYWORD_DEFS.filter((def) => state.draft.keywords[def.key]).length;
  const abilityCount = state.draft.abilities.length;
  const costWeight = num(state.draft.cost.mana, 0) + num(state.draft.cost.wheat, 0) + num(state.draft.cost.iron, 0);
  const statWeight = num(state.draft.stats.attack, 0) + num(state.draft.stats.health, 0) + num(state.draft.stats.range, 0) + num(state.draft.stats.movement, 0);
  const textWeight = Math.ceil((state.draft.text || '').length / 70);
  return clamp(keywordCount + (abilityCount * 3) + Math.round(costWeight * 0.7) + Math.round(statWeight * 0.45) + textWeight, 1, 100);
}

function complexityTier(score) {
  if (score < 18) return 'Simple';
  if (score < 34) return 'Moderate';
  if (score < 55) return 'Advanced';
  return 'Expert';
}

function draftTagsArray() {
  return String(state.draft.metadata.tags || '')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function raceChipMarkup(selected = []) {
  return DUEL_FAMILIES.map((family) => {
    const meta = raceMeta(family);
    const active = selected.includes(family);
    return `<button type="button" class="race-chip ${active ? 'active' : ''}" data-action="toggle-race-tag" data-race="${family}">${raceIconGlyph(family)} ${escapeHtml(meta.label)}</button>`;
  }).join('');
}

function raceArchetypeMarkup() {
  return Object.entries(RACE_ARCHETYPE_PRESETS).map(([id, preset]) => (
    `<button type="button" class="ghost" data-action="apply-race-archetype" data-archetype="${id}">${escapeHtml(preset.label)}</button>`
  )).join('');
}

function moduleStatus(moduleId) {
  const errors = state.validation.errors.filter((item) => item.module === moduleId);
  const warnings = state.validation.warnings.filter((item) => item.module === moduleId);
  if (errors.length) return { tone: 'bad', label: `${errors.length} issue(s)` };
  if (warnings.length) return { tone: 'warn', label: `${warnings.length} warning(s)` };
  return { tone: 'good', label: 'Complete' };
}

function moduleRegistry() {
  return [
    { id: 'identity', title: 'Card Identity', subtitle: 'Name, ID, rarity, primary text', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderIdentityModule },
    { id: 'type-mode', title: 'Type & Mode', subtitle: 'Card type + mode behavior', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderTypeModeModule },
    { id: 'costs-stats', title: 'Costs & Stats', subtitle: 'Mana/resources and combat stats', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderCostsStatsModule },
    { id: 'race-familiarity', title: 'Race & Familiarity', subtitle: 'Species identity, tribe mix and familiarity growth', modes: ['duel', 'hybrid'], levels: ['beginner', 'advanced'], render: renderRaceFamiliarityModule },
    { id: 'keywords', title: 'Keywords', subtitle: 'Fast tactical markers and identities', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderKeywordsModule },
    { id: 'abilities', title: 'Ability Builder', subtitle: 'Composable trigger-condition-effect blocks', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderAbilityModule },
    { id: 'targeting', title: 'Targeting & Rules', subtitle: 'Target filters and placement restrictions', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderTargetingModule },
    { id: 'art-frame', title: 'Art / PNG / Overlay Studio', subtitle: 'Upload, crop, frame and readability checks', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderArtModule },
    { id: 'normal-options', title: 'Normal Mode Options', subtitle: 'Duel-specific metadata and behaviors', modes: ['duel', 'hybrid'], levels: ['beginner', 'advanced'], render: renderNormalModeModule },
    { id: 'conquest-options', title: 'Conquest Options', subtitle: 'Production source, side and structure flags', modes: ['conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderConquestModule },
    { id: 'tokens-links', title: 'Tokens / Linked Cards', subtitle: 'Generated cards and relationships', modes: ['duel', 'conquest', 'hybrid'], levels: ['advanced'], render: renderTokenLinksModule },
    { id: 'collection-meta', title: 'Collection Metadata', subtitle: 'Pack, collection, role and tags', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderCollectionModule },
    { id: 'templates', title: 'Template Library', subtitle: 'Start from preset archetypes', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderTemplatesModule },
    { id: 'validation', title: 'Validation', subtitle: 'Schema and gameplay safety checks', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderValidationModule },
    { id: 'save-export', title: 'Save / Export / Clone', subtitle: 'Persistence and interchange', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderSaveExportModule },
  ];
}

function visibleModules() {
  const modules = moduleRegistry().filter((mod) => mod.modes.includes(state.ui.mode) && mod.levels.includes(state.ui.experience));
  const order = state.ui.moduleOrder.length ? state.ui.moduleOrder : modules.map((mod) => mod.id);
  const orderIndex = new Map(order.map((id, idx) => [id, idx]));
  modules.sort((a, b) => (orderIndex.get(a.id) ?? 999) - (orderIndex.get(b.id) ?? 999));
  modules.sort((a, b) => {
    const aPinned = state.ui.modulePinned[a.id] ? 1 : 0;
    const bPinned = state.ui.modulePinned[b.id] ? 1 : 0;
    return bPinned - aPinned;
  });
  const q = state.ui.moduleSearch.trim().toLowerCase();
  if (!q) return modules;
  return modules.filter((mod) => `${mod.title} ${mod.subtitle}`.toLowerCase().includes(q));
}

function syncTopbarSelections() {
  const modeSelect = document.querySelector('#creator-card-mode');
  const expSelect = document.querySelector('#creator-experience');
  const typeSelect = document.querySelector('#creator-type-quick');
  const workspaceSelect = document.querySelector('#workspace-preset-select');
  if (modeSelect) modeSelect.value = state.ui.mode;
  if (expSelect) expSelect.value = state.ui.experience;
  if (workspaceSelect) workspaceSelect.value = state.ui.workspace;
  if (!typeSelect) return;
  const options = typeOptionsForMode();
  typeSelect.innerHTML = options.map((type) => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join('');
  if (!options.includes(state.draft.type)) state.draft.type = options[0];
  typeSelect.value = state.draft.type;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function previewCardTitle() {
  return state.draft.name || 'Untitled Card';
}

function parseTagsForCard() {
  const tags = draftTagsArray();
  const keywordTags = KEYWORD_DEFS.filter((entry) => state.draft.keywords[entry.key]).map((entry) => entry.label);
  const raceTags = draftRaceList().map((entry) => raceMeta(entry).label);
  return [...tags, ...keywordTags, ...raceTags];
}

function renderStatusRow() {
  const autosave = document.querySelector('#autosave-indicator');
  const validation = document.querySelector('#validation-summary');
  const complexity = document.querySelector('#complexity-meter');
  const draftMeta = document.querySelector('#draft-meta');
  if (autosave) autosave.textContent = state.autosave.label;
  if (validation) {
    const errorCount = state.validation.errors.length;
    const warningCount = state.validation.warnings.length;
    validation.textContent = errorCount ? `${errorCount} errors` : warningCount ? `${warningCount} warnings` : 'Validation clear';
    validation.classList.remove('good', 'warn', 'bad');
    validation.classList.add(errorCount ? 'bad' : warningCount ? 'warn' : 'good');
  }
  if (complexity) {
    const score = complexityScore();
    complexity.textContent = `Complexity: ${complexityTier(score)} (${score})`;
  }
  if (draftMeta) {
    const updated = state.draft.updatedAt ? new Date(state.draft.updatedAt).toLocaleTimeString() : 'unsaved';
    draftMeta.textContent = `Draft: ${state.draft.id || 'new'} • ${updated}`;
  }
}

function renderLeftPane() {
  const host = document.querySelector('#studio-left');
  if (!host) return;
  const modules = visibleModules();
  const templates = allTemplates().filter((tmpl) => tmpl.mode === state.ui.mode || tmpl.mode === 'hybrid');
  const recent = state.recentCards.slice(0, 8);
  host.innerHTML = `
    <div class="left-head">
      <strong>Creator Navigation</strong>
      <button type="button" data-action="toggle-left">${state.ui.leftCollapsed ? '>' : 'v'}</button>
    </div>
    <div class="left-body">
      <div class="field-search-wrap">
        <label>Search Modules
          <input type="text" id="module-search" value="${escapeHtml(state.ui.moduleSearch)}" placeholder="Search sections..." />
        </label>
      </div>
      <div class="nav-list">
        ${modules.map((module) => {
          const status = moduleStatus(module.id);
          return `
            <div class="nav-item" data-module-nav="${module.id}">
              <div class="row">
                <button type="button" data-action="jump-module" data-module="${module.id}">${escapeHtml(module.title)}</button>
                <span class="status-dot ${status.tone}"></span>
              </div>
              <div class="meta">${escapeHtml(module.subtitle)} • ${status.label}</div>
            </div>
          `;
        }).join('')}
      </div>

      <div class="template-search-wrap" style="margin-top:0.7rem;">
        <strong>Template Quickstart</strong>
      </div>
      <div class="template-list">
        ${templates.slice(0, 8).map((template) => `
          <div class="template-item">
            <div class="row">
              <button type="button" data-action="apply-template" data-template-id="${template.id}">${escapeHtml(template.label)}</button>
              <small>${escapeHtml(template.type)}</small>
            </div>
            <div class="meta">${escapeHtml(template.summary || '')}</div>
          </div>
        `).join('')}
      </div>

      <div style="margin-top:0.7rem;"><strong>Recent Cards</strong></div>
      <div class="quick-list">
        ${recent.length ? recent.map((entry) => `
          <div class="quick-item">
            <div class="row">
              <button type="button" data-action="load-card-id" data-card-id="${escapeHtml(entry.id)}">${escapeHtml(entry.name || entry.id)}</button>
              <small>${escapeHtml(entry.type || 'card')}</small>
            </div>
          </div>
        `).join('') : '<div class="note">No recent cards saved yet.</div>'}
      </div>

      <div class="workspace-preset-grid">
        <button type="button" data-action="workspace-preset" data-preset="balanced">Balanced</button>
        <button type="button" data-action="workspace-preset" data-preset="compact">Compact</button>
        <button type="button" data-action="workspace-preset" data-preset="ability_forge">Ability Forge</button>
        <button type="button" data-action="workspace-preset" data-preset="preview_focus">Preview Focus</button>
      </div>
    </div>
  `;
}

function renderCenterPane() {
  const host = document.querySelector('#studio-center');
  if (!host) return;
  const modules = visibleModules();
  host.innerHTML = modules.map((module, index) => {
    const collapsed = state.ui.moduleCollapsed[module.id];
    const pinned = !!state.ui.modulePinned[module.id];
    return `
      <article class="module-panel" id="module-${module.id}" data-module="${module.id}">
        <header class="module-head">
          <div class="title-wrap">
            <h3>${escapeHtml(module.title)}</h3>
            <small>${escapeHtml(module.subtitle)}</small>
          </div>
          <div class="module-tools">
            <button type="button" data-action="module-pin" data-module="${module.id}" title="Pin">${pinned ? '★' : '☆'}</button>
            <button type="button" data-action="module-move-up" data-module="${module.id}" ${index === 0 ? 'disabled' : ''}>↑</button>
            <button type="button" data-action="module-move-down" data-module="${module.id}" ${index === modules.length - 1 ? 'disabled' : ''}>↓</button>
            <button type="button" data-action="module-collapse" data-module="${module.id}">${collapsed ? '>' : 'v'}</button>
          </div>
        </header>
        <div class="module-body ${collapsed ? 'collapsed' : ''}">
          ${module.render()}
        </div>
      </article>
    `;
  }).join('');
  bindDropzone();
}

function renderRightPane() {
  const host = document.querySelector('#studio-right');
  if (!host) return;
  const tags = parseTagsForCard();
  const races = draftRaceList();
  const previewClass = PREVIEW_MODES.includes(state.ui.previewMode) ? state.ui.previewMode : 'full';
  const artStyle = state.draft.art.src
    ? `background-image:url('${state.draft.art.src}');background-size:${state.draft.art.fit};background-position:${state.draft.art.x}% ${state.draft.art.y}%;`
    : 'background-image:linear-gradient(135deg,#203555,#11253f);';
  const manaCost = `M:${num(state.draft.cost.mana, 0)} W:${num(state.draft.cost.wheat, 0)} I:${num(state.draft.cost.iron, 0)}`;
  host.innerHTML = `
    <div class="right-head">
      <strong>Live Preview</strong>
      <button type="button" data-action="toggle-right">${state.ui.rightCollapsed ? '>' : 'v'}</button>
    </div>
    <div class="right-body">
      <section class="preview-controls">
        <div class="field-grid">
          <label>Preview Mode
            <select id="preview-mode-select">
              ${PREVIEW_MODES.map((mode) => `<option value="${mode}" ${mode === state.ui.previewMode ? 'selected' : ''}>${mode}</option>`).join('')}
            </select>
          </label>
          <label>Preview Zoom
            <input type="range" min="0.7" max="1.35" step="0.05" id="preview-zoom" value="${state.ui.previewZoom}" />
          </label>
          <label>Show Tags
            <select id="preview-show-tags">
              <option value="yes" ${state.ui.previewShowTags ? 'selected' : ''}>Visible</option>
              <option value="no" ${!state.ui.previewShowTags ? 'selected' : ''}>Hidden</option>
            </select>
          </label>
        </div>
        <div class="inline-chips">
          <button type="button" data-action="preview-popout">Popout</button>
          <button type="button" data-action="quick-validate">Run Validation</button>
          <button type="button" data-action="save-version">Save Version</button>
        </div>
      </section>

      <section class="preview-stage">
        <div class="card-preview ${previewClass}" style="transform:scale(${state.ui.previewZoom}); transform-origin: top center;">
          <div class="card-layer-art" style="${artStyle}"></div>
          <div class="card-content">
            <div class="card-top">
              <div class="card-name">${escapeHtml(previewCardTitle())}</div>
              <div class="card-cost">${escapeHtml(manaCost)}</div>
            </div>
            <div class="preview-family-row">${races.length ? races.map((race) => `<span class="race-chip static">${raceIconGlyph(race)} ${escapeHtml(raceMeta(race).label)}</span>`).join('') : '<span class="race-chip static">NE Neutral</span>'}</div>
            <div class="card-text">${escapeHtml(generatedRulesText() || 'No rules text yet.')}</div>
            <div class="card-bottom">
              <div class="card-stats">
                <span class="stat-pill">ATK ${num(state.draft.stats.attack, 0)}</span>
                <span class="stat-pill">HP ${num(state.draft.stats.health, 0)}</span>
                <span class="stat-pill">DEF ${num(state.draft.stats.defense, 0)}</span>
              </div>
              <div class="stat-pill">${escapeHtml(state.draft.type)} • ${escapeHtml(state.draft.rarity)}</div>
            </div>
          </div>
        </div>
        ${state.ui.previewShowTags ? `<div class="inline-chips" style="margin-top:.55rem;">${tags.length ? tags.map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join('') : '<span class="chip">No tags</span>'}</div>` : ''}
      </section>

      <section class="preview-insights">
        <div class="${state.validation.errors.length ? 'error-box' : 'success-box'}">
          ${state.validation.errors.length ? `Errors: ${state.validation.errors.length}` : 'No critical errors.'}
        </div>
        ${state.validation.warnings.length ? `<div class="warning">Warnings: ${state.validation.warnings.length}</div>` : ''}
        <div class="note">Mode: ${escapeHtml(state.ui.mode)} • Workflow: ${escapeHtml(state.ui.experience)} • Abilities: ${state.draft.abilities.length}</div>
        <div class="note">Families: ${escapeHtml(selectedRaceSummary())} • Familiarity: ${state.draft.normal.familiarityRace ? `${familiarityLabel(state.draft.normal.familiarityRace)} start ${num(state.draft.normal.familiarityStart, 0)}` : 'none'}</div>
        <div class="note">Archetype suggestion: ${escapeHtml(archetypeSuggestion())}</div>
      </section>
    </div>
  `;
}

function renderBottomPane() {
  const host = document.querySelector('#studio-bottom');
  if (!host) return;
  const tabs = [
    ['activity', 'Activity'],
    ['ability-json', 'Ability JSON'],
    ['project-json', 'Project JSON'],
    ['docs', 'Docs'],
    ['versions', 'Versions'],
  ];
  let content = '';
  if (state.ui.bottomTab === 'activity') {
    const rows = state.activity.slice(-80).reverse();
    content = rows.length
      ? rows.map((entry) => `<div class="note">${escapeHtml(new Date(entry.at).toLocaleTimeString())} • ${escapeHtml(entry.msg)}</div>`).join('')
      : '<div class="note">No activity yet.</div>';
  } else if (state.ui.bottomTab === 'ability-json') {
    content = `<pre class="mono">${escapeHtml(JSON.stringify(state.draft.abilities, null, 2))}</pre>`;
  } else if (state.ui.bottomTab === 'project-json') {
    content = `
      <textarea id="project-json-editor" class="mono">${escapeHtml(JSON.stringify(state.draft, null, 2))}</textarea>
      <div class="inline-chips">
        <button type="button" data-action="copy-project-json">Copy JSON</button>
        <button type="button" data-action="import-project-json">Import JSON</button>
      </div>
    `;
  } else if (state.ui.bottomTab === 'docs') {
    content = `
      <div class="note">Beginner mode hides advanced modules and focuses on essentials.</div>
      <div class="note">Advanced mode exposes full targeting, production, and scripting metadata.</div>
      <div class="note">Use Ability Builder presets to rapidly scaffold card logic.</div>
      <div class="note">Save versions frequently before major balance edits.</div>
    `;
  } else if (state.ui.bottomTab === 'versions') {
    content = state.versions.length
      ? state.versions.map((version, idx) => `
        <div class="template-item">
          <div class="row">
            <strong>${escapeHtml(version.label || `Version ${idx + 1}`)}</strong>
            <small>${escapeHtml(new Date(version.at).toLocaleString())}</small>
          </div>
          <div class="row" style="margin-top:.28rem;">
            <button type="button" data-action="restore-version" data-version-index="${idx}">Restore</button>
            <button type="button" data-action="delete-version" data-version-index="${idx}">Delete</button>
          </div>
        </div>
      `).join('')
      : '<div class="note">No saved versions.</div>';
  }

  host.innerHTML = `
    <div class="bottom-head">
      <strong>Studio Drawer</strong>
      <button type="button" data-action="toggle-bottom">${state.ui.bottomCollapsed ? '>' : 'v'}</button>
    </div>
    <div class="bottom-tabs">
      ${tabs.map(([id, label]) => `<button type="button" data-action="bottom-tab" data-tab="${id}" ${id === state.ui.bottomTab ? 'class="primary"' : ''}>${label}</button>`).join('')}
    </div>
    <div class="bottom-content">${content}</div>
  `;
}

function renderCommandPalette() {
  const overlay = document.querySelector('#command-palette');
  const list = document.querySelector('#command-list');
  const search = document.querySelector('#command-search');
  if (!overlay || !list || !search) return;
  overlay.classList.toggle('hidden', !state.ui.commandOpen);
  overlay.setAttribute('aria-hidden', state.ui.commandOpen ? 'false' : 'true');
  search.value = state.ui.commandQuery;
  if (state.ui.commandOpen) search.focus();
  const items = commandItems().filter((item) => {
    const q = state.ui.commandQuery.trim().toLowerCase();
    if (!q) return true;
    return `${item.label} ${item.group}`.toLowerCase().includes(q);
  });
  list.innerHTML = items.map((item) => `
    <button type="button" class="command-item" data-action="run-command" data-command-id="${item.id}">
      <span>${escapeHtml(item.label)}</span>
      <small>${escapeHtml(item.group)}</small>
    </button>
  `).join('') || '<div class="note">No matching command.</div>';
}

function renderAll() {
  if (!state.ready) return;
  syncTopbarSelections();
  applyLayoutClasses();
  renderStatusRow();
  renderLeftPane();
  renderCenterPane();
  renderRightPane();
  renderBottomPane();
  renderCommandPalette();
}

function applyLayoutClasses() {
  document.body.classList.toggle('left-collapsed', state.ui.leftCollapsed);
  document.body.classList.toggle('right-collapsed', state.ui.rightCollapsed);
  document.body.classList.toggle('bottom-collapsed', state.ui.bottomCollapsed);
}

function allTemplates() {
  const pluginTemplates = state.pluginTemplates.map((card) => ({
    id: `plugin-${card.id}`,
    label: card.name || card.id,
    mode: deduceModeFromTemplate(card),
    type: card.type || 'minion',
    summary: 'Plugin template',
    patch: card,
  }));
  const userTemplates = state.userTemplates.map((entry) => ({ ...entry, id: `user-${entry.id}` }));
  return [...BUILTIN_TEMPLATES, ...pluginTemplates, ...userTemplates];
}

function deduceModeFromTemplate(template) {
  const compat = String(template.battleCompatibility || template.requiredModes || '').toLowerCase();
  if (compat.includes('conquest') || template.productionBuildingType || template.producible) return 'conquest';
  if (compat.includes('both')) return 'hybrid';
  return 'duel';
}

function logActivity(msg) {
  state.activity.push({ at: Date.now(), msg });
  if (state.activity.length > 300) state.activity.shift();
}

function validateDraft() {
  const errors = [];
  const warnings = [];
  const races = draftRaceList();
  if (!state.draft.id.trim()) errors.push({ module: 'identity', path: 'id', message: 'Card ID is required.' });
  if (!/^[a-z0-9][a-z0-9-_]*$/i.test(state.draft.id.trim())) warnings.push({ module: 'identity', path: 'id', message: 'Use stable slug-like card IDs.' });
  if (!state.draft.name.trim()) errors.push({ module: 'identity', path: 'name', message: 'Card name is required.' });
  if (!typeOptionsForMode().includes(state.draft.type)) errors.push({ module: 'type-mode', path: 'type', message: 'Card type is invalid for current mode.' });
  if (num(state.draft.cost.mana, 0) < 0 || num(state.draft.cost.wheat, 0) < 0 || num(state.draft.cost.iron, 0) < 0) {
    errors.push({ module: 'costs-stats', path: 'cost', message: 'Costs must be non-negative.' });
  }
  if (num(state.draft.stats.health, 0) <= 0 && !['spell', 'relic', 'field', 'tactic', 'support', 'upgrade', 'equipment'].includes(state.draft.type)) {
    errors.push({ module: 'costs-stats', path: 'stats.health', message: 'Units/buildings need health above 0.' });
  }
  if (state.ui.mode === 'conquest') {
    if (!state.draft.conquest.productionSource) warnings.push({ module: 'conquest-options', path: 'conquest.productionSource', message: 'Set a production source for conquest cards.' });
    if (state.draft.conquest.isBuilding && num(state.draft.stats.attack, 0) > 0 && !state.draft.keywords.turret) warnings.push({ module: 'conquest-options', path: 'conquest.isBuilding', message: 'Attacking buildings should usually be tagged as turret.' });
  }
  if (state.ui.mode === 'duel' && state.draft.conquest.isBuilding) warnings.push({ module: 'conquest-options', path: 'conquest.isBuilding', message: 'Conquest flags are set while in duel mode.' });
  if (state.ui.mode !== 'conquest' && !races.length) warnings.push({ module: 'race-familiarity', path: 'normal.race', message: 'Set at least one race/family for duel cards that use tribe or familiarity mechanics.' });
  if (state.draft.normal.familiarityRace && !races.includes(state.draft.normal.familiarityRace)) warnings.push({ module: 'race-familiarity', path: 'normal.familiarityRace', message: 'Familiarity race should usually be part of the card family mix.' });
  if (state.draft.normal.familiarityThreshold > 0 && !state.draft.normal.familiarityReward.trim()) warnings.push({ module: 'race-familiarity', path: 'normal.familiarityReward', message: 'Familiarity threshold is set but no reward text is described.' });
  if (state.draft.normal.localExclusive && state.draft.normal.includeInPacks) warnings.push({ module: 'normal-mode', path: 'normal.localExclusive', message: 'Local-exclusive cards are usually excluded from normal pack progression.' });
  if (!state.draft.text.trim() && state.draft.abilities.length === 0) warnings.push({ module: 'identity', path: 'text', message: 'Card has no text or ability blocks.' });
  if (state.draft.abilities.some((ability) => !ability.trigger || !ability.effect)) errors.push({ module: 'abilities', path: 'abilities', message: 'Every ability needs trigger and effect.' });
  if (state.draft.abilities.some((ability) => ability.family && !DUEL_FAMILIES.includes(ability.family))) warnings.push({ module: 'abilities', path: 'abilities.family', message: 'Ability family filter should use a standardized race/type.' });
  if (state.draft.abilities.some((ability) => ability.familiarityThreshold > 0 && !ability.familiarityRace)) warnings.push({ module: 'abilities', path: 'abilities.familiarityRace', message: 'Familiarity threshold ability is missing a familiarity race.' });
  if (state.draft.abilities.some((ability) => ability.targetFamily && !ability.family && !ability.sourceFamily && !ability.controllerFamily)) warnings.push({ module: 'abilities', path: 'abilities.targetFamily', message: 'Target race filters work best with a source/controller race filter.' });
  if (state.draft.art.src && !/^data:image\/|^https?:\/\//i.test(state.draft.art.src)) warnings.push({ module: 'art-frame', path: 'art.src', message: 'Art source should be a URL or uploaded data image.' });
  if (!state.draft.metadata.packName.trim()) warnings.push({ module: 'collection-meta', path: 'metadata.packName', message: 'Pack assignment is empty.' });
  if (state.draft.id && state.cardLibrary[state.draft.id]) warnings.push({ module: 'save-export', path: 'id', message: 'Saving will overwrite existing custom card with same ID.' });
  state.validation = { errors, warnings };
}

function abilitySummary(block) {
  const trigger = String(block.trigger || 'Trigger').replace(/_/g, ' ');
  const family = normalizeFamilyId(block.family);
  const familyLabel = family ? raceMeta(family).label : '';
  const familiarityRace = normalizeFamilyId(block.familiarityRace);
  const familiarityLabelText = familiarityRace ? raceMeta(familiarityRace).label : '';
  const sourceFamily = normalizeFamilyId(block.sourceFamily);
  const targetFamily = normalizeFamilyId(block.targetFamily);
  const controllerFamily = normalizeFamilyId(block.controllerFamily);
  const target = block.target ? String(block.target).replace(/_/g, ' ') : 'target';
  const duration = num(block.duration, 1) > 1 ? ` for ${num(block.duration, 1)} turns` : '';
  const filterBits = [
    sourceFamily ? `source ${raceMeta(sourceFamily).label}` : '',
    targetFamily ? `target ${raceMeta(targetFamily).label}` : '',
    controllerFamily ? `controller has ${raceMeta(controllerFamily).label}` : '',
  ].filter(Boolean);
  const filterSuffix = filterBits.length ? ` [${filterBits.join(' • ')}]` : '';

  if (block.effect === 'gainStats' && familyLabel) {
    const zone = block.familyZone || 'board';
    return `${trigger}: For every ${familyLabel} in your ${zone}, gain +${num(block.amount, 1)}/+${num(block.amount, 1)}${duration}${filterSuffix}.`;
  }
  if (block.effect === 'reduceCost' && familyLabel) {
    return `${trigger}: This costs (${num(block.amount, 1)}) less for each ${familyLabel} in your ${block.familyZone || 'hand'}${filterSuffix}.`;
  }
  if (block.effect === 'draw' && familyLabel && num(block.threshold, 0) > 0) {
    return `${trigger}: If you control ${num(block.threshold, 0)} or more ${familyLabel}, draw ${num(block.amount, 1)}.`;
  }
  if (block.effect === 'gainFamiliarity' && familyLabel) {
    return `${trigger}: Gain ${num(block.amount, 1)} ${familyLabel} Familiarity.`;
  }
  if (block.effect === 'spendFamiliarity' && familiarityLabelText) {
    return `${trigger}: Spend ${num(block.familiarityAmount || block.amount, 1)} ${familiarityLabelText} Familiarity.`;
  }
  if (familiarityLabelText && num(block.familiarityThreshold, 0) > 0) {
    return `${trigger}: ${familiarityLabelText} Familiarity ${num(block.familiarityThreshold, 0)} -> ${String(block.effect).replace(/([A-Z])/g, ' $1').trim()} ${num(block.amount, 0)} on ${target}${duration}.`;
  }
  const base = `${trigger}: ${String(block.effect || 'effect').replace(/([A-Z])/g, ' $1').trim()} ${num(block.amount, 0)}`;
  const targetText = target ? ` on ${target}` : '';
  const condition = block.condition ? ` if ${block.condition}` : '';
  return `${base}${targetText}${condition}${filterSuffix}${duration}.`;
}

function renderIdentityModule() {
  return `
    <div class="field-grid">
      <label>Card ID<input type="text" data-path="id" value="${escapeHtml(state.draft.id)}" placeholder="gen4-card-id" /></label>
      <label>Card Name<input type="text" data-path="name" value="${escapeHtml(state.draft.name)}" placeholder="Card Name" /></label>
      <label>Rarity
        <select data-path="rarity">
          ${RARITIES.map((rarity) => `<option value="${rarity}" ${state.draft.rarity === rarity ? 'selected' : ''}>${rarity}</option>`).join('')}
        </select>
      </label>
      <label>Generation<input type="text" data-path="metadata.generation" value="${escapeHtml(state.draft.metadata.generation)}" /></label>
    </div>
    <div class="stack">
      <label>Rules Text<textarea data-path="text" placeholder="Rules text...">${escapeHtml(state.draft.text)}</textarea></label>
      <label>Design Notes<textarea data-path="metadata.notes" placeholder="Internal dev notes...">${escapeHtml(state.draft.metadata.notes)}</textarea></label>
    </div>
  `;
}

function renderTypeModeModule() {
  return `
    <div class="field-grid">
      <label>Card Mode
        <select id="module-mode-select">
          <option value="duel" ${state.ui.mode === 'duel' ? 'selected' : ''}>Normal Mode</option>
          <option value="conquest" ${state.ui.mode === 'conquest' ? 'selected' : ''}>Conquest Mode</option>
          <option value="hybrid" ${state.ui.mode === 'hybrid' ? 'selected' : ''}>Hybrid</option>
        </select>
      </label>
      <label>Card Type
        <select data-path="type">
          ${typeOptionsForMode().map((type) => `<option value="${type}" ${state.draft.type === type ? 'selected' : ''}>${type}</option>`).join('')}
        </select>
      </label>
      <label>Workflow
        <select id="module-experience-select">
          <option value="beginner" ${state.ui.experience === 'beginner' ? 'selected' : ''}>Beginner</option>
          <option value="advanced" ${state.ui.experience === 'advanced' ? 'selected' : ''}>Advanced</option>
        </select>
      </label>
      <label>Workspace Preset
        <select id="module-workspace-select">
          <option value="balanced" ${state.ui.workspace === 'balanced' ? 'selected' : ''}>Balanced</option>
          <option value="compact" ${state.ui.workspace === 'compact' ? 'selected' : ''}>Compact</option>
          <option value="ability_forge" ${state.ui.workspace === 'ability_forge' ? 'selected' : ''}>Ability Forge</option>
          <option value="preview_focus" ${state.ui.workspace === 'preview_focus' ? 'selected' : ''}>Preview Focus</option>
        </select>
      </label>
    </div>
    <div class="note">Mode-adaptive modules will auto-show relevant controls and hide incompatible sections.</div>
  `;
}

function renderCostsStatsModule() {
  const type = state.draft.type;
  const spellLike = ['spell', 'tactic', 'support', 'upgrade', 'equipment', 'field', 'relic', 'trap'].includes(type);
  return `
    <div class="field-grid">
      <label>Mana Cost<input type="number" min="0" data-path="cost.mana" value="${num(state.draft.cost.mana, 0)}" /></label>
      <label>Wheat Cost<input type="number" min="0" data-path="cost.wheat" value="${num(state.draft.cost.wheat, 0)}" /></label>
      <label>Iron Cost<input type="number" min="0" data-path="cost.iron" value="${num(state.draft.cost.iron, 0)}" /></label>
      ${spellLike ? `<label>Spell Damage<input type="number" min="0" data-path="normal.damage" value="${num(state.draft.normal.damage, 0)}" /></label>` : ''}
      ${!spellLike ? `<label>Attack<input type="number" min="0" data-path="stats.attack" value="${num(state.draft.stats.attack, 0)}" /></label>` : ''}
      ${!spellLike ? `<label>Health<input type="number" min="1" data-path="stats.health" value="${num(state.draft.stats.health, 1)}" /></label>` : ''}
      <label>Defense<input type="number" min="0" data-path="stats.defense" value="${num(state.draft.stats.defense, 0)}" /></label>
      <label>Range<input type="number" min="1" data-path="stats.range" value="${num(state.draft.stats.range, 1)}" /></label>
      <label>Movement<input type="number" min="0" data-path="stats.movement" value="${num(state.draft.stats.movement, 1)}" /></label>
    </div>
  `;
}

function renderKeywordsModule() {
  return `
    <div class="inline-chips">
      ${KEYWORD_DEFS.map((keyword) => `
        <label class="chip">
          <input type="checkbox" data-path="keywords.${keyword.key}" ${state.draft.keywords[keyword.key] ? 'checked' : ''} />
          ${escapeHtml(keyword.label)}
        </label>
      `).join('')}
    </div>
    <div class="note">Type markers are used in preview, inspect panels, and deck/debug tooling.</div>
  `;
}

function renderRaceFamiliarityModule() {
  const selected = draftRaceList();
  return `
    <div class="note">Pick the species mix first, then define how the card rewards race counts or familiarity.</div>
    <div class="inline-chips race-archetype-row">
      ${raceArchetypeMarkup()}
    </div>
    <div class="field-grid">
      <label>Primary Race
        <select data-path="normal.race">
          <option value="">neutral</option>
          ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${state.draft.normal.race === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
        </select>
      </label>
      <label>Race Mix (CSV)<input type="text" data-path="normal.races" value="${escapeHtml(state.draft.normal.races)}" placeholder="dragon, ancient" /></label>
      <label>Element<input type="text" data-path="normal.element" value="${escapeHtml(state.draft.normal.element)}" /></label>
      <label>Archetype Role<input type="text" data-path="metadata.role" value="${escapeHtml(state.draft.metadata.role)}" placeholder="Dragon finisher / race lord" /></label>
      <label>Synergy Hints<input type="text" data-path="normal.synergy" value="${escapeHtml(state.draft.normal.synergy)}" placeholder="dragon,flying,hoard" /></label>
      <label>Familiarity Race
        <select data-path="normal.familiarityRace">
          <option value="">none</option>
          ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${state.draft.normal.familiarityRace === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
        </select>
      </label>
      <label>Starting Familiarity<input type="number" min="0" data-path="normal.familiarityStart" value="${num(state.draft.normal.familiarityStart, 0)}" /></label>
      <label>Threshold<input type="number" min="0" data-path="normal.familiarityThreshold" value="${num(state.draft.normal.familiarityThreshold, 0)}" /></label>
      <label>Threshold Reward<input type="text" data-path="normal.familiarityReward" value="${escapeHtml(state.draft.normal.familiarityReward)}" placeholder="your Dragons cost 1 less" /></label>
    </div>
    <div class="race-chip-grid">${raceChipMarkup(selected)}</div>
    <label>Familiarity Notes<textarea data-path="normal.familiarityNotes">${escapeHtml(state.draft.normal.familiarityNotes)}</textarea></label>
    <div class="note">Current family identity: ${escapeHtml(selectedRaceSummary())}.</div>
    <div class="note">Suggested archetype: ${escapeHtml(archetypeSuggestion())}.</div>
  `;
}

function renderAbilityModule() {
  const presets = state.abilityTemplates;
  return `
    <div class="field-grid">
      <label>Add Preset
        <select id="ability-preset-select">
          <option value="">Custom Empty Block</option>
          ${presets.map((preset) => `<option value="${preset.id}">${escapeHtml(preset.name)} (${escapeHtml(preset.category || 'general')})</option>`).join('')}
        </select>
      </label>
      <label>Ability Ops
        <div class="inline-chips">
          <button type="button" data-action="ability-add">Add Ability</button>
          <button type="button" data-action="ability-save-template">Save Ability Layout</button>
        </div>
      </label>
    </div>
    ${state.draft.abilities.length ? state.draft.abilities.map((block, idx) => {
      const collapsed = !!state.ui.abilityCollapsed[block.id];
      return `
        <div class="ability-block" data-ability-id="${block.id}">
          <div class="ability-head">
            <div>
              <strong>#${idx + 1} ${escapeHtml(block.name || 'Ability')}</strong>
              <div class="ability-summary">${escapeHtml(abilitySummary(block))}</div>
            </div>
            <div class="module-tools">
              <button type="button" data-action="ability-duplicate" data-ability-id="${block.id}">Dupe</button>
              <button type="button" data-action="ability-up" data-ability-id="${block.id}" ${idx === 0 ? 'disabled' : ''}>↑</button>
              <button type="button" data-action="ability-down" data-ability-id="${block.id}" ${idx === state.draft.abilities.length - 1 ? 'disabled' : ''}>↓</button>
              <button type="button" data-action="ability-collapse" data-ability-id="${block.id}">${collapsed ? '>' : 'v'}</button>
              <button type="button" data-action="ability-delete" data-ability-id="${block.id}">X</button>
            </div>
          </div>
          <div class="ability-body ${collapsed ? 'collapsed' : ''}">
            <div class="inline-chips ability-rail">
              <span class="chip subtle">Trigger</span>
              <span class="chip subtle">Condition</span>
              <span class="chip subtle">Target</span>
              <span class="chip subtle">Effect</span>
            </div>
            <div class="field-grid">
              <label>Name<input type="text" data-ability-field="name" data-ability-id="${block.id}" value="${escapeHtml(block.name)}" /></label>
              <label>Trigger
                <select data-ability-field="trigger" data-ability-id="${block.id}">
                  ${ABILITY_TRIGGER_OPTIONS.map((entry) => `<option value="${entry}" ${block.trigger === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Target
                <select data-ability-field="target" data-ability-id="${block.id}">
                  ${ABILITY_TARGET_OPTIONS.map((entry) => `<option value="${entry}" ${block.target === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Condition<input type="text" data-ability-field="condition" data-ability-id="${block.id}" value="${escapeHtml(block.condition)}" /></label>
              <label>Effect
                <select data-ability-field="effect" data-ability-id="${block.id}">
                  ${ABILITY_EFFECT_OPTIONS.map((entry) => `<option value="${entry}" ${block.effect === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Amount<input type="number" data-ability-field="amount" data-ability-id="${block.id}" value="${num(block.amount, 0)}" /></label>
              <label>Duration<input type="number" min="1" data-ability-field="duration" data-ability-id="${block.id}" value="${num(block.duration, 1)}" /></label>
              <label>Scope<input type="text" data-ability-field="scope" data-ability-id="${block.id}" value="${escapeHtml(block.scope)}" /></label>
              <label>Filters<input type="text" data-ability-field="filters" data-ability-id="${block.id}" value="${escapeHtml(block.filters)}" /></label>
              <label>Timing<input type="text" data-ability-field="timing" data-ability-id="${block.id}" value="${escapeHtml(block.timing)}" /></label>
              <label>Race / Type
                <select data-ability-field="family" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.family === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Count Zone
                <select data-ability-field="familyZone" data-ability-id="${block.id}">
                  ${ABILITY_ZONE_OPTIONS.map((zone) => `<option value="${zone}" ${block.familyZone === zone ? 'selected' : ''}>${zone}</option>`).join('')}
                </select>
              </label>
              <label>Source Race
                <select data-ability-field="sourceFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.sourceFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Target Race
                <select data-ability-field="targetFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.targetFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Controller Has Race
                <select data-ability-field="controllerFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.controllerFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Dead Race Count
                <select data-ability-field="deadFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.deadFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Threshold<input type="number" min="0" data-ability-field="threshold" data-ability-id="${block.id}" value="${num(block.threshold, 0)}" /></label>
              <label>Familiarity Race
                <select data-ability-field="familiarityRace" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.familiarityRace === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Familiarity Gain/Spend<input type="number" min="0" data-ability-field="familiarityAmount" data-ability-id="${block.id}" value="${num(block.familiarityAmount, 0)}" /></label>
              <label>Familiarity Threshold<input type="number" min="0" data-ability-field="familiarityThreshold" data-ability-id="${block.id}" value="${num(block.familiarityThreshold, 0)}" /></label>
              <label>Deck Rule<input type="text" data-ability-field="deckRule" data-ability-id="${block.id}" value="${escapeHtml(block.deckRule)}" placeholder="deck contains only dragon" /></label>
              <label>Token Race<input type="text" data-ability-field="tokenRace" data-ability-id="${block.id}" value="${escapeHtml(block.tokenRace)}" placeholder="dragonkin" /></label>
              <label>Persistent Counter<input type="text" data-ability-field="counterKey" data-ability-id="${block.id}" value="${escapeHtml(block.counterKey)}" placeholder="brood, omen, fury" /></label>
              <label>Cooldown<input type="number" min="0" data-ability-field="cooldown" data-ability-id="${block.id}" value="${num(block.cooldown, 0)}" /></label>
              <label>Charges<input type="number" min="0" data-ability-field="charges" data-ability-id="${block.id}" value="${num(block.charges, 0)}" /></label>
              <label class="chip"><input type="checkbox" data-ability-field="oncePerTurn" data-ability-id="${block.id}" ${block.oncePerTurn ? 'checked' : ''} />Once/Turn</label>
            </div>
            <label>Notes<textarea data-ability-field="notes" data-ability-id="${block.id}">${escapeHtml(block.notes)}</textarea></label>
            <label>Advanced Script Hook<textarea data-ability-field="script" data-ability-id="${block.id}">${escapeHtml(block.script)}</textarea></label>
          </div>
        </div>
      `;
    }).join('') : '<div class="note">No abilities yet. Add one from preset or empty block.</div>'}
  `;
}

function renderTargetingModule() {
  return `
    <div class="field-grid">
      <label>Source<input type="text" data-path="targeting.source" value="${escapeHtml(state.draft.targeting.source)}" /></label>
      <label>Scope<input type="text" data-path="targeting.scope" value="${escapeHtml(state.draft.targeting.scope)}" /></label>
      <label>Team<input type="text" data-path="targeting.team" value="${escapeHtml(state.draft.targeting.team)}" /></label>
      <label>Placement Rule<input type="text" data-path="targeting.placement" value="${escapeHtml(state.draft.targeting.placement)}" placeholder="Can only be placed on..." /></label>
      <label>Requirement<input type="text" data-path="targeting.requirement" value="${escapeHtml(state.draft.targeting.requirement)}" placeholder="Requires Blacksmith..." /></label>
      <label>Line of Fire<input type="text" data-path="targeting.lineOfFire" value="${escapeHtml(state.draft.targeting.lineOfFire)}" /></label>
      <label>Filters<textarea data-path="targeting.filters">${escapeHtml(state.draft.targeting.filters)}</textarea></label>
    </div>
    <div class="note">Placement/targeting restrictions are shown in hover, inspect, and invalid-action feedback.</div>
  `;
}

function renderArtModule() {
  return `
    <div class="dropzone" id="art-dropzone">Drop PNG/JPG here or <button type="button" data-action="open-art-upload">choose file</button></div>
    <div class="field-grid">
      <label>Art URL / Data<input type="text" data-path="art.src" value="${escapeHtml(state.draft.art.src)}" placeholder="https://... or data:image/..." /></label>
      <label>Fit
        <select data-path="art.fit">
          <option value="cover" ${state.draft.art.fit === 'cover' ? 'selected' : ''}>cover</option>
          <option value="contain" ${state.draft.art.fit === 'contain' ? 'selected' : ''}>contain</option>
          <option value="fill" ${state.draft.art.fit === 'fill' ? 'selected' : ''}>fill</option>
        </select>
      </label>
      <label>X Position<input type="range" min="0" max="100" step="1" data-path="art.x" value="${num(state.draft.art.x, 50)}" /></label>
      <label>Y Position<input type="range" min="0" max="100" step="1" data-path="art.y" value="${num(state.draft.art.y, 50)}" /></label>
      <label>Zoom<input type="range" min="0.5" max="1.8" step="0.05" data-path="art.zoom" value="${num(state.draft.art.zoom, 1)}" /></label>
      <label>Frame Theme<input type="text" data-path="art.frameTheme" value="${escapeHtml(state.draft.art.frameTheme)}" /></label>
      <label>Frame Tint<input type="color" data-path="art.frameTint" value="${escapeHtml(state.draft.art.frameTint)}" /></label>
      <label>Overlay<input type="text" data-path="art.overlay" value="${escapeHtml(state.draft.art.overlay)}" /></label>
      <label>Background<input type="text" data-path="art.background" value="${escapeHtml(state.draft.art.background)}" /></label>
      <label>Emblem<input type="text" data-path="art.emblem" value="${escapeHtml(state.draft.art.emblem)}" /></label>
      <label class="chip"><input type="checkbox" data-path="art.rarityBadge" ${state.draft.art.rarityBadge ? 'checked' : ''}/>Show Rarity Badge</label>
    </div>
    <label>Art Notes<textarea data-path="art.notes">${escapeHtml(state.draft.art.notes)}</textarea></label>
  `;
}

function renderNormalModeModule() {
  return `
    <div class="field-grid">
      <label>Battle Compatibility
        <select data-path="normal.battleCompatibility">
          <option value="both" ${state.draft.normal.battleCompatibility === 'both' ? 'selected' : ''}>both</option>
          <option value="duel_only" ${state.draft.normal.battleCompatibility === 'duel_only' ? 'selected' : ''}>duel_only</option>
          <option value="defense_only" ${state.draft.normal.battleCompatibility === 'defense_only' ? 'selected' : ''}>defense_only</option>
        </select>
      </label>
      <label>Required Modes<input type="text" data-path="normal.requiredModes" value="${escapeHtml(state.draft.normal.requiredModes)}" /></label>
      <label>Home Dimension<input type="text" data-path="normal.homeDimension" value="${escapeHtml(state.draft.normal.homeDimension)}" /></label>
      <label>Pack Type<input type="text" data-path="normal.packType" value="${escapeHtml(state.draft.normal.packType)}" /></label>
      <label>Catch Limit<input type="number" min="0" data-path="normal.catchLimit" value="${num(state.draft.normal.catchLimit, 0)}" /></label>
      <label class="chip"><input type="checkbox" data-path="normal.includeInPacks" ${state.draft.normal.includeInPacks ? 'checked' : ''} />Include in Packs</label>
      <label class="chip"><input type="checkbox" data-path="normal.localExclusive" ${state.draft.normal.localExclusive ? 'checked' : ''} />Exclusive to Local Multiplayer</label>
    </div>
    <div class="note">Use the Race & Familiarity step for species selection, threshold scaling, and dragon-family setup. Local-exclusive cards stay out of the standard normal pool and only enter Local Player.</div>
  `;
}

function renderConquestModule() {
  return `
    <div class="field-grid">
      <label>Side
        <select data-path="conquest.side">
          <option value="defender" ${state.draft.conquest.side === 'defender' ? 'selected' : ''}>defender</option>
          <option value="attacker" ${state.draft.conquest.side === 'attacker' ? 'selected' : ''}>attacker</option>
        </select>
      </label>
      <label>Production Source
        <select data-path="conquest.productionSource">
          ${CONQUEST_SOURCES.map((source) => `<option value="${source}" ${state.draft.conquest.productionSource === source ? 'selected' : ''}>${source}</option>`).join('')}
        </select>
      </label>
      <label>Building Type<input type="text" data-path="conquest.buildingType" value="${escapeHtml(state.draft.conquest.buildingType)}" /></label>
      <label>Attack Range<input type="number" min="1" data-path="conquest.attackRange" value="${num(state.draft.conquest.attackRange, 1)}" /></label>
      <label>Movement<input type="number" min="0" data-path="conquest.movement" value="${num(state.draft.conquest.movement, 1)}" /></label>
      <label>Required Modes<input type="text" data-path="conquest.requiredModes" value="${escapeHtml(state.draft.conquest.requiredModes)}" /></label>
      <label>Battle Compatibility<input type="text" data-path="conquest.battleCompatibility" value="${escapeHtml(state.draft.conquest.battleCompatibility)}" /></label>
      <label class="chip"><input type="checkbox" data-path="conquest.producible" ${state.draft.conquest.producible ? 'checked' : ''}/>Producible</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isBuilding" ${state.draft.conquest.isBuilding ? 'checked' : ''}/>Building</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isTurret" ${state.draft.conquest.isTurret ? 'checked' : ''}/>Turret</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isBarricade" ${state.draft.conquest.isBarricade ? 'checked' : ''}/>Barricade</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isFacility" ${state.draft.conquest.isFacility ? 'checked' : ''}/>Facility</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isUpgrade" ${state.draft.conquest.isUpgrade ? 'checked' : ''}/>Upgrade</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isEquipment" ${state.draft.conquest.isEquipment ? 'checked' : ''}/>Equipment</label>
      <label class="chip"><input type="checkbox" data-path="conquest.homestead" ${state.draft.conquest.homestead ? 'checked' : ''}/>Homestead</label>
      <label class="chip"><input type="checkbox" data-path="conquest.pylon" ${state.draft.conquest.pylon ? 'checked' : ''}/>Mana Pylon</label>
    </div>
  `;
}

function renderTokenLinksModule() {
  return `
    <div class="field-grid">
      <label>Summons<input type="text" data-path="tokenLinks.summons" value="${escapeHtml(state.draft.tokenLinks.summons)}" placeholder="token-id-1,token-id-2" /></label>
      <label>Generated By<input type="text" data-path="tokenLinks.generatedBy" value="${escapeHtml(state.draft.tokenLinks.generatedBy)}" /></label>
      <label>Upgrades Into<input type="text" data-path="tokenLinks.upgradesInto" value="${escapeHtml(state.draft.tokenLinks.upgradesInto)}" /></label>
      <label>Equipped By<input type="text" data-path="tokenLinks.equippedBy" value="${escapeHtml(state.draft.tokenLinks.equippedBy)}" /></label>
    </div>
    <div class="note">Use IDs to form card relationship graphs and generator links.</div>
  `;
}

function renderCollectionModule() {
  return `
    <div class="field-grid">
      <label>Collection<input type="text" data-path="metadata.collection" value="${escapeHtml(state.draft.metadata.collection)}" placeholder="Volcanic Ash Collection" /></label>
      <label>Pack Name<input type="text" data-path="metadata.packName" value="${escapeHtml(state.draft.metadata.packName)}" placeholder="Gen 4 Booster" /></label>
      <label>World<input type="text" data-path="metadata.world" value="${escapeHtml(state.draft.metadata.world)}" /></label>
      <label>Production Source Label<input type="text" data-path="metadata.productionSource" value="${escapeHtml(state.draft.metadata.productionSource)}" /></label>
      <label>Role<input type="text" data-path="metadata.role" value="${escapeHtml(state.draft.metadata.role)}" /></label>
      <label>Creator Tags<input type="text" data-path="metadata.creatorTags" value="${escapeHtml(state.draft.metadata.creatorTags)}" /></label>
      <label>Tags CSV<textarea data-path="metadata.tags">${escapeHtml(state.draft.metadata.tags)}</textarea></label>
    </div>
  `;
}

function renderTemplatesModule() {
  const templates = allTemplates().filter((entry) => entry.mode === state.ui.mode || entry.mode === 'hybrid');
  return `
    <div class="field-grid">
      <label>Template
        <select id="template-select-module">
          ${templates.map((template) => `<option value="${template.id}">${escapeHtml(template.label)} (${escapeHtml(template.type)})</option>`).join('')}
        </select>
      </label>
      <label>Template Name for Save<input type="text" id="save-template-name" placeholder="My custom template" /></label>
    </div>
    <div class="inline-chips">
      <button type="button" data-action="apply-template-from-module">Apply Template</button>
      <button type="button" data-action="save-user-template">Save as User Template</button>
      <button type="button" data-action="duplicate-card">Duplicate Card</button>
      <button type="button" data-action="clone-variant">Clone Variant</button>
    </div>
    <div class="template-list">
      ${state.userTemplates.length ? state.userTemplates.map((template, idx) => `
        <div class="template-item">
          <div class="row">
            <strong>${escapeHtml(template.label)}</strong>
            <small>${escapeHtml(template.mode)} • ${escapeHtml(template.type)}</small>
          </div>
          <div class="row" style="margin-top:.28rem;">
            <button type="button" data-action="apply-user-template" data-user-template-index="${idx}">Apply</button>
            <button type="button" data-action="delete-user-template" data-user-template-index="${idx}">Delete</button>
          </div>
        </div>
      `).join('') : '<div class="note">No user templates saved yet.</div>'}
    </div>
  `;
}

function renderValidationModule() {
  const errors = state.validation.errors;
  const warnings = state.validation.warnings;
  return `
    ${errors.length ? errors.map((entry) => `<div class="error-box">${escapeHtml(entry.message)} <button type="button" data-action="jump-to-path" data-path="${escapeHtml(entry.path || '')}">Jump</button></div>`).join('') : '<div class="success-box">No blocking errors detected.</div>'}
    ${warnings.length ? warnings.map((entry) => `<div class="warning">${escapeHtml(entry.message)} <button type="button" data-action="jump-to-path" data-path="${escapeHtml(entry.path || '')}">Jump</button></div>`).join('') : '<div class="note">No warnings.</div>'}
  `;
}

function renderSaveExportModule() {
  return `
    <div class="inline-chips">
      <button type="button" class="primary" data-action="save-card">Save Card</button>
      <button type="button" data-action="save-version">Save Version</button>
      <button type="button" data-action="export-card-json">Export Card JSON</button>
      <button type="button" data-action="import-card-json">Import Card JSON</button>
      <button type="button" data-action="reset-draft">New Draft</button>
    </div>
    <textarea id="exchange-json" class="mono" placeholder="JSON exchange area"></textarea>
  `;
}

function applyWorkspacePreset(name) {
  state.ui.workspace = name;
  if (name === 'compact') {
    state.ui.leftCollapsed = false;
    state.ui.rightCollapsed = false;
    state.ui.bottomCollapsed = true;
  } else if (name === 'ability_forge') {
    state.ui.leftCollapsed = false;
    state.ui.rightCollapsed = true;
    state.ui.bottomCollapsed = false;
    state.ui.activeModule = 'abilities';
    state.ui.modulePinned.abilities = true;
  } else if (name === 'preview_focus') {
    state.ui.leftCollapsed = true;
    state.ui.rightCollapsed = false;
    state.ui.bottomCollapsed = true;
  } else {
    state.ui.leftCollapsed = false;
    state.ui.rightCollapsed = false;
    state.ui.bottomCollapsed = false;
  }
  saveJsonStorage(STORAGE.uiPrefs, {
    workspace: state.ui.workspace,
    leftCollapsed: state.ui.leftCollapsed,
    rightCollapsed: state.ui.rightCollapsed,
    bottomCollapsed: state.ui.bottomCollapsed,
  });
  renderAll();
  logActivity(`Workspace preset applied: ${name}`);
}

function applyTemplateById(id) {
  const template = allTemplates().find((entry) => entry.id === id);
  if (!template) return;
  pushHistory(`template:${template.label}`);
  if (template.mode && template.mode !== 'hybrid') applyModeDefaults(template.mode);
  if (template.type) state.draft.type = template.type;
  mergeDeep(state.draft, safeClone(template.patch || {}));
  if (!state.draft.id) state.draft.id = slug(template.label);
  if (!state.draft.name) state.draft.name = template.label;
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Template applied: ${template.label}`);
}

function saveUserTemplate(name) {
  const label = String(name || '').trim();
  if (!label) {
    logActivity('Template save skipped (missing name).');
    return;
  }
  const template = {
    id: uid('usr-tmpl'),
    label,
    mode: state.ui.mode,
    type: state.draft.type,
    summary: 'User-saved template',
    patch: safeClone(state.draft),
  };
  state.userTemplates.push(template);
  saveJsonStorage(STORAGE.userTemplates, state.userTemplates);
  renderAll();
  logActivity(`Saved user template "${label}".`);
}

function applyUserTemplate(index) {
  const template = state.userTemplates[index];
  if (!template) return;
  pushHistory(`user-template:${template.label}`);
  state.draft = safeClone(template.patch);
  applyModeDefaults(template.mode || 'duel');
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Applied user template "${template.label}".`);
}

function removeUserTemplate(index) {
  if (!state.userTemplates[index]) return;
  const [removed] = state.userTemplates.splice(index, 1);
  saveJsonStorage(STORAGE.userTemplates, state.userTemplates);
  renderAll();
  logActivity(`Deleted user template "${removed.label}".`);
}

function addAbilityBlockFromPreset(presetId = '') {
  const preset = state.abilityTemplates.find((entry) => entry.id === presetId) ?? null;
  const block = createAbilityBlock(preset);
  state.draft.abilities.push(block);
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Ability block added${preset ? ` (${preset.name})` : ''}.`);
}

function updateAbilityField(abilityId, field, value) {
  const block = state.draft.abilities.find((entry) => entry.id === abilityId);
  if (!block) return;
  const numericFields = new Set(['amount', 'duration', 'cooldown', 'charges', 'threshold', 'familiarityAmount', 'familiarityThreshold']);
  if (numericFields.has(field)) block[field] = num(value, 0);
  else if (field === 'oncePerTurn') block[field] = bool(value);
  else block[field] = value;
  state.draft.updatedAt = Date.now();
  validateDraft();
  renderStatusRow();
  renderRightPane();
  if (state.ui.bottomTab === 'ability-json') renderBottomPane();
}

function moveAbility(abilityId, delta) {
  const idx = state.draft.abilities.findIndex((entry) => entry.id === abilityId);
  if (idx < 0) return;
  const next = idx + delta;
  if (next < 0 || next >= state.draft.abilities.length) return;
  const [entry] = state.draft.abilities.splice(idx, 1);
  state.draft.abilities.splice(next, 0, entry);
  queueAutosave();
  renderAll();
}

function duplicateAbility(abilityId) {
  const block = state.draft.abilities.find((entry) => entry.id === abilityId);
  if (!block) return;
  const clone = safeClone(block);
  clone.id = uid('ability');
  clone.name = `${clone.name || 'Ability'} Copy`;
  state.draft.abilities.push(clone);
  queueAutosave();
  renderAll();
}

function toggleDraftRace(family = '') {
  const next = draftRaceList();
  const normalized = normalizeFamilyId(family);
  if (!normalized) return;
  const idx = next.indexOf(normalized);
  if (idx >= 0) next.splice(idx, 1);
  else next.push(normalized);
  setDraftRaceList(next);
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
}

function applyRaceArchetype(archetypeId = '') {
  const preset = RACE_ARCHETYPE_PRESETS[archetypeId];
  if (!preset) return;
  setDraftRaceList(preset.races);
  state.draft.normal.synergy = preset.synergy;
  state.draft.metadata.role = preset.role;
  Object.assign(state.draft.keywords, preset.keywords ?? {});
  state.draft.normal.familiarityRace = preset.races[0] ?? '';
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Applied race archetype: ${preset.label}.`);
}

function deleteAbility(abilityId) {
  const idx = state.draft.abilities.findIndex((entry) => entry.id === abilityId);
  if (idx < 0) return;
  state.draft.abilities.splice(idx, 1);
  delete state.ui.abilityCollapsed[abilityId];
  validateDraft();
  queueAutosave();
  renderAll();
}

function toggleAbilityCollapse(abilityId) {
  state.ui.abilityCollapsed[abilityId] = !state.ui.abilityCollapsed[abilityId];
  renderCenterPane();
}

function toggleModuleCollapse(moduleId) {
  state.ui.moduleCollapsed[moduleId] = !state.ui.moduleCollapsed[moduleId];
  renderCenterPane();
}

function toggleModulePin(moduleId) {
  state.ui.modulePinned[moduleId] = !state.ui.modulePinned[moduleId];
  renderCenterPane();
}

function moveModule(moduleId, delta) {
  const modules = visibleModules();
  const ids = modules.map((mod) => mod.id);
  const idx = ids.indexOf(moduleId);
  if (idx < 0) return;
  const next = idx + delta;
  if (next < 0 || next >= ids.length) return;
  const currentOrder = state.ui.moduleOrder.length ? state.ui.moduleOrder.slice() : moduleRegistry().map((mod) => mod.id);
  const a = currentOrder.indexOf(moduleId);
  const b = currentOrder.indexOf(ids[next]);
  if (a < 0 || b < 0) return;
  const tmp = currentOrder[a];
  currentOrder[a] = currentOrder[b];
  currentOrder[b] = tmp;
  state.ui.moduleOrder = currentOrder;
  queueAutosave();
  renderCenterPane();
}

function jumpToModule(moduleId) {
  state.ui.activeModule = moduleId;
  const node = document.querySelector(`#module-${moduleId}`);
  if (node) node.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function draftToCardPayload() {
  const tagSet = new Set(draftTagsArray());
  const races = draftRaceList();
  tagSet.add('GEN4');
  tagSet.add(state.ui.mode === 'conquest' ? 'conquest' : 'duel');
  races.forEach((race) => tagSet.add(race));
  const ability = state.draft.abilities[0]
    ? {
      trigger: state.draft.abilities[0].trigger,
      action: state.draft.abilities[0].effect,
      amount: state.draft.abilities[0].amount,
      duration: state.draft.abilities[0].duration,
      condition: state.draft.abilities[0].condition || null,
      family: state.draft.abilities[0].family || null,
      familyZone: state.draft.abilities[0].familyZone || null,
      sourceFamily: state.draft.abilities[0].sourceFamily || null,
      targetFamily: state.draft.abilities[0].targetFamily || null,
      controllerFamily: state.draft.abilities[0].controllerFamily || null,
      deadFamily: state.draft.abilities[0].deadFamily || null,
      threshold: num(state.draft.abilities[0].threshold, 0),
      familiarityRace: state.draft.abilities[0].familiarityRace || null,
      familiarityThreshold: num(state.draft.abilities[0].familiarityThreshold, 0),
      familiarityAmount: num(state.draft.abilities[0].familiarityAmount, 0),
      text: abilitySummary(state.draft.abilities[0]),
    }
    : null;
  const card = {
    id: state.draft.id.trim(),
    name: state.draft.name.trim(),
    type: state.draft.type,
    cost: num(state.draft.cost.mana, 0),
    wheatCost: num(state.draft.cost.wheat, 0),
    ironCost: num(state.draft.cost.iron, 0),
    attack: num(state.draft.stats.attack, 0),
    health: num(state.draft.stats.health, 1),
    def: num(state.draft.stats.defense, 0),
    range: num(state.draft.stats.range, 1),
    movement: num(state.draft.stats.movement, 1),
    rarity: state.draft.rarity,
    race: races[0] || state.draft.normal.race || null,
    races,
    element: state.draft.normal.element || null,
    damage: num(state.draft.normal.damage, 0),
    text: state.draft.text,
    keywords: KEYWORD_DEFS.filter((entry) => state.draft.keywords[entry.key]).map((entry) => entry.key),
    ability,
    abilities: safeClone(state.draft.abilities),
    synergy: String(state.draft.normal.synergy || '').split(',').map((item) => item.trim()).filter(Boolean),
    includeInPacks: !!state.draft.normal.includeInPacks,
    localExclusive: !!state.draft.normal.localExclusive,
    packType: state.draft.normal.packType || 'booster',
    catchLimit: num(state.draft.normal.catchLimit, 0),
    homeDimension: state.draft.normal.homeDimension || '',
    familiarity: {
      race: state.draft.normal.familiarityRace || null,
      start: num(state.draft.normal.familiarityStart, 0),
      threshold: num(state.draft.normal.familiarityThreshold, 0),
      reward: state.draft.normal.familiarityReward || '',
      notes: state.draft.normal.familiarityNotes || '',
    },
    battleCompatibility: state.ui.mode === 'conquest' ? state.draft.conquest.battleCompatibility : state.draft.normal.battleCompatibility,
    requiredModes: state.ui.mode === 'conquest' ? state.draft.conquest.requiredModes : state.draft.normal.requiredModes,
    production: {
      producible: !!state.draft.conquest.producible,
      buildingType: state.draft.conquest.buildingType,
      speciesOrigin: races[0] || state.draft.normal.race,
      worldOrigin: state.draft.metadata.world,
      unlockByWorld: state.draft.metadata.world,
      loseWithWorld: false,
      techRequirement: 0,
      favorRequirement: 0,
      productionCostGold: num(state.draft.cost.iron, 0),
      productionCostLifeforce: num(state.draft.cost.wheat, 0),
      reinforcementTier: 1,
      requiredModes: state.draft.conquest.requiredModes || '',
    },
    campaignMeta: {
      battleCompatibility: state.ui.mode === 'conquest' ? state.draft.conquest.battleCompatibility : state.draft.normal.battleCompatibility,
      producible: !!state.draft.conquest.producible,
      productionBuildingType: state.draft.conquest.productionSource,
      speciesOrigin: races[0] || state.draft.normal.race,
      worldOrigin: state.draft.metadata.world,
      unlockByWorld: state.draft.metadata.world,
      loseWithWorld: false,
      techRequirement: 0,
      favorRequirement: 0,
      productionCostGold: num(state.draft.cost.iron, 0),
      productionCostLifeforce: num(state.draft.cost.wheat, 0),
      reinforcementTier: 1,
      requiredModes: state.ui.mode === 'conquest' ? state.draft.conquest.requiredModes : state.draft.normal.requiredModes,
    },
    mtgMeta: {
      collection: state.draft.metadata.collection,
      packName: state.draft.metadata.packName,
      world: state.draft.metadata.world,
      role: state.draft.metadata.role,
      notes: state.draft.metadata.notes,
    },
    art: safeClone(state.draft.art),
    targeting: safeClone(state.draft.targeting),
    tokenLinks: safeClone(state.draft.tokenLinks),
    conquest: safeClone(state.draft.conquest),
    metadata: safeClone(state.draft.metadata),
    tags: [...tagSet, 'custom-made'],
    creatorStudioVersion: 2,
    sourceType: 'custom-made',
    customMade: true,
  };
  KEYWORD_DEFS.forEach((entry) => { card[entry.key] = !!state.draft.keywords[entry.key]; });
  return card;
}

function loadCardToDraft(card) {
  const next = createDefaultDraft(card?.conquest?.productionSource ? 'conquest' : 'duel');
  next.id = card.id || '';
  next.name = card.name || '';
  next.type = card.type || next.type;
  next.rarity = card.rarity || next.rarity;
  next.text = card.text || '';
  next.cost.mana = num(card.cost, 0);
  next.cost.wheat = num(card.wheatCost, 0);
  next.cost.iron = num(card.ironCost, 0);
  next.stats.attack = num(card.attack, next.stats.attack);
  next.stats.health = num(card.health, next.stats.health);
  next.stats.defense = num(card.def, 0);
  next.stats.range = num(card.range, 1);
  next.stats.movement = num(card.movement, 1);
  next.normal.race = card.race || card.races?.[0] || '';
  next.normal.races = Array.isArray(card.races) ? card.races.join(', ') : (card.race ? String(card.race) : '');
  next.normal.element = card.element || '';
  next.normal.damage = num(card.damage, 0);
  next.normal.synergy = Array.isArray(card.synergy) ? card.synergy.join(',') : '';
  next.normal.familiarityRace = card.familiarity?.race || '';
  next.normal.familiarityStart = num(card.familiarity?.start, 0);
  next.normal.familiarityThreshold = num(card.familiarity?.threshold, 0);
  next.normal.familiarityReward = card.familiarity?.reward || '';
  next.normal.familiarityNotes = card.familiarity?.notes || '';
  next.normal.battleCompatibility = card.battleCompatibility || 'both';
  next.normal.requiredModes = card.requiredModes || '';
  next.normal.localExclusive = !!card.localExclusive;
  next.normal.homeDimension = card.homeDimension || '';
  next.normal.packType = card.packType || 'booster';
  next.normal.includeInPacks = card.includeInPacks !== false;
  next.normal.catchLimit = num(card.catchLimit, 0);
  next.abilities = Array.isArray(card.abilities)
    ? card.abilities.map((entry) => ({
      ...createAbilityBlock(),
      ...entry,
      id: entry.id || uid('ability'),
      effect: entry.effect?.action ?? entry.action ?? entry.effect ?? 'dealDamage',
      amount: num(entry.amount ?? entry.effect?.amount, 1),
      duration: num(entry.duration, 1),
      family: entry.family || '',
      familyZone: entry.familyZone || 'board',
      sourceFamily: entry.sourceFamily || '',
      targetFamily: entry.targetFamily || '',
      controllerFamily: entry.controllerFamily || '',
      deadFamily: entry.deadFamily || '',
      threshold: num(entry.threshold, 0),
      familiarityRace: entry.familiarityRace || '',
      familiarityAmount: num(entry.familiarityAmount, 0),
      familiarityThreshold: num(entry.familiarityThreshold, 0),
    }))
    : (card.ability ? [{
      ...createAbilityBlock(),
      trigger: card.ability.trigger || 'battlecry',
      effect: card.ability.action || 'dealDamage',
      amount: num(card.ability.amount, 1),
      duration: num(card.ability.duration, 1),
      condition: card.ability.condition || '',
      notes: card.ability.text || '',
      family: card.ability.family || '',
      familyZone: card.ability.familyZone || 'board',
      sourceFamily: card.ability.sourceFamily || '',
      targetFamily: card.ability.targetFamily || '',
      controllerFamily: card.ability.controllerFamily || '',
      deadFamily: card.ability.deadFamily || '',
      threshold: num(card.ability.threshold, 0),
      familiarityRace: card.ability.familiarityRace || '',
      familiarityAmount: num(card.ability.familiarityAmount, 0),
      familiarityThreshold: num(card.ability.familiarityThreshold, 0),
    }] : []);
  const tagSet = new Set(card.keywords || []);
  KEYWORD_DEFS.forEach((entry) => {
    next.keywords[entry.key] = bool(card[entry.key]) || tagSet.has(entry.key);
  });
  next.conquest = {
    ...next.conquest,
    ...(card.conquest || {}),
    productionSource: card.conquest?.productionSource || card.production?.buildingType || next.conquest.productionSource,
    side: card.conquest?.side || 'defender',
  };
  next.metadata = {
    ...next.metadata,
    ...(card.metadata || {}),
    tags: Array.isArray(card.tags) ? card.tags.join(', ') : next.metadata.tags,
  };
  next.art = { ...next.art, ...(card.art || {}) };
  next.tokenLinks = { ...next.tokenLinks, ...(card.tokenLinks || {}) };
  next.targeting = { ...next.targeting, ...(card.targeting || {}) };
  next.creatorStudioVersion = 2;
  state.draft = next;
  const mode = card?.conquest?.productionSource || card?.conquest?.isBuilding ? 'conquest' : deduceModeFromTemplate(card);
  applyModeDefaults(mode);
  validateDraft();
}

function saveCurrentCard() {
  validateDraft();
  if (state.validation.errors.length) {
    logActivity('Save blocked: resolve validation errors first.');
    renderRightPane();
    renderBottomPane();
    return;
  }
  const payload = draftToCardPayload();
  const persisted = persistCustomCard(payload);
  state.draft.updatedAt = Date.now();
  state.recentCards = [{ id: payload.id, name: payload.name, type: payload.type, at: Date.now() }, ...state.recentCards.filter((entry) => entry.id !== payload.id)].slice(0, 20);
  saveJsonStorage(STORAGE.recentCards, state.recentCards);
  queueAutosave();
  logActivity(`${persisted.savedCard.name} ${persisted.isNew ? 'created' : 'updated'} in custom card library.`);
  renderStatusRow();
  renderLeftPane();
  renderBottomPane();
}

function saveVersion(label = '') {
  const version = {
    at: Date.now(),
    label: label || `${state.draft.name || state.draft.id || 'Card'} snapshot`,
    draft: safeClone(state.draft),
  };
  state.versions.unshift(version);
  state.versions = state.versions.slice(0, 60);
  saveJsonStorage(STORAGE.versions, state.versions);
  logActivity(`Version saved: ${version.label}`);
  renderBottomPane();
}

function restoreVersion(index) {
  const version = state.versions[index];
  if (!version) return;
  pushHistory('restore-version');
  state.draft = safeClone(version.draft);
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Version restored: ${version.label}`);
}

function deleteVersion(index) {
  const version = state.versions[index];
  if (!version) return;
  state.versions.splice(index, 1);
  saveJsonStorage(STORAGE.versions, state.versions);
  renderBottomPane();
  logActivity(`Version deleted: ${version.label}`);
}

function exportCardJson() {
  const area = document.querySelector('#exchange-json');
  if (!area) return;
  area.value = JSON.stringify(draftToCardPayload(), null, 2);
  logActivity('Card JSON exported to exchange area.');
}

function importCardJson() {
  const area = document.querySelector('#exchange-json');
  if (!area) return;
  try {
    const parsed = JSON.parse(area.value || '{}');
    pushHistory('import-json');
    loadCardToDraft(parsed);
    queueAutosave();
    renderAll();
    logActivity('Card JSON imported successfully.');
  } catch {
    logActivity('Import failed: invalid JSON.');
    renderBottomPane();
  }
}

function copyProjectJson() {
  const area = document.querySelector('#project-json-editor');
  if (!area) return;
  area.select();
  document.execCommand('copy');
  logActivity('Project JSON copied.');
}

function importProjectJson() {
  const area = document.querySelector('#project-json-editor');
  if (!area) return;
  try {
    const parsed = JSON.parse(area.value || '{}');
    pushHistory('import-project');
    state.draft = mergeDeep(createDefaultDraft(state.ui.mode), parsed);
    validateDraft();
    queueAutosave();
    renderAll();
    logActivity('Project JSON imported.');
  } catch {
    logActivity('Project JSON import failed: invalid JSON.');
    renderBottomPane();
  }
}

function duplicateCard() {
  pushHistory('duplicate-card');
  state.draft.id = `${state.draft.id || 'card'}-copy`;
  state.draft.name = `${state.draft.name || 'Card'} Copy`;
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity('Card duplicated.');
}

function cloneVariant() {
  pushHistory('clone-variant');
  state.draft.id = `${state.draft.id || 'card'}-variant-${Math.floor(Math.random() * 90 + 10)}`;
  state.draft.name = `${state.draft.name || 'Card'} Variant`;
  state.draft.rarity = state.draft.rarity === 'legendary' ? 'epic' : state.draft.rarity;
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity('Variant clone created.');
}

function resetDraft() {
  pushHistory('reset-draft');
  state.draft = createDefaultDraft(state.ui.mode);
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity('Started a new draft.');
}

function commandItems() {
  const base = [
    { id: 'save-card', label: 'Save Card', group: 'File' },
    { id: 'save-version', label: 'Save Version Snapshot', group: 'File' },
    { id: 'export-card-json', label: 'Export Card JSON', group: 'File' },
    { id: 'import-card-json', label: 'Import Card JSON', group: 'File' },
    { id: 'undo', label: 'Undo', group: 'Edit' },
    { id: 'redo', label: 'Redo', group: 'Edit' },
    { id: 'duplicate-card', label: 'Duplicate Card', group: 'Edit' },
    { id: 'clone-variant', label: 'Clone Variant', group: 'Edit' },
    { id: 'quick-validate', label: 'Run Validation', group: 'Quality' },
    { id: 'preview-popout', label: 'Preview Popout', group: 'View' },
    { id: 'toggle-left', label: 'Toggle Left Sidebar', group: 'View' },
    { id: 'toggle-right', label: 'Toggle Right Sidebar', group: 'View' },
    { id: 'toggle-bottom', label: 'Toggle Bottom Drawer', group: 'View' },
  ];
  const moduleCommands = moduleRegistry().map((module) => ({ id: `goto:${module.id}`, label: `Go to ${module.title}`, group: 'Modules' }));
  const templateCommands = allTemplates().slice(0, 20).map((template) => ({ id: `template:${template.id}`, label: `Apply Template: ${template.label}`, group: 'Templates' }));
  return [...base, ...moduleCommands, ...templateCommands];
}

function runCommand(commandId) {
  if (commandId.startsWith('goto:')) {
    jumpToModule(commandId.split(':')[1]);
    return;
  }
  if (commandId.startsWith('template:')) {
    applyTemplateById(commandId.split(':')[1]);
    return;
  }
  const directMap = {
    'save-card': saveCurrentCard,
    'save-version': () => saveVersion('Palette Snapshot'),
    'export-card-json': exportCardJson,
    'import-card-json': importCardJson,
    undo,
    redo,
    'duplicate-card': duplicateCard,
    'clone-variant': cloneVariant,
    'quick-validate': () => {
      validateDraft();
      renderStatusRow();
      renderRightPane();
      renderCenterPane();
      logActivity('Validation refreshed.');
    },
    'preview-popout': openPreviewPopout,
    'toggle-left': () => { state.ui.leftCollapsed = !state.ui.leftCollapsed; renderAll(); },
    'toggle-right': () => { state.ui.rightCollapsed = !state.ui.rightCollapsed; renderAll(); },
    'toggle-bottom': () => { state.ui.bottomCollapsed = !state.ui.bottomCollapsed; renderAll(); },
  };
  if (directMap[commandId]) directMap[commandId]();
}

function bindDropzone() {
  const zone = document.querySelector('#art-dropzone');
  if (!zone || zone.dataset.bound === 'yes') return;
  zone.dataset.bound = 'yes';
  zone.addEventListener('dragover', (event) => {
    event.preventDefault();
    zone.classList.add('dragging');
  });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragging'));
  zone.addEventListener('drop', (event) => {
    event.preventDefault();
    zone.classList.remove('dragging');
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    loadArtFile(file);
  });
}

function loadArtFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    pushHistory('art-upload');
    state.draft.art.src = String(reader.result || '');
    state.draft.updatedAt = Date.now();
    queueAutosave();
    renderRightPane();
    renderCenterPane();
    logActivity(`Art uploaded: ${file.name}`);
  };
  reader.readAsDataURL(file);
}

function openPreviewPopout() {
  const overlay = document.querySelector('#preview-popout');
  const body = document.querySelector('#preview-popout-body');
  const source = document.querySelector('.preview-stage');
  if (!overlay || !body || !source) return;
  body.innerHTML = source.innerHTML;
  overlay.classList.remove('hidden');
  overlay.setAttribute('aria-hidden', 'false');
}

function closePreviewPopout() {
  const overlay = document.querySelector('#preview-popout');
  if (!overlay) return;
  overlay.classList.add('hidden');
  overlay.setAttribute('aria-hidden', 'true');
}

function updateDraftFieldFromInput(input) {
  const path = input.dataset.path;
  if (!path) return;
  const type = input.type;
  let value;
  if (type === 'checkbox') value = input.checked;
  else if (type === 'number' || type === 'range') value = num(input.value, 0);
  else value = input.value;
  byPathSet(state.draft, path, value);
  if (path === 'normal.race') setDraftRaceList([value, ...draftRaceList().filter((entry) => entry !== normalizeFamilyId(value))]);
  if (path === 'normal.races') setDraftRaceList(parseCsv(value));
  state.draft.updatedAt = Date.now();
  validateDraft();
  renderStatusRow();
  renderRightPane();
  if (state.ui.bottomTab === 'project-json' || state.ui.bottomTab === 'ability-json') renderBottomPane();
}

function bindGlobalEvents() {
  document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const action = target.dataset.action;
    if (!action) return;

    if (action === 'module-collapse') toggleModuleCollapse(target.dataset.module);
    else if (action === 'module-pin') toggleModulePin(target.dataset.module);
    else if (action === 'module-move-up') moveModule(target.dataset.module, -1);
    else if (action === 'module-move-down') moveModule(target.dataset.module, 1);
    else if (action === 'jump-module') jumpToModule(target.dataset.module);
    else if (action === 'toggle-left') { state.ui.leftCollapsed = !state.ui.leftCollapsed; renderAll(); }
    else if (action === 'toggle-right') { state.ui.rightCollapsed = !state.ui.rightCollapsed; renderAll(); }
    else if (action === 'toggle-bottom') { state.ui.bottomCollapsed = !state.ui.bottomCollapsed; renderAll(); }
    else if (action === 'bottom-tab') { state.ui.bottomTab = target.dataset.tab; renderBottomPane(); }
    else if (action === 'apply-template') applyTemplateById(target.dataset.templateId);
    else if (action === 'apply-template-from-module') {
      const select = document.querySelector('#template-select-module');
      applyTemplateById(select?.value || '');
    }
    else if (action === 'toggle-race-tag') toggleDraftRace(target.dataset.race);
    else if (action === 'apply-race-archetype') applyRaceArchetype(target.dataset.archetype);
    else if (action === 'save-user-template') {
      const input = document.querySelector('#save-template-name');
      saveUserTemplate(input?.value || '');
    }
    else if (action === 'apply-user-template') applyUserTemplate(num(target.dataset.userTemplateIndex, -1));
    else if (action === 'delete-user-template') removeUserTemplate(num(target.dataset.userTemplateIndex, -1));
    else if (action === 'ability-add') {
      pushHistory('ability-add');
      const presetId = document.querySelector('#ability-preset-select')?.value || '';
      addAbilityBlockFromPreset(presetId);
    }
    else if (action === 'ability-duplicate') { pushHistory('ability-duplicate'); duplicateAbility(target.dataset.abilityId); }
    else if (action === 'ability-delete') { pushHistory('ability-delete'); deleteAbility(target.dataset.abilityId); }
    else if (action === 'ability-up') { pushHistory('ability-move'); moveAbility(target.dataset.abilityId, -1); }
    else if (action === 'ability-down') { pushHistory('ability-move'); moveAbility(target.dataset.abilityId, 1); }
    else if (action === 'ability-collapse') toggleAbilityCollapse(target.dataset.abilityId);
    else if (action === 'ability-save-template') {
      const label = `Ability Template ${state.userTemplates.length + 1}`;
      saveUserTemplate(label);
    }
    else if (action === 'save-card') saveCurrentCard();
    else if (action === 'export-card-json') exportCardJson();
    else if (action === 'import-card-json') importCardJson();
    else if (action === 'save-version') saveVersion();
    else if (action === 'restore-version') restoreVersion(num(target.dataset.versionIndex, -1));
    else if (action === 'delete-version') deleteVersion(num(target.dataset.versionIndex, -1));
    else if (action === 'copy-project-json') copyProjectJson();
    else if (action === 'import-project-json') importProjectJson();
    else if (action === 'duplicate-card') duplicateCard();
    else if (action === 'clone-variant') cloneVariant();
    else if (action === 'reset-draft') resetDraft();
    else if (action === 'preview-popout') openPreviewPopout();
    else if (action === 'close-preview-popout') closePreviewPopout();
    else if (action === 'open-art-upload') document.querySelector('#art-file-input')?.click();
    else if (action === 'open-command-palette') { state.ui.commandOpen = true; renderCommandPalette(); }
    else if (action === 'close-command-palette') { state.ui.commandOpen = false; renderCommandPalette(); }
    else if (action === 'run-command') runCommand(target.dataset.commandId);
    else if (action === 'workspace-preset') applyWorkspacePreset(target.dataset.preset);
    else if (action === 'load-card-id') {
      const card = state.cardLibrary[target.dataset.cardId];
      if (card) {
        pushHistory('load-card');
        loadCardToDraft(card);
        renderAll();
        logActivity(`Loaded card ${card.name || card.id}.`);
      }
    }
    else if (action === 'jump-to-path') {
      const moduleGuess = state.validation.errors.find((entry) => entry.path === target.dataset.path)?.module
        || state.validation.warnings.find((entry) => entry.path === target.dataset.path)?.module;
      if (moduleGuess) jumpToModule(moduleGuess);
    }
    else if (action === 'undo') undo();
    else if (action === 'redo') redo();
    else if (action === 'quick-validate') {
      validateDraft();
      renderAll();
      logActivity('Validation refreshed.');
    }
  });

  document.addEventListener('input', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (target.matches('[data-path]')) {
      updateDraftFieldFromInput(target);
      queueAutosave();
      return;
    }
    if (target.matches('[data-ability-field]')) {
      const input = target;
      const abilityId = input.dataset.abilityId;
      const field = input.dataset.abilityField;
      if (abilityId && field) {
        let value;
        if (input.type === 'checkbox') value = input.checked;
        else value = input.value;
        updateAbilityField(abilityId, field, value);
        queueAutosave();
      }
      return;
    }
    if (target.id === 'module-search') {
      state.ui.moduleSearch = target.value;
      renderLeftPane();
      renderCenterPane();
      return;
    }
    if (target.id === 'command-search') {
      state.ui.commandQuery = target.value;
      renderCommandPalette();
      return;
    }
    if (target.id === 'preview-zoom') {
      state.ui.previewZoom = num(target.value, 1);
      renderRightPane();
      return;
    }
  });

  document.addEventListener('change', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (target.id === 'creator-card-mode' || target.id === 'module-mode-select') {
      pushHistory('mode-change');
      applyModeDefaults(target.value);
      validateDraft();
      queueAutosave();
      renderAll();
      return;
    }
    if (target.id === 'creator-experience' || target.id === 'module-experience-select') {
      state.ui.experience = target.value;
      queueAutosave();
      renderAll();
      return;
    }
    if (target.id === 'workspace-preset-select' || target.id === 'module-workspace-select') {
      applyWorkspacePreset(target.value);
      return;
    }
    if (target.id === 'creator-type-quick') {
      pushHistory('type-change');
      state.draft.type = target.value;
      validateDraft();
      queueAutosave();
      renderAll();
      return;
    }
    if (target.id === 'preview-mode-select') {
      state.ui.previewMode = target.value;
      renderRightPane();
      queueAutosave();
      return;
    }
    if (target.id === 'preview-show-tags') {
      state.ui.previewShowTags = target.value === 'yes';
      renderRightPane();
      queueAutosave();
      return;
    }
    if (target.matches('[data-path]')) {
      pushHistory(`edit:${target.dataset.path}`);
    }
  });

  document.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault();
      saveCurrentCard();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      state.ui.commandOpen = true;
      renderCommandPalette();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
      event.preventDefault();
      undo();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') {
      event.preventDefault();
      redo();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === 's') {
      event.preventDefault();
      saveVersion('Shortcut Snapshot');
      return;
    }
    if (event.key === 'Escape') {
      state.ui.commandOpen = false;
      renderCommandPalette();
      closePreviewPopout();
    }
  });

  const fileInput = document.querySelector('#art-file-input');
  fileInput?.addEventListener('change', () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    pushHistory('art-upload');
    loadArtFile(file);
    fileInput.value = '';
  });
}

async function loadPluginData() {
  const logs = [];
  const errors = await loadPlugins(
    registry,
    [
      { manifest: './plugins/index.json', base: './plugins', type: 'card-pack', kind: 'creatorCardPacks' },
      { manifest: './ability_packs/index.json', base: './ability_packs', type: 'ability-pack', kind: 'abilityPacks' },
      { manifest: '../packs/index.json', base: '../packs', type: 'card-pack', kind: 'sharedCardPacks' },
      { manifest: '../game/ai_packs/index.json', base: '../game/ai_packs', type: 'ai-pack', kind: 'aiPacks' },
    ],
    (line) => logs.push(line),
  );
  state.abilityTemplates = [...FALLBACK_ABILITY_TEMPLATES, ...registry.list('abilityPacks').flatMap((pack) => pack.templates ?? [])];
  state.pluginTemplates = registry.list('creatorCardPacks').flatMap((pack) => (pack.cards ?? []).filter((card) => card.template));
  [...logs, ...errors.map((msg) => `Error: ${msg}`)].forEach((msg) => logActivity(msg));
}

function hydratePersistentState() {
  state.userTemplates = loadJsonStorage(STORAGE.userTemplates, []);
  state.versions = loadJsonStorage(STORAGE.versions, []);
  state.recentCards = loadJsonStorage(STORAGE.recentCards, []);
  state.cardLibrary = loadJsonStorage(STORAGE.customCards, {});
  state.profile = loadJsonStorage(STORAGE.profile, {});
  const uiPrefs = loadJsonStorage(STORAGE.uiPrefs, {});
  state.ui.workspace = uiPrefs.workspace ?? state.ui.workspace;
  state.ui.leftCollapsed = !!uiPrefs.leftCollapsed;
  state.ui.rightCollapsed = !!uiPrefs.rightCollapsed;
  state.ui.bottomCollapsed = !!uiPrefs.bottomCollapsed;
}

function bootstrapDraft() {
  state.draft = createDefaultDraft(state.ui.mode);
  const restored = loadProjectDraft();
  if (!restored) {
    const starter = BUILTIN_TEMPLATES.find((template) => template.id === 'tmpl-basic-minion');
    if (starter) mergeDeep(state.draft, safeClone(starter.patch));
  }
  state.ui.moduleOrder = moduleRegistry().map((module) => module.id);
  if (state.ui.workspace) applyWorkspacePreset(state.ui.workspace);
}

async function boot() {
  hydratePersistentState();
  bootstrapDraft();
  await loadPluginData();
  validateDraft();
  pushHistory('boot');
  state.ready = true;
  bindGlobalEvents();
  renderAll();
  logActivity('Creator Studio ready.');
}

boot();
