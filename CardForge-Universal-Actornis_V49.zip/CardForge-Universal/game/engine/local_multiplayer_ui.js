import {
  LOCAL_PLAYER_AI_DIFFICULTIES,
  LOCAL_PLAYER_ELEMENTS,
  LOCAL_PLAYER_FORMATS,
  LOCAL_PLAYER_MODES,
  LOCAL_PLAYER_STORMS,
  LOCAL_PLAYER_WARBANDS,
  createLocalMatch,
  currentLocalParticipant,
  defaultLocalPlayerSetup,
  endLocalTurn,
  hydrateModeChoices,
  localAttack,
  localLegalAttackTargets,
  localMatchToText,
  localSeatSummary,
  normalizeLocalPlayerSetup,
  playLocalCard,
  randomizeSeatOrder,
  runLocalAiTurn,
  acknowledgeHandoff,
} from './local_multiplayer.js';

const LOCAL_PLAYER_SETUP_KEY = 'cardforge.localplayer.setup.v1';
const LOCAL_PLAYER_PRESET_KEY = 'cardforge.localplayer.presets.v1';
let globalHotkeysAttached = false;

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function readLocalJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export function createLocalPlayerController(env = {}) {
  const {
    state,
    getAllCards,
    toast,
    openInspectPanel,
    collectCardFamilies,
    extractCardRaces,
    getFamiliarity,
    hasFamilyTag,
    normalizeAbilityText,
    normalizeCardType,
    raceIconGlyph,
    raceMeta,
    toNumber,
    uid,
  } = env;

  function persistPrefs() {
    if (state.localPlayer?.setup) {
      const setup = cloneJson(state.localPlayer.setup);
      setup.slots = (setup.slots ?? []).map((slot) => ({ ...slot, chaosOptions: [] }));
      localStorage.setItem(LOCAL_PLAYER_SETUP_KEY, JSON.stringify(setup));
    }
    localStorage.setItem(LOCAL_PLAYER_PRESET_KEY, JSON.stringify(state.localPlayer?.presets ?? []));
  }

  function ensureReady() {
    if (state.localPlayer.setup) return;
    const savedSetup = readLocalJson(LOCAL_PLAYER_SETUP_KEY, null);
    const savedPresets = readLocalJson(LOCAL_PLAYER_PRESET_KEY, []);
    state.localPlayer.setup = hydrateModeChoices(normalizeLocalPlayerSetup(savedSetup ?? defaultLocalPlayerSetup(), []), getAllCards());
    state.localPlayer.presets = Array.isArray(savedPresets) ? savedPresets : [];
  }

  function formatMeta(setup = state.localPlayer.setup) {
    return LOCAL_PLAYER_FORMATS.find((entry) => entry.id === setup?.formatId) ?? LOCAL_PLAYER_FORMATS[0];
  }

  function modeMeta(setup = state.localPlayer.setup) {
    return LOCAL_PLAYER_MODES.find((entry) => entry.id === setup?.modeId) ?? LOCAL_PLAYER_MODES[0];
  }

  function enabledSlots(setup = state.localPlayer.setup) {
    return (setup?.slots ?? []).filter((slot) => slot.enabled);
  }

  function setupIssues(setup = state.localPlayer.setup) {
    const issues = [];
    const enabled = enabledSlots(setup);
    if (enabled.length < 2) issues.push('Enable at least two seats.');
    if (new Set(enabled.map((slot) => Number(slot.team ?? 0))).size < 2) issues.push('At least two teams are required.');
    if (setup?.modeId === 'elemental') {
      enabled.forEach((slot) => {
        if (!Array.isArray(slot.elements) || slot.elements.length !== 2 || slot.elements[0] === slot.elements[1]) {
          issues.push(`${slot.name}: choose two different elements.`);
        }
      });
    }
    return issues;
  }

  function controllerLabel(slot = {}) {
    if (slot.controller === 'ai') {
      const diff = LOCAL_PLAYER_AI_DIFFICULTIES.find((entry) => entry.id === slot.aiDifficulty)?.label ?? 'Normal';
      return `AI • ${diff}`;
    }
    return 'Human';
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function liveSeats(match = state.localPlayer.match) {
    return (match?.participants ?? []).filter((entry) => !entry.eliminated);
  }

  function defaultBoardScaleForSeatCount(count = 2) {
    if (count >= 4) return 0.94;
    if (count === 3) return 0.98;
    return 1;
  }

  function createDefaultViewLayout(match = state.localPlayer.match, perspectiveSeatId = state.localPlayer.perspectiveSeatId) {
    return {
      boardScale: defaultBoardScaleForSeatCount(liveSeats(match).length),
      boardOffset: { x: 0, y: 0 },
      handScale: 1,
      handCompact: false,
      handSort: 'original',
    };
  }

  function ensureViewLayout(match = state.localPlayer.match, perspectiveSeatId = state.localPlayer.perspectiveSeatId) {
    if (!match || !perspectiveSeatId) return null;
    state.localPlayer.viewLayouts = state.localPlayer.viewLayouts && typeof state.localPlayer.viewLayouts === 'object'
      ? state.localPlayer.viewLayouts
      : {};
    if (!state.localPlayer.viewLayouts[perspectiveSeatId]) {
      state.localPlayer.viewLayouts[perspectiveSeatId] = createDefaultViewLayout(match, perspectiveSeatId);
    }
    const layout = state.localPlayer.viewLayouts[perspectiveSeatId];
    layout.boardScale = clamp(toNumber(layout.boardScale, defaultBoardScaleForSeatCount(liveSeats(match).length)), 0.72, 1.28);
    layout.boardOffset = {
      x: clamp(toNumber(layout.boardOffset?.x, 0), -240, 240),
      y: clamp(toNumber(layout.boardOffset?.y, 0), -240, 240),
    };
    layout.handScale = clamp(toNumber(layout.handScale, 1), 0.82, 1.32);
    layout.handCompact = !!layout.handCompact;
    layout.handSort = ['original', 'cost', 'type'].includes(layout.handSort) ? layout.handSort : 'original';
    return layout;
  }

  function resetPerspectiveLayout(match = state.localPlayer.match, perspectiveSeatId = state.localPlayer.perspectiveSeatId) {
    if (!match || !perspectiveSeatId) return;
    state.localPlayer.viewLayouts = state.localPlayer.viewLayouts && typeof state.localPlayer.viewLayouts === 'object'
      ? state.localPlayer.viewLayouts
      : {};
    state.localPlayer.viewLayouts[perspectiveSeatId] = createDefaultViewLayout(match, perspectiveSeatId);
  }

  function clearAiTimer() {
    if (state.localPlayer.aiTimer) {
      clearTimeout(state.localPlayer.aiTimer);
      state.localPlayer.aiTimer = null;
    }
  }

  function resetSelections() {
    state.localPlayer.selectedHandCardId = null;
    state.localPlayer.selectedAttackerId = null;
  }

  function resetLayoutState() {
    state.localPlayer.boardDrag = null;
    state.localPlayer.dragState = null;
    state.localPlayer.hoverPreview = null;
    state.localPlayer.pendingFx = null;
    state.localPlayer.suppressClickUntil = 0;
    state.localPlayer.viewLayouts = {};
    destroyDragGhost();
  }

  function showTitle() {
    clearAiTimer();
    state.localPlayer.boardDrag = null;
    state.localPlayer.dragState = null;
    state.localPlayer.hoverPreview = null;
    destroyDragGhost();
    document.querySelector('#title-screen')?.classList.remove('hidden');
    document.querySelector('#title-stats-panel')?.classList.add('hidden');
    document.querySelector('#local-player-panel')?.classList.add('hidden');
    document.querySelector('#local-player-app')?.classList.add('hidden');
    document.querySelector('#app')?.classList.add('hidden');
  }

  function updateSetup(mutator) {
    ensureReady();
    const draft = cloneJson(state.localPlayer.setup);
    mutator(draft);
    state.localPlayer.setup = hydrateModeChoices(normalizeLocalPlayerSetup(draft, []), getAllCards());
    persistPrefs();
    renderSetup();
  }

  function refreshSetup(regenerateSeed = false) {
    updateSetup((draft) => {
      if (regenerateSeed) draft.randomSeed = `${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    });
  }

  function quickFillAi() {
    updateSetup((draft) => {
      (draft.slots ?? []).forEach((slot, index) => {
        if (!slot.enabled || index === 0) return;
        slot.controller = 'ai';
        slot.aiDifficulty = index >= 2 ? 'hard' : 'normal';
        if (!slot.name || /^player\s+\d+$/i.test(slot.name)) slot.name = `AI ${index + 1}`;
      });
    });
  }

  function savePreset() {
    const current = state.localPlayer.setup;
    const name = window.prompt('Preset name', `${formatMeta(current).label} • ${modeMeta(current).label}`)?.trim();
    if (!name) return;
    const preset = { id: uid('local-preset'), name, createdAt: Date.now(), setup: cloneJson(current) };
    preset.setup.slots = (preset.setup.slots ?? []).map((slot) => ({ ...slot, chaosOptions: [] }));
    state.localPlayer.presets = [preset, ...(state.localPlayer.presets ?? []).filter((entry) => entry.id !== preset.id)].slice(0, 10);
    persistPrefs();
    renderSetup();
    toast(`Saved preset: ${name}`, 'info');
  }

  function applyPreset(presetId) {
    const preset = (state.localPlayer.presets ?? []).find((entry) => entry.id === presetId);
    if (!preset) return;
    state.localPlayer.setup = hydrateModeChoices(normalizeLocalPlayerSetup(preset.setup, []), getAllCards());
    persistPrefs();
    renderSetup();
  }

  function deletePreset(presetId) {
    state.localPlayer.presets = (state.localPlayer.presets ?? []).filter((entry) => entry.id !== presetId);
    persistPrefs();
    renderSetup();
  }

  function openSetup() {
    ensureReady();
    clearAiTimer();
    state.localPlayer.match = null;
    state.localPlayer.activeScreen = 'setup';
    state.localPlayer.lastCompletedMatch = null;
    resetLayoutState();
    resetSelections();
    document.querySelector('#title-screen')?.classList.add('hidden');
    document.querySelector('#title-stats-panel')?.classList.add('hidden');
    document.querySelector('#app')?.classList.add('hidden');
    document.querySelector('#local-player-app')?.classList.add('hidden');
    document.querySelector('#local-player-panel')?.classList.remove('hidden');
    renderSetup();
    attachSetupHandlers();
  }

  function renderSetup() {
    ensureReady();
    const host = document.querySelector('#local-player-panel');
    if (!host) return;
    const setup = state.localPlayer.setup;
    const issues = setupIssues(setup);
    const format = formatMeta(setup);
    const mode = modeMeta(setup);
    const presets = (state.localPlayer.presets ?? []).length
      ? (state.localPlayer.presets ?? []).map((preset) => `
          <article class="local-preset-card local-summary-card">
            <strong>${preset.name}</strong>
            <div class="meta">${new Date(preset.createdAt).toLocaleString()}</div>
            <div class="local-actions-row">
              <button data-local-action="apply-preset" data-local-id="${preset.id}">Load</button>
              <button class="subtle" data-local-action="delete-preset" data-local-id="${preset.id}">Delete</button>
            </div>
          </article>`).join('')
      : '<div class="local-empty-note">No saved presets yet.</div>';
    const seatPreview = (setup.seatOrder ?? []).map((seatIndex, turnIndex) => {
      const slot = setup.slots?.[seatIndex];
      if (!slot?.enabled) return '';
      return `<span class="turn-pill" style="border-color:${slot.color};">T${turnIndex + 1} • ${slot.name}</span>`;
    }).join('');

    host.innerHTML = `
      <div class="local-setup-shell">
        <aside class="local-setup-sidebar">
          <article class="local-side-panel">
            <div class="local-side-panel-head">
              <h4>Format</h4>
              <span class="local-chip active">${format.label}</span>
            </div>
            <div class="local-chip-row">
              ${LOCAL_PLAYER_FORMATS.map((entry) => `<button class="local-chip ${entry.id === setup.formatId ? 'active' : ''}" data-local-action="set-format" data-local-id="${entry.id}">${entry.label}</button>`).join('')}
            </div>
            <div class="meta">${format.description}</div>
            <div class="local-banner-note">All cards are unlocked here. Local Player never mutates campaign progression or collection ownership.</div>
          </article>
          <article class="local-side-panel">
            <h4>Seat Order</h4>
            <div class="local-turn-order">${seatPreview || '<span class="local-empty-note">Enable seats to generate turn order.</span>'}</div>
            <div class="local-actions-row">
              <button data-local-action="randomize-seats">Randomize Seats</button>
              <button class="subtle" data-local-action="quick-ai-fill">Quick AI Fill</button>
            </div>
          </article>
          <article class="local-side-panel">
            <h4>Presets</h4>
            ${presets}
            <div class="local-actions-row">
              <button data-local-action="save-preset">Save Preset</button>
              <button class="subtle" data-local-action="refresh-seed">Regenerate Choices</button>
            </div>
          </article>
        </aside>
        <main class="local-setup-main">
          <article class="local-summary-card">
            <div class="local-runtime-head">
              <div>
                <h4>Deck Generation Mode</h4>
                <div class="meta">${mode.description}</div>
              </div>
              <span class="local-chip active">${enabledSlots(setup).length} active seats</span>
            </div>
            <div class="local-mode-grid">
              ${LOCAL_PLAYER_MODES.map((entry) => `<article class="local-mode-card ${entry.id === setup.modeId ? 'active' : ''}" data-local-action="set-mode" data-local-id="${entry.id}"><h4>${entry.label}</h4><div class="meta">${entry.description}</div></article>`).join('')}
            </div>
          </article>
          <article class="local-summary-card">
            <div class="local-runtime-head">
              <div>
                <h4>Seats & Teams</h4>
                <div class="meta">Configure humans, AI, colors, teams, and mode-specific deck inputs.</div>
              </div>
              <span class="local-chip">${format.id === 'custom' ? 'Custom Teams' : 'Preset Teams'}</span>
            </div>
            <div class="local-seat-grid">
              ${setup.slots.map((slot, index) => `
                <article class="local-seat-card ${slot.enabled ? '' : 'disabled'}" style="box-shadow:0 0 0 1px ${slot.color}55, 0 16px 28px rgba(0,0,0,.22);">
                  <div class="local-seat-head">
                    <h4><span class="local-color-dot" style="background:${slot.color}"></span> Seat ${index + 1}</h4>
                    <label class="local-chip"><input type="checkbox" data-local-field="enabled" data-seat-index="${index}" ${slot.enabled ? 'checked' : ''}/> Active</label>
                  </div>
                  <label>Name<input data-local-field="name" data-seat-index="${index}" value="${slot.name}" maxlength="24" /></label>
                  <div class="local-option-grid">
                    <label>Controller<select data-local-field="controller" data-seat-index="${index}"><option value="human" ${slot.controller === 'human' ? 'selected' : ''}>Human</option><option value="ai" ${slot.controller === 'ai' ? 'selected' : ''}>AI</option></select></label>
                    <label>AI Difficulty<select data-local-field="aiDifficulty" data-seat-index="${index}" ${slot.controller !== 'ai' ? 'disabled' : ''}>${LOCAL_PLAYER_AI_DIFFICULTIES.map((entry) => `<option value="${entry.id}" ${slot.aiDifficulty === entry.id ? 'selected' : ''}>${entry.label}</option>`).join('')}</select></label>
                    <label>Team<select data-local-field="team" data-seat-index="${index}" ${setup.formatId !== 'custom' ? 'disabled' : ''}>${Array.from({ length: 4 }, (_, teamIndex) => `<option value="${teamIndex + 1}" ${Number(slot.team) === teamIndex + 1 ? 'selected' : ''}>Team ${teamIndex + 1}</option>`).join('')}</select></label>
                  </div>
                  <div class="local-seat-meta"><span class="local-chip">${slot.color}</span><span class="local-chip">${controllerLabel(slot)}</span><span class="local-chip">Team ${slot.team}</span></div>
                  ${renderSetupModeInputs(setup, slot, index)}
                </article>`).join('')}
            </div>
          </article>
          <article class="local-summary-card">
            <div class="local-runtime-head"><h4>Launch</h4><span class="local-chip ${issues.length ? '' : 'active'}">${issues.length ? `${issues.length} issue(s)` : 'Ready'}</span></div>
            ${issues.length ? `<div class="local-banner-note">${issues.map((entry) => `<div>${entry}</div>`).join('')}</div>` : ''}
            <div class="local-actions-row"><button data-local-action="start-match">Start Local Match</button><button class="subtle" data-local-action="back-title">Back To Title</button></div>
          </article>
        </main>
      </div>`;
    attachSetupHandlers();
  }
  function renderSetupModeInputs(setup = state.localPlayer.setup, slot = {}, index = 0) {
    const chaosOptions = slot.chaosOptions ?? [];
    if (setup.modeId === 'chaos') {
      return `<div class="local-option-grid">${chaosOptions.map((entry) => `<label class="local-chip ${entry.id === slot.selectedChaosId ? 'active' : ''}"><input type="radio" data-local-field="selectedChaosId" data-seat-index="${index}" value="${entry.id}" ${entry.id === slot.selectedChaosId ? 'checked' : ''}/> ${entry.label}</label>`).join('')}</div><div class="meta">${chaosOptions.find((entry) => entry.id === slot.selectedChaosId)?.description ?? 'Pick a schematic.'}</div>`;
    }
    if (setup.modeId === 'elemental') {
      return `<div class="local-option-grid"><label>Element A<select data-local-field="element0" data-seat-index="${index}">${LOCAL_PLAYER_ELEMENTS.map((entry) => `<option value="${entry}" ${slot.elements?.[0] === entry ? 'selected' : ''}>${entry}</option>`).join('')}</select></label><label>Element B<select data-local-field="element1" data-seat-index="${index}">${LOCAL_PLAYER_ELEMENTS.map((entry) => `<option value="${entry}" ${slot.elements?.[1] === entry ? 'selected' : ''}>${entry}</option>`).join('')}</select></label></div>`;
    }
    if (setup.modeId === 'warbands') {
      return `<label>Warband<select data-local-field="warband" data-seat-index="${index}">${LOCAL_PLAYER_WARBANDS.map((entry) => `<option value="${entry.id}" ${slot.warband === entry.id ? 'selected' : ''}>${entry.label}</option>`).join('')}</select></label>`;
    }
    return `<label>Storm Focus<select data-local-field="stormFocus" data-seat-index="${index}">${LOCAL_PLAYER_STORMS.map((entry) => `<option value="${entry.id}" ${slot.stormFocus === entry.id ? 'selected' : ''}>${entry.label}</option>`).join('')}</select></label>`;
  }

  function findCard(match = state.localPlayer.match, seatId = '', cardId = '') {
    const participant = (match?.participants ?? []).find((entry) => entry.id === seatId);
    if (!participant) return null;
    return [...(participant.hand ?? []), ...(participant.board ?? []), ...(participant.relics ?? []), ...(participant.fields ?? []), ...(participant.graveyard ?? [])].find((entry) => entry.instanceId === cardId) ?? null;
  }

  function selectedHandCard(match = state.localPlayer.match) {
    const active = currentLocalParticipant(match);
    return active ? (active.hand ?? []).find((card) => card.instanceId === state.localPlayer.selectedHandCardId) ?? null : null;
  }

  function selectedAttacker(match = state.localPlayer.match) {
    const active = currentLocalParticipant(match);
    return active ? (active.board ?? []).find((card) => card.instanceId === state.localPlayer.selectedAttackerId) ?? null : null;
  }

  function canHumanAct(match = state.localPlayer.match) {
    const active = currentLocalParticipant(match);
    return !!active && !match?.matchOver && active.controller === 'human' && !match?.handoff?.required;
  }

  function seatClass(participant = {}, current = null, perspective = null) {
    const classes = [`role-${participant.perspectiveRole}`];
    if (participant.id === current?.id) classes.push('current-turn');
    if (perspective && participant.team === perspective.team && participant.id !== perspective.id) classes.push('teammate');
    else if (perspective && participant.id !== perspective.id) classes.push('enemy');
    return classes.join(' ');
  }

  function handCardClass(layout = null) {
    return layout?.handCompact ? 'compact' : 'expanded';
  }

  function attackValue(participant = {}, card = {}) {
    const auraBonus = [...(participant.relics ?? []), ...(participant.fields ?? []), ...(participant.board ?? [])].reduce((sum, perm) => {
      const match = normalizeAbilityText(perm.text ?? '').toLowerCase().match(/your\s+([a-z-]+)s?\s+have\s+\+(\d+)\s+attack/i);
      return match && hasFamilyTag(card, match[1]) ? sum + Number(match[2] ?? 0) : sum;
    }, 0);
    return Math.max(0, toNumber(card.attack, 0) + toNumber(card.tempAttack, 0) + auraBonus);
  }

  function targetKeys(match = state.localPlayer.match) {
    const active = currentLocalParticipant(match);
    const attacker = selectedAttacker(match);
    if (!active || !attacker || !canHumanAct(match)) return new Set();
    return new Set(localLegalAttackTargets(match, active.id, attacker).map((target) => `${target.type}:${target.ownerId}:${target.cardId ?? 'hero'}`));
  }

  function participantFamiliarity(participant = {}, card = null) {
    const pool = participant?.familiarity && typeof participant.familiarity === 'object' ? participant.familiarity : {};
    const focus = card ? collectCardFamilies(card) : Object.keys(pool);
    const entries = [...new Set(focus)].map((family) => {
      const amount = getFamiliarity(pool, family);
      return amount > 0 ? `${raceIconGlyph(family)} ${amount}` : null;
    }).filter(Boolean);
    return entries.join(' · ') || 'None';
  }

  function cardDefense(card = {}) {
    return Math.max(0, toNumber(card.defense ?? card.armor ?? card.shield ?? 0, 0));
  }

  function cardKeywordBadges(card = {}) {
    const normalizedText = normalizeAbilityText(card.text ?? '').toLowerCase();
    const tokens = new Set(
      [
        ...(Array.isArray(card.keywords) ? card.keywords : []),
        ...(Array.isArray(card.tags) ? card.tags : []),
      ].map((entry) => String(entry).toLowerCase()),
    );
    const badges = [];
    const maybePush = (id, label) => {
      if (!badges.some((entry) => entry.id === id)) badges.push({ id, label });
    };
    if (tokens.has('flying') || /\bflying\b/.test(normalizedText)) maybePush('flying', 'FLY');
    if (tokens.has('taunt') || tokens.has('guard') || /\b(taunt|guard)\b/.test(normalizedText)) maybePush('guard', 'GRD');
    if (tokens.has('rush') || /\brush\b/.test(normalizedText)) maybePush('rush', 'RSH');
    if (tokens.has('charge') || /\bcharge\b/.test(normalizedText)) maybePush('charge', 'CHG');
    if (tokens.has('lifesteal') || /\blifesteal\b/.test(normalizedText)) maybePush('lifesteal', 'LST');
    if (tokens.has('stealth') || /\bstealth\b/.test(normalizedText)) maybePush('stealth', 'STL');
    if (tokens.has('divine shield') || normalizedText.includes('divine shield') || card.statuses?.divineShield) maybePush('shield', 'DS');
    if (tokens.has('dragon') || hasFamilyTag(card, 'dragon') || hasFamilyTag(card, 'dragonkin')) maybePush('dragon', 'DRG');
    return badges.slice(0, 5);
  }

  function reasonLabel(reason = '') {
    return ({
      not_turn: 'Not your turn',
      mana: 'Not enough mana',
      board_full: 'No legal lane',
      missing_card: 'Card is no longer available',
      missing_attacker: 'Attacker is gone',
      exhausted: 'Already attacked',
      invalid_target: 'Blocked by Taunt or invalid target',
      missing_target: 'Target disappeared',
      match_over: 'Match is already over',
    }[reason] ?? 'Invalid action');
  }

  function seatIdentityLabel(participant = {}, current = null, perspective = null) {
    if (participant.eliminated) return 'Eliminated';
    if (participant.id === current?.id) return 'Current turn';
    if (participant.id === perspective?.id) return 'You';
    if (perspective && participant.team === perspective.team) return 'Teammate';
    return 'Enemy';
  }

  function sortedHandCards(cards = [], layout = null) {
    const list = [...cards];
    if (layout?.handSort === 'cost') {
      list.sort((a, b) => toNumber(a.cost, 0) - toNumber(b.cost, 0) || String(a.name).localeCompare(String(b.name)));
    } else if (layout?.handSort === 'type') {
      list.sort((a, b) => normalizeCardType(a).localeCompare(normalizeCardType(b)) || toNumber(a.cost, 0) - toNumber(b.cost, 0));
    }
    return list;
  }

  function destroyDragGhost() {
    if (state.localPlayer.dragGhostEl instanceof HTMLElement) state.localPlayer.dragGhostEl.remove();
    state.localPlayer.dragGhostEl = null;
  }

  function buildDragGhost(card = {}, ownerColor = '#7aa2ff') {
    destroyDragGhost();
    const ghost = document.createElement('div');
    ghost.className = 'local-drag-ghost';
    ghost.style.setProperty('--owner-color', ownerColor);
    ghost.innerHTML = `<strong>${card.name ?? 'Card'}</strong><span>${normalizeCardType(card)} • ${toNumber(card.cost, 0)}</span>`;
    document.body.appendChild(ghost);
    state.localPlayer.dragGhostEl = ghost;
    return ghost;
  }

  function moveDragGhost(x = 0, y = 0) {
    if (!(state.localPlayer.dragGhostEl instanceof HTMLElement)) return;
    state.localPlayer.dragGhostEl.style.transform = `translate(${x + 14}px, ${y + 14}px)`;
  }

  function clearInteractionOverlay(host) {
    host?.querySelectorAll('.drag-valid,.drag-hover,.local-impact-flash,.local-summon-flash,.local-attack-surge').forEach((node) => {
      node.classList.remove('drag-valid', 'drag-hover', 'local-impact-flash', 'local-summon-flash', 'local-attack-surge');
    });
    const layer = host?.querySelector('#local-interaction-layer');
    if (layer) layer.innerHTML = '';
  }

  function clearInteractionLine(host) {
    host?.querySelectorAll('.drag-hover').forEach((node) => node.classList.remove('drag-hover'));
    const layer = host?.querySelector('#local-interaction-layer');
    if (layer) layer.innerHTML = '';
  }

  function highlightDropTargets(host, keys = []) {
    clearInteractionOverlay(host);
    keys.forEach((key) => {
      host?.querySelector(`[data-local-drop-key="${key}"]`)?.classList.add('drag-valid');
    });
  }

  function setHoverDropTarget(host, key = '') {
    host?.querySelectorAll('.drag-hover').forEach((node) => node.classList.remove('drag-hover'));
    if (!key) return;
    host?.querySelector(`[data-local-drop-key="${key}"]`)?.classList.add('drag-hover');
  }

  function dropTargetAtPoint(host, x = 0, y = 0, allowedKeys = []) {
    const allowed = new Set(allowedKeys);
    const doc = host?.ownerDocument ?? document;
    if (doc?.elementsFromPoint) {
      const stack = doc.elementsFromPoint(x, y);
      for (const entry of stack) {
        if (!(entry instanceof Element)) continue;
        const candidate = entry.closest?.('[data-local-drop-key]');
        const key = candidate?.getAttribute?.('data-local-drop-key') ?? '';
        if (key && allowed.has(key) && candidate instanceof HTMLElement) return { key, node: candidate };
      }
    }
    const candidates = allowedKeys.map((key) => {
      const node = host?.querySelector(`[data-local-drop-key="${key}"]`);
      if (!(node instanceof HTMLElement)) return null;
      const rect = node.getBoundingClientRect();
      if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) return null;
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      return {
        key,
        node,
        area: rect.width * rect.height,
        distance: Math.hypot(x - centerX, y - centerY),
      };
    }).filter(Boolean).sort((a, b) => a.area - b.area || a.distance - b.distance);
    return candidates[0] ?? null;
  }

  function dropKeyAtPoint(host, x = 0, y = 0, allowedKeys = []) {
    return dropTargetAtPoint(host, x, y, allowedKeys)?.key ?? '';
  }

  function drawInteractionLine(host, from = null, to = null, color = '#8fd4ff') {
    const layer = host?.querySelector('#local-interaction-layer');
    const viewport = host?.querySelector('#local-board-viewport');
    if (!(layer instanceof SVGElement) || !(viewport instanceof HTMLElement) || !from || !to) return;
    const rect = viewport.getBoundingClientRect();
    layer.setAttribute('viewBox', `0 0 ${Math.max(1, rect.width)} ${Math.max(1, rect.height)}`);
    layer.innerHTML = `<defs><marker id="local-arrow-head" markerWidth="12" markerHeight="12" refX="9" refY="6" orient="auto"><path d="M0,0 L12,6 L0,12 Z" fill="${color}"></path></marker></defs><line class="local-attack-line" x1="${from.x - rect.left}" y1="${from.y - rect.top}" x2="${to.x - rect.left}" y2="${to.y - rect.top}" stroke="${color}" marker-end="url(#local-arrow-head)"></line>`;
  }

  function emitArenaFloat(host, text = '', x = 0, y = 0, tone = 'info') {
    if (!(host instanceof HTMLElement)) return;
    const viewport = host.querySelector('#local-board-viewport');
    if (!(viewport instanceof HTMLElement)) return;
    const rect = viewport.getBoundingClientRect();
    const node = document.createElement('div');
    node.className = `local-battle-float ${tone}`;
    node.textContent = text;
    node.style.left = `${x - rect.left}px`;
    node.style.top = `${y - rect.top}px`;
    viewport.appendChild(node);
    window.setTimeout(() => node.remove(), 900);
  }

  function updateHoverPreview(host, match, preview = null) {
    const panel = host?.querySelector('#local-hover-preview');
    if (!(panel instanceof HTMLElement)) return;
    state.localPlayer.hoverPreview = preview;
    if (!preview?.visible) {
      panel.classList.add('hidden');
      panel.innerHTML = '';
      return;
    }
    const participant = (match?.participants ?? []).find((entry) => entry.id === preview.seatId);
    if (!participant) {
      panel.classList.add('hidden');
      panel.innerHTML = '';
      return;
    }
    const card = preview.kind === 'card' ? findCard(match, preview.seatId, preview.cardId) : null;
    const families = card ? extractCardRaces(card) : [];
    panel.classList.remove('hidden');
    panel.style.setProperty('--player-color', participant.color);
    panel.innerHTML = `<div class="local-hover-preview-head"><strong>${card?.name ?? participant.name}</strong><span>${card ? normalizeCardType(card) : 'Hero'}</span></div>
      <div class="local-hover-preview-body">
        ${card ? `<div class="local-card-stats"><span>ATK ${attackValue(participant, card)}</span><span>HP ${toNumber(card.health, 0)}</span><span>DEF ${cardDefense(card)}</span></div>
        <div class="local-family-row">${families.map((family) => `<span class="local-family-chip">${raceIconGlyph(family)} ${raceMeta(family).label}</span>`).join('') || '<span class="local-family-chip">Neutral</span>'}</div>
        <div class="local-keyword-row">${cardKeywordBadges(card).map((badge) => `<span class="local-keyword-chip ${badge.id}">${badge.label}</span>`).join('') || '<span class="local-keyword-chip muted">No tags</span>'}</div>
        <div class="meta">${card.text || 'No rules text.'}</div>
        <div class="meta">Owner ${participant.name} • Familiarity ${participantFamiliarity(participant, card)}</div>` : `<div class="local-card-stats"><span>HP ${participant.heroHealth}/${participant.heroMaxHealth}</span><span>Mana ${participant.mana}/${participant.maxMana}</span></div><div class="meta">Deck ${participant.deck.length} • Hand ${participant.hand.length}</div><div class="meta">Familiarity: ${participantFamiliarity(participant)}</div>`}
      </div>`;
    const viewport = host?.querySelector('#local-board-viewport');
    if (viewport instanceof HTMLElement) {
      const viewRect = viewport.getBoundingClientRect();
      const width = panel.offsetWidth || 280;
      const height = panel.offsetHeight || 180;
      const left = Math.min(Math.max(preview.x, viewRect.left + 12), viewRect.right - width - 12);
      const top = Math.min(Math.max(preview.y, viewRect.top + 12), viewRect.bottom - height - 12);
      panel.style.left = `${left - viewRect.left}px`;
      panel.style.top = `${top - viewRect.top}px`;
    } else {
      panel.style.left = `${preview.x}px`;
      panel.style.top = `${preview.y}px`;
    }
  }

  function queueBattleFx(fx = null) {
    state.localPlayer.pendingFx = fx;
  }

  function applyPendingFx(host, match = state.localPlayer.match) {
    const fx = state.localPlayer.pendingFx;
    if (!fx || !(host instanceof HTMLElement)) return;
    state.localPlayer.pendingFx = null;
    if (fx.type === 'summon') {
      host.querySelector(`[data-card-id="${fx.cardId}"]`)?.classList.add('local-summon-flash');
      if (fx.point) emitArenaFloat(host, 'Summon', fx.point.x, fx.point.y, 'good');
    } else if (fx.type === 'attack') {
      host.querySelector(`[data-card-id="${fx.attackerId}"]`)?.classList.add('local-attack-surge');
      if (fx.targetType === 'unit') host.querySelector(`[data-card-id="${fx.targetCardId}"]`)?.classList.add('local-impact-flash');
      if (fx.targetType === 'hero') host.querySelector(`[data-seat-id="${fx.targetSeatId}"][data-local-action="hero"]`)?.classList.add('local-impact-flash');
      if (fx.point) emitArenaFloat(host, `-${fx.amount ?? 0}`, fx.point.x, fx.point.y, 'bad');
    } else if (fx.type === 'invalid' && fx.point) {
      emitArenaFloat(host, fx.text ?? 'Invalid', fx.point.x, fx.point.y, 'warn');
    }
  }

  function scheduleAiTurn() {
    clearAiTimer();
    const match = state.localPlayer.match;
    const active = currentLocalParticipant(match);
    if (!match || !active || match.matchOver || active.controller !== 'ai') return;
    const difficulty = LOCAL_PLAYER_AI_DIFFICULTIES.find((entry) => entry.id === active.aiDifficulty) ?? LOCAL_PLAYER_AI_DIFFICULTIES[1];
    state.localPlayer.aiTimer = setTimeout(() => {
      state.localPlayer.aiTimer = null;
      if (!state.localPlayer.match || state.localPlayer.match.matchOver) return;
      runLocalAiTurn(state.localPlayer.match);
      state.localPlayer.perspectiveSeatId = currentLocalParticipant(state.localPlayer.match)?.id ?? state.localPlayer.perspectiveSeatId;
      resetSelections();
      renderBattle();
      scheduleAiTurn();
    }, difficulty.thinkMs);
  }

  function startMatch(fromSetup = null) {
    ensureReady();
    const setup = hydrateModeChoices(normalizeLocalPlayerSetup(fromSetup ?? state.localPlayer.setup, []), getAllCards());
    const issues = setupIssues(setup);
    if (issues.length) {
      toast(issues[0], 'error');
      renderSetup();
      return;
    }
    state.localPlayer.setup = setup;
    state.localPlayer.match = createLocalMatch(setup, getAllCards(), []);
    state.localPlayer.activeScreen = 'battle';
    state.localPlayer.perspectiveSeatId = currentLocalParticipant(state.localPlayer.match)?.id ?? null;
    resetLayoutState();
    resetSelections();
    persistPrefs();
    document.querySelector('#local-player-panel')?.classList.add('hidden');
    document.querySelector('#title-screen')?.classList.add('hidden');
    document.querySelector('#app')?.classList.add('hidden');
    document.querySelector('#local-player-app')?.classList.remove('hidden');
    renderBattle();
    attachBattleHandlers();
    scheduleAiTurn();
  }

  function rematch() {
    if (state.localPlayer.setup) startMatch(state.localPlayer.setup);
  }

  function heroTargetKey(participant = {}) {
    return `hero:${participant.id}:hero`;
  }

  function heroPanelHtml(participant = {}, current = null, perspective = null, activeTargetKeys = new Set()) {
    const heroKey = heroTargetKey(participant);
    const classes = ['local-hero-panel'];
    if (activeTargetKeys.has(heroKey)) classes.push('target-valid');
    if (state.localPlayer.selectedAttackerId && participant.id !== current?.id && !activeTargetKeys.has(heroKey)) classes.push('target-blocked');
    if (participant.id === current?.id) classes.push('current-turn');
    return `<button type="button" class="${classes.join(' ')}" data-local-action="hero" data-seat-id="${participant.id}" data-local-preview="hero" data-local-drop-key="${heroKey}">
      <div class="local-hero-top">
        <strong>${participant.name}</strong>
        <span class="local-team-pill" style="--player-color:${participant.color};">Team ${participant.team}</span>
      </div>
      <div class="local-hero-stats">
        <span>HP ${participant.heroHealth}/${participant.heroMaxHealth}</span>
        <span>Mana ${participant.mana}/${participant.maxMana}</span>
        <span>Deck ${participant.deck.length}</span>
        <span>Hand ${participant.hand.length}</span>
      </div>
      <div class="local-hero-foot">
        <span>${seatIdentityLabel(participant, current, perspective)}</span>
        <span>${participant.controller === 'ai' ? participant.aiDifficulty.toUpperCase() : 'HUMAN'}</span>
      </div>
    </button>`;
  }

  function boardCardHtml(match, participant, slotIndex, current, perspective, activeTargetKeys = new Set()) {
    const card = (participant.board ?? []).find((entry) => Number(entry.slot) === slotIndex) ?? null;
    const slotKey = `slot:${participant.id}:${slotIndex}`;
    const dragTargets = new Set(state.localPlayer.dragState?.targets ?? []);
    if (!card) {
      const selectedCard = selectedHandCard(match);
      const valid = (current?.id === participant.id && canHumanAct(match) && selectedCard && normalizeCardType(selectedCard) === 'minion')
        || dragTargets.has(slotKey);
      return `<button type="button" class="local-slot ${valid ? 'valid' : ''}" data-local-action="slot" data-local-drop-key="${slotKey}" data-seat-id="${participant.id}" data-slot="${slotIndex}">
        <span class="local-slot-label">${valid ? 'Deploy' : 'Open lane'}</span>
        <span class="local-slot-index">Slot ${slotIndex + 1}</span>
      </button>`;
    }
    const families = extractCardRaces(card);
    const key = `unit:${participant.id}:${card.instanceId}`;
    const badges = cardKeywordBadges(card);
    const compactFamilies = families.slice(0, 2).map((family) => `<span class="local-family-chip compact">${raceIconGlyph(family)} ${raceMeta(family).label.slice(0, 3).toUpperCase()}</span>`).join('');
    const compactBadges = badges.slice(0, 3).map((badge) => `<span class="local-keyword-chip ${badge.id} compact">${badge.label}</span>`).join('');
    const classes = ['local-board-card'];
    if (state.localPlayer.selectedAttackerId === card.instanceId || state.localPlayer.dragState?.cardId === card.instanceId) classes.push('selected');
    if (activeTargetKeys.has(key)) classes.push('target-valid');
    if ((state.localPlayer.selectedAttackerId || state.localPlayer.dragState?.type === 'attack') && participant.id !== current?.id && !activeTargetKeys.has(key)) classes.push('target-blocked');
    if (participant.id === current?.id && !card.canAttack) classes.push('exhausted');
    if (participant.id === current?.id && card.canAttack) classes.push('ready');
    classes.push(`rarity-${String(card.rarity ?? 'common').toLowerCase()}`);
    return `<button type="button" class="${classes.join(' ')}" data-local-action="board-card" data-seat-id="${participant.id}" data-card-id="${card.instanceId}" data-local-preview="card" data-local-drop-key="${key}" style="--owner-color:${participant.color};">
      <div class="local-board-card-frame">
        <div class="local-board-card-content">
          <div class="local-board-card-head">
            <strong>${card.name}</strong>
            <span class="local-card-ready ${participant.id === current?.id && card.canAttack ? 'ready' : 'spent'}">${participant.id === current?.id && card.canAttack ? 'READY' : 'SET'}</span>
          </div>
          <div class="local-card-stats">
            <span>ATK ${attackValue(participant, card)}</span>
            <span>HP ${toNumber(card.health, 0)}</span>
            <span>DEF ${cardDefense(card)}</span>
          </div>
          <div class="local-card-minirow">${compactFamilies || '<span class="local-family-chip compact">Neutral</span>'}</div>
          <div class="local-card-minirow">${compactBadges || `<span class="local-keyword-chip muted compact">${normalizeCardType(card).slice(0, 3).toUpperCase()}</span>`}</div>
        </div>
      </div>
    </button>`;
  }

  function seatRegionHtml(match, participant, current, perspective, activeTargetKeys = new Set()) {
    const relation = seatIdentityLabel(participant, current, perspective);
    return `<section class="local-seat-region ${seatClass(participant, current, perspective)}" data-seat-role="${participant.perspectiveRole}" data-seat-id="${participant.id}" style="--player-color:${participant.color};">
      <div class="local-seat-region-inner">
        <div class="local-seat-banner">
          <div class="local-seat-name"><span class="local-color-dot" style="background:${participant.color}"></span>${participant.name}</div>
          <div class="local-seat-banner-meta">
            <span class="local-chip">${relation}</span>
            <span class="local-chip">Hand ${participant.hand.length}</span>
            <span class="local-chip">Deck ${participant.deck.length}</span>
          </div>
        </div>
        ${heroPanelHtml(participant, current, perspective, activeTargetKeys)}
        <div class="local-board-grid">${Array.from({ length: 4 }, (_, slotIndex) => boardCardHtml(match, participant, slotIndex, current, perspective, activeTargetKeys)).join('')}</div>
      </div>
    </section>`;
  }

  function hoverPreviewHtml(match = state.localPlayer.match) {
    const preview = state.localPlayer.hoverPreview;
    return `<aside id="local-hover-preview" class="local-hover-preview ${preview?.visible ? '' : 'hidden'}"></aside>`;
  }

  function renderBattle() {
    const host = document.querySelector('#local-player-battle');
    const shell = document.querySelector('#local-player-app');
    if (!host || !shell || !state.localPlayer.match) return;
    const match = state.localPlayer.match;
    const current = currentLocalParticipant(match);
    if (!state.localPlayer.perspectiveSeatId) state.localPlayer.perspectiveSeatId = current?.id ?? null;
    const perspectiveSeatId = state.localPlayer.perspectiveSeatId ?? current?.id ?? null;
    const seats = localSeatSummary(match, perspectiveSeatId);
    const layout = ensureViewLayout(match, perspectiveSeatId);
    const perspective = (match.participants ?? []).find((entry) => entry.id === perspectiveSeatId) ?? current;
    const clickTargets = targetKeys(match);
    const dragTargets = new Set(state.localPlayer.dragState?.targets ?? []);
    const activeTargetKeys = new Set([...clickTargets, ...dragTargets]);
    const handCards = (!match.handoff?.required && perspective?.id === current?.id && current?.controller === 'human')
      ? sortedHandCards(current.hand ?? [], layout)
      : [];
    const boardTransform = `translate(${toNumber(layout?.boardOffset?.x, 0)}px, ${toNumber(layout?.boardOffset?.y, 0)}px) scale(${toNumber(layout?.boardScale, 1)})`;

    host.innerHTML = `
      <div class="local-match-banner"><div class="local-runtime-head"><div><h4>${formatMeta(match.config).label} • ${modeMeta(match.config).label}</h4><div class="meta">Turn ${match.turnNumber} • Active: ${current?.name ?? 'Unknown'} • ${current?.controller === 'ai' ? 'AI resolving' : 'Pass-and-play human turn'}</div></div><div class="local-turn-order">${match.participants.filter((entry) => !entry.eliminated).map((entry, index) => `<button type="button" class="turn-pill ${entry.id === current?.id ? 'active' : ''}" data-local-action="focus-seat" data-seat-id="${entry.id}" style="border-color:${entry.color};">${index + 1}. ${entry.name}</button>`).join('')}</div></div><div class="meta">${match.lastSummary ?? 'Ready.'}</div></div>
      <div class="local-runtime-layout">
        <aside class="local-side-panel">
          <h4>Battle Controls</h4>
          <div class="local-runtime-actions">
            <button data-local-action="fit-layout">Fit Board</button>
            <button data-local-action="focus-current">Focus Current</button>
            <button data-local-action="zoom-out">Zoom -</button>
            <button data-local-action="zoom-in">Zoom +</button>
            <button class="subtle" data-local-action="reset-view">Reset View</button>
          </div>
          <div class="local-banner-note">One shared battlefield, anchored seat regions, one camera. Only the current player's hand is revealed.</div>
          <div class="local-banner-note">Hotkeys: <strong>1-4</strong> focus seats, <strong>Esc</strong> clears selections, <strong>mouse wheel</strong> zooms the arena.</div>
          <div class="local-deck-summary-grid">${(match.deckSummaries ?? []).map((entry) => { const seat = (match.participants ?? []).find((row) => row.id === entry.seatId); return `<div class="local-banner-note"><strong>${seat?.name ?? entry.seatId}</strong><div class="meta">Deck ${entry.summary?.size ?? 0} • Minions ${entry.summary?.minions ?? 0} • Spells ${entry.summary?.spells ?? 0}</div></div>`; }).join('')}</div>
        </aside>
        <section class="local-runtime-arena-shell">
          <div id="local-board-viewport" class="local-board-viewport">
            <div id="local-board-arena" class="local-board-arena" style="transform:${boardTransform};">
              <div class="local-arena-core">
                <div class="local-arena-centerpiece">
                  <div class="local-arena-marking cross"></div>
                  <div class="local-arena-marking ring"></div>
                  <div class="local-arena-marking lanes"></div>
                </div>
              </div>
              ${seats.map((participant) => seatRegionHtml(match, participant, current, perspective, activeTargetKeys)).join('')}
            </div>
            <svg id="local-interaction-layer" class="local-interaction-layer" preserveAspectRatio="none"></svg>
            ${hoverPreviewHtml(match)}
          </div>
          ${match.handoff?.required ? `<div class="local-handoff-overlay" style="background:linear-gradient(160deg, ${current?.color ?? '#6f7cff'}22, rgba(5,9,20,.92));"><div class="local-handoff-card" style="box-shadow:0 0 0 1px ${current?.color ?? '#6f7cff'}88, 0 24px 50px rgba(0,0,0,.48);"><h3>${current?.name ?? 'Player'}</h3><div class="meta">It's your turn. Pass the device, then continue when ready.</div><div class="meta">Turn ${match.turnNumber} • Team ${current?.team ?? 'n/a'}</div><div class="local-actions-row" style="justify-content:center;margin-top:1rem;"><button data-local-action="continue-turn">Continue</button></div></div></div>` : ''}
          ${match.matchOver ? `<div class="local-victory-overlay"><div class="local-victory-card"><h3>${match.winnerSeatIds?.length > 1 ? `Team ${match.winnerTeam} Wins` : `${(match.participants ?? []).find((entry) => entry.id === match.winnerSeatIds?.[0])?.name ?? 'Winner'} Wins`}</h3><div class="meta">Format ${formatMeta(match.config).label} • ${modeMeta(match.config).label} • Turn ${match.turnNumber}</div><div class="local-actions-row" style="justify-content:center;margin-top:1rem;"><button data-local-action="rematch">Rematch</button><button class="subtle" data-local-action="return-setup">Setup</button><button class="subtle" data-local-action="back-title">Title</button></div></div></div>` : ''}
        </section>
        <aside class="local-side-panel">
          <div><h4>Action Feed</h4><div class="meta">${match.lastSummary ?? 'Ready.'}</div></div>
          <div class="local-runtime-card compact">${(match.log ?? []).slice(-8).reverse().map((entry) => `<div class="local-banner-note"><div>${entry.text}</div><div class="meta">${new Date(entry.ts).toLocaleTimeString()}</div></div>`).join('') || '<div class="local-empty-note">No events yet.</div>'}</div>
          <div class="local-runtime-card compact">
            <div class="meta">Click or drag from hand to a lane. Click or drag a ready unit onto a valid target. Right-click any public card or hero to inspect.</div>
            <div class="local-runtime-actions">
              <button data-local-action="cancel-select">Cancel Selection</button>
              <button class="subtle" data-local-action="end-turn" ${canHumanAct(match) ? '' : 'disabled'}>End Turn</button>
            </div>
          </div>
        </aside>
      </div>
      <section class="local-hand-zone">
        <article class="local-runtime-card">
          <div class="local-runtime-head">
            <div><h4>${current?.name ?? 'Active'} Hand</h4><div class="meta">${match.handoff?.required ? 'Hidden until confirmed.' : current?.controller === 'human' ? 'Drag or click a card, then deploy. Attack by dragging or selecting a ready unit.' : 'AI is acting.'}</div></div>
            <div class="local-runtime-actions">
              <button data-local-action="toggle-hand-compact">${layout?.handCompact ? 'Expand Hand' : 'Compact Hand'}</button>
              <button data-local-action="hand-zoom-out">Zoom Out</button>
              <button data-local-action="hand-zoom-in">Zoom In</button>
              <button data-local-action="sort-hand-cost">Sort by Cost</button>
              <button data-local-action="sort-hand-type">Sort by Type</button>
              <button class="subtle" data-local-action="sort-hand-original">Original</button>
              <button class="subtle" data-local-action="inspect-current-hero">Inspect Hero</button>
            </div>
          </div>
          ${match.handoff?.required ? '<div class="local-hidden-hand">Hidden hand. The board view unlocks after the turn handoff is acknowledged.</div>' : handCards.length ? `<div class="local-hand-grid ${handCardClass(layout)}" style="--hand-scale:${toNumber(layout?.handScale, 1)};">${handCards.map((card) => { const families = extractCardRaces(card); const badges = cardKeywordBadges(card); return `<article class="local-hand-card ${handCardClass(layout)} ${state.localPlayer.selectedHandCardId === card.instanceId ? 'selected' : ''}" data-local-action="hand-card" data-card-id="${card.instanceId}" data-local-card-id="${card.instanceId}" data-local-preview="card"><strong>${card.name}</strong><div class="local-card-stats"><span>${normalizeCardType(card)}</span><span>${toNumber(card.cost, 0)} mana</span></div><div class="local-family-row">${families.map((family) => `<span class="local-family-chip">${raceIconGlyph(family)} ${raceMeta(family).label}</span>`).join('') || '<span class="local-family-chip">Neutral</span>'}</div><div class="local-keyword-row">${badges.length ? badges.map((badge) => `<span class="local-keyword-chip ${badge.id}">${badge.label}</span>`).join('') : '<span class="local-keyword-chip muted">No tags</span>'}</div><div class="meta">${card.text || 'No text.'}</div><div class="local-actions-row"><button data-local-action="play-card" data-card-id="${card.instanceId}">${normalizeCardType(card) === 'minion' ? 'Select Lane' : 'Play Now'}</button><button class="subtle" data-local-action="inspect-hand" data-card-id="${card.instanceId}">Inspect</button></div></article>`; }).join('')}</div>` : '<div class="local-empty-note">No visible hand cards for this perspective.</div>'}
        </article>
      </section>`;
    attachBattleHandlers();
    requestAnimationFrame(() => {
      updateHoverPreview(host, match, state.localPlayer.hoverPreview?.visible ? state.localPlayer.hoverPreview : null);
      applyPendingFx(host, match);
    });
  }
  function handleSetupInteraction(target) {
    const action = target.dataset.localAction;
    if (action === 'set-format') updateSetup((draft) => { draft.formatId = target.dataset.localId; });
    else if (action === 'set-mode') updateSetup((draft) => { draft.modeId = target.dataset.localId; });
    else if (action === 'randomize-seats') {
      state.localPlayer.setup = hydrateModeChoices(randomizeSeatOrder(state.localPlayer.setup), getAllCards());
      persistPrefs();
      renderSetup();
    } else if (action === 'quick-ai-fill') quickFillAi();
    else if (action === 'save-preset') savePreset();
    else if (action === 'refresh-seed') {
      refreshSetup(true);
    } else if (action === 'apply-preset') applyPreset(target.dataset.localId);
    else if (action === 'delete-preset') deletePreset(target.dataset.localId);
    else if (action === 'start-match') startMatch();
    else if (action === 'back-title') showTitle();
  }

  function handleSetupField(target) {
    const seatIndex = Number(target.dataset.seatIndex);
    const field = target.dataset.localField;
    if (!Number.isInteger(seatIndex) || !field) return;
    updateSetup((draft) => {
      const slot = draft.slots[seatIndex];
      if (!slot) return;
      if (field === 'enabled') slot.enabled = !!target.checked;
      else if (field === 'name') slot.name = target.value.trim() || `Player ${seatIndex + 1}`;
      else if (field === 'controller') slot.controller = target.value;
      else if (field === 'aiDifficulty') slot.aiDifficulty = target.value;
      else if (field === 'team') slot.team = Number(target.value);
      else if (field === 'selectedChaosId') slot.selectedChaosId = target.value;
      else if (field === 'element0') slot.elements = [target.value, slot.elements?.[1] ?? LOCAL_PLAYER_ELEMENTS[1]];
      else if (field === 'element1') slot.elements = [slot.elements?.[0] ?? LOCAL_PLAYER_ELEMENTS[0], target.value];
      else if (field === 'warband') slot.warband = target.value;
      else if (field === 'stormFocus') slot.stormFocus = target.value;
    });
  }

  function attachSetupHandlers() {
    const host = document.querySelector('#local-player-panel');
    if (!host) return;
    host.onclick = (event) => {
      const target = event.target instanceof Element ? event.target.closest('[data-local-action]') : null;
      if (!target) return;
      handleSetupInteraction(target);
    };
    host.onchange = (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;
      if (!target.dataset.localField) return;
      handleSetupField(target);
    };
  }

  function attachBattleHandlers() {
    const host = document.querySelector('#local-player-battle');
    if (!host) return;
    attachGlobalHotkeys();
    const match = state.localPlayer.match;
    const currentLayout = () => ensureViewLayout(match, state.localPlayer.perspectiveSeatId ?? currentLocalParticipant(match)?.id ?? null);
    const eventId = (event) => (event?.pointerId != null ? event.pointerId : 'mouse');
    const clearDragState = () => {
      const dragState = state.localPlayer.dragState;
      if (dragState?.captureEl instanceof HTMLElement && dragState.pointerId != null && dragState.pointerId !== 'mouse') {
        try { dragState.captureEl.releasePointerCapture(dragState.pointerId); } catch {}
      }
      state.localPlayer.dragState = null;
      destroyDragGhost();
      clearInteractionOverlay(host);
    };
    const pointForNode = (node) => {
      if (!(node instanceof HTMLElement)) return null;
      const rect = node.getBoundingClientRect();
      return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    };
    const startDrag = (pointerEvent, dragState) => {
      state.localPlayer.dragState = dragState;
      if (dragState.captureEl instanceof HTMLElement && dragState.pointerId !== 'mouse') {
        try { dragState.captureEl.setPointerCapture(pointerEvent.pointerId); } catch {}
      }
    };
    const beginPlayDrag = (pointerEvent, handCardEl) => {
      const current = currentLocalParticipant(match);
      if (!canHumanAct(match) || !(handCardEl instanceof HTMLElement)) return false;
      const card = findCard(match, current?.id, handCardEl.dataset.cardId ?? handCardEl.dataset.localCardId);
      if (!card || normalizeCardType(card) !== 'minion') return false;
      pointerEvent.preventDefault();
      pointerEvent.stopPropagation();
      const targets = Array.from({ length: 4 }, (_, slotIndex) => `slot:${current.id}:${slotIndex}`)
        .filter((key) => host.querySelector(`[data-local-drop-key="${key}"]`));
      startDrag(pointerEvent, {
        kind: 'play',
        pointerId: eventId(pointerEvent),
        cardId: card.instanceId,
        ownerId: current.id,
        startX: pointerEvent.clientX,
        startY: pointerEvent.clientY,
        lastX: pointerEvent.clientX,
        lastY: pointerEvent.clientY,
        started: false,
        hoverKey: '',
        targets,
        captureEl: handCardEl,
      });
      return true;
    };
    const beginAttackDrag = (pointerEvent, boardCardEl) => {
      const current = currentLocalParticipant(match);
      if (!canHumanAct(match) || !(boardCardEl instanceof HTMLElement) || boardCardEl.dataset.seatId !== current?.id) return false;
      const card = findCard(match, current?.id, boardCardEl.dataset.cardId);
      if (!card?.canAttack) return false;
      pointerEvent.preventDefault();
      pointerEvent.stopPropagation();
      startDrag(pointerEvent, {
        kind: 'attack',
        pointerId: eventId(pointerEvent),
        cardId: card.instanceId,
        ownerId: current.id,
        startX: pointerEvent.clientX,
        startY: pointerEvent.clientY,
        lastX: pointerEvent.clientX,
        lastY: pointerEvent.clientY,
        started: false,
        hoverKey: '',
        targets: localLegalAttackTargets(match, current.id, card).map((entry) => `${entry.type}:${entry.ownerId}:${entry.cardId ?? 'hero'}`),
        sourcePoint: pointForNode(boardCardEl),
        captureEl: boardCardEl,
      });
      return true;
    };
    const attachDirectPointerHandlers = () => {
      host.querySelectorAll('.local-hand-card').forEach((node) => {
        if (!(node instanceof HTMLElement)) return;
        node.onpointerdown = (event) => {
          beginPlayDrag(event, node);
        };
        node.onmousedown = (event) => {
          if (state.localPlayer.dragState) return;
          beginPlayDrag(event, node);
        };
      });
      host.querySelectorAll('.local-board-card').forEach((node) => {
        if (!(node instanceof HTMLElement)) return;
        node.onpointerdown = (event) => {
          beginAttackDrag(event, node);
        };
        node.onmousedown = (event) => {
          if (state.localPlayer.dragState) return;
          beginAttackDrag(event, node);
        };
      });
    };
    const startSummonFx = (result) => {
      const node = host.querySelector(`[data-card-id="${result?.card?.instanceId}"]`);
      queueBattleFx({ type: 'summon', cardId: result?.card?.instanceId, point: pointForNode(node) });
    };
    const startAttackFx = (attackerId, target) => {
      const node = target?.type === 'hero'
        ? host.querySelector(`[data-local-action="hero"][data-seat-id="${target.ownerId}"]`)
        : host.querySelector(`[data-card-id="${target.cardId}"]`);
      const attackerNode = host.querySelector(`[data-card-id="${attackerId}"]`);
      queueBattleFx({
        type: 'attack',
        attackerId,
        targetType: target?.type,
        targetCardId: target?.cardId ?? null,
        targetSeatId: target?.ownerId ?? null,
        amount: attackerNode ? Number(attackerNode.querySelector('.local-card-stats span')?.textContent?.replace(/\D+/g, '') ?? 0) : 0,
        point: pointForNode(node),
      });
    };

    host.onclick = (event) => {
      if (Date.now() < toNumber(state.localPlayer.suppressClickUntil, 0)) return;
      const target = event.target instanceof Element ? event.target.closest('[data-local-action]') : null;
      if (!target || !match) return;
      const action = target.dataset.localAction;
      const current = currentLocalParticipant(match);
      const perspectiveSeatId = state.localPlayer.perspectiveSeatId ?? current?.id ?? null;
      const viewLayout = ensureViewLayout(match, perspectiveSeatId);
      if (action === 'continue-turn') {
        acknowledgeHandoff(match);
        state.localPlayer.perspectiveSeatId = current?.id ?? state.localPlayer.perspectiveSeatId;
        renderBattle();
        scheduleAiTurn();
      } else if (action === 'zoom-in' && viewLayout) {
        viewLayout.boardScale = Math.min(1.28, toNumber(viewLayout.boardScale, 1) + 0.08);
        renderBattle();
      } else if (action === 'zoom-out' && viewLayout) {
        viewLayout.boardScale = Math.max(0.72, toNumber(viewLayout.boardScale, 1) - 0.08);
        renderBattle();
      } else if (action === 'focus-seat' && target.dataset.seatId) {
        state.localPlayer.perspectiveSeatId = target.dataset.seatId;
        ensureViewLayout(match, state.localPlayer.perspectiveSeatId);
        renderBattle();
      } else if (action === 'reset-view' && viewLayout) {
        resetPerspectiveLayout(match, perspectiveSeatId);
        renderBattle();
      } else if (action === 'fit-layout') {
        resetPerspectiveLayout(match, perspectiveSeatId);
        renderBattle();
      } else if (action === 'focus-current') {
        state.localPlayer.perspectiveSeatId = current?.id ?? state.localPlayer.perspectiveSeatId;
        const focusLayout = ensureViewLayout(match, state.localPlayer.perspectiveSeatId);
        if (focusLayout) {
          focusLayout.boardScale = Math.min(1.16, defaultBoardScaleForSeatCount(liveSeats(match).length) + 0.08);
          focusLayout.boardOffset = { x: 0, y: 56 };
        }
        renderBattle();
      } else if (action === 'toggle-hand-compact' && viewLayout) {
        viewLayout.handCompact = !viewLayout.handCompact;
        renderBattle();
      } else if (action === 'hand-zoom-in' && viewLayout) {
        viewLayout.handScale = Math.min(1.32, toNumber(viewLayout.handScale, 1) + 0.08);
        renderBattle();
      } else if (action === 'hand-zoom-out' && viewLayout) {
        viewLayout.handScale = Math.max(0.82, toNumber(viewLayout.handScale, 1) - 0.08);
        renderBattle();
      } else if (action === 'sort-hand-cost' && viewLayout) {
        viewLayout.handSort = 'cost';
        renderBattle();
      } else if (action === 'sort-hand-type' && viewLayout) {
        viewLayout.handSort = 'type';
        renderBattle();
      } else if (action === 'sort-hand-original' && viewLayout) {
        viewLayout.handSort = 'original';
        renderBattle();
      } else if (action === 'cancel-select') {
        clearDragState();
        resetSelections();
        renderBattle();
      } else if (action === 'end-turn' && canHumanAct(match)) {
        endLocalTurn(match);
        state.localPlayer.perspectiveSeatId = currentLocalParticipant(match)?.id ?? state.localPlayer.perspectiveSeatId;
        resetSelections();
        clearDragState();
        renderBattle();
        scheduleAiTurn();
      } else if (action === 'rematch') rematch();
      else if (action === 'return-setup') {
        state.localPlayer.match = null;
        state.localPlayer.activeScreen = 'setup';
        resetLayoutState();
        document.querySelector('#local-player-app')?.classList.add('hidden');
        document.querySelector('#local-player-panel')?.classList.remove('hidden');
        renderSetup();
      } else if (action === 'back-title') showTitle();
      else if (action === 'inspect-current-hero' && current) {
        openInspectPanel({ type: 'hero', side: 'player', name: current.name, health: current.heroHealth, maxHealth: current.heroMaxHealth, defense: 0, localFamiliaritySummary: participantFamiliarity(current) });
      } else if ((action === 'play-card' || action === 'hand-card') && canHumanAct(match)) {
        const card = findCard(match, current?.id, target.dataset.cardId ?? target.dataset.localCardId);
        if (!card) return;
        if (normalizeCardType(card) === 'minion') {
          state.localPlayer.selectedHandCardId = state.localPlayer.selectedHandCardId === card.instanceId ? null : card.instanceId;
          state.localPlayer.selectedAttackerId = null;
          renderBattle();
        } else if (action === 'play-card') {
          const result = playLocalCard(match, current.id, card.instanceId);
          if (!result.ok) {
            toast(`Cannot play ${card.name}: ${reasonLabel(result.reason)}`, 'error');
            queueBattleFx({ type: 'invalid', text: reasonLabel(result.reason), point: { x: event.clientX, y: event.clientY } });
            applyPendingFx(host, match);
          } else {
            resetSelections();
            renderBattle();
            requestAnimationFrame(() => {
              startSummonFx(result);
              applyPendingFx(host, match);
            });
            scheduleAiTurn();
          }
        }
      } else if (action === 'inspect-hand') {
        const card = findCard(match, current?.id, target.dataset.cardId);
        if (card) openInspectPanel({ type: 'hand-card', card, side: 'player', localFamiliaritySummary: participantFamiliarity(current, card) });
      } else if (action === 'slot' && canHumanAct(match)) {
        const card = selectedHandCard(match);
        if (!card || normalizeCardType(card) !== 'minion' || target.dataset.seatId !== current?.id) return;
        const result = playLocalCard(match, current.id, card.instanceId, Number(target.dataset.slot));
        if (!result.ok) {
          toast(`Cannot play ${card.name}: ${reasonLabel(result.reason)}`, 'error');
          queueBattleFx({ type: 'invalid', text: reasonLabel(result.reason), point: { x: event.clientX, y: event.clientY } });
          applyPendingFx(host, match);
        } else {
          resetSelections();
          renderBattle();
          requestAnimationFrame(() => {
            startSummonFx(result);
            applyPendingFx(host, match);
          });
          scheduleAiTurn();
        }
      } else if (action === 'board-card') {
        const ownerId = target.dataset.seatId;
        const cardId = target.dataset.cardId;
        const card = findCard(match, ownerId, cardId);
        if (!card) return;
        if (canHumanAct(match) && ownerId === current?.id) {
          if (state.localPlayer.selectedHandCardId) {
            resetSelections();
            renderBattle();
          } else if (card.canAttack) {
            state.localPlayer.selectedAttackerId = state.localPlayer.selectedAttackerId === cardId ? null : cardId;
            renderBattle();
          } else {
            toast(reasonLabel('exhausted'), 'error');
          }
        } else if (canHumanAct(match) && state.localPlayer.selectedAttackerId && ownerId !== current?.id) {
          const result = localAttack(match, current.id, state.localPlayer.selectedAttackerId, { type: 'unit', ownerId, cardId });
          if (!result.ok) {
            toast(`Attack failed: ${reasonLabel(result.reason)}`, 'error');
            queueBattleFx({ type: 'invalid', text: reasonLabel(result.reason), point: { x: event.clientX, y: event.clientY } });
            applyPendingFx(host, match);
          } else {
            const attackerId = state.localPlayer.selectedAttackerId;
            resetSelections();
            renderBattle();
            requestAnimationFrame(() => {
              startAttackFx(attackerId, { type: 'unit', ownerId, cardId });
              applyPendingFx(host, match);
            });
            scheduleAiTurn();
          }
        }
      } else if (action === 'hero' && canHumanAct(match) && state.localPlayer.selectedAttackerId && target.dataset.seatId !== current?.id) {
        const result = localAttack(match, current.id, state.localPlayer.selectedAttackerId, { type: 'hero', ownerId: target.dataset.seatId, cardId: null });
        if (!result.ok) {
          toast(`Attack failed: ${reasonLabel(result.reason)}`, 'error');
          queueBattleFx({ type: 'invalid', text: reasonLabel(result.reason), point: { x: event.clientX, y: event.clientY } });
          applyPendingFx(host, match);
        } else {
          const attackerId = state.localPlayer.selectedAttackerId;
          resetSelections();
          renderBattle();
          requestAnimationFrame(() => {
            startAttackFx(attackerId, { type: 'hero', ownerId: target.dataset.seatId, cardId: null });
            applyPendingFx(host, match);
          });
          scheduleAiTurn();
        }
      }
    };

    host.oncontextmenu = (event) => {
      const target = event.target instanceof Element ? event.target.closest('[data-local-action]') : null;
      if (!target || !match) return;
      event.preventDefault();
      const perspectiveSeatId = state.localPlayer.perspectiveSeatId ?? currentLocalParticipant(match)?.id ?? null;
      if (target.dataset.localAction === 'board-card') {
        const participant = (match.participants ?? []).find((entry) => entry.id === target.dataset.seatId);
        const card = findCard(match, target.dataset.seatId, target.dataset.cardId);
        if (participant && card) openInspectPanel({ type: 'board-minion', minion: card, side: target.dataset.seatId === perspectiveSeatId ? 'player' : 'enemy', localFamiliaritySummary: participantFamiliarity(participant, card) });
      } else if (target.dataset.localAction === 'hero') {
        const participant = (match.participants ?? []).find((entry) => entry.id === target.dataset.seatId);
        if (participant) openInspectPanel({ type: 'hero', side: participant.id === perspectiveSeatId ? 'player' : 'enemy', name: participant.name, health: participant.heroHealth, maxHealth: participant.heroMaxHealth, defense: 0, localFamiliaritySummary: participantFamiliarity(participant) });
      }
    };
    host.ondragstart = (event) => event.preventDefault();

    const viewport = host.querySelector('#local-board-viewport');
    if (!viewport) return;
    attachDirectPointerHandlers();
    viewport.onwheel = (event) => {
      event.preventDefault();
      const viewLayout = currentLayout();
      if (!viewLayout) return;
      viewLayout.boardScale = Math.max(0.72, Math.min(1.28, toNumber(viewLayout.boardScale, 1) + (event.deltaY < 0 ? 0.08 : -0.08)));
      renderBattle();
    };
    const startBoardPan = (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (!target || !match) return;
      const viewLayout = currentLayout();
      const boardBackground = target.closest('#local-board-viewport');
      if (boardBackground && !target.closest('button, input, select, textarea') && viewLayout) {
        event.preventDefault();
        state.localPlayer.boardDrag = {
          pointerId: eventId(event),
          startX: event.clientX,
          startY: event.clientY,
          originX: toNumber(viewLayout.boardOffset?.x, 0),
          originY: toNumber(viewLayout.boardOffset?.y, 0),
          captureEl: viewport,
        };
        viewport.classList.add('dragging');
        if (event.pointerId != null) {
          try { viewport.setPointerCapture(event.pointerId); } catch {}
        }
      }
    };
    host.onpointerdown = startBoardPan;
    host.onmousedown = (event) => {
      if (state.localPlayer.dragState) return;
      startBoardPan(event);
    };
    const handleMove = (event) => {
      const viewLayout = currentLayout();
      const drag = state.localPlayer.dragState;
      if (drag && drag.pointerId === eventId(event)) {
        drag.lastX = event.clientX;
        drag.lastY = event.clientY;
        const distance = Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY);
        if (!drag.started && distance > 8) {
          drag.started = true;
          const sourceOwner = (match.participants ?? []).find((entry) => entry.id === drag.ownerId);
          const sourceCard = findCard(match, drag.ownerId, drag.cardId);
          buildDragGhost(sourceCard ?? {}, sourceOwner?.color ?? '#7aa2ff');
          highlightDropTargets(host, drag.targets);
        }
        if (!drag.started) return;
        moveDragGhost(event.clientX, event.clientY);
        const hoverKey = dropKeyAtPoint(host, event.clientX, event.clientY, drag.targets);
        drag.hoverKey = hoverKey;
        setHoverDropTarget(host, hoverKey);
        if (drag.kind === 'attack') {
          const hoverTarget = hoverKey ? host.querySelector(`[data-local-drop-key="${hoverKey}"]`) : null;
          const hoverPoint = hoverTarget instanceof HTMLElement ? pointForNode(hoverTarget) : { x: event.clientX, y: event.clientY };
          const sourceOwner = (match.participants ?? []).find((entry) => entry.id === drag.ownerId);
          drawInteractionLine(host, drag.sourcePoint, hoverPoint, sourceOwner?.color ?? '#ff8f8f');
        }
        return;
      }
      const boardDrag = state.localPlayer.boardDrag;
      if (boardDrag && boardDrag.pointerId === eventId(event) && viewLayout) {
        viewLayout.boardOffset = { x: boardDrag.originX + (event.clientX - boardDrag.startX), y: boardDrag.originY + (event.clientY - boardDrag.startY) };
        const arena = host.querySelector('#local-board-arena');
        if (arena) arena.style.transform = `translate(${toNumber(viewLayout.boardOffset?.x, 0)}px, ${toNumber(viewLayout.boardOffset?.y, 0)}px) scale(${toNumber(viewLayout.boardScale, 1)})`;
        return;
      }
      const previewTarget = event.target instanceof Element ? event.target.closest('[data-local-preview]') : null;
      if (!previewTarget || match.handoff?.required) {
        updateHoverPreview(host, match, null);
        return;
      }
      if (previewTarget.classList.contains('local-board-card')) {
        updateHoverPreview(host, match, {
          visible: true,
          kind: 'card',
          seatId: previewTarget.getAttribute('data-seat-id'),
          cardId: previewTarget.getAttribute('data-card-id'),
          x: event.clientX + 18,
          y: event.clientY + 18,
        });
      } else if (previewTarget.classList.contains('local-hero-panel')) {
        updateHoverPreview(host, match, {
          visible: true,
          kind: 'hero',
          seatId: previewTarget.getAttribute('data-seat-id'),
          x: event.clientX + 18,
          y: event.clientY + 18,
        });
      } else if (previewTarget.classList.contains('local-hand-card')) {
        updateHoverPreview(host, match, {
          visible: true,
          kind: 'card',
          seatId: currentLocalParticipant(match)?.id,
          cardId: previewTarget.getAttribute('data-card-id'),
          x: event.clientX + 18,
          y: event.clientY + 18,
        });
      }
      const selected = selectedAttacker(match);
      if (selected && canHumanAct(match)) {
        const current = currentLocalParticipant(match);
        const legal = new Set(localLegalAttackTargets(match, current?.id, selected).map((entry) => `${entry.type}:${entry.ownerId}:${entry.cardId ?? 'hero'}`));
        const targetNode = previewTarget instanceof Element ? previewTarget.closest('[data-local-drop-key]') : null;
        const hoverKey = targetNode?.getAttribute?.('data-local-drop-key') ?? '';
        if (hoverKey && legal.has(hoverKey)) {
          const attackerNode = host.querySelector(`[data-card-id="${selected.instanceId}"]`);
          const sourcePoint = pointForNode(attackerNode);
          const hoverPoint = pointForNode(targetNode);
          setHoverDropTarget(host, hoverKey);
          drawInteractionLine(host, sourcePoint, hoverPoint, current?.color ?? '#8fd4ff');
        } else {
          clearInteractionLine(host);
        }
      } else if (state.localPlayer.selectedHandCardId && canHumanAct(match)) {
        const targetNode = previewTarget instanceof Element ? previewTarget.closest('.local-slot[data-local-drop-key]') : null;
        setHoverDropTarget(host, targetNode?.getAttribute?.('data-local-drop-key') ?? '');
        const layer = host.querySelector('#local-interaction-layer');
        if (layer) layer.innerHTML = '';
      } else {
        clearInteractionLine(host);
      }
    };
    host.onpointermove = handleMove;
    host.onmousemove = (event) => {
      if (!state.localPlayer.dragState && !state.localPlayer.boardDrag && !(event.target instanceof Element && event.target.closest('[data-local-preview]'))) return;
      handleMove(event);
    };
    const handleEnd = (event) => {
      const drag = state.localPlayer.dragState;
      if (drag && drag.pointerId === eventId(event)) {
        const current = currentLocalParticipant(match);
        const validKey = dropKeyAtPoint(host, event.clientX, event.clientY, drag.targets) || drag.hoverKey || '';
        const started = drag.started || Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY) > 8;
        clearDragState();
        state.localPlayer.suppressClickUntil = Date.now() + (started ? 180 : 0);
        if (started && canHumanAct(match)) {
          if (drag.kind === 'play' && validKey) {
            const [, seatId, slotText] = validKey.split(':');
            const result = playLocalCard(match, current.id, drag.cardId, Number(slotText));
            if (!result.ok) {
              toast(`Cannot play card: ${reasonLabel(result.reason)}`, 'error');
              queueBattleFx({ type: 'invalid', text: reasonLabel(result.reason), point: { x: event.clientX, y: event.clientY } });
              applyPendingFx(host, match);
            } else {
              resetSelections();
              renderBattle();
              requestAnimationFrame(() => {
                startSummonFx(result);
                applyPendingFx(host, match);
              });
              scheduleAiTurn();
            }
          } else if (drag.kind === 'attack' && validKey) {
            const [targetType, ownerId, cardId] = validKey.split(':');
            const payload = { type: targetType === 'unit' ? 'unit' : 'hero', ownerId, cardId: cardId === 'hero' ? null : cardId };
            const result = localAttack(match, current.id, drag.cardId, payload);
            if (!result.ok) {
              toast(`Attack failed: ${reasonLabel(result.reason)}`, 'error');
              queueBattleFx({ type: 'invalid', text: reasonLabel(result.reason), point: { x: event.clientX, y: event.clientY } });
              applyPendingFx(host, match);
            } else {
              resetSelections();
              renderBattle();
              requestAnimationFrame(() => {
                startAttackFx(drag.cardId, payload);
                applyPendingFx(host, match);
              });
              scheduleAiTurn();
            }
          } else {
            queueBattleFx({ type: 'invalid', text: drag.kind === 'attack' ? 'Invalid target' : 'No legal lane', point: { x: event.clientX, y: event.clientY } });
            applyPendingFx(host, match);
          }
        }
        return;
      }
      const boardDrag = state.localPlayer.boardDrag;
      if (boardDrag?.pointerId === eventId(event)) {
        state.localPlayer.boardDrag = null;
        viewport.classList.remove('dragging');
        if (event.pointerId != null) {
          try { viewport.releasePointerCapture(event.pointerId); } catch {}
        }
      }
    };
    host.onpointerup = handleEnd;
    host.onpointercancel = handleEnd;
    host.onmouseup = handleEnd;
    host.onpointerleave = () => {
      if (!state.localPlayer.dragState) {
        updateHoverPreview(host, match, null);
        clearInteractionLine(host);
      }
    };
  }

  function attachGlobalHotkeys() {
    if (globalHotkeysAttached) return;
    globalHotkeysAttached = true;
    window.addEventListener('keydown', (event) => {
      if (state.localPlayer.activeScreen !== 'battle' || !state.localPlayer.match) return;
      const tag = event.target instanceof HTMLElement ? event.target.tagName : '';
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) return;
      if (event.key === 'Escape') {
        resetSelections();
        state.localPlayer.hoverPreview = null;
        renderBattle();
        return;
      }
      if (!/^[1-4]$/.test(event.key)) return;
      const seatIndex = Number(event.key) - 1;
      const participant = (state.localPlayer.match.participants ?? []).filter((entry) => !entry.eliminated)[seatIndex];
      if (!participant) return;
      state.localPlayer.perspectiveSeatId = participant.id;
      ensureViewLayout(state.localPlayer.match, participant.id);
      renderBattle();
    });
  }

  function isActive() {
    return !document.querySelector('#local-player-panel')?.classList.contains('hidden') || !document.querySelector('#local-player-app')?.classList.contains('hidden');
  }

  function textState() {
    return state.localPlayer.match ? localMatchToText(state.localPlayer.match, state.localPlayer.perspectiveSeatId ?? currentLocalParticipant(state.localPlayer.match)?.id ?? null) : null;
  }

  function advanceTime() {
    if (state.localPlayer.match && !state.localPlayer.match.matchOver && currentLocalParticipant(state.localPlayer.match)?.controller === 'ai') scheduleAiTurn();
    if (state.localPlayer.activeScreen === 'battle') renderBattle();
    else if (state.localPlayer.activeScreen === 'setup') renderSetup();
  }

  return { ensureReady, openSetup, renderSetup, renderBattle, showTitle, startMatch, rematch, isActive, textState, advanceTime, attachSetupHandlers, attachBattleHandlers };
}
