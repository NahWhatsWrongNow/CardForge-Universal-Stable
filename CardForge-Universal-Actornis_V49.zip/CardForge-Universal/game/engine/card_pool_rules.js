function normalizeList(value = '') {
  return String(value ?? '')
    .split(/[|,]/)
    .map((entry) => String(entry ?? '').trim().toLowerCase())
    .filter(Boolean);
}

function lowerTags(card = {}) {
  return Array.isArray(card?.tags) ? card.tags.map((tag) => String(tag ?? '').trim().toLowerCase()).filter(Boolean) : [];
}

function lowerType(card = {}) {
  return String(card?.type ?? '').trim().toLowerCase();
}

function lowerCompat(card = {}) {
  return String(card?.battleCompatibility ?? card?.campaignMeta?.battleCompatibility ?? card?.mtgMeta?.battleCompatibility ?? '').trim().toLowerCase();
}

export function requiredModesForCard(card = {}) {
  return normalizeList(card?.requiredModes ?? card?.campaignMeta?.requiredModes ?? card?.mtgMeta?.requiredModes ?? '');
}

export function isLocalExclusiveCard(card = {}) {
  if (!!card?.localExclusive) return true;
  const tags = lowerTags(card);
  if (tags.includes('local-exclusive') || tags.includes('local-player-exclusive')) return true;
  return requiredModesForCard(card).some((entry) => entry === 'local-player' || entry === 'local_player' || entry === 'local multiplayer');
}

export function isConquestOnlyCard(card = {}) {
  const tags = lowerTags(card);
  const type = lowerType(card);
  const compat = lowerCompat(card);
  const mode = String(card?.mode ?? '').trim().toLowerCase();
  const requiredModes = requiredModesForCard(card);
  const conquestOnlyTypes = new Set(['unit', 'building', 'facility', 'turret', 'barricade', 'equipment', 'upgrade', 'tactic', 'support']);
  return mode === 'conquest'
    || compat === 'defense_only'
    || conquestOnlyTypes.has(type)
    || tags.includes('conquest')
    || tags.includes('conquest-only')
    || requiredModes.some((entry) => entry.includes('conquest') || entry.includes('defense'));
}

export function isNormalModePoolCard(card = {}) {
  return !isConquestOnlyCard(card) && !isLocalExclusiveCard(card);
}

export function isLocalMultiplayerPoolCard(card = {}) {
  return !isConquestOnlyCard(card) && (isNormalModePoolCard(card) || isLocalExclusiveCard(card));
}
