const STORAGE_KEY = 'cardforge.profile.v1';
const WORLD_KEY = 'cardforge.world.seed.v1';
const MATCH_KEY = 'cardforge.match.opponent.v1';
const MATCH_CONTEXT_KEY = 'cardforge.match.context.v1';
const MATCH_RESULT_KEY = 'cardforge.match.result.v1';
const CUSTOM_CARD_LIBRARY_KEY = 'cardforge.creator.customCards.v1';
const LOCAL_MODE = window.location.protocol === 'file:';

const LOCAL_DATA = {
  aiIndex: { entries: [] },
  quests: { quests: [{ id: 'local-win', goal: 'Win 1 match', metric: 'wins', target: 1, reward: 120 }] },
  store: {
    products: [
      {
        id: 'local-pack',
        name: 'Local Starter Pack',
        price: 60,
        count: 10,
        description: 'Fallback local pack.',
      },
      {
        id: 'gen4-pack',
        name: 'GEN4 Booster Pack',
        description: '20 GEN4 cards from the Volcanic Ash and other Gen 4 world collections.',
        price: 320,
        count: 20,
        poolTag: 'GEN4',
        weights: { common: 0.52, rare: 0.32, epic: 0.12, legendary: 0.04 },
        pity: { threshold: 3, rarity: 'epic' },
      },
    ],
  },
  decks: {
    decks: [
      {
        id: 'local-balanced',
        name: 'Local Balanced',
        entries: [
          { cardId: 'local-ember-apprentice', count: 10 },
          { cardId: 'local-ward-guardian', count: 10 },
          { cardId: 'local-rift-scout', count: 10 },
        ],
      },
    ],
  },
  cardex: {
    updatedAt: 'local',
    count: 3,
    cards: [
      { id: 'local-ember-apprentice', name: 'Ember Apprentice', type: 'minion', cost: 1, attack: 2, health: 1, race: 'mage', element: 'fire', rarity: 'common', tags: ['starter'] },
      { id: 'local-ward-guardian', name: 'Ward Guardian', type: 'minion', cost: 2, attack: 2, health: 3, race: 'guardian', element: 'light', rarity: 'rare', tags: ['starter'] },
      { id: 'local-rift-scout', name: 'Rift Scout', type: 'minion', cost: 1, attack: 1, health: 2, race: 'scout', element: 'arcane', rarity: 'common', tags: ['starter'] },
    ],
  },
  aiProfiles: [
    {
      id: 'local-initiate',
      name: 'Mira Vale',
      level: 2,
      deck: [{ name: 'Ember Acolyte', attack: 2, health: 1 }, { name: 'Ward Sentry', attack: 1, health: 3, taunt: true }],
      personality: { title: 'Dimensional Initiate', dimensionTag: '#Aster-2', backstory: 'A careful duelist from the Prism lanes.' },
    },
    {
      id: 'local-sentinel',
      name: 'Gregory Of Oltine',
      level: 5,
      deck: [{ name: 'Oltine Bulwark', attack: 2, health: 4, taunt: true }, { name: 'Rift Lancer', attack: 4, health: 2 }],
      personality: { title: 'Oltine Sentinel', dimensionTag: '#Oltine-Prime', backstory: 'A tactical veteran who defends the fracture gates.' },
    },
  ],
  loadingTips: [
    { id: 'local-tip-1', title: 'Local Primer', subtitle: 'Formation', flavor: 'A clean eight-slot formation beats a messy high-roll.', gameplayTip: 'Keep one slot open into reactive decks.', faction: 'neutral' },
  ],
};

const dom = {
  lobbyPanel: document.getElementById('lobby-panel'),
  openLobby: document.getElementById('open-lobby'),
  continueGameBtn: document.getElementById('continue-game-btn'),
  newGameBtn: document.getElementById('new-game-btn'),
  openStatsBtn: document.getElementById('open-stats-btn'),
  newGamePanel: document.getElementById('new-game-panel'),
  confirmNewGameBtn: document.getElementById('confirm-new-game-btn'),
  cancelNewGameBtn: document.getElementById('cancel-new-game-btn'),
  profileQuickStats: document.getElementById('profile-quick-stats'),
  loadingPanel: document.getElementById('loading-panel'),
  loadingFiles: document.getElementById('loading-files'),
  battlemapPanel: document.getElementById('battlemap-panel'),
  battlemapShell: document.getElementById('battlemap-shell'),
  mapStage: document.getElementById('map-stage'),
  mapSvg: document.getElementById('dimension-map'),
  mapPanzoomRoot: document.getElementById('map-panzoom-root'),
  mapBoundaryLayer: document.getElementById('map-boundary-layer'),
  mapRoutesLayer: document.getElementById('map-routes-layer'),
  mapRoamersLayer: document.getElementById('map-roamers-layer'),
  mapNodesLayer: document.getElementById('map-nodes-layer'),
  mapEffectsCanvas: document.getElementById('map-effects-canvas'),
  mapStyleSelect: document.getElementById('map-style-select'),
  mapNodeSearch: document.getElementById('map-node-search'),
  mapStatusFilter: document.getElementById('map-status-filter'),
  mapStyleFilter: document.getElementById('map-style-filter'),
  mapLegend: document.getElementById('map-legend'),
  mapCenterSelectedBtn: document.getElementById('map-center-selected-btn'),
  mapResetViewBtn: document.getElementById('map-reset-view-btn'),
  mapExpandToggle: document.getElementById('map-expand-toggle'),
  findGatewayBtn: document.getElementById('find-gateway-btn'),
  openGalaxyCreatorBtn: document.getElementById('open-galaxy-creator-btn'),
  openAiEditorBtn: document.getElementById('open-ai-editor-btn'),
  modalBackdrop: document.getElementById('map-modal-backdrop'),
  gatewayModal: document.getElementById('gateway-modal'),
  gatewaySeedInput: document.getElementById('gateway-seed-input'),
  gatewaySeedMode: document.getElementById('gateway-seed-mode'),
  gatewayAutoSeedBtn: document.getElementById('gateway-auto-seed-btn'),
  gatewayCopySeedBtn: document.getElementById('gateway-copy-seed-btn'),
  gatewayImportBtn: document.getElementById('gateway-import-btn'),
  gatewayFeedback: document.getElementById('gateway-modal-feedback'),
  galaxyCreatorModal: document.getElementById('galaxy-creator-modal'),
  galaxyCreatorForm: document.getElementById('galaxy-creator-form'),
  galaxyStyleSelect: document.getElementById('galaxy-style-select'),
  galaxySeedFromNameBtn: document.getElementById('galaxy-seed-from-name-btn'),
  galaxySaveBtn: document.getElementById('galaxy-save-btn'),
  galaxyExportBtn: document.getElementById('galaxy-export-btn'),
  galaxyImportBtn: document.getElementById('galaxy-import-btn'),
  galaxyImportExport: document.getElementById('galaxy-import-export'),
  galaxyCreatorFeedback: document.getElementById('galaxy-creator-feedback'),
  aiEditorModal: document.getElementById('ai-editor-modal'),
  aiEditorForm: document.getElementById('ai-editor-form'),
  aiStyleSelect: document.getElementById('ai-style-select'),
  aiGalaxySearch: document.getElementById('ai-galaxy-search'),
  aiAssignedGalaxySelect: document.getElementById('ai-assigned-galaxy-select'),
  aiPackSelect: document.getElementById('ai-pack-select'),
  aiSaveBtn: document.getElementById('ai-save-btn'),
  aiUnassignBtn: document.getElementById('ai-unassign-btn'),
  aiExportBtn: document.getElementById('ai-export-btn'),
  aiImportBtn: document.getElementById('ai-import-btn'),
  aiPreviewLineBtn: document.getElementById('ai-preview-line-btn'),
  aiImportExport: document.getElementById('ai-import-export'),
  aiEditorFeedback: document.getElementById('ai-editor-feedback'),
  threatInspectModal: document.getElementById('threat-inspect-modal'),
  threatInspectBody: document.getElementById('threat-inspect-body'),
  threatInspectBattleBtn: document.getElementById('threat-inspect-battle-btn'),
  threatInspectCenterBtn: document.getElementById('threat-inspect-center-btn'),
  conquestModal: document.getElementById('conquest-modal'),
  conquestWorldMeta: document.getElementById('conquest-world-meta'),
  conquestMeterFill: document.getElementById('conquest-meter-fill'),
  conquestMeterText: document.getElementById('conquest-meter-text'),
  conquestPlanetList: document.getElementById('conquest-planet-list'),
  conquestObjectiveList: document.getElementById('conquest-objective-list'),
  conquestObjectiveDetail: document.getElementById('conquest-objective-detail'),
  conquestBattleBtn: document.getElementById('conquest-battle-btn'),
  conquestFacilityBtn: document.getElementById('conquest-facility-btn'),
  conquestDeckEditorBtn: document.getElementById('conquest-deck-editor-btn'),
  conquestCardCreatorBtn: document.getElementById('conquest-card-creator-btn'),
  conquestWorldOpsBtn: document.getElementById('conquest-world-ops-btn'),
  worldManagementModal: document.getElementById('world-management-modal'),
  worldOpsHeader: document.getElementById('world-ops-header'),
  worldOpsPlanetSelect: document.getElementById('world-ops-planet-select'),
  worldOpsPlanetMeta: document.getElementById('world-ops-planet-meta'),
  worldOpsBuildings: document.getElementById('world-ops-buildings'),
  worldOpsFactoryType: document.getElementById('world-ops-factory-type'),
  worldOpsProduceCount: document.getElementById('world-ops-produce-count'),
  worldOpsProduceCards: document.getElementById('world-ops-produce-cards'),
  worldOpsBuildBtn: document.getElementById('world-ops-build-btn'),
  worldOpsProduceBtn: document.getElementById('world-ops-produce-btn'),
  worldOpsFacilityBtn: document.getElementById('world-ops-facility-btn'),
  worldOpsDeckEditorBtn: document.getElementById('world-ops-deck-editor-btn'),
  worldOpsCardCreatorBtn: document.getElementById('world-ops-card-creator-btn'),
  worldOpsFeedback: document.getElementById('world-ops-feedback'),
  facilityWarModal: document.getElementById('facility-war-modal'),
  facilityWarHeader: document.getElementById('facility-war-header'),
  facilityDevCommandInput: document.getElementById('facility-dev-command-input'),
  facilityDevCommandRun: document.getElementById('facility-dev-command-run'),
  facilityDevSuite: document.getElementById('facility-dev-suite'),
  facilityGridSizeLabel: document.getElementById('facility-grid-size-label'),
  facilityFitBoardBtn: document.getElementById('facility-fit-board-btn'),
  facilityFocusBoardBtn: document.getElementById('facility-focus-board-btn'),
  facilityZoomInBtn: document.getElementById('facility-zoom-in-btn'),
  facilityZoomOutBtn: document.getElementById('facility-zoom-out-btn'),
  facilityResetBoardBtn: document.getElementById('facility-reset-board-btn'),
  facilityHeatmapToggleBtn: document.getElementById('facility-heatmap-toggle-btn'),
  facilityCinematicToggleBtn: document.getElementById('facility-cinematic-toggle-btn'),
  facilitySetupPresetSelect: document.getElementById('facility-setup-preset-select'),
  facilitySaveSetupBtn: document.getElementById('facility-save-setup-btn'),
  facilityLoadSetupBtn: document.getElementById('facility-load-setup-btn'),
  facilityBattleStatusChips: document.getElementById('facility-battle-status-chips'),
  facilityHeatmapLegend: document.getElementById('facility-heatmap-legend'),
  facilityLaneControl: document.getElementById('facility-lane-control'),
  facilityWarResources: document.getElementById('facility-war-resources'),
  facilityWarEffectsCanvas: document.getElementById('facility-war-effects-canvas'),
  facilityWarGrid: document.getElementById('facility-war-grid'),
  facilityWarDefenderHand: document.getElementById('facility-war-defender-hand'),
  facilityWarHandCount: document.getElementById('facility-war-hand-count'),
  facilityHandCategoryChips: document.getElementById('facility-hand-category-chips'),
  facilityHandExpandBtn: document.getElementById('facility-hand-expand-btn'),
  facilityHandCompactBtn: document.getElementById('facility-hand-compact-btn'),
  facilityHandSortCostBtn: document.getElementById('facility-hand-sort-cost-btn'),
  facilityHandSortTypeBtn: document.getElementById('facility-hand-sort-type-btn'),
  facilityHandSortSourceBtn: document.getElementById('facility-hand-sort-source-btn'),
  facilityWarAttackerInfo: document.getElementById('facility-war-attacker-info'),
  facilityWarLog: document.getElementById('facility-war-log'),
  facilityLogGroupBtn: document.getElementById('facility-log-group-btn'),
  facilityWarSelectedCard: document.getElementById('facility-war-selected-card'),
  facilityWarCompareCard: document.getElementById('facility-war-compare-card'),
  facilityInspectPinBtn: document.getElementById('facility-inspect-pin-btn'),
  facilityInspectCompareBtn: document.getElementById('facility-inspect-compare-btn'),
  facilityInspectPrevBtn: document.getElementById('facility-inspect-prev-btn'),
  facilityInspectNextBtn: document.getElementById('facility-inspect-next-btn'),
  facilityDrawTrainingBtn: document.getElementById('facility-draw-training-btn'),
  facilityDrawFactoryBtn: document.getElementById('facility-draw-factory-btn'),
  facilityDrawBlacksmithBtn: document.getElementById('facility-draw-blacksmith-btn'),
  facilityDrawCommandBtn: document.getElementById('facility-draw-command-btn'),
  facilityDrawVehicleBtn: document.getElementById('facility-draw-vehicle-btn'),
  facilityDrawOrdnanceBtn: document.getElementById('facility-draw-ordnance-btn'),
  facilityDrawAirBtn: document.getElementById('facility-draw-air-btn'),
  facilityDrawPowerBtn: document.getElementById('facility-draw-power-btn'),
  facilityDrawRecoveryBtn: document.getElementById('facility-draw-recovery-btn'),
  facilityDrawExperimentalBtn: document.getElementById('facility-draw-experimental-btn'),
  facilityWarAttackBtn: document.getElementById('facility-war-attack-btn'),
  facilityWarDeconstructBtn: document.getElementById('facility-war-deconstruct-btn'),
  facilityWarEndTurnBtn: document.getElementById('facility-war-end-turn-btn'),
  facilityWarMatSettingsBtn: document.getElementById('facility-war-mat-settings-btn'),
  facilityWarResetBtn: document.getElementById('facility-war-reset-btn'),
  conquestMatSettingsModal: document.getElementById('conquest-mat-settings-modal'),
  conquestMatPresetSelect: document.getElementById('conquest-mat-preset-select'),
  conquestMatTintRange: document.getElementById('conquest-mat-tint-range'),
  conquestMatCustomUrl: document.getElementById('conquest-mat-custom-url'),
  conquestMatUpload: document.getElementById('conquest-mat-upload'),
  conquestMatApplyBtn: document.getElementById('conquest-mat-apply-btn'),
  conquestMatResetBtn: document.getElementById('conquest-mat-reset-btn'),
  conquestDeckEditorModal: document.getElementById('conquest-deck-editor-modal'),
  conquestDeckEditorHeader: document.getElementById('conquest-deck-editor-header'),
  conquestDeckEditorDecks: document.getElementById('conquest-deck-editor-decks'),
  conquestDeckEditorCards: document.getElementById('conquest-deck-editor-cards'),
  conquestDeckEditorLibrary: document.getElementById('conquest-deck-editor-library'),
  conquestDeckEditorSaveBtn: document.getElementById('conquest-deck-editor-save-btn'),
  conquestDeckEditorFeedback: document.getElementById('conquest-deck-editor-feedback'),
  conquestCardCreatorModal: document.getElementById('conquest-card-creator-modal'),
  conquestCardCreatorForm: document.getElementById('conquest-card-creator-form'),
  conquestCardCreateBtn: document.getElementById('conquest-card-create-btn'),
  conquestCardCreatorFeedback: document.getElementById('conquest-card-creator-feedback'),
  systemViewer: document.getElementById('system-viewer'),
  systemViewerBody: document.getElementById('system-viewer-body'),
  viewerModeSplitBtn: document.getElementById('viewer-mode-split'),
  viewerModeVisualBtn: document.getElementById('viewer-mode-visual'),
  viewerModeInfoBtn: document.getElementById('viewer-mode-info'),
  systemFocusBtn: document.getElementById('system-focus-btn'),
  mapHoverCard: document.getElementById('map-hover-card'),
  mapOrbitCanvas: document.getElementById('map-orbit-canvas'),
  invasionPanel: document.getElementById('invasion-panel'),
  invasionStateLabel: document.getElementById('invasion-state-label'),
  warpKeyStatus: document.getElementById('warp-key-status'),
  invasionProgressFill: document.getElementById('invasion-progress-fill'),
  invasionProgressText: document.getElementById('invasion-progress-text'),
  traceProgressFill: document.getElementById('trace-progress-fill'),
  traceProgressText: document.getElementById('trace-progress-text'),
  infamyProgressFill: document.getElementById('infamy-progress-fill'),
  infamyProgressText: document.getElementById('infamy-progress-text'),
  invasionThreatSummary: document.getElementById('invasion-threat-summary'),
  invasionBossWarning: document.getElementById('invasion-boss-warning'),
  scanChallengePanel: document.getElementById('scan-challenge-panel'),
  scanChallengeTitle: document.getElementById('scan-challenge-title'),
  scanChallengeTimer: document.getElementById('scan-challenge-timer'),
  scanChallengeMessage: document.getElementById('scan-challenge-message'),
  scanChallengeTargets: document.getElementById('scan-challenge-targets'),
  scanChallengeBank: document.getElementById('scan-challenge-bank'),
  invasionEventFeed: document.getElementById('invasion-event-feed'),
  pirateDossierList: document.getElementById('pirate-dossier-list'),
  invasionAlienSection: document.getElementById('invasion-alien-section'),
  invasionAlienList: document.getElementById('invasion-alien-list'),
  invasionThreatFilter: document.getElementById('invasion-threat-filter'),
  invasionInterceptBtn: document.getElementById('invasion-intercept-btn'),
  invasionScanBtn: document.getElementById('invasion-scan-btn'),
  invasionWorldOpsBtn: document.getElementById('invasion-world-ops-btn'),
  matchTab: document.getElementById('match-tab'),
  deckTab: document.getElementById('deck-tab'),
  questsTab: document.getElementById('quests-tab'),
  statsTab: document.getElementById('stats-tab'),
  shopTab: document.getElementById('shop-tab'),
  marketTab: document.getElementById('market-tab'),
  carnifexTab: document.getElementById('carnifex-tab'),
  worldTab: document.getElementById('world-tab'),
  cardexMeta: document.getElementById('cardex-meta'),
  cardexList: document.getElementById('cardex-list'),
  cardexSearch: document.getElementById('cardex-search'),
  dimensionInput: document.getElementById('dimension-input'),
  dimensionLocate: document.getElementById('dimension-locate'),
  dimensionCanvas: document.getElementById('dimension-canvas'),
  lobbyRoomCanvas: document.getElementById('lobby-room-canvas'),
  roomHint: document.getElementById('room-hint'),
  dialogLog: document.getElementById('dialog-log'),
  dialogChoices: document.getElementById('dialog-choices'),
  talkNearby: document.getElementById('talk-nearby'),
  captureTarget: document.getElementById('capture-target'),
  startCapture: document.getElementById('start-capture'),
  captureFeedback: document.getElementById('capture-feedback'),
  captureStage: document.getElementById('capture-stage'),
  lifeforceMeta: document.getElementById('lifeforce-meta'),
  capturedList: document.getElementById('captured-list'),
  traderOffer: document.getElementById('trader-offer'),
  openMarketHubBtn: document.getElementById('open-market-hub-btn'),
  paywallToggle: document.getElementById('paywall-toggle'),
  idleChatter: document.getElementById('idle-chatter'),
  cinematic: document.getElementById('match-cinematic'),
  cinematicPlayer: document.getElementById('cinematic-player'),
  cinematicOpponent: document.getElementById('cinematic-opponent'),
  cinematicTip: document.getElementById('cinematic-tip'),
  cinematicFlavor: document.getElementById('cinematic-flavor'),
};

let cachedAiProfiles = [];
let cachedDecks = [];
let cachedLoadingTips = [];
let cachedMapStyles = [];
let cachedStarterGalaxies = [];
let cachedCardPacks = [];
let cachedPackCardsById = {};
let cachedPirateMasterPool = [];
let cachedPirateHouses = [];
let cachedAlienFactions = [];
let cachedEventCategories = [];
let cachedModeRulesets = [];
let profileCache = null;
let profileCacheRaw = null;
let mapOrbitHandle = null;
let codexOrbitHandle = null;
let worldRoom = { player: { x: 70, y: 270 }, residents: [] };
let idleChatterTimer = null;
let captureState = null;
let activeDialogAi = null;
const dialogLineMemory = {};
let mapEffectsHandle = null;
let mapEffectsState = null;
let invasionLaunchLock = false;
let facilityWarEffectsHandle = null;
let facilityWarEffectsState = null;
let facilityBoardPanBound = false;
let facilityBoardPanState = null;
let facilityBoardResizeBound = false;
let mapProfilesRef = [];
let lobbyInitPromise = null;
let lobbyLoaded = false;
let scanSelectedTokenId = null;
let conquestCardLookupCache = { key: '', byId: new Map() };
const marketUiState = {
  selectedTraderId: null,
  selectedNodeId: null,
  selectedShipId: null,
  inspectCardId: null,
  playerOffer: {},
  traderOffer: {},
  inventoryQuery: '',
  stockQuery: '',
  excludeFavorites: true,
  excludeDecked: true,
  duplicatesOnly: false,
  pinnedCards: [],
  feedbackMessage: '',
  stockLimit: 72,
  inventoryLimit: 120,
};
const modalUiState = {
  threat: { threatId: null, nodeId: null },
  conquest: { worldId: null, planetId: null, objectiveId: null },
  worldOps: { worldId: null, planetId: null, selectedBuildingId: null, selectedProduceCardId: null },
  facilityWar: {
    worldId: null,
    planetId: null,
    selectedHandCardId: null,
    hoverHandCardId: null,
    inspectCellIndex: null,
    inspectPinned: false,
    compareCellIndex: null,
    selectedUnitCellIndex: null,
    selectedAttackSourceIndex: null,
    dragAttackSourceIndex: null,
    boardViewMode: 'fit',
    boardZoom: 1,
    handViewMode: 'expanded',
    handCategoryFilter: 'all',
    handSort: 'none',
    showHeatmap: false,
    cinematicMode: false,
    setupPresetSlot: 'alpha',
    logGrouped: true,
  },
  conquestDeckEditor: {
    worldId: null,
    planetId: null,
    selectedDeckKey: 'training',
    workingDecks: null,
    libraryQuery: '',
    libraryRoleFilter: 'all',
    librarySort: 'name',
  },
};

const FACILITY_DEV_PANEL_REGISTRY = [
  { id: 'aiPlanner', title: 'AI Planner' },
  { id: 'aiGraphs', title: 'AI Graphs' },
  { id: 'deckViewer', title: 'Deck Viewer' },
  { id: 'deckGraphs', title: 'Deck Graphs' },
  { id: 'conquestDecks', title: 'Conquest Decks' },
  { id: 'economy', title: 'Economy' },
  { id: 'threatMap', title: 'Threat Map' },
  { id: 'ranges', title: 'Range Overlay' },
  { id: 'vfx', title: 'VFX Trace' },
  { id: 'ownership', title: 'Ownership' },
  { id: 'unitTypes', title: 'Unit Types' },
  { id: 'warStats', title: 'War Stats' },
  { id: 'battleStats', title: 'Battle Stats' },
  { id: 'handStats', title: 'Hand Stats' },
  { id: 'turnFlow', title: 'Turn Flow' },
  { id: 'lanePressure', title: 'Lane Pressure' },
  { id: 'structureState', title: 'Structure State' },
  { id: 'homesteadState', title: 'Homestead State' },
  { id: 'debugLog', title: 'Debug Log' },
  { id: 'targeting', title: 'Targeting' },
  { id: 'movement', title: 'Movement' },
  { id: 'actionTrace', title: 'Action Trace' },
];

const FACILITY_DEV_ALIAS = Object.fromEntries(FACILITY_DEV_PANEL_REGISTRY.map((panel) => [panel.id.toLowerCase(), panel.id]));
Object.assign(FACILITY_DEV_ALIAS, {
  aiplanner: 'aiPlanner',
  planner: 'aiPlanner',
  aigraphs: 'aiGraphs',
  graphs: 'aiGraphs',
  deckgraph: 'deckGraphs',
  deckviewer: 'deckViewer',
  battlestats: 'battleStats',
  warstats: 'warStats',
  handstats: 'handStats',
  showeconomy: 'economy',
  showresources: 'economy',
  showfacilitydecks: 'conquestDecks',
  showcellcontrol: 'ownership',
  showownership: 'ownership',
  showthreatmap: 'threatMap',
  showranges: 'ranges',
  showmovement: 'movement',
  showturretrange: 'ranges',
  showhomestead: 'homesteadState',
  showstructures: 'structureState',
  showlanepressure: 'lanePressure',
  showvfx: 'vfx',
  showtags: 'unitTypes',
  showtypes: 'unitTypes',
  aitrace: 'actionTrace',
});

const FACILITY_DEV_GROUPS = {
  all: FACILITY_DEV_PANEL_REGISTRY.map((panel) => panel.id),
  graphs: ['aiGraphs', 'deckGraphs', 'economy', 'battleStats', 'lanePressure'],
  planner: ['aiPlanner', 'actionTrace'],
  decks: ['deckViewer', 'deckGraphs', 'conquestDecks'],
};

const facilityDevUiState = {
  enabled: false,
  visibility: {},
  collapsed: {},
  lastSampleAt: 0,
  metrics: {
    aiTimeline: [],
    economyTimeline: [],
    laneDeltaTimeline: [],
    actionTrace: [],
    lastAiPhase: 'idle',
  },
};

const NODE_INTERACTION_STATES = {
  IDLE: 'idle',
  HOVER: 'hover',
  SELECTED: 'selected',
  FOCUSED: 'focused',
  ANIMATING_IN: 'animating-in',
  OCCUPIED: 'occupied',
  UNOCCUPIED: 'unoccupied',
  DISABLED: 'disabled',
};

const PIRATE_ROLE_DEFS = {
  scout: {
    id: 'scout',
    name: 'Scout Corsair',
    objectiveWeights: { patrol: 0.5, investigate: 0.45, flee: 0.05 },
    detectBonus: 1.3,
    fleeBias: 1.35,
    styleId: 'riftstorm',
    archetype: 'tempo-scout',
  },
  raider: {
    id: 'raider',
    name: 'Raider Brigand',
    objectiveWeights: { patrol: 0.45, investigate: 0.4, flee: 0.15 },
    detectBonus: 0.9,
    fleeBias: 0.85,
    styleId: 'solar-dominion',
    archetype: 'aggro-pressure',
  },
  smuggler: {
    id: 'smuggler',
    name: 'Rift Smuggler',
    objectiveWeights: { patrol: 0.35, investigate: 0.5, flee: 0.15 },
    detectBonus: 1.1,
    fleeBias: 1.1,
    styleId: 'voidglass',
    archetype: 'disruption-value',
  },
  salvager: {
    id: 'salvager',
    name: 'Salvage Reaver',
    objectiveWeights: { patrol: 0.5, investigate: 0.35, flee: 0.15 },
    detectBonus: 0.85,
    fleeBias: 0.8,
    styleId: 'drowned-ledger',
    archetype: 'value-control',
  },
  harpoon: {
    id: 'harpoon',
    name: 'Harpoon Captain',
    objectiveWeights: { patrol: 0.35, investigate: 0.5, flee: 0.15 },
    detectBonus: 1,
    fleeBias: 0.75,
    styleId: 'luminous-tribunal',
    archetype: 'combat-control',
  },
  marshal: {
    id: 'marshal',
    name: 'Sea Marshal',
    objectiveWeights: { patrol: 0.25, investigate: 0.5, flee: 0.25 },
    detectBonus: 1.4,
    fleeBias: 1.2,
    styleId: 'riftstorm',
    archetype: 'boss-incursion',
  },
};

const PIRATE_HOUSE_DEFAULTS = {
  red_wake: {
    id: 'red_wake',
    name: 'The Red Wake Brotherhood',
    wielder: 'Captain Rauk Vhal, the Smileless Tide',
    styleId: 'riftstorm',
    colorHint: '#ff5d5d',
    aiStyle: 'fast pressure, blood trades, reckless boarding',
  },
  coffin_reef: {
    id: 'coffin_reef',
    name: 'The Coffin Reef Brotherhood',
    wielder: 'Mother Serekh, Keeper of the Last Wake',
    styleId: 'drowned-ledger',
    colorHint: '#7ab8a8',
    aiStyle: 'slow attrition, memoryprint recursion, death-value inevitability',
  },
  null_gospel: {
    id: 'null_gospel',
    name: 'The Null-Gospel Lantern Fleet',
    wielder: 'Prelate-Corsair Ilex Vann, the Lantern-Mouth',
    styleId: 'luminous-tribunal',
    colorHint: '#f0cf86',
    aiStyle: 'control lockout, silence, tax, anti-spell denial',
  },
  gilded_harrow: {
    id: 'gilded_harrow',
    name: 'The Gilded Harrow Syndicate',
    wielder: 'Commodore Ysra Vale, the Gilt Widow',
    styleId: 'solar-dominion',
    colorHint: '#d4a85d',
    aiStyle: 'midrange control, mark/bounty pressure, elegant theft',
  },
};

const DIMENSIONAL_ATTACKERS_DEFAULTS = {
  trace: 0,
  traceState: 'Hidden',
  invasionProgress: 0,
  invasionThreshold: 100,
  pirateInfamy: 0,
  pirateInfamyLabel: 'Unknown',
  playerExposed: false,
  activePirates: [],
  sightings: [],
  eventLog: [],
  pirateDossier: [],
  battlePressure: {
    recentBattleStamps: [],
    streak: 0,
    lastBattleAt: 0,
  },
  pendingIntercept: null,
  bossState: {
    pending: false,
    activePirateId: null,
    lastSpawnAt: 0,
    defeatedCount: 0,
  },
  warpKey: {
    keyId: 'warp-key-home',
    ownerId: 'player',
    dimensionId: 'player-home',
    signatureStrength: 54,
    concealment: 68,
    compromised: false,
    compromisedByPirateId: null,
  },
  viroleanSea: {
    axis: 0.95,
    lockedForPlayer: true,
    label: 'Virolean Sea',
  },
  scanChallenge: {
    active: false,
    pirateId: null,
    scanNodeId: null,
    slots: [],
    emojiBank: [],
    successCount: 0,
    failCount: 0,
    maxFails: 3,
    ticksLeft: 0,
    lastMessage: '',
    cooldownUntil: 0,
  },
  lastTickAt: 0,
  lastKnownStats: {
    wins: 0,
    losses: 0,
  },
};

function emptyCampaignMarketState() {
  return {
    traderFactions: {},
    relations: {},
    activeTraders: [],
    tradeShips: [],
    marketIndices: {
      global: 1,
      collections: {},
      rarities: { common: 1, rare: 1, epic: 1, legendary: 1 },
      events: { global: 1 },
      history: [],
    },
    priceHistory: {},
    collectionIndices: {},
    collectionHistory: {},
    factionTradeHistory: {},
    playerProfitHistory: [],
    relationHistory: {},
    newsFeed: [],
    activeDemands: [],
    routeHeat: {},
    lastMarketTickAt: 0,
    lastDemandRotationAt: 0,
    watchedCards: [],
  };
}

const CAMPAIGN_DEFAULTS = {
  ownedDimensions: [],
  ownedWorldIds: [],
  lostWorldIds: [],
  worldStates: {},
  conquestCardLibrary: [],
  speciesAccess: {},
  reinforcementPool: {},
  activeThreats: [],
  supernaturalEvents: [],
  eventHistory: [],
  totalIncome: 0,
  lastProductionTickAt: 0,
  selectedWorldId: null,
  market: emptyCampaignMarketState(),
  diplomacy: { relations: {}, transactionCounters: {}, embargoes: {}, flags: {} },
  tradeShips: [],
};

const MAP_WORLD_DEFAULTS = {
  createdGalaxies: [],
  customAiProfiles: [],
  nodeAssignments: {},
  gatewayIndexBySeed: {},
  mapFilters: { search: '', status: 'all', style: 'all' },
  globalMapStyleId: 'astral-cartographer',
  selectedNodeId: null,
  dimensionalAttackers: structuredClone(DIMENSIONAL_ATTACKERS_DEFAULTS),
  campaign: structuredClone(CAMPAIGN_DEFAULTS),
};

const MAP_TYPES = {
  GalaxyDefinition: 'GalaxyDefinition',
  GalaxyNodeState: 'GalaxyNodeState',
  MapNode: 'MapNode',
  ThreatGroup: 'ThreatGroup',
  CustomAiProfile: 'CustomAiProfile',
  ConversationPack: 'ConversationPack',
  MapStyle: 'MapStyle',
};

const mapView = {
  panX: 0,
  panY: 0,
  zoom: 1,
  dragging: false,
  panCandidate: false,
  panPointerId: null,
  leftPointerHeld: false,
  dragStartX: 0,
  dragStartY: 0,
  lastX: 0,
  lastY: 0,
  suppressClickUntil: 0,
  threatFilter: 'all',
  baseNodes: [],
  nodes: [],
  routes: [],
  hoveredNodeId: null,
  selectedNodeId: null,
  focusedNodeId: null,
  animatingNodeId: null,
  nodeEls: {},
  routeEls: {},
  systemViewerMode: 'split',
  systemViewerFocus: false,
  viewportWidth: 900,
  viewportHeight: 360,
  worldWidth: 900,
  worldHeight: 360,
  lastWarpCompromised: false,
  baseSceneSig: '',
  sceneStaticSig: '',
  dynamicThreatEls: {
    pirates: Object.create(null),
    aliens: Object.create(null),
    fleeLines: Object.create(null),
    wakeLines: Object.create(null),
  },
  orbitSelection: {
    nodeId: null,
    worldId: null,
    planetId: null,
    planets: [],
  },
  lastTickPersistAt: 0,
  invasionUiSig: '',
  invasionFeedSig: '',
  invasionDossierSig: '',
  invasionAlienSig: '',
  offscreenGuardCount: 0,
  invasionSweep: null,
};
let mapInteractionsBound = false;
let mapModalsBound = false;
let mapWorldTicker = null;
const MAP_WORLD_TICK_MS = 1000;
let mapRuntimeSuspended = false;
let mapAutosaveTimer = null;
let mapAutosaveQueuedProfile = null;
let mapAutosaveQueuedAt = 0;
let mapTickPending = false;

function flushQueuedMapAutosave() {
  if (!mapAutosaveQueuedProfile) return;
  try {
    saveProfile(mapAutosaveQueuedProfile, { skipNormalize: true });
  } catch {}
  mapAutosaveQueuedProfile = null;
  mapAutosaveQueuedAt = 0;
}

function queueMapAutosave(profile, { immediate = false } = {}) {
  if (!profile) return;
  mapAutosaveQueuedProfile = profile;
  mapAutosaveQueuedAt = Date.now();
  if (immediate) {
    if (mapAutosaveTimer) {
      clearTimeout(mapAutosaveTimer);
      mapAutosaveTimer = null;
    }
    flushQueuedMapAutosave();
    return;
  }
  if (mapAutosaveTimer) return;
  mapAutosaveTimer = setTimeout(() => {
    mapAutosaveTimer = null;
    const run = () => flushQueuedMapAutosave();
    if (typeof window.requestIdleCallback === 'function') window.requestIdleCallback(run, { timeout: 1200 });
    else setTimeout(run, 0);
  }, 900);
}

function isFacilityWarOpen() {
  return !!(dom.facilityWarModal && !dom.facilityWarModal.classList.contains('hidden'));
}

function shouldTickMapWorld() {
  if (document.hidden) return false;
  if (!dom.lobbyPanel || dom.lobbyPanel.classList.contains('hidden')) return false;
  if (!dom.battlemapPanel || dom.battlemapPanel.classList.contains('hidden')) return false;
  if (!dom.matchTab || dom.matchTab.classList.contains('hidden')) return false;
  return true;
}

function stopMapWorldTicker() {
  if (!mapWorldTicker) return;
  clearInterval(mapWorldTicker);
  mapWorldTicker = null;
  mapTickPending = false;
}

function stopOrbitAnimation(handleKey = 'map') {
  if (handleKey === 'map' && mapOrbitHandle) {
    cancelAnimationFrame(mapOrbitHandle);
    mapOrbitHandle = null;
    if (dom.mapOrbitCanvas) {
      dom.mapOrbitCanvas.onclick = null;
      dom.mapOrbitCanvas.onpointermove = null;
      dom.mapOrbitCanvas.onpointerleave = null;
      dom.mapOrbitCanvas.style.cursor = 'default';
    }
    return;
  }
  if (handleKey === 'codex' && codexOrbitHandle) {
    cancelAnimationFrame(codexOrbitHandle);
    codexOrbitHandle = null;
  }
}

function startMapWorldTicker() {
  if (mapWorldTicker || mapRuntimeSuspended || isFacilityWarOpen()) return;
  mapWorldTicker = setInterval(() => {
    if (!shouldTickMapWorld()) return;
    if (mapTickPending) return;
    const profiles = mapProfilesRef.length ? mapProfilesRef : cachedAiProfiles;
    if (!profiles.length) return;
    mapTickPending = true;
    const runTick = () => {
      try {
        if (shouldTickMapWorld()) tickMapWorldScene(profiles);
      } finally {
        mapTickPending = false;
      }
    };
    if (typeof window.requestIdleCallback === 'function') window.requestIdleCallback(runTick, { timeout: 120 });
    else setTimeout(runTick, 0);
  }, MAP_WORLD_TICK_MS);
}

function suspendMapRuntime(reason = 'system') {
  mapRuntimeSuspended = true;
  stopMapWorldTicker();
  flushQueuedMapAutosave();
  stopMapEffects();
  stopOrbitAnimation('map');
  stopOrbitAnimation('codex');
  mapView.runtimePauseReason = reason;
}

function resumeMapRuntime() {
  mapRuntimeSuspended = false;
  if (isFacilityWarOpen()) return;
  if (!shouldTickMapWorld()) return;
  startMapWorldTicker();
  if (mapView.nodes.length) {
    const profile = loadProfile();
    const mapWorld = getMapWorld(profile);
    const style = findStyleById(mapWorld.globalMapStyleId);
    const staticSig = mapView.sceneStaticSig || buildStaticSceneSignature(mapView.nodes);
    startMapEffects(style, mapView.nodes, staticSig);
    const selectedNode = mapNodeById(mapView.selectedNodeId) ?? mapView.nodes[0] ?? null;
    if (selectedNode) updateMapInspectCard(selectedNode, profile, mapProfilesRef.length ? mapProfilesRef : cachedAiProfiles);
  }
}

function setMapLeftPointerHeld(active) {
  mapView.leftPointerHeld = !!active;
  document.body.classList.toggle('left-click-hold', mapView.leftPointerHeld);
  if (!mapView.leftPointerHeld) return;
  if (mapView.hoveredNodeId) {
    mapView.hoveredNodeId = null;
    updateMapNodeInteractionVisuals();
  }
}

function suppressMapNativeEvent(event) {
  if (!event) return;
  if (event.cancelable) event.preventDefault();
  event.stopPropagation();
}

function mapClickSuppressed() {
  return Date.now() < toFiniteNumber(mapView.suppressClickUntil, 0);
}

function canStartMapPanFromTarget(target) {
  if (!target) return true;
  const el = target instanceof Element ? target : null;
  if (!el) return true;
  return !el.closest(
    '.map-hover-card button, .map-hover-card a, .map-hover-card input, .map-hover-card select, .map-hover-card textarea',
  );
}

function tickMapWorldScene(profiles) {
  const profileState = loadProfile();
  applyQueuedMatchResult(profileState);
  if (!mapView.nodes.length) {
    renderBattleMap(profiles, profileState);
    return;
  }
  const aiProfiles = allAiProfiles(profiles, profileState);
  const candidateNodes = (mapView.baseNodes?.length ? mapView.baseNodes : mapView.nodes).filter((node) => node && node.id);
  const layoutNodes = (mapView.nodes?.length ? mapView.nodes : candidateNodes).filter((node) => node && node.id);
  if (!candidateNodes.length) {
    renderBattleMap(profiles, profileState);
    return;
  }
  const mapWorld = getMapWorldFast(profileState);
  const tick = runDimensionalAttackersTick(profileState, candidateNodes, mapWorld);
  const attackersForTick = tick.attackers;
  const campaignTick = runCampaignTick(profileState, candidateNodes, aiProfiles, attackersForTick, mapWorld);
  if (tick.changed || campaignTick.changed) {
    const now = Date.now();
    const persistBudgetMs = 15000;
    const shouldPersistNow = !mapView.lastTickPersistAt || ((now - mapView.lastTickPersistAt) >= persistBudgetMs);
    if (shouldPersistNow) {
      queueMapAutosave(profileState);
      mapView.lastTickPersistAt = now;
    }
  }
  const refreshedMapWorld = getMapWorldFast(profileState);
  const attackers = getDimensionalAttackers(refreshedMapWorld);
  const campaign = refreshedMapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const marketCards = mergeLauncherCardCatalog(loadCreatorCustomCards());
  if (window.CardForgeMarket) {
    window.CardForgeMarket.tickMarket(profileState, layoutNodes, marketCards, Date.now());
  }
  ensureMapCameraHasVisibleNode(layoutNodes, mapView.selectedNodeId, mapView.viewportWidth, mapView.viewportHeight);
  applyMapTransform();
  renderDynamicThreatLayers(layoutNodes, attackers, campaign, profiles, mapView.worldWidth, mapView.worldHeight);
  renderInvasionPanel(attackers, profiles, profileState, refreshedMapWorld, campaign);
}

function getSessionSeed() {
  let seed = localStorage.getItem(WORLD_KEY);
  if (!seed) {
    seed = `${Date.now()}-${Math.floor(Math.random() * 99999)}`;
    localStorage.setItem(WORLD_KEY, seed);
  }
  return seed;
}

function seededRandom(seed) {
  let t = 0;
  for (let i = 0; i < seed.length; i += 1) t += seed.charCodeAt(i) * (i + 1);
  return () => {
    t = (t * 9301 + 49297) % 233280;
    return t / 233280;
  };
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function toFiniteNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function infamyLabel(infamy = 0) {
  if (infamy >= 90) return 'High-Value Target';
  if (infamy >= 70) return 'Infamous';
  if (infamy >= 52) return 'Marked';
  if (infamy >= 34) return 'Hunted';
  if (infamy >= 18) return 'Noticed';
  return 'Unknown';
}

function slugifyId(value = '') {
  return String(value ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function toArray(value) {
  return Array.isArray(value) ? value : [];
}

const FALLBACK_MODE_RULESETS = [
  {
    id: 'wielder-duel',
    name: 'Wielder Duel',
    battleType: 'wielder_duel',
    model: 'duel',
    deckSize: 30,
    maxCopiesPerCard: 2,
    startingMana: 1,
    startingHand: 5,
    enableStrategicZones: false,
    structureSlots: 0,
    reinforcementRate: 0,
  },
  {
    id: 'planetary-defense',
    name: 'Planetary Defense',
    battleType: 'defense_conquest',
    model: 'defense',
    deckSize: 40,
    maxCopiesPerCard: 3,
    startingMana: 2,
    startingHand: 6,
    enableStrategicZones: true,
    structureSlots: 4,
    reinforcementRate: 1,
  },
  {
    id: 'massive-invasion',
    name: 'Massive Invasion',
    battleType: 'invasion_massive',
    model: 'defense',
    deckSize: 60,
    maxCopiesPerCard: 4,
    startingMana: 3,
    startingHand: 7,
    enableStrategicZones: true,
    structureSlots: 6,
    reinforcementRate: 2,
  },
];

const FALLBACK_ALIEN_FACTIONS = [
  {
    id: 'chitin-ascendancy',
    name: 'The Chitin Ascendancy',
    color: '#74f08f',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [1, 4],
    techLevelRange: [2, 8],
    deckTags: ['swarm', 'brood', 'token', 'pressure'],
    behaviorNotes: 'Hive pressure doctrine built on swarms and synapse amplification.',
    cardPackId: 'chitin-ascendancy',
  },
  {
    id: 'glass-null-collective',
    name: 'The Glass Null Collective',
    color: '#71f5ee',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [3, 9],
    deckTags: ['precision', 'copy', 'control', 'barrier'],
    behaviorNotes: 'Fractal precision fleets that split, mirror, and punish mispositioning.',
    cardPackId: 'glass-null-collective',
  },
  {
    id: 'verdant-consumers',
    name: 'The Verdant Consumers',
    color: '#85ef6a',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [1, 4],
    techLevelRange: [2, 8],
    deckTags: ['growth', 'heal', 'spore', 'attrition'],
    behaviorNotes: 'Parasitic overgrowth forces that spread hazards and recover through pressure.',
    cardPackId: 'verdant-consumers',
  },
  {
    id: 'halo-censors',
    name: 'The Halo Censors',
    color: '#f2dc86',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [4, 10],
    deckTags: ['formation', 'suppression', 'shield', 'elite'],
    behaviorNotes: 'Radiant censor detachments enforcing silence and disciplined lanes.',
    cardPackId: 'halo-censors',
  },
  {
    id: 'iron-carrion-mandate',
    name: 'The Iron Carrion Mandate',
    color: '#9fb3bb',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [4, 10],
    deckTags: ['siege', 'salvage', 'structure', 'attrition'],
    behaviorNotes: 'Necro-industrial columns that grind lanes with siege engines and salvage loops.',
    cardPackId: 'iron-carrion-mandate',
  },
];

const CONQUEST_EXTRA_THREAT_FACTIONS = Object.freeze([
  {
    id: 'warlord-convoys',
    name: 'Warlord Convoys',
    color: '#ff9c7a',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [4, 11],
    deckTags: ['siege', 'vehicle', 'armor', 'breach'],
    behaviorNotes: 'Armored convoy columns focused on lane breakpoints and structure demolition.',
    specialTraits: ['convoy-lanes', 'ram-charge', 'siege-pressure'],
    threatStyle: 'siege-heavy',
    attackPattern: 'Establish pylons, deploy armored spearheads, then breach one lane with siege support.',
    strengths: ['Excellent against structures and barricades', 'Strong mid-late pressure'],
    weaknesses: ['Can be outmaneuvered by air and flanks', 'Weak early board flood'],
    unitRoster: [
      { name: 'Convoy Ram Tank', role: 'Structure breaker', tags: ['vehicle', 'siege', 'anti-structure'] },
      { name: 'Redline Breacher', role: 'Breach infantry escort', tags: ['ground', 'breach'] },
      { name: 'Hauler Gun Cart', role: 'Ranged convoy support', tags: ['vehicle', 'ranged'] },
    ],
  },
  {
    id: 'beast-stampedes',
    name: 'Beast Stampedes',
    color: '#b7ea86',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [1, 4],
    techLevelRange: [2, 8],
    deckTags: ['swarm', 'horde', 'giant', 'rush'],
    behaviorNotes: 'Territorial predator swarms that overload lanes with bodies and apex beasts.',
    specialTraits: ['feral-wave', 'apex-charge', 'territorial-rage'],
    threatStyle: 'swarm-heavy',
    attackPattern: 'Mass lane flooding followed by giant breakthrough attempts on weakened defenses.',
    strengths: ['High lane saturation', 'Powerful giant finishers'],
    weaknesses: ['Vulnerable to sustained explosives', 'Limited tactical spells'],
    unitRoster: [
      { name: 'Razorhide Pack', role: 'Cheap horde pressure', tags: ['horde', 'ground'] },
      { name: 'Apex Tusk Horror', role: 'Giant breakthrough', tags: ['giant', 'siege'] },
      { name: 'Stampede Howler', role: 'Morale pressure support', tags: ['support', 'horde'] },
    ],
  },
  {
    id: 'cult-uprisings',
    name: 'Cult Uprisings',
    color: '#d58cff',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [3, 9],
    deckTags: ['swarm', 'morale', 'sacrifice', 'control'],
    behaviorNotes: 'Fanatic infantry cells that weaponize sacrifice, fear, and burst tempo swings.',
    specialTraits: ['zeal-wave', 'ritual-burst', 'morale-break'],
    threatStyle: 'control-pressure',
    attackPattern: 'Fill lanes with fanatics, convert losses into tactical spikes, and force collapse windows.',
    strengths: ['High tempo tactics', 'Strong anti-attrition bursts'],
    weaknesses: ['Fragile frontline bodies', 'Reliant on timing windows'],
    unitRoster: [
      { name: 'Cult Knife Swarm', role: 'Cheap rush body', tags: ['horde', 'ground'] },
      { name: 'Ritual Drummer', role: 'Offense amplifier', tags: ['support', 'morale'] },
      { name: 'Ash Prophet Cell', role: 'Control caster infantry', tags: ['ranged', 'control'] },
    ],
  },
  {
    id: 'rogue-mechanized-cells',
    name: 'Rogue Mechanized Cells',
    color: '#8dd9ff',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [4, 11],
    deckTags: ['vehicle', 'turret', 'drone', 'anti-structure'],
    behaviorNotes: 'Autonomous war-machine pods with disciplined fire lanes and structure cracking payloads.',
    specialTraits: ['drone-nest', 'turret-grid', 'machine-overclock'],
    threatStyle: 'precision-siege',
    attackPattern: 'Set pylon relays, deploy walkers and turrets, then pressure from overlapping fire corridors.',
    strengths: ['Excellent ranged discipline', 'High structural pressure'],
    weaknesses: ['Can stall when mobility is denied', 'Lower horde count'],
    unitRoster: [
      { name: 'Drone Nest Carrier', role: 'Summon engine', tags: ['support', 'drone'] },
      { name: 'Autonomous Walker', role: 'Armored lane pusher', tags: ['vehicle', 'ground'] },
      { name: 'Spine Turret Pod', role: 'Static suppression', tags: ['turret', 'ranged'] },
    ],
  },
  {
    id: 'necro-bloom-infestations',
    name: 'Necro-Bloom Infestations',
    color: '#7ee3a7',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [3, 10],
    deckTags: ['growth', 'heal', 'attrition', 'horde'],
    behaviorNotes: 'Corruption blooms that spread hazards, regenerate waves, and grind defenders down.',
    specialTraits: ['spore-cloud', 'rot-heal', 'creeping-attrition'],
    threatStyle: 'attrition-growth',
    attackPattern: 'Open with infestation bodies, build healing pressure, and outlast defensive economy.',
    strengths: ['Strong sustain', 'Excellent attrition wars'],
    weaknesses: ['Slow initial burst', 'Punished by focused anti-horde explosives'],
    unitRoster: [
      { name: 'Plague Bloom Host', role: 'Healing spread core', tags: ['support', 'growth'] },
      { name: 'Rotvine Hordes', role: 'Sticky lane swarm', tags: ['horde', 'ground'] },
      { name: 'Blight Spore Cannon', role: 'Ranged corruption support', tags: ['ranged', 'attrition'] },
    ],
  },
  {
    id: 'sky-raider-wings',
    name: 'Sky Raider Wings',
    color: '#9fd3ff',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [2, 5],
    techLevelRange: [3, 10],
    deckTags: ['air', 'harrier', 'bombard', 'capture'],
    behaviorNotes: 'Air-first strike wings that disrupt lanes and punish static defenses from above.',
    specialTraits: ['wing-screen', 'bomb-run', 'rapid-flank'],
    threatStyle: 'air-assault',
    attackPattern: 'Establish pylon tempo, pressure with harriers, and convert openings into air bombing waves.',
    strengths: ['High mobility', 'Strong anti-ground pressure'],
    weaknesses: ['Vulnerable to anti-air nets', 'Lower structure HP'],
    unitRoster: [
      { name: 'Sky Harrier', role: 'Flying lane disruptor', tags: ['air', 'ranged'] },
      { name: 'Bombard Kite', role: 'Anti-horde bomber', tags: ['air', 'explosive'] },
      { name: 'Wing Marshal', role: 'Air command support', tags: ['air', 'support'] },
    ],
  },
  {
    id: 'fortress-columns',
    name: 'Fortress Columns',
    color: '#f4d6a2',
    icon: '△',
    threatGeometry: 'triangle',
    deckSizePreference: [20, 70],
    aiSkillRange: [3, 5],
    techLevelRange: [5, 12],
    deckTags: ['elite', 'shield', 'siege', 'command'],
    behaviorNotes: 'Slow elite assault formations built around shielded command units and bunker-breaking tools.',
    specialTraits: ['fortress-shield', 'command-anchors', 'slow-advance'],
    threatStyle: 'elite-pressure',
    attackPattern: 'Stabilize with elite fronts, then advance methodically with protected siege assets.',
    strengths: ['Very strong frontline durability', 'Excellent structure-breaking finish'],
    weaknesses: ['Lower board spread', 'Can be outpaced by multi-lane rush'],
    unitRoster: [
      { name: 'Bulwark Colossus', role: 'Shielded heavy anchor', tags: ['giant', 'elite'] },
      { name: 'Citadel Breach Team', role: 'Siege specialists', tags: ['siege', 'anti-structure'] },
      { name: 'Aegis Marshal', role: 'Command elite support', tags: ['officer', 'support'] },
    ],
  },
]);

const ALIEN_COMMANDER_LIBRARY = {
  'chitin-ascendancy': {
    bosses: [
      {
        id: 'chitin-boss-vorak-nest-crown',
        name: 'Vorak Tchrenn',
        title: 'Nest-Crown of the Endless Maw',
        levelBand: [20, 32],
        personality: 'Predatory, adaptive, and relentlessly patient.',
        playstyle: 'Mass swarm recursion with synapse scaling into apex pressure.',
        lore: 'Vorak threads hive-commands through collapse residue, turning every failed defense into fresh biomass doctrine.',
        signatureMechanics: ['Synapse amplification', 'Death-spawn chains', 'Brood overrun'],
        signatureCards: ['Nestspire Bulwark', 'Apex Drone', 'Queen\'s War-Nest'],
        dialogue: {
          intro: 'Signal acquired. Your habitat will hatch our next wave.',
          strong: 'Your losses are useful. Keep feeding the nest.',
          defeat: 'Retreating biomass. The hive will remember this geometry.',
        },
      },
    ],
    elites: [
      {
        id: 'chitin-elite-skarn-brood-tyrant',
        name: 'Skarn of the Needle Brood',
        title: 'Brood Tyrant',
        levelBand: [12, 20],
        personality: 'Aggressive lane-crasher with instinctive flanking.',
        playstyle: 'Early swarm pressure and lane collapse.',
        signatureMechanics: ['Board flood', 'Piercing strikes'],
        signatureCards: ['Apex Drone', 'Apex Howler', 'Synapse Overgrowth Field'],
      },
      {
        id: 'chitin-elite-thryxa-hatch-matron',
        name: 'Thryxa',
        title: 'Hatch Matron',
        levelBand: [14, 22],
        personality: 'Cold and surgical coordinator.',
        playstyle: 'Token multiplication with back-row pressure.',
        signatureMechanics: ['Hatch burst', 'Adjacency scaling'],
        signatureCards: ['Nestspire Bulwark', 'Hive Hatch Protocol', 'Brood Pressure Lattice'],
      },
    ],
  },
  'glass-null-collective': {
    bosses: [
      {
        id: 'glass-boss-priarch-vell',
        name: 'Priarch Vell-9',
        title: 'Fractal Executor',
        levelBand: [20, 32],
        personality: 'Emotionless, exact, and ruthlessly efficient.',
        playstyle: 'Precision mirrors, copy pressure, and anti-commit punish windows.',
        lore: 'Vell-9 computes attrition from first contact and applies perfect losses until resistance becomes arithmetic.',
        signatureMechanics: ['Mirror split', 'Reflective control', 'Null-lattice lockdown'],
        signatureCards: ['Nullglass Barrier Array', 'Prism Equation Field', 'Mirror-Split Directive'],
        dialogue: {
          intro: 'Incursion proof established. Your defense is now a solved branch.',
          strong: 'Resource curve collapsed. Continue compliance.',
          defeat: 'Prediction fault logged. Recomputing your pattern.',
        },
      },
    ],
    elites: [
      {
        id: 'glass-elite-shard-prelate-azr',
        name: 'Shard Prelate Azr',
        title: 'Mirror Prelate',
        levelBand: [12, 20],
        personality: 'Sharp, mocking, and data-hungry.',
        playstyle: 'Refraction tempo and copy attrition.',
        signatureMechanics: ['Copy and split', 'Barrier timing'],
        signatureCards: ['Facet Echo', 'Mirror-Split Directive', 'Refraction Bastion'],
      },
      {
        id: 'glass-elite-facet-huntress',
        name: 'Facet Huntress Nyl',
        title: 'Lattice Huntress',
        levelBand: [14, 22],
        personality: 'Patient sniper doctrine.',
        playstyle: 'Backline picks and anti-large precision.',
        signatureMechanics: ['Piercing precision', 'Control geometry'],
        signatureCards: ['Crystal Lance Equation', 'Prismline Sever', 'Nullglass Barrier Array'],
      },
    ],
  },
  'verdant-consumers': {
    bosses: [
      {
        id: 'verdant-boss-grand-bloom-vara',
        name: 'Vara the Root-Mouth',
        title: 'Grand Bloom Marshal',
        levelBand: [20, 32],
        personality: 'Calm, suffocating, and inevitability-focused.',
        playstyle: 'Sustain attrition, spread infest, then overgrow lanes.',
        lore: 'Vara turns tactical maps into growth cycles, consuming fortifications as fertilizer.',
        signatureMechanics: ['Spore spread', 'Healing inevitability', 'Terrain takeover'],
        signatureCards: ['Overgrowth Canopy Field', 'Rootwall Barricade', 'Worldroot Assimilation'],
        dialogue: {
          intro: 'Your cities are soil pretending to be steel.',
          strong: 'You are already inside the grove.',
          defeat: 'Seasons turn. We return with deeper roots.',
        },
      },
    ],
    elites: [
      {
        id: 'verdant-elite-bloom-marshal-ith',
        name: 'Ith Bloom-Marshal',
        title: 'Bloom Marshal',
        levelBand: [12, 20],
        personality: 'Methodical spreader.',
        playstyle: 'Root lockdown and heal loops.',
        signatureMechanics: ['Root control', 'Sustain pressure'],
        signatureCards: ['Sporeburst Bloom', 'Rootweb Grasp', 'Living Reactor Grove'],
      },
      {
        id: 'verdant-elite-spore-abbess',
        name: 'Abbess of Sporeglass',
        title: 'Spore Abbess',
        levelBand: [14, 22],
        personality: 'Soft-spoken and terrifyingly patient.',
        playstyle: 'Delayed value and token bloom chains.',
        signatureMechanics: ['Token propagation', 'Delayed growth payoff'],
        signatureCards: ['Parasitic Germination', 'Infestation Cycle', 'Everdawn Bloomheart'],
      },
    ],
  },
  'halo-censors': {
    bosses: [
      {
        id: 'halo-boss-archon-serel',
        name: 'Archon Serel Vaunt',
        title: 'Voice of Final Doctrine',
        levelBand: [20, 32],
        personality: 'Elegant, judgmental, and absolute.',
        playstyle: 'Elite formation control with suppression and radiant finishers.',
        lore: 'Serel writes doctrine into battlefield light, deleting dissent with immaculate formation law.',
        signatureMechanics: ['Suppression', 'Formation buffs', 'Shield discipline'],
        signatureCards: ['Cathedral of Censored Suns', 'Radiant Purge Beam', 'Halo Bastion Prism'],
        dialogue: {
          intro: 'Yield and be corrected. Resist and be archived.',
          strong: 'Order is not negotiable.',
          defeat: 'Doctrine bends. It does not break.',
        },
      },
    ],
    elites: [
      {
        id: 'halo-elite-censor-archon-lyr',
        name: 'Lyr Censor-Archon',
        title: 'Censor Archon',
        levelBand: [12, 20],
        personality: 'Measured and punitive.',
        playstyle: 'Suppress spells and hold clean formations.',
        signatureMechanics: ['Silence windows', 'Guarded phalanx'],
        signatureCards: ['Sanctioned Silence', 'Doctrine Shieldwall', 'Choir Discipline Field'],
      },
      {
        id: 'halo-elite-choir-exactor',
        name: 'Choir Exactor Pell',
        title: 'Judgment Exactor',
        levelBand: [14, 22],
        personality: 'Cruelly serene.',
        playstyle: 'Anti-swarm beams and precision takedowns.',
        signatureMechanics: ['Radiant purge', 'Punish overextension'],
        signatureCards: ['Judgment Prism', 'Choirline Interdiction', 'Luminous Reprimand'],
      },
    ],
  },
  'iron-carrion-mandate': {
    bosses: [
      {
        id: 'iron-boss-dreadmarshal-korr',
        name: 'Korr Vex',
        title: 'Dreadmarshal of the Carrion Forges',
        levelBand: [20, 32],
        personality: 'Brutal, practical, and siege-obsessed.',
        playstyle: 'Heavy siege attrition with salvage recursion and structure pressure.',
        lore: 'Korr wages war like accounting: every loss reprocessed into the next weaponized invoice.',
        signatureMechanics: ['Siege recursion', 'Salvage loops', 'Anti-fortification'],
        signatureCards: ['Mandate Dread-Factory', 'Rustplate Barricade Grid', 'Mandate of Endless Harvest'],
        dialogue: {
          intro: 'All matter is inventory. You are now inventory.',
          strong: 'Scrap them. Feed the furnaces.',
          defeat: 'Debts remain. We collect later.',
        },
      },
    ],
    elites: [
      {
        id: 'iron-elite-siege-lord-tram',
        name: 'Tram Siege-Lord',
        title: 'Siege Lord',
        levelBand: [12, 20],
        personality: 'Impatient demolisher.',
        playstyle: 'Lane-breaking artillery tempo.',
        signatureMechanics: ['Siege spikes', 'Barricade pressure'],
        signatureCards: ['Mandate Siege Protocol', 'Breaker Cannon Salvo', 'Siege Platform Bulwark'],
      },
      {
        id: 'iron-elite-scrap-magister-vorn',
        name: 'Vorn Scrap-Magister',
        title: 'Scrap Magister',
        levelBand: [14, 22],
        personality: 'Cold recycler.',
        playstyle: 'Long-game salvage value and attrition advantage.',
        signatureMechanics: ['Salvage engine', 'Corpse-furnace conversion'],
        signatureCards: ['Carrion Recovery Order', 'Corpseforge Conversion', 'Corpse-Furnace Reactor'],
      },
    ],
  },
};

function normalizeAlienCommanderVariant(raw = {}, rank = 'elite', faction = {}) {
  const cleanRank = rank === 'boss' ? 'boss' : 'elite';
  return {
    id: raw.id ?? `${slugifyId(faction.id || 'alien')}-${cleanRank}-${Date.now()}`,
    name: raw.name ?? faction.name ?? 'Unknown Commander',
    title: raw.title ?? (cleanRank === 'boss' ? 'Faction Apex' : 'Field Commander'),
    levelBand: Array.isArray(raw.levelBand) && raw.levelBand.length >= 2 ? raw.levelBand : (cleanRank === 'boss' ? [20, 35] : [12, 24]),
    personality: raw.personality ?? 'Adaptive incursion doctrine.',
    playstyle: raw.playstyle ?? 'Balanced pressure.',
    lore: raw.lore ?? `${faction.name ?? 'Alien faction'} commander.`,
    signatureMechanics: toArray(raw.signatureMechanics),
    signatureCards: toArray(raw.signatureCards),
    dialogue: raw.dialogue && typeof raw.dialogue === 'object' ? raw.dialogue : {},
    rank: cleanRank,
  };
}

function enrichFactionWithCommanders(faction = {}) {
  const factionId = slugifyId(faction.id || '');
  const preset = ALIEN_COMMANDER_LIBRARY[factionId] ?? {};
  const bossRaw = toArray(faction.bosses).length ? toArray(faction.bosses) : toArray(preset.bosses);
  const eliteRaw = toArray(faction.elites).length ? toArray(faction.elites) : toArray(preset.elites);
  return {
    ...faction,
    bosses: bossRaw.map((entry) => normalizeAlienCommanderVariant(entry, 'boss', faction)),
    elites: eliteRaw.map((entry) => normalizeAlienCommanderVariant(entry, 'elite', faction)),
  };
}

const PLANET_BIOMES = ['forge-desert', 'acid-jungle', 'glacier-crypt', 'storm-ocean', 'ash-wastes', 'iron-orchard', 'luminous-plate'];
const OBJECTIVE_LIBRARY = [
  'Destroy Fort Quavus',
  'Capture the Orbital Elevator',
  'Break the Crystal Breeding Grounds',
  'Silence the Storm Array',
  'Seize the Rift Harbor',
  'Eliminate the Governor-Beast',
  'Disable Shield Spires',
  'Destroy Nest Cluster Theta',
  'Hold the Iron Gate',
  'Purge the Hollow Basilica',
  'Sabotage the Spawn Forges',
  'Cripple the Null Beacon',
];

const BUILDING_LIBRARY = {
  training_center: { id: 'training_center', name: 'Training Centre', costGold: 140, income: 0, favor: 4, production: 1, defense: 0 },
  factory: { id: 'factory', name: 'Factory', costGold: 180, income: 2, favor: -2, production: 2, defense: 0 },
  trade_port: { id: 'trade_port', name: 'Trade Port', costGold: 160, income: 4, favor: 1, production: 0, defense: 0 },
  welfare_mall: { id: 'welfare_mall', name: 'Welfare Mall', costGold: 120, income: 0, favor: 8, production: 0, defense: 0 },
  mana_reactor: { id: 'mana_reactor', name: 'Mana Reactor', costGold: 190, income: 1, favor: 0, production: 2, defense: 1 },
  blacksmith: { id: 'blacksmith', name: 'Blacksmith', costGold: 165, income: 0, favor: 1, production: 1, defense: 1 },
  storage_depot: { id: 'storage_depot', name: 'Storage Depot', costGold: 145, income: 0, favor: 1, production: 1, defense: 0 },
  fortress: { id: 'fortress', name: 'Fortress', costGold: 220, income: 0, favor: -1, production: 0, defense: 3 },
  turret_grid: { id: 'turret_grid', name: 'Turret Grid', costGold: 150, income: 0, favor: -1, production: 0, defense: 2 },
  card_factory: { id: 'card_factory', name: 'Card Factory', costGold: 240, income: 0, favor: 0, production: 3, defense: 0 },
};

const CONQUEST_BOARD_DEFAULT_CONFIG = Object.freeze({
  rows: 7,
  cols: 16,
  noMansLandStartCol: 6,
  noMansLandCols: 3,
});

function resolveConquestBoardConfig() {
  let persisted = null;
  try {
    const raw = localStorage.getItem('cardforge.conquest.board_config.v1');
    if (raw) persisted = JSON.parse(raw);
  } catch {
    persisted = null;
  }
  const runtime = (typeof window !== 'undefined' && window.CF_CONQUEST_BOARD_CONFIG && typeof window.CF_CONQUEST_BOARD_CONFIG === 'object')
    ? window.CF_CONQUEST_BOARD_CONFIG
    : null;
  const source = runtime ?? persisted ?? {};
  const rows = clamp(Math.floor(toFiniteNumber(source.rows, CONQUEST_BOARD_DEFAULT_CONFIG.rows)), 5, 12);
  const cols = clamp(Math.floor(toFiniteNumber(source.cols, CONQUEST_BOARD_DEFAULT_CONFIG.cols)), 10, 24);
  const noMansLandStartCol = clamp(
    Math.floor(toFiniteNumber(source.noMansLandStartCol, CONQUEST_BOARD_DEFAULT_CONFIG.noMansLandStartCol)),
    1,
    Math.max(1, cols - 2),
  );
  const noMansLandCols = clamp(
    Math.floor(toFiniteNumber(source.noMansLandCols, CONQUEST_BOARD_DEFAULT_CONFIG.noMansLandCols)),
    1,
    Math.max(1, cols - noMansLandStartCol),
  );
  return Object.freeze({ rows, cols, noMansLandStartCol, noMansLandCols });
}

const CONQUEST_BOARD_CONFIG = resolveConquestBoardConfig();
const CONQUEST_GRID_ROWS = CONQUEST_BOARD_CONFIG.rows;
const CONQUEST_GRID_COLS = CONQUEST_BOARD_CONFIG.cols;
const CONQUEST_NO_MANS_START_COL = clamp(
  Math.floor(toFiniteNumber(CONQUEST_BOARD_CONFIG.noMansLandStartCol, 6)),
  1,
  Math.max(1, CONQUEST_GRID_COLS - 2),
);
const CONQUEST_NO_MANS_COLS = clamp(
  Math.floor(toFiniteNumber(CONQUEST_BOARD_CONFIG.noMansLandCols, 3)),
  1,
  Math.max(1, CONQUEST_GRID_COLS - CONQUEST_NO_MANS_START_COL),
);
const CONQUEST_NO_MANS_END_COL = Math.min(CONQUEST_GRID_COLS - 1, CONQUEST_NO_MANS_START_COL + CONQUEST_NO_MANS_COLS - 1);
const CONQUEST_ATTACKER_DEPLOY_MIN_COL = 0;
const CONQUEST_ATTACKER_DEPLOY_MAX_COL = Math.max(0, CONQUEST_NO_MANS_START_COL - 1);
const CONQUEST_DEFENDER_DEPLOY_MIN_COL = Math.min(CONQUEST_GRID_COLS - 1, CONQUEST_NO_MANS_END_COL + 1);
const CONQUEST_DEFENDER_DEPLOY_MAX_COL = CONQUEST_GRID_COLS - 1;
const CONQUEST_ATTACKER_COLS = Math.max(0, CONQUEST_ATTACKER_DEPLOY_MAX_COL - CONQUEST_ATTACKER_DEPLOY_MIN_COL + 1);
const ATTACKER_MAX_PLAYS_PER_TURN = 3;
const DEFENDER_MAX_DRAWS_PER_TURN = 3;
const CONQUEST_DEFENDER_DECK_KEYS = ['training', 'factory', 'blacksmith', 'command', 'vehicle', 'ordnance', 'air', 'power', 'recovery', 'experimental'];
const CONQUEST_DECK_DRAW_LABELS = {
  training: 'Training',
  factory: 'Factory',
  blacksmith: 'Blacksmith',
  command: 'Command',
  vehicle: 'Vehicle',
  ordnance: 'Ordnance',
  air: 'Air Support',
  power: 'Power/Shield',
  recovery: 'Recovery',
  experimental: 'Experimental',
};
const CONQUEST_FACILITY_DRAW_REQUIREMENTS = {
  training: { buildingIds: ['cq-training-facility', 'cq-training-bronze'], facilityLabel: 'Training Facility' },
  factory: { buildingIds: ['cq-factory', 'cq-factory-bronze'], facilityLabel: 'Factory' },
  blacksmith: { buildingIds: ['cq-blacksmith', 'cq-blacksmith-bronze'], facilityLabel: 'Blacksmith' },
  command: { buildingIds: [], facilityLabel: 'Command' },
  vehicle: { buildingIds: ['cq-motor-pool'], facilityLabel: 'Motor Pool' },
  ordnance: { buildingIds: ['cq-ordnance-foundry'], facilityLabel: 'Ordnance Foundry' },
  air: { buildingIds: ['cq-air-pad'], facilityLabel: 'Air Pad / Skydock' },
  power: { buildingIds: ['cq-reactor-core'], facilityLabel: 'Reactor Core' },
  recovery: { buildingIds: ['cq-medical-bay'], facilityLabel: 'Medical Bay' },
  experimental: { buildingIds: ['cq-war-lab'], facilityLabel: 'War Lab' },
};
const CONQUEST_MAT_PRESETS = Object.freeze({
  grass: {
    label: 'Grass',
    image: 'radial-gradient(circle at 18% 14%, rgba(135, 196, 126, 0.24), transparent 38%), radial-gradient(circle at 84% 80%, rgba(96, 160, 106, 0.2), transparent 40%), linear-gradient(165deg, rgba(20, 45, 26, 0.88), rgba(10, 28, 16, 0.96))',
  },
  desert: {
    label: 'Desert',
    image: 'radial-gradient(circle at 22% 16%, rgba(212, 171, 95, 0.24), transparent 34%), radial-gradient(circle at 78% 82%, rgba(189, 141, 71, 0.2), transparent 36%), linear-gradient(165deg, rgba(54, 36, 16, 0.9), rgba(31, 21, 8, 0.96))',
  },
  'ash-waste': {
    label: 'Ash Waste',
    image: 'radial-gradient(circle at 12% 22%, rgba(131, 103, 102, 0.24), transparent 36%), radial-gradient(circle at 78% 74%, rgba(102, 87, 87, 0.2), transparent 34%), linear-gradient(168deg, rgba(30, 24, 27, 0.93), rgba(16, 13, 15, 0.98))',
  },
  crystal: {
    label: 'Crystal',
    image: 'radial-gradient(circle at 18% 18%, rgba(118, 177, 255, 0.25), transparent 36%), radial-gradient(circle at 86% 76%, rgba(154, 121, 255, 0.2), transparent 38%), linear-gradient(165deg, rgba(17, 33, 66, 0.9), rgba(10, 20, 41, 0.96))',
  },
  swamp: {
    label: 'Swamp',
    image: 'radial-gradient(circle at 20% 12%, rgba(119, 156, 97, 0.22), transparent 35%), radial-gradient(circle at 84% 84%, rgba(76, 115, 66, 0.22), transparent 36%), linear-gradient(165deg, rgba(20, 34, 20, 0.92), rgba(10, 18, 11, 0.97))',
  },
  fortress: {
    label: 'Fortress',
    image: 'radial-gradient(circle at 16% 16%, rgba(118, 161, 230, 0.2), transparent 36%), radial-gradient(circle at 82% 78%, rgba(130, 156, 212, 0.16), transparent 38%), linear-gradient(170deg, rgba(18, 29, 56, 0.9), rgba(9, 17, 33, 0.96))',
  },
  'metal-deck': {
    label: 'Metal Deck',
    image: 'repeating-linear-gradient(135deg, rgba(68, 82, 110, 0.22) 0, rgba(68, 82, 110, 0.22) 6px, rgba(39, 51, 76, 0.22) 6px, rgba(39, 51, 76, 0.22) 12px), linear-gradient(170deg, rgba(20, 31, 54, 0.92), rgba(11, 18, 34, 0.97))',
  },
  'alien-hive': {
    label: 'Alien Hive',
    image: 'radial-gradient(circle at 12% 20%, rgba(114, 183, 130, 0.2), transparent 40%), radial-gradient(circle at 78% 80%, rgba(88, 130, 166, 0.2), transparent 34%), linear-gradient(170deg, rgba(16, 37, 33, 0.92), rgba(8, 23, 25, 0.98))',
  },
  'frozen-tundra': {
    label: 'Frozen Tundra',
    image: 'radial-gradient(circle at 16% 16%, rgba(193, 224, 255, 0.24), transparent 35%), radial-gradient(circle at 84% 76%, rgba(137, 190, 255, 0.2), transparent 38%), linear-gradient(168deg, rgba(20, 37, 63, 0.9), rgba(12, 24, 43, 0.97))',
  },
  'lava-basin': {
    label: 'Lava Basin',
    image: 'radial-gradient(circle at 18% 76%, rgba(255, 146, 103, 0.24), transparent 34%), radial-gradient(circle at 84% 20%, rgba(255, 205, 112, 0.16), transparent 36%), linear-gradient(170deg, rgba(47, 19, 19, 0.93), rgba(24, 10, 10, 0.98))',
  },
});
const CONQUEST_MAT_DEFAULT = Object.freeze({
  preset: 'fortress',
  tint: 24,
  customUrl: '',
  customDataUrl: '',
});
const FACILITY_SETUP_STARTER_CARDS = [
  { id: 'cq-farm', count: 1 },
  { id: 'cq-mine', count: 1 },
  { id: 'cq-factory', count: 1 },
  { id: 'cq-training-facility', count: 1 },
  { id: 'cq-blacksmith', count: 1 },
  { id: 'cq-barricade', count: 5 },
  { id: 'cq-turret', count: 4 },
];

const CONQUEST_BASE_CARDS = [
  { id: 'cq-farm-bronze', name: 'Farm (Bronze I)', type: 'building', sourceBuilding: 'utility', cost: { wheat: 0, iron: 0, mana: 0 }, attack: 0, health: 6, defense: 1, range: 1, tags: ['farm', 'production'], text: 'Produces +2 wheat each defender turn while attacked.' },
  { id: 'cq-mine-bronze', name: 'Mine (Bronze I)', type: 'building', sourceBuilding: 'utility', cost: { wheat: 0, iron: 0, mana: 0 }, attack: 0, health: 6, defense: 1, range: 1, tags: ['mine', 'production'], text: 'Produces +2 iron each defender turn while attacked.' },
  { id: 'cq-factory-bronze', name: 'Factory (Bronze I)', type: 'building', sourceBuilding: 'utility', cost: { wheat: 0, iron: 0, mana: 0 }, attack: 0, health: 7, defense: 2, range: 1, tags: ['factory', 'production'], text: 'Unlocks factory draw options and armored production.' },
  { id: 'cq-training-bronze', name: 'Training Facility (Bronze I)', type: 'building', sourceBuilding: 'utility', cost: { wheat: 0, iron: 0, mana: 0 }, attack: 0, health: 7, defense: 1, range: 1, tags: ['training', 'production'], text: 'Unlocks troop recruitment draws.' },
  { id: 'cq-blacksmith-bronze', name: 'Blacksmith (Bronze I)', type: 'building', sourceBuilding: 'utility', cost: { wheat: 0, iron: 2, mana: 0 }, attack: 0, health: 7, defense: 1, range: 1, tags: ['blacksmith', 'production'], text: 'Can produce one equipment draw each turn.' },
  { id: 'cq-storage', name: 'Storage Depot', type: 'building', sourceBuilding: 'utility', cost: { wheat: 2, iron: 2, mana: 0 }, attack: 0, health: 8, defense: 1, range: 1, tags: ['storage'], text: 'Raises wheat and iron cap by +5.' },
  { id: 'cq-barricade', name: 'Barricade', type: 'building', sourceBuilding: 'factory', cost: { wheat: 1, iron: 2, mana: 0 }, attack: 0, health: 9, defense: 3, range: 1, tags: ['barricade', 'wall'], text: 'Blocks direct lane attacks until destroyed.' },
  { id: 'cq-turret', name: 'Turret', type: 'building', sourceBuilding: 'factory', cost: { wheat: 1, iron: 3, mana: 0 }, attack: 3, health: 7, defense: 2, range: 2, tags: ['turret', 'ranged'], text: 'Fires up to 2 nodes each defender turn unless blocked by a barricade directly ahead.' },
  { id: 'cq-turret-silver-upgrade', name: 'Turret Silver Upgrade Schematic', type: 'upgrade', sourceBuilding: 'factory', cost: { wheat: 2, iron: 4, mana: 0 }, attack: 0, health: 0, defense: 0, range: 1, tags: ['upgrade', 'schematic', 'turret'], text: 'Apply to turret: +2 DEF, +2 ATK, skips one firing turn.' },
  { id: 'cq-barricade-silver-upgrade', name: 'Barricade Silver Upgrade Schematic', type: 'upgrade', sourceBuilding: 'factory', cost: { wheat: 2, iron: 3, mana: 0 }, attack: 0, health: 0, defense: 0, range: 1, tags: ['upgrade', 'schematic', 'barricade'], text: 'Apply to barricade: +4 HP and +1 DEF.' },
  { id: 'cq-militia', name: 'Militia Recruit', type: 'unit', sourceBuilding: 'training', cost: { wheat: 1, iron: 0, mana: 0 }, attack: 1, health: 1, defense: 0, range: 1, tags: ['ground', 'infantry'], text: 'Base troop body (1/1/0).' },
  { id: 'cq-shieldbearer', name: 'Shieldbearer Squad', type: 'unit', sourceBuilding: 'training', cost: { wheat: 2, iron: 1, mana: 0 }, attack: 2, health: 4, defense: 1, range: 1, tags: ['ground', 'guard'], text: 'Lane holder for the frontline.' },
  { id: 'cq-archer-line', name: 'Archer Line', type: 'unit', sourceBuilding: 'training', cost: { wheat: 2, iron: 0, mana: 0 }, attack: 2, health: 2, defense: 0, range: 2, tags: ['ground', 'ranged', 'fragile'], text: 'Ranged support, especially against fragile units.' },
  { id: 'cq-armored-phalanx', name: 'Armored Phalanx', type: 'unit', sourceBuilding: 'factory', cost: { wheat: 2, iron: 3, mana: 0 }, attack: 3, health: 6, defense: 2, range: 1, tags: ['ground', 'armored'], text: 'Slow durable formation unit.' },
  { id: 'cq-explosive-shell', name: 'Explosive Shell', type: 'spell', sourceBuilding: 'factory', cost: { wheat: 1, iron: 3, mana: 0 }, attack: 0, health: 0, defense: 0, range: 3, tags: ['explosive'], text: 'Deals explosive damage (5 + 20% max HP) to horde target.' },
  { id: 'cq-sword-kit', name: 'Sword Kit', type: 'upgrade', sourceBuilding: 'blacksmith', cost: { wheat: 1, iron: 2, mana: 0 }, attack: 2, health: 0, defense: 0, range: 1, tags: ['weapon', 'melee'], text: 'Equip unit: +2 ATK.' },
  { id: 'cq-bow-kit', name: 'Bow Kit', type: 'upgrade', sourceBuilding: 'blacksmith', cost: { wheat: 1, iron: 2, mana: 0 }, attack: 1, health: 0, defense: 0, range: 2, tags: ['weapon', 'bow', 'ranged'], text: 'Equip unit: +1 ATK, +1 range.' },
  { id: 'cq-leather-armor', name: 'Leather Armor', type: 'upgrade', sourceBuilding: 'blacksmith', cost: { wheat: 1, iron: 1, mana: 0 }, attack: 0, health: 2, defense: 0, range: 1, tags: ['armor'], text: 'Equip unit: +2 HP.' },
  { id: 'cq-plate-armor', name: 'Plate Armor', type: 'upgrade', sourceBuilding: 'blacksmith', cost: { wheat: 1, iron: 3, mana: 0 }, attack: 0, health: 3, defense: 1, range: 1, tags: ['armor', 'heavy'], text: 'Equip unit: +3 HP and +1 DEF.' },
  { id: 'cq-homestead', name: 'Invasion Homestead', type: 'building', subtype: 'homestead', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 1 }, attack: 0, health: 14, defense: 2, range: 1, tags: ['attacker', 'structure', 'homestead', 'command'], text: 'Attacker anchor. Must be deployed first. If destroyed, defenders win immediately.' },
  { id: 'cq-mana-pylon', name: 'Mana Pylon', type: 'pylon', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 1 }, attack: 0, health: 5, defense: 0, range: 1, tags: ['attacker', 'resource'], text: 'Attacker gains +1 mana per turn while active.' },
  { id: 'cq-goblin-tribe', name: 'Goblin Tribe (10)', type: 'unit', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 2 }, attack: 10, health: 10, defense: 0, range: 1, tags: ['attacker', 'ground', 'horde'], text: 'Horde body. Damage scales with surviving members.' },
  { id: 'cq-raider-pack', name: 'Raider Pack', type: 'unit', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 3 }, attack: 4, health: 4, defense: 1, range: 1, tags: ['attacker', 'ground'], text: 'Standard invasion ground pressure.' },
  { id: 'cq-air-skirmisher', name: 'Air Skirmisher', type: 'unit', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 3 }, attack: 3, health: 2, defense: 0, range: 2, tags: ['attacker', 'air', 'fragile'], text: 'Fast aerial threat with ranged poke.' },
  { id: 'cq-siege-giant', name: 'Siege Giant', type: 'unit', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 7 }, attack: 8, health: 12, defense: 2, range: 1, tags: ['attacker', 'ground', 'giant', 'siege'], text: 'Heavy siege body requiring high mana.' },
  { id: 'cq-void-demolisher', name: 'Void Demolisher', type: 'unit', sourceBuilding: 'attacker', cost: { wheat: 0, iron: 0, mana: 5 }, attack: 5, health: 7, defense: 1, range: 1, tags: ['attacker', 'ground', 'siege'], text: '+2 ATK versus barricades and turrets.' },
];

const CONQUEST_DECK_DEFAULTS = {
  training: ['cq-militia', 'cq-militia', 'cq-shieldbearer', 'cq-archer-line', 'cq-militia', 'cq-shieldbearer', 'cq-archer-line', 'cq-militia', 'cq-militia', 'cq-shieldbearer'],
  factory: ['cq-barricade', 'cq-barricade', 'cq-barricade', 'cq-barricade', 'cq-barricade', 'cq-turret', 'cq-turret', 'cq-turret', 'cq-turret', 'cq-turret-silver-upgrade', 'cq-barricade-silver-upgrade', 'cq-armored-phalanx', 'cq-armored-phalanx', 'cq-explosive-shell'],
  blacksmith: ['cq-sword-kit', 'cq-sword-kit', 'cq-bow-kit', 'cq-bow-kit', 'cq-leather-armor', 'cq-leather-armor', 'cq-plate-armor', 'cq-plate-armor'],
  command: [],
  vehicle: [],
  ordnance: [],
  air: [],
  power: [],
  recovery: [],
  experimental: [],
  utility: ['cq-farm-bronze', 'cq-mine-bronze', 'cq-factory-bronze', 'cq-training-bronze', 'cq-blacksmith-bronze', 'cq-storage'],
  attacker: [
    'cq-homestead',
    'cq-mana-pylon', 'cq-mana-pylon', 'cq-mana-pylon', 'cq-mana-pylon',
    'cq-goblin-tribe', 'cq-goblin-tribe', 'cq-goblin-tribe', 'cq-goblin-tribe', 'cq-goblin-tribe',
    'cq-raider-pack', 'cq-raider-pack', 'cq-raider-pack', 'cq-raider-pack', 'cq-raider-pack', 'cq-raider-pack',
    'cq-air-skirmisher', 'cq-air-skirmisher', 'cq-air-skirmisher', 'cq-air-skirmisher', 'cq-air-skirmisher',
    'cq-void-demolisher', 'cq-void-demolisher', 'cq-void-demolisher', 'cq-void-demolisher',
    'cq-siege-giant', 'cq-siege-giant',
  ],
};

const CONQUEST_CARD_ID_ALIASES = {
  'cq-farm-bronze': 'cq-farm',
  'cq-mine-bronze': 'cq-mine',
  'cq-factory-bronze': 'cq-factory',
  'cq-training-bronze': 'cq-training-facility',
  'cq-blacksmith-bronze': 'cq-blacksmith',
  'cq-militia': 'cq-militia-recruit',
  'cq-archer-line': 'cq-archer-cadet',
  'cq-sword-kit': 'cq-iron-shortsword',
  'cq-bow-kit': 'cq-longbow-set',
  'cq-leather-armor': 'cq-leather-jerkin',
  'cq-plate-armor': 'cq-iron-mail',
  'cq-turret-silver-upgrade': 'cq-silver-turret-upgrade',
  'cq-barricade-silver-upgrade': 'cq-silver-barricade-upgrade',
  'cq-goblin-tribe': 'cq-riot-goblin-tribe',
  'cq-raider-pack': 'cq-bone-clad-raiders',
  'cq-air-skirmisher': 'cq-carrion-bats',
  'cq-siege-giant': 'cq-rift-giant',
};

function normalizeConquestCardId(cardId = '') {
  const raw = String(cardId ?? '').trim();
  return CONQUEST_CARD_ID_ALIASES[raw] ?? raw;
}

const CONQUEST_CONTENT_V2 = (window.CONQUEST_CARD_CONTENT_V2 && typeof window.CONQUEST_CARD_CONTENT_V2 === 'object')
  ? window.CONQUEST_CARD_CONTENT_V2
  : null;

const CONQUEST_RUNTIME_CARDS = Array.isArray(CONQUEST_CONTENT_V2?.cards) && CONQUEST_CONTENT_V2.cards.length
  ? CONQUEST_CONTENT_V2.cards.map((entry) => ({ ...entry }))
  : CONQUEST_BASE_CARDS.map((entry) => ({ ...entry }));

const CONQUEST_RUNTIME_DECK_DEFAULTS = {
  training: Array.isArray(CONQUEST_CONTENT_V2?.decks?.training) && CONQUEST_CONTENT_V2.decks.training.length
    ? CONQUEST_CONTENT_V2.decks.training.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.training),
  factory: Array.isArray(CONQUEST_CONTENT_V2?.decks?.factory) && CONQUEST_CONTENT_V2.decks.factory.length
    ? CONQUEST_CONTENT_V2.decks.factory.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.factory),
  blacksmith: Array.isArray(CONQUEST_CONTENT_V2?.decks?.blacksmith) && CONQUEST_CONTENT_V2.decks.blacksmith.length
    ? CONQUEST_CONTENT_V2.decks.blacksmith.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.blacksmith),
  command: Array.isArray(CONQUEST_CONTENT_V2?.decks?.command) && CONQUEST_CONTENT_V2.decks.command.length
    ? CONQUEST_CONTENT_V2.decks.command.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.command),
  vehicle: Array.isArray(CONQUEST_CONTENT_V2?.decks?.vehicle) && CONQUEST_CONTENT_V2.decks.vehicle.length
    ? CONQUEST_CONTENT_V2.decks.vehicle.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.vehicle),
  ordnance: Array.isArray(CONQUEST_CONTENT_V2?.decks?.ordnance) && CONQUEST_CONTENT_V2.decks.ordnance.length
    ? CONQUEST_CONTENT_V2.decks.ordnance.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.ordnance),
  air: Array.isArray(CONQUEST_CONTENT_V2?.decks?.air) && CONQUEST_CONTENT_V2.decks.air.length
    ? CONQUEST_CONTENT_V2.decks.air.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.air),
  power: Array.isArray(CONQUEST_CONTENT_V2?.decks?.power) && CONQUEST_CONTENT_V2.decks.power.length
    ? CONQUEST_CONTENT_V2.decks.power.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.power),
  recovery: Array.isArray(CONQUEST_CONTENT_V2?.decks?.recovery) && CONQUEST_CONTENT_V2.decks.recovery.length
    ? CONQUEST_CONTENT_V2.decks.recovery.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.recovery),
  experimental: Array.isArray(CONQUEST_CONTENT_V2?.decks?.experimental) && CONQUEST_CONTENT_V2.decks.experimental.length
    ? CONQUEST_CONTENT_V2.decks.experimental.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.experimental),
  utility: Array.isArray(CONQUEST_CONTENT_V2?.decks?.utility) && CONQUEST_CONTENT_V2.decks.utility.length
    ? CONQUEST_CONTENT_V2.decks.utility.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.utility),
  attacker: Array.isArray(CONQUEST_CONTENT_V2?.decks?.attacker) && CONQUEST_CONTENT_V2.decks.attacker.length
    ? CONQUEST_CONTENT_V2.decks.attacker.map((entry) => String(entry))
    : conquestDeckCopy(CONQUEST_DECK_DEFAULTS.attacker),
};

function conquestDeckCopy(deck = []) {
  return Array.isArray(deck) ? deck.map((entry) => normalizeConquestCardId(String(entry))) : [];
}

function shouldUpgradeLegacyConquestDeck(deckKey, list = []) {
  const normalized = (Array.isArray(list) ? list : []).map((entry) => normalizeConquestCardId(entry)).filter(Boolean);
  const unique = new Set(normalized);
  if (!unique.size) return true;
  const fallback = conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS?.[deckKey] ?? []);
  const fallbackUnique = new Set(fallback).size;
  const density = normalized.length ? (unique.size / normalized.length) : 0;
  const maxCopies = normalized.reduce((map, id) => {
    map.set(id, (map.get(id) ?? 0) + 1);
    return map;
  }, new Map());
  const highestShare = normalized.length
    ? Math.max(...Array.from(maxCopies.values())) / normalized.length
    : 1;
  if (deckKey === 'blacksmith') {
    return unique.size < Math.max(24, Math.floor(fallbackUnique * 0.45))
      || density < 0.38
      || highestShare > 0.22;
  }
  if (deckKey === 'training') {
    return unique.size < Math.max(18, Math.floor(fallbackUnique * 0.42))
      || density < 0.34
      || highestShare > 0.3;
  }
  if (deckKey === 'factory') {
    return unique.size < Math.max(16, Math.floor(fallbackUnique * 0.4))
      || density < 0.32
      || highestShare > 0.34;
  }
  if (deckKey === 'command') {
    return unique.size < Math.max(14, Math.floor(fallbackUnique * 0.4))
      || density < 0.3
      || highestShare > 0.35;
  }
  if (deckKey === 'vehicle' || deckKey === 'ordnance' || deckKey === 'air' || deckKey === 'power' || deckKey === 'recovery' || deckKey === 'experimental') {
    return unique.size < Math.max(12, Math.floor(fallbackUnique * 0.38))
      || density < 0.28
      || highestShare > 0.36;
  }
  if (deckKey === 'attacker') {
    return unique.size < Math.max(24, Math.floor(fallbackUnique * 0.42))
      || normalized.length < 50;
  }
  return false;
}

function defaultConquestDecks() {
  return {
    training: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.training),
    factory: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.factory),
    blacksmith: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.blacksmith),
    command: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.command),
    vehicle: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.vehicle),
    ordnance: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.ordnance),
    air: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.air),
    power: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.power),
    recovery: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.recovery),
    experimental: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.experimental),
    utility: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.utility),
    attacker: conquestDeckCopy(CONQUEST_RUNTIME_DECK_DEFAULTS.attacker),
  };
}

function conquestCardLibrary(profile = null) {
  const base = CONQUEST_RUNTIME_CARDS.map((card) => ({ ...card }));
  const mapWorld = getMapWorld(profile ?? loadProfile());
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const custom = Array.isArray(campaign.conquestCardLibrary) ? campaign.conquestCardLibrary : [];
  custom.forEach((entry) => {
    if (!entry?.id || !entry?.name) return;
    const sourceBuilding = String(entry.sourceBuilding ?? entry.productionSource ?? 'utility').toLowerCase();
    const side = String(entry.side ?? (sourceBuilding === 'attacker' ? 'attacker' : 'defender')).toLowerCase();
    const wheatCost = Math.max(0, Number(entry.wheatCost ?? entry.cost?.wheat ?? 0));
    const ironCost = Math.max(0, Number(entry.ironCost ?? entry.cost?.iron ?? 0));
    const manaCost = Math.max(0, Number(entry.manaCost ?? entry.cost?.mana ?? 0));
    const tags = new Set(toArray(entry.tags).map((tag) => String(tag).trim().toLowerCase()).filter(Boolean));
    tags.add('conquest');
    tags.add(sourceBuilding);
    tags.add(side);
    base.push({
      id: String(entry.id),
      name: String(entry.name),
      mode: 'conquest',
      side,
      cardType: String(entry.cardType ?? (String(entry.type ?? '').toLowerCase().includes('spell') ? 'Spell' : 'Unit')),
      subtype: String(entry.subtype ?? ''),
      techTier: String(entry.techTier ?? 'Bronze 1'),
      faction: entry.faction ? String(entry.faction) : null,
      species: entry.species ? String(entry.species) : null,
      productionSource: sourceBuilding,
      sourceBuilding,
      type: String(entry.type ?? 'unit'),
      cost: {
        wheat: wheatCost,
        iron: ironCost,
        mana: manaCost,
      },
      wheatCost,
      ironCost,
      manaCost,
      attack: Math.max(0, Number(entry.attack ?? 0)),
      health: Math.max(0, Number(entry.health ?? 0)),
      defense: Math.max(0, Number(entry.defense ?? 0)),
      range: clamp(Math.max(1, Number(entry.range ?? 1)), 1, 5),
      siege: Math.max(0, Number(entry.siege ?? 0)),
      flying: !!entry.flying,
      horde: !!entry.horde,
      large: !!entry.large,
      fortified: !!entry.fortified,
      structure: !!entry.structure,
      barricade: !!entry.barricade,
      facility: !!entry.facility,
      equipment: !!entry.equipment,
      upgradeSchematic: !!entry.upgradeSchematic,
      repairRelevant: !!entry.repairRelevant,
      captureRelevant: !!entry.captureRelevant,
      attackerPackage: entry.attackerPackage ? String(entry.attackerPackage) : null,
      tags: Array.from(tags),
      text: String(entry.text ?? 'Custom conquest card.'),
      flavorText: String(entry.flavorText ?? ''),
      production: entry.production && typeof entry.production === 'object' ? { ...entry.production } : null,
      tactic: entry.tactic && typeof entry.tactic === 'object' ? { ...entry.tactic } : null,
    });
  });
  return base;
}

function conquestCardById(profile, cardId) {
  const normalizedId = normalizeConquestCardId(cardId);
  const resolved = profile ?? loadProfile();
  const campaignCards = toArray(resolved?.mapWorld?.campaign?.conquestCardLibrary);
  const cacheKey = `${CONQUEST_RUNTIME_CARDS.length}:${campaignCards.length}:${campaignCards.map((entry) => String(entry?.id ?? '')).join('|')}`;
  if (conquestCardLookupCache.key !== cacheKey) {
    const byId = new Map();
    conquestCardLibrary(resolved).forEach((entry) => {
      if (!entry?.id) return;
      byId.set(String(entry.id), entry);
    });
    conquestCardLookupCache = { key: cacheKey, byId };
  }
  return conquestCardLookupCache.byId.get(normalizedId) ?? null;
}

function allModeRulesets() {
  const packed = (cachedModeRulesets ?? []).flatMap((pack) => Array.isArray(pack?.rulesets) ? pack.rulesets : []);
  if (packed.length) return packed;
  return FALLBACK_MODE_RULESETS;
}

function resolveRuleset({ rulesetId = null, battleType = null } = {}) {
  const all = allModeRulesets();
  const byId = rulesetId ? all.find((entry) => entry.id === rulesetId) : null;
  if (byId) return byId;
  const byType = battleType ? all.find((entry) => entry.battleType === battleType) : null;
  if (byType) return byType;
  return all.find((entry) => entry.id === 'wielder-duel') ?? all[0] ?? FALLBACK_MODE_RULESETS[0];
}

function battleContextPayload(aiProfile, context = {}) {
  const battleType = context.battleType ?? 'wielder_duel';
  const ruleset = resolveRuleset({ rulesetId: context.rulesetId, battleType });
  return {
    version: 1,
    ts: Date.now(),
    aiProfileId: aiProfile?.id ?? null,
    rulesetId: ruleset.id,
    rulesetName: ruleset.name,
    battleType,
    modeModel: ruleset.model ?? 'duel',
    deckSize: Number(context.deckSize ?? ruleset.deckSize ?? 30),
    maxCopiesPerCard: Number(context.maxCopiesPerCard ?? ruleset.maxCopiesPerCard ?? 2),
    startingMana: Number(context.startingMana ?? ruleset.startingMana ?? 1),
    startingHand: Number(context.startingHand ?? ruleset.startingHand ?? 5),
    structureSlots: Number(context.structureSlots ?? ruleset.structureSlots ?? 0),
    enableStrategicZones: !!(context.enableStrategicZones ?? ruleset.enableStrategicZones ?? false),
    enableResponseWindows: !!(context.enableResponseWindows ?? ruleset.enableResponseWindows ?? false),
    objectiveId: context.objectiveId ?? null,
    worldId: context.worldId ?? null,
    planetId: context.planetId ?? null,
    threatId: context.threatId ?? null,
    sourceNodeId: context.sourceNodeId ?? null,
    techLevel: Number(context.techLevel ?? 1),
    aiSkillStars: Number(context.aiSkillStars ?? Math.max(1, Math.min(5, Math.ceil((aiProfile?.level ?? 1) / 10)))),
    threatDeckSize: Number(context.threatDeckSize ?? context.deckSize ?? ruleset.deckSize ?? 30),
    reinforcementMod: Number(context.reinforcementMod ?? ruleset.reinforcementRate ?? 0),
    metadata: context.metadata ?? {},
  };
}

function objectiveRegionName(seed, idx) {
  const prefixes = ['North', 'South', 'East', 'West', 'Upper', 'Lower', 'Outer', 'Inner'];
  const suffixes = ['Basin', 'Cradle', 'District', 'Gate', 'Breach', 'Spine', 'Harbor', 'Plate'];
  const rand = rngFromSeed(`${seed}-region-${idx}`);
  return `${prefixes[Math.floor(rand() * prefixes.length)]} ${suffixes[Math.floor(rand() * suffixes.length)]}`;
}

const PLANET_NAME_PARTS_A = ['Astra', 'Viron', 'Kel', 'Myra', 'Tarn', 'Nox', 'Lumen', 'Quor', 'Eid', 'Braska', 'Thorne', 'Ilyr'];
const PLANET_NAME_PARTS_B = ['fall', 'reach', 'spire', 'hollow', 'veil', 'forge', 'rift', 'march', 'fen', 'crown', 'glen', 'strand'];

function generatePlanetName(worldName, worldId, planetIndex) {
  const rand = rngFromSeed(`${worldId}-planet-name-${planetIndex}`);
  const left = PLANET_NAME_PARTS_A[Math.floor(rand() * PLANET_NAME_PARTS_A.length)];
  const right = PLANET_NAME_PARTS_B[Math.floor(rand() * PLANET_NAME_PARTS_B.length)];
  const numeric = 10 + Math.floor(rand() * 89);
  return `${left}${right}-${numeric} (${worldName} ${planetIndex})`;
}

function planetSizeClass(worldId, planetIndex) {
  const roll = rngFromSeed(`${worldId}-planet-size-${planetIndex}`)();
  if (roll < 0.2) return 'small';
  if (roll < 0.62) return 'medium';
  if (roll < 0.87) return 'large';
  return 'massive';
}

function strongholdsForPlanet(sizeClass = 'medium') {
  switch (String(sizeClass)) {
    case 'small': return 3;
    case 'large': return 5;
    case 'massive': return 6;
    default: return 4;
  }
}

function conquestExpectedGridSize() {
  return CONQUEST_GRID_ROWS * CONQUEST_GRID_COLS;
}

function conquestIsNoMansLandCol(col) {
  const c = Math.floor(toFiniteNumber(col, -1));
  return c >= CONQUEST_NO_MANS_START_COL && c <= CONQUEST_NO_MANS_END_COL;
}

function conquestZoneForCol(col) {
  const c = Math.floor(toFiniteNumber(col, -1));
  if (c < 0 || c >= CONQUEST_GRID_COLS) return 'invalid';
  if (conquestIsNoMansLandCol(c)) return 'no-mans-land';
  if (c >= CONQUEST_ATTACKER_DEPLOY_MIN_COL && c <= CONQUEST_ATTACKER_DEPLOY_MAX_COL) return 'attacker';
  if (c >= CONQUEST_DEFENDER_DEPLOY_MIN_COL && c <= CONQUEST_DEFENDER_DEPLOY_MAX_COL) return 'defender';
  return 'contested';
}

function conquestCanDeployAt(side, col) {
  const normalized = String(side ?? '').toLowerCase();
  const zone = conquestZoneForCol(col);
  if (normalized === 'attacker') return zone === 'attacker';
  if (normalized === 'defender') return zone === 'defender';
  return false;
}

function conquestDeploymentColumns(side) {
  const normalized = String(side ?? '').toLowerCase();
  if (normalized === 'attacker') {
    return Array.from(
      { length: Math.max(0, CONQUEST_ATTACKER_DEPLOY_MAX_COL - CONQUEST_ATTACKER_DEPLOY_MIN_COL + 1) },
      (_, idx) => CONQUEST_ATTACKER_DEPLOY_MIN_COL + idx,
    );
  }
  if (normalized === 'defender') {
    return Array.from(
      { length: Math.max(0, CONQUEST_DEFENDER_DEPLOY_MAX_COL - CONQUEST_DEFENDER_DEPLOY_MIN_COL + 1) },
      (_, idx) => CONQUEST_DEFENDER_DEPLOY_MIN_COL + idx,
    );
  }
  return [];
}

function conquestBacklineCol(side) {
  return String(side ?? '').toLowerCase() === 'defender'
    ? CONQUEST_DEFENDER_DEPLOY_MAX_COL
    : CONQUEST_ATTACKER_DEPLOY_MIN_COL;
}

function conquestFrontlineDeployCol(side) {
  return String(side ?? '').toLowerCase() === 'defender'
    ? CONQUEST_DEFENDER_DEPLOY_MIN_COL
    : CONQUEST_ATTACKER_DEPLOY_MAX_COL;
}

function blankFacilityGrid() {
  return Array.from({ length: conquestExpectedGridSize() }, (_, idx) => {
    const { col } = facilityCellFromIndex(idx);
    const zone = conquestZoneForCol(col);
    return {
      owner: zone === 'attacker' ? 'attacker' : zone === 'defender' ? 'defender' : 'neutral',
      occupant: null,
    };
  });
}

function normalizeConquestMatSettings(rawSettings = null) {
  const presetRaw = String(rawSettings?.preset ?? CONQUEST_MAT_DEFAULT.preset).toLowerCase().trim();
  const preset = Object.prototype.hasOwnProperty.call(CONQUEST_MAT_PRESETS, presetRaw)
    ? presetRaw
    : CONQUEST_MAT_DEFAULT.preset;
  const tint = clamp(Math.round(toFiniteNumber(rawSettings?.tint, CONQUEST_MAT_DEFAULT.tint)), 0, 70);
  const customUrl = String(rawSettings?.customUrl ?? '').trim();
  const customDataUrl = String(rawSettings?.customDataUrl ?? '').trim();
  return {
    preset,
    tint,
    customUrl,
    customDataUrl,
  };
}

function safeCssUrl(url = '') {
  const clean = String(url ?? '').trim();
  if (!clean) return '';
  return `url("${clean.replace(/"/g, '%22')}")`;
}

function conquestMatLayerFromSettings(settings = null) {
  const normalized = normalizeConquestMatSettings(settings);
  if (normalized.customDataUrl) return safeCssUrl(normalized.customDataUrl);
  if (normalized.customUrl) return safeCssUrl(normalized.customUrl);
  return CONQUEST_MAT_PRESETS[normalized.preset]?.image ?? CONQUEST_MAT_PRESETS[CONQUEST_MAT_DEFAULT.preset].image;
}

function applyConquestMatToModal(state) {
  const modal = dom.facilityWarModal;
  if (!modal) return;
  const settings = normalizeConquestMatSettings(state?.matSettings);
  const layer = conquestMatLayerFromSettings(settings);
  const tint = clamp(Math.round(toFiniteNumber(settings.tint, CONQUEST_MAT_DEFAULT.tint)), 0, 70);
  modal.style.setProperty('--facility-mat-layer', layer);
  modal.style.setProperty('--facility-mat-tint', `${tint / 100}`);
  modal.dataset.matPreset = settings.preset;
  modal.dataset.matCustom = settings.customDataUrl || settings.customUrl ? '1' : '0';
}

function buildFacilitySetupHand(profile = null) {
  const resolved = profile ?? loadProfile();
  const library = Object.fromEntries(conquestCardLibrary(resolved).map((card) => [card.id, card]));
  const out = [];
  FACILITY_SETUP_STARTER_CARDS.forEach((entry) => {
    const count = Math.max(0, Number(entry.count ?? 1));
    if (!library[entry.id]) return;
    for (let i = 0; i < count; i += 1) {
      out.push({ instanceId: `${entry.id}-setup-${Date.now()}-${Math.floor(Math.random() * 9999)}-${i}`, cardId: entry.id });
    }
  });
  return out;
}

function facilitySetupCardsRemaining(state) {
  const remaining = {};
  FACILITY_SETUP_STARTER_CARDS.forEach((entry) => {
    remaining[entry.id] = Math.max(0, Number(entry.count ?? 1));
  });
  (state?.grid ?? []).forEach((cell) => {
    const cardId = String(cell?.occupant?.cardId ?? '');
    if (!cardId || !Object.prototype.hasOwnProperty.call(remaining, cardId)) return;
    remaining[cardId] = Math.max(0, Number(remaining[cardId] ?? 0) - 1);
  });
  (state?.defender?.hand ?? []).forEach((entry) => {
    const cardId = String(entry?.cardId ?? '');
    if (!cardId || !Object.prototype.hasOwnProperty.call(remaining, cardId)) return;
  });
  return remaining;
}

function defaultFacilitySetupPresets() {
  return {
    alpha: null,
    beta: null,
    gamma: null,
  };
}

function normalizeFacilitySetupPresets(raw = null) {
  const base = defaultFacilitySetupPresets();
  if (!raw || typeof raw !== 'object') return base;
  ['alpha', 'beta', 'gamma'].forEach((slot) => {
    const entry = raw[slot];
    if (!entry || typeof entry !== 'object') return;
    const placements = toArray(entry.placements)
      .filter((row) => row && typeof row === 'object' && Number.isInteger(Number(row.cellIndex)) && row.occupant && typeof row.occupant === 'object')
      .map((row) => ({
        cellIndex: clamp(Math.floor(Number(row.cellIndex)), 0, (CONQUEST_GRID_ROWS * CONQUEST_GRID_COLS) - 1),
        occupant: {
          ...row.occupant,
          cardId: normalizeConquestCardId(row.occupant.cardId),
          side: 'defender',
        },
      }))
      .filter((row) => !!row.occupant.cardId);
    base[slot] = placements.length
      ? {
        label: String(entry.label ?? `${slot[0].toUpperCase()}${slot.slice(1)} Setup`),
        savedAt: Number(entry.savedAt ?? Date.now()),
        placements,
      }
      : null;
  });
  return base;
}

function buildSetupHandFromGrid(state, profile = null) {
  const hand = buildFacilitySetupHand(profile ?? loadProfile());
  const setupRequired = Object.create(null);
  FACILITY_SETUP_STARTER_CARDS.forEach((entry) => {
    setupRequired[entry.id] = Math.max(0, Number(entry.count ?? 1));
  });
  toArray(state?.grid).forEach((cell) => {
    const cardId = String(cell?.occupant?.cardId ?? '');
    if (!cardId || !Object.prototype.hasOwnProperty.call(setupRequired, cardId)) return;
    setupRequired[cardId] = Math.max(0, Number(setupRequired[cardId] ?? 0) - 1);
  });
  const handByCard = new Map();
  hand.forEach((entry) => {
    const key = String(entry.cardId ?? '');
    if (!handByCard.has(key)) handByCard.set(key, []);
    handByCard.get(key).push(entry);
  });
  const trimmed = [];
  Object.entries(setupRequired).forEach(([cardId, remaining]) => {
    const rows = handByCard.get(cardId) ?? [];
    for (let i = 0; i < Math.min(rows.length, remaining); i += 1) trimmed.push(rows[i]);
  });
  return trimmed;
}

function snapshotDefenderSetupPreset(state) {
  const placements = [];
  toArray(state?.grid).forEach((cell, idx) => {
    const occ = cell?.occupant;
    if (!occ || String(occ.side ?? '') !== 'defender') return;
    placements.push({
      cellIndex: idx,
      occupant: JSON.parse(JSON.stringify(occ)),
    });
  });
  return placements.length
    ? {
      savedAt: Date.now(),
      placements,
    }
    : null;
}

function restoreDefenderSetupPreset(state, preset = null) {
  if (!state || !preset || typeof preset !== 'object') return { ok: false, message: 'Preset is empty.' };
  if (String(state.phase ?? '') !== 'setup') return { ok: false, message: 'Setup presets can only be loaded during setup phase.' };
  const placements = toArray(preset.placements)
    .filter((row) => row && typeof row === 'object' && Number.isInteger(Number(row.cellIndex)) && row.occupant && typeof row.occupant === 'object');
  if (!placements.length) return { ok: false, message: 'Preset has no saved placements.' };
  const before = state.grid.reduce((count, cell) => count + (cell?.occupant?.side === 'defender' ? 1 : 0), 0);
  state.grid.forEach((cell) => {
    if (cell?.occupant?.side === 'defender') cell.occupant = null;
  });
  let restored = 0;
  placements.forEach((row) => {
    const idx = clamp(Math.floor(Number(row.cellIndex)), 0, Math.max(0, state.grid.length - 1));
    const target = state.grid[idx];
    if (!target || target.occupant?.side === 'attacker') return;
    const { row: gridRow, col: gridCol } = facilityCellFromIndex(idx);
    const candidate = JSON.parse(JSON.stringify(row.occupant));
    candidate.side = 'defender';
    const cardLike = {
      id: candidate.cardId,
      type: candidate.type,
      tags: toArray(candidate.tags),
      name: candidate.name,
    };
    if (!canDefenderPlaceAt(state, cardLike, gridRow, gridCol)) return;
    candidate.status = candidate.status ?? {};
    candidate.status.deployedTurn = Number(state.turn ?? 1);
    candidate.status.actedTurn = 0;
    target.occupant = candidate;
    target.owner = 'defender';
    restored += 1;
  });
  syncDefenderResourceCaps(state, { clampOverflow: true });
  state.defender.hand = buildSetupHandFromGrid(state);
  const delta = restored - before;
  return restored > 0
    ? { ok: true, message: `Loaded setup preset (${restored} placements${delta ? `, delta ${delta >= 0 ? '+' : ''}${delta}` : ''}).` }
    : { ok: false, message: 'Preset placements are not valid for this board state.' };
}

function facilityCellIndex(row, col) {
  return (row * CONQUEST_GRID_COLS) + col;
}

function shuffledConquestDeck(list = []) {
  const out = conquestDeckCopy(list);
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

function normalizeConquestDecks(rawDecks = null) {
  const fallback = defaultConquestDecks();
  if (!rawDecks || typeof rawDecks !== 'object') return fallback;
  const normalized = {};
  ['training', 'factory', 'blacksmith', 'command', 'vehicle', 'ordnance', 'air', 'power', 'recovery', 'experimental', 'utility', 'attacker'].forEach((key) => {
    const fromRaw = Array.isArray(rawDecks[key])
      ? rawDecks[key].map((entry) => normalizeConquestCardId(String(entry))).filter(Boolean)
      : [];
    let list = fromRaw.length ? fromRaw : conquestDeckCopy(fallback[key]);
    if (shouldUpgradeLegacyConquestDeck(key, list)) {
      list = conquestDeckCopy(fallback[key]);
    }
    normalized[key] = list.length ? list : conquestDeckCopy(fallback[key]);
  });
  return normalized;
}

function createFacilityWarState(worldId, planetId, conquestDecks = null) {
  const profile = loadProfile();
  const decks = normalizeConquestDecks(conquestDecks);
  const grid = blankFacilityGrid();
  const setupHand = buildFacilitySetupHand(profile);
  const attackerDeck = [];
  const attackerTemplate = decks.attacker.length ? decks.attacker : CONQUEST_RUNTIME_DECK_DEFAULTS.attacker;
  while (attackerDeck.length < 60) {
    attackerDeck.push(String(attackerTemplate[attackerDeck.length % attackerTemplate.length]));
  }
  return {
    version: 1,
    worldId,
    planetId,
    active: false,
    underAttack: false,
    phase: 'setup',
    turn: 1,
    side: 'defender',
    drawActionsLeft: DEFENDER_MAX_DRAWS_PER_TURN,
    attackerPlaysLeft: ATTACKER_MAX_PLAYS_PER_TURN,
    defender: {
      wheat: 0,
      iron: 0,
      wheatCap: 10,
      ironCap: 10,
      hand: setupHand,
      drawDecks: {
        training: shuffledConquestDeck(decks.training),
        factory: shuffledConquestDeck(decks.factory),
        blacksmith: shuffledConquestDeck(decks.blacksmith),
        command: shuffledConquestDeck(decks.command),
        vehicle: shuffledConquestDeck(decks.vehicle),
        ordnance: shuffledConquestDeck(decks.ordnance),
        air: shuffledConquestDeck(decks.air),
        power: shuffledConquestDeck(decks.power),
        recovery: shuffledConquestDeck(decks.recovery),
        experimental: shuffledConquestDeck(decks.experimental),
      },
      discard: [],
      drawHistory: {
        training: [],
        factory: [],
        blacksmith: [],
        command: [],
        vehicle: [],
        ordnance: [],
        air: [],
        power: [],
        recovery: [],
        experimental: [],
      },
      lastCapClamp: null,
      blacksmithDrawnOnTurn: 0,
      tempWheatDiscount: 0,
      tempIronDiscount: 0,
      trainingDiscountCharges: 0,
      trainingDiscountChargesPerTurn: 0,
      factoryBonusDrawEveryOther: false,
    },
    attacker: {
      mana: 1,
      manaPylons: 1,
      homesteadDeployed: false,
      hand: [],
      deck: attackerDeck,
      discard: [],
    },
    grid,
    log: [
      { ts: Date.now(), text: 'Setup phase active. Place your starting facilities, barricades, and turrets before the assault begins.', level: 'info' },
    ],
    winner: null,
    outcomeAppliedAt: 0,
    lastDraw: null,
    encounter: null,
    matSettings: normalizeConquestMatSettings(null),
    setupPresets: defaultFacilitySetupPresets(),
    conquestDecks: decks,
    playerSide: 'defender',
    aiControl: {
      attacker: true,
      defender: false,
    },
  };
}

function generateObjectivesForPlanet(worldId, planetId, factionId = 'neutral', techLevel = 1, danger = 1, objectiveTarget = 4) {
  const rand = rngFromSeed(`${worldId}-${planetId}-${factionId}-${techLevel}-${danger}`);
  const desired = clamp(Math.floor(toFiniteNumber(objectiveTarget, 4)), 3, 8);
  const shuffled = [...OBJECTIVE_LIBRARY].sort(() => rand() - 0.5);
  const entries = [];
  for (let i = 0; i < desired; i += 1) {
    const title = shuffled[i % shuffled.length];
    const triangles = clamp(1 + Math.floor(rand() * 4) + Math.floor(danger / 4), 1, 6);
    const aiSkillStars = clamp(1 + Math.floor(rand() * 3) + Math.floor(danger / 5), 1, 5);
    const objTech = clamp(techLevel + Math.floor(rand() * 3), 1, 10);
    const deckVariant = conquestDeckVariantForStars(aiSkillStars);
    entries.push({
      id: `${planetId}-obj-${i + 1}`,
      title,
      regionName: objectiveRegionName(`${worldId}-${planetId}`, i + 1),
      type: 'conquest',
      status: 'pending',
      deckTriangles: triangles,
      deckSizeEstimate: triangles * 10,
      aiSkillStars,
      deckVariant,
      deckSeries: conquestDeckSeriesName(factionId, triangles, deckVariant),
      deckDoctrine: conquestDoctrineLabelForThreat(factionId, aiSkillStars),
      techLevel: objTech,
      strategicEffect: aiSkillStars >= 4 ? 'High command node' : 'Regional control point',
      rewards: {
        gold: 50 + (triangles * 12),
        production: 1 + Math.floor(triangles / 3),
      },
      lore: `${title} has become a critical objective for ${factionId}.`,
      battleType: 'defense_conquest',
    });
  }
  return entries;
}

function worldCardTag(id = '') {
  return `world:${String(id).toLowerCase()}`;
}

function updateConquestMeter(worldState) {
  const planets = Array.isArray(worldState?.planets) ? worldState.planets : [];
  const capital = planets.find((planet) => planet?.id === worldState?.capitalPlanetId)
    ?? planets.find((planet) => planet?.isCapital)
    ?? planets[0]
    ?? null;
  const total = capital ? (capital.objectives?.length ?? 0) : 0;
  const done = capital ? (capital.objectives ?? []).filter((entry) => entry.status === 'completed').length : 0;
  worldState.conquest = {
    totalObjectives: total,
    completedObjectives: done,
    meter: total > 0 ? clamp((done / total) * 100, 0, 100) : 0,
  };
}

function ensureCampaignWorldState(campaign, node, ownerAi = null, profileState = null) {
  const worldId = node.id;
  if (!campaign.worldStates[worldId]) {
    const rand = rngFromSeed(`${worldId}-campaign-${node.seed}`);
    const planetTotal = clamp(node.planetCount ?? 6, 1, 14);
    const capitalIndex = clamp(Math.floor(rand() * planetTotal), 0, Math.max(0, planetTotal - 1));
    const techLevel = clamp(1 + Math.floor(rand() * 4) + Math.floor((ownerAi?.level ?? 1) / 9), 1, 10);
    const factionId = ownerAi?.faction ? slugifyId(ownerAi.faction) : (node.ownerName ? slugifyId(node.ownerName) : 'neutral');
    const planets = Array.from({ length: planetTotal }, (_, idx) => {
      const planetId = `${worldId}-p${idx + 1}`;
      const danger = clamp(2 + Math.floor(rand() * 8), 1, 10);
      const sizeClass = planetSizeClass(worldId, idx + 1);
      const isCapital = idx === capitalIndex;
      const strongholdTarget = strongholdsForPlanet(sizeClass);
      const conquestDecks = defaultConquestDecks();
      return {
        id: planetId,
        name: generatePlanetName(node.name, worldId, idx + 1),
        biome: PLANET_BIOMES[Math.floor(rand() * PLANET_BIOMES.length)],
        isCapital,
        sizeClass,
        danger,
        strongholdsRequired: isCapital ? strongholdTarget : 0,
        strongholdsCaptured: 0,
        ownership: isCapital ? 'contested' : 'neutral',
        objectives: isCapital ? generateObjectivesForPlanet(worldId, planetId, factionId, techLevel, danger, strongholdTarget) : [],
        buildings: [],
        buildingCapacity: 8,
        favor: clamp(48 + Math.floor(rand() * 18), 10, 90),
        income: 0,
        production: 0,
        reinforcementPool: {},
        conquestDecks,
        facilityWar: createFacilityWarState(worldId, planetId, conquestDecks),
      };
    });
    campaign.worldStates[worldId] = {
      worldId,
      nodeId: worldId,
      universe: node.universe ?? 'Unknown',
      worldName: node.name,
      speciesTag: worldCardTag(worldId),
      factionId,
      ownerAiId: ownerAi?.id ?? node.occupiedByAIId ?? null,
      duelDefeated: !!(profileState?.defeatedAiIds ?? []).includes(ownerAi?.id ?? ''),
      conquestUnlocked: !!(profileState?.defeatedAiIds ?? []).includes(ownerAi?.id ?? ''),
      secured: false,
      lost: false,
      techLevel,
      favor: 56,
      capitalPlanetId: planets[capitalIndex]?.id ?? planets[0]?.id ?? null,
      planets,
      economy: { income: 0, production: 0, defenseBonus: 0 },
      producedCards: {},
      buildHistory: [],
    };
  }
  const worldState = campaign.worldStates[worldId];
  if (!worldState.capitalPlanetId) {
    worldState.capitalPlanetId = worldState.planets?.find((planet) => planet?.isCapital)?.id
      ?? worldState.planets?.[0]?.id
      ?? null;
  }
  if (ownerAi?.id && (profileState?.defeatedAiIds ?? []).includes(ownerAi.id)) {
    worldState.duelDefeated = true;
    worldState.conquestUnlocked = true;
  }
  (worldState.planets ?? []).forEach((planet) => {
    const isCapital = planet.id === worldState.capitalPlanetId || !!planet.isCapital;
    planet.isCapital = isCapital;
    planet.sizeClass = planet.sizeClass ?? planetSizeClass(worldId, Number(String(planet.id).split('p').at(-1) ?? 1));
    planet.strongholdsRequired = isCapital
      ? Math.max(3, Number(planet.strongholdsRequired ?? strongholdsForPlanet(planet.sizeClass)))
      : 0;
    planet.strongholdsCaptured = isCapital ? Math.max(0, Number(planet.strongholdsCaptured ?? 0)) : 0;
    if (isCapital) {
      planet.conquestDecks = normalizeConquestDecks(planet.conquestDecks);
      planet.facilityWar = planet.facilityWar && typeof planet.facilityWar === 'object'
        ? { ...createFacilityWarState(worldId, planet.id, planet.conquestDecks), ...planet.facilityWar, conquestDecks: normalizeConquestDecks(planet.facilityWar.conquestDecks ?? planet.conquestDecks) }
        : createFacilityWarState(worldId, planet.id, planet.conquestDecks);
    } else {
      planet.conquestDecks = planet.conquestDecks ?? null;
      planet.facilityWar = planet.facilityWar ?? null;
    }
    if (isCapital && (!Array.isArray(planet.objectives) || !planet.objectives.length)) {
      planet.objectives = generateObjectivesForPlanet(
        worldId,
        planet.id,
        worldState.factionId,
        worldState.techLevel,
        planet.danger ?? 4,
        planet.strongholdsRequired,
      );
    } else if (!isCapital) {
      planet.objectives = [];
      if (planet.ownership === 'owned') planet.ownership = 'neutral';
    }
    planet.strongholdsCaptured = isCapital ? planet.objectives.filter((entry) => entry.status === 'completed').length : 0;
  });
  updateConquestMeter(worldState);
  return worldState;
}

function applyPlanetEconomy(worldState) {
  let income = 0;
  let production = 0;
  let defenseBonus = 0;
  let favorShift = 0;
  (worldState.planets ?? []).forEach((planet) => {
    let planetIncome = 0;
    let planetProduction = 0;
    let planetDefense = 0;
    (planet.buildings ?? []).forEach((buildingId) => {
      const meta = BUILDING_LIBRARY[buildingId];
      if (!meta) return;
      planetIncome += meta.income ?? 0;
      planetProduction += meta.production ?? 0;
      planetDefense += meta.defense ?? 0;
      favorShift += meta.favor ?? 0;
    });
    planet.income = planetIncome;
    planet.production = planetProduction;
    income += planetIncome;
    production += planetProduction;
    defenseBonus += planetDefense;
  });
  worldState.favor = clamp(worldState.favor + Math.sign(favorShift) * Math.min(2, Math.abs(favorShift) * 0.15), 5, 100);
  worldState.economy = { income, production, defenseBonus };
}

function objectiveCompletion(planet) {
  const objectives = Array.isArray(planet?.objectives) ? planet.objectives : [];
  const total = objectives.length;
  const done = objectives.filter((entry) => entry.status === 'completed').length;
  return { total, done };
}

function reconcileWorldOwnership(campaign, worldState, profileState = null) {
  let changed = false;
  const trackStats = !!profileState;
  if (trackStats) ensureProfileStats(profileState);
  const prevWorldSecured = !!worldState?.secured;
  const prevWorldLost = !!worldState?.lost;
  const planets = Array.isArray(worldState?.planets) ? worldState.planets : [];
  const capitalPlanetId = worldState?.capitalPlanetId
    ?? planets.find((planet) => planet?.isCapital)?.id
    ?? planets[0]?.id
    ?? null;
  worldState.capitalPlanetId = capitalPlanetId;
  planets.forEach((planet) => {
    const isCapital = planet.id === capitalPlanetId;
    planet.isCapital = isCapital;
    const prevOwnership = planet.ownership ?? 'contested';
    const { total, done } = objectiveCompletion(planet);
    planet.strongholdsRequired = isCapital ? Math.max(3, Number((planet.strongholdsRequired ?? total) || 3)) : 0;
    planet.strongholdsCaptured = done;
    const nextOwnership = isCapital
      ? (total > 0 && done >= total ? 'owned' : 'contested')
      : 'neutral';
    if (planet.ownership !== nextOwnership) {
      planet.ownership = nextOwnership;
      changed = true;
      if (trackStats) {
        if (isCapital && prevOwnership !== 'owned' && nextOwnership === 'owned') {
          profileState.stats.planets.conquered = Math.max(0, Number(profileState.stats.planets.conquered ?? 0)) + 1;
        } else if (isCapital && prevOwnership === 'owned' && nextOwnership !== 'owned') {
          profileState.stats.planets.lost = Math.max(0, Number(profileState.stats.planets.lost ?? 0)) + 1;
        }
      }
    }
  });
  updateConquestMeter(worldState);
  const fullySecured = (worldState.conquest?.totalObjectives ?? 0) > 0
    && (worldState.conquest?.completedObjectives ?? 0) >= (worldState.conquest?.totalObjectives ?? 0);
  const anyOwnedPlanets = planets.some((entry) => entry.id === capitalPlanetId && entry.ownership === 'owned');
  if (fullySecured && !worldState.everSecured) {
    worldState.everSecured = true;
    changed = true;
  }
  if (worldState.secured !== fullySecured) {
    worldState.secured = fullySecured;
    changed = true;
    if (trackStats && !prevWorldSecured && fullySecured && !worldState.lost) {
      profileState.stats.worlds.conquered = Math.max(0, Number(profileState.stats.worlds.conquered ?? 0)) + 1;
    }
  }
  if (worldState.lost && anyOwnedPlanets) {
    worldState.lost = false;
    changed = true;
  } else if (!worldState.lost && worldState.everSecured && !anyOwnedPlanets && !fullySecured) {
    worldState.lost = true;
    changed = true;
  }
  const worldId = worldState.worldId;
  campaign.ownedWorldIds = Array.isArray(campaign.ownedWorldIds) ? campaign.ownedWorldIds : [];
  campaign.lostWorldIds = Array.isArray(campaign.lostWorldIds) ? campaign.lostWorldIds : [];
  if (fullySecured && !worldState.lost && !campaign.ownedWorldIds.includes(worldId)) {
    campaign.ownedWorldIds.push(worldId);
    changed = true;
  }
  if ((!fullySecured || worldState.lost) && campaign.ownedWorldIds.includes(worldId)) {
    campaign.ownedWorldIds = campaign.ownedWorldIds.filter((id) => id !== worldId);
    changed = true;
  }
  if (worldState.lost && !campaign.lostWorldIds.includes(worldId)) {
    campaign.lostWorldIds.push(worldId);
    changed = true;
    if (trackStats && !prevWorldLost) {
      profileState.stats.worlds.lost = Math.max(0, Number(profileState.stats.worlds.lost ?? 0)) + 1;
    }
  }
  if (!worldState.lost && campaign.lostWorldIds.includes(worldId)) {
    campaign.lostWorldIds = campaign.lostWorldIds.filter((id) => id !== worldId);
    changed = true;
  }
  campaign.speciesAccess = campaign.speciesAccess ?? {};
  const hasAccess = !!worldState.secured && !worldState.lost;
  if (campaign.speciesAccess[worldState.speciesTag] !== hasAccess) {
    campaign.speciesAccess[worldState.speciesTag] = hasAccess;
    changed = true;
  }
  campaign.ownedDimensions = Array.isArray(campaign.ownedDimensions) ? campaign.ownedDimensions : [];
  const dim = String(worldState.universe ?? worldState.worldName ?? '').trim();
  if (dim) {
    if (hasAccess && !campaign.ownedDimensions.includes(dim)) {
      campaign.ownedDimensions.push(dim);
      changed = true;
    }
    if (!hasAccess && campaign.ownedDimensions.includes(dim)) {
      campaign.ownedDimensions = campaign.ownedDimensions.filter((entry) => entry !== dim);
      changed = true;
    }
  }
  return changed;
}

function loadCreatorCustomCards() {
  try {
    const parsed = JSON.parse(localStorage.getItem(CUSTOM_CARD_LIBRARY_KEY) || '{}');
    return Object.values(parsed ?? {}).filter((entry) => entry && typeof entry === 'object');
  } catch {
    return [];
  }
}

function cardCampaignMeta(card = {}) {
  const raw = card.mtgMeta ?? card.campaignMeta ?? {};
  const production = card.production ?? {};
  return {
    battleCompatibility: String(card.battleCompatibility ?? raw.battleCompatibility ?? 'both').toLowerCase(),
    producible: !!(production.producible ?? raw.producible ?? false),
    productionBuildingType: String(production.buildingType ?? raw.productionBuildingType ?? '').trim().toLowerCase(),
    speciesOrigin: String(production.speciesOrigin ?? raw.speciesOrigin ?? card.race ?? '').trim().toLowerCase(),
    worldOrigin: String(production.worldOrigin ?? raw.worldOrigin ?? card.homeDimension ?? '').trim(),
    techRequirement: Math.max(0, toFiniteNumber(production.techRequirement ?? raw.techRequirement ?? 0)),
    favorRequirement: Math.max(0, toFiniteNumber(production.favorRequirement ?? raw.favorRequirement ?? 0)),
    productionCostGold: Math.max(0, toFiniteNumber(production.productionCostGold ?? raw.productionCostGold ?? 0)),
    productionCostLifeforce: Math.max(0, toFiniteNumber(production.productionCostLifeforce ?? raw.productionCostLifeforce ?? 0)),
    reinforcementTier: Math.max(1, toFiniteNumber(production.reinforcementTier ?? raw.reinforcementTier ?? 1)),
    unlockByWorld: String(production.unlockByWorld ?? raw.unlockByWorld ?? '').trim(),
    loseWithWorld: !!(production.loseWithWorld ?? raw.loseWithWorld ?? false),
    requiredModes: String(production.requiredModes ?? raw.requiredModes ?? '').trim().toLowerCase(),
  };
}

function cardAvailabilityForWorld(profileState, worldState, card, { forProduction = false } = {}) {
  const campaign = getMapWorld(profileState).campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const meta = cardCampaignMeta(card);
  const speciesAccess = campaign.speciesAccess ?? {};
  const worldId = String(worldState?.worldId ?? '');
  const worldTech = Math.max(0, toFiniteNumber(worldState?.techLevel, 0));
  const worldFavor = Math.max(0, toFiniteNumber(worldState?.favor, 0));
  if (meta.battleCompatibility === 'duel_only' && forProduction) return { available: false, reason: 'Duel-only card.' };
  if (forProduction && !meta.producible) return { available: false, reason: 'Not marked as producible.' };
  if (meta.unlockByWorld && !campaign.ownedWorldIds?.includes(meta.unlockByWorld)) {
    return { available: false, reason: `Requires owning world ${meta.unlockByWorld}.` };
  }
  if (meta.loseWithWorld && meta.unlockByWorld && campaign.lostWorldIds?.includes(meta.unlockByWorld)) {
    return { available: false, reason: `Unavailable: world ${meta.unlockByWorld} is lost.` };
  }
  if (meta.worldOrigin && meta.worldOrigin !== worldId && meta.worldOrigin !== worldState?.universe) {
    return { available: false, reason: `Origin-locked to ${meta.worldOrigin}.` };
  }
  if (meta.speciesOrigin && speciesAccess[meta.speciesOrigin] === false) {
    return { available: false, reason: `Species access for ${meta.speciesOrigin} is lost.` };
  }
  if (meta.techRequirement > worldTech) return { available: false, reason: `Requires tech ${meta.techRequirement}.` };
  if (meta.favorRequirement > worldFavor) return { available: false, reason: `Requires favor ${meta.favorRequirement}.` };
  if (forProduction && meta.productionBuildingType) {
    const normalizedBuildings = (worldState?.planets ?? [])
      .flatMap((planet) => planet.buildings ?? [])
      .map((entry) => String(entry).toLowerCase());
    if (!normalizedBuildings.includes(meta.productionBuildingType)) {
      return { available: false, reason: `Requires ${meta.productionBuildingType} building.` };
    }
  }
  return { available: true, reason: '' };
}

function cardFactoryPool(profileState, worldState) {
  const customDefs = Array.isArray(profileState.customPackDefs) ? profileState.customPackDefs : [];
  const customPackCards = customDefs.flatMap((pack) => Array.isArray(pack.cards) ? pack.cards : []);
  const creatorCards = loadCreatorCustomCards();
  const combined = [...customPackCards, ...creatorCards];
  const tags = [worldState.speciesTag, `faction:${worldState.factionId}`, `world:${worldState.worldId}`]
    .map((entry) => String(entry).toLowerCase());
  const tagged = combined.filter((card) => {
    const cardTags = Array.isArray(card.tags) ? card.tags.map((t) => String(t).toLowerCase()) : [];
    const meta = cardCampaignMeta(card);
    const modeCompat = meta.battleCompatibility !== 'duel_only';
    const thematicMatch = tags.some((tag) => cardTags.includes(tag))
      || meta.speciesOrigin === String(worldState.speciesTag ?? '').toLowerCase()
      || meta.worldOrigin === String(worldState.worldId ?? '')
      || meta.worldOrigin === String(worldState.universe ?? '');
    return modeCompat && thematicMatch;
  }).map((card) => {
    const availability = cardAvailabilityForWorld(profileState, worldState, card, { forProduction: true });
    return { ...card, availability };
  });
  if (tagged.length) return tagged;

  const corePool = Array.isArray(cachedCardPacks) ? cachedCardPacks : [];
  return corePool.slice(0, 12).map((pack, idx) => ({
    id: `prod-${worldState.worldId}-${idx + 1}`,
    name: `${worldState.worldName} Reinforcement ${idx + 1}`,
    cost: 2 + (idx % 6),
    rarity: idx % 9 === 0 ? 'legendary' : idx % 5 === 0 ? 'epic' : idx % 2 === 0 ? 'rare' : 'common',
    tags: [worldState.speciesTag],
    availability: { available: true, reason: '' },
  }));
}

function allAlienFactions() {
  const source = cachedAlienFactions.length ? cachedAlienFactions : FALLBACK_ALIEN_FACTIONS;
  const merged = [...source, ...CONQUEST_EXTRA_THREAT_FACTIONS];
  const deduped = merged.filter((faction, idx, arr) => arr.findIndex((other) => other?.id === faction?.id) === idx);
  return deduped.map((faction) => enrichFactionWithCommanders(faction));
}

function playerOccupiedDimensionNodes(nodes = []) {
  return (nodes ?? []).filter((node) => node.playerHome || node.stateTag === 'playerOwned');
}

function chooseAlienTargetNode(nodes = [], currentNodeId = '', seed = '') {
  const occupied = playerOccupiedDimensionNodes(nodes);
  if (!occupied.length) return null;
  const pool = occupied.filter((node) => node.id !== currentNodeId);
  const source = pool.length ? pool : occupied;
  const rand = rngFromSeed(`${seed}-${currentNodeId}-${occupied.length}`);
  return source[Math.floor(rand() * source.length)] ?? source[0] ?? null;
}

function chooseInvasionPlanetForWorld(worldState, preferredPlanetId = '') {
  const planets = Array.isArray(worldState?.planets) ? worldState.planets : [];
  if (!planets.length) return null;
  const capital = planets.find((entry) => entry.id === worldState?.capitalPlanetId)
    ?? planets.find((entry) => entry.isCapital)
    ?? planets[0];
  if (preferredPlanetId) {
    const preferred = planets.find((entry) => entry.id === preferredPlanetId);
    if (preferred && preferred.id === capital?.id) return preferred;
  }
  return capital ?? null;
}

function resolveAlienThreatPlanetId(threat, worldState) {
  if (!threat || !worldState) return null;
  if (threat.targetPlanetId && (worldState.planets ?? []).some((entry) => entry.id === threat.targetPlanetId)) {
    return threat.targetPlanetId;
  }
  const chosen = chooseInvasionPlanetForWorld(worldState);
  if (!chosen) return null;
  threat.targetPlanetId = chosen.id;
  return chosen.id;
}

function applyAlienSiegePressure(campaign, profileState = null) {
  const threats = Array.isArray(campaign?.activeThreats) ? campaign.activeThreats : [];
  const worldStates = campaign?.worldStates ?? {};
  let changed = false;
  threats.forEach((threat) => {
    if (!threat || threat.threatType !== 'alien' || threat.resolved || threat.status !== 'siege') return;
    const worldId = String(threat.currentNodeId ?? threat.nodeId ?? threat.targetNodeId ?? '');
    if (!worldId) return;
    const world = worldStates[worldId];
    if (!world) return;
    const planet = chooseInvasionPlanetForWorld(world, threat.targetPlanetId);
    if (!planet) return;
    threat.targetPlanetId = planet.id;
    const gain = clamp(10 + Number(threat.aiSkillStars ?? 1) * 3 + Number(threat.techLevel ?? 1), 8, 36);
    const nextPressure = Number(threat.siegePressure ?? 0) + gain;
    threat.siegePressure = nextPressure;
    if (nextPressure < 100) return;

    threat.siegePressure = nextPressure - 100;
    ensurePlanetConquestState(world, planet);
    const completed = (planet.objectives ?? []).filter((entry) => entry.status === 'completed');
    if (completed.length) {
      const targetObjective = completed[completed.length - 1];
      targetObjective.status = 'pending';
      targetObjective.rewardGranted = false;
      targetObjective.lastResult = 'loss';
      targetObjective.lastBattleAt = Date.now();
    }
    planet.strongholdsCaptured = Math.max(0, Number(planet.strongholdsCaptured ?? 0) - 1);
    planet.ownership = 'contested';
    campaign.eventHistory = [...(campaign.eventHistory ?? []), {
      ts: Date.now(),
      severity: 'danger',
      text: `${threat.factionName ?? 'Alien fleet'} overran strongholds on ${planet.name}.`,
    }].slice(-80);
    changed = true;

    const capitalId = world.capitalPlanetId
      ?? (world.planets ?? []).find((entry) => entry?.isCapital)?.id
      ?? (world.planets ?? [])[0]?.id;
    const anyOwned = (world.planets ?? []).some((entry) => entry.id === capitalId && entry.ownership === 'owned');
    if (!anyOwned) {
      const wasLost = !!world.lost;
      world.lost = true;
      world.secured = false;
      if (!wasLost) {
        campaign.eventHistory = [...(campaign.eventHistory ?? []), {
          ts: Date.now(),
          severity: 'danger',
          text: `${world.worldName} has fallen under ${threat.factionName ?? 'alien'} occupation.`,
        }].slice(-80);
      }
    }
  });
  if (changed) {
    Object.values(worldStates).forEach((world) => {
      if (!world) return;
      if (reconcileWorldOwnership(campaign, world, profileState)) changed = true;
    });
  }
  return changed;
}

function enforceSingleActiveAlienThreat(campaign) {
  const activeAliens = (campaign.activeThreats ?? [])
    .filter((threat) => threat?.threatType === 'alien' && !threat.resolved)
    .sort((a, b) => toFiniteNumber(b.createdAt, 0) - toFiniteNumber(a.createdAt, 0));
  if (activeAliens.length <= 1) return false;
  const keepId = activeAliens[0].id;
  let changed = false;
  campaign.activeThreats = (campaign.activeThreats ?? []).map((threat) => {
    if (threat?.threatType !== 'alien' || threat.resolved || threat.id === keepId) return threat;
    changed = true;
    return { ...threat, resolved: true, resolvedReason: 'fleet_cap' };
  });
  return changed;
}

function moveAlienThreats(campaign, nodes = []) {
  const byId = Object.fromEntries((nodes ?? []).map((node) => [node.id, node]));
  const occupiedTargets = playerOccupiedDimensionNodes(nodes);
  if (!occupiedTargets.length) return false;
  let changed = false;
  const now = Date.now();
  (campaign.activeThreats ?? []).forEach((threat) => {
    if (!threat || threat.threatType !== 'alien' || threat.resolved) return;
    const baseNodeId = threat.currentNodeId ?? threat.nodeId ?? occupiedTargets[0].id;
    if (!byId[baseNodeId]) {
      const fallback = occupiedTargets[0];
      threat.currentNodeId = fallback.id;
      threat.nodeId = fallback.id;
      threat.travelProgress = 0;
      changed = true;
    } else if (!threat.currentNodeId) {
      threat.currentNodeId = baseNodeId;
      changed = true;
    }

    const activeTarget = byId[threat.targetNodeId];
    if (!activeTarget || activeTarget.stateTag !== 'playerOwned') {
      const nextTarget = chooseAlienTargetNode(nodes, threat.currentNodeId, `${threat.id}-target-${now}`);
      if (nextTarget) {
        threat.targetNodeId = nextTarget.id;
        const worldState = campaign?.worldStates?.[nextTarget.id];
        const targetPlanet = chooseInvasionPlanetForWorld(worldState, threat.targetPlanetId);
        if (targetPlanet) threat.targetPlanetId = targetPlanet.id;
        if (!threat.nodeId) threat.nodeId = nextTarget.id;
        changed = true;
      }
    }

    const fromNode = byId[threat.currentNodeId] ?? occupiedTargets[0];
    const toNode = byId[threat.targetNodeId] ?? fromNode;
    if (Number(threat.siegeTurnsRemaining ?? 0) > 0 && toNode.id === fromNode.id) {
      threat.siegeTurnsRemaining = Math.max(0, Number(threat.siegeTurnsRemaining ?? 0) - 1);
      threat.status = 'siege';
      threat.objective = 'hold';
      threat.travelProgress = 0;
      threat.nodeId = toNode.id;
      changed = true;
      return;
    }
    const speed = clamp(toFiniteNumber(threat.moveSpeed, 0.14), 0.06, 0.36);
    threat.moveSpeed = speed;
    threat.status = 'moving';
    threat.objective = 'invade';

    if (toNode.id === fromNode.id) {
      const nextTarget = chooseAlienTargetNode(nodes, threat.currentNodeId, `${threat.id}-retarget-${now}`);
      if (nextTarget && nextTarget.id !== fromNode.id) {
        threat.targetNodeId = nextTarget.id;
        const worldState = campaign?.worldStates?.[nextTarget.id];
        const targetPlanet = chooseInvasionPlanetForWorld(worldState, threat.targetPlanetId);
        if (targetPlanet) threat.targetPlanetId = targetPlanet.id;
      } else {
        threat.travelProgress = 0;
        threat.status = 'siege';
        threat.objective = 'hold';
        threat.nodeId = toNode.id;
        threat.siegeTurnsRemaining = Math.max(1, Number(threat.siegeTurnsRemaining ?? 1));
      }
      return;
    }

    const prevProgress = clamp(toFiniteNumber(threat.travelProgress, 0), 0, 1);
    const nextProgress = clamp(prevProgress + speed, 0, 1);
    if (nextProgress !== prevProgress) {
      threat.travelProgress = nextProgress;
      changed = true;
    }
    if (nextProgress >= 1) {
      threat.currentNodeId = toNode.id;
      threat.nodeId = toNode.id;
      threat.travelProgress = 0;
      threat.lastMovedAt = now;
      threat.movementTick = Math.max(0, Math.floor(toFiniteNumber(threat.movementTick, 0)) + 1);
      threat.status = 'siege';
      threat.objective = 'hold';
      const worldState = campaign?.worldStates?.[toNode.id];
      const targetPlanet = chooseInvasionPlanetForWorld(worldState, threat.targetPlanetId);
      if (targetPlanet) threat.targetPlanetId = targetPlanet.id;
      threat.siegeTurnsRemaining = clamp(2 + Math.floor(rngFromSeed(`${threat.id}-${threat.movementTick}-${now}`)() * 3), 2, 5);
      const retarget = chooseAlienTargetNode(nodes, threat.currentNodeId, `${threat.id}-retarget-${threat.movementTick}`);
      if (retarget && retarget.id !== threat.currentNodeId) threat.targetNodeId = retarget.id;
      changed = true;
    }
  });
  return changed;
}

function classifyAlienThreatRank(triangles = 2, aiSkillStars = 1, techLevel = 1) {
  if (triangles >= 6 && aiSkillStars >= 4 && techLevel >= 7) return 'boss';
  if (triangles >= 4 || aiSkillStars >= 3 || techLevel >= 5) return 'elite';
  return 'standard';
}

function pickAlienCommanderForThreat(faction = {}, seed = '', rank = 'standard') {
  const rand = rngFromSeed(`${seed}-${faction.id ?? 'alien'}-${rank}`);
  if (rank === 'boss' && toArray(faction.bosses).length) {
    const bosses = toArray(faction.bosses);
    return bosses[Math.floor(rand() * bosses.length)];
  }
  if ((rank === 'elite' || rank === 'boss') && toArray(faction.elites).length) {
    const elites = toArray(faction.elites);
    return elites[Math.floor(rand() * elites.length)];
  }
  const blended = [...toArray(faction.elites), ...toArray(faction.bosses)];
  if (blended.length) return blended[Math.floor(rand() * blended.length)];
  return null;
}

function spawnAlienThreat(campaign, nodes, seedSalt = '') {
  const activeAlien = (campaign.activeThreats ?? []).find((threat) => threat?.threatType === 'alien' && !threat.resolved);
  if (activeAlien) return null;
  const occupiedTargets = playerOccupiedDimensionNodes(nodes);
  if (!occupiedTargets.length) return null;
  const nonOwnedSpawnNodes = (nodes ?? []).filter((node) => !node.playerHome && node.stateTag !== 'hidden' && node.stateTag !== 'playerOwned');
  const spawnPool = nonOwnedSpawnNodes.length ? nonOwnedSpawnNodes : occupiedTargets;
  const rand = rngFromSeed(`${Date.now()}-alien-${seedSalt}-${spawnPool.length}`);
  const faction = pickRandom(allAlienFactions(), `${Date.now()}-${seedSalt}`) ?? FALLBACK_ALIEN_FACTIONS[0];
  const originNode = spawnPool[Math.floor(rand() * spawnPool.length)];
  const targetNode = occupiedTargets[Math.floor(rand() * occupiedTargets.length)];
  const targetWorld = campaign?.worldStates?.[targetNode.id];
  const targetPlanet = chooseInvasionPlanetForWorld(targetWorld);
  let triangles = clamp(1 + Math.floor(rand() * 6), 1, 6);
  let aiSkillStars = clamp((faction.aiSkillRange?.[0] ?? 1) + Math.floor(rand() * ((faction.aiSkillRange?.[1] ?? 4) - (faction.aiSkillRange?.[0] ?? 1) + 1)), 1, 5);
  let techLevel = clamp((faction.techLevelRange?.[0] ?? 2) + Math.floor(rand() * ((faction.techLevelRange?.[1] ?? 8) - (faction.techLevelRange?.[0] ?? 2) + 1)), 1, 12);
  const rank = classifyAlienThreatRank(triangles, aiSkillStars, techLevel);
  const commander = pickAlienCommanderForThreat(faction, `${seedSalt}-${Date.now()}-${targetNode.id}`, rank);
  if (rank === 'elite') {
    aiSkillStars = Math.max(aiSkillStars, 3);
    techLevel = Math.max(techLevel, 5);
    triangles = Math.max(triangles, 3);
  } else if (rank === 'boss') {
    aiSkillStars = Math.max(aiSkillStars, 4);
    techLevel = Math.max(techLevel, 8);
    triangles = Math.max(triangles, 5);
  }
  const deckVariant = conquestDeckVariantForStars(aiSkillStars);
  const deckSeries = conquestDeckSeriesName(faction.id, triangles, deckVariant);
  const deckSizeEstimate = triangles * 10;
  const threat = {
    type: MAP_TYPES.ThreatGroup,
    id: `alien-threat-${Date.now()}-${Math.floor(rand() * 999)}`,
    threatType: 'alien',
    factionId: faction.id,
    factionName: faction.name,
    nodeId: targetNode.id,
    currentNodeId: originNode.id,
    targetNodeId: targetNode.id,
    targetPlanetId: targetPlanet?.id ?? null,
    travelProgress: 0,
    moveSpeed: clamp(0.12 + (rand() * 0.16), 0.06, 0.33),
    movementTick: 0,
    region: targetNode.universe ?? targetNode.name,
    deckTriangles: triangles,
    deckSizeEstimate,
    deckVariant,
    deckSeries,
    deckDoctrine: conquestDoctrineLabelForThreat(faction.id, aiSkillStars),
    aiSkillStars,
    techLevel,
    color: faction.color ?? '#56e98f',
    icon: faction.icon ?? '△',
    objective: 'invade',
    status: 'moving',
    deckTags: toArray(faction.deckTags),
    threatStyle: String(faction.threatStyle ?? faction.reinforcementStyle ?? 'standard'),
    behaviorNotes: String(faction.behaviorNotes ?? ''),
    attackPattern: String(faction.attackPattern ?? faction.behaviorNotes ?? 'Pushes conquest lanes with coordinated assaults.'),
    strengths: toArray(faction.strengths),
    weaknesses: toArray(faction.weaknesses),
    unitRoster: toArray(faction.unitRoster),
    specialTraits: toArray(faction.specialTraits),
    siegePressure: 0,
    siegeTurnsRemaining: 0,
    commanderRank: rank,
    commanderId: commander?.id ?? null,
    commanderName: commander?.name ?? null,
    commanderTitle: commander?.title ?? null,
    commanderPersonality: commander?.personality ?? null,
    commanderPlaystyle: commander?.playstyle ?? null,
    commanderLore: commander?.lore ?? null,
    signatureMechanics: toArray(commander?.signatureMechanics),
    signatureCards: toArray(commander?.signatureCards),
    commanderDialogue: commander?.dialogue ?? {},
    createdAt: Date.now(),
  };
  campaign.activeThreats = [...(campaign.activeThreats ?? []), threat].slice(-24);
  const commanderText = threat.commanderName
    ? `${threat.commanderName}${threat.commanderTitle ? `, ${threat.commanderTitle}` : ''}`
    : null;
  campaign.eventHistory = [...(campaign.eventHistory ?? []), {
    ts: Date.now(),
    text: `${threat.factionName} ${rank === 'standard' ? 'fleet' : `${rank} fleet`} entered from ${originNode.name} and is advancing on ${targetNode.name} (${threat.deckSizeEstimate} cards${commanderText ? ` • ${commanderText}` : ''}).`,
    severity: rank === 'boss' || threat.aiSkillStars >= 4 ? 'danger' : 'warn',
  }].slice(-80);
  return threat;
}

function buildPlayerHomeCampaignNode(profileState, attackers = null) {
  const homeId = String(attackers?.warpKey?.dimensionId ?? 'player-home');
  if (!homeId) return null;
  return {
    id: homeId,
    name: 'Your Dimension',
    seed: normalizeSeed(getSessionSeed()),
    universe: 'Home Dimension',
    planetCount: 6,
    playerHome: true,
    stateTag: attackers?.warpKey?.compromised ? 'compromised' : 'playerOwned',
    occupiedByAIId: 'player-home',
    ownerName: 'You',
  };
}

function runCampaignTick(profileState, candidateNodes, aiProfiles, attackers = null, mapWorld = null) {
  const resolvedMapWorld = mapWorld ?? getMapWorldFast(profileState);
  const campaign = resolvedMapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  let changed = false;
  const nodesForCampaign = Array.isArray(candidateNodes) ? [...candidateNodes] : [];
  const playerHomeNode = buildPlayerHomeCampaignNode(profileState, attackers);
  if (playerHomeNode && !nodesForCampaign.some((node) => node.id === playerHomeNode.id)) {
    nodesForCampaign.push(playerHomeNode);
  }
  nodesForCampaign.forEach((node) => {
    const ownerAi = node.playerHome
      ? { id: 'player-home', name: 'Player', faction: 'player-home', level: Math.max(1, Number(profileState.stats?.wins ?? 0) + 1) }
      : ownerAiForNode(node, aiProfiles);
    const world = ensureCampaignWorldState(campaign, node, ownerAi, profileState);
    if (node.playerHome) {
      if (!world.homeAutoOwned) {
        world.homeAutoOwned = true;
        world.duelDefeated = true;
        world.conquestUnlocked = true;
        world.secured = true;
        world.lost = false;
        world.ownerAiId = 'player-home';
        world.factionId = 'player-home';
        (world.planets ?? []).forEach((planet) => {
          planet.ownership = 'owned';
          (planet.objectives ?? []).forEach((objective) => {
            objective.status = 'completed';
            objective.rewardGranted = true;
            objective.lastResult = objective.lastResult ?? 'win';
          });
        });
        updateConquestMeter(world);
        changed = true;
      }
      applyPlanetEconomy(world);
      if (reconcileWorldOwnership(campaign, world, null)) changed = true;
      campaign.speciesAccess = campaign.speciesAccess ?? {};
      if (campaign.speciesAccess[world.speciesTag] !== true) {
        campaign.speciesAccess[world.speciesTag] = true;
        changed = true;
      }
      campaign.ownedWorldIds = Array.isArray(campaign.ownedWorldIds) ? campaign.ownedWorldIds : [];
      if (!campaign.ownedWorldIds.includes(world.worldId)) {
        campaign.ownedWorldIds.push(world.worldId);
        changed = true;
      }
      campaign.lostWorldIds = Array.isArray(campaign.lostWorldIds) ? campaign.lostWorldIds : [];
      if (campaign.lostWorldIds.includes(world.worldId)) {
        campaign.lostWorldIds = campaign.lostWorldIds.filter((id) => id !== world.worldId);
        changed = true;
      }
      campaign.ownedDimensions = Array.isArray(campaign.ownedDimensions) ? campaign.ownedDimensions : [];
      const dim = String(world.universe ?? world.worldName ?? '').trim();
      if (dim && !campaign.ownedDimensions.includes(dim)) {
        campaign.ownedDimensions.push(dim);
        changed = true;
      }
      return;
    }
    applyPlanetEconomy(world);
    if (reconcileWorldOwnership(campaign, world, profileState)) changed = true;
  });
  const now = Date.now();
  const elapsed = campaign.lastProductionTickAt ? (now - campaign.lastProductionTickAt) : 0;
  if (elapsed >= 25000) {
    let incomeTotal = 0;
    let productionTotal = 0;
    Object.values(campaign.worldStates ?? {}).forEach((world) => {
      if (!world || world.lost) return;
      const income = Number(world.economy?.income ?? 0);
      const prod = Number(world.economy?.production ?? 0);
      incomeTotal += income;
      productionTotal += prod;
      if (prod > 0) {
        const key = `reinforcement:${world.worldId}`;
        campaign.reinforcementPool[key] = Math.max(0, Number(campaign.reinforcementPool[key] ?? 0) + prod);
      }
    });
    profileState.economy = profileState.economy ?? { gold: 0, lifeforce: 0 };
    profileState.economy.gold = Number(profileState.economy.gold ?? 0) + incomeTotal;
    campaign.totalIncome = incomeTotal;
    campaign.lastProductionTickAt = now;
    campaign.eventHistory = [...(campaign.eventHistory ?? []), {
      ts: now,
      text: `Empire production tick: +${incomeTotal} gold, +${productionTotal} reinforcements.`,
      severity: 'info',
    }].slice(-80);
    changed = true;
  }
  if (enforceSingleActiveAlienThreat(campaign)) changed = true;
  if (moveAlienThreats(campaign, nodesForCampaign)) changed = true;
  if (applyAlienSiegePressure(campaign, profileState)) changed = true;
  const activeAlien = (campaign.activeThreats ?? []).find((threat) => threat?.threatType === 'alien' && !threat.resolved);
  const ownedTargets = playerOccupiedDimensionNodes(nodesForCampaign);
  if (!activeAlien && ownedTargets.length) {
    const rand = rngFromSeed(`${now}-${profileState.stats?.wins ?? 0}-${ownedTargets.length}`);
    const spawnChance = clamp(0.01 + ((profileState.stats?.wins ?? 0) * 0.001), 0.01, 0.1);
    if (rand() < spawnChance) {
      if (spawnAlienThreat(campaign, nodesForCampaign, String(profileState.stats?.wins ?? 0))) changed = true;
    }
  }
  const maxAge = 15 * 60 * 1000;
  const before = (campaign.activeThreats ?? []).length;
  campaign.activeThreats = (campaign.activeThreats ?? []).filter((threat) => (now - Number(threat.createdAt ?? now)) < maxAge && !threat.resolved);
  if (campaign.activeThreats.length !== before) changed = true;
  resolvedMapWorld.campaign = campaign;
  profileState.mapWorld = resolvedMapWorld;
  return { campaign, changed };
}

function mergeRoleWeights(houseWeights = {}, templateWeights = {}) {
  const out = {};
  Object.keys(PIRATE_ROLE_DEFS).forEach((role) => {
    out[role] = Math.max(0.01, toFiniteNumber(templateWeights?.[role], toFiniteNumber(houseWeights?.[role], 1)));
  });
  return out;
}

function normalizePirateHouseDef(raw = {}) {
  const id = slugifyId(raw.id || raw.name || `house-${Date.now()}`);
  const fallback = PIRATE_HOUSE_DEFAULTS[id] ?? {};
  return {
    id,
    name: raw.name ?? fallback.name ?? id,
    wielder: raw.wielder ?? fallback.wielder ?? 'Unknown Wielder',
    aiStyle: raw.aiStyle ?? fallback.aiStyle ?? 'adaptive',
    tone: raw.tone ?? '',
    styleId: raw.styleId ?? fallback.styleId ?? 'riftstorm',
    colorHint: raw.colorHint ?? fallback.colorHint ?? '#ff8d68',
    roleWeights: mergeRoleWeights(fallback.roleWeights ?? {}, raw.roleWeights ?? {}),
    levelRange: {
      min: Math.max(1, toFiniteNumber(raw.levelRange?.min, 1)),
      max: Math.max(1, toFiniteNumber(raw.levelRange?.max, 40)),
    },
  };
}

function normalizePirateCardCopy(template = {}, houseDef = {}, copyIndex = 0) {
  const baseName = String(template.name ?? `Pirate Card ${copyIndex + 1}`);
  const templateSlug = slugifyId(baseName || `card-${copyIndex + 1}`);
  const templateId = `${houseDef.id}-${templateSlug}`;
  const typeRaw = String(template.type ?? 'minion').toLowerCase();
  const type = ['minion', 'spell', 'relic'].includes(typeRaw) ? typeRaw : 'minion';
  const tags = [...new Set(['pirate', houseDef.id, ...toArray(template.tags)])];
  return {
    id: `${templateId}-${copyIndex + 1}`,
    templateId,
    houseId: houseDef.id,
    houseName: houseDef.name,
    styleId: houseDef.styleId,
    name: baseName,
    type,
    cost: Math.max(1, toFiniteNumber(template.cost, 1)),
    attack: Math.max(0, toFiniteNumber(template.attack, type === 'minion' ? 1 : 0)),
    health: Math.max(0, toFiniteNumber(template.health, type === 'minion' ? 1 : 0)),
    def: Math.max(0, toFiniteNumber(template.def, 0)),
    rarity: template.rarity ?? (template.signature ? 'legendary' : 'rare'),
    tags,
    keywords: toArray(template.keywords),
    roleWeights: mergeRoleWeights(houseDef.roleWeights, template.roleWeights ?? {}),
    levelMin: Math.max(1, toFiniteNumber(template.levelMin, houseDef.levelRange.min)),
    levelMax: Math.max(1, toFiniteNumber(template.levelMax, houseDef.levelRange.max)),
    bossOnly: !!template.bossOnly,
    signature: !!template.signature,
    text: template.text ?? '',
    effect: typeof template.effect === 'object' && template.effect ? template.effect : null,
  };
}

function expandPirateHousePack(pack = {}) {
  const houses = [];
  const cards = [];
  toArray(pack.houses).forEach((rawHouse) => {
    const house = normalizePirateHouseDef(rawHouse);
    houses.push(house);
    toArray(rawHouse.templates).forEach((template) => {
      const copies = Math.max(1, Math.min(8, Math.floor(toFiniteNumber(template.count, 1))));
      for (let i = 0; i < copies; i += 1) {
        cards.push(normalizePirateCardCopy(template, house, i));
      }
    });
  });
  return { houses, cards };
}

function houseById(id = '') {
  const normalized = slugifyId(id);
  return cachedPirateHouses.find((entry) => entry.id === normalized) ?? PIRATE_HOUSE_DEFAULTS[normalized] ?? null;
}

function traceStateLabel(trace = 0, exposed = false) {
  if (exposed) return 'Exposed';
  if (trace >= 70) return 'Tracked';
  if (trace >= 38) return 'Disturbed';
  return 'Hidden';
}

function normalizePirateRoamer(entry = {}) {
  const house = houseById(entry.houseId) ?? houseById(entry.houseName) ?? null;
  return {
    id: entry.id ?? `pirate-${Date.now()}-${Math.floor(Math.random() * 9999)}`,
    name: entry.name ?? 'Unregistered Corsair',
    role: entry.role ?? 'scout',
    level: Math.max(1, toFiniteNumber(entry.level, 4)),
    houseId: house?.id ?? slugifyId(entry.houseId ?? ''),
    houseName: entry.houseName ?? house?.name ?? 'Independent Raider Cell',
    houseWielder: entry.houseWielder ?? house?.wielder ?? null,
    styleId: entry.styleId ?? house?.styleId ?? PIRATE_ROLE_DEFS[entry.role]?.styleId ?? 'riftstorm',
    faction: entry.faction ?? 'Dimensional Attackers',
    objective: entry.objective ?? 'patrol',
    currentNodeId: entry.currentNodeId ?? null,
    targetNodeId: entry.targetNodeId ?? null,
    travelProgress: clamp(toFiniteNumber(entry.travelProgress, 0), 0, 1),
    speed: clamp(toFiniteNumber(entry.speed, 0.2), 0.08, 0.55),
    detectionPower: clamp(toFiniteNumber(entry.detectionPower, 1), 0.4, 2.4),
    aiProfileId: entry.aiProfileId ?? null,
    assignedPacks: Array.isArray(entry.assignedPacks) ? entry.assignedPacks : ['pirate_master_pool_v1'],
    escapeCountdown: Math.max(0, Math.floor(toFiniteNumber(entry.escapeCountdown, 0))),
    visible: entry.visible !== false,
    lastObjectiveShiftAt: toFiniteNumber(entry.lastObjectiveShiftAt, 0),
    createdAt: toFiniteNumber(entry.createdAt, Date.now()),
    rewardMeta: entry.rewardMeta ?? '',
    threat: clamp(toFiniteNumber(entry.threat, 4), 1, 14),
    chatterTier: entry.chatterTier ?? 'default',
    searchProgress: clamp(toFiniteNumber(entry.searchProgress, 0), 0, 100),
  };
}

function mergeDimensionalAttackersState(raw = {}) {
  const merged = {
    ...structuredClone(DIMENSIONAL_ATTACKERS_DEFAULTS),
    ...(raw ?? {}),
    battlePressure: {
      ...DIMENSIONAL_ATTACKERS_DEFAULTS.battlePressure,
      ...(raw?.battlePressure ?? {}),
    },
    bossState: {
      ...DIMENSIONAL_ATTACKERS_DEFAULTS.bossState,
      ...(raw?.bossState ?? {}),
    },
    warpKey: {
      ...DIMENSIONAL_ATTACKERS_DEFAULTS.warpKey,
      ...(raw?.warpKey ?? {}),
    },
    viroleanSea: {
      ...DIMENSIONAL_ATTACKERS_DEFAULTS.viroleanSea,
      ...(raw?.viroleanSea ?? {}),
    },
    scanChallenge: {
      ...DIMENSIONAL_ATTACKERS_DEFAULTS.scanChallenge,
      ...(raw?.scanChallenge ?? {}),
    },
    lastKnownStats: {
      ...DIMENSIONAL_ATTACKERS_DEFAULTS.lastKnownStats,
      ...(raw?.lastKnownStats ?? {}),
    },
    activePirates: Array.isArray(raw?.activePirates) ? raw.activePirates.map((entry) => normalizePirateRoamer(entry)) : [],
    sightings: Array.isArray(raw?.sightings) ? raw.sightings.slice(-32) : [],
    eventLog: Array.isArray(raw?.eventLog) ? raw.eventLog.slice(-60) : [],
    pirateDossier: Array.isArray(raw?.pirateDossier) ? raw.pirateDossier.slice(-80) : [],
  };
  merged.trace = clamp(toFiniteNumber(merged.trace, 0), 0, 100);
  merged.invasionProgress = clamp(toFiniteNumber(merged.invasionProgress, 0), 0, Math.max(100, toFiniteNumber(merged.invasionThreshold, 100)));
  merged.invasionThreshold = Math.max(60, toFiniteNumber(merged.invasionThreshold, 100));
  merged.pirateInfamy = clamp(toFiniteNumber(merged.pirateInfamy, 0), 0, 100);
  merged.pirateInfamyLabel = infamyLabel(merged.pirateInfamy);
  merged.playerExposed = !!merged.playerExposed || merged.invasionProgress >= merged.invasionThreshold;
  merged.traceState = traceStateLabel(merged.trace, merged.playerExposed);
  merged.viroleanSea.axis = clamp(toFiniteNumber(merged.viroleanSea.axis, DIMENSIONAL_ATTACKERS_DEFAULTS.viroleanSea.axis), 0.9, 0.98);
  merged.scanChallenge.active = !!merged.scanChallenge.active;
  merged.scanChallenge.pirateId = merged.scanChallenge.pirateId ?? null;
  merged.scanChallenge.scanNodeId = merged.scanChallenge.scanNodeId ?? null;
  merged.scanChallenge.slots = Array.isArray(merged.scanChallenge.slots) ? merged.scanChallenge.slots : [];
  merged.scanChallenge.emojiBank = Array.isArray(merged.scanChallenge.emojiBank) ? merged.scanChallenge.emojiBank : [];
  merged.scanChallenge.successCount = Math.max(0, Math.floor(toFiniteNumber(merged.scanChallenge.successCount, 0)));
  merged.scanChallenge.failCount = Math.max(0, Math.floor(toFiniteNumber(merged.scanChallenge.failCount, 0)));
  merged.scanChallenge.maxFails = Math.max(1, Math.floor(toFiniteNumber(merged.scanChallenge.maxFails, 3)));
  merged.scanChallenge.ticksLeft = Math.max(0, Math.floor(toFiniteNumber(merged.scanChallenge.ticksLeft, 0)));
  merged.scanChallenge.lastMessage = String(merged.scanChallenge.lastMessage ?? '');
  merged.scanChallenge.cooldownUntil = Math.max(0, toFiniteNumber(merged.scanChallenge.cooldownUntil, 0));
  merged.battlePressure.recentBattleStamps = (Array.isArray(merged.battlePressure.recentBattleStamps) ? merged.battlePressure.recentBattleStamps : [])
    .map((stamp) => toFiniteNumber(stamp, 0))
    .filter((stamp) => stamp > 0)
    .slice(-48);
  return merged;
}

function getDimensionalAttackers(mapWorld) {
  mapWorld.dimensionalAttackers = mergeDimensionalAttackersState(mapWorld.dimensionalAttackers ?? {});
  return mapWorld.dimensionalAttackers;
}

function pushPirateEvent(attackers, text, severity = 'info', meta = {}) {
  const entry = {
    id: `evt-${Date.now()}-${Math.floor(Math.random() * 9999)}`,
    text,
    severity,
    ts: Date.now(),
    ...meta,
  };
  attackers.eventLog = [...(attackers.eventLog ?? []), entry].slice(-60);
  if (meta.pirateId) {
    attackers.sightings = [...(attackers.sightings ?? []), {
      pirateId: meta.pirateId,
      nodeId: meta.nodeId ?? null,
      ts: entry.ts,
      text,
    }].slice(-32);
  }
}

function normalizeSeed(input) {
  const normalized = String(input ?? '').trim();
  return normalized.toUpperCase().replace(/\s+/g, '-').replace(/[^A-Z0-9-]/g, '');
}

function normalizeSeedWithMode(input, mode = 'auto') {
  const raw = String(input ?? '').trim();
  if (!raw) return '';
  const wantsNumber = mode === 'number' || (mode === 'auto' && /^[0-9]+$/.test(raw));
  if (wantsNumber) {
    const n = Number(raw);
    if (!Number.isFinite(n)) return '';
    return normalizeSeed(`N-${Math.floor(Math.abs(n)).toString(36).toUpperCase()}`);
  }
  return normalizeSeed(raw);
}

function seedHash32(seed) {
  let hash = 2166136261;
  const source = normalizeSeed(seed) || 'SEED-0';
  for (let i = 0; i < source.length; i += 1) {
    hash ^= source.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function rngFromSeed(seed) {
  let state = seedHash32(seed) || 1;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return ((state >>> 0) % 100000) / 100000;
  };
}

function autoSeed(prefix = 'GW') {
  const rand = rngFromSeed(`${Date.now()}-${Math.random()}`);
  const block = () => Math.floor(rand() * 46656).toString(36).toUpperCase().padStart(3, '0');
  return `${prefix}-${block()}-${block()}`;
}

function buildDifficultyLabel(level = 1) {
  if (level <= 5) return 'Beginner';
  if (level <= 15) return 'Standard';
  if (level <= 30) return 'Skilled';
  if (level <= 50) return 'Elite';
  return 'Boss';
}

function mapTypeDisplay(stateName = 'unoccupied') {
  const key = String(stateName);
  if (key === 'occupied') return 'Occupied';
  if (key === 'unoccupied') return 'Mystery';
  if (key === 'gateway') return 'Gateway';
  if (key === 'boss') return 'Boss';
  if (key === 'playerOwned') return 'Player Owned';
  if (key === 'compromised') return 'Compromised';
  if (key === 'pirate') return 'Pirate Activity';
  if (key === 'hidden') return 'Hidden';
  if (key === 'locked') return 'Locked';
  if (key === 'special') return 'Special';
  if (key === 'created') return 'Created';
  return 'Unknown';
}

function mapNodeIcon(stateName = 'unoccupied') {
  const key = String(stateName);
  if (key === 'occupied') return '◆';
  if (key === 'unoccupied') return '?';
  if (key === 'gateway') return '◈';
  if (key === 'boss') return '♛';
  if (key === 'playerOwned') return '⬢';
  if (key === 'compromised') return '⛒';
  if (key === 'pirate') return '☠';
  if (key === 'hidden') return '◌';
  if (key === 'locked') return '⛶';
  if (key === 'special') return '✦';
  return '•';
}

function invasionThreatUrgencyScore(threat = null) {
  if (!threat) return 0;
  const stars = clamp(Math.round(toFiniteNumber(threat.aiSkillStars, 1)), 1, 5);
  const triangles = clamp(Math.round(toFiniteNumber(threat.deckTriangles, toFiniteNumber(threat.deckSizeEstimate, 30) / 10)), 1, 6);
  const tech = Math.max(1, Math.round(toFiniteNumber(threat.techLevel, 1)));
  const pressure = clamp(toFiniteNumber(threat.siegePressure, 0), 0, 220);
  const rankBonus = threat.commanderRank === 'boss' ? 35 : (threat.commanderRank === 'elite' ? 18 : 0);
  return (stars * 12) + (triangles * 9) + tech + (pressure * 0.18) + rankBonus;
}

function invasionThreatDangerTier(threat = null) {
  const score = invasionThreatUrgencyScore(threat);
  if (score >= 130) return 'critical';
  if (score >= 98) return 'high';
  if (score >= 72) return 'elevated';
  return 'watch';
}

function invasionThreatDeckChips(threat = null) {
  if (!threat) return [];
  const chips = [];
  const style = String(threat.threatStyle ?? '').trim();
  if (style) chips.push(style);
  toArray(threat.deckTags).forEach((entry) => {
    const normalized = String(entry ?? '').toLowerCase().trim();
    if (!normalized || chips.includes(normalized)) return;
    chips.push(normalized);
  });
  toArray(threat.specialTraits).forEach((entry) => {
    const normalized = String(entry ?? '').toLowerCase().trim();
    if (!normalized || chips.includes(normalized)) return;
    chips.push(normalized);
  });
  return chips.slice(0, 6);
}

function pirateActivityState(pirate = null, attackers = null) {
  if (!pirate) return 'hidden';
  const objective = String(pirate.objective ?? '').toLowerCase();
  if (objective === 'flee') return 'escaping';
  if (objective === 'invade' || objective === 'raid') return 'invading';
  if (objective === 'investigate' || objective === 'scan') {
    const progress = toFiniteNumber(pirate.searchProgress, 0);
    return progress >= 65 ? 'tracking' : 'scouting';
  }
  if (objective === 'patrol') {
    const exposed = !!(attackers?.playerExposed);
    return exposed ? 'exposed' : 'hidden';
  }
  return 'tracking';
}

function pirateDangerTier(pirate = null) {
  const level = Math.max(1, Math.round(toFiniteNumber(pirate?.level, 1)));
  const threat = Math.max(1, Math.round(toFiniteNumber(pirate?.threat, 1)));
  const score = level + (threat * 2);
  if (score >= 36) return 'critical';
  if (score >= 26) return 'high';
  if (score >= 16) return 'elevated';
  return 'watch';
}

function galaxyStateTag(galaxy, profile) {
  const assignedAiId = galaxy.occupiedByAIId ?? galaxy.ownerAiId ?? null;
  if (assignedAiId) {
    const defeated = (profile.defeatedAiIds ?? []).includes(assignedAiId);
    if (galaxy.nodeType === 'boss') return defeated ? 'playerOwned' : 'boss';
    return defeated ? 'playerOwned' : 'occupied';
  }
  if (galaxy.state === 'hidden') return 'hidden';
  if (galaxy.state === 'locked') return 'locked';
  if (galaxy.nodeType === 'boss') return 'boss';
  if (galaxy.gatewayImported) return 'gateway';
  if (galaxy.state === 'special' || galaxy.nodeType === 'special') return 'special';
  return 'unoccupied';
}

function pickGalaxyColor(style, stateName, fallback = '#7fb4ff') {
  const palette = style?.palette ?? {};
  if (stateName === 'occupied') return palette.nodeBase ?? fallback;
  if (stateName === 'unoccupied') return palette.nodeUnoccupied ?? '#7883a9';
  if (stateName === 'gateway') return palette.nodeGateway ?? '#7af5f9';
  if (stateName === 'boss') return palette.nodeBoss ?? '#ff7d68';
  if (stateName === 'playerOwned') return palette.nodePlayer ?? '#7dffa2';
  if (stateName === 'compromised') return '#ff4f64';
  if (stateName === 'pirate') return '#ff8d68';
  if (stateName === 'hidden') return '#6a708d';
  if (stateName === 'locked') return '#515a7f';
  return palette.nodeBase ?? fallback;
}

function generateGalaxyFromSeed(seedInput, configOverrides = {}) {
  const seed = normalizeSeed(seedInput || autoSeed('GX'));
  const rand = rngFromSeed(seed);
  const sunCount = configOverrides.sunCount ?? (1 + Math.floor(rand() * 3));
  const planetCount = configOverrides.planetCount ?? (4 + Math.floor(rand() * 7));
  const orbitLayouts = ['stable', 'chaotic', 'spiral', 'fractured', 'binary'];
  const orbitLayout = configOverrides.orbitLayout ?? orbitLayouts[Math.floor(rand() * orbitLayouts.length)];
  const moonDensity = configOverrides.moonDensity ?? Math.floor(rand() * 5);
  const ringedPlanets = configOverrides.ringedPlanets ?? (rand() > 0.52);
  const accentHue = Math.floor(rand() * 360);
  const landmark = rand() > 0.65 ? 'anomaly' : rand() > 0.35 ? 'relay' : 'none';
  const gatewaySignature = configOverrides.gatewaySignature ?? `GX-${seed.slice(0, 4)}-${Math.floor(100 + rand() * 899)}`;
  const rarityBand = configOverrides.rarityTier ?? (rand() > 0.9 ? 'legendary' : rand() > 0.72 ? 'epic' : rand() > 0.42 ? 'rare' : 'common');
  return {
    type: MAP_TYPES.GalaxyDefinition,
    id: configOverrides.id ?? `galaxy-${seed.toLowerCase()}`,
    name: configOverrides.name ?? `Gateway ${seed.slice(-4)}`,
    seed,
    sunCount,
    planetCount,
    orbitLayout,
    moonDensity,
    ringedPlanets: !!ringedPlanets,
    landmark,
    paletteMeta: {
      accentHue,
      accent: `hsl(${accentHue}, 74%, 62%)`,
      secondary: `hsl(${(accentHue + 42) % 360}, 62%, 52%)`,
    },
    styleId: configOverrides.styleId ?? 'astral-cartographer',
    lore: configOverrides.lore ?? 'Uncatalogued system discovered by dimensional resonance.',
    universe: configOverrides.universe ?? 'Unmapped Expanse',
    state: configOverrides.state ?? 'unoccupied',
    nodeType: configOverrides.nodeType ?? 'gateway',
    occupiedByAIId: configOverrides.occupiedByAIId ?? null,
    packSource: Array.isArray(configOverrides.packSource) ? configOverrides.packSource : [],
    ambienceTag: configOverrides.ambienceTag ?? '',
    rarityTier: rarityBand,
    gatewaySignature,
    emblem: configOverrides.emblem ?? '',
    hazardType: configOverrides.hazardType ?? 'none',
    createdAt: configOverrides.createdAt ?? Date.now(),
    updatedAt: Date.now(),
    discoveryDefault: configOverrides.discoveryDefault ?? 'discovered',
    gatewayImported: !!configOverrides.gatewayImported,
  };
}

function mapNodeMatchesFilters(node, filters) {
  if (node.playerHome && node.stateTag === 'compromised') return true;
  const q = String(filters.search ?? '').trim().toLowerCase();
  const statusFilter = filters.status ?? 'all';
  const styleFilter = filters.style ?? 'all';
  const matchesSearch = !q || `${node.name} ${node.seed} ${node.gatewaySignature} ${node.ownerName ?? ''}`.toLowerCase().includes(q);
  const matchesStatus = statusFilter === 'all'
    || node.stateTag === statusFilter
    || (statusFilter === 'created' && !!node.isCreated);
  const matchesStyle = styleFilter === 'all' || node.styleId === styleFilter;
  return matchesSearch && matchesStatus && matchesStyle;
}

function pickRandom(list = [], seed = null) {
  if (list.length === 0) return null;
  if (seed == null) return list[Math.floor(Math.random() * list.length)];
  const rand = seededRandom(seed);
  return list[Math.floor(rand() * list.length)];
}

function weightedPick(entries = [], key = 'global') {
  if (!entries.length) return null;
  const normalized = entries.map((entry) => (
    typeof entry === 'string'
      ? { text: entry, weight: 1 }
      : { text: entry.text, weight: Math.max(0.2, Number(entry.weight ?? 1)) }
  ));
  const last = dialogLineMemory[key] ?? null;
  const pool = normalized.map((entry) => ({
    ...entry,
    weight: entry.text === last ? entry.weight * 0.35 : entry.weight,
  }));
  const total = pool.reduce((sum, entry) => sum + entry.weight, 0);
  let roll = Math.random() * Math.max(0.01, total);
  for (const entry of pool) {
    roll -= entry.weight;
    if (roll <= 0) {
      dialogLineMemory[key] = entry.text;
      return entry.text;
    }
  }
  const fallback = pool[pool.length - 1].text;
  dialogLineMemory[key] = fallback;
  return fallback;
}

function aiLine(ai, category, fallback = '...') {
  const buckets = ai?.voiceLines ?? ai?.personality?.voiceLines ?? {};
  const entries = buckets?.[category] ?? [fallback];
  return weightedPick(entries, `${ai?.id ?? 'unknown'}:${category}`) ?? fallback;
}

const DEFAULT_PROFILE_STATS = {
  wins: 0,
  losses: 0,
  packsOpened: 0,
  streak: 0,
  bestStreak: 0,
  battlesPlayed: 0,
  modes: {
    duel: { wins: 0, losses: 0, battles: 0 },
    defense: { wins: 0, losses: 0, battles: 0 },
  },
  threats: {
    pirate: { wins: 0, losses: 0, battles: 0 },
    alien: { wins: 0, losses: 0, battles: 0 },
    boss: { wins: 0, losses: 0, battles: 0 },
    wielder: { wins: 0, losses: 0, battles: 0 },
  },
  factionsFought: {},
  bossesDefeated: 0,
  namedWieldersDefeated: 0,
  worlds: { conquered: 0, lost: 0 },
  planets: { conquered: 0, lost: 0 },
  invasions: { intercepted: 0, piratesEscaped: 0 },
  packs: {
    openedTotal: 0,
    byPack: {},
    cardsByPack: {},
    uniqueByPack: {},
    rarityPulls: { common: 0, rare: 0, epic: 0, legendary: 0 },
    legendaryPulls: 0,
  },
  collectionProgress: {
    totalCopiesOwned: 0,
    uniqueOwned: 0,
  },
  decks: {
    created: 0,
    edited: 0,
  },
  battleHistory: [],
};

function mergeProfileStats(raw = {}) {
  return {
    ...DEFAULT_PROFILE_STATS,
    ...(raw ?? {}),
    modes: {
      duel: { ...DEFAULT_PROFILE_STATS.modes.duel, ...(raw?.modes?.duel ?? {}) },
      defense: { ...DEFAULT_PROFILE_STATS.modes.defense, ...(raw?.modes?.defense ?? {}) },
    },
    threats: {
      pirate: { ...DEFAULT_PROFILE_STATS.threats.pirate, ...(raw?.threats?.pirate ?? {}) },
      alien: { ...DEFAULT_PROFILE_STATS.threats.alien, ...(raw?.threats?.alien ?? {}) },
      boss: { ...DEFAULT_PROFILE_STATS.threats.boss, ...(raw?.threats?.boss ?? {}) },
      wielder: { ...DEFAULT_PROFILE_STATS.threats.wielder, ...(raw?.threats?.wielder ?? {}) },
    },
    factionsFought: { ...(raw?.factionsFought ?? {}) },
    worlds: { ...DEFAULT_PROFILE_STATS.worlds, ...(raw?.worlds ?? {}) },
    planets: { ...DEFAULT_PROFILE_STATS.planets, ...(raw?.planets ?? {}) },
    invasions: { ...DEFAULT_PROFILE_STATS.invasions, ...(raw?.invasions ?? {}) },
    packs: {
      ...DEFAULT_PROFILE_STATS.packs,
      ...(raw?.packs ?? {}),
      byPack: { ...(raw?.packs?.byPack ?? {}) },
      cardsByPack: { ...(raw?.packs?.cardsByPack ?? {}) },
      uniqueByPack: { ...(raw?.packs?.uniqueByPack ?? {}) },
      rarityPulls: { ...DEFAULT_PROFILE_STATS.packs.rarityPulls, ...(raw?.packs?.rarityPulls ?? {}) },
    },
    collectionProgress: { ...DEFAULT_PROFILE_STATS.collectionProgress, ...(raw?.collectionProgress ?? {}) },
    decks: { ...DEFAULT_PROFILE_STATS.decks, ...(raw?.decks ?? {}) },
    battleHistory: Array.isArray(raw?.battleHistory) ? raw.battleHistory.slice(-80) : [],
  };
}

function computeCollectionProgress(collection = {}) {
  const entries = Object.entries(collection ?? {});
  const uniqueOwned = entries.filter(([, count]) => Number(count ?? 0) > 0).length;
  const totalCopiesOwned = entries.reduce((sum, [, count]) => sum + Math.max(0, Number(count ?? 0)), 0);
  return { uniqueOwned, totalCopiesOwned };
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function ensureProfileStats(profile) {
  profile.stats = mergeProfileStats(profile.stats ?? {});
  const progress = computeCollectionProgress(profile.collection ?? {});
  profile.stats.collectionProgress.uniqueOwned = progress.uniqueOwned;
  profile.stats.collectionProgress.totalCopiesOwned = progress.totalCopiesOwned;
  profile.stats.battlesPlayed = Math.max(
    Number(profile.stats.battlesPlayed ?? 0),
    Number(profile.stats.wins ?? 0) + Number(profile.stats.losses ?? 0),
  );
  profile.stats.packsOpened = Math.max(
    Number(profile.stats.packsOpened ?? 0),
    Number(profile.stats.packs?.openedTotal ?? 0),
  );
  return profile.stats;
}

function loadProfile() {
  const base = {
    economy: {
      gold: 400,
      lifeforce: 0,
      pityByProduct: {},
      lastDailyGiftAt: null,
      marketLedger: [],
      wishlist: [],
      watchedCards: [],
      licenses: {},
    },
    stats: mergeProfileStats(),
    collection: {
      'river-scout': 2,
      'iron-guard': 2,
      'ember-adept': 2,
      'pack-bolt': 2,
      'frost-weaver': 2,
      'arcane-scholar': 2,
      'dune-sentinel': 2,
      'mana-surge': 2,
      'primal-charge': 2,
      'totem-caller': 2,
      'pack-howl': 2,
      'soul-lantern': 2,
      'wildfang-alpha': 2,
      'void-silence': 2,
      'tangle-warden': 2,
      'grove-guardian': 2,
      'gen3-riftway-pathfinder': 2,
      'gen3-collapse-channeler': 2,
      'gen3-arc-skein-defender': 2,
      'gen3-thread-draw': 2,
      'gen3-fault-bolt': 2,
      'gen3-emergency-mend': 2,
      'gen3-war-chorus': 2,
      'gen3-time-snag': 2,
      'gen3-voidwell-sentinel': 2,
      'gen3-reinforce-line': 2,
      'gen3-frontier-barricade': 2,
      'gen3-turret-spire': 2,
      'gen3-mana-harbor-field': 2,
      'gen3-reactor-ramp': 2,
      'gen3-supply-relay': 2,
      'gen3-recovery-grove': 2,
      'gen3-collapse-drake': 2,
      'gen3-bastion-scribe': 2,
      'gen3-guardian-mandate': 2,
      'gen3-null-tax-order': 2,
    },
    customDecks: [],
    deckFolders: ['Ranked', 'Lore Decks', 'Experiments', 'AI Bosses', 'Tournament Builds', 'Meme Decks'],
    deckRulesets: {},
    deckSnapshots: {},
    deckSearchPresets: [],
    favoriteCards: [],
    cardLastUsed: {},
    archivedDeckIds: [],
    starterDeckId: 'starter-duel-collapsed-vanguard',
    starterDefenseDeckId: 'starter-defense-frontier-phalanx',
    discoveredDimensions: [],
    defeatedAiIds: [],
    lobbyResidents: [],
    carnexCodes: {},
    capturedCards: {},
    paywallMode: false,
    questProgress: {},
    questClaims: {},
    mapWorld: structuredClone(MAP_WORLD_DEFAULTS),
  };
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || '{}';
    if (profileCache && raw === profileCacheRaw) return profileCache;
    const parsed = JSON.parse(raw);
    const mapWorld = {
      ...structuredClone(MAP_WORLD_DEFAULTS),
      ...(parsed.mapWorld ?? {}),
      mapFilters: {
        ...MAP_WORLD_DEFAULTS.mapFilters,
        ...(parsed.mapWorld?.mapFilters ?? {}),
      },
      createdGalaxies: Array.isArray(parsed.mapWorld?.createdGalaxies) ? parsed.mapWorld.createdGalaxies : [],
      customAiProfiles: Array.isArray(parsed.mapWorld?.customAiProfiles) ? parsed.mapWorld.customAiProfiles : [],
      nodeAssignments: { ...(parsed.mapWorld?.nodeAssignments ?? {}) },
      gatewayIndexBySeed: { ...(parsed.mapWorld?.gatewayIndexBySeed ?? {}) },
      dimensionalAttackers: mergeDimensionalAttackersState(parsed.mapWorld?.dimensionalAttackers ?? {}),
      campaign: {
        ...structuredClone(CAMPAIGN_DEFAULTS),
        ...(parsed.mapWorld?.campaign ?? {}),
        worldStates: { ...(parsed.mapWorld?.campaign?.worldStates ?? {}) },
        conquestCardLibrary: Array.isArray(parsed.mapWorld?.campaign?.conquestCardLibrary) ? parsed.mapWorld.campaign.conquestCardLibrary : [],
        speciesAccess: { ...(parsed.mapWorld?.campaign?.speciesAccess ?? {}) },
        reinforcementPool: { ...(parsed.mapWorld?.campaign?.reinforcementPool ?? {}) },
        activeThreats: Array.isArray(parsed.mapWorld?.campaign?.activeThreats) ? parsed.mapWorld.campaign.activeThreats : [],
        supernaturalEvents: Array.isArray(parsed.mapWorld?.campaign?.supernaturalEvents) ? parsed.mapWorld.campaign.supernaturalEvents : [],
        eventHistory: Array.isArray(parsed.mapWorld?.campaign?.eventHistory) ? parsed.mapWorld.campaign.eventHistory : [],
        market: {
          ...emptyCampaignMarketState(),
          ...(parsed.mapWorld?.campaign?.market ?? {}),
          marketIndices: {
            ...emptyCampaignMarketState().marketIndices,
            ...(parsed.mapWorld?.campaign?.market?.marketIndices ?? {}),
            rarities: {
              ...emptyCampaignMarketState().marketIndices.rarities,
              ...(parsed.mapWorld?.campaign?.market?.marketIndices?.rarities ?? {}),
            },
            events: {
              ...emptyCampaignMarketState().marketIndices.events,
              ...(parsed.mapWorld?.campaign?.market?.marketIndices?.events ?? {}),
            },
            history: Array.isArray(parsed.mapWorld?.campaign?.market?.marketIndices?.history) ? parsed.mapWorld.campaign.market.marketIndices.history : [],
          },
          priceHistory: { ...(parsed.mapWorld?.campaign?.market?.priceHistory ?? {}) },
          collectionIndices: { ...(parsed.mapWorld?.campaign?.market?.collectionIndices ?? {}) },
          collectionHistory: { ...(parsed.mapWorld?.campaign?.market?.collectionHistory ?? {}) },
          factionTradeHistory: { ...(parsed.mapWorld?.campaign?.market?.factionTradeHistory ?? {}) },
          playerProfitHistory: Array.isArray(parsed.mapWorld?.campaign?.market?.playerProfitHistory) ? parsed.mapWorld.campaign.market.playerProfitHistory : [],
          relationHistory: { ...(parsed.mapWorld?.campaign?.market?.relationHistory ?? {}) },
          newsFeed: Array.isArray(parsed.mapWorld?.campaign?.market?.newsFeed) ? parsed.mapWorld.campaign.market.newsFeed : [],
          activeDemands: Array.isArray(parsed.mapWorld?.campaign?.market?.activeDemands) ? parsed.mapWorld.campaign.market.activeDemands : [],
          tradeShips: Array.isArray(parsed.mapWorld?.campaign?.market?.tradeShips) ? parsed.mapWorld.campaign.market.tradeShips : [],
        },
        diplomacy: {
          relations: { ...(parsed.mapWorld?.campaign?.diplomacy?.relations ?? {}) },
          transactionCounters: { ...(parsed.mapWorld?.campaign?.diplomacy?.transactionCounters ?? {}) },
          embargoes: { ...(parsed.mapWorld?.campaign?.diplomacy?.embargoes ?? {}) },
          flags: { ...(parsed.mapWorld?.campaign?.diplomacy?.flags ?? {}) },
        },
        tradeShips: Array.isArray(parsed.mapWorld?.campaign?.tradeShips) ? parsed.mapWorld.campaign.tradeShips : [],
      },
    };
    const resolved = {
      ...base,
      ...parsed,
      economy: {
        ...base.economy,
        ...(parsed.economy ?? {}),
        lifeforce: Math.max(0, Number(parsed.economy?.lifeforce ?? base.economy.lifeforce ?? 0)),
        marketLedger: Array.isArray(parsed.economy?.marketLedger) ? parsed.economy.marketLedger : [],
        wishlist: Array.isArray(parsed.economy?.wishlist) ? parsed.economy.wishlist : [],
        watchedCards: Array.isArray(parsed.economy?.watchedCards) ? parsed.economy.watchedCards : [],
        licenses: parsed.economy?.licenses && typeof parsed.economy.licenses === 'object' ? parsed.economy.licenses : {},
      },
      stats: mergeProfileStats(parsed.stats ?? {}),
      collection: { ...base.collection, ...(parsed.collection ?? {}) },
      customDecks: Array.isArray(parsed.customDecks) ? parsed.customDecks : [],
      deckFolders: Array.isArray(parsed.deckFolders) ? parsed.deckFolders : [...base.deckFolders],
      deckRulesets: { ...base.deckRulesets, ...(parsed.deckRulesets ?? {}) },
      deckSnapshots: { ...base.deckSnapshots, ...(parsed.deckSnapshots ?? {}) },
      deckSearchPresets: Array.isArray(parsed.deckSearchPresets) ? parsed.deckSearchPresets : [],
      favoriteCards: Array.isArray(parsed.favoriteCards) ? parsed.favoriteCards : [],
      cardLastUsed: { ...base.cardLastUsed, ...(parsed.cardLastUsed ?? {}) },
      archivedDeckIds: Array.isArray(parsed.archivedDeckIds) ? parsed.archivedDeckIds : [],
      starterDeckId: parsed.starterDeckId || base.starterDeckId,
      starterDefenseDeckId: parsed.starterDefenseDeckId || parsed.starterDeckId || base.starterDefenseDeckId,
      discoveredDimensions: [...new Set([...(base.discoveredDimensions || []), ...((parsed.discoveredDimensions) || [])])],
      defeatedAiIds: [...new Set([...(base.defeatedAiIds || []), ...((parsed.defeatedAiIds) || [])])],
      lobbyResidents: [...new Set([...(base.lobbyResidents || []), ...((parsed.lobbyResidents) || [])])],
      carnexCodes: { ...base.carnexCodes, ...(parsed.carnexCodes ?? {}) },
      capturedCards: { ...base.capturedCards, ...(parsed.capturedCards ?? {}) },
      questProgress: { ...base.questProgress, ...(parsed.questProgress ?? {}) },
      questClaims: { ...base.questClaims, ...(parsed.questClaims ?? {}) },
      mapWorld,
    };
    if (window.CardForgeMarket) {
      resolved.mapWorld.campaign.market.tradeShips = Array.isArray(resolved.mapWorld.campaign.tradeShips) && resolved.mapWorld.campaign.tradeShips.length
        ? resolved.mapWorld.campaign.tradeShips
        : resolved.mapWorld.campaign.market.tradeShips;
    }
    delete resolved.traderOffer;
    ensureProfileStats(resolved);
    profileCache = resolved;
    profileCacheRaw = raw;
    return resolved;
  } catch {
    ensureProfileStats(base);
    profileCache = base;
    profileCacheRaw = localStorage.getItem(STORAGE_KEY) || null;
    return base;
  }
}

function isQuotaStorageError(error) {
  if (!error) return false;
  const name = String(error?.name ?? '');
  const message = String(error?.message ?? '');
  const code = Number(error?.code ?? 0);
  return name === 'QuotaExceededError'
    || name === 'NS_ERROR_DOM_QUOTA_REACHED'
    || code === 22
    || code === 1014
    || /quota/i.test(message)
    || /exceeded the quota/i.test(message);
}

function compactProfileForStorage(profile) {
  const compacted = structuredClone(profile ?? {});
  if (!compacted || typeof compacted !== 'object') return compacted;
  if (compacted.stats && typeof compacted.stats === 'object') {
    if (Array.isArray(compacted.stats.battleHistory)) compacted.stats.battleHistory = compacted.stats.battleHistory.slice(-80);
  }
  if (compacted.mapWorld && typeof compacted.mapWorld === 'object') {
    if (Array.isArray(compacted.mapWorld.createdGalaxies)) compacted.mapWorld.createdGalaxies = compacted.mapWorld.createdGalaxies.slice(-280);
    if (Array.isArray(compacted.mapWorld.customAiProfiles)) compacted.mapWorld.customAiProfiles = compacted.mapWorld.customAiProfiles.slice(-220);
    const campaign = compacted.mapWorld.campaign;
    if (campaign && typeof campaign === 'object') {
      if (Array.isArray(campaign.eventHistory)) campaign.eventHistory = campaign.eventHistory.slice(-140);
      if (Array.isArray(campaign.supernaturalEvents)) campaign.supernaturalEvents = campaign.supernaturalEvents.slice(-80);
      if (Array.isArray(campaign.activeThreats)) campaign.activeThreats = campaign.activeThreats.slice(-80);
      if (Array.isArray(campaign.conquestCardLibrary)) campaign.conquestCardLibrary = campaign.conquestCardLibrary.slice(-720);
      if (Array.isArray(campaign.tradeShips)) campaign.tradeShips = campaign.tradeShips.slice(0, 16);
      if (campaign.market && typeof campaign.market === 'object') {
        if (Array.isArray(campaign.market.activeTraders)) campaign.market.activeTraders = campaign.market.activeTraders.slice(0, 20);
        if (Array.isArray(campaign.market.tradeShips)) campaign.market.tradeShips = campaign.market.tradeShips.slice(0, 16);
        if (Array.isArray(campaign.market.newsFeed)) campaign.market.newsFeed = campaign.market.newsFeed.slice(-18);
        if (Array.isArray(campaign.market.activeDemands)) campaign.market.activeDemands = campaign.market.activeDemands.slice(0, 18);
        if (campaign.market.marketIndices && typeof campaign.market.marketIndices === 'object' && Array.isArray(campaign.market.marketIndices.history)) {
          campaign.market.marketIndices.history = campaign.market.marketIndices.history.slice(-72);
        }
        if (campaign.market.priceHistory && typeof campaign.market.priceHistory === 'object') {
          Object.keys(campaign.market.priceHistory).forEach((cardId) => {
            campaign.market.priceHistory[cardId] = Array.isArray(campaign.market.priceHistory[cardId])
              ? campaign.market.priceHistory[cardId].slice(-48)
              : [];
          });
        }
        if (campaign.market.relationHistory && typeof campaign.market.relationHistory === 'object') {
          Object.keys(campaign.market.relationHistory).forEach((factionId) => {
            campaign.market.relationHistory[factionId] = Array.isArray(campaign.market.relationHistory[factionId])
              ? campaign.market.relationHistory[factionId].slice(-72)
              : [];
          });
        }
        if (campaign.market.collectionHistory && typeof campaign.market.collectionHistory === 'object') {
          Object.keys(campaign.market.collectionHistory).forEach((collectionId) => {
            campaign.market.collectionHistory[collectionId] = Array.isArray(campaign.market.collectionHistory[collectionId])
              ? campaign.market.collectionHistory[collectionId].slice(-48)
              : [];
          });
        }
        if (campaign.market.factionTradeHistory && typeof campaign.market.factionTradeHistory === 'object') {
          Object.keys(campaign.market.factionTradeHistory).forEach((factionId) => {
            campaign.market.factionTradeHistory[factionId] = Array.isArray(campaign.market.factionTradeHistory[factionId])
              ? campaign.market.factionTradeHistory[factionId].slice(-60)
              : [];
          });
        }
        if (Array.isArray(campaign.market.playerProfitHistory)) {
          campaign.market.playerProfitHistory = campaign.market.playerProfitHistory.slice(-90);
        }
      }
      if (campaign.worldStates && typeof campaign.worldStates === 'object') {
        Object.values(campaign.worldStates).forEach((worldState) => {
          if (!worldState || typeof worldState !== 'object') return;
          if (Array.isArray(worldState.buildHistory)) worldState.buildHistory = worldState.buildHistory.slice(-80);
          if (Array.isArray(worldState.planets)) {
            worldState.planets = worldState.planets.map((planet) => {
              if (!planet || typeof planet !== 'object') return planet;
              const next = { ...planet };
              if (Array.isArray(next.objectives)) next.objectives = next.objectives.slice(0, 16);
              if (Array.isArray(next.buildHistory)) next.buildHistory = next.buildHistory.slice(-40);
              return next;
            });
          }
        });
      }
    }
  }
  return compacted;
}

function tryStoreProfile(profile, serialized) {
  try {
    localStorage.setItem(STORAGE_KEY, serialized);
    profileCache = profile;
    profileCacheRaw = serialized;
    return true;
  } catch (error) {
    return false;
  }
}

function saveProfile(profile, options = {}) {
  const skipNormalize = !!options?.skipNormalize;
  ensureProfileStats(profile);
  if (skipNormalize) {
    try {
      const serialized = JSON.stringify(profile);
      if (tryStoreProfile(profile, serialized)) return true;
      const compacted = compactProfileForStorage(profile);
      const compactedSerialized = JSON.stringify(compacted);
      if (tryStoreProfile(compacted, compactedSerialized)) {
        Object.assign(profile, compacted);
        return true;
      }
    } catch (error) {
      console.warn('[profile] Failed to serialize profile (skipNormalize).', error);
      return false;
    }
    console.warn('[profile] Unable to persist profile in localStorage (skipNormalize).');
    return false;
  }
  profile.collection = profile.collection ?? {};
  profile.economy = {
    gold: Math.max(0, Number(profile.economy?.gold ?? 0)),
    lifeforce: Math.max(0, Number(profile.economy?.lifeforce ?? 0)),
    pityByProduct: profile.economy?.pityByProduct ?? {},
    lastDailyGiftAt: profile.economy?.lastDailyGiftAt ?? null,
    marketLedger: Array.isArray(profile.economy?.marketLedger) ? profile.economy.marketLedger : [],
    wishlist: Array.isArray(profile.economy?.wishlist) ? profile.economy.wishlist : [],
    watchedCards: Array.isArray(profile.economy?.watchedCards) ? profile.economy.watchedCards : [],
    licenses: profile.economy?.licenses && typeof profile.economy.licenses === 'object' ? profile.economy.licenses : {},
  };
  profile.customDecks = Array.isArray(profile.customDecks) ? profile.customDecks : [];
  profile.deckFolders = Array.isArray(profile.deckFolders) ? profile.deckFolders : ['Ranked', 'Lore Decks', 'Experiments', 'AI Bosses', 'Tournament Builds', 'Meme Decks'];
  profile.deckRulesets = profile.deckRulesets ?? {};
  profile.deckSnapshots = profile.deckSnapshots ?? {};
  profile.deckSearchPresets = Array.isArray(profile.deckSearchPresets) ? profile.deckSearchPresets : [];
  profile.favoriteCards = Array.isArray(profile.favoriteCards) ? profile.favoriteCards : [];
  profile.cardLastUsed = profile.cardLastUsed ?? {};
  profile.archivedDeckIds = Array.isArray(profile.archivedDeckIds) ? profile.archivedDeckIds : [];
  profile.mapWorld = {
    ...structuredClone(MAP_WORLD_DEFAULTS),
    ...(profile.mapWorld ?? {}),
    mapFilters: {
      ...MAP_WORLD_DEFAULTS.mapFilters,
      ...(profile.mapWorld?.mapFilters ?? {}),
    },
    createdGalaxies: Array.isArray(profile.mapWorld?.createdGalaxies) ? profile.mapWorld.createdGalaxies : [],
    customAiProfiles: Array.isArray(profile.mapWorld?.customAiProfiles) ? profile.mapWorld.customAiProfiles : [],
    nodeAssignments: { ...(profile.mapWorld?.nodeAssignments ?? {}) },
    gatewayIndexBySeed: { ...(profile.mapWorld?.gatewayIndexBySeed ?? {}) },
    dimensionalAttackers: mergeDimensionalAttackersState(profile.mapWorld?.dimensionalAttackers ?? {}),
      campaign: {
        ...structuredClone(CAMPAIGN_DEFAULTS),
        ...(profile.mapWorld?.campaign ?? {}),
        worldStates: { ...(profile.mapWorld?.campaign?.worldStates ?? {}) },
        conquestCardLibrary: Array.isArray(profile.mapWorld?.campaign?.conquestCardLibrary) ? profile.mapWorld.campaign.conquestCardLibrary : [],
        speciesAccess: { ...(profile.mapWorld?.campaign?.speciesAccess ?? {}) },
        reinforcementPool: { ...(profile.mapWorld?.campaign?.reinforcementPool ?? {}) },
        activeThreats: Array.isArray(profile.mapWorld?.campaign?.activeThreats) ? profile.mapWorld.campaign.activeThreats : [],
        supernaturalEvents: Array.isArray(profile.mapWorld?.campaign?.supernaturalEvents) ? profile.mapWorld.campaign.supernaturalEvents : [],
        eventHistory: Array.isArray(profile.mapWorld?.campaign?.eventHistory) ? profile.mapWorld.campaign.eventHistory : [],
        market: {
          ...emptyCampaignMarketState(),
          ...(profile.mapWorld?.campaign?.market ?? {}),
          marketIndices: {
            ...emptyCampaignMarketState().marketIndices,
            ...(profile.mapWorld?.campaign?.market?.marketIndices ?? {}),
            rarities: {
              ...emptyCampaignMarketState().marketIndices.rarities,
              ...(profile.mapWorld?.campaign?.market?.marketIndices?.rarities ?? {}),
            },
            events: {
              ...emptyCampaignMarketState().marketIndices.events,
              ...(profile.mapWorld?.campaign?.market?.marketIndices?.events ?? {}),
            },
            history: Array.isArray(profile.mapWorld?.campaign?.market?.marketIndices?.history) ? profile.mapWorld.campaign.market.marketIndices.history : [],
          },
          priceHistory: { ...(profile.mapWorld?.campaign?.market?.priceHistory ?? {}) },
          collectionIndices: { ...(profile.mapWorld?.campaign?.market?.collectionIndices ?? {}) },
          relationHistory: { ...(profile.mapWorld?.campaign?.market?.relationHistory ?? {}) },
          newsFeed: Array.isArray(profile.mapWorld?.campaign?.market?.newsFeed) ? profile.mapWorld.campaign.market.newsFeed : [],
          activeDemands: Array.isArray(profile.mapWorld?.campaign?.market?.activeDemands) ? profile.mapWorld.campaign.market.activeDemands : [],
          tradeShips: Array.isArray(profile.mapWorld?.campaign?.market?.tradeShips) ? profile.mapWorld.campaign.market.tradeShips : [],
        },
        diplomacy: {
          relations: { ...(profile.mapWorld?.campaign?.diplomacy?.relations ?? {}) },
          transactionCounters: { ...(profile.mapWorld?.campaign?.diplomacy?.transactionCounters ?? {}) },
          embargoes: { ...(profile.mapWorld?.campaign?.diplomacy?.embargoes ?? {}) },
          flags: { ...(profile.mapWorld?.campaign?.diplomacy?.flags ?? {}) },
        },
        tradeShips: Array.isArray(profile.mapWorld?.campaign?.tradeShips) ? profile.mapWorld.campaign.tradeShips : [],
      },
    };
  delete profile.traderOffer;
  try {
    const serialized = JSON.stringify(profile);
    if (tryStoreProfile(profile, serialized)) return true;
    const compacted = compactProfileForStorage(profile);
    const compactedSerialized = JSON.stringify(compacted);
    if (tryStoreProfile(compacted, compactedSerialized)) {
      profile.stats = compacted.stats;
      profile.mapWorld = compacted.mapWorld;
      return true;
    }
  } catch (error) {
    if (!isQuotaStorageError(error)) {
      console.warn('[profile] Failed to serialize profile.', error);
      return false;
    }
  }
  console.warn('[profile] Unable to persist profile in localStorage.');
  return false;
}

function safeSaveProfile(profile, options = {}) {
  try {
    return saveProfile(profile, options);
  } catch (error) {
    if (isQuotaStorageError(error)) {
      try {
        const compacted = compactProfileForStorage(profile);
        return saveProfile(compacted, { ...options, skipNormalize: true });
      } catch (_) {
        return false;
      }
    }
    console.warn('[profile] saveProfile threw unexpectedly.', error);
    return false;
  }
}

function withProfile(updater) {
  const profile = loadProfile();
  updater(profile);
  safeSaveProfile(profile);
  return profile;
}

async function loadJson(path, fallback) {
  if (LOCAL_MODE) return fallback;
  try {
    const response = await fetch(path);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (error) {
    throw error;
  }
}

function readQueuedMatchResult() {
  try {
    const raw = localStorage.getItem(MATCH_RESULT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function clearQueuedMatchResult() {
  localStorage.removeItem(MATCH_RESULT_KEY);
}

function applyQueuedMatchResult(profileState) {
  const queued = readQueuedMatchResult();
  if (!queued) return false;
  const mapWorld = getMapWorld(profileState);
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const attackers = getDimensionalAttackers(mapWorld);
  const isWin = String(queued.result ?? 'loss').toLowerCase() === 'win';
  const threatType = String(queued.metadata?.threatType ?? '').toLowerCase();
  let changed = false;

  if (threatType === 'pirate') {
    const pirateId = queued.threatId ?? attackers.pendingIntercept?.pirateId ?? null;
    if (pirateId) {
      const pirateIdx = (attackers.activePirates ?? []).findIndex((entry) => entry.id === pirateId);
      const pirate = pirateIdx >= 0 ? attackers.activePirates[pirateIdx] : null;
      if (pirate) {
        if (isWin) onPirateDefeated(attackers, pirate, profileState);
        else onPirateEscaped(attackers, pirate, profileState);
        attackers.activePirates.splice(pirateIdx, 1);
        changed = true;
      }
    }
    attackers.pendingIntercept = null;
    attackers.lastKnownStats = {
      wins: toFiniteNumber(profileState.stats?.wins, 0),
      losses: toFiniteNumber(profileState.stats?.losses, 0),
    };
    clearWarpKeyCompromised(attackers);
  } else if (threatType === 'alien') {
    const threatId = queued.threatId ?? null;
    if (threatId) {
      const before = campaign.activeThreats?.length ?? 0;
      const threat = (campaign.activeThreats ?? []).find((entry) => entry?.id === threatId) ?? null;
      campaign.activeThreats = (campaign.activeThreats ?? []).filter((entry) => entry?.id !== threatId);
      if ((campaign.activeThreats?.length ?? 0) !== before) changed = true;
      campaign.eventHistory = [...(campaign.eventHistory ?? []), {
        ts: Date.now(),
        severity: isWin ? 'good' : 'danger',
        text: isWin
          ? `${threat?.factionName ?? 'Alien'} invasion fleet destroyed near ${threat?.targetNodeId ?? queued.worldId ?? 'frontier'}.`
          : `${threat?.factionName ?? 'Alien'} fleet broke through after your defeat near ${threat?.targetNodeId ?? queued.worldId ?? 'frontier'}.`,
      }].slice(-80);
    }
  }

  const worldId = String(queued.worldId ?? '').trim();
  const planetId = String(queued.planetId ?? '').trim();
  const objectiveId = String(queued.objectiveId ?? '').trim();
  if (worldId && objectiveId) {
    const world = campaign.worldStates?.[worldId] ?? null;
    const planet = world?.planets?.find((entry) => entry.id === planetId) ?? null;
    const objective = planet?.objectives?.find((entry) => entry.id === objectiveId) ?? null;
    if (objective && objective.status !== 'completed') {
      objective.status = isWin ? 'completed' : 'pending';
      objective.lastResult = isWin ? 'win' : 'loss';
      objective.lastBattleAt = Date.now();
      if (isWin) {
        objective.rewardGranted = true;
        profileState.economy = profileState.economy ?? { gold: 0, lifeforce: 0 };
        const objReward = 40 + Math.floor(toFiniteNumber(objective.deckSizeEstimate, 20) * 0.45);
        profileState.economy.gold = Number(profileState.economy.gold ?? 0) + objReward;
      }
      if (planet) {
        ensurePlanetConquestState(world, planet);
        planet.strongholdsCaptured = planet.objectives.filter((entry) => entry.status === 'completed').length;
        planet.strongholdsRequired = Math.max(3, Number(planet.strongholdsRequired ?? planet.objectives.length));
        if (isWin && planet.strongholdsCaptured >= planet.strongholdsRequired) {
          planet.facilityWar.phase = planet.facilityWar.phase === 'idle' ? 'battle-ready' : planet.facilityWar.phase;
          campaign.eventHistory = [...(campaign.eventHistory ?? []), {
            ts: Date.now(),
            severity: 'good',
            text: `${planet.name} strongholds seized. Facility war mat unlocked.`,
          }].slice(-80);
        }
      }
      reconcileWorldOwnership(campaign, world, profileState);
      changed = true;
    }
  }

  mapWorld.campaign = campaign;
  mapWorld.dimensionalAttackers = attackers;
  profileState.mapWorld = mapWorld;
  if (changed) saveProfile(profileState);
  clearQueuedMatchResult();
  return changed;
}

function mapStatus(profileState, aiProfile) {
  const gate = Math.max(0, (aiProfile.level ?? 1) - 3);
  const defeated = (profileState.defeatedAiIds ?? []).includes(aiProfile.id);
  const unlockedByWins = (profileState.stats?.wins ?? 0) >= gate;
  const unlocked = defeated || unlockedByWins;
  const inLobby = (profileState.lobbyResidents ?? []).includes(aiProfile.id) || defeated;
  return { gate, defeated, unlocked, inLobby };
}

function getMapWorld(profile = null) {
  const resolved = profile ?? loadProfile();
  resolved.mapWorld = {
    ...structuredClone(MAP_WORLD_DEFAULTS),
    ...(resolved.mapWorld ?? {}),
    mapFilters: {
      ...MAP_WORLD_DEFAULTS.mapFilters,
      ...(resolved.mapWorld?.mapFilters ?? {}),
    },
    createdGalaxies: Array.isArray(resolved.mapWorld?.createdGalaxies) ? resolved.mapWorld.createdGalaxies : [],
    customAiProfiles: Array.isArray(resolved.mapWorld?.customAiProfiles) ? resolved.mapWorld.customAiProfiles : [],
    nodeAssignments: { ...(resolved.mapWorld?.nodeAssignments ?? {}) },
    gatewayIndexBySeed: { ...(resolved.mapWorld?.gatewayIndexBySeed ?? {}) },
    dimensionalAttackers: mergeDimensionalAttackersState(resolved.mapWorld?.dimensionalAttackers ?? {}),
    campaign: {
      ...structuredClone(CAMPAIGN_DEFAULTS),
      ...(resolved.mapWorld?.campaign ?? {}),
      worldStates: { ...(resolved.mapWorld?.campaign?.worldStates ?? {}) },
      conquestCardLibrary: Array.isArray(resolved.mapWorld?.campaign?.conquestCardLibrary) ? resolved.mapWorld.campaign.conquestCardLibrary : [],
      speciesAccess: { ...(resolved.mapWorld?.campaign?.speciesAccess ?? {}) },
      reinforcementPool: { ...(resolved.mapWorld?.campaign?.reinforcementPool ?? {}) },
      activeThreats: Array.isArray(resolved.mapWorld?.campaign?.activeThreats) ? resolved.mapWorld.campaign.activeThreats : [],
      supernaturalEvents: Array.isArray(resolved.mapWorld?.campaign?.supernaturalEvents) ? resolved.mapWorld.campaign.supernaturalEvents : [],
      eventHistory: Array.isArray(resolved.mapWorld?.campaign?.eventHistory) ? resolved.mapWorld.campaign.eventHistory : [],
    },
  };
  return resolved.mapWorld;
}

function getMapWorldFast(profile = null) {
  const resolved = profile ?? loadProfile();
  if (!resolved.mapWorld || typeof resolved.mapWorld !== 'object') resolved.mapWorld = {};
  const mapWorld = resolved.mapWorld;
  if (!Array.isArray(mapWorld.createdGalaxies)) mapWorld.createdGalaxies = [];
  if (!Array.isArray(mapWorld.customAiProfiles)) mapWorld.customAiProfiles = [];
  if (!mapWorld.nodeAssignments || typeof mapWorld.nodeAssignments !== 'object') mapWorld.nodeAssignments = {};
  if (!mapWorld.gatewayIndexBySeed || typeof mapWorld.gatewayIndexBySeed !== 'object') mapWorld.gatewayIndexBySeed = {};
  if (!mapWorld.mapFilters || typeof mapWorld.mapFilters !== 'object') {
    mapWorld.mapFilters = { ...MAP_WORLD_DEFAULTS.mapFilters };
  } else {
    mapWorld.mapFilters.search = String(mapWorld.mapFilters.search ?? '');
    mapWorld.mapFilters.status = String(mapWorld.mapFilters.status ?? MAP_WORLD_DEFAULTS.mapFilters.status);
    mapWorld.mapFilters.style = String(mapWorld.mapFilters.style ?? MAP_WORLD_DEFAULTS.mapFilters.style);
  }
  if (!mapWorld.globalMapStyleId) mapWorld.globalMapStyleId = MAP_WORLD_DEFAULTS.globalMapStyleId;
  if (!mapWorld.dimensionalAttackers || typeof mapWorld.dimensionalAttackers !== 'object') {
    mapWorld.dimensionalAttackers = {};
  }
  if (!mapWorld.campaign || typeof mapWorld.campaign !== 'object') mapWorld.campaign = {};
  const campaign = mapWorld.campaign;
  if (!campaign.worldStates || typeof campaign.worldStates !== 'object') campaign.worldStates = {};
  if (!Array.isArray(campaign.conquestCardLibrary)) campaign.conquestCardLibrary = [];
  if (!campaign.speciesAccess || typeof campaign.speciesAccess !== 'object') campaign.speciesAccess = {};
  if (!campaign.reinforcementPool || typeof campaign.reinforcementPool !== 'object') campaign.reinforcementPool = {};
  if (!Array.isArray(campaign.activeThreats)) campaign.activeThreats = [];
  if (!Array.isArray(campaign.supernaturalEvents)) campaign.supernaturalEvents = [];
  if (!Array.isArray(campaign.eventHistory)) campaign.eventHistory = [];
  if (!Array.isArray(campaign.ownedWorldIds)) campaign.ownedWorldIds = [];
  if (!Array.isArray(campaign.lostWorldIds)) campaign.lostWorldIds = [];
  if (!Array.isArray(campaign.ownedDimensions)) campaign.ownedDimensions = [];
  campaign.totalIncome = toFiniteNumber(campaign.totalIncome, 0);
  campaign.lastProductionTickAt = toFiniteNumber(campaign.lastProductionTickAt, 0);
  return mapWorld;
}

function findStyleById(styleId) {
  return cachedMapStyles.find((style) => style.id === styleId)
    ?? cachedMapStyles[0]
    ?? {
      id: 'astral-cartographer',
      name: 'Astral Cartographer',
      palette: {
        bgA: '#071127',
        bgB: '#162241',
        route: 'rgba(154, 196, 255, 0.46)',
        routeEnergy: 'rgba(225, 241, 255, 0.9)',
        nodeBase: '#7fb4ff',
        nodeUnoccupied: '#7488ad',
        nodeGateway: '#8deeff',
        nodeBoss: '#ff7d68',
        nodePlayer: '#7dffa2',
        hover: '#f0f8ff',
        selected: '#ffe497',
      },
    };
}

function applyMapStyle(styleId) {
  const style = findStyleById(styleId);
  const palette = style.palette ?? {};
  document.documentElement.style.setProperty('--map-bg-a', palette.bgA ?? '#071127');
  document.documentElement.style.setProperty('--map-bg-b', palette.bgB ?? '#162241');
  document.documentElement.style.setProperty('--map-route', palette.route ?? 'rgba(129, 166, 255, 0.42)');
  document.documentElement.style.setProperty('--map-route-energy', palette.routeEnergy ?? 'rgba(173, 209, 255, 0.85)');
  document.documentElement.style.setProperty('--map-node-base', palette.nodeBase ?? '#7fb4ff');
  document.documentElement.style.setProperty('--map-node-unoccupied', palette.nodeUnoccupied ?? '#7b82a8');
  document.documentElement.style.setProperty('--map-node-gateway', palette.nodeGateway ?? '#7af5f9');
  document.documentElement.style.setProperty('--map-node-boss', palette.nodeBoss ?? '#ff7d68');
  document.documentElement.style.setProperty('--map-node-player', palette.nodePlayer ?? '#7dffa2');
  document.documentElement.style.setProperty('--map-node-hover', palette.hover ?? '#e4f3ff');
  document.documentElement.style.setProperty('--map-node-selected', palette.selected ?? '#ffd882');
  return style;
}

function allAiProfiles(baseProfiles = cachedAiProfiles, profile = null) {
  const resolvedProfile = profile ?? loadProfile();
  const mapWorld = getMapWorldFast(resolvedProfile);
  const customAis = mapWorld.customAiProfiles ?? [];
  const merged = [...baseProfiles];
  customAis.forEach((ai) => {
    if (!ai?.id) return;
    const idx = merged.findIndex((entry) => entry.id === ai.id);
    if (idx >= 0) merged[idx] = { ...merged[idx], ...ai };
    else merged.push(ai);
  });
  return merged;
}

function buildGalaxyLibrary(profile, aiProfiles) {
  const mapWorld = getMapWorld(profile);
  const all = [];
  const byId = new Set();

  const pushGalaxy = (entry, source) => {
    if (!entry?.id) return;
    const identity = `${entry.id} ${entry.name ?? ''} ${entry.universe ?? ''} ${entry.seed ?? ''}`.toLowerCase();
    if (/\bvirolean[\s_-]*sea\b/.test(identity) || /\bviroleansea\b/.test(identity)) return;
    if (byId.has(entry.id)) return;
    byId.add(entry.id);
    const generated = generateGalaxyFromSeed(entry.seed ?? entry.id, {
      ...entry,
      id: entry.id,
      name: entry.name ?? entry.id,
      styleId: entry.styleId ?? mapWorld.globalMapStyleId,
      nodeType: entry.nodeType ?? (source === 'created' ? 'created' : entry.nodeType ?? 'special'),
      state: entry.state ?? (entry.occupiedByAIId || entry.ownerAiId ? 'occupied' : 'unoccupied'),
      gatewayImported: !!entry.gatewayImported,
      createdAt: entry.createdAt ?? Date.now(),
    });
    generated.source = source;
    generated.occupiedByAIId = entry.occupiedByAIId ?? entry.ownerAiId ?? mapWorld.nodeAssignments[generated.id] ?? null;
    all.push(generated);
  };

  cachedStarterGalaxies.forEach((entry) => pushGalaxy(entry, 'starter'));
  mapWorld.createdGalaxies.forEach((entry) => pushGalaxy(entry, 'created'));

  aiProfiles.forEach((ai, idx) => {
    const factionText = String(ai.faction ?? ai.personality?.title ?? '').toLowerCase();
    const dimensionTag = String(ai.personality?.dimensionTag ?? '').toLowerCase();
    const aiName = String(ai.name ?? '').toLowerCase();
    const isPirateRuntime = String(ai.id ?? '').startsWith('pirate-ai-')
      || factionText.includes('dimensional attackers')
      || factionText.includes('pirate')
      || factionText.includes('virolean')
      || dimensionTag.includes('virolean')
      || aiName.includes('virolean');
    if (isPirateRuntime) return;
    const exists = all.some((galaxy) => (galaxy.occupiedByAIId ?? galaxy.ownerAiId) === ai.id);
    if (exists) return;
    const fallback = generateGalaxyFromSeed(`${ai.id}-AUTO`, {
      id: `auto-${ai.id}`,
      name: ai.personality?.dimensionTag?.replace('#', '') ?? ai.name,
      universe: ai.personality?.dimensionTag?.replace('#', '') ?? 'Auto Dimension',
      styleId: ai.themeId ?? mapWorld.globalMapStyleId,
      nodeType: (ai.level ?? 1) >= 30 ? 'boss' : 'special',
      state: 'occupied',
      lore: ai.personality?.backstory ?? `${ai.name}'s controlled dimension.`,
      occupiedByAIId: ai.id,
      gatewayImported: false,
      createdAt: Date.now() - (idx * 2500),
    });
    fallback.source = 'auto-ai';
    all.push(fallback);
  });

  return all;
}

function resolvePirateLevel(attackers, role = 'scout', regionThreat = 4) {
  const infamy = toFiniteNumber(attackers.pirateInfamy, 0);
  const invasion = toFiniteNumber(attackers.invasionProgress, 0);
  const trace = toFiniteNumber(attackers.trace, 0);
  const base = 3 + Math.floor((infamy * 0.08) + (invasion * 0.05) + (trace * 0.04) + (regionThreat * 0.35));
  const roleMod = role === 'scout' ? -1 : role === 'marshal' ? 5 : role === 'raider' ? 1 : 0;
  if (role === 'marshal') return Math.max(20, Math.min(42, base + roleMod));
  return clamp(base + roleMod, 3, 19);
}

function pirateRoleByPressure(attackers, rand) {
  const infamy = toFiniteNumber(attackers.pirateInfamy, 0);
  const pressure = toFiniteNumber(attackers.invasionProgress, 0);
  const roll = rand();
  if (attackers.playerExposed && roll > 0.74) return 'harpoon';
  if (infamy >= 65 && roll > 0.62) return 'harpoon';
  if (pressure >= 72 && roll > 0.58) return 'raider';
  if (roll < 0.26) return 'smuggler';
  if (roll < 0.52) return 'scout';
  if (roll < 0.78) return 'raider';
  return 'salvager';
}

function choosePirateHouseForSpawn(role, level, spawnNode, attackers, rand) {
  const available = cachedPirateHouses.length
    ? cachedPirateHouses
    : Object.values(PIRATE_HOUSE_DEFAULTS).map((entry) => normalizePirateHouseDef(entry));
  if (!available.length) return normalizePirateHouseDef(PIRATE_HOUSE_DEFAULTS.red_wake);
  const styleHint = String(spawnNode?.styleId ?? '').toLowerCase();
  const levelBand = Math.max(1, Math.floor(level));
  const weighted = available.map((house) => {
    let weight = 0.75;
    if (levelBand <= 8) {
      if (house.id === 'red_wake') weight += 2.3;
      if (house.id === 'gilded_harrow') weight += 0.6;
    } else if (levelBand <= 12) {
      if (house.id === 'red_wake') weight += 1.2;
      if (house.id === 'gilded_harrow') weight += 1.5;
    } else if (levelBand <= 16) {
      if (house.id === 'null_gospel') weight += 1.8;
      if (house.id === 'gilded_harrow') weight += 1.2;
    } else if (levelBand <= 19) {
      if (house.id === 'coffin_reef') weight += 1.8;
      if (house.id === 'gilded_harrow') weight += 1.3;
    } else {
      if (house.id === 'null_gospel') weight += 1.2;
      if (house.id === 'coffin_reef') weight += 1.25;
      if (house.id === 'gilded_harrow') weight += 1.35;
      if (house.id === 'red_wake') weight += 1.1;
    }
    if (role === 'scout' && house.id === 'red_wake') weight += 0.8;
    if (role === 'smuggler' && house.id === 'gilded_harrow') weight += 0.7;
    if (role === 'harpoon' && house.id === 'null_gospel') weight += 0.8;
    if (role === 'salvager' && house.id === 'coffin_reef') weight += 0.9;
    if (role === 'marshal' && (house.id === 'gilded_harrow' || house.id === 'null_gospel')) weight += 0.9;
    if (styleHint && house.styleId && styleHint.includes(house.styleId)) weight += 0.5;
    const infamyBoost = toFiniteNumber(attackers?.pirateInfamy, 0) / 120;
    if (house.id === 'null_gospel' || house.id === 'gilded_harrow') weight += infamyBoost;
    return { house, weight };
  });
  return weightedPickEntry(weighted, rand)?.house ?? available[0];
}

function pirateNameForRole(role, rand, house = null) {
  const first = ['Ash', 'Vire', 'Kest', 'Cinder', 'Rake', 'Morrow', 'Slate', 'Dusk', 'Gale', 'Drift'];
  const second = ['Corsair', 'Brigand', 'Smuggler', 'Reaver', 'Harpooner', 'Deckhand', 'Pike', 'Ravager'];
  const titleByRole = {
    scout: 'Scout Corsair',
    raider: 'Raider Brigand',
    smuggler: 'Rift Smuggler',
    salvager: 'Salvage Reaver',
    harpoon: 'Harpoon Captain',
    marshal: 'Sea Marshal',
  };
  const name = `${first[Math.floor(rand() * first.length)]} ${second[Math.floor(rand() * second.length)]}`;
  if (role === 'marshal' && house?.wielder) return house.wielder;
  return `${name}, ${titleByRole[role] ?? 'Dimensional Attacker'}`;
}

function pirateFlavorLine(pirate, category = 'spot') {
  const house = houseById(pirate.houseId) ?? null;
  const houseTag = house?.name ? ` [${house.name}]` : '';
  if (category === 'found') return `${pirate.name}${houseTag}: Warp key signature confirmed. Running for the Virolean Sea.`;
  if (category === 'flee') return `${pirate.name}${houseTag}: Do not engage. Report this dimension and cross the sea.`;
  if (category === 'intercept') return `${pirate.name}${houseTag}: Intercept attempt logged. Burn them down or break pursuit.`;
  if (category === 'defeat') return `${pirate.name}${houseTag}: We are not the last hunters.`;
  if (category === 'boss') return `${pirate.name}${houseTag}: Mark this world. Full strike authorization.`;
  return `${pirate.name}${houseTag}: Trace residue detected in nearby lanes.`;
}

function markWarpKeyCompromised(attackers, pirateId) {
  attackers.warpKey.compromised = true;
  attackers.warpKey.compromisedByPirateId = pirateId;
}

function clearWarpKeyCompromised(attackers) {
  const fleeing = (attackers.activePirates ?? []).some((pirate) => pirate.objective === 'flee');
  if (fleeing) return;
  attackers.warpKey.compromised = false;
  attackers.warpKey.compromisedByPirateId = null;
}

function recordBattleTrace(attackers, aiLevel = 1) {
  const now = Date.now();
  const pressure = attackers.battlePressure;
  pressure.recentBattleStamps = (pressure.recentBattleStamps ?? []).filter((stamp) => (now - stamp) <= 10 * 60 * 1000);
  pressure.recentBattleStamps.push(now);
  pressure.lastBattleAt = now;
  pressure.streak = pressure.recentBattleStamps.length;
  const rapidBonus = Math.max(0, pressure.recentBattleStamps.length - 2) * 1.8;
  const levelBonus = clamp(toFiniteNumber(aiLevel, 1) * 0.24, 0, 6);
  const delta = 6 + rapidBonus + levelBonus;
  attackers.trace = clamp(attackers.trace + delta, 0, 100);
  attackers.traceState = traceStateLabel(attackers.trace, attackers.playerExposed);
  if (delta >= 10) {
    pushPirateEvent(attackers, `Dimensional wake increased by frequent battles (+${delta.toFixed(1)} trace).`, 'warn');
  }
}

function applyTraceDecay(attackers, elapsedMs) {
  const step = Math.floor(elapsedMs / 18000);
  if (step <= 0) return;
  attackers.trace = clamp(attackers.trace - (step * 1.15), 0, 100);
  attackers.traceState = traceStateLabel(attackers.trace, attackers.playerExposed);
}

function pirateEscapeImpact(attackers, pirate) {
  const base = 8 + Math.floor((pirate.level ?? 4) / 3);
  const roleBonus = pirate.role === 'scout' ? 2 : pirate.role === 'marshal' ? 10 : pirate.role === 'harpoon' ? 6 : 4;
  return base + roleBonus;
}

function registerPirateDossier(attackers, pirate, outcome) {
  attackers.pirateDossier = [...(attackers.pirateDossier ?? []), {
    pirateId: pirate.id,
    name: pirate.name,
    house: pirate.houseName ?? 'Unknown House',
    role: pirate.role,
    level: pirate.level,
    outcome,
    ts: Date.now(),
  }].slice(-80);
}

const SCAN_EMOJIS = ['🛰️', '🧭', '📡', '🧿', '🔭', '🪐', '☄️', '🌌', '🛡️', '⚙️'];

function createScanChallengeForPirate(pirate, attackers, rand) {
  const slotCount = clamp(3 + Math.floor((pirate.level ?? 4) / 10), 3, 4);
  const shuffled = [...SCAN_EMOJIS].sort(() => rand() - 0.5);
  const targets = shuffled.slice(0, slotCount);
  const decoys = shuffled.slice(slotCount, slotCount + clamp(2 + Math.floor((pirate.level ?? 4) / 16), 2, 3));
  const bank = [...targets, ...decoys].sort(() => rand() - 0.5).map((emoji, idx) => ({
    id: `scan-token-${Date.now()}-${idx}`,
    emoji,
  }));
  const slots = targets.map((emoji, idx) => ({
    id: `slot-${idx + 1}`,
    rnd: 100 + Math.floor(rand() * 900),
    targetEmoji: emoji,
    placedEmoji: null,
    locked: false,
  }));
  return {
    active: true,
    pirateId: pirate.id,
    scanNodeId: pirate.currentNodeId ?? null,
    slots,
    emojiBank: bank,
    successCount: 0,
    failCount: 0,
    maxFails: 4,
    ticksLeft: clamp(12 - Math.floor((pirate.level ?? 4) / 5), 6, 12),
    lastMessage: `${pirate.name} initiated directional scan lock. Redirect the emoji channels.`,
    cooldownUntil: Date.now() + 12000,
  };
}

function startScanChallenge(attackers, pirate, rand) {
  const current = attackers.scanChallenge ?? {};
  if (current.active) return false;
  if (Date.now() < toFiniteNumber(current.cooldownUntil, 0)) return false;
  pirate.objective = 'investigate';
  pirate.targetNodeId = pirate.currentNodeId;
  pirate.travelProgress = 0;
  attackers.scanChallenge = createScanChallengeForPirate(pirate, attackers, rand);
  pushPirateEvent(attackers, `${pirate.name} is triangulating your Warp Key signature. Counter-scan now.`, 'warn', { pirateId: pirate.id, nodeId: pirate.currentNodeId });
  return true;
}

function failScanChallenge(attackers, pirate, reason = 'counter-scan failed') {
  attackers.scanChallenge = {
    ...DIMENSIONAL_ATTACKERS_DEFAULTS.scanChallenge,
    cooldownUntil: Date.now() + 22000,
    lastMessage: `Scan failed: ${reason}`,
  };
  if (!pirate) return;
  pirate.objective = 'flee';
  pirate.targetNodeId = 'virolean-sea';
  pirate.escapeCountdown = clamp(3 + Math.floor(6 / Math.max(0.4, pirate.speed)), 3, 10);
  pirate.travelProgress = 0;
  pirate.fleeTargetY = null;
  markWarpKeyCompromised(attackers, pirate.id);
  pushPirateEvent(attackers, `${pirate.name} got a lock and is escaping for the Virolean Sea.`, 'danger', { pirateId: pirate.id, nodeId: pirate.currentNodeId });
}

function completeScanChallenge(attackers, pirate) {
  attackers.trace = clamp(attackers.trace - 5, 0, 100);
  attackers.traceState = traceStateLabel(attackers.trace, attackers.playerExposed);
  attackers.scanChallenge = {
    ...DIMENSIONAL_ATTACKERS_DEFAULTS.scanChallenge,
    cooldownUntil: Date.now() + 28000,
    lastMessage: 'Counter-scan succeeded. Pirate lock broken.',
  };
  if (pirate) {
    pirate.objective = 'patrol';
    pirate.targetNodeId = null;
    pirate.travelProgress = 0;
  }
  pushPirateEvent(attackers, 'Counter-scan succeeded. Pirate lock redirected to false channels.', 'good', { pirateId: pirate?.id ?? null, nodeId: pirate?.currentNodeId ?? null });
}

function scanSuccessMessage(rnd) {
  const pool = [
    `Successfully directed scan to RND-${rnd}.`,
    `RND-${rnd} accepted false signature feed.`,
    `Counter-pulse aligned at RND-${rnd}.`,
    `Scan vector diverted to phantom lane RND-${rnd}.`,
  ];
  return pool[Math.floor(Math.random() * pool.length)];
}

function scanFailureMessage(rnd) {
  const pool = [
    `RND-${rnd} rejected payload. Pirate triangulation tightening.`,
    `Scan mismatch at RND-${rnd}. Signature leakage increased.`,
    `Counter-scan drift at RND-${rnd}. Lock stability dropping.`,
  ];
  return pool[Math.floor(Math.random() * pool.length)];
}

function applyScanDrop(slotIndex, tokenId) {
  const profile = loadProfile();
  const mapWorld = getMapWorld(profile);
  const attackers = getDimensionalAttackers(mapWorld);
  const challenge = attackers.scanChallenge;
  if (!challenge?.active) return;
  const slot = challenge.slots?.[slotIndex];
  const token = (challenge.emojiBank ?? []).find((entry) => entry.id === tokenId) ?? null;
  if (!slot || !token || slot.locked) return;
  const pirate = (attackers.activePirates ?? []).find((entry) => entry.id === challenge.pirateId) ?? null;

  if (token.emoji === slot.targetEmoji) {
    slot.placedEmoji = token.emoji;
    slot.locked = true;
    challenge.successCount = Math.max(0, Math.floor(toFiniteNumber(challenge.successCount, 0)) + 1);
    challenge.lastMessage = scanSuccessMessage(slot.rnd);
    pushPirateEvent(attackers, challenge.lastMessage, 'good', { pirateId: pirate?.id ?? null, nodeId: pirate?.currentNodeId ?? null });
  } else {
    challenge.failCount = Math.max(0, Math.floor(toFiniteNumber(challenge.failCount, 0)) + 1);
    challenge.lastMessage = scanFailureMessage(slot.rnd);
    pushPirateEvent(attackers, challenge.lastMessage, 'warn', { pirateId: pirate?.id ?? null, nodeId: pirate?.currentNodeId ?? null });
  }

  const solved = challenge.slots.every((entry) => !!entry.locked);
  if (solved) completeScanChallenge(attackers, pirate);
  else if (challenge.failCount >= challenge.maxFails) failScanChallenge(attackers, pirate, 'counter-scan collapsed');

  mapWorld.dimensionalAttackers = attackers;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  renderBattleMap(mapProfilesRef.length ? mapProfilesRef : cachedAiProfiles, profile);
}

function onPirateEscaped(attackers, pirate, profileState = null) {
  const gain = pirateEscapeImpact(attackers, pirate);
  attackers.invasionProgress = clamp(attackers.invasionProgress + gain, 0, attackers.invasionThreshold);
  attackers.trace = clamp(attackers.trace + Math.max(1, gain * 0.2), 0, 100);
  attackers.playerExposed = attackers.invasionProgress >= attackers.invasionThreshold;
  attackers.traceState = traceStateLabel(attackers.trace, attackers.playerExposed);
  pushPirateEvent(attackers, `${pirate.name} escaped across the Virolean Sea (+${gain} invasion pressure).`, 'danger', { pirateId: pirate.id });
  registerPirateDossier(attackers, pirate, 'escaped');
  if (profileState) {
    ensureProfileStats(profileState);
    profileState.stats.invasions.piratesEscaped = Math.max(0, Number(profileState.stats.invasions.piratesEscaped ?? 0)) + 1;
  }
}

function onPirateDefeated(attackers, pirate, profileState = null) {
  const infamyGain = pirate.role === 'marshal' ? 14 : 5 + Math.floor((pirate.level ?? 5) / 4);
  attackers.pirateInfamy = clamp(attackers.pirateInfamy + infamyGain, 0, 100);
  attackers.pirateInfamyLabel = infamyLabel(attackers.pirateInfamy);
  attackers.invasionProgress = clamp(attackers.invasionProgress - (pirate.role === 'marshal' ? 18 : 8), 0, attackers.invasionThreshold);
  pushPirateEvent(attackers, `${pirate.name} was intercepted and destroyed (+${infamyGain} pirate infamy).`, 'good', { pirateId: pirate.id });
  registerPirateDossier(attackers, pirate, 'defeated');
  if (profileState) {
    ensureProfileStats(profileState);
    profileState.stats.invasions.intercepted = Math.max(0, Number(profileState.stats.invasions.intercepted ?? 0)) + 1;
  }
}

function spawnPirateRoamer(attackers, candidateNodes) {
  if (!candidateNodes.length) return null;
  const now = Date.now();
  const seed = `${now}-${attackers.trace.toFixed(2)}-${attackers.pirateInfamy.toFixed(2)}-${candidateNodes.length}`;
  const rand = rngFromSeed(seed);
  const role = pirateRoleByPressure(attackers, rand);
  const roleDef = PIRATE_ROLE_DEFS[role] ?? PIRATE_ROLE_DEFS.scout;
  const spawnNode = candidateNodes[Math.floor(rand() * candidateNodes.length)];
  const level = resolvePirateLevel(attackers, role, spawnNode.threatRating ?? 4);
  const house = choosePirateHouseForSpawn(role, level, spawnNode, attackers, rand);
  const pirate = normalizePirateRoamer({
    id: `pir-${Math.floor(now / 1000)}-${Math.floor(rand() * 9999)}`,
    name: pirateNameForRole(role, rand, house),
    role,
    level,
    houseId: house?.id ?? null,
    houseName: house?.name ?? null,
    houseWielder: house?.wielder ?? null,
    styleId: house?.styleId ?? roleDef.styleId,
    objective: attackers.trace >= 38 ? 'investigate' : 'patrol',
    currentNodeId: spawnNode.id,
    targetNodeId: null,
    speed: 0.16 + (rand() * 0.26),
    detectionPower: roleDef.detectBonus + (rand() * 0.2),
    assignedPacks: ['pirate_master_pool_v1', 'pirate_houses_v1'],
    createdAt: now,
    threat: clamp(Math.floor(level / 2), 2, 14),
  });
  attackers.activePirates.push(pirate);
  pushPirateEvent(attackers, `${pirate.name} of ${pirate.houseName || 'an unknown cell'} sighted in ${spawnNode.name}.`, 'info', { pirateId: pirate.id, nodeId: spawnNode.id });
  return pirate;
}

function choosePirateNextNode(pirate, candidateNodes, rand) {
  const current = candidateNodes.find((node) => node.id === pirate.currentNodeId) ?? candidateNodes[0];
  if (!current) return null;
  const scored = candidateNodes
    .filter((node) => node.id !== current.id && !node.playerHome)
    .map((node) => ({
      node,
      dist: Math.hypot((node.mapXHint ?? 0.5) - (current.mapXHint ?? 0.5), (node.mapYHint ?? 0.5) - (current.mapYHint ?? 0.5)),
      threat: node.threatRating ?? 4,
    }))
    .sort((a, b) => a.dist - b.dist);
  if (!scored.length) return null;
  const top = scored.slice(0, Math.min(5, scored.length));
  const pick = top[Math.floor(rand() * top.length)];
  return pick?.node ?? null;
}

function resolvePendingIntercept(attackers, profileState) {
  const pending = attackers.pendingIntercept;
  if (!pending?.pirateId) {
    attackers.lastKnownStats = {
      wins: toFiniteNumber(profileState.stats?.wins, 0),
      losses: toFiniteNumber(profileState.stats?.losses, 0),
    };
    return false;
  }
  const wins = toFiniteNumber(profileState.stats?.wins, 0);
  const losses = toFiniteNumber(profileState.stats?.losses, 0);
  const prevWins = toFiniteNumber(attackers.lastKnownStats?.wins, 0);
  const prevLosses = toFiniteNumber(attackers.lastKnownStats?.losses, 0);
  const winDelta = wins - prevWins;
  const lossDelta = losses - prevLosses;
  if (winDelta <= 0 && lossDelta <= 0) return false;
  const pirateIdx = attackers.activePirates.findIndex((entry) => entry.id === pending.pirateId);
  const pirate = pirateIdx >= 0 ? attackers.activePirates[pirateIdx] : null;
  if (pirate) {
    if (winDelta > 0) onPirateDefeated(attackers, pirate, profileState);
    else onPirateEscaped(attackers, pirate, profileState);
    attackers.activePirates.splice(pirateIdx, 1);
  }
  attackers.pendingIntercept = null;
  attackers.lastKnownStats = { wins, losses };
  clearWarpKeyCompromised(attackers);
  return true;
}

function runDimensionalAttackersTick(profileState, candidateNodes, mapWorld = null) {
  const resolvedMapWorld = mapWorld ?? getMapWorldFast(profileState);
  const attackers = getDimensionalAttackers(resolvedMapWorld);
  const now = Date.now();
  const prevTrace = attackers.trace;
  const prevInvasion = attackers.invasionProgress;
  const prevPirateCount = attackers.activePirates.length;
  const prevExposed = attackers.playerExposed;
  let changed = resolvePendingIntercept(attackers, profileState);
  let temporalChange = false;
  const elapsed = attackers.lastTickAt ? (now - attackers.lastTickAt) : 0;
  applyTraceDecay(attackers, elapsed);
  attackers.lastTickAt = now;
  attackers.pirateInfamyLabel = infamyLabel(attackers.pirateInfamy);
  attackers.traceState = traceStateLabel(attackers.trace, attackers.playerExposed);

  const scan = attackers.scanChallenge ?? DIMENSIONAL_ATTACKERS_DEFAULTS.scanChallenge;
  if (scan.active) {
    const prevTicks = Math.max(0, Math.floor(toFiniteNumber(scan.ticksLeft, 0)));
    scan.ticksLeft = Math.max(0, prevTicks - 1);
    if (scan.ticksLeft !== prevTicks) temporalChange = true;
    const scanPirate = attackers.activePirates.find((entry) => entry.id === scan.pirateId) ?? null;
    if (!scanPirate) {
      attackers.scanChallenge = {
        ...DIMENSIONAL_ATTACKERS_DEFAULTS.scanChallenge,
        cooldownUntil: Date.now() + 12000,
        lastMessage: 'Counter-scan ended. Pirate signal lost.',
      };
      changed = true;
    } else if (scan.ticksLeft <= 0) {
      failScanChallenge(attackers, scanPirate, 'scan window expired');
      changed = true;
    }
  }

  const activeMax = clamp(1 + Math.floor(attackers.pirateInfamy / 26) + (attackers.playerExposed ? 1 : 0), 1, 4);
  if ((attackers.activePirates ?? []).length < activeMax) {
    const rand = rngFromSeed(`${now}-${attackers.trace}-${attackers.pirateInfamy}-${(attackers.activePirates ?? []).length}`);
    const spawnChance = clamp(0.011 + (attackers.trace * 0.00075) + (attackers.pirateInfamy * 0.00032), 0.011, 0.16);
    if (rand() < spawnChance) {
      const pirate = spawnPirateRoamer(attackers, candidateNodes.filter((node) => !node.playerHome));
      if (pirate) changed = true;
    }
  }

  const seaAxis = clamp(toFiniteNumber(attackers.viroleanSea.axis, 0.95), 0.9, 0.98);
  const rand = rngFromSeed(`${now}-${attackers.traceState}-${attackers.activePirates.length}`);
  attackers.activePirates.forEach((pirate) => {
    if (!pirate.currentNodeId && candidateNodes[0]) {
      pirate.currentNodeId = candidateNodes[0].id;
      temporalChange = true;
    }
    const fromNode = candidateNodes.find((node) => node.id === pirate.currentNodeId) ?? candidateNodes[0];
    if (!fromNode) return;
    const seekGain = (0.55 + (attackers.trace * 0.022) + (attackers.pirateInfamy * 0.012) + (pirate.detectionPower * 0.9));
    pirate.searchProgress = clamp((pirate.searchProgress ?? 0) + seekGain, 0, 100);
    if (!pirate.targetNodeId && pirate.objective !== 'flee') {
      const next = choosePirateNextNode(pirate, candidateNodes, rand);
      pirate.targetNodeId = next?.id ?? pirate.currentNodeId;
      temporalChange = true;
    }
    if (pirate.objective === 'flee') {
      const prevCountdown = Math.max(0, pirate.escapeCountdown);
      pirate.escapeCountdown = Math.max(0, prevCountdown - 1);
      if (pirate.escapeCountdown !== prevCountdown) temporalChange = true;
      if (!Number.isFinite(pirate.fleeTargetY)) {
        pirate.fleeTargetY = clamp((fromNode?.mapYHint ?? 0.5) + ((rand() - 0.5) * 0.22), 0.08, 0.92);
        temporalChange = true;
      }
      const nextProgress = clamp(pirate.travelProgress + (0.42 * pirate.speed), 0, 1);
      if (nextProgress !== pirate.travelProgress) {
        pirate.travelProgress = nextProgress;
        temporalChange = true;
      }
      if (pirate.escapeCountdown <= 0 || pirate.travelProgress >= 1) {
        onPirateEscaped(attackers, pirate, profileState);
        pirate._remove = true;
        changed = true;
      }
      return;
    }

    const toNode = candidateNodes.find((node) => node.id === pirate.targetNodeId) ?? fromNode;
    if (!fromNode || !toNode) return;
    const nextProgress = clamp(pirate.travelProgress + (0.28 * pirate.speed), 0, 1);
    if (nextProgress !== pirate.travelProgress) {
      pirate.travelProgress = nextProgress;
      temporalChange = true;
    }
    if (pirate.travelProgress >= 1) {
      pirate.currentNodeId = toNode.id;
      pirate.travelProgress = 0;
      const next = choosePirateNextNode(pirate, candidateNodes, rand);
      pirate.targetNodeId = next?.id ?? pirate.currentNodeId;
      changed = true;
      temporalChange = true;
    }

    const proximity = clamp(1 - Math.abs((fromNode.mapXHint ?? 0.5) - seaAxis), 0, 1);
    const ageMs = Math.max(0, now - toFiniteNumber(pirate.createdAt, now));
    const graceFactor = ageMs < 12000 ? 0 : 1;
    const detectBase = (0.0006 + (attackers.trace * 0.00021) + (pirate.detectionPower * 0.0016) + (attackers.pirateInfamy * 0.00011)) * graceFactor;
    const detectRoll = detectBase + (proximity * 0.0028) + (attackers.playerExposed ? 0.0025 : 0);
    const activeScanId = attackers.scanChallenge?.active ? attackers.scanChallenge.pirateId : null;
    const searchReady = (pirate.searchProgress ?? 0) >= (58 - Math.min(20, attackers.trace * 0.2));
    if (pirate.objective !== 'flee' && !activeScanId && searchReady && rand() < detectRoll) {
      const started = startScanChallenge(attackers, pirate, rand);
      if (started) {
        pirate.searchProgress = 0;
        changed = true;
      }
    }
  });

  attackers.activePirates = attackers.activePirates.filter((pirate) => !pirate._remove);
  clearWarpKeyCompromised(attackers);

  if (!attackers.playerExposed && attackers.invasionProgress >= attackers.invasionThreshold) {
    attackers.playerExposed = true;
    attackers.bossState.pending = true;
    pushPirateEvent(attackers, 'Concealment failed. Your dimension is now EXPOSED.', 'danger');
    changed = true;
  }

  if (attackers.playerExposed && attackers.bossState.pending && !attackers.bossState.activePirateId) {
    const marshal = spawnPirateRoamer(attackers, candidateNodes.filter((node) => !node.playerHome));
    if (marshal) {
      marshal.role = 'marshal';
      marshal.level = Math.max(20, resolvePirateLevel(attackers, 'marshal', marshal.threat));
      marshal.name = pirateNameForRole('marshal', rngFromSeed(`${marshal.id}-marshal`), houseById(marshal.houseId));
      marshal.objective = 'investigate';
      marshal.detectionPower = 1.6;
      marshal.speed = 0.2;
      attackers.bossState.pending = false;
      attackers.bossState.activePirateId = marshal.id;
      attackers.bossState.lastSpawnAt = now;
      pushPirateEvent(attackers, pirateFlavorLine(marshal, 'boss'), 'danger', { pirateId: marshal.id, nodeId: marshal.currentNodeId });
      changed = true;
    }
  }

  attackers.traceState = traceStateLabel(attackers.trace, attackers.playerExposed);
  if (
    attackers.trace !== prevTrace
    || attackers.invasionProgress !== prevInvasion
    || attackers.activePirates.length !== prevPirateCount
    || attackers.playerExposed !== prevExposed
  ) {
    changed = true;
  }
  if (temporalChange) changed = true;
  resolvedMapWorld.dimensionalAttackers = attackers;
  profileState.mapWorld = resolvedMapWorld;
  return { attackers, changed };
}

function beginPirateIntercept(baseProfiles, pirateId) {
  const profile = loadProfile();
  const mapWorld = getMapWorld(profile);
  const attackers = getDimensionalAttackers(mapWorld);
  const pirate = attackers.activePirates.find((entry) => entry.id === pirateId);
  if (!pirate) {
    return { ok: false, message: 'No pirate target is currently available.' };
  }
  const aiProfile = ensurePirateAiProfile(mapWorld, pirate);
  attackers.pendingIntercept = {
    pirateId,
    aiProfileId: aiProfile?.id ?? null,
    startedAt: Date.now(),
  };
  attackers.lastKnownStats = {
    wins: toFiniteNumber(profile.stats?.wins, 0),
    losses: toFiniteNumber(profile.stats?.losses, 0),
  };
  mapWorld.dimensionalAttackers = attackers;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  const mergedAi = allAiProfiles(baseProfiles, profile);
  const queued = mergedAi.find((entry) => entry.id === aiProfile.id) ?? aiProfile;
  if (!queued) return { ok: false, message: 'Pirate battle profile failed to initialize.' };
  const worldForEncounter = findCampaignWorldByNode(profile, pirate.currentNodeId ?? '');
  const targetPlanet = chooseInvasionPlanetForWorld(worldForEncounter);
  pushPirateEvent(attackers, pirateFlavorLine(pirate, 'intercept'), 'warn', { pirateId: pirate.id, nodeId: pirate.currentNodeId });
  saveProfile(profile);
  const pirateTriangles = clamp(Math.round(toFiniteNumber((pirate.level ?? 12) / 6, 2)), 1, 6);
  const pirateStars = clamp(Math.round(toFiniteNumber((pirate.level ?? 12) / 8, 2)), 1, 5);
  startCinematic('Novice', queued, {
    rulesetId: pirate.level >= 20 ? 'massive-invasion' : 'planetary-defense',
    battleType: 'defense_conquest',
    routeTarget: 'facility_war',
    forceReset: true,
    worldId: pirate.currentNodeId ?? '',
    planetId: targetPlanet?.id ?? null,
    targetPlanetId: targetPlanet?.id ?? null,
    threatId: pirate.id,
    deckTriangles: pirateTriangles,
    deckSize: conquestDeckSizeFromTriangles(pirateTriangles),
    threatDeckSize: conquestDeckSizeFromTriangles(pirateTriangles),
    aiSkillStars: pirateStars,
    metadata: {
      threatType: 'pirate',
      factionId: normalizeConquestInvasionFactionId(pirate.houseId ?? pirate.houseName ?? 'iron-carrion-mandate'),
      deckTriangles: pirateTriangles,
      aiSkillStars: pirateStars,
      houseId: pirate.houseId ?? null,
      houseName: pirate.houseName ?? null,
      role: pirate.role ?? null,
    },
  });
  return { ok: true, message: `Intercepting ${pirate.name}.` };
}

function showTab(tab) {
  ['match', 'deck', 'quests', 'shop', 'market', 'stats', 'carnifex', 'world'].forEach((id) => {
    document.getElementById(`${id}-tab`).classList.toggle('hidden', id !== tab);
  });
  document.querySelectorAll('[data-tab]').forEach((button) => {
    const active = button.dataset.tab === tab;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
  });

  if (tab === 'world') {
    renderWorldTab(cachedAiProfiles);
  }
  if (tab === 'market') {
    renderMarketTab();
  }
  if (tab === 'stats') {
    renderStatsTab();
  }
  if (tab === 'match') {
    resumeMapRuntime();
  } else {
    suspendMapRuntime('tab-change');
  }
}

document.querySelectorAll('[data-tab]').forEach((button) => {
  button.onclick = () => showTab(button.dataset.tab);
});

async function loadAiProfiles() {
  if (LOCAL_MODE) return LOCAL_DATA.aiProfiles;
  const idx = await loadJson('./game/ai_packs/index.json', LOCAL_DATA.aiIndex);
  const out = [];
  for (const entry of idx.entries ?? []) {
    try {
      const data = await loadJson(`./game/ai_packs/${entry}`, null);
      if (data?.personality) out.push(data);
    } catch {}
  }
  return out.sort((a, b) => (a.level ?? 1) - (b.level ?? 1));
}

async function loadAllDecks() {
  if (LOCAL_MODE) return LOCAL_DATA.decks.decks ?? [];
  const idx = await loadJson('./game/deck_packs/index.json', { entries: ['starter_decks.json'] });
  const out = [];
  for (const entry of idx.entries ?? []) {
    try {
      const data = await loadJson(`./game/deck_packs/${entry}`, null);
      out.push(...(data?.decks ?? []));
    } catch {}
  }
  return out;
}

async function loadLoadingTips() {
  if (LOCAL_MODE) return LOCAL_DATA.loadingTips ?? [];
  const idx = await loadJson('./game/loading_packs/index.json', { entries: [] });
  const out = [];
  for (const entry of idx.entries ?? []) {
    try {
      const data = await loadJson(`./game/loading_packs/${entry}`, null);
      out.push(...(data?.entries ?? []));
    } catch {}
  }
  return out;
}

async function loadMapStyles() {
  const fallback = {
    styles: [
      {
        id: 'astral-cartographer',
        name: 'Astral Cartographer',
        palette: {
          bgA: '#071127',
          bgB: '#162241',
          route: 'rgba(154, 196, 255, 0.46)',
          routeEnergy: 'rgba(225, 241, 255, 0.9)',
          nodeBase: '#7fb4ff',
          nodeUnoccupied: '#7488ad',
          nodeGateway: '#8deeff',
          nodeBoss: '#ff8f75',
          nodePlayer: '#8bffc0',
          hover: '#f0f8ff',
          selected: '#ffe497',
        },
      },
    ],
  };
  if (LOCAL_MODE) return fallback.styles;
  try {
    const idx = await loadJson('./game/map_style_packs/index.json', { entries: [] });
    const out = [];
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./game/map_style_packs/${entry}`, null);
        out.push(...(pack?.styles ?? []));
      } catch {}
    }
    return out.length ? out : fallback.styles;
  } catch {
    return fallback.styles;
  }
}

async function loadStarterGalaxies() {
  if (LOCAL_MODE) return [];
  try {
    const idx = await loadJson('./game/galaxy_packs/index.json', { entries: [] });
    const out = [];
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./game/galaxy_packs/${entry}`, null);
        out.push(...(pack?.entries ?? []));
      } catch {}
    }
    return out;
  } catch {
    return [];
  }
}

async function loadPackCatalog() {
  const out = [];
  try {
    const idx = await loadJson('./packs/index.json', { entries: [] });
    for (const entry of idx.entries ?? []) {
      out.push({
        id: String(entry).replace('.json', ''),
        name: String(entry).replace('.json', '').replace(/[_-]+/g, ' '),
        source: 'core',
      });
    }
  } catch {}
  const profile = loadProfile();
  const custom = Array.isArray(profile.customPackDefs) ? profile.customPackDefs : [];
  custom.forEach((pack) => {
    if (!pack?.id) return;
    out.push({
      id: pack.id,
      name: pack.name ?? pack.id,
      source: 'custom',
    });
  });
  return out.filter((item, idx, arr) => arr.findIndex((other) => other.id === item.id) === idx);
}

async function loadPackCardsById() {
  const map = {};
  if (LOCAL_MODE) return map;
  try {
    const idx = await loadJson('./packs/index.json', { entries: [] });
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./packs/${entry}`, null);
        if (!pack || !Array.isArray(pack.cards)) continue;
        const packId = String(pack.id ?? String(entry).replace('.json', '')).toLowerCase();
        map[packId] = pack.cards.map((card) => ({
          ...card,
          packSource: card.packSource ?? packId,
          factionId: card.factionId ?? card.invasionFaction ?? packId,
          invasionFaction: card.invasionFaction ?? card.factionId ?? packId,
        }));
      } catch {}
    }
  } catch {}
  return map;
}

async function loadPirateMasterPool() {
  const fallbackCards = [
    { id: 'fallback-pirate-1', templateId: 'fallback-pirate-1', houseId: 'red_wake', houseName: 'The Red Wake Brotherhood', name: 'Fallback Corsair', type: 'minion', cost: 2, attack: 2, health: 3, def: 1, roleWeights: { scout: 1.2, raider: 1 }, levelMin: 1, levelMax: 25, tags: ['pirate', 'red_wake'] },
    { id: 'fallback-pirate-2', templateId: 'fallback-pirate-2', houseId: 'red_wake', houseName: 'The Red Wake Brotherhood', name: 'Fallback Brigand', type: 'minion', cost: 3, attack: 3, health: 3, def: 0, roleWeights: { raider: 1.3 }, levelMin: 1, levelMax: 30, tags: ['pirate', 'red_wake'] },
    { id: 'fallback-pirate-3', templateId: 'fallback-pirate-3', houseId: 'coffin_reef', houseName: 'The Coffin Reef Brotherhood', name: 'Fallback Reaver', type: 'minion', cost: 4, attack: 4, health: 5, def: 1, roleWeights: { salvager: 1.3, harpoon: 1 }, levelMin: 8, levelMax: 40, tags: ['pirate', 'coffin_reef'] },
  ];
  const fallbackHouses = Object.values(PIRATE_HOUSE_DEFAULTS).map((entry) => normalizePirateHouseDef(entry));
  if (LOCAL_MODE) return { cards: fallbackCards, houses: fallbackHouses };
  try {
    const idx = await loadJson('./game/pirate_packs/index.json', { entries: [] });
    const outCards = [];
    const outHouses = [];
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./game/pirate_packs/${entry}`, null);
        if (Array.isArray(pack?.cards)) outCards.push(...pack.cards);
        if (Array.isArray(pack?.houses)) {
          const expanded = expandPirateHousePack(pack);
          outHouses.push(...expanded.houses);
          outCards.push(...expanded.cards);
        }
      } catch {}
    }
    const dedupHouses = outHouses.filter((house, i, arr) => arr.findIndex((other) => other.id === house.id) === i);
    return {
      cards: outCards.length ? outCards : fallbackCards,
      houses: dedupHouses.length ? dedupHouses : fallbackHouses,
    };
  } catch {
    return { cards: fallbackCards, houses: fallbackHouses };
  }
}

async function loadModeRulesets() {
  if (LOCAL_MODE) return [{ id: 'fallback-modes', rulesets: FALLBACK_MODE_RULESETS }];
  try {
    const idx = await loadJson('./game/mode_packs/index.json', { entries: [] });
    const out = [];
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./game/mode_packs/${entry}`, null);
        if (Array.isArray(pack?.rulesets)) out.push(pack);
      } catch {}
    }
    return out.length ? out : [{ id: 'fallback-modes', rulesets: FALLBACK_MODE_RULESETS }];
  } catch {
    return [{ id: 'fallback-modes', rulesets: FALLBACK_MODE_RULESETS }];
  }
}

async function loadAlienFactions() {
  if (LOCAL_MODE) return FALLBACK_ALIEN_FACTIONS;
  try {
    const idx = await loadJson('./game/alien_packs/index.json', { entries: [] });
    const out = [];
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./game/alien_packs/${entry}`, null);
        out.push(...(pack?.factions ?? []));
      } catch {}
    }
    return out.length ? out : FALLBACK_ALIEN_FACTIONS;
  } catch {
    return FALLBACK_ALIEN_FACTIONS;
  }
}

async function loadEventCategories() {
  if (LOCAL_MODE) return [];
  try {
    const idx = await loadJson('./game/event_packs/index.json', { entries: [] });
    const out = [];
    for (const entry of idx.entries ?? []) {
      try {
        const pack = await loadJson(`./game/event_packs/${entry}`, null);
        out.push(...(pack?.categories ?? []));
      } catch {}
    }
    return out;
  } catch {
    return [];
  }
}

function pirateCurveTargets(role = 'scout') {
  if (role === 'raider') return { 1: 6, 2: 7, 3: 7, 4: 5, 5: 3, 6: 2 };
  if (role === 'smuggler') return { 1: 5, 2: 8, 3: 8, 4: 4, 5: 3, 6: 2 };
  if (role === 'salvager') return { 1: 4, 2: 6, 3: 9, 4: 6, 5: 3, 6: 2 };
  if (role === 'harpoon') return { 1: 4, 2: 5, 3: 8, 4: 7, 5: 4, 6: 2 };
  if (role === 'marshal') return { 1: 2, 2: 4, 3: 7, 4: 7, 5: 6, 6: 4 };
  return { 1: 7, 2: 8, 3: 7, 4: 4, 5: 3, 6: 1 };
}

function weightedPickEntry(entries, rand) {
  if (!entries.length) return null;
  const total = entries.reduce((sum, entry) => sum + Math.max(0.01, entry.weight ?? 1), 0);
  let roll = rand() * total;
  for (const entry of entries) {
    roll -= Math.max(0.01, entry.weight ?? 1);
    if (roll <= 0) return entry;
  }
  return entries[entries.length - 1];
}

function toDeckCurveBucket(cost = 1) {
  const normalized = Math.max(1, Math.floor(toFiniteNumber(cost, 1)));
  return Math.min(6, normalized);
}

function buildPirateBattleDeckFromPool(role = 'scout', level = 5, seed = null, houseId = null) {
  const sourcePool = Array.isArray(cachedPirateMasterPool) && cachedPirateMasterPool.length
    ? cachedPirateMasterPool
    : [];
  if (!sourcePool.length) return [];
  const roleDef = PIRATE_ROLE_DEFS[role] ?? PIRATE_ROLE_DEFS.scout;
  const targetHouseId = slugifyId(houseId ?? '');
  const curveTargets = pirateCurveTargets(roleDef.id);
  const rand = rngFromSeed(seed ?? `${roleDef.id}-${level}-${Date.now()}`);
  let eligible = sourcePool.filter((entry) => {
    const min = toFiniteNumber(entry.levelMin, 1);
    const max = Math.max(min, toFiniteNumber(entry.levelMax, 80));
    if (entry.bossOnly && level < 20) return false;
    return level >= min && level <= (max + 6);
  });
  if (targetHouseId) {
    const houseEligible = eligible.filter((entry) => slugifyId(entry.houseId) === targetHouseId);
    if (houseEligible.length) eligible = houseEligible;
  }
  const selected = [];
  const copyCountByTemplateId = {};
  const curveCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
  while (selected.length < 30 && eligible.length > 0) {
    const weighted = eligible.map((entry) => {
      const roleWeight = toFiniteNumber(entry.roleWeights?.[roleDef.id], 0.5);
      const generalWeight = toFiniteNumber(entry.roleWeights?.scout, 0.3) * 0.15;
      const levelBoost = clamp((level - toFiniteNumber(entry.levelMin, 1)) * 0.04, 0, 1.2);
      const bucket = toDeckCurveBucket(entry.cost);
      const target = curveTargets[bucket] ?? 4;
      const fullnessPenalty = curveCounts[bucket] > target ? 0.42 : 1;
      const templateKey = entry.templateId ?? entry.id;
      const duplicatePenalty = (copyCountByTemplateId[templateKey] ?? 0) >= 3 ? 0 : ((copyCountByTemplateId[templateKey] ?? 0) === 2 ? 0.45 : ((copyCountByTemplateId[templateKey] ?? 0) === 1 ? 0.7 : 1));
      const signatureBoost = level >= 20 && entry.signature ? 1.55 : 1;
      return {
        entry,
        weight: Math.max(0.01, (roleWeight + generalWeight + levelBoost) * fullnessPenalty * duplicatePenalty * signatureBoost),
      };
    }).filter((item) => item.weight > 0.01);
    if (!weighted.length) break;
    const picked = weightedPickEntry(weighted, rand);
    if (!picked?.entry) break;
    const card = picked.entry;
    selected.push(card);
    const templateKey = card.templateId ?? card.id;
    copyCountByTemplateId[templateKey] = (copyCountByTemplateId[templateKey] ?? 0) + 1;
    const bucket = toDeckCurveBucket(card.cost);
    curveCounts[bucket] = (curveCounts[bucket] ?? 0) + 1;
  }
  return selected.slice(0, 30).map((card, idx) => {
    const atk = Math.max(1, toFiniteNumber(card.attack, Math.max(1, Math.floor(card.cost * 0.9))));
    const hp = Math.max(1, toFiniteNumber(card.health, Math.max(1, Math.ceil(card.cost * 1.1))));
    const def = Math.max(0, toFiniteNumber(card.def, 0));
    const keywordList = Array.isArray(card.keywords) ? card.keywords.map((k) => String(k).toLowerCase()) : [];
    const normalizedType = String(card.type ?? 'minion').toLowerCase();
    const runtimeType = normalizedType === 'relic' ? 'spell' : (normalizedType === 'spell' ? 'spell' : 'minion');
    const effect = typeof card.effect === 'object' && card.effect
      ? card.effect
      : (runtimeType === 'spell'
        ? { action: 'dealDamage', amount: Math.max(1, Math.min(4, Math.ceil(toFiniteNumber(card.cost, 2) * 0.75))) }
        : {});
    return {
      id: `pirate-runtime-${card.id}-${idx}`,
      name: card.name,
      type: runtimeType,
      cost: Math.max(1, toFiniteNumber(card.cost, 1)),
      attack: atk,
      health: hp,
      def,
      taunt: keywordList.includes('guard'),
      pierce: keywordList.includes('pierce') ? 1 : 0,
      trueDamage: keywordList.includes('truedamage'),
      charge: keywordList.includes('charge'),
      race: 'pirate',
      rarity: card.rarity ?? 'common',
      tags: [...new Set(['pirate', ...(card.tags ?? [])])],
      lore: card.text ?? '',
      text: card.text ?? '',
      effect,
      ability: effect,
      houseId: card.houseId ?? targetHouseId,
      houseName: card.houseName ?? houseById(targetHouseId)?.name ?? null,
    };
  });
}

function pirateDialogueByRole(roleDef, level, house = null) {
  const roleName = roleDef?.name ?? 'Dimensional Attacker';
  const houseName = house?.name ?? 'Dimensional Attackers';
  const houseMood = house?.id ?? 'generic';
  const lineSets = {
    red_wake: {
      pre: 'Pressure doors open. Red Wake boards first.',
      low: 'Patch me later. Keep swinging.',
      strong: 'Blood trade accepted. Advance.',
    },
    coffin_reef: {
      pre: 'We toll the bell and take what remains.',
      low: 'If I fall, record the name and continue.',
      strong: 'The wake takes another debt.',
    },
    null_gospel: {
      pre: 'Silence now. Obedience follows.',
      low: 'Stability compromised. Continue interdiction.',
      strong: 'Verdict delivered. Continue suppression.',
    },
    gilded_harrow: {
      pre: 'Invoice opened. Collection in progress.',
      low: 'The contract still holds. Proceed.',
      strong: 'Marked and processed. Next account.',
    },
    generic: {
      pre: 'Signal lock acquired. Hand over the warp key trace.',
      low: 'Hull is cracking. Pulling to fallback lanes.',
      strong: 'Clean strike. Stay still.',
    },
  };
  const houseLines = lineSets[houseMood] ?? lineSets.generic;
  return {
    pre_match: [
      `${roleName} • ${houseName}: ${houseLines.pre}`,
      `${roleName}: Keep this clean and keep it moving.`,
      `${roleName}: You can surrender now and keep your people alive.`,
    ],
    low_health: [
      `${roleName}: ${houseLines.low}`,
      `${roleName}: We're bloodied, not broken.`,
      `${roleName}: Cover this lane while we regroup.`,
    ],
    strong_play: [
      `${roleName}: ${houseLines.strong}`,
      `${roleName}: Pressure up. Don't give them breathing room.`,
      `${roleName}: Good hit. Repeat it.`,
    ],
    victory_near: [
      `${roleName}: One more exchange and this dimension goes dark.`,
      `${roleName}: End line is in reach. Push now.`,
      `${roleName}: Finish this before they stabilize.`,
    ],
    defeat: [
      `${roleName}: Noted. Your signature is worth reporting anyway.`,
      `${roleName}: We lost this engagement. Not the war.`,
      `${roleName}: Smart defense. We'll adapt.`,
    ],
    post_defeat_lobby: [
      `${roleName}: You fought well, but pirate routes never close.`,
      `${roleName}: You earned the win. Keep that edge.`,
      `${roleName}: Next time we bring better guns.`,
    ],
    combo_ready: [
      `${roleName}: We chain this line and finish.`,
      `${roleName}: Stack this play and break the wall.`,
      `${roleName}: Timing window is open. Take it.`,
    ],
    big_enemy_seen: [
      `${roleName}: Heavy target spotted. Harpoon it.`,
      `${roleName}: Big one on field. Focus fire.`,
      `${roleName}: Ignore the noise, kill the giant.`,
    ],
    lobby_greeting: [
      `${roleName}: Bounty class ${level} confirmed.`,
      `${roleName}: Keep your edge sharp.`,
      `${roleName}: Another day, another war map.`,
    ],
  };
}

function ensurePirateAiProfile(mapWorld, pirate) {
  const aiId = pirate.aiProfileId ?? `pirate-ai-${pirate.id}`;
  pirate.aiProfileId = aiId;
  const idx = mapWorld.customAiProfiles.findIndex((entry) => entry.id === aiId);
  const roleDef = PIRATE_ROLE_DEFS[pirate.role] ?? PIRATE_ROLE_DEFS.scout;
  const house = houseById(pirate.houseId);
  const deck = buildPirateBattleDeckFromPool(pirate.role, pirate.level, `${pirate.id}-${pirate.level}`, pirate.houseId);
  const profile = {
    type: MAP_TYPES.CustomAiProfile,
    id: aiId,
    name: pirate.name,
    level: pirate.level,
    difficultyLabel: buildDifficultyLabel(pirate.level),
    archetype: roleDef.archetype,
    styleId: pirate.styleId ?? house?.styleId ?? roleDef.styleId,
    assignedGalaxyId: null,
    assignedPacks: pirate.assignedPacks ?? ['pirate_master_pool_v1', 'pirate_houses_v1'],
    universe: 'Virolean Fringe',
    faction: house?.name ?? 'Dimensional Attackers',
    deckIdentity: `${house?.name ?? 'Dimensional Attackers'} • ${roleDef.name} taskforce`,
    behaviorNotes: [
      `Role=${roleDef.name}`,
      `House=${house?.name ?? 'Unknown'}`,
      `Objective=${pirate.objective}`,
      `EscapeBias=${roleDef.fleeBias}`,
    ],
    rewardMeta: pirate.rewardMeta ?? `gold:${80 + (pirate.level * 4)}`,
    personality: {
      title: `${roleDef.name} of ${house?.name ?? 'the Fringe'}`,
      dimensionTag: '#Virolean-Sea',
      backstory: `${house?.name ?? 'Pirate cells'} hunt warp signatures along the Virolean boundary.`,
      chatStyle: 'threat-pragmatic',
    },
    voiceLines: pirateDialogueByRole(roleDef, pirate.level, house),
    deck,
  };
  if (idx >= 0) mapWorld.customAiProfiles[idx] = { ...mapWorld.customAiProfiles[idx], ...profile };
  else mapWorld.customAiProfiles.push(profile);
  return mapWorld.customAiProfiles.find((entry) => entry.id === aiId);
}

function buildMapPositions(nodes, width, height, options = {}) {
  const seedKeys = nodes.map((node) => node.seed ?? node.id).sort().join('|');
  const rand = seededRandom(`${getSessionSeed()}-map-layout-${nodes.length}-${seedKeys}`);
  const placed = [];
  const margin = Math.max(64, Math.round(Math.min(width, height) * 0.06));
  const seaAxis = clamp(toFiniteNumber(options.seaAxis, 0.985), 0.94, 0.996);
  const safeRightPadding = Math.max(360, toFiniteNumber(options.safeRightPadding, Math.round(width * 0.36)));
  const safeMaxX = Math.max(margin + 220, Math.floor((width * seaAxis) - safeRightPadding));
  const safeMinY = margin + 12;
  const safeMaxY = Math.max(safeMinY + 120, height - margin - 12);
  for (const node of nodes) {
    let chosen = null;
    const safeHintMax = clamp(seaAxis - 0.24, 0.5, 0.8);
    const hintX = clamp(toFiniteNumber(node.mapXHint, rand()), 0.04, safeHintMax);
    const hintY = clamp(toFiniteNumber(node.mapYHint, rand()), 0.08, 0.92);
    for (let attempt = 0; attempt < 520; attempt += 1) {
      const hintSpanX = Math.max(120, (safeMaxX - margin) * 0.14);
      const hintSpanY = Math.max(96, (safeMaxY - safeMinY) * 0.18);
      const jitterX = (rand() - 0.5) * hintSpanX;
      const jitterY = (rand() - 0.5) * hintSpanY;
      const x = clamp((hintX * safeMaxX) + jitterX, margin, safeMaxX);
      const y = clamp((hintY * height) + jitterY, safeMinY, safeMaxY);
      const nameLength = Math.max(8, String(node.name ?? '').length);
      const labelPressure = clamp((nameLength * 1.6), 26, 68);
      const minDistance = 146 + labelPressure + (node.radius * 2.4);
      const valid = placed.every((other) => Math.hypot(other.x - x, other.y - y) >= (minDistance + other.radius));
      if (valid) {
        chosen = { x, y };
        break;
      }
    }
    if (!chosen) {
      const i = placed.length;
      const cols = Math.max(3, Math.floor((safeMaxX - margin) / 284));
      const cellW = Math.max(214, (safeMaxX - margin) / Math.max(1, cols - 1));
      const cellH = 194;
      chosen = {
        x: clamp(margin + ((i % cols) * cellW), margin, safeMaxX),
        y: clamp(safeMinY + (Math.floor(i / cols) * cellH) + ((i % 2) ? 16 : 0), safeMinY, safeMaxY),
      };
    }
    placed.push({ ...node, x: chosen.x, y: chosen.y });
  }
  for (let iteration = 0; iteration < 88; iteration += 1) {
    let moved = false;
    for (let i = 0; i < placed.length; i += 1) {
      const a = placed[i];
      for (let j = i + 1; j < placed.length; j += 1) {
        const b = placed[j];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy) || 0.0001;
        const desired = 152
          + ((a.radius + b.radius) * 1.62)
          + clamp((String(a.name ?? '').length + String(b.name ?? '').length) * 0.7, 24, 72);
        if (dist >= desired) continue;
        const overlap = (desired - dist) * 0.5;
        const nx = dx / dist;
        const ny = dy / dist;
        a.x = clamp(a.x - (nx * overlap), margin, safeMaxX);
        a.y = clamp(a.y - (ny * overlap), safeMinY, safeMaxY);
        b.x = clamp(b.x + (nx * overlap), margin, safeMaxX);
        b.y = clamp(b.y + (ny * overlap), safeMinY, safeMaxY);
        moved = true;
      }
    }
    if (!moved) break;
  }
  return placed;
}

function abbreviateMapNodeLabel(name, maxLength = 14) {
  const clean = String(name ?? '').trim();
  if (!clean) return 'Unknown';
  if (clean.length <= maxLength) return clean;
  return `${clean.slice(0, Math.max(4, maxLength - 1)).trimEnd()}…`;
}

function estimateMapLabelHalfWidth(text) {
  return Math.max(24, Math.min(88, Math.round(text.length * 3.4)));
}

function buildMapRoutes(nodes) {
  const routes = [];
  for (let i = 0; i < nodes.length; i += 1) {
    const source = nodes[i];
    const nearest = [...nodes]
      .filter((node) => node.id !== source.id)
      .sort((a, b) => Math.hypot(a.x - source.x, a.y - source.y) - Math.hypot(b.x - source.x, b.y - source.y))
      .slice(0, 2);
    nearest.forEach((target) => {
      if (source.id > target.id) return;
      routes.push({ id: `${source.id}:${target.id}`, a: source.id, b: target.id, x1: source.x, y1: source.y, x2: target.x, y2: target.y });
    });
  }
  return routes;
}

function buildStaticSceneSignature(nodes = []) {
  return nodes
    .map((node) => {
      const x = Number.isFinite(node.x) ? node.x : ((node.mapXHint ?? 0) * 1000);
      const y = Number.isFinite(node.y) ? node.y : ((node.mapYHint ?? 0.5) * 1000);
      return `${node.id}:${node.stateTag}:${node.styleId}:${node.radius}:${Math.round(x)}:${Math.round(y)}`;
    })
    .sort()
    .join('|');
}

function renderDynamicThreatLayers(nodes, attackers, campaign, profiles, width, height) {
  if (!dom.mapRoamersLayer) return;
  mapView.dynamicThreatEls = mapView.dynamicThreatEls ?? {
    pirates: Object.create(null),
    aliens: Object.create(null),
    fleeLines: Object.create(null),
    wakeLines: Object.create(null),
    tradeHeat: Object.create(null),
    traders: Object.create(null),
  };
  const caches = mapView.dynamicThreatEls;
  caches.pirates = caches.pirates ?? Object.create(null);
  caches.aliens = caches.aliens ?? Object.create(null);
  caches.fleeLines = caches.fleeLines ?? Object.create(null);
  caches.wakeLines = caches.wakeLines ?? Object.create(null);
  caches.tradeHeat = caches.tradeHeat ?? Object.create(null);
  caches.traders = caches.traders ?? Object.create(null);

  if (!caches.lineLayer || caches.lineLayer.parentNode !== dom.mapRoamersLayer) {
    caches.lineLayer = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    caches.lineLayer.classList.add('roamer-line-layer');
    dom.mapRoamersLayer.appendChild(caches.lineLayer);
  }
  if (!caches.entityLayer || caches.entityLayer.parentNode !== dom.mapRoamersLayer) {
    caches.entityLayer = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    caches.entityLayer.classList.add('roamer-entity-layer');
    dom.mapRoamersLayer.appendChild(caches.entityLayer);
  }

  const nodesById = Object.fromEntries((nodes ?? []).map((node) => [node.id, node]));
  const seaAxis = clamp(toFiniteNumber(attackers.viroleanSea.axis, 0.986), 0.976, 0.996);
  const seaX = width * seaAxis;
  const seenPirates = new Set();
  const seenAliens = new Set();
  const seenLines = new Set();
  const seenWakeLines = new Set();
  const seenTradeHeat = new Set();
  const seenTraders = new Set();
  const livePiratesById = Object.fromEntries((attackers.activePirates ?? []).map((entry) => [entry.id, entry]));
  const liveThreatsById = Object.fromEntries(((campaign?.activeThreats ?? []).filter((entry) => entry && !entry.resolved)).map((entry) => [entry.id, entry]));
  const marketState = campaign?.market ?? emptyCampaignMarketState();
  const livePirateById = (pirateId) => livePiratesById[pirateId] ?? null;
  const liveThreatById = (threatId) => liveThreatsById[threatId] ?? null;
  const restoreMapHoverCard = () => {
    const fallbackNode = nodesById[mapView.hoveredNodeId] ?? nodesById[mapView.selectedNodeId] ?? null;
    if (fallbackNode) updateMapInspectCard(fallbackNode, loadProfile(), profiles);
    else dom.mapHoverCard?.classList.add('hidden');
  };
  const showTraderManifest = (trader) => {
    if (!dom.mapHoverCard) return;
    const faction = window.CardForgeMarket?.TRADER_FACTIONS?.[trader.factionId];
    const relation = relationChip(trader.factionId, marketState);
    dom.mapHoverCard.innerHTML = `
      <h4>${escapeHtml(trader.name ?? 'Trade Vessel')}</h4>
      <div class="map-inspect-grid">
        <div><strong>Faction</strong><br/>${escapeHtml(faction?.name ?? trader.subtitle ?? 'Independent')}</div>
        <div><strong>Class</strong><br/>${escapeHtml(trader.shipClass ?? trader.traderType ?? 'merchant')}</div>
        <div><strong>Relation</strong><br/>${escapeHtml(relation.label)} ${relation.score >= 0 ? '+' : ''}${relation.score}</div>
        <div><strong>ETA</strong><br/>${Math.max(0, Number(trader.eta ?? 0))}s</div>
        <div><strong>Manifest</strong><br/>${escapeHtml(trader.manifestSummary ?? 'Rotating cargo')}</div>
        <div><strong>Specialties</strong><br/>${escapeHtml((trader.specialtyPreview ?? trader.specialties ?? []).slice(0, 4).join(', ') || 'mixed')}</div>
      </div>
      <div class="market-card-tags">${(trader.manifestPreview ?? []).map((entry) => `<span class="tag-chip">${escapeHtml(entry.name)} x${entry.copies}</span>`).join('')}</div>
      <div class="map-inspect-actions">
        <button data-world-market-trader="${trader.id}">Board Market</button>
      </div>
    `;
    dom.mapHoverCard.classList.remove('hidden');
  };

  const upsertPirateElement = (pirate, pirateHouse) => {
    const existing = caches.pirates[pirate.id];
    if (existing) return existing;
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.dataset.pirateId = pirate.id;
    g.classList.add('pirate-roamer');

    const aura = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    aura.classList.add('pirate-aura');
    aura.setAttribute('cx', '0');
    aura.setAttribute('cy', '0');
    g.appendChild(aura);

    const core = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    core.classList.add('pirate-core');
    core.setAttribute('cx', '0');
    core.setAttribute('cy', '0');
    core.setAttribute('r', '6.2');
    g.appendChild(core);

    const glyph = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    glyph.classList.add('pirate-glyph');
    glyph.textContent = '☠';
    glyph.setAttribute('x', '0');
    glyph.setAttribute('y', '3.5');
    g.appendChild(glyph);

    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.classList.add('pirate-label');
    label.setAttribute('x', '0');
    label.setAttribute('y', '-11');
    label.textContent = 'PIRATE';
    g.appendChild(label);

    const hit = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    hit.classList.add('pirate-hit-target');
    hit.setAttribute('cx', '0');
    hit.setAttribute('cy', '0');
    hit.setAttribute('r', '14');
    hit.addEventListener('pointerenter', () => {
      if (mapView.dragging || mapView.leftPointerHeld) return;
      const livePirate = livePirateById(pirate.id) ?? pirate;
      const liveHouse = houseById(livePirate.houseId) ?? pirateHouse;
      const activity = pirateActivityState(livePirate, attackers);
      const danger = pirateDangerTier(livePirate);
      dom.invasionThreatSummary.textContent = `${livePirate.name} • ${liveHouse?.name ?? livePirate.houseName ?? 'Unknown House'} • Lvl ${livePirate.level} • ${activity} • ${danger.toUpperCase()} danger.`;
    });
    hit.addEventListener('click', () => {
      if (mapClickSuppressed()) return;
      const livePirate = livePirateById(pirate.id) ?? pirate;
      const result = beginPirateIntercept(profiles, livePirate.id);
      if (!result.ok && livePirate.currentNodeId && nodesById[livePirate.currentNodeId]) {
        centerMapOnNode(livePirate.currentNodeId);
      } else if (!result.ok) {
        dom.invasionThreatSummary.textContent = result.message;
      }
    });
    hit.addEventListener('contextmenu', (event) => {
      event.preventDefault();
      const livePirate = livePirateById(pirate.id) ?? pirate;
      const liveHouse = houseById(livePirate.houseId) ?? pirateHouse;
      openPirateInspectModal(livePirate, liveHouse, nodesById[livePirate.currentNodeId] ?? null, profiles);
    });
    g.appendChild(hit);
    caches.entityLayer.appendChild(g);
    const record = { g, aura, hit, label };
    caches.pirates[pirate.id] = record;
    return record;
  };

  const upsertAlienElement = (threat, targetNode, currentNode) => {
    const existing = caches.aliens[threat.id];
    if (existing) return existing;
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.classList.add('alien-threat-group');
    g.dataset.threatId = threat.id;

    const aura = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    aura.classList.add('alien-threat-aura');
    aura.setAttribute('cx', '0');
    aura.setAttribute('cy', '0');
    aura.setAttribute('r', '13');
    g.appendChild(aura);

    const markers = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    markers.classList.add('alien-threat-markers');
    g.appendChild(markers);

    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.classList.add('alien-threat-label');
    label.setAttribute('x', '0');
    label.setAttribute('y', '-9');
    label.textContent = 'INVASION';
    g.appendChild(label);

    const hit = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    hit.classList.add('alien-threat-hit');
    hit.addEventListener('pointerenter', () => {
      if (mapView.dragging || mapView.leftPointerHeld) return;
      const liveThreat = liveThreatById(threat.id) ?? threat;
      const liveCurrent = mapNodeById(liveThreat.currentNodeId ?? liveThreat.nodeId) ?? currentNode;
      const liveTarget = mapNodeById(liveThreat.targetNodeId ?? liveThreat.nodeId) ?? targetNode ?? liveCurrent;
      const movement = liveCurrent?.id !== liveTarget?.id
        ? `moving to ${liveTarget?.name ?? 'target'}`
        : `holding near ${liveTarget?.name ?? liveCurrent?.name ?? 'target'}`;
      const commander = liveThreat.commanderName
        ? `${liveThreat.commanderName}${liveThreat.commanderTitle ? `, ${liveThreat.commanderTitle}` : ''}`
        : null;
      const chips = invasionThreatDeckChips(liveThreat).join(', ');
      const danger = invasionThreatDangerTier(liveThreat).toUpperCase();
      dom.invasionThreatSummary.textContent = `${liveThreat.factionName}${commander ? ` • ${commander}` : ''} ${movement}: ${liveThreat.deckSizeEstimate} cards • ${danger} • Skill ${clamp(Number(liveThreat.aiSkillStars ?? 1), 1, 5)}★ • Tech ${liveThreat.techLevel}${chips ? ` • ${chips}` : ''}.`;
    });
    hit.addEventListener('click', () => {
      if (mapClickSuppressed()) return;
      const liveThreat = liveThreatById(threat.id) ?? threat;
      const liveCurrent = mapNodeById(liveThreat.currentNodeId ?? liveThreat.nodeId) ?? currentNode;
      const liveTarget = mapNodeById(liveThreat.targetNodeId ?? liveThreat.nodeId) ?? targetNode ?? liveCurrent;
      launchAlienThreatBattle(liveThreat, liveTarget);
    });
    hit.addEventListener('contextmenu', (event) => {
      event.preventDefault();
      const liveThreat = liveThreatById(threat.id) ?? threat;
      const liveCurrent = mapNodeById(liveThreat.currentNodeId ?? liveThreat.nodeId) ?? currentNode;
      const liveTarget = mapNodeById(liveThreat.targetNodeId ?? liveThreat.nodeId) ?? targetNode ?? liveCurrent;
      openThreatInspectModal(liveThreat, liveTarget, profiles);
    });
    g.appendChild(hit);
    caches.entityLayer.appendChild(g);
    const record = { g, markers, hit, aura, label, markerKey: '' };
    caches.aliens[threat.id] = record;
    return record;
  };

  const upsertTraderElement = (trader) => {
    const existing = caches.traders[trader.id];
    if (existing) return existing;
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.classList.add('market-trade-ship');
    g.dataset.traderId = trader.id;

    const wake = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    wake.classList.add('market-trade-ship-wake');
    g.appendChild(wake);

    const hull = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    hull.classList.add('market-trade-ship-hull');
    hull.setAttribute('d', 'M -11 5 L -4 -7 L 11 -4 L 8 7 Z');
    g.appendChild(hull);

    const emblem = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    emblem.classList.add('market-trade-ship-emblem');
    emblem.setAttribute('x', '0');
    emblem.setAttribute('y', '2');
    emblem.textContent = trader.icon ?? '◈';
    g.appendChild(emblem);

    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.classList.add('market-trade-ship-label');
    label.setAttribute('x', '0');
    label.setAttribute('y', '-10');
    label.textContent = 'TRADER';
    g.appendChild(label);

    const hit = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    hit.classList.add('market-trade-ship-hit');
    hit.setAttribute('x', '-16');
    hit.setAttribute('y', '-16');
    hit.setAttribute('width', '32');
    hit.setAttribute('height', '28');
    hit.addEventListener('pointerenter', () => {
      if (mapView.dragging || mapView.leftPointerHeld) return;
      const faction = window.CardForgeMarket?.TRADER_FACTIONS?.[trader.factionId];
      const relation = relationChip(trader.factionId, marketState);
      const stockPreview = trader.manifestPreview?.map((entry) => entry.name).join(', ') ?? '';
      dom.invasionThreatSummary.textContent = `${trader.name} • ${faction?.name ?? trader.subtitle ?? 'Merchant faction'} • ${relation.label} • ETA ${Math.max(0, Number(trader.eta ?? 0))} • ${stockPreview || 'rotating cargo'}.`;
      showTraderManifest(trader);
      g.classList.add('hovered');
    });
    hit.addEventListener('pointerleave', () => {
      g.classList.remove('hovered');
      restoreMapHoverCard();
    });
    hit.addEventListener('click', () => {
      if (mapClickSuppressed()) return;
      openMarketFromMap({ traderId: trader.id, shipId: trader.id, nodeId: trader.dockedNodeId ?? trader.nodeId ?? null });
    });
    hit.addEventListener('contextmenu', (event) => {
      event.preventDefault();
      openMarketFromMap({ traderId: trader.id, shipId: trader.id, nodeId: trader.dockedNodeId ?? trader.nodeId ?? null });
    });
    g.appendChild(hit);
    caches.entityLayer.appendChild(g);
    const record = { g, wake, hull, emblem, label, hit };
    caches.traders[trader.id] = record;
    return record;
  };

  const upsertTradeHeatLine = (routeKey) => {
    const existing = caches.tradeHeat[routeKey];
    if (existing) return existing;
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.classList.add('market-route-heat');
    line.dataset.routeKey = routeKey;
    caches.tradeHeat[routeKey] = line;
    caches.lineLayer.appendChild(line);
    return line;
  };

  (attackers.activePirates ?? []).forEach((pirate) => {
    seenPirates.add(pirate.id);
    const fromNode = nodesById[pirate.currentNodeId] ?? nodes.find((node) => !node.playerHome) ?? nodes[0];
    if (!fromNode) return;
    const toNode = pirate.objective === 'flee'
      ? null
      : (nodesById[pirate.targetNodeId] ?? fromNode);
    const activity = pirateActivityState(pirate, attackers);
    const dangerTier = pirateDangerTier(pirate);
    let x = fromNode.x;
    let y = fromNode.y;
    if (pirate.objective === 'flee') {
      const hintY = Number.isFinite(pirate.fleeTargetY) ? pirate.fleeTargetY : (fromNode.mapYHint ?? 0.5);
      const targetY = clamp(hintY * height, 22, height - 22);
      x = fromNode.x + ((seaX - fromNode.x) * clamp(pirate.travelProgress, 0, 1));
      y = fromNode.y + ((targetY - fromNode.y) * clamp(pirate.travelProgress, 0, 1));
      const lineId = pirate.id;
      let fleeLine = caches.fleeLines[lineId];
      if (!fleeLine || fleeLine.parentNode !== caches.lineLayer) {
        fleeLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        fleeLine.classList.add('pirate-escape-line');
        fleeLine.dataset.pirateId = pirate.id;
        caches.fleeLines[lineId] = fleeLine;
        caches.lineLayer.appendChild(fleeLine);
      }
      fleeLine.setAttribute('x1', String(x));
      fleeLine.setAttribute('y1', String(y));
      fleeLine.setAttribute('x2', String(seaX));
      fleeLine.setAttribute('y2', String(targetY));
      seenLines.add(lineId);
    } else if (toNode) {
      x = fromNode.x + ((toNode.x - fromNode.x) * clamp(pirate.travelProgress, 0, 1));
      y = fromNode.y + ((toNode.y - fromNode.y) * clamp(pirate.travelProgress, 0, 1));
    }
    const wakeLineId = pirate.id;
    let wakeLine = caches.wakeLines[wakeLineId];
    if (!wakeLine || wakeLine.parentNode !== caches.lineLayer) {
      wakeLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      wakeLine.classList.add('pirate-wake-line');
      wakeLine.dataset.pirateId = pirate.id;
      caches.wakeLines[wakeLineId] = wakeLine;
      caches.lineLayer.appendChild(wakeLine);
    }
    wakeLine.className.baseVal = `pirate-wake-line activity-${activity} danger-${dangerTier}`;
    wakeLine.setAttribute('x1', String(fromNode.x));
    wakeLine.setAttribute('y1', String(fromNode.y));
    wakeLine.setAttribute('x2', String(x));
    wakeLine.setAttribute('y2', String(y));
    seenWakeLines.add(wakeLineId);
    pirate.mapX = x;
    pirate.mapY = y;
    const pirateHouse = houseById(pirate.houseId);
    const pirateRecord = upsertPirateElement(pirate, pirateHouse);
    pirateRecord.g.setAttribute('class', `pirate-roamer role-${pirate.role} objective-${pirate.objective} activity-${activity} danger-${dangerTier} house-${pirate.houseId || 'independent'}`);
    pirateRecord.g.setAttribute('transform', `translate(${x.toFixed(2)} ${y.toFixed(2)})`);
    pirateRecord.aura.setAttribute('r', String(10 + Math.max(1, Math.floor((pirate.level ?? 6) / 8))));
    pirateRecord.hit.setAttribute('r', '14');
    pirateRecord.label.textContent = `Lvl ${Math.max(1, Math.round(toFiniteNumber(pirate.level, 1)))} • ${activity}`;
  });

  const threatOverlays = (campaign?.activeThreats ?? []).filter((threat) => threat?.threatType === 'alien' && !threat.resolved);
  threatOverlays.forEach((threat) => {
    seenAliens.add(threat.id);
    const currentNode = nodesById[threat.currentNodeId ?? threat.nodeId] ?? nodesById[threat.nodeId];
    if (!currentNode) return;
    const targetNode = nodesById[threat.targetNodeId] ?? currentNode;
    const progress = clamp(toFiniteNumber(threat.travelProgress, 0), 0, 1);
    const anchorX = currentNode.x + ((targetNode.x - currentNode.x) * progress);
    const anchorY = currentNode.y + ((targetNode.y - currentNode.y) * progress);
    threat.mapX = anchorX;
    threat.mapY = anchorY;
    const triangles = Math.max(1, Number(threat.deckTriangles ?? Math.ceil(Number(threat.deckSizeEstimate ?? 20) / 10)));
    const starCount = clamp(Number(threat.aiSkillStars ?? 1), 1, 5);
    const dangerTier = invasionThreatDangerTier(threat);
    const threatStyle = slugifyId(threat.threatStyle ?? '').trim() || 'standard';
    const baseX = anchorX + Math.max(14, (currentNode.radius ?? 10) + 7);
    const baseY = anchorY - Math.max(10, (currentNode.radius ?? 10));
    const gRecord = upsertAlienElement(threat, targetNode, currentNode);
    gRecord.g.setAttribute('class', `alien-threat-group rank-${threat.commanderRank || 'standard'} danger-${dangerTier} style-${threatStyle} status-${slugifyId(threat.status ?? 'moving')}`);
    gRecord.g.setAttribute('transform', `translate(${baseX.toFixed(2)} ${baseY.toFixed(2)})`);
    const color = threat.color ?? '#57e892';
    const maxTri = Math.min(8, triangles);
    const markerKey = `${maxTri}:${starCount}:${color}:${threat.deckSizeEstimate ?? 20}`;
    if (gRecord.markerKey !== markerKey) {
      gRecord.markers.innerHTML = '';
      for (let i = 0; i < maxTri; i += 1) {
        const col = i % 4;
        const row = Math.floor(i / 4);
        const tx = col * 11;
        const ty = row * 11;
        const tri = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        tri.setAttribute('points', `${tx},${ty} ${tx - 4},${ty + 8} ${tx + 4},${ty + 8}`);
        tri.setAttribute('fill', color);
        tri.setAttribute('stroke', 'rgba(206,255,220,0.8)');
        tri.setAttribute('stroke-width', '1');
        gRecord.markers.appendChild(tri);
      }
      for (let s = 0; s < starCount; s += 1) {
        const star = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        star.classList.add('alien-threat-star');
        star.textContent = '★';
        star.setAttribute('x', String(s * 8));
        star.setAttribute('y', '-5');
        gRecord.markers.appendChild(star);
      }
      gRecord.markerKey = markerKey;
    }
    gRecord.aura.setAttribute('r', String(12 + (triangles * 1.6)));
    gRecord.label.textContent = `${threat.icon ?? '△'} ${triangles}△ • ${starCount}★ • ${threat.deckSizeEstimate ?? (triangles * 10)}c`;
    gRecord.hit.setAttribute('x', '-14');
    gRecord.hit.setAttribute('y', '-22');
    gRecord.hit.setAttribute('width', String(Math.max(56, (Math.min(4, maxTri) * 11) + 26)));
    gRecord.hit.setAttribute('height', String(Math.max(40, 32 + (Math.ceil(maxTri / 4) * 11))));
  });

  Object.entries(marketState.routeHeat ?? {}).forEach(([routeKey, heat]) => {
    const [fromId, toId] = String(routeKey).split('|');
    const fromNode = nodesById[fromId];
    const toNode = nodesById[toId];
    if (!fromNode || !toNode) return;
    const line = upsertTradeHeatLine(routeKey);
    line.setAttribute('x1', String(fromNode.x));
    line.setAttribute('y1', String(fromNode.y));
    line.setAttribute('x2', String(toNode.x));
    line.setAttribute('y2', String(toNode.y));
    line.style.setProperty('--heat-opacity', String(Math.min(0.78, 0.12 + (Number(heat) * 0.12))));
    line.style.setProperty('--heat-width', String(Math.min(5.5, 1 + (Number(heat) * 0.55))));
    seenTradeHeat.add(routeKey);
  });

  (marketState.tradeShips ?? []).forEach((trader) => {
    if (!trader?.id || trader.visible === false) return;
    const route = Array.isArray(trader.routeNodeIds) ? trader.routeNodeIds : [];
    const fromNode = nodesById[route[trader.legIndex % Math.max(1, route.length)]] ?? null;
    const toNode = nodesById[route[(trader.legIndex + 1) % Math.max(1, route.length)]] ?? fromNode;
    if (!fromNode || !toNode) return;
    seenTraders.add(trader.id);
    const x = fromNode.x + ((toNode.x - fromNode.x) * clamp(toFiniteNumber(trader.travelProgress, 0), 0, 1));
    const y = fromNode.y + ((toNode.y - fromNode.y) * clamp(toFiniteNumber(trader.travelProgress, 0), 0, 1));
    const record = upsertTraderElement(trader);
    const faction = window.CardForgeMarket?.TRADER_FACTIONS?.[trader.factionId];
    record.g.style.setProperty('--trade-faction-color', faction?.palette?.primary ?? '#7fd5ff');
    record.g.style.setProperty('--trade-faction-glow', faction?.palette?.glow ?? 'rgba(127,213,255,0.35)');
    record.g.setAttribute('transform', `translate(${x.toFixed(2)} ${y.toFixed(2)})`);
    record.label.textContent = `${trader.icon ?? faction?.emblem ?? '◈'} ${Math.max(1, Number(trader.stock?.length ?? 0))} lots`;
    record.wake.setAttribute('x1', String(-18));
    record.wake.setAttribute('y1', String(8));
    record.wake.setAttribute('x2', String(-2));
    record.wake.setAttribute('y2', String(2));
    record.g.classList.toggle('docked', !!trader.dockedNodeId);
  });

  Object.keys(caches.pirates).forEach((pirateId) => {
    if (seenPirates.has(pirateId)) return;
    const record = caches.pirates[pirateId];
    if (record?.g?.parentNode) record.g.parentNode.removeChild(record.g);
    delete caches.pirates[pirateId];
  });
  Object.keys(caches.aliens).forEach((threatId) => {
    if (seenAliens.has(threatId)) return;
    const record = caches.aliens[threatId];
    if (record?.g?.parentNode) record.g.parentNode.removeChild(record.g);
    delete caches.aliens[threatId];
  });
  Object.keys(caches.fleeLines).forEach((pirateId) => {
    if (seenLines.has(pirateId)) return;
    const line = caches.fleeLines[pirateId];
    if (line?.parentNode) line.parentNode.removeChild(line);
    delete caches.fleeLines[pirateId];
  });
  Object.keys(caches.wakeLines).forEach((pirateId) => {
    if (seenWakeLines.has(pirateId)) return;
    const line = caches.wakeLines[pirateId];
    if (line?.parentNode) line.parentNode.removeChild(line);
    delete caches.wakeLines[pirateId];
  });
  Object.keys(caches.tradeHeat).forEach((routeKey) => {
    if (seenTradeHeat.has(routeKey)) return;
    const line = caches.tradeHeat[routeKey];
    if (line?.parentNode) line.parentNode.removeChild(line);
    delete caches.tradeHeat[routeKey];
  });
  Object.keys(caches.traders).forEach((traderId) => {
    if (seenTraders.has(traderId)) return;
    const record = caches.traders[traderId];
    if (record?.g?.parentNode) record.g.parentNode.removeChild(record.g);
    delete caches.traders[traderId];
  });
}

function ownerAiForNode(node, aiProfiles) {
  const ownerId = node.occupiedByAIId ?? node.ownerAiId ?? null;
  if (!ownerId) return null;
  return aiProfiles.find((ai) => ai.id === ownerId) ?? null;
}

function setSystemViewerMode(mode = 'split') {
  const normalized = ['split', 'visual', 'info'].includes(mode) ? mode : 'split';
  mapView.systemViewerMode = normalized;
  if (!dom.systemViewer) return;
  dom.systemViewer.classList.remove('mode-split', 'mode-visual', 'mode-info');
  dom.systemViewer.classList.add(`mode-${normalized}`);
  [dom.viewerModeSplitBtn, dom.viewerModeVisualBtn, dom.viewerModeInfoBtn].forEach((button) => {
    if (!button) return;
    button.classList.toggle('active', button.dataset.viewerMode === normalized);
  });
}

function setSystemViewerFocus(enabled) {
  mapView.systemViewerFocus = !!enabled;
  dom.battlemapShell?.classList.toggle('focus-system', mapView.systemViewerFocus);
  if (dom.systemFocusBtn) {
    dom.systemFocusBtn.dataset.focus = mapView.systemViewerFocus ? 'on' : 'off';
    dom.systemFocusBtn.textContent = mapView.systemViewerFocus ? 'Exit Focus' : 'Focus System';
  }
}

function updateMapRouteHighlight(nodeId = null) {
  Object.values(mapView.routeEls).forEach((line) => {
    if (!line) return;
    const active = !!nodeId && (line.dataset.a === nodeId || line.dataset.b === nodeId);
    line.classList.toggle('active', active);
  });
}

function resolveNodeInteractionState(nodeId, node) {
  if (node.stateTag === 'locked') return NODE_INTERACTION_STATES.DISABLED;
  if (mapView.animatingNodeId === nodeId) return NODE_INTERACTION_STATES.ANIMATING_IN;
  if (mapView.focusedNodeId === nodeId) return NODE_INTERACTION_STATES.FOCUSED;
  if (mapView.selectedNodeId === nodeId) return NODE_INTERACTION_STATES.SELECTED;
  if (mapView.hoveredNodeId === nodeId) return NODE_INTERACTION_STATES.HOVER;
  if (node.stateTag === 'occupied' || node.stateTag === 'boss' || node.stateTag === 'playerOwned' || node.stateTag === 'compromised' || node.stateTag === 'pirate') return NODE_INTERACTION_STATES.OCCUPIED;
  return NODE_INTERACTION_STATES.UNOCCUPIED;
}

function updateMapNodeInteractionVisuals() {
  Object.entries(mapView.nodeEls).forEach(([nodeId, g]) => {
    if (!g) return;
    const node = mapNodeById(nodeId);
    if (!node) return;
    const interactionState = resolveNodeInteractionState(nodeId, node);
    g.dataset.interactionState = interactionState;
    g.classList.toggle('hovered', interactionState === NODE_INTERACTION_STATES.HOVER);
    g.classList.toggle('selected', mapView.selectedNodeId === nodeId || interactionState === NODE_INTERACTION_STATES.SELECTED);
    g.classList.toggle('focused', interactionState === NODE_INTERACTION_STATES.FOCUSED);
    g.classList.toggle('animating-in', interactionState === NODE_INTERACTION_STATES.ANIMATING_IN);
    g.classList.toggle('disabled', interactionState === NODE_INTERACTION_STATES.DISABLED);
  });
  updateMapRouteHighlight(mapView.hoveredNodeId || mapView.selectedNodeId || null);
}

function resolveRouteRisk(route, nodesById) {
  const a = nodesById[route.a];
  const b = nodesById[route.b];
  const avgThreat = ((a?.threatRating ?? 1) + (b?.threatRating ?? 1)) / 2;
  if (avgThreat >= 8) return 'elite';
  if (avgThreat >= 5) return 'unstable';
  if ((a?.stateTag === 'gateway' || b?.stateTag === 'gateway')) return 'corrupted';
  return 'stable';
}

function updateMapInspectCard(node, profileState, aiProfiles) {
  if (!node) {
    dom.mapHoverCard.classList.add('hidden');
    return;
  }
  const ownerAi = ownerAiForNode(node, aiProfiles);
  const mapWorld = getMapWorld(profileState);
  const attackers = getDimensionalAttackers(mapWorld);
  const fleeingPirate = (attackers.activePirates ?? []).find((pirate) => pirate.objective === 'flee') ?? null;
  const interceptPirate = fleeingPirate ?? ((attackers.activePirates ?? [])[0] ?? null);
  const status = ownerAi ? mapStatus(profileState, ownerAi) : { unlocked: true, defeated: false, gate: 0 };
  const activeAlienThreat = (mapWorld.campaign?.activeThreats ?? []).find((entry) => (
    entry?.threatType === 'alien'
    && !entry.resolved
    && (entry.currentNodeId === node.id || entry.targetNodeId === node.id || entry.nodeId === node.id)
  )) ?? null;
  const statusLabel = mapTypeDisplay(node.stateTag);
  const ownerName = node.playerHome
    ? 'You'
    : ownerAi?.name ?? (node.stateTag === 'unoccupied' ? 'Unknown' : node.ownerName ?? 'Unassigned');
  const difficulty = node.playerHome
    ? (attackers.playerExposed ? 'Exposed' : 'Concealed')
    : (ownerAi ? buildDifficultyLabel(ownerAi.level ?? 1) : 'Uncharted');
  const nodePacks = node.playerHome
    ? (fleeingPirate?.assignedPacks ?? [])
    : (node.packSource ?? []);
  const packs = nodePacks.slice(0, 3).map((packId) => `<span class=\"tag-chip\">${packId}</span>`).join(' ') || '<span class=\"tag-chip\">none</span>';
  const challengeEnabled = !!activeAlienThreat
    || (node.playerHome && !!interceptPirate)
    || (!!ownerAi && status.unlocked && node.stateTag !== 'playerOwned');
  const challengeLabel = activeAlienThreat
    ? 'Defend Invasion'
    : (node.playerHome
      ? (interceptPirate ? `Engage ${interceptPirate.name}` : 'No Pirate Target')
      : 'Challenge');
  const assignEnabled = !!node.isCreated;
  const campaignWorld = findCampaignWorldByNode(profileState, node.id);
  const conquestEnabled = !!campaignWorld?.conquestUnlocked;
  const fallbackWorldOpsWorld = preferredWorldOpsWorld(profileState, attackers);
  const worldOpsEnabled = (!!campaignWorld && !campaignWorld?.lost) || (!!fallbackWorldOpsWorld && !fallbackWorldOpsWorld?.lost);
  const conquestLabel = campaignWorld
    ? `Conquest ${Math.round(toFiniteNumber(campaignWorld.conquest?.meter, 0))}%`
    : 'Conquest';
  const marketTrader = hasNodeMarketAccess(profileState, node.id);
  dom.mapHoverCard.innerHTML = `
    <h4>${node.name}</h4>
    <div class="map-inspect-grid">
      <div><strong>Status</strong><br/>${statusLabel}</div>
      <div><strong>Threat</strong><br/>${node.threatRating}</div>
      <div><strong>Seed</strong><br/>${node.seed}</div>
      <div><strong>Gateway</strong><br/>${node.gatewaySignature ?? 'n/a'}</div>
      <div><strong>Universe</strong><br/>${node.universe ?? 'Unknown'}</div>
      <div><strong>Style</strong><br/>${findStyleById(node.styleId).name}</div>
      <div><strong>Owner</strong><br/>${ownerName}</div>
      <div><strong>Difficulty</strong><br/>${difficulty}</div>
      <div><strong>Packs</strong><br/>${packs}</div>
      <div><strong>Warp Key</strong><br/>${node.playerHome ? (attackers.warpKey.compromised ? 'Compromised' : 'Concealed') : 'n/a'}</div>
      <div><strong>Conquest</strong><br/>${campaignWorld ? `${campaignWorld.conquest?.completedObjectives ?? 0}/${campaignWorld.conquest?.totalObjectives ?? 0}` : 'n/a'}</div>
      <div><strong>World Control</strong><br/>${campaignWorld ? (campaignWorld.secured ? (campaignWorld.lost ? 'Lost' : 'Owned') : 'Contested') : 'n/a'}</div>
      <div><strong>Lore</strong><br/>${node.lore ? node.lore.slice(0, 110) : 'No records.'}</div>
    </div>
    <div class="map-inspect-actions">
      <button data-node-action="focus">Focus</button>
      <button data-node-action="challenge" ${challengeEnabled ? '' : 'disabled'}>${challengeLabel}</button>
      <button data-node-action="assign" ${assignEnabled ? '' : 'disabled'}>Assign AI</button>
      <button data-node-action="conquest" ${conquestEnabled ? '' : 'disabled'}>${conquestLabel}</button>
      <button data-node-action="market" ${marketTrader ? '' : 'disabled'}>${marketTrader ? 'Open Market' : 'No Market'}</button>
      <button data-node-action="world-ops" ${worldOpsEnabled ? '' : 'disabled'}>World Ops</button>
      <button data-node-action="engage-invasion" ${activeAlienThreat ? '' : 'disabled'}>Engage Invasion</button>
      <button data-node-action="edit-galaxy">Edit Galaxy</button>
    </div>
  `;
  dom.mapHoverCard.classList.remove('hidden');
  const orbitPlanets = (campaignWorld?.planets ?? []).map((planet) => ({
    id: planet.id,
    name: planet.name,
    conquered: planet.ownership === 'owned',
    strongholdsRequired: Number(planet.strongholdsRequired ?? objectiveCompletion(planet).total ?? 0),
    strongholdsCaptured: Number(planet.strongholdsCaptured ?? objectiveCompletion(planet).done ?? 0),
  }));
  const orbitThreatMarkers = [];
  if (activeAlienThreat && campaignWorld) {
    const invadedPlanetId = resolveAlienThreatPlanetId(activeAlienThreat, campaignWorld);
    if (invadedPlanetId) {
      orbitThreatMarkers.push({
        planetId: invadedPlanetId,
        triangles: Number(activeAlienThreat.deckTriangles ?? Math.ceil(Number(activeAlienThreat.deckSizeEstimate ?? 20) / 10)),
        stars: Number(activeAlienThreat.aiSkillStars ?? 1),
        color: '#57e892',
        factionId: activeAlienThreat.factionId ?? activeAlienThreat.invasionFaction ?? 'iron-carrion-mandate',
        threatStyle: activeAlienThreat.threatStyle ?? activeAlienThreat.commanderPlaystyle ?? '',
        deckSeries: activeAlienThreat.deckSeries ?? '',
      });
    }
  }
  startOrbitAnimation(dom.mapOrbitCanvas, 'map', {
    label: node.universe ?? node.name,
    name: node.name,
    seed: node.seed,
    nodeId: node.id,
    worldId: campaignWorld?.worldId ?? null,
    planetCount: node.planetCount,
    sunCount: node.sunCount,
    orbitLayout: node.orbitLayout,
    planets: orbitPlanets,
  }, Math.max(1, node.level ?? 1), ownerName, {
    interactiveMode: conquestEnabled ? 'conquest' : 'inspect',
    selectedPlanetId: modalUiState.conquest.planetId,
    threatMarkers: orbitThreatMarkers,
    onPlanetClick: (planetEntry) => {
      if (!conquestEnabled || !campaignWorld || !planetEntry?.id) return;
      modalUiState.conquest.planetId = planetEntry.id;
      openConquestModal(node.id, aiProfiles, planetEntry.id);
    },
  });
  dom.mapHoverCard.querySelectorAll('[data-node-action]').forEach((button) => {
    button.onclick = () => {
      const action = button.dataset.nodeAction;
      if (action === 'focus') {
        centerMapOnNode(node.id);
      } else if (action === 'challenge' && challengeEnabled) {
        if (activeAlienThreat) {
          launchAlienThreatBattle(activeAlienThreat, node);
        } else if (node.playerHome && interceptPirate) {
          beginPirateIntercept(mapProfilesRef, interceptPirate.id);
        } else if (ownerAi) {
          startCinematic('Novice', ownerAi, {
            rulesetId: 'wielder-duel',
            battleType: 'wielder_duel',
            worldId: node.id,
            sourceNodeId: node.id,
            techLevel: Math.max(1, Number(campaignWorld?.techLevel ?? 1)),
            metadata: {
              factionId: campaignWorld?.factionId ?? null,
              conquestUnlocked: !!campaignWorld?.conquestUnlocked,
            },
          });
        }
      } else if (action === 'assign') {
        openModal('ai-editor-modal');
        hydrateAiEditor(node.id);
      } else if (action === 'conquest') {
        if (!conquestEnabled) return;
        const capitalId = chooseInvasionPlanetForWorld(campaignWorld)?.id ?? null;
        const selected = modalUiState.conquest.planetId && orbitPlanets.some((planet) => planet.id === modalUiState.conquest.planetId)
          ? modalUiState.conquest.planetId
          : (capitalId ?? orbitPlanets[0]?.id ?? null);
        if (selected) {
          openConquestModal(node.id, aiProfiles, selected);
        }
      } else if (action === 'market') {
        if (!marketTrader) return;
        openMarketFromMap({ traderId: marketTrader.id, nodeId: node.id, shipId: marketTrader.kind === 'ship' ? marketTrader.id : null });
      } else if (action === 'world-ops') {
        const profile = loadProfile();
        const world = findCampaignWorldByNode(profile, node.id)
          ?? preferredWorldOpsWorld(profile, getDimensionalAttackers(getMapWorld(profile)));
        if (!world) return;
        modalUiState.worldOps.worldId = world.worldId;
        modalUiState.worldOps.planetId = chooseInvasionPlanetForWorld(world)?.id ?? null;
        openWorldOpsModal(profile);
      } else if (action === 'engage-invasion') {
        if (!activeAlienThreat) return;
        launchAlienThreatBattle(activeAlienThreat, node);
      } else if (action === 'edit-galaxy') {
        openModal('galaxy-creator-modal');
        hydrateGalaxyForm(node.id);
      }
    };
  });
}
function startOrbitAnimation(canvas, handleKey, systemSpec, difficulty = 1, owner = 'Unknown', options = {}) {
  if (!canvas) return;
  if (handleKey === 'map' && (mapRuntimeSuspended || isFacilityWarOpen())) return;
  const spec = typeof systemSpec === 'object' && systemSpec
    ? systemSpec
    : { label: String(systemSpec ?? 'Unknown Dimension') };
  const label = spec.label ?? spec.name ?? 'Unknown Dimension';
  const interactiveMode = String(options?.interactiveMode ?? 'inspect');
  const onPlanetClick = typeof options?.onPlanetClick === 'function' ? options.onPlanetClick : null;
  const selectedPlanetId = options?.selectedPlanetId ? String(options.selectedPlanetId) : null;
  const threatMarkers = Array.isArray(options?.threatMarkers)
    ? options.threatMarkers
      .map((entry) => ({
        planetId: String(entry?.planetId ?? ''),
        triangles: clamp(Math.max(1, Number(entry?.triangles ?? 1)), 1, 8),
        stars: clamp(Math.max(1, Number(entry?.stars ?? 1)), 1, 5),
        color: String(entry?.color ?? '#59f08f'),
        factionId: normalizeConquestInvasionFactionId(entry?.factionId ?? ''),
        threatStyle: String(entry?.threatStyle ?? ''),
        deckSeries: String(entry?.deckSeries ?? ''),
      }))
      .filter((entry) => entry.planetId)
    : [];
  const threatByPlanet = new Map(threatMarkers.map((entry) => [entry.planetId, entry]));
  const providedPlanets = Array.isArray(spec.planets) ? spec.planets : [];
  const seed = `${getSessionSeed()}-${label}-${owner}-${spec.seed ?? ''}-${spec.planetCount ?? ''}-${spec.sunCount ?? ''}`;
  const rand = seededRandom(seed);
  const sunCount = clamp(Math.floor(toFiniteNumber(spec.sunCount, 1)), 1, 3);
  const orbitLayout = String(spec.orbitLayout ?? 'stable').toLowerCase();
  const rect = canvas.getBoundingClientRect();
  const cssWidth = Math.max(260, Math.floor(rect.width || 420));
  const cssHeight = Math.max(190, Math.floor(rect.height || 290));
  const minDimension = Math.min(cssWidth, cssHeight);
  const sunRadius = clamp(Math.round(minDimension * 0.055), 8, 16);
  const padding = 24;
  const maxOrbitRadius = Math.max(46, Math.floor((minDimension * 0.5) - sunRadius - padding));
  const orbitStart = Math.max(24, Math.floor(sunRadius + 12));
  const maxBySpace = clamp(Math.floor((maxOrbitRadius - orbitStart) / 18) + 1, 3, 12);
  const count = clamp(
    Math.floor(toFiniteNumber(providedPlanets.length || spec.planetCount, 3 + Math.floor(difficulty / 7))),
    3,
    maxBySpace,
  );
  const orbitGap = clamp(Math.floor((maxOrbitRadius - orbitStart) / Math.max(1, count - 1)), 17, 34);
  const usedRadii = [];
  const minOrbitSep = Math.max(10, orbitGap * 0.62);
  const takeOrbitRadius = (i) => {
    let r = orbitStart + (orbitGap * i);
    if (orbitLayout === 'chaotic') r += (rand() - 0.5) * orbitGap * 0.34;
    if (orbitLayout === 'spiral') r += i * 1.2;
    while (usedRadii.some((value) => Math.abs(value - r) < minOrbitSep)) r += minOrbitSep * 0.55;
    usedRadii.push(r);
    return r;
  };
  const planets = Array.from({ length: count }, (_, i) => ({
    id: String(providedPlanets[i]?.id ?? `${slugifyId(label)}-orbit-${i + 1}`),
    name: String(providedPlanets[i]?.name ?? `Planet ${i + 1}`),
    conquered: !!providedPlanets[i]?.conquered,
    strongholdsRequired: Math.max(0, Number(providedPlanets[i]?.strongholdsRequired ?? 0)),
    strongholdsCaptured: Math.max(0, Number(providedPlanets[i]?.strongholdsCaptured ?? 0)),
    orbitIndex: i,
    orbitRadius: takeOrbitRadius(i),
    angle: rand() * Math.PI * 2,
    speed: 0.0026 + (i * 0.00065) + (difficulty * 0.00004),
    sizeFactor: 0.16 + (rand() * 0.14),
    color: `hsl(${Math.floor(rand() * 360)}, 82%, 60%)`,
    drawX: 0,
    drawY: 0,
    drawR: 0,
  }));

  if (handleKey === 'map') stopOrbitAnimation('map');
  if (handleKey === 'codex') stopOrbitAnimation('codex');
  let hoveredPlanetId = null;

  const pickPlanetAt = (event) => {
    const rectNow = canvas.getBoundingClientRect();
    if (!rectNow.width || !rectNow.height) return null;
    const px = event.clientX - rectNow.left;
    const py = event.clientY - rectNow.top;
    for (let idx = planets.length - 1; idx >= 0; idx -= 1) {
      const planet = planets[idx];
      const dx = px - planet.drawX;
      const dy = py - planet.drawY;
      if ((dx * dx) + (dy * dy) <= ((planet.drawR + 6) ** 2)) return planet;
    }
    return null;
  };

  if (handleKey === 'map') {
    canvas.onpointermove = (event) => {
      const hit = pickPlanetAt(event);
      hoveredPlanetId = hit?.id ?? null;
      canvas.style.cursor = hit && interactiveMode === 'conquest' ? 'pointer' : 'default';
    };
    canvas.onpointerleave = () => {
      hoveredPlanetId = null;
      canvas.style.cursor = 'default';
    };
    canvas.onclick = (event) => {
      if (interactiveMode !== 'conquest' || !onPlanetClick) return;
      const hit = pickPlanetAt(event);
      if (!hit) return;
      mapView.orbitSelection.nodeId = String(spec.nodeId ?? mapView.selectedNodeId ?? '');
      mapView.orbitSelection.worldId = String(spec.worldId ?? mapView.orbitSelection.worldId ?? '');
      mapView.orbitSelection.planetId = hit.id;
      mapView.orbitSelection.planets = planets.map((entry) => ({ id: entry.id, name: entry.name }));
      onPlanetClick(hit);
    };
  } else {
    canvas.onclick = null;
    canvas.onpointermove = null;
    canvas.onpointerleave = null;
    canvas.style.cursor = 'default';
  }

  let frame = 0;
  let lastFrameTs = 0;
  const draw = (ts = 0) => {
    if ((ts - lastFrameTs) < 32) {
      if (handleKey === 'map') mapOrbitHandle = requestAnimationFrame(draw);
      else codexOrbitHandle = requestAnimationFrame(draw);
      return;
    }
    lastFrameTs = ts;
    frame += 1;
    const ratio = Math.max(1, Math.min(2.2, (window.devicePixelRatio || 1) * 1.35));
    const liveRect = canvas.getBoundingClientRect();
    const drawWidth = Math.max(260, Math.floor(liveRect.width || cssWidth));
    const drawHeight = Math.max(190, Math.floor(liveRect.height || cssHeight));
    const targetW = Math.max(1, Math.floor(drawWidth * ratio));
    const targetH = Math.max(1, Math.floor(drawHeight * ratio));
    if (canvas.width !== targetW || canvas.height !== targetH || frame % 120 === 0) {
      canvas.width = targetW;
      canvas.height = targetH;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.imageSmoothingEnabled = true;

    ctx.clearRect(0, 0, drawWidth, drawHeight);
    const gradient = ctx.createLinearGradient(0, 0, drawWidth, drawHeight);
    gradient.addColorStop(0, '#07112a');
    gradient.addColorStop(1, '#150e2d');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, drawWidth, drawHeight);

    const cx = drawWidth / 2;
    const cy = drawHeight / 2;
    const liveMin = Math.min(drawWidth, drawHeight);
    const liveSunRadius = clamp(Math.round(liveMin * 0.052), 9, 16);

    for (let s = 0; s < sunCount; s += 1) {
      const ang = (Math.PI * 2 * s) / sunCount;
      const offset = sunCount === 1 ? 0 : 12;
      const sx = cx + Math.cos(ang) * offset;
      const sy = cy + Math.sin(ang) * offset;
      ctx.fillStyle = s === 0 ? '#ffe5a0' : '#ffd276';
      ctx.beginPath();
      ctx.arc(sx, sy, liveSunRadius - (s * 1.5), 0, Math.PI * 2);
      ctx.fill();
    }

    planets.forEach((planet) => {
      const orbitRadius = planet.orbitRadius * (liveMin / minDimension);
      const size = clamp((orbitGap * planet.sizeFactor), 2.2, Math.max(3.8, orbitGap * 0.3));
      ctx.strokeStyle = 'rgba(130, 170, 255, 0.30)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(cx, cy, orbitRadius, 0, Math.PI * 2);
      ctx.stroke();

      planet.angle += planet.speed;
      const px = cx + Math.cos(planet.angle) * orbitRadius;
      const py = cy + Math.sin(planet.angle) * orbitRadius;
      const selected = planet.id === selectedPlanetId || planet.id === mapView.orbitSelection.planetId;
      const hovered = planet.id === hoveredPlanetId;
      planet.drawX = px;
      planet.drawY = py;
      planet.drawR = size;
      if (selected || hovered) {
        ctx.fillStyle = selected ? 'rgba(123, 235, 149, 0.25)' : 'rgba(130, 187, 255, 0.2)';
        ctx.beginPath();
        ctx.arc(px, py, size + 5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = planet.color;
      ctx.beginPath();
      ctx.arc(px, py, size, 0, Math.PI * 2);
      ctx.fill();
      if (planet.conquered) {
        ctx.fillStyle = 'rgba(126, 234, 160, 0.95)';
        ctx.font = '10px "Segoe UI", sans-serif';
        ctx.fillText('✓', px - 3, py + 3);
      }
      const marker = threatByPlanet.get(planet.id);
      if (marker) {
        const fx = conquestFactionFxProfile(marker.factionId);
        const triRows = Math.ceil(Math.min(6, marker.triangles) / 3);
        const markX = px - 7;
        const markY = py - size - (triRows * 8) - 7;
        for (let i = 0; i < marker.triangles; i += 1) {
          const col = i % 3;
          const row = Math.floor(i / 3);
          const tx = markX + (col * 6);
          const ty = markY + (row * 7);
          ctx.fillStyle = marker.color;
          ctx.beginPath();
          ctx.moveTo(tx, ty);
          ctx.lineTo(tx - 3, ty + 6);
          ctx.lineTo(tx + 3, ty + 6);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = 'rgba(216,255,225,0.9)';
          ctx.lineWidth = 0.7;
          ctx.stroke();
        }
        ctx.fillStyle = '#f0f8ff';
        ctx.font = '9px "Segoe UI", sans-serif';
        ctx.fillText('★'.repeat(marker.stars), markX - 1, markY - 5);
        const ringCount = 4 + marker.stars;
        const pulse = ((Math.sin((frame * 0.08 * fx.speed) + (planet.orbitIndex * 0.7)) + 1) * 0.5);
        for (let p = 0; p < ringCount; p += 1) {
          const t = ((frame * 0.012 * fx.speed) + ((Math.PI * 2 * p) / ringCount));
          const ringR = size + 6 + ((p % 3) * 3) + (pulse * 3);
          const sx = px + (Math.cos(t) * ringR);
          const sy = py + (Math.sin(t) * ringR);
          const alpha = 0.16 + (0.34 * pulse);
          ctx.fillStyle = `rgba(${fx.ember}, ${alpha})`;
          if (fx.style === 'shard') {
            ctx.beginPath();
            ctx.moveTo(sx, sy - 2.2);
            ctx.lineTo(sx - 1.9, sy + 2.2);
            ctx.lineTo(sx + 1.9, sy + 2.2);
            ctx.closePath();
            ctx.fill();
          } else if (fx.style === 'halo') {
            ctx.strokeStyle = `rgba(${fx.pulse}, ${0.2 + (0.34 * pulse)})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(sx, sy, 1.9 + (pulse * 0.8), 0, Math.PI * 2);
            ctx.stroke();
          } else {
            ctx.beginPath();
            ctx.arc(sx, sy, 1.15 + (pulse * 1.2), 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }
    });

    ctx.fillStyle = '#bdd1ff';
    ctx.font = '12px "Segoe UI", sans-serif';
    ctx.fillText(`Dimension: ${label}`, 10, 18);
    ctx.fillText(`Owner: ${owner}`, 10, 34);
    if (interactiveMode === 'conquest' && handleKey === 'map') {
      ctx.fillStyle = '#9dd2ff';
      ctx.font = '11px "Segoe UI", sans-serif';
      ctx.fillText('Click an orbiting planet to open conquest for that world.', 10, Math.max(46, drawHeight - 12));
      const hoverPlanet = planets.find((entry) => entry.id === hoveredPlanetId) ?? null;
      if (hoverPlanet) {
        const cap = Math.max(0, Number(hoverPlanet.strongholdsCaptured ?? 0));
        const req = Math.max(0, Number(hoverPlanet.strongholdsRequired ?? 0));
        ctx.fillText(`${hoverPlanet.name} • Strongholds ${cap}/${req}`, 10, Math.max(60, drawHeight - 28));
      }
    }

    if (handleKey === 'map') mapOrbitHandle = requestAnimationFrame(draw);
    else codexOrbitHandle = requestAnimationFrame(draw);
  };

  draw();
}

function renderBattleMap(profiles, profileState) {
  const viewportWidth = 900;
  const viewportHeight = 360;
  const mapWorld = getMapWorldFast(profileState);
  const style = applyMapStyle(mapWorld.globalMapStyleId);
  const aiProfiles = allAiProfiles(profiles, profileState);
  const galaxies = buildGalaxyLibrary(profileState, aiProfiles);
  const worldScale = clamp(toFiniteNumber(4.05 + (galaxies.length * 0.045), 4.2), 4.2, 7.2);
  const width = Math.max(viewportWidth, Math.round(viewportWidth * worldScale));
  const height = Math.max(viewportHeight, Math.round(viewportHeight * worldScale));
  mapView.viewportWidth = viewportWidth;
  mapView.viewportHeight = viewportHeight;
  mapView.worldWidth = width;
  mapView.worldHeight = height;
  if (dom.mapSvg) dom.mapSvg.setAttribute('viewBox', `0 0 ${viewportWidth} ${viewportHeight}`);
  const filters = mapWorld.mapFilters;
  const candidateNodes = galaxies.map((galaxy) => {
    const ownerAi = ownerAiForNode(galaxy, aiProfiles);
    const nodeStyleId = galaxy.styleId || mapWorld.globalMapStyleId;
    const stateTag = galaxyStateTag(galaxy, profileState);
    const ownerStatus = ownerAi ? mapStatus(profileState, ownerAi) : null;
    const threat = ownerAi ? Math.min(10, Math.max(1, Math.floor((ownerAi.level ?? 1) / 5) + (stateTag === 'boss' ? 2 : 0))) : (stateTag === 'boss' ? 9 : 4);
    const rarityScale = galaxy.rarityTier === 'legendary' ? 1.25 : galaxy.rarityTier === 'epic' ? 1.12 : 1;
    const importance = clamp(0.85 + (threat * 0.05), 0.85, 1.45) * rarityScale;
    const h = seedHash32(galaxy.seed ?? galaxy.id ?? 'node');
    return {
      ...galaxy,
      type: MAP_TYPES.MapNode,
      styleId: nodeStyleId,
      ownerName: ownerAi?.name ?? null,
      ownerTitle: ownerAi?.personality?.title ?? null,
      level: ownerAi?.level ?? (galaxy.sunCount + galaxy.planetCount),
      stateTag,
      ownerStatus,
      threatRating: threat,
      color: pickGalaxyColor(findStyleById(nodeStyleId), stateTag),
      radius: Math.round((10 + Math.min(10, Math.floor((ownerAi?.level ?? galaxy.planetCount ?? 4) / 4))) * importance),
      importance,
      isCreated: galaxy.source === 'created',
      isGateway: !!galaxy.gatewayImported || galaxy.nodeType === 'gateway',
      mapXHint: 0.08 + (((h % 1000) / 1000) * 0.72),
      mapYHint: (((Math.floor(h / 1000)) % 1000) / 1000),
    };
  });

  const tick = runDimensionalAttackersTick(profileState, candidateNodes, mapWorld);
  const attackers = tick.attackers;
  const campaignTick = runCampaignTick(profileState, candidateNodes, aiProfiles, attackers, mapWorld);
  const campaign = campaignTick.campaign;
  const aiCountBefore = (mapWorld.customAiProfiles ?? []).length;
  if ((attackers.activePirates ?? []).length) {
    attackers.activePirates.forEach((pirate) => ensurePirateAiProfile(mapWorld, pirate));
  }
  if ((mapWorld.customAiProfiles ?? []).length !== aiCountBefore) {
    tick.changed = true;
  }
  if (tick.changed || campaignTick.changed) {
    safeSaveProfile(profileState, { skipNormalize: true });
    mapView.lastTickPersistAt = Date.now();
  }

  const playerStateTag = attackers.warpKey.compromised ? 'compromised' : 'playerOwned';
  const playerHomeNode = {
    type: MAP_TYPES.MapNode,
    id: attackers.warpKey.dimensionId ?? 'player-home',
    name: 'Your Dimension',
    seed: normalizeSeed(getSessionSeed()),
    gatewaySignature: attackers.warpKey.keyId,
    universe: 'Home Dimension',
    lore: attackers.warpKey.compromised
      ? 'Warp key breach detected. Pirate scouts are fleeing toward the Virolean Sea.'
      : 'Concealed dimensional anchor. Keep trace low to stay hidden.',
    styleId: mapWorld.globalMapStyleId,
    ownerName: 'You',
    ownerTitle: 'Warp Key Holder',
    level: Math.max(1, Math.floor((profileState.stats?.wins ?? 0) / 3) + 1),
    stateTag: playerStateTag,
    ownerStatus: null,
    threatRating: attackers.warpKey.compromised ? 10 : 2,
    color: pickGalaxyColor(style, playerStateTag),
    radius: attackers.warpKey.compromised ? 16 : 12,
    importance: attackers.warpKey.compromised ? 1.35 : 1.05,
    isCreated: false,
    isGateway: false,
    playerHome: true,
    nodeType: 'player-home',
    geometry: attackers.warpKey.compromised ? 'square' : 'circle',
    mapXHint: 0.14,
    mapYHint: 0.56,
  };
  candidateNodes.push(playerHomeNode);
  mapView.baseNodes = candidateNodes.map((entry) => ({ ...entry }));
  mapView.baseSceneSig = buildStaticSceneSignature(mapView.baseNodes);

  const visible = candidateNodes.filter((node) => mapNodeMatchesFilters(node, filters));
  const usingFallbackView = visible.length === 0;
  const seaAxisForLayout = clamp(toFiniteNumber(attackers.viroleanSea.axis, 0.986), 0.976, 0.996);
  let laidOut = buildMapPositions(usingFallbackView ? candidateNodes : visible, width, height, {
    seaAxis: seaAxisForLayout,
    safeRightPadding: Math.round(width * 0.44),
  });
  laidOut = Array.isArray(laidOut)
    ? laidOut.filter((node) => node && Number.isFinite(node.x) && Number.isFinite(node.y))
    : [];
  if (!laidOut.length) {
    const fallbackNode = candidateNodes[0] ?? playerHomeNode;
    laidOut = [{
      ...fallbackNode,
      x: viewportWidth * 0.5,
      y: viewportHeight * 0.5,
      radius: Math.max(12, toFiniteNumber(fallbackNode?.radius, 12)),
    }];
  }
  const hadExistingNodes = Array.isArray(mapView.nodes) && mapView.nodes.length > 0;
  mapView.nodes = laidOut;
  mapView.routes = buildMapRoutes(laidOut);
  const selected = mapView.selectedNodeId ?? mapWorld.selectedNodeId;
  mapView.selectedNodeId = selected && laidOut.some((node) => node.id === selected) ? selected : laidOut[0]?.id ?? null;
  if (!mapView.focusedNodeId || !laidOut.some((node) => node.id === mapView.focusedNodeId)) mapView.focusedNodeId = mapView.selectedNodeId;
  ensureMapCameraHasVisibleNode(laidOut, mapView.selectedNodeId, viewportWidth, viewportHeight, !hadExistingNodes);
  if (!laidOut.some((node) => isMapNodeVisibleInViewport(node, viewportWidth, viewportHeight))) {
    const focusNode = laidOut.find((node) => node.id === mapView.selectedNodeId) ?? laidOut[0] ?? null;
    recenterMapCameraOnNode(focusNode, viewportWidth, viewportHeight);
    mapView.offscreenGuardCount = 0;
  }
  dom.mapBoundaryLayer.innerHTML = '';
  dom.mapRoutesLayer.innerHTML = '';
  dom.mapRoamersLayer.innerHTML = '';
  dom.mapNodesLayer.innerHTML = '';
  mapView.dynamicThreatEls = {
    pirates: Object.create(null),
    aliens: Object.create(null),
    fleeLines: Object.create(null),
    wakeLines: Object.create(null),
  };
  mapView.nodeEls = {};
  mapView.routeEls = {};
  const nodesById = Object.fromEntries(laidOut.map((node) => [node.id, node]));

  const seaAxis = clamp(toFiniteNumber(attackers.viroleanSea.axis, 0.986), 0.976, 0.996);
  const seaX = width * seaAxis;
  const seaShroud = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  seaShroud.classList.add('virolean-sea-shroud');
  seaShroud.setAttribute('x', String(seaX));
  seaShroud.setAttribute('y', '0');
  seaShroud.setAttribute('width', String(Math.max(0, width - seaX)));
  seaShroud.setAttribute('height', String(height));
  dom.mapBoundaryLayer.appendChild(seaShroud);

  const seaLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  seaLine.classList.add('virolean-sea-line');
  seaLine.setAttribute('x1', String(seaX));
  seaLine.setAttribute('y1', '0');
  seaLine.setAttribute('x2', String(seaX));
  seaLine.setAttribute('y2', String(height));
  dom.mapBoundaryLayer.appendChild(seaLine);

  const seaLabel = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  seaLabel.classList.add('virolean-sea-label');
  seaLabel.textContent = `${attackers.viroleanSea.label} (Locked)`;
  seaLabel.setAttribute('x', String(seaX + 8));
  seaLabel.setAttribute('y', '18');
  dom.mapBoundaryLayer.appendChild(seaLabel);

  mapView.routes.forEach((route) => {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    const routeRisk = resolveRouteRisk(route, nodesById);
    line.classList.add('map-route', `risk-${routeRisk}`);
    line.dataset.routeId = route.id;
    line.dataset.a = route.a;
    line.dataset.b = route.b;
    line.dataset.risk = routeRisk;
    const importance = Math.max(nodesById[route.a]?.importance ?? 1, nodesById[route.b]?.importance ?? 1);
    line.setAttribute('x1', String(route.x1));
    line.setAttribute('y1', String(route.y1));
    line.setAttribute('x2', String(route.x2));
    line.setAttribute('y2', String(route.y2));
    line.setAttribute('stroke-width', String((1.6 + ((importance - 1) * 1.4)).toFixed(2)));
    mapView.routeEls[route.id] = line;
    dom.mapRoutesLayer.appendChild(line);
  });

  const labelAnchors = [];
  laidOut.forEach((node) => {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.classList.add('dim-node', `state-${node.stateTag}`);
    g.dataset.id = node.id;
    if (node.id === mapView.selectedNodeId && node.isGateway) g.classList.add('spawned');
    g.dataset.interactionState = NODE_INTERACTION_STATES.IDLE;

    const hit = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    hit.classList.add('node-hit-target');
    hit.setAttribute('cx', String(node.x));
    hit.setAttribute('cy', String(node.y));
    hit.setAttribute('r', String(Math.max(20, node.radius + 8)));

    const ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    ring.classList.add('node-ring');
    ring.setAttribute('cx', String(node.x));
    ring.setAttribute('cy', String(node.y));
    ring.setAttribute('r', String(node.radius + 5));
    ring.setAttribute('fill', 'none');
    ring.setAttribute('stroke', 'rgba(160,190,255,0.3)');
    ring.setAttribute('stroke-width', '1.5');

    let core;
    if (node.geometry === 'square') {
      core = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      core.classList.add('node-core', 'node-core-square');
      core.setAttribute('x', String(node.x - node.radius));
      core.setAttribute('y', String(node.y - node.radius));
      core.setAttribute('width', String(node.radius * 2));
      core.setAttribute('height', String(node.radius * 2));
      core.setAttribute('rx', '3');
      core.setAttribute('fill', node.color);
      core.setAttribute('stroke', '#ffd2d8');
      core.setAttribute('stroke-width', '2.3');
    } else {
      core = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      core.classList.add('node-core');
      core.setAttribute('cx', String(node.x));
      core.setAttribute('cy', String(node.y));
      core.setAttribute('r', String(node.radius));
      core.setAttribute('fill', node.color);
      core.setAttribute('stroke', '#d9ebff');
      core.setAttribute('stroke-width', '2.1');
    }

    const levelText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    levelText.classList.add('node-level');
    levelText.textContent = node.stateTag === 'unoccupied' || node.stateTag === 'hidden' ? '?' : String(node.level ?? 1);
    levelText.setAttribute('x', String(node.x));
    levelText.setAttribute('y', String(node.y + 4));
    levelText.setAttribute('text-anchor', 'middle');
    levelText.setAttribute('fill', '#061022');
    levelText.setAttribute('font-size', '11');
    levelText.setAttribute('font-weight', '700');

    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    icon.classList.add('node-icon');
    icon.textContent = mapNodeIcon(node.stateTag);
    icon.setAttribute('x', String(node.x + Math.max(9, node.radius - 2)));
    icon.setAttribute('y', String(node.y - Math.max(8, node.radius - 3)));

    const name = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    name.classList.add('node-label');
    const displayLabel = abbreviateMapNodeLabel(node.name, 12);
    name.textContent = displayLabel;
    let labelX = node.x;
    let labelY = node.y - (node.radius + 12);
    let placedLabel = false;
    const halfW = estimateMapLabelHalfWidth(displayLabel);
    const placements = [
      { dx: 0, dy: 0 },
      { dx: 0, dy: -16 },
      { dx: 0, dy: 16 },
      { dx: 28, dy: -8 },
      { dx: -28, dy: -8 },
      { dx: 34, dy: 10 },
      { dx: -34, dy: 10 },
      { dx: 0, dy: -30 },
      { dx: 0, dy: 28 },
    ];
    for (const candidate of placements) {
      const cx = clamp(node.x + candidate.dx, halfW + 6, width - halfW - 6);
      const cy = clamp((node.y - (node.radius + 12)) + candidate.dy, 16, height - 10);
      const collides = labelAnchors.some((anchor) => {
        const dx = Math.abs(anchor.x - cx);
        const dy = Math.abs(anchor.y - cy);
        return dx < (anchor.hw + halfW + 8) && dy < 15;
      });
      if (!collides) {
        labelX = cx;
        labelY = cy;
        placedLabel = true;
        break;
      }
    }
    if (!placedLabel) {
      const fallbackBand = 22 + ((labelAnchors.length % 9) * 17);
      labelX = clamp(node.x + ((labelAnchors.length % 2 ? 1 : -1) * (44 + (labelAnchors.length % 3) * 10)), halfW + 6, width - halfW - 6);
      labelY = clamp(node.y - (node.radius + fallbackBand), 16, height - 10);
    }
    labelAnchors.push({ x: labelX, y: labelY, hw: halfW });
    name.setAttribute('x', String(labelX));
    name.setAttribute('y', String(labelY));
    name.setAttribute('text-anchor', 'middle');
    name.setAttribute('fill', '#d9e8ff');
    name.setAttribute('font-size', '10');

    const badge = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    badge.classList.add('node-status-badge');
    badge.textContent = mapTypeDisplay(node.stateTag);
    badge.setAttribute('x', String(labelX));
    badge.setAttribute('y', String(node.y + node.radius + 16));

    g.appendChild(hit);
    g.appendChild(ring);
    g.appendChild(core);
    g.appendChild(icon);
    g.appendChild(levelText);
    g.appendChild(name);
    g.appendChild(badge);

    const hoverIn = () => {
      if (mapView.dragging || mapView.leftPointerHeld) return;
      mapView.hoveredNodeId = node.id;
      updateMapNodeInteractionVisuals();
      updateMapInspectCard(node, profileState, aiProfiles);
    };
    const hoverOut = () => {
      if (mapView.hoveredNodeId !== node.id) return;
      mapView.hoveredNodeId = null;
      updateMapNodeInteractionVisuals();
    };
    const selectNode = () => {
      if (node.playerHome) {
        const profileNow = loadProfile();
        const attackersNow = getDimensionalAttackers(getMapWorld(profileNow));
        const fleeingPirate = (attackersNow.activePirates ?? []).find((pirate) => pirate.objective === 'flee') ?? null;
        if (attackersNow.warpKey.compromised && fleeingPirate) {
          const result = beginPirateIntercept(profiles, fleeingPirate.id);
          if (!result.ok && dom.invasionThreatSummary) dom.invasionThreatSummary.textContent = result.message;
          return;
        }
      }
      mapView.selectedNodeId = node.id;
      mapView.focusedNodeId = node.id;
      withProfile((next) => {
        const mw = getMapWorld(next);
        mw.selectedNodeId = node.id;
        next.mapWorld = mw;
      });
      updateMapNodeInteractionVisuals();
      updateMapInspectCard(node, loadProfile(), aiProfiles);
    };
    hit.addEventListener('pointerenter', hoverIn);
    hit.addEventListener('pointerleave', hoverOut);
    hit.addEventListener('focus', hoverIn);
    hit.addEventListener('blur', hoverOut);
    hit.addEventListener('click', (event) => {
      if (mapClickSuppressed()) {
        event.preventDefault();
        return;
      }
      selectNode();
    });

    mapView.nodeEls[node.id] = g;
    dom.mapNodesLayer.appendChild(g);
  });

  // Keep threat overlays above node hit targets so alien/pirate markers stay clickable.
  if (dom.mapPanzoomRoot && dom.mapRoamersLayer) {
    dom.mapPanzoomRoot.appendChild(dom.mapRoamersLayer);
  }

  renderDynamicThreatLayers(laidOut, attackers, campaign, profiles, width, height);

  applyMapTransform();
  setSystemViewerMode(mapView.systemViewerMode);
  setSystemViewerFocus(mapView.systemViewerFocus);
  updateMapNodeInteractionVisuals();
  bindMapInteractionHandlers(profiles);
  mapView.lastWarpCompromised = !!attackers.warpKey?.compromised;
  mapView.sceneStaticSig = buildStaticSceneSignature(laidOut);
  startMapEffects(style, laidOut, mapView.sceneStaticSig);
  const selectedNode = laidOut.find((node) => node.id === mapView.selectedNodeId) ?? laidOut[0] ?? null;
  if (usingFallbackView) {
    if (dom.mapHoverCard) {
      dom.mapHoverCard.innerHTML = '<h4>No Nodes Match Current Filters</h4><div>Showing full map for reference. Adjust search/filter options to narrow results.</div>';
      dom.mapHoverCard.classList.remove('hidden');
    }
  } else {
    if (selectedNode) updateMapInspectCard(selectedNode, profileState, aiProfiles);
  }
  renderInvasionPanel(attackers, profiles, profileState, mapWorld, campaign);
}

function renderScanChallengePanel(attackers) {
  if (!dom.scanChallengePanel) return;
  const challenge = attackers.scanChallenge ?? {};
  if (!challenge.active) {
    dom.scanChallengePanel.classList.add('hidden');
    if (dom.scanChallengeTargets) dom.scanChallengeTargets.innerHTML = '';
    if (dom.scanChallengeBank) dom.scanChallengeBank.innerHTML = '';
    if (dom.scanChallengeMessage) dom.scanChallengeMessage.textContent = challenge.lastMessage || '';
    return;
  }
  const pirate = (attackers.activePirates ?? []).find((entry) => entry.id === challenge.pirateId) ?? null;
  dom.scanChallengePanel.classList.remove('hidden');
  dom.scanChallengeTitle.textContent = pirate
    ? `Detection Counter-Scan • ${pirate.name}`
    : 'Detection Counter-Scan';
  dom.scanChallengeTimer.textContent = `${Math.max(0, challenge.ticksLeft)} ticks`;
  dom.scanChallengeMessage.textContent = challenge.lastMessage || 'Drag the emoji channels into their target RND slots.';

  dom.scanChallengeTargets.innerHTML = '';
  (challenge.slots ?? []).forEach((slot, idx) => {
    const card = document.createElement('div');
    card.className = `scan-slot-card ${slot.locked ? 'locked' : 'open'}`;
    card.dataset.slotIndex = String(idx);
    card.innerHTML = `
      <div class="scan-slot-head">RND-${slot.rnd}</div>
      <div class="scan-slot-target">Target: ${slot.targetEmoji}</div>
      <div class="scan-slot-drop">${slot.locked ? slot.placedEmoji : 'Drop Emoji'}</div>
    `;
    card.addEventListener('dragover', (event) => event.preventDefault());
    card.addEventListener('drop', (event) => {
      event.preventDefault();
      const tokenId = event.dataTransfer?.getData('text/plain') || scanSelectedTokenId;
      if (!tokenId) return;
      applyScanDrop(idx, tokenId);
    });
    card.addEventListener('click', () => {
      if (scanSelectedTokenId) applyScanDrop(idx, scanSelectedTokenId);
    });
    dom.scanChallengeTargets.appendChild(card);
  });

  dom.scanChallengeBank.innerHTML = '';
  (challenge.emojiBank ?? []).forEach((token) => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = `scan-emoji-chip ${scanSelectedTokenId === token.id ? 'selected' : ''}`;
    chip.textContent = token.emoji;
    chip.draggable = true;
    chip.dataset.tokenId = token.id;
    chip.addEventListener('dragstart', (event) => {
      scanSelectedTokenId = token.id;
      event.dataTransfer?.setData('text/plain', token.id);
      event.dataTransfer.effectAllowed = 'move';
    });
    chip.addEventListener('click', () => {
      scanSelectedTokenId = token.id;
      renderScanChallengePanel(attackers);
    });
    dom.scanChallengeBank.appendChild(chip);
  });
}

function preferredWorldOpsWorld(profileNow, attackers) {
  const mapWorldNow = getMapWorldFast(profileNow);
  const campaign = mapWorldNow.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const selectedNode = mapNodeById(mapView.selectedNodeId);
  const selectedWorld = selectedNode ? findCampaignWorldByNode(profileNow, selectedNode.id) : null;
  if (selectedWorld && !selectedWorld.lost) return selectedWorld;
  const homeWorldId = String(attackers?.warpKey?.dimensionId ?? '').trim();
  if (homeWorldId) {
    const homeWorld = campaign.worldStates?.[homeWorldId] ?? null;
    if (homeWorld && !homeWorld.lost) return homeWorld;
  }
  const fallback = Object.values(campaign.worldStates ?? {})
    .filter((world) => world && !world.lost)
    .sort((a, b) => Number(b.secured) - Number(a.secured))[0];
  return fallback ?? null;
}

function invasionThreatMatchesFilter(threat, filter = 'all') {
  const normalized = String(filter ?? 'all').toLowerCase();
  if (!threat || normalized === 'all') return true;
  const chips = new Set(invasionThreatDeckChips(threat).map((entry) => String(entry).toLowerCase()));
  const stars = clamp(Math.round(toFiniteNumber(threat.aiSkillStars, 1)), 1, 5);
  const rank = String(threat.commanderRank ?? '').toLowerCase();
  if (normalized === 'urgent') return invasionThreatUrgencyScore(threat) >= 98;
  if (normalized === 'siege') return chips.has('siege') || chips.has('breach') || chips.has('anti-structure') || chips.has('vehicle');
  if (normalized === 'swarm') return chips.has('swarm') || chips.has('horde') || chips.has('growth');
  if (normalized === 'air') return chips.has('air') || chips.has('flying') || chips.has('harrier');
  if (normalized === 'elite') return stars >= 4 || rank === 'elite' || rank === 'boss' || chips.has('elite') || chips.has('command');
  return true;
}

function renderActiveAlienFleetList(profileNow, baseProfiles = [], mapWorldNow = null, campaignNow = null) {
  if (!dom.invasionAlienSection || !dom.invasionAlienList) return;
  const resolvedMapWorld = mapWorldNow ?? getMapWorldFast(profileNow);
  const campaign = campaignNow ?? resolvedMapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const activeAliens = (campaign.activeThreats ?? [])
    .filter((entry) => entry?.threatType === 'alien' && !entry.resolved)
    .sort((a, b) => invasionThreatUrgencyScore(b) - invasionThreatUrgencyScore(a));
  const filterMode = String(mapView.threatFilter ?? 'all').toLowerCase();
  const filteredAliens = activeAliens.filter((threat) => invasionThreatMatchesFilter(threat, filterMode));
  const alienSig = `${filterMode}|${filteredAliens.map((threat) => [
    threat.id,
    threat.currentNodeId ?? '',
    threat.targetNodeId ?? '',
    threat.targetPlanetId ?? '',
    threat.deckSizeEstimate ?? 0,
    threat.aiSkillStars ?? 1,
    threat.techLevel ?? 1,
    threat.threatStyle ?? '',
    threat.commanderRank ?? '',
  ].join('|')).join('~')}`;
  if (mapView.invasionAlienSig === alienSig) return;
  mapView.invasionAlienSig = alienSig;
  dom.invasionAlienSection.classList.toggle('hidden', activeAliens.length === 0);
  dom.invasionAlienList.innerHTML = '';
  if (!activeAliens.length) return;
  if (!filteredAliens.length) {
    dom.invasionAlienList.innerHTML = '<div class="invasion-feed-empty">No active fleets match the current threat filter.</div>';
    return;
  }
  filteredAliens.forEach((threat) => {
    const currentNode = mapNodeById(threat.currentNodeId ?? threat.nodeId) ?? null;
    const targetNode = mapNodeById(threat.targetNodeId ?? threat.nodeId) ?? currentNode;
    const worldState = campaign.worldStates?.[targetNode?.id ?? currentNode?.id ?? ''] ?? null;
    const targetPlanet = chooseInvasionPlanetForWorld(worldState, threat.targetPlanetId);
    const fallbackNode = targetNode ?? currentNode ?? {
      id: String(threat.targetNodeId ?? threat.currentNodeId ?? threat.nodeId ?? `threat-${threat.id}`),
      name: String(threat.region ?? threat.factionName ?? 'Unknown Region'),
      universe: String(threat.region ?? 'Unknown'),
      styleId: 'astral-cartographer',
    };
    const commander = threat.commanderName
      ? `${threat.commanderName}${threat.commanderTitle ? `, ${threat.commanderTitle}` : ''}`
      : 'Field Command';
    const row = document.createElement('div');
    const dangerTier = invasionThreatDangerTier(threat);
    const urgency = Math.round(invasionThreatUrgencyScore(threat));
    row.className = `invasion-alien-row tier-${dangerTier}`;
    const doctrineLabel = conquestDoctrineLabelForThreat(threat.factionId, threat.aiSkillStars);
    const triangleCount = clamp(Math.round(toFiniteNumber(threat.deckTriangles, toFiniteNumber(threat.deckSizeEstimate, 30) / 10)), 1, 6);
    const variant = threat.deckVariant ?? conquestDeckVariantForStars(threat.aiSkillStars);
    const deckSeries = threat.deckSeries ?? conquestDeckSeriesName(threat.factionId, triangleCount, variant);
    const deckChips = invasionThreatDeckChips(threat);
    const chipHtml = threatChipMarkup(deckChips, 'is-style');
    const commanderStars = '★'.repeat(clamp(Number(threat.aiSkillStars ?? 1), 1, 5));
    const pattern = String(threat.attackPattern ?? threat.behaviorNotes ?? threat.commanderPlaystyle ?? 'Adaptive assault profile.');
    row.innerHTML = `
      <div class="invasion-alien-main">
        <div class="invasion-alien-title">
          <strong>${threat.factionName}</strong>
          <span class="threat-tier tier-${dangerTier}">${dangerTier.toUpperCase()}</span>
          <span class="threat-urgency">Urgency ${urgency}</span>
        </div>
        <div class="invasion-alien-meta">${threat.deckSizeEstimate} cards • ${commanderStars} • Tech ${Math.max(1, Number(threat.techLevel ?? 1))} • ${threat.commanderRank ?? 'standard'} command</div>
        <small>${commander} • ${currentNode?.name ?? 'Unknown'} → ${targetNode?.name ?? currentNode?.name ?? 'Unknown'}${targetPlanet ? ` • Planet ${targetPlanet.name}` : ''}</small>
        <small>${deckSeries} • Doctrine ${doctrineLabel} • ${variant} • Triangles ${triangleCount}</small>
        <small>${pattern}</small>
        <div class="threat-chip-row">${chipHtml}</div>
      </div>
    `;
    const actions = document.createElement('div');
    actions.className = 'invasion-alien-actions';
    const focusBtn = document.createElement('button');
    focusBtn.type = 'button';
    focusBtn.textContent = 'Focus';
    focusBtn.onclick = () => {
      const focusNodeId = (currentNode ?? targetNode)?.id;
      if (focusNodeId) centerMapOnNode(focusNodeId);
    };
    const inspectBtn = document.createElement('button');
    inspectBtn.type = 'button';
    inspectBtn.textContent = 'Inspect';
    inspectBtn.onclick = () => openThreatInspectModal(threat, fallbackNode, baseProfiles);
    const engageBtn = document.createElement('button');
    engageBtn.type = 'button';
    engageBtn.textContent = 'Engage';
    engageBtn.onclick = () => launchAlienThreatBattle(threat, fallbackNode);
    actions.appendChild(focusBtn);
    actions.appendChild(inspectBtn);
    actions.appendChild(engageBtn);
    row.appendChild(actions);
    dom.invasionAlienList.appendChild(row);
  });
}

function renderInvasionPanel(attackers, baseProfiles, profileNow = null, mapWorldNow = null, campaignNow = null) {
  if (!dom.invasionPanel) return;
  if (dom.invasionThreatFilter && dom.invasionThreatFilter.value !== mapView.threatFilter) {
    dom.invasionThreatFilter.value = mapView.threatFilter || 'all';
  }
  const threshold = Math.max(1, toFiniteNumber(attackers.invasionThreshold, 100));
  const progressRatio = clamp((attackers.invasionProgress / threshold) * 100, 0, 100);
  const traceRatio = clamp(attackers.trace, 0, 100);
  const infamyRatio = clamp(attackers.pirateInfamy, 0, 100);
  dom.invasionStateLabel.textContent = attackers.playerExposed ? 'Exposed' : 'Hidden';
  dom.invasionStateLabel.classList.toggle('is-exposed', !!attackers.playerExposed);
  dom.warpKeyStatus.textContent = attackers.warpKey.compromised
    ? 'Warp Key: Compromised'
    : `Warp Key: Concealed (${Math.round(attackers.warpKey.concealment)})`;
  dom.warpKeyStatus.classList.toggle('danger', !!attackers.warpKey.compromised);

  dom.invasionProgressFill.style.width = `${progressRatio.toFixed(1)}%`;
  dom.traceProgressFill.style.width = `${traceRatio.toFixed(1)}%`;
  dom.infamyProgressFill.style.width = `${infamyRatio.toFixed(1)}%`;
  dom.invasionProgressText.textContent = `${Math.round(attackers.invasionProgress)}/${threshold} • Concealment Under Threat`;
  dom.traceProgressText.textContent = `${Math.round(attackers.trace)} • ${attackers.traceState}`;
  dom.infamyProgressText.textContent = `${Math.round(attackers.pirateInfamy)} • ${attackers.pirateInfamyLabel}`;

  const fleeing = (attackers.activePirates ?? []).filter((pirate) => pirate.objective === 'flee');
  const hunters = (attackers.activePirates ?? []).filter((pirate) => pirate.objective === 'investigate').length;
  const resolvedProfile = profileNow ?? loadProfile();
  const resolvedMapWorld = mapWorldNow ?? getMapWorldFast(resolvedProfile);
  const campaign = campaignNow ?? resolvedMapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const activeAliens = (campaign.activeThreats ?? []).filter((entry) => entry?.threatType === 'alien' && !entry.resolved);
  const filterMode = String(mapView.threatFilter ?? 'all').toLowerCase();
  const filteredAliens = activeAliens.filter((threat) => invasionThreatMatchesFilter(threat, filterMode));
  const urgentThreat = [...activeAliens].sort((a, b) => invasionThreatUrgencyScore(b) - invasionThreatUrgencyScore(a))[0] ?? null;
  const scanActive = !!attackers.scanChallenge?.active;
  const scanPirate = scanActive ? (attackers.activePirates ?? []).find((entry) => entry.id === attackers.scanChallenge?.pirateId) : null;
  dom.invasionThreatSummary.textContent = scanActive
    ? `Counter-scan active against ${scanPirate?.name ?? 'unknown pirate'}. Redirect channels before lock completes.`
    : (fleeing.length
    ? `${fleeing.length} pirate${fleeing.length > 1 ? 's are' : ' is'} escaping toward the Virolean Sea. Intercept now.`
    : activeAliens.length
      ? `${activeAliens.length} alien invasion fleet${activeAliens.length > 1 ? 's are' : ' is'} active (${filteredAliens.length} shown). Top threat: ${urgentThreat?.factionName ?? 'Unknown'} ${invasionThreatDangerTier(urgentThreat).toUpperCase()} at urgency ${Math.round(invasionThreatUrgencyScore(urgentThreat))}.`
      : `${(attackers.activePirates ?? []).length} active pirate roamers. Hunters: ${hunters}.`);

  dom.invasionBossWarning.classList.toggle('hidden', !attackers.playerExposed && !attackers.bossState.pending);
  if (!dom.invasionBossWarning.classList.contains('hidden')) {
    dom.invasionBossWarning.textContent = attackers.bossState.activePirateId
      ? 'Boss incursion active: Sea Marshal class attacker deployed.'
      : 'Boss incursion imminent: exposure reached critical threshold.';
  }

  const activeFlee = fleeing[0] ?? null;
  dom.invasionInterceptBtn.disabled = !activeFlee;
  dom.invasionInterceptBtn.textContent = activeFlee
    ? `Intercept ${activeFlee.name} (${Math.max(0, activeFlee.escapeCountdown)} ticks)`
    : 'No Active Escape to Intercept';
  dom.invasionInterceptBtn.onclick = () => {
    if (!activeFlee) return;
    beginPirateIntercept(baseProfiles, activeFlee.id);
  };
  dom.invasionScanBtn.onclick = () => renderBattleMap(baseProfiles, loadProfile());
  if (dom.invasionWorldOpsBtn) {
    const world = preferredWorldOpsWorld(resolvedProfile, attackers);
    const canOpenWorldOps = !!world && !world.lost;
    dom.invasionWorldOpsBtn.disabled = !canOpenWorldOps;
    dom.invasionWorldOpsBtn.textContent = canOpenWorldOps
      ? `World Ops • ${world.worldName}`
      : 'World Ops';
    dom.invasionWorldOpsBtn.onclick = () => {
      if (!canOpenWorldOps) return;
      modalUiState.worldOps.worldId = world.worldId;
      modalUiState.worldOps.planetId = chooseInvasionPlanetForWorld(world)?.id ?? null;
      openWorldOpsModal(loadProfile());
    };
  }
  renderActiveAlienFleetList(resolvedProfile, baseProfiles, resolvedMapWorld, campaign);
  renderScanChallengePanel(attackers);

  const events = [...(attackers.eventLog ?? [])].slice(-12).reverse();
  const eventSig = events.map((entry) => {
    const ageBucket = Math.max(0, Math.floor((Date.now() - toFiniteNumber(entry.ts, Date.now())) / 5000));
    return `${entry.ts}|${entry.severity ?? 'info'}|${entry.text}|${ageBucket}`;
  }).join('~');
  if (mapView.invasionFeedSig !== eventSig) {
    mapView.invasionFeedSig = eventSig;
    dom.invasionEventFeed.innerHTML = '';
    if (!events.length) {
      dom.invasionEventFeed.innerHTML = '<div class="invasion-feed-empty">No pirate sightings yet.</div>';
    } else {
      events.forEach((entry) => {
        const row = document.createElement('div');
        row.className = `invasion-feed-row sev-${entry.severity ?? 'info'}`;
        const ageSec = Math.max(0, Math.floor((Date.now() - toFiniteNumber(entry.ts, Date.now())) / 1000));
        row.innerHTML = `<span>${entry.text}</span><small>${ageSec}s ago</small>`;
        dom.invasionEventFeed.appendChild(row);
      });
    }
  }

  const dossier = [...(attackers.pirateDossier ?? [])].slice(-8).reverse();
  const dossierSig = dossier.map((entry) => `${entry.name}|${entry.house}|${entry.level}|${entry.role}|${entry.outcome}`).join('~');
  if (mapView.invasionDossierSig !== dossierSig) {
    mapView.invasionDossierSig = dossierSig;
    dom.pirateDossierList.innerHTML = '';
    if (!dossier.length) {
      dom.pirateDossierList.innerHTML = '<div class="invasion-feed-empty">Dossier is empty.</div>';
    } else {
      dossier.forEach((entry) => {
        const row = document.createElement('div');
        row.className = `dossier-row outcome-${entry.outcome ?? 'unknown'}`;
        row.textContent = `${entry.name} • ${entry.house ?? 'Unknown House'} • Lvl ${entry.level} • ${entry.role} • ${entry.outcome}`;
        dom.pirateDossierList.appendChild(row);
      });
    }
  }
}

function mapNodeById(nodeId) {
  return mapView.nodes.find((node) => node.id === nodeId) ?? null;
}

function sanitizeMapCameraState() {
  mapView.zoom = Number.isFinite(mapView.zoom) && mapView.zoom > 0 ? mapView.zoom : 1;
  mapView.panX = Number.isFinite(mapView.panX) ? mapView.panX : 0;
  mapView.panY = Number.isFinite(mapView.panY) ? mapView.panY : 0;
}

function recenterMapCameraOnNode(node, viewportWidth = mapView.viewportWidth, viewportHeight = mapView.viewportHeight) {
  if (!node) return;
  sanitizeMapCameraState();
  mapView.panX = (viewportWidth * 0.5) - (node.x * mapView.zoom);
  mapView.panY = (viewportHeight * 0.5) - (node.y * mapView.zoom);
}

function isMapNodeVisibleInViewport(node, viewportWidth = mapView.viewportWidth, viewportHeight = mapView.viewportHeight) {
  if (!node) return false;
  const px = (node.x * mapView.zoom) + mapView.panX;
  const py = (node.y * mapView.zoom) + mapView.panY;
  const radius = Math.max(16, toFiniteNumber(node.radius, 12));
  return px >= -radius && px <= (viewportWidth + radius) && py >= -radius && py <= (viewportHeight + radius);
}

function ensureMapCameraHasVisibleNode(nodes, preferredNodeId = null, viewportWidth = mapView.viewportWidth, viewportHeight = mapView.viewportHeight, force = false) {
  if (!Array.isArray(nodes) || !nodes.length) return;
  sanitizeMapCameraState();
  const anyVisible = nodes.some((node) => isMapNodeVisibleInViewport(node, viewportWidth, viewportHeight));
  if (anyVisible) {
    mapView.offscreenGuardCount = 0;
    return;
  }
  if (force) {
    const forcedNode = nodes.find((node) => node.id === preferredNodeId) ?? nodes[0] ?? null;
    recenterMapCameraOnNode(forcedNode, viewportWidth, viewportHeight);
    mapView.offscreenGuardCount = 0;
    return;
  }
  if (mapView.dragging || mapView.leftPointerHeld) return;
  mapView.offscreenGuardCount = toFiniteNumber(mapView.offscreenGuardCount, 0) + 1;
  if (mapView.offscreenGuardCount < 2) return;
  const focusNode = nodes.find((node) => node.id === preferredNodeId) ?? nodes[0] ?? null;
  recenterMapCameraOnNode(focusNode, viewportWidth, viewportHeight);
  mapView.offscreenGuardCount = 0;
}

function applyMapTransform() {
  if (!dom.mapPanzoomRoot) return;
  sanitizeMapCameraState();
  dom.mapPanzoomRoot.setAttribute('transform', `translate(${mapView.panX} ${mapView.panY}) scale(${mapView.zoom})`);
}

function centerMapOnNode(nodeId) {
  const node = mapNodeById(nodeId);
  if (!node) return;
  mapView.selectedNodeId = node.id;
  mapView.focusedNodeId = node.id;
  sanitizeMapCameraState();
  const viewBox = dom.mapSvg?.viewBox?.baseVal;
  const w = viewBox?.width || 900;
  const h = viewBox?.height || 360;
  const targetPanX = (w * 0.5) - (node.x * mapView.zoom);
  const targetPanY = (h * 0.5) - (node.y * mapView.zoom);
  const startX = mapView.panX;
  const startY = mapView.panY;
  const start = performance.now();
  const duration = 320;
  const tick = (now) => {
    const t = Math.min(1, (now - start) / duration);
    const eased = 1 - ((1 - t) ** 3);
    mapView.panX = startX + ((targetPanX - startX) * eased);
    mapView.panY = startY + ((targetPanY - startY) * eased);
    applyMapTransform();
    if (t < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
  updateMapNodeInteractionVisuals();
}

function resetMapView() {
  mapView.zoom = 1;
  const focusNode = mapNodeById(mapView.selectedNodeId) ?? mapView.nodes[0] ?? null;
  if (focusNode) recenterMapCameraOnNode(focusNode);
  else {
    mapView.panX = 0;
    mapView.panY = 0;
  }
  mapView.offscreenGuardCount = 0;
  applyMapTransform();
  updateMapNodeInteractionVisuals();
}

function resizeMapEffectsCanvas() {
  if (!dom.mapEffectsCanvas || !dom.mapStage) return;
  const rect = dom.mapStage.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  dom.mapEffectsCanvas.width = Math.round(rect.width * ratio);
  dom.mapEffectsCanvas.height = Math.round(rect.height * ratio);
  const ctx = dom.mapEffectsCanvas.getContext('2d');
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
}

function stopMapEffects() {
  if (mapEffectsHandle) {
    cancelAnimationFrame(mapEffectsHandle);
    mapEffectsHandle = null;
  }
  mapEffectsState = null;
}

function stopFacilityWarEffects() {
  if (facilityWarEffectsHandle) {
    cancelAnimationFrame(facilityWarEffectsHandle);
    facilityWarEffectsHandle = null;
  }
  if (dom.facilityWarEffectsCanvas) {
    dom.facilityWarEffectsCanvas.getContext('2d')?.clearRect(0, 0, dom.facilityWarEffectsCanvas.width, dom.facilityWarEffectsCanvas.height);
  }
  if (dom.facilityWarGrid?.parentElement) {
    dom.facilityWarGrid.parentElement.style.transform = '';
  }
  facilityWarEffectsState = null;
}

function queueFacilityWarEffect(event = {}) {
  if (!event || typeof event !== 'object') return;
  if (!facilityWarEffectsState || !dom.facilityWarModal || dom.facilityWarModal.classList.contains('hidden')) return;
  const now = (typeof performance !== 'undefined' && typeof performance.now === 'function')
    ? performance.now()
    : Date.now();
  const payload = {
    kind: String(event.kind ?? 'pulse'),
    side: String(event.side ?? 'neutral'),
    ts: now,
    life: Math.max(140, Number(event.life ?? 560)),
    ...event,
  };
  const list = Array.isArray(facilityWarEffectsState.events) ? facilityWarEffectsState.events : [];
  list.push(payload);
  const overflow = Math.max(0, list.length - 120);
  if (overflow > 0) list.splice(0, overflow);
  facilityWarEffectsState.events = list;
  const shakePower = Math.max(0, Number(payload.shakePower ?? 0));
  if (shakePower > 0) {
    facilityWarEffectsState.shakePower = Math.max(Number(facilityWarEffectsState.shakePower ?? 0), shakePower);
    const shakeUntil = now + Math.max(120, Number(payload.shakeDuration ?? 220));
    facilityWarEffectsState.shakeUntil = Math.max(Number(facilityWarEffectsState.shakeUntil ?? 0), shakeUntil);
  }
}

function conquestVfxTagArray(entry = {}, extraTags = []) {
  const tags = new Set(toArray(entry?.tags).map((tag) => String(tag).toLowerCase()));
  if (entry?.flying) tags.add('flying');
  if (entry?.horde) tags.add('horde');
  if (entry?.large) tags.add('large');
  if (entry?.siege && Number(entry.siege) > 0) tags.add('siege');
  if (entry?.range && Number(entry.range) > 1) tags.add('ranged');
  if (entry?.type === 'building') tags.add('structure');
  if (String(entry?.type ?? '').toLowerCase() === 'pylon') tags.add('pylon');
  toArray(extraTags).forEach((tag) => tags.add(String(tag).toLowerCase()));
  return Array.from(tags);
}

function resolveConquestAttackVfxProfile(sourceOcc = null, targetOcc = null, flags = {}) {
  const sourceName = String(sourceOcc?.name ?? flags.cardName ?? '').toLowerCase();
  const targetName = String(targetOcc?.name ?? '').toLowerCase();
  const sourceTags = new Set(conquestVfxTagArray(sourceOcc, [...toArray(flags.extraSourceTags), ...toArray(flags.sourceTags)]));
  const targetTags = new Set(conquestVfxTagArray(targetOcc, [...toArray(flags.extraTargetTags), ...toArray(flags.targetTags)]));
  const explosive = !!flags.explosive || sourceTags.has('explosive') || sourceTags.has('ordnance') || sourceName.includes('mortar');
  const antiAir = !!flags.antiAir || sourceTags.has('anti-air') || sourceTags.has('anti_flying') || sourceTags.has('anti-flying') || sourceName.includes('anti-air') || sourceName.includes('flak');
  const barrage = !!flags.barrage || sourceTags.has('barrage') || sourceName.includes('barrage');
  const turret = sourceTags.has('turret') || sourceName.includes('turret') || sourceName.includes('ballista');
  const marksman = sourceTags.has('marksman') || sourceName.includes('marksman') || sourceName.includes('sniper');
  const bowman = sourceTags.has('bow') || sourceTags.has('archer') || sourceName.includes('archer') || sourceName.includes('bow');
  const siege = sourceTags.has('siege');
  const ranged = sourceTags.has('ranged') || bowman || marksman || turret || antiAir;
  const flying = sourceTags.has('flying');
  const heavy = siege || sourceTags.has('large') || sourceName.includes('giant') || sourceName.includes('colossus');
  const targetIsStructure = targetTags.has('structure') || targetTags.has('barricade') || targetTags.has('turret') || targetName.includes('wall');
  let attackClass = 'melee';
  let projectileKind = 'lunge';
  let impactKind = 'slash-impact';
  if (turret) {
    attackClass = 'turret';
    projectileKind = explosive ? 'turret-shell' : 'turret-bolt';
    impactKind = explosive ? 'blast-impact' : 'spark-impact';
  } else if (barrage && antiAir) {
    attackClass = 'anti-barrage';
    projectileKind = 'flak-barrage';
    impactKind = 'flak-burst';
  } else if (antiAir) {
    attackClass = 'anti-air';
    projectileKind = 'flak-shot';
    impactKind = 'air-burst';
  } else if (explosive) {
    attackClass = 'explosive';
    projectileKind = 'mortar-shell';
    impactKind = 'blast-impact';
  } else if (marksman) {
    attackClass = 'marksman';
    projectileKind = 'marksman-shot';
    impactKind = 'precision-impact';
  } else if (bowman) {
    attackClass = 'bow';
    projectileKind = 'arrow';
    impactKind = 'pierce-impact';
  } else if (ranged) {
    attackClass = 'ranged';
    projectileKind = 'bolt';
    impactKind = 'spark-impact';
  } else if (flying) {
    attackClass = 'flying';
    projectileKind = 'dive';
    impactKind = 'shock-impact';
  } else if (siege) {
    attackClass = 'siege';
    projectileKind = 'siege-strike';
    impactKind = targetIsStructure ? 'debris-impact' : 'shock-impact';
  } else if (heavy) {
    attackClass = 'heavy-melee';
    projectileKind = 'heavy-lunge';
    impactKind = 'shock-impact';
  }
  return {
    attackClass,
    projectileKind,
    impactKind,
    sourceTags: Array.from(sourceTags),
    targetTags: Array.from(targetTags),
    explosive,
    antiAir,
    barrage,
    turret,
    heavy,
    ranged,
    shakePower: explosive ? 7.5 : (heavy ? 3.3 : 0),
    shakeDuration: explosive ? 260 : (heavy ? 180 : 0),
  };
}

function queueConquestActionEvent(kind = 'ability-trigger', payload = {}) {
  queueFacilityWarEffect({
    kind: String(kind || 'ability-trigger').toLowerCase(),
    ...payload,
  });
}

function normalizeInvasionCardType(type = 'minion') {
  const t = String(type ?? 'minion').toLowerCase();
  if (t === 'creature' || t === 'token') return 'minion';
  if (t === 'artifact') return 'relic';
  if (t === 'fortress' || t === 'turret' || t === 'reactor') return 'structure';
  return t;
}

const CONQUEST_INVA_TRIANGLE_TO_SIZE = Object.freeze({
  1: 10,
  2: 20,
  3: 30,
  4: 40,
  5: 50,
  6: 60,
});

const CONQUEST_INVA_FACTION_DOCTRINES = Object.freeze({
  'chitin-ascendancy': {
    label: 'Brood Flood',
    advancedLabel: 'Apex Brood Siege',
    weights: { pylon: 0.16, ground: 0.19, ranged: 0.06, air: 0.09, horde: 0.24, giant: 0.06, siege: 0.1, tactic: 0.06, support: 0.04 },
    preferTags: ['horde', 'swarm', 'ground', 'capture', 'breach', 'summon'],
    avoidTags: ['officer', 'morale'],
    threatStyle: 'swarm-heavy',
  },
  'glass-null-collective': {
    label: 'Fractal Precision',
    advancedLabel: 'Null Lattice Control',
    weights: { pylon: 0.18, ground: 0.11, ranged: 0.21, air: 0.1, horde: 0.05, giant: 0.07, siege: 0.08, tactic: 0.12, support: 0.08 },
    preferTags: ['ranged', 'support', 'sabotage', 'anti-large', 'anti-flying', 'capture'],
    avoidTags: ['horde'],
    threatStyle: 'precision-control',
  },
  'verdant-consumers': {
    label: 'Infestation Grind',
    advancedLabel: 'Bloom Suffocation',
    weights: { pylon: 0.15, ground: 0.17, ranged: 0.08, air: 0.08, horde: 0.18, giant: 0.08, siege: 0.08, tactic: 0.09, support: 0.09 },
    preferTags: ['horde', 'support', 'weather', 'capture', 'resource', 'repair'],
    avoidTags: ['anti-large'],
    threatStyle: 'attrition-growth',
  },
  'halo-censors': {
    label: 'Luminous Spearhead',
    advancedLabel: 'Doctrine Purge Wing',
    weights: { pylon: 0.16, ground: 0.12, ranged: 0.18, air: 0.16, horde: 0.04, giant: 0.08, siege: 0.08, tactic: 0.1, support: 0.08 },
    preferTags: ['officer', 'morale', 'air', 'ranged', 'support', 'anti-horde'],
    avoidTags: ['horde'],
    threatStyle: 'elite-pressure',
  },
  'iron-carrion-mandate': {
    label: 'Siege Attrition Column',
    advancedLabel: 'Carrion Linebreaker Armory',
    weights: { pylon: 0.17, ground: 0.13, ranged: 0.11, air: 0.06, horde: 0.07, giant: 0.11, siege: 0.18, tactic: 0.09, support: 0.08 },
    preferTags: ['siege', 'anti-structure', 'breach', 'giant', 'resource', 'sabotage'],
    avoidTags: ['fragile'],
    threatStyle: 'siege-heavy',
  },
  'warlord-convoys': {
    label: 'Convoy Breakline',
    advancedLabel: 'Warlord Armored Spear',
    weights: { pylon: 0.18, ground: 0.12, ranged: 0.1, air: 0.03, horde: 0.04, giant: 0.11, siege: 0.24, tactic: 0.1, support: 0.08 },
    preferTags: ['vehicle', 'siege', 'anti-structure', 'breach', 'armored'],
    avoidTags: ['fragile', 'horde'],
    threatStyle: 'siege-heavy',
  },
  'beast-stampedes': {
    label: 'Stampede Pressure',
    advancedLabel: 'Apex Stampede Breakthrough',
    weights: { pylon: 0.12, ground: 0.2, ranged: 0.05, air: 0.08, horde: 0.28, giant: 0.1, siege: 0.08, tactic: 0.05, support: 0.04 },
    preferTags: ['horde', 'swarm', 'giant', 'ground', 'capture'],
    avoidTags: ['officer', 'resource'],
    threatStyle: 'swarm-heavy',
  },
  'cult-uprisings': {
    label: 'Fanatic Surge',
    advancedLabel: 'Ritual Collapse Doctrine',
    weights: { pylon: 0.14, ground: 0.19, ranged: 0.09, air: 0.05, horde: 0.19, giant: 0.05, siege: 0.08, tactic: 0.14, support: 0.07 },
    preferTags: ['horde', 'morale', 'support', 'tactic', 'capture'],
    avoidTags: ['heavy', 'expensive'],
    threatStyle: 'control-pressure',
  },
  'rogue-mechanized-cells': {
    label: 'Machine Lattice',
    advancedLabel: 'Autonomous Siege Grid',
    weights: { pylon: 0.18, ground: 0.12, ranged: 0.16, air: 0.06, horde: 0.04, giant: 0.1, siege: 0.16, tactic: 0.09, support: 0.09 },
    preferTags: ['vehicle', 'turret', 'ranged', 'siege', 'anti-structure'],
    avoidTags: ['horde'],
    threatStyle: 'precision-siege',
  },
  'necro-bloom-infestations': {
    label: 'Bloom Attrition',
    advancedLabel: 'Necro-Canopy Suffocation',
    weights: { pylon: 0.14, ground: 0.16, ranged: 0.08, air: 0.05, horde: 0.2, giant: 0.08, siege: 0.08, tactic: 0.1, support: 0.11 },
    preferTags: ['growth', 'horde', 'support', 'repair', 'weather', 'attrition'],
    avoidTags: ['fragile'],
    threatStyle: 'attrition-growth',
  },
  'sky-raider-wings': {
    label: 'Harrier Wing',
    advancedLabel: 'Sky Raider Bomb Net',
    weights: { pylon: 0.16, ground: 0.09, ranged: 0.16, air: 0.24, horde: 0.06, giant: 0.06, siege: 0.08, tactic: 0.09, support: 0.06 },
    preferTags: ['air', 'flying', 'anti-ground', 'capture', 'ranged'],
    avoidTags: ['barricade'],
    threatStyle: 'air-assault',
  },
  'fortress-columns': {
    label: 'Bulwark March',
    advancedLabel: 'Citadel Breaker Column',
    weights: { pylon: 0.15, ground: 0.15, ranged: 0.11, air: 0.04, horde: 0.04, giant: 0.13, siege: 0.16, tactic: 0.1, support: 0.12 },
    preferTags: ['elite', 'fortified', 'siege', 'command', 'support'],
    avoidTags: ['fragile', 'swarm'],
    threatStyle: 'elite-pressure',
  },
});

const CONQUEST_INVA_FACTION_ALIASES = Object.freeze({
  'the-chitin-ascendancy': 'chitin-ascendancy',
  'the-glass-null-collective': 'glass-null-collective',
  'the-verdant-consumers': 'verdant-consumers',
  'the-halo-censors': 'halo-censors',
  'the-iron-carrion-mandate': 'iron-carrion-mandate',
  'warlord-convoy': 'warlord-convoys',
  'warlord-convoys': 'warlord-convoys',
  'beast-stampede': 'beast-stampedes',
  'beast-stampedes': 'beast-stampedes',
  'cult-uprising': 'cult-uprisings',
  'cult-uprisings': 'cult-uprisings',
  'rogue-mechanized-cell': 'rogue-mechanized-cells',
  'rogue-mechanized-cells': 'rogue-mechanized-cells',
  'necro-bloom-infestation': 'necro-bloom-infestations',
  'necro-bloom-infestations': 'necro-bloom-infestations',
  'sky-raider-wing': 'sky-raider-wings',
  'sky-raider-wings': 'sky-raider-wings',
  'fortress-column': 'fortress-columns',
  'fortress-columns': 'fortress-columns',
  pirates: 'iron-carrion-mandate',
  pirate: 'iron-carrion-mandate',
});

const CONQUEST_INVA_FACTION_DECK_SERIES = Object.freeze({
  'chitin-ascendancy': Object.freeze([
    'Needle Brood Raid',
    'Larval Spearhead',
    'Synapse Patrol',
    'Nest-Breach Armada',
    'Apex Brood Cohort',
    'Endless Hatch Overrun',
  ]),
  'glass-null-collective': Object.freeze([
    'Facet Knife Strike',
    'Prismline Detachment',
    'Fractal Control Wing',
    'Null Lattice Spearhead',
    'Mirror Logic Cohort',
    'Executor Lattice Army',
  ]),
  'verdant-consumers': Object.freeze([
    'Spore Needle Bloom',
    'Root-Surge Talon',
    'Infestation Growth Front',
    'Creeping Bloom Column',
    'Worldroot Siege Garden',
    'Grand Canopy Assimilation',
  ]),
  'halo-censors': Object.freeze([
    'Edict Strike Choir',
    'Radiant Lancer Wing',
    'Doctrine Purge Patrol',
    'Halo Spear Formation',
    'Sanction Archon Column',
    'Final Doctrine Crusade',
  ]),
  'iron-carrion-mandate': Object.freeze([
    'Scrapline Breach Cell',
    'Rust Column Assault',
    'Carrion Siege Patrol',
    'Forgebreaker Spearhead',
    'Mandate Iron Cohort',
    'Dread Furnace Armada',
  ]),
  'warlord-convoys': Object.freeze([
    'Convoy Probe Unit',
    'Roadbreaker Lance',
    'Armored Freight Spear',
    'Warlord Breach Column',
    'Siege Convoy Cohort',
    'Grand Convoy Invasion',
  ]),
  'beast-stampedes': Object.freeze([
    'Wildpack Probe',
    'Razorhide Rush',
    'Stampede Vanguard',
    'Apex Herd Assault',
    'Territory Break Pack',
    'Worldstampede Cataclysm',
  ]),
  'cult-uprisings': Object.freeze([
    'Knife Cell Incursion',
    'Ritual Street Surge',
    'Fanatic Frontline',
    'Ascendant Cult Wave',
    'Censor-Break Procession',
    'Eclipse Rite Host',
  ]),
  'rogue-mechanized-cells': Object.freeze([
    'Rogue Drone Node',
    'Walker Probe Team',
    'Mechanized Breach Cell',
    'Autonomous Gunline',
    'Blacksite Machine Cohort',
    'Prime Logic War Mesh',
  ]),
  'necro-bloom-infestations': Object.freeze([
    'Spore Drift Outbreak',
    'Rotvine Pressure Front',
    'Bloom Infestation Wave',
    'Necro-Canopy Push',
    'Plague Garden Cohort',
    'Worldroot Rot Siege',
  ]),
  'sky-raider-wings': Object.freeze([
    'Harrier Recon Wing',
    'Dive Lash Flight',
    'Raider Air Spear',
    'Bomb Net Detachment',
    'Storm Wing Cohort',
    'Skybreaker Armada',
  ]),
  'fortress-columns': Object.freeze([
    'Bulwark Probe Line',
    'Aegis Spear Team',
    'Fortress March Patrol',
    'Citadel Breach Column',
    'Imperator Shield Cohort',
    'Bastion Hammer Legion',
  ]),
});

function normalizeConquestInvasionFactionId(raw = '') {
  const slug = slugifyId(String(raw ?? '').trim());
  if (!slug) return 'iron-carrion-mandate';
  return CONQUEST_INVA_FACTION_ALIASES[slug] ?? slug;
}

const CONQUEST_FACTION_FX_SIGNATURES = Object.freeze({
  'chitin-ascendancy': Object.freeze({
    trail: '108, 232, 145',
    pulse: '151, 255, 190',
    ember: '86, 212, 128',
    style: 'swarm',
    speed: 1.2,
    density: 1.35,
  }),
  'glass-null-collective': Object.freeze({
    trail: '148, 226, 255',
    pulse: '205, 243, 255',
    ember: '129, 192, 255',
    style: 'shard',
    speed: 1.15,
    density: 1.1,
  }),
  'verdant-consumers': Object.freeze({
    trail: '132, 224, 152',
    pulse: '198, 255, 205',
    ember: '102, 190, 125',
    style: 'spore',
    speed: 1,
    density: 1.25,
  }),
  'halo-censors': Object.freeze({
    trail: '255, 218, 142',
    pulse: '255, 242, 197',
    ember: '236, 196, 111',
    style: 'halo',
    speed: 1.08,
    density: 1,
  }),
  'iron-carrion-mandate': Object.freeze({
    trail: '255, 146, 116',
    pulse: '255, 196, 167',
    ember: '224, 112, 89',
    style: 'siege',
    speed: 0.95,
    density: 1.2,
  }),
  'warlord-convoys': Object.freeze({
    trail: '255, 155, 104',
    pulse: '255, 206, 170',
    ember: '220, 126, 88',
    style: 'siege',
    speed: 0.92,
    density: 1.28,
  }),
  'beast-stampedes': Object.freeze({
    trail: '168, 236, 121',
    pulse: '218, 255, 175',
    ember: '122, 206, 88',
    style: 'swarm',
    speed: 1.26,
    density: 1.42,
  }),
  'cult-uprisings': Object.freeze({
    trail: '216, 142, 255',
    pulse: '243, 198, 255',
    ember: '176, 108, 226',
    style: 'ritual',
    speed: 1.08,
    density: 1.24,
  }),
  'rogue-mechanized-cells': Object.freeze({
    trail: '149, 223, 255',
    pulse: '207, 241, 255',
    ember: '118, 178, 226',
    style: 'shard',
    speed: 1.02,
    density: 1.08,
  }),
  'necro-bloom-infestations': Object.freeze({
    trail: '124, 228, 164',
    pulse: '202, 255, 228',
    ember: '88, 186, 132',
    style: 'spore',
    speed: 1.03,
    density: 1.33,
  }),
  'sky-raider-wings': Object.freeze({
    trail: '149, 199, 255',
    pulse: '206, 232, 255',
    ember: '118, 158, 226',
    style: 'air',
    speed: 1.34,
    density: 1.12,
  }),
  'fortress-columns': Object.freeze({
    trail: '255, 214, 149',
    pulse: '255, 236, 191',
    ember: '222, 182, 116',
    style: 'halo',
    speed: 0.88,
    density: 1.04,
  }),
});

function conquestFactionFxProfile(factionId = '') {
  const key = normalizeConquestInvasionFactionId(factionId);
  return CONQUEST_FACTION_FX_SIGNATURES[key] ?? Object.freeze({
    trail: '160, 206, 255',
    pulse: '214, 234, 255',
    ember: '130, 178, 235',
    style: 'default',
    speed: 1,
    density: 1,
  });
}

function conquestDeckVariantForStars(stars = 2) {
  return clamp(Math.round(toFiniteNumber(stars, 2)), 1, 5) >= 4 ? 'advanced' : 'basic';
}

function conquestDeckSeriesName(factionId = '', triangles = 3, variant = 'basic') {
  const resolved = normalizeConquestInvasionFactionId(factionId);
  const tri = clamp(Math.round(toFiniteNumber(triangles, 3)), 1, 6);
  const series = CONQUEST_INVA_FACTION_DECK_SERIES[resolved] ?? [];
  const baseName = series[tri - 1] ?? `Triangle ${tri} Assault`;
  return variant === 'advanced' ? `${baseName} [Advanced]` : baseName;
}

function conquestDoctrineLabelForThreat(factionId = '', stars = 2) {
  const doctrine = CONQUEST_INVA_FACTION_DOCTRINES[normalizeConquestInvasionFactionId(factionId)] ?? null;
  if (!doctrine) return 'mixed-doctrine';
  return Number(stars ?? 1) >= 4 ? doctrine.advancedLabel : doctrine.label;
}

function conquestDeckSizeFromTriangles(triangles = 3) {
  const tri = clamp(Math.round(toFiniteNumber(triangles, 3)), 1, 6);
  return CONQUEST_INVA_TRIANGLE_TO_SIZE[tri] ?? 30;
}

function conquestTrianglesFromDeckSize(deckSize = 30) {
  const size = clamp(Math.round(toFiniteNumber(deckSize, 30)), 10, 60);
  return clamp(Math.round(size / 10), 1, 6);
}

function conquestMinimumPylonsForSize(size = 30) {
  const normalized = clamp(Math.round(toFiniteNumber(size, 30)), 10, 60);
  if (normalized >= 60) return 9;
  if (normalized >= 50) return 8;
  if (normalized >= 40) return 6;
  if (normalized >= 30) return 5;
  if (normalized >= 20) return 3;
  return 2;
}

function conquestAttackerPoolByCategory(profile = null) {
  const cards = conquestCardLibrary(profile ?? loadProfile())
    .filter((card) => String(card.sourceBuilding ?? card.productionSource ?? '').toLowerCase() === 'attacker');
  const categories = {
    all: cards,
    homestead: [],
    pylon: [],
    pylonCore: [],
    ground: [],
    ranged: [],
    air: [],
    horde: [],
    giant: [],
    siege: [],
    tactic: [],
    support: [],
  };
  cards.forEach((card) => {
    const tags = new Set(toArray(card.tags).map((tag) => String(tag).toLowerCase()));
    const type = String(card.type ?? '').toLowerCase();
    const isTactic = type === 'spell' || type === 'tactic';
    const isPylon = type === 'pylon' || tags.has('pylon');
    const isCorePylon = (type === 'pylon' || String(card.subtype ?? '').toLowerCase().includes('mana pylon'))
      && !isTactic;
    const isHomestead = tags.has('homestead') || String(card.subtype ?? '').toLowerCase().includes('homestead');
    const isAir = !!card.flying || tags.has('air');
    const isHorde = !!card.horde || tags.has('horde');
    const isLarge = !!card.large || tags.has('large') || tags.has('giant');
    const isRanged = Number(card.range ?? 1) > 1 || tags.has('ranged');
    const isSiege = Number(card.siege ?? 0) > 0 || tags.has('siege') || tags.has('anti-structure') || tags.has('breach');
    if (isHomestead) categories.homestead.push(card);
    if (isPylon) categories.pylon.push(card);
    if (isCorePylon) categories.pylonCore.push(card);
    if (isTactic) categories.tactic.push(card);
    if (isAir) categories.air.push(card);
    if (isHorde) categories.horde.push(card);
    if (isLarge) categories.giant.push(card);
    if (isRanged) categories.ranged.push(card);
    if (isSiege) categories.siege.push(card);
    if (!isTactic && !isAir && !isLarge && !isHorde) categories.ground.push(card);
    if (tags.has('support') || tags.has('officer') || tags.has('morale') || tags.has('resource') || tags.has('capture') || tags.has('sabotage')) {
      categories.support.push(card);
    }
  });
  return categories;
}

function conquestDoctrineDeckPlan(size = 30, stars = 2, doctrine = null) {
  const resolved = doctrine ?? CONQUEST_INVA_FACTION_DOCTRINES['iron-carrion-mandate'];
  const remaining = Math.max(0, size - 1);
  const counts = {
    pylon: 0, ground: 0, ranged: 0, air: 0, horde: 0, giant: 0, siege: 0, tactic: 0, support: 0,
  };
  Object.entries(resolved.weights ?? {}).forEach(([cat, weight]) => {
    counts[cat] = Math.max(0, Math.floor(remaining * Math.max(0, Number(weight ?? 0))));
  });
  counts.pylon = Math.max(counts.pylon, Math.max(2, Math.floor(size / 12)));
  counts.giant = Math.max(counts.giant, size >= 60 ? 4 : size >= 50 ? 3 : size >= 40 ? 2 : size >= 30 ? 1 : 0);
  counts.siege = Math.max(counts.siege, size >= 20 ? 2 : 1);
  counts.tactic = Math.max(counts.tactic, size >= 20 ? 2 : 1);
  counts.ground = Math.max(counts.ground, size >= 20 ? 4 : 2);
  if (stars <= 2) {
    counts.ground += 2;
    counts.tactic = Math.max(1, counts.tactic - 2);
    counts.support = Math.max(1, counts.support - 1);
  }
  if (stars >= 4) {
    counts.tactic += 2;
    counts.support += 1;
    counts.siege += 1;
  }
  let total = Object.values(counts).reduce((sum, n) => sum + n, 0);
  const fillOrder = ['ground', 'horde', 'ranged', 'air', 'siege', 'support', 'tactic', 'pylon', 'giant'];
  while (total < remaining) {
    const key = fillOrder[total % fillOrder.length];
    counts[key] += 1;
    total += 1;
  }
  while (total > remaining) {
    const key = fillOrder.find((entry) => counts[entry] > (entry === 'pylon' ? 2 : entry === 'ground' ? 2 : 0));
    if (!key) break;
    counts[key] -= 1;
    total -= 1;
  }
  return counts;
}

function conquestPickCardsForDoctrine(pool, count, doctrine, stars = 2, seed = '') {
  if (!Array.isArray(pool) || !pool.length || count <= 0) return [];
  const rand = rngFromSeed(`${seed}-${count}-${stars}`);
  const prefer = new Set(toArray(doctrine?.preferTags).map((tag) => String(tag).toLowerCase()));
  const avoid = new Set(toArray(doctrine?.avoidTags).map((tag) => String(tag).toLowerCase()));
  const scored = pool.map((card) => {
    const tags = new Set(toArray(card.tags).map((tag) => String(tag).toLowerCase()));
    let score = 1 + (Number(card.siege ?? 0) * 0.5) + ((Number(card.range ?? 1) > 1) ? 0.35 : 0);
    tags.forEach((tag) => {
      if (prefer.has(tag)) score += 1.6;
      if (avoid.has(tag)) score -= 1.1;
    });
    if (stars >= 4 && (tags.has('support') || tags.has('capture') || tags.has('sabotage'))) score += 1.2;
    if (stars <= 2 && (String(card.type ?? '').toLowerCase() === 'spell' || String(card.type ?? '').toLowerCase() === 'tactic')) score -= 0.9;
    return { card, score: Math.max(0.05, score + (rand() * 0.3)) };
  }).sort((a, b) => b.score - a.score);
  const out = [];
  for (let i = 0; i < count; i += 1) {
    const topWindow = Math.max(1, Math.min(8, scored.length));
    const pickIdx = Math.floor(rand() * topWindow);
    out.push(scored[pickIdx]?.card?.id ?? scored[0].card.id);
  }
  return out;
}

function normalizeConquestAttackerDeckShape(deckIds = [], pools = null, options = {}) {
  const size = clamp(Math.round(toFiniteNumber(options.size, 30)), 10, 60);
  const homesteadId = String(options.homesteadId ?? 'cq-homestead');
  const requiredPylons = Math.max(0, Math.round(toFiniteNumber(options.requiredPylons, 2)));
  const allCards = Array.isArray(pools?.all) ? pools.all : [];
  const pylonCards = Array.isArray(pools?.pylonCore) && pools.pylonCore.length
    ? pools.pylonCore
    : (Array.isArray(pools?.pylon) ? pools.pylon : []);
  const groundCards = Array.isArray(pools?.ground) ? pools.ground : [];
  const homesteadCards = Array.isArray(pools?.homestead) ? pools.homestead : [];
  const normalized = toArray(deckIds).map((entry) => String(entry)).filter(Boolean);
  const pylonIds = new Set(pylonCards.map((entry) => String(entry.id)));
  const allIds = allCards.map((entry) => String(entry.id));
  const groundIds = (groundCards.length ? groundCards : allCards).map((entry) => String(entry.id));
  const pylonCycle = pylonCards.map((entry) => String(entry.id));
  const fallbackPylon = pylonCycle[0] ?? 'cq-mana-pylon';
  const fallbackGround = groundIds[0] ?? allIds[0] ?? fallbackPylon;
  const homesteadSet = new Set(homesteadCards.map((entry) => String(entry.id)));
  homesteadSet.add(homesteadId);
  const deckNoHome = normalized.filter((entry) => !homesteadSet.has(entry));
  const out = [homesteadId, ...deckNoHome];

  let pylonCount = out.filter((entry) => pylonIds.has(entry)).length;
  let insertAt = 1;
  while (pylonCount < requiredPylons && out.length < size) {
    out.splice(Math.min(insertAt, out.length), 0, pylonCycle[(pylonCount + insertAt) % Math.max(1, pylonCycle.length)] ?? fallbackPylon);
    pylonCount += 1;
    insertAt += 1;
  }

  let fillCursor = 0;
  while (out.length < size) {
    out.push(groundIds[fillCursor % Math.max(1, groundIds.length)] ?? fallbackGround);
    fillCursor += 1;
  }

  if (out.length > size) {
    for (let idx = out.length - 1; idx >= 1 && out.length > size; idx -= 1) {
      const candidate = out[idx];
      if (candidate === homesteadId) continue;
      if (pylonIds.has(candidate)) {
        const currentPylon = out.filter((entry) => pylonIds.has(entry)).length;
        if (currentPylon <= requiredPylons) continue;
      }
      out.splice(idx, 1);
    }
    while (out.length > size) out.pop();
  }

  if (out[0] !== homesteadId) {
    const idx = out.findIndex((entry) => entry === homesteadId);
    if (idx >= 0) {
      out.splice(idx, 1);
      out.unshift(homesteadId);
    } else {
      out.unshift(homesteadId);
      if (out.length > size) out.pop();
    }
  }
  return out.slice(0, size);
}

function buildConquestInvasionAttackerDeck(profile, {
  factionId = 'iron-carrion-mandate',
  triangles = 3,
  stars = 2,
  deckSize = null,
  threatId = '',
} = {}) {
  const resolvedFactionId = normalizeConquestInvasionFactionId(factionId);
  const doctrine = CONQUEST_INVA_FACTION_DOCTRINES[resolvedFactionId] ?? CONQUEST_INVA_FACTION_DOCTRINES['iron-carrion-mandate'];
  const tri = clamp(Math.round(toFiniteNumber(triangles, deckSize ? Math.round(toFiniteNumber(deckSize, 30) / 10) : 3)), 1, 6);
  const size = conquestDeckSizeFromTriangles(tri);
  const normalizedStars = clamp(Math.round(toFiniteNumber(stars, 2)), 1, 5);
  const variant = conquestDeckVariantForStars(normalizedStars);
  const deckName = conquestDeckSeriesName(resolvedFactionId, tri, variant);
  const mapWorld = getMapWorld(profile ?? loadProfile());
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const customFactionDecks = campaign?.invasionAttackerDecks?.[resolvedFactionId];
  const customTriangleDecks = customFactionDecks?.[`triangle_${tri}`];
  const customVariant = customTriangleDecks?.[variant]
    ?? customTriangleDecks?.default
    ?? customTriangleDecks?.basic
    ?? customTriangleDecks?.advanced
    ?? null;
  const pools = conquestAttackerPoolByCategory(profile);
  const homestead = pools.homestead.find((entry) => entry.id === 'cq-homestead') ?? pools.homestead[0] ?? { id: 'cq-homestead' };
  const counts = conquestDoctrineDeckPlan(size, normalizedStars, doctrine);
  const requiredPylons = Math.max(conquestMinimumPylonsForSize(size), Math.max(2, Number(counts.pylon ?? 2)));
  if (Array.isArray(customVariant) && customVariant.length) {
    const normalized = normalizeConquestAttackerDeckShape(customVariant, pools, {
      size,
      requiredPylons,
      homesteadId: homestead.id,
    });
    return {
      deckIds: normalized,
      meta: {
        factionId: resolvedFactionId,
        triangles: tri,
        deckSize: size,
        stars: normalizedStars,
        variant,
        deckName: `${deckName} (custom)`,
        doctrine: `${variant === 'advanced' ? doctrine.advancedLabel : doctrine.label} (custom)`,
        threatStyle: doctrine.threatStyle,
        categoryPlan: counts,
      },
    };
  }
  const seedBase = `${resolvedFactionId}-${tri}-${normalizedStars}-${variant}-${threatId || 'deck'}`;
  const deckIds = [String(homestead.id ?? 'cq-homestead')];
  const categories = ['pylon', 'ground', 'ranged', 'air', 'horde', 'giant', 'siege', 'tactic', 'support'];
  categories.forEach((category) => {
    const sourcePool = category === 'pylon'
      ? (pools.pylonCore?.length ? pools.pylonCore : pools.pylon)
      : pools[category];
    const picks = conquestPickCardsForDoctrine(
      sourcePool?.length ? sourcePool : pools.all,
      Math.max(0, Number(counts[category] ?? 0)),
      doctrine,
      normalizedStars,
      `${seedBase}-${category}`,
    );
    deckIds.push(...picks);
  });
  const normalized = normalizeConquestAttackerDeckShape(deckIds, pools, {
    size,
    requiredPylons,
    homesteadId: homestead.id,
  });
  return {
    deckIds: normalized,
    meta: {
      factionId: resolvedFactionId,
      triangles: tri,
      deckSize: size,
      stars: normalizedStars,
      variant,
      deckName,
      doctrine: variant === 'advanced' ? doctrine.advancedLabel : doctrine.label,
      threatStyle: doctrine.threatStyle,
      categoryPlan: counts,
    },
  };
}

function buildEncounterAttackerDeck(profile, context = {}, activeThreat = null) {
  const threatType = String(context?.metadata?.threatType ?? '').toLowerCase();
  const factionIdRaw = context?.metadata?.factionId
    ?? context?.factionId
    ?? activeThreat?.factionId
    ?? activeThreat?.houseId
    ?? (threatType === 'pirate' ? 'iron-carrion-mandate' : 'iron-carrion-mandate');
  const triangles = context?.deckTriangles
    ?? context?.metadata?.deckTriangles
    ?? activeThreat?.deckTriangles
    ?? conquestTrianglesFromDeckSize(context?.deckSize ?? context?.threatDeckSize ?? activeThreat?.deckSizeEstimate ?? 30);
  const stars = context?.aiSkillStars
    ?? context?.metadata?.aiSkillStars
    ?? activeThreat?.aiSkillStars
    ?? (threatType === 'pirate' ? 3 : 2);
  const forcedDeckSize = conquestDeckSizeFromTriangles(triangles);
  return buildConquestInvasionAttackerDeck(profile, {
    factionId: factionIdRaw,
    triangles,
    stars,
    deckSize: forcedDeckSize,
    threatId: context?.threatId ?? activeThreat?.id ?? '',
  });
}

function applyEncounterAttackerDeck(state, deckPackage = null) {
  if (!state || !deckPackage?.deckIds?.length) return;
  state.attacker = state.attacker ?? {};
  state.attacker.mana = 1;
  state.attacker.manaPylons = 1;
  state.attacker.homesteadDeployed = false;
  state.attacker.hand = [];
  state.attacker.deck = deckPackage.deckIds.map((entry) => String(entry));
  state.attacker.discard = [];
  state.attacker.deckMeta = { ...(deckPackage.meta ?? {}) };
}

function invasionFactionPool(threat) {
  const factionId = String(threat?.factionId ?? '').toLowerCase();
  if (!factionId) return [];
  const direct = Array.isArray(cachedPackCardsById?.[factionId]) ? cachedPackCardsById[factionId] : [];
  if (direct.length) return direct;
  const all = Object.values(cachedPackCardsById ?? {}).flat();
  return all.filter((card) => {
    const cardFaction = String(card.factionId ?? card.invasionFaction ?? '').toLowerCase();
    const packSource = String(card.packSource ?? '').toLowerCase();
    const tags = Array.isArray(card.tags) ? card.tags.map((tag) => String(tag).toLowerCase()) : [];
    return cardFaction === factionId || packSource === factionId || tags.includes(factionId) || tags.includes(`faction:${factionId}`);
  });
}

function buildAlienFallbackDeck(threat, nodeName = 'frontier') {
  const size = clamp(Math.floor(toFiniteNumber(threat?.deckSizeEstimate, 30)), 20, 90);
  const faction = String(threat?.factionName ?? 'Alien Vanguard');
  const out = [];
  for (let i = 0; i < size; i += 1) {
    const atk = 1 + (i % 5);
    const hp = 2 + ((i + 1) % 6);
    out.push({
      id: `alien-placeholder-${slugifyId(threat?.id ?? faction)}-${i + 1}`,
      name: `${faction} Drone ${i + 1}`,
      type: 'minion',
      attack: atk,
      health: hp,
      def: i % 4 === 0 ? 1 : 0,
      race: 'alien',
      element: 'void',
      rarity: i % 12 === 0 ? 'epic' : i % 5 === 0 ? 'rare' : 'common',
      tags: ['alien', String(threat?.factionId ?? 'alien').toLowerCase(), `region:${slugifyId(nodeName)}`],
      text: i % 7 === 0 ? 'Swarm doctrine: +1 ATK this turn after deployment.' : '',
      taunt: i % 9 === 0,
      charge: i % 11 === 0,
    });
  }
  return out;
}

function buildAlienPlaceholderDeck(threat, nodeName = 'frontier') {
  const size = clamp(Math.floor(toFiniteNumber(threat?.deckSizeEstimate, 30)), 20, 90);
  const factionId = String(threat?.factionId ?? '').toLowerCase();
  const pool = invasionFactionPool(threat)
    .map((card) => ({ ...card, __normalizedType: normalizeInvasionCardType(card.type) }))
    .filter((card) => card.__normalizedType === 'minion');
  if (!pool.length) return buildAlienFallbackDeck(threat, nodeName);

  const rand = rngFromSeed(`${threat?.id ?? factionId}-${size}-${threat?.aiSkillStars ?? 1}-${threat?.techLevel ?? 1}`);
  const curveWeights = [
    { cost: 1, weight: 2.2 },
    { cost: 2, weight: 2.6 },
    { cost: 3, weight: 2.4 },
    { cost: 4, weight: 2.1 },
    { cost: 5, weight: 1.6 },
    { cost: 6, weight: 1.2 },
    { cost: 7, weight: 0.8 },
    { cost: 8, weight: 0.6 },
    { cost: 9, weight: 0.35 },
  ];
  if (toFiniteNumber(threat?.aiSkillStars, 1) >= 4) {
    curveWeights.forEach((entry) => {
      if (entry.cost <= 2) entry.weight *= 0.85;
      if (entry.cost >= 5) entry.weight *= 1.22;
    });
  }

  const rarityBias = {
    common: 1,
    rare: 1 + (toFiniteNumber(threat?.aiSkillStars, 1) * 0.08),
    epic: 1 + (toFiniteNumber(threat?.techLevel, 1) * 0.07),
    legendary: 0.45 + (toFiniteNumber(threat?.techLevel, 1) * 0.045),
  };
  const out = [];
  const factionTag = factionId || 'alien';
  const signatureNeedles = toArray(threat?.signatureCards).map((entry) => slugifyId(entry));
  const signatureBoost = threat?.commanderRank === 'boss' ? 2.4 : (threat?.commanderRank === 'elite' ? 1.75 : 1);
  for (let i = 0; i < size; i += 1) {
    const target = weightedPickEntry(curveWeights, rand)?.cost ?? 3;
    let candidates = pool.filter((card) => Math.abs(toFiniteNumber(card.cost, 1) - target) <= 1);
    if (!candidates.length) candidates = pool;
    const weighted = candidates.map((card) => ({
      card,
      weight: (() => {
        const base = Math.max(0.12, (rarityBias[String(card.rarity ?? 'common').toLowerCase()] ?? 1) + (0.2 * rand()));
        if (!signatureNeedles.length) return base;
        const idSlug = slugifyId(card.id ?? '');
        const nameSlug = slugifyId(card.name ?? '');
        const signatureMatch = signatureNeedles.some((needle) => idSlug.includes(needle) || nameSlug.includes(needle));
        return signatureMatch ? (base * signatureBoost) : base;
      })(),
    }));
    const picked = weightedPickEntry(weighted, rand)?.card ?? candidates[Math.floor(rand() * candidates.length)];
    const atk = Math.max(1, toFiniteNumber(picked.attack, Math.ceil(toFiniteNumber(picked.cost, 1) * 0.75)));
    const hp = Math.max(1, toFiniteNumber(picked.health, Math.ceil(toFiniteNumber(picked.cost, 1) * 1.1)));
    out.push({
      ...picked,
      id: `${picked.id}-fleet-${i + 1}`,
      name: picked.name,
      type: 'minion',
      attack: atk,
      health: hp,
      def: Math.max(0, toFiniteNumber(picked.def ?? picked.baseDef, 0)),
      rarity: picked.rarity ?? 'common',
      race: picked.race ?? 'alien',
      tags: [...new Set([...(picked.tags ?? []), 'alien', factionTag, `region:${slugifyId(nodeName)}`])],
      text: picked.text ?? '',
      taunt: !!picked.taunt || !!picked.guard,
      charge: !!picked.charge || String(picked.text ?? '').toLowerCase().includes('haste'),
      pierce: Math.max(0, toFiniteNumber(picked.pierce, 0)),
      trueDamage: !!picked.trueDamage,
      large: !!picked.large,
      swarm: !!picked.swarm,
      flying: !!picked.flying,
      reach: !!picked.reach,
      siege: !!picked.siege,
      effect: picked.effect ?? picked.ability ?? {},
      ability: picked.ability ?? picked.effect ?? {},
      battleCompatibility: picked.battleCompatibility ?? 'defense_only',
      factionId: picked.factionId ?? factionId,
      invasionFaction: picked.invasionFaction ?? factionId,
      packSource: picked.packSource ?? factionId,
    });
  }
  return out;
}

function threatCommanderLabel(threat = {}) {
  if (!threat.commanderName) return null;
  return `${threat.commanderName}${threat.commanderTitle ? `, ${threat.commanderTitle}` : ''}`;
}

function threatRankDisplay(rank = 'standard') {
  if (rank === 'boss') return 'Boss Commander';
  if (rank === 'elite') return 'Elite Commander';
  return 'Standard Command';
}

function grimdarkThreatDialogue(threat, nodeName = 'this world') {
  const faction = threat?.factionName ?? 'Invasion fleet';
  const commander = threat?.commanderName ?? 'Field commander';
  return {
    battle_start: [
      `${commander}: We are here for ${nodeName}. Nothing personal.`,
      `${faction}: Hold the line if you can. We only need one breach.`,
      `${commander}: Your defenses are noted. We'll test each lane in turn.`,
    ],
    strong_play: [
      `${commander}: That wall won't last another exchange.`,
      `${faction}: Pressure is working. Keep the push clean.`,
      `${commander}: You are spending faster than you can recover.`,
    ],
    low_health: [
      `${commander}: Casualties are acceptable. Maintain formation.`,
      `${faction}: Pull back one lane, keep the pylon line intact.`,
      `${commander}: Stabilize and continue. We are still in this.`,
    ],
    victory_near: [
      `${commander}: One final push and the dimension falls.`,
      `${faction}: Last column in sight. Do not slow down.`,
      `${commander}: We finish this now.`,
    ],
    defeat: [
      `${commander}: Withdrawal confirmed. We'll return with heavier fleets.`,
      `${faction}: You bought time, not safety.`,
      `${commander}: This loss is temporary.`,
    ],
  };
}

function clearInvasionSweepFx() {
  mapView.invasionSweep = null;
  if (mapEffectsState) mapEffectsState.invasionSweep = null;
}

function triggerInvasionSweepFx(threat, sourceNode, targetNode, durationMs = 1760) {
  if (!threat || !targetNode) return null;
  const factionId = normalizeConquestInvasionFactionId(
    threat.factionId ?? threat.invasionFaction ?? threat.factionName ?? 'iron-carrion-mandate',
  );
  const fx = conquestFactionFxProfile(factionId);
  const now = Date.now();
  const source = sourceNode ?? targetNode;
  const sweep = {
    threatId: String(threat.id ?? `${factionId}-${now}`),
    sourceNodeId: String(source?.id ?? targetNode.id),
    targetNodeId: String(targetNode.id),
    factionId,
    deckSeries: String(threat.deckSeries ?? conquestDeckSeriesName(factionId, threat.deckTriangles, threat.deckVariant)),
    threatStyle: String(threat.threatStyle ?? threat.commanderPlaystyle ?? fx.style ?? 'standard'),
    stars: clamp(Math.round(toFiniteNumber(threat.aiSkillStars, 2)), 1, 5),
    triangles: clamp(Math.round(toFiniteNumber(threat.deckTriangles, threat.deckSizeEstimate / 10)), 1, 6),
    startedAt: now,
    durationMs: clamp(Math.round(toFiniteNumber(durationMs, 1760)), 820, 3600),
  };
  mapView.invasionSweep = sweep;
  if (mapEffectsState) mapEffectsState.invasionSweep = sweep;
  return sweep;
}

function playInvasionSweepSequence(threat, targetNode) {
  if (!threat || !targetNode) return Promise.resolve();
  const battlemapVisible = !!(
    dom.battlemapPanel
    && !dom.battlemapPanel.classList.contains('hidden')
    && dom.matchTab
    && !dom.matchTab.classList.contains('hidden')
  );
  if (!battlemapVisible) return Promise.resolve();
  const sourceNode = mapNodeById(threat.currentNodeId ?? threat.nodeId ?? threat.sourceNodeId ?? targetNode.id)
    ?? mapNodeById(threat.nodeId ?? '')
    ?? targetNode;
  const sweep = triggerInvasionSweepFx(threat, sourceNode, targetNode);
  if (!sweep) return Promise.resolve();
  if (!mapEffectsHandle) {
    const profile = loadProfile();
    const mapWorld = getMapWorld(profile);
    const style = findStyleById(mapWorld.globalMapStyleId);
    const nodes = mapView.nodes?.length ? mapView.nodes : mapView.baseNodes;
    startMapEffects(style, nodes, mapView.sceneStaticSig || buildStaticSceneSignature(nodes));
  }
  const waitMs = clamp(Math.round(toFiniteNumber(sweep.durationMs, 1760) * 0.9), 620, 2600);
  return new Promise((resolve) => {
    setTimeout(resolve, waitMs);
  });
}

async function launchAlienThreatBattle(threat, node) {
  if (!threat || invasionLaunchLock) return;
  invasionLaunchLock = true;
  const resolvedNode = node ?? mapNodeById(threat.currentNodeId ?? threat.targetNodeId ?? threat.nodeId) ?? {
    id: String(threat.targetNodeId ?? threat.currentNodeId ?? threat.nodeId ?? `threat-${threat.id}`),
    name: String(threat.region ?? threat.factionName ?? 'Unknown Region'),
    universe: String(threat.region ?? 'Unknown'),
    styleId: 'astral-cartographer',
  };
  const aiLevel = clamp((Number(threat.aiSkillStars ?? 1) * 6) + Number(threat.techLevel ?? 1), 4, 50);
  const placeholderDeck = buildAlienPlaceholderDeck(threat, resolvedNode.name);
  const commanderLabel = threatCommanderLabel(threat);
  const rankLabel = threatRankDisplay(threat.commanderRank ?? 'standard');
  const signatureCardLine = toArray(threat.signatureCards).slice(0, 3).join(', ');
  const signatureMechanicLine = toArray(threat.signatureMechanics).slice(0, 3).join(', ');
  const introLine = threat.commanderDialogue?.intro ?? `${threat.factionName} commander engaging ${resolvedNode.name}.`;
  const strongLine = threat.commanderDialogue?.strong ?? `${threat.factionName} pressure intensifies.`;
  const defeatLine = threat.commanderDialogue?.defeat ?? `${threat.factionName} fleet forced into withdrawal.`;
  const deckDoctrine = conquestDoctrineLabelForThreat(threat.factionId, threat.aiSkillStars);
  const triCount = clamp(Math.round(toFiniteNumber(threat.deckTriangles, toFiniteNumber(threat.deckSizeEstimate, 30) / 10)), 1, 6);
  const deckVariant = threat.deckVariant ?? conquestDeckVariantForStars(threat.aiSkillStars);
  const deckSeries = threat.deckSeries ?? conquestDeckSeriesName(threat.factionId, triCount, deckVariant);
  const canned = grimdarkThreatDialogue(threat, resolvedNode.name);
  const threatAi = {
    id: `alien-ai-${threat.id}`,
    name: commanderLabel ?? `${threat.factionName} Vanguard`,
    level: aiLevel,
    archetype: `alien-${threat.factionId}`,
    personality: {
      title: commanderLabel ? `${rankLabel} • ${threat.factionName}` : `${threat.factionName} Incursion`,
      dimensionTag: `#${resolvedNode.universe ?? resolvedNode.name}`,
      backstory: threat.commanderLore
        ? `${threat.commanderLore} Current objective: ${threat.objective ?? 'invade'} ${resolvedNode.name}.`
        : `${threat.factionName} force advancing on ${resolvedNode.name}.`,
      loadingFlavor: `${introLine} ${signatureMechanicLine ? `Signature: ${signatureMechanicLine}.` : ''} ${signatureCardLine ? `Lead cards: ${signatureCardLine}.` : ''}`.trim(),
    },
    deckIdentity: `${threat.deckSizeEstimate}-card strike force (${triCount}△ • ${deckSeries} • ${deckDoctrine} • ${rankLabel})`,
    styleId: resolvedNode.styleId,
    faction: threat.factionName,
    assignedPacks: [threat.factionId].filter(Boolean),
    deck: placeholderDeck,
    summons: placeholderDeck.slice(0, 16),
    voiceLines: {
      battle_start: [introLine, ...canned.battle_start],
      strong_play: [strongLine, ...canned.strong_play],
      low_health: canned.low_health,
      victory_near: canned.victory_near,
      defeat: [defeatLine, ...canned.defeat],
    },
    behaviorNotes: [threat.commanderPersonality, threat.commanderPlaystyle].filter(Boolean).join(' • '),
  };
  try {
    await playInvasionSweepSequence(threat, resolvedNode);
    startCinematic('Novice', threatAi, {
      rulesetId: threat.deckSizeEstimate >= 60 ? 'massive-invasion' : 'planetary-defense',
      battleType: 'defense_conquest',
      routeTarget: 'facility_war',
      forceReset: true,
      worldId: threat.targetNodeId ?? threat.nodeId,
      planetId: threat.targetPlanetId ?? null,
      targetPlanetId: threat.targetPlanetId ?? null,
      threatId: threat.id,
      sourceNodeId: threat.currentNodeId ?? threat.nodeId,
      deckSize: threat.deckSizeEstimate,
      threatDeckSize: threat.deckSizeEstimate,
      deckTriangles: clamp(Math.round(toFiniteNumber(threat.deckTriangles, threat.deckSizeEstimate / 10)), 1, 6),
      aiSkillStars: threat.aiSkillStars,
      techLevel: threat.techLevel,
      metadata: {
        threatType: 'alien',
        factionId: threat.factionId,
        commanderId: threat.commanderId ?? null,
        commanderName: threat.commanderName ?? null,
        commanderTitle: threat.commanderTitle ?? null,
        commanderRank: threat.commanderRank ?? 'standard',
        signatureCards: toArray(threat.signatureCards),
        signatureMechanics: toArray(threat.signatureMechanics),
      },
    });
  } catch (error) {
    console.error('[Conquest] Failed to launch invasion battle:', error);
  } finally {
    clearInvasionSweepFx();
    invasionLaunchLock = false;
  }
}

function startMapEffects(style, nodes, staticSig = '') {
  if (!dom.mapEffectsCanvas) return;
  if (mapRuntimeSuspended || isFacilityWarOpen()) return;
  resizeMapEffectsCanvas();
  const sceneSig = `${style?.id ?? 'style'}|${staticSig}`;
  if (mapEffectsState?.sceneSig === sceneSig && mapEffectsHandle) return;
  stopMapEffects();
  const ctx = dom.mapEffectsCanvas.getContext('2d');
  const rect = dom.mapStage?.getBoundingClientRect() ?? dom.mapEffectsCanvas.getBoundingClientRect();
  let width = Math.max(1, rect.width);
  let height = Math.max(1, rect.height);
  const rand = rngFromSeed(`${style.id}-${nodes.length}-${getSessionSeed()}`);
  const starDensity = Math.max(40, style?.starfield?.density ?? 90);
  const twinkle = Math.max(0.2, style?.starfield?.twinkle ?? 0.8);
  const stars = Array.from({ length: starDensity }, () => ({
    x: rand() * width,
    y: rand() * height,
    r: 0.4 + rand() * 1.6,
    phase: rand() * Math.PI * 2,
  }));
  const particleCount = Math.max(16, style?.particles?.count ?? 42);
  const particleSpeed = Math.max(0.06, style?.particles?.speed ?? 0.28);
  const particles = Array.from({ length: particleCount }, () => ({
    x: rand() * width,
    y: rand() * height,
    vx: (rand() - 0.5) * particleSpeed,
    vy: (rand() - 0.5) * particleSpeed,
    size: 0.7 + (rand() * 2.4),
  }));
  const orbiters = nodes.filter((node) => node.sunCount > 1 || node.stateTag === 'occupied' || node.stateTag === 'boss').map((node) => ({
    nodeId: node.id,
    angle: rand() * Math.PI * 2,
    radius: node.radius + 9 + (rand() * 11),
    speed: 0.006 + (rand() * 0.01),
    size: 1.2 + (rand() * 2.3),
  }));
  const bgA = style?.palette?.bgA ?? '#071127';
  const bgB = style?.palette?.bgB ?? '#162241';
  let tick = 0;
  let lastFrameTs = 0;
  mapEffectsState = {
    sceneSig,
    styleId: style?.id ?? 'astral-cartographer',
    stars,
    particles,
    orbiters,
    invasionSweep: mapView.invasionSweep ?? null,
  };
  const draw = (ts = 0) => {
    if (mapRuntimeSuspended || isFacilityWarOpen() || document.hidden || !dom.battlemapPanel || dom.battlemapPanel.classList.contains('hidden')) {
      mapEffectsHandle = null;
      return;
    }
    if ((ts - lastFrameTs) < 32) {
      mapEffectsHandle = requestAnimationFrame(draw);
      return;
    }
    lastFrameTs = ts;
    tick += 1;
    const liveRect = dom.mapStage?.getBoundingClientRect() ?? dom.mapEffectsCanvas.getBoundingClientRect();
    const liveWidth = Math.max(1, liveRect.width);
    const liveHeight = Math.max(1, liveRect.height);
    if (Math.abs(liveWidth - width) > 6 || Math.abs(liveHeight - height) > 6) {
      width = liveWidth;
      height = liveHeight;
      resizeMapEffectsCanvas();
    }
    ctx.clearRect(0, 0, width, height);
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, bgA);
    gradient.addColorStop(1, bgB);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    stars.forEach((star) => {
      const alpha = 0.18 + (0.68 * ((Math.sin((tick * 0.016 * twinkle) + star.phase) + 1) * 0.5));
      ctx.fillStyle = `rgba(225,236,255,${alpha})`;
      ctx.beginPath();
      ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
      ctx.fill();
    });

    particles.forEach((particle) => {
      particle.x += particle.vx;
      particle.y += particle.vy;
      if (particle.x < -8) particle.x = width + 8;
      if (particle.x > width + 8) particle.x = -8;
      if (particle.y < -8) particle.y = height + 8;
      if (particle.y > height + 8) particle.y = -8;
      ctx.fillStyle = 'rgba(177,206,255,0.22)';
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fill();
    });

    orbiters.forEach((orbiter) => {
      const node = mapNodeById(orbiter.nodeId);
      if (!node) return;
      orbiter.angle += orbiter.speed;
      const px = (node.x * mapView.zoom) + mapView.panX + Math.cos(orbiter.angle) * (orbiter.radius * mapView.zoom);
      const py = (node.y * mapView.zoom) + mapView.panY + Math.sin(orbiter.angle) * (orbiter.radius * mapView.zoom);
      ctx.fillStyle = 'rgba(188, 227, 255, 0.65)';
      ctx.beginPath();
      ctx.arc(px, py, orbiter.size, 0, Math.PI * 2);
      ctx.fill();
    });

    const sweep = mapView.invasionSweep ?? mapEffectsState?.invasionSweep ?? null;
    if (sweep?.targetNodeId) {
      const sourceNode = mapNodeById(sweep.sourceNodeId ?? sweep.targetNodeId) ?? mapNodeById(sweep.targetNodeId);
      const targetNode = mapNodeById(sweep.targetNodeId);
      if (sourceNode && targetNode) {
        mapEffectsState.invasionSweep = sweep;
        const fx = conquestFactionFxProfile(sweep.factionId);
        const nowMs = Date.now();
        const startedAt = Number(sweep.startedAt ?? nowMs);
        const duration = Math.max(520, Number(sweep.durationMs ?? 1700));
        const rawProgress = (nowMs - startedAt) / duration;
        const progress = clamp(rawProgress, 0, 1);
        const finishFade = rawProgress > 1 ? clamp(1 - ((rawProgress - 1) / 0.28), 0, 1) : 1;
        const alpha = 0.15 + (0.72 * finishFade);
        const sx = (sourceNode.x * mapView.zoom) + mapView.panX;
        const sy = (sourceNode.y * mapView.zoom) + mapView.panY;
        const tx = (targetNode.x * mapView.zoom) + mapView.panX;
        const ty = (targetNode.y * mapView.zoom) + mapView.panY;
        const hx = sx + ((tx - sx) * progress);
        const hy = sy + ((ty - sy) * progress);
        const trail = ctx.createLinearGradient(sx, sy, hx, hy);
        trail.addColorStop(0, `rgba(${fx.pulse}, ${0.06 * alpha})`);
        trail.addColorStop(0.55, `rgba(${fx.trail}, ${0.22 * alpha})`);
        trail.addColorStop(1, `rgba(${fx.pulse}, ${0.74 * alpha})`);
        ctx.strokeStyle = trail;
        ctx.lineWidth = 2 + (2.2 * finishFade);
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(hx, hy);
        ctx.stroke();
        const particleCount = 8 + Math.round(5 * fx.density);
        for (let i = 0; i < particleCount; i += 1) {
          const t = clamp(progress - ((i / particleCount) * 0.3), 0, 1);
          const px = sx + ((tx - sx) * t);
          const py = sy + ((ty - sy) * t);
          const pulse = 0.55 + (Math.sin((tick * 0.07 * fx.speed) + i) * 0.45);
          const r = 1 + ((1 - (i / particleCount)) * 2.4 * pulse);
          ctx.fillStyle = `rgba(${fx.ember}, ${(0.2 + (0.52 * (1 - (i / particleCount)))) * alpha})`;
          if (fx.style === 'shard') {
            ctx.beginPath();
            ctx.moveTo(px, py - r);
            ctx.lineTo(px - (r * 0.8), py + r);
            ctx.lineTo(px + (r * 0.8), py + r);
            ctx.closePath();
            ctx.fill();
          } else if (fx.style === 'halo') {
            ctx.strokeStyle = `rgba(${fx.pulse}, ${(0.12 + (0.34 * (1 - (i / particleCount)))) * alpha})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(px, py, r, 0, Math.PI * 2);
            ctx.stroke();
          } else {
            ctx.beginPath();
            ctx.arc(px, py, r, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        const headRadius = 5.4 + (3.2 * finishFade);
        ctx.fillStyle = `rgba(${fx.pulse}, ${0.84 * alpha})`;
        ctx.beginPath();
        ctx.arc(hx, hy, headRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = `rgba(${fx.trail}, ${0.42 * alpha})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(tx, ty, 8 + (6 * (1 - progress)), 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = `rgba(${fx.ember}, ${0.54 * alpha})`;
        ctx.beginPath();
        ctx.arc(tx, ty, 2.4 + (2 * (Math.sin(tick * 0.08) * 0.5 + 0.5)), 0, Math.PI * 2);
        ctx.fill();
        const statusLabel = `${sweep.deckSeries ?? 'Invasion'} • ${'★'.repeat(clamp(Math.round(toFiniteNumber(sweep.stars, 2)), 1, 5))}`;
        ctx.font = '11px "Segoe UI", sans-serif';
        ctx.fillStyle = `rgba(${fx.pulse}, ${0.82 * alpha})`;
        ctx.fillText(statusLabel, Math.min(width - 240, Math.max(14, hx + 12)), Math.max(22, hy - 14));
        if (rawProgress >= 1.28) {
          clearInvasionSweepFx();
        }
      } else if (Date.now() - Number(sweep.startedAt ?? Date.now()) > 4200) {
        clearInvasionSweepFx();
      }
    }

    mapEffectsHandle = requestAnimationFrame(draw);
  };
  draw();
}

function startFacilityWarEffects(state) {
  const canvas = dom.facilityWarEffectsCanvas;
  if (!canvas || !state) return;
  const mapWorld = getMapWorld(loadProfile());
  const style = findStyleById(mapWorld.globalMapStyleId);
  const sceneSig = `${state.worldId ?? 'world'}:${state.planetId ?? 'planet'}:${style.id}`;
  if (facilityWarEffectsState?.sceneSig === sceneSig && facilityWarEffectsHandle) {
    facilityWarEffectsState.liveState = state;
    return;
  }
  stopFacilityWarEffects();

  const rand = rngFromSeed(`facility-${sceneSig}-${getSessionSeed()}`);
  const startedAt = (typeof performance !== 'undefined' && typeof performance.now === 'function')
    ? performance.now()
    : Date.now();
  const stars = Array.from({ length: 66 }, () => ({
    x: rand(),
    y: rand(),
    r: 0.5 + (rand() * 1.5),
    phase: rand() * Math.PI * 2,
  }));
  const particles = Array.from({ length: 32 }, () => ({
    x: rand(),
    y: rand(),
    vx: (rand() - 0.5) * 0.00028,
    vy: (rand() - 0.5) * 0.00028,
    size: 0.8 + (rand() * 2.1),
  }));
  facilityWarEffectsState = {
    sceneSig,
    styleId: style.id,
    stars,
    particles,
    tick: 0,
    liveState: state,
    shakePower: 0,
    shakeUntil: 0,
    introStartTs: startedAt,
    introDuration: 940,
    events: [{
      kind: 'battlemat-enter',
      side: 'neutral',
      ts: startedAt,
      life: 980,
    }],
  };
  let lastFrameTs = 0;
  const draw = (ts = 0) => {
    const effectState = facilityWarEffectsState;
    if (!effectState || !dom.facilityWarModal || dom.facilityWarModal.classList.contains('hidden')) {
      facilityWarEffectsHandle = null;
      return;
    }
    if ((ts - lastFrameTs) < 32) {
      facilityWarEffectsHandle = requestAnimationFrame(draw);
      return;
    }
    lastFrameTs = ts;
    effectState.tick += 1;
    const rect = canvas.getBoundingClientRect();
    const ratio = Math.max(1, window.devicePixelRatio || 1);
    const width = Math.max(220, Math.floor(rect.width || 520));
    const height = Math.max(170, Math.floor(rect.height || 360));
    const targetW = Math.max(1, Math.floor(width * ratio));
    const targetH = Math.max(1, Math.floor(height * ratio));
    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const now = (typeof performance !== 'undefined' && typeof performance.now === 'function')
      ? performance.now()
      : Date.now();
    const activeShake = Number(effectState.shakeUntil ?? 0) > now
      ? Math.max(0, Number(effectState.shakePower ?? 0)) * clamp((Number(effectState.shakeUntil ?? 0) - now) / 240, 0, 1)
      : 0;
    const shakeX = activeShake > 0 ? (Math.random() - 0.5) * activeShake : 0;
    const shakeY = activeShake > 0 ? (Math.random() - 0.5) * activeShake : 0;
    const gridShell = dom.facilityWarGrid?.parentElement;
    if (gridShell) {
      if (activeShake > 0.1) {
        gridShell.style.transform = `translate(${shakeX.toFixed(2)}px, ${shakeY.toFixed(2)}px)`;
      } else if (gridShell.style.transform) {
        gridShell.style.transform = '';
      }
    }
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(shakeX, shakeY);
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, style.palette?.bgA ?? '#071127');
    gradient.addColorStop(1, style.palette?.bgB ?? '#121a35');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    const introDuration = Math.max(460, Number(effectState.introDuration ?? 940));
    const introProgress = clamp((now - Number(effectState.introStartTs ?? now)) / introDuration, 0, 1);
    if (introProgress < 1) {
      const fade = 1 - introProgress;
      const sweepX = (-0.36 + (1.56 * introProgress)) * width;
      const sweep = ctx.createLinearGradient(sweepX - (width * 0.22), 0, sweepX + (width * 0.22), 0);
      sweep.addColorStop(0, 'rgba(122, 186, 255, 0)');
      sweep.addColorStop(0.5, `rgba(138, 204, 255, ${0.12 + (0.32 * fade)})`);
      sweep.addColorStop(1, 'rgba(122, 186, 255, 0)');
      ctx.fillStyle = `rgba(2, 8, 19, ${0.48 * fade})`;
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = sweep;
      ctx.fillRect(0, 0, width, height);
      for (let r = 0; r < CONQUEST_GRID_ROWS; r += 1) {
        const y = ((r + 0.5) / CONQUEST_GRID_ROWS) * height;
        ctx.strokeStyle = `rgba(146, 203, 255, ${0.06 + (0.18 * fade)})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    }

    effectState.stars.forEach((star) => {
      const alpha = 0.16 + (0.56 * ((Math.sin((effectState.tick * 0.021) + star.phase) + 1) * 0.5));
      ctx.fillStyle = `rgba(216,234,255,${alpha})`;
      ctx.beginPath();
      ctx.arc(star.x * width, star.y * height, star.r, 0, Math.PI * 2);
      ctx.fill();
    });

    effectState.particles.forEach((particle) => {
      particle.x += particle.vx;
      particle.y += particle.vy;
      if (particle.x < -0.02) particle.x = 1.02;
      if (particle.x > 1.02) particle.x = -0.02;
      if (particle.y < -0.02) particle.y = 1.02;
      if (particle.y > 1.02) particle.y = -0.02;
      ctx.fillStyle = 'rgba(162, 204, 255, 0.24)';
      ctx.beginPath();
      ctx.arc(particle.x * width, particle.y * height, particle.size, 0, Math.PI * 2);
      ctx.fill();
    });

    const cellW = width / CONQUEST_GRID_COLS;
    const cellH = height / CONQUEST_GRID_ROWS;
    const locateCell = (idx) => {
      if (!Number.isInteger(idx)) return null;
      const row = Math.floor(idx / CONQUEST_GRID_COLS);
      const col = idx % CONQUEST_GRID_COLS;
      if (row < 0 || row >= CONQUEST_GRID_ROWS || col < 0 || col >= CONQUEST_GRID_COLS) return null;
      return {
        x: (col * cellW) + (cellW * 0.5),
        y: (row * cellH) + (cellH * 0.5),
      };
    };

    const liveGrid = effectState.liveState?.grid ?? [];
    if (liveGrid.length) {
      liveGrid.forEach((cell, idx) => {
        if (!cell?.occupant) return;
        const row = Math.floor(idx / CONQUEST_GRID_COLS);
        const col = idx % CONQUEST_GRID_COLS;
        const cx = (col * cellW) + (cellW * 0.5);
        const cy = (row * cellH) + (cellH * 0.5);
        const glow = cell.occupant.side === 'defender'
          ? 'rgba(98, 184, 255, 0.18)'
          : 'rgba(232, 124, 124, 0.18)';
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(cx, cy, Math.min(cellW, cellH) * 0.24, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    const activeEvents = [];
    (Array.isArray(effectState.events) ? effectState.events : []).forEach((event) => {
      const age = now - Number(event.ts ?? now);
      const life = Math.max(140, Number(event.life ?? 560));
      if (age >= life) return;
      activeEvents.push(event);
      const progress = clamp(age / life, 0, 1);
      const fade = 1 - progress;
      const source = locateCell(Number.isInteger(event.sourceIndex) ? event.sourceIndex : event.cellIndex);
      const target = locateCell(Number.isInteger(event.targetIndex) ? event.targetIndex : event.cellIndex);
      const kind = String(event.kind ?? 'pulse').toLowerCase();
      const attackClass = String(event.attackClass ?? '').toLowerCase();
      const projectileKind = String(event.projectileKind ?? '').toLowerCase();
      const impactKind = String(event.impactKind ?? '').toLowerCase();
      const palette = (() => {
        if (attackClass.includes('anti-barrage')) return '255, 174, 109';
        if (attackClass.includes('anti-air')) return '166, 222, 255';
        if (attackClass.includes('turret')) return '255, 211, 132';
        if (attackClass.includes('explosive')) return '255, 163, 94';
        if (attackClass.includes('siege')) return '255, 143, 121';
        if (attackClass.includes('marksman')) return '191, 235, 255';
        if (attackClass.includes('bow')) return '201, 229, 170';
        if (attackClass.includes('flying')) return '172, 203, 255';
        if (event.side === 'defender') return '102, 214, 255';
        if (event.side === 'attacker') return '255, 124, 124';
        return '182, 205, 255';
      })();
      if (kind === 'battlemat-enter') {
        const frame = 1 - progress;
        const sweepW = width * (0.12 + (0.36 * frame));
        const sweepX = (progress * 1.3 * width) - (width * 0.15);
        const sweep = ctx.createLinearGradient(sweepX - sweepW, 0, sweepX + sweepW, 0);
        sweep.addColorStop(0, 'rgba(164, 212, 255, 0)');
        sweep.addColorStop(0.5, `rgba(164, 212, 255, ${0.1 + (0.22 * frame)})`);
        sweep.addColorStop(1, 'rgba(164, 212, 255, 0)');
        ctx.fillStyle = sweep;
        ctx.fillRect(0, 0, width, height);
      } else if (kind === 'attack' || kind === 'attack-start' || kind === 'projectile-fire' || kind === 'projectile' || kind === 'turret-fire' || kind === 'anti-air-fire' || kind === 'anti-barrage') {
        const from = source ?? target;
        const to = target ?? source;
        if (from && to) {
          if (kind === 'attack-start') {
            const flare = Math.min(cellW, cellH) * (0.05 + (0.2 * progress));
            ctx.fillStyle = `rgba(${palette}, ${0.16 + (0.58 * fade)})`;
            ctx.beginPath();
            ctx.arc(from.x, from.y, flare, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = `rgba(${palette}, ${0.12 + (0.44 * fade)})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(from.x, from.y, flare * 1.7, 0, Math.PI * 2);
            ctx.stroke();
            return;
          }
          const tRaw = projectileKind === 'arrow' || projectileKind === 'mortar-shell' || projectileKind === 'turret-shell'
            ? clamp(progress * 0.94, 0, 1)
            : clamp(progress * 1.25, 0, 1);
          const drawImpactPulse = () => {
            ctx.strokeStyle = `rgba(${palette}, ${0.24 + (0.56 * fade)})`;
            ctx.lineWidth = 1.1;
            ctx.beginPath();
            ctx.arc(to.x, to.y, (Math.min(cellW, cellH) * 0.07) + (Math.min(cellW, cellH) * 0.19 * progress), 0, Math.PI * 2);
            ctx.stroke();
          };
          if (projectileKind === 'arrow') {
            const midX = (from.x + to.x) * 0.5;
            const midY = Math.min(from.y, to.y) - Math.max(10, Math.abs(to.x - from.x) * 0.08);
            const omt = 1 - tRaw;
            const px = (omt * omt * from.x) + (2 * omt * tRaw * midX) + (tRaw * tRaw * to.x);
            const py = (omt * omt * from.y) + (2 * omt * tRaw * midY) + (tRaw * tRaw * to.y);
            ctx.strokeStyle = `rgba(${palette}, ${0.28 + (0.62 * fade)})`;
            ctx.lineWidth = 1.4 + (0.8 * fade);
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.quadraticCurveTo(midX, midY, to.x, to.y);
            ctx.stroke();
            ctx.fillStyle = `rgba(${palette}, ${0.36 + (0.58 * fade)})`;
            ctx.beginPath();
            ctx.arc(px, py, 1.6 + (2.2 * fade), 0, Math.PI * 2);
            ctx.fill();
            drawImpactPulse();
          } else if (projectileKind === 'marksman-shot' || attackClass.includes('marksman')) {
            const px = from.x + ((to.x - from.x) * tRaw);
            const py = from.y + ((to.y - from.y) * tRaw);
            ctx.strokeStyle = `rgba(${palette}, ${0.22 + (0.76 * fade)})`;
            ctx.lineWidth = 1 + (1.4 * fade);
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.lineTo(to.x, to.y);
            ctx.stroke();
            ctx.fillStyle = `rgba(${palette}, ${0.44 + (0.48 * fade)})`;
            ctx.beginPath();
            ctx.arc(px, py, 1.1 + (2.8 * fade), 0, Math.PI * 2);
            ctx.fill();
            drawImpactPulse();
          } else if (projectileKind === 'flak-barrage' || kind === 'anti-barrage') {
            const bursts = 3;
            for (let b = 0; b < bursts; b += 1) {
              const offset = ((b - 1) * Math.max(6, cellW * 0.12));
              const fromY = from.y + offset;
              const toY = to.y + (offset * 0.4);
              const px = from.x + ((to.x - from.x) * tRaw);
              const py = fromY + ((toY - fromY) * tRaw);
              ctx.strokeStyle = `rgba(${palette}, ${0.14 + (0.5 * fade)})`;
              ctx.lineWidth = 1 + (1.4 * fade);
              ctx.beginPath();
              ctx.moveTo(from.x, fromY);
              ctx.lineTo(to.x, toY);
              ctx.stroke();
              ctx.fillStyle = `rgba(${palette}, ${0.26 + (0.58 * fade)})`;
              ctx.beginPath();
              ctx.arc(px, py, 1.3 + (1.8 * fade), 0, Math.PI * 2);
              ctx.fill();
            }
            drawImpactPulse();
          } else if (projectileKind === 'mortar-shell' || projectileKind === 'turret-shell') {
            const midX = (from.x + to.x) * 0.5;
            const midY = Math.min(from.y, to.y) - Math.max(14, Math.abs(to.x - from.x) * 0.13);
            const omt = 1 - tRaw;
            const px = (omt * omt * from.x) + (2 * omt * tRaw * midX) + (tRaw * tRaw * to.x);
            const py = (omt * omt * from.y) + (2 * omt * tRaw * midY) + (tRaw * tRaw * to.y);
            ctx.strokeStyle = `rgba(${palette}, ${0.2 + (0.56 * fade)})`;
            ctx.lineWidth = 2 + (1.6 * fade);
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.quadraticCurveTo(midX, midY, to.x, to.y);
            ctx.stroke();
            ctx.fillStyle = `rgba(${palette}, ${0.36 + (0.58 * fade)})`;
            ctx.beginPath();
            ctx.arc(px, py, 2 + (2.6 * fade), 0, Math.PI * 2);
            ctx.fill();
            drawImpactPulse();
          } else if (projectileKind === 'lunge' || projectileKind === 'heavy-lunge' || projectileKind === 'dive') {
            const px = from.x + ((to.x - from.x) * tRaw);
            const py = from.y + ((to.y - from.y) * tRaw);
            ctx.strokeStyle = `rgba(${palette}, ${0.26 + (0.62 * fade)})`;
            ctx.lineWidth = projectileKind === 'heavy-lunge' ? 3.6 : 2.4;
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.lineTo(px, py);
            ctx.stroke();
            drawImpactPulse();
          } else {
            const px = from.x + ((to.x - from.x) * tRaw);
            const py = from.y + ((to.y - from.y) * tRaw);
            ctx.strokeStyle = `rgba(${palette}, ${0.22 + (0.68 * fade)})`;
            ctx.lineWidth = 1.2 + (2.2 * fade);
            ctx.beginPath();
            ctx.moveTo(from.x, from.y);
            ctx.lineTo(to.x, to.y);
            ctx.stroke();
            ctx.fillStyle = `rgba(${palette}, ${0.24 + (0.68 * fade)})`;
            ctx.beginPath();
            ctx.arc(px, py, 1.4 + (4.2 * fade), 0, Math.PI * 2);
            ctx.fill();
            drawImpactPulse();
          }
        }
      } else if (kind === 'impact' || kind === 'explosive-impact' || kind === 'structure-break' || kind === 'barricade-break') {
        const anchor = target ?? source;
        if (!anchor) return;
        const ringBoost = kind === 'explosive-impact' || kind === 'barricade-break' || kind === 'structure-break' ? 1.35 : 1;
        const radius = (Math.min(cellW, cellH) * (0.12 + (0.24 * progress))) * ringBoost;
        ctx.strokeStyle = `rgba(${palette}, ${0.2 + (0.62 * fade)})`;
        ctx.lineWidth = 1.6 + (2.4 * fade);
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = `rgba(${palette}, ${0.08 + (0.22 * fade)})`;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, Math.max(2, radius * 0.42), 0, Math.PI * 2);
        ctx.fill();
        if (kind === 'barricade-break' || kind === 'structure-break') {
          const shards = kind === 'barricade-break' ? 6 : 9;
          for (let i = 0; i < shards; i += 1) {
            const angle = ((Math.PI * 2) / shards) * i;
            const spread = radius * (0.42 + (0.7 * progress));
            const sx = anchor.x + (Math.cos(angle) * spread);
            const sy = anchor.y + (Math.sin(angle) * spread);
            ctx.strokeStyle = `rgba(${palette}, ${0.16 + (0.52 * fade)})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(anchor.x, anchor.y);
            ctx.lineTo(sx, sy);
            ctx.stroke();
          }
        }
      } else if (kind === 'summon' || kind === 'upgrade' || kind === 'equip' || kind === 'deconstruct' || kind === 'tactic' || kind === 'ability-trigger') {
        const anchor = target ?? source ?? (kind === 'ability-trigger' ? { x: width * 0.5, y: Math.max(28, height * 0.14) } : null);
        if (!anchor) return;
        let color = event.side === 'defender' ? '111, 231, 164' : '255, 142, 142';
        if (kind === 'upgrade') color = '183, 133, 255';
        if (kind === 'equip') color = '255, 209, 116';
        if (kind === 'deconstruct') color = '255, 169, 120';
        if (kind === 'tactic') color = '133, 192, 255';
        if (kind === 'ability-trigger') color = '154, 202, 255';
        const radiusBase = Math.min(cellW, cellH) * (kind === 'summon' && event.large ? 0.22 : 0.16);
        const radius = radiusBase + (Math.min(cellW, cellH) * 0.22 * progress);
        ctx.strokeStyle = `rgba(${color}, ${0.18 + (0.62 * fade)})`;
        ctx.lineWidth = 1.4 + (1.8 * fade);
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = `rgba(${color}, ${0.12 + (0.24 * fade)})`;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, Math.max(2, radius * 0.42), 0, Math.PI * 2);
        ctx.fill();
        if (kind === 'upgrade') {
          ctx.fillStyle = `rgba(${color}, ${0.26 + (0.6 * fade)})`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.font = `700 ${Math.max(12, Math.round(14 + (4 * fade)))}px "Segoe UI", Arial, sans-serif`;
          ctx.fillText('^', anchor.x, anchor.y - (radius * 0.35));
        } else if (kind === 'equip') {
          ctx.fillStyle = `rgba(${color}, ${0.24 + (0.56 * fade)})`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.font = `700 ${Math.max(10, Math.round(12 + (3 * fade)))}px "Segoe UI", Arial, sans-serif`;
          ctx.fillText('EQ', anchor.x, anchor.y - (radius * 0.24));
        } else if (kind === 'summon') {
          for (let p = 0; p < 4; p += 1) {
            const ang = (Math.PI * 0.5 * p) + (progress * 1.4);
            const puff = Math.max(2, radius * (0.22 + (0.16 * p)));
            ctx.fillStyle = `rgba(${color}, ${0.09 + (0.18 * fade)})`;
            ctx.beginPath();
            ctx.arc(anchor.x + (Math.cos(ang) * radius * 0.45), anchor.y + (Math.sin(ang) * radius * 0.45), puff, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      } else if (kind === 'move') {
        const from = source;
        const to = target;
        if (!from || !to) return;
        ctx.strokeStyle = `rgba(${event.side === 'defender' ? '122, 220, 255' : '255, 156, 156'}, ${0.18 + (0.52 * fade)})`;
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x, to.y);
        ctx.stroke();
        ctx.setLineDash([]);
      } else if (kind === 'capture') {
        const anchor = target ?? source;
        if (!anchor) return;
        const color = event.side === 'defender' ? '95, 215, 255' : '255, 138, 138';
        const radius = Math.min(cellW, cellH) * (0.18 + (0.22 * progress));
        ctx.strokeStyle = `rgba(${color}, ${0.2 + (0.56 * fade)})`;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = `rgba(${color}, ${0.08 + (0.22 * fade)})`;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, radius * 0.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (kind === 'heal' || kind === 'repair' || kind === 'shield-gain') {
        const anchor = target ?? source;
        if (!anchor) return;
        const amount = Math.max(0, Number(event.amount ?? 0));
        const color = kind === 'shield-gain' ? '126, 189, 255' : (kind === 'repair' ? '112, 221, 196' : '114, 236, 154');
        const rise = (Math.min(cellW, cellH) * 0.2) + (progress * 24);
        const x = anchor.x;
        const y = anchor.y - rise;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `700 ${Math.max(11, Math.round(12 + (3 * fade)))}px "Segoe UI", Arial, sans-serif`;
        const label = `${kind === 'shield-gain' ? 'S+' : '+'}${amount > 0 ? amount : ''}`;
        ctx.strokeStyle = `rgba(7, 16, 28, ${0.34 + (0.46 * fade)})`;
        ctx.lineWidth = 2.8;
        ctx.strokeText(label, x, y);
        ctx.fillStyle = `rgba(${color}, ${0.26 + (0.72 * fade)})`;
        ctx.fillText(label, x, y);
        const pulse = Math.min(cellW, cellH) * (0.08 + (0.18 * progress));
        ctx.strokeStyle = `rgba(${color}, ${0.14 + (0.44 * fade)})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, pulse, 0, Math.PI * 2);
        ctx.stroke();
      } else if (kind === 'kill' || kind === 'death') {
        const anchor = target ?? source;
        if (!anchor) return;
        const cross = Math.min(cellW, cellH) * (0.12 + (0.2 * progress));
        const color = kind === 'death' ? '246, 166, 166' : '255, 134, 134';
        ctx.strokeStyle = `rgba(${color}, ${0.18 + (0.74 * fade)})`;
        ctx.lineWidth = 1.6 + (1.8 * fade);
        ctx.beginPath();
        ctx.moveTo(anchor.x - cross, anchor.y - cross);
        ctx.lineTo(anchor.x + cross, anchor.y + cross);
        ctx.moveTo(anchor.x + cross, anchor.y - cross);
        ctx.lineTo(anchor.x - cross, anchor.y + cross);
        ctx.stroke();
        ctx.fillStyle = `rgba(${color}, ${0.08 + (0.22 * fade)})`;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, cross * 0.6, 0, Math.PI * 2);
        ctx.fill();
      } else if (kind === 'damage') {
        const anchor = target ?? source;
        if (!anchor) return;
        const amount = Math.max(0, Number(event.amount ?? 0));
        const lethal = !!event.lethal;
        const heavy = !!event.heavy || amount >= 6 || attackClass.includes('explosive') || attackClass.includes('siege');
        let color = '255, 142, 142';
        if (attackClass.includes('explosive') || kind === 'explosive-impact') color = '255, 176, 106';
        if (attackClass.includes('turret')) color = '255, 214, 128';
        if (attackClass.includes('marksman')) color = '213, 236, 255';
        const rise = (Math.min(cellW, cellH) * 0.26) + (progress * 32);
        const x = anchor.x;
        const y = anchor.y - rise;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `700 ${Math.max(11, Math.round((heavy ? 14 : 12) + (4 * fade)))}px "Segoe UI", Arial, sans-serif`;
        const label = `-${amount}${lethal ? '!' : ''}`;
        ctx.strokeStyle = `rgba(5, 10, 22, ${0.35 + (0.5 * fade)})`;
        ctx.lineWidth = 3.2;
        ctx.strokeText(label, x, y);
        ctx.fillStyle = `rgba(${color}, ${0.28 + (0.72 * fade)})`;
        ctx.fillText(label, x, y);
        ctx.strokeStyle = `rgba(${color}, ${0.14 + (0.42 * fade)})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(anchor.x, anchor.y, (Math.min(cellW, cellH) * 0.06) + (Math.min(cellW, cellH) * 0.14 * progress), 0, Math.PI * 2);
        ctx.stroke();
      } else if (kind === 'resource') {
        const barX = width * 0.16;
        const barY = height * 0.12;
        const amountW = Math.max(0, Number(event.amountWheat ?? 0));
        const amountI = Math.max(0, Number(event.amountIron ?? 0));
        const amountM = Math.max(0, Number(event.amountMana ?? 0));
        const amountText = amountM > 0
          ? `+M${amountM}`
          : `+W${amountW} / +I${amountI}`;
        ctx.fillStyle = `rgba(170, 216, 255, ${0.06 + (0.24 * fade)})`;
        ctx.fillRect(barX - 34, barY - 20 - (progress * 10), 140, 24);
        ctx.fillStyle = `rgba(212, 232, 255, ${0.22 + (0.7 * fade)})`;
        ctx.font = '11px Arial';
        ctx.fillText(amountText, barX - 30, barY - (progress * 10));
      } else if (kind === 'draw') {
        const barX = width * 0.16;
        const barY = height * 0.2;
        const deckLabel = String(event.deckKey ?? 'deck').toUpperCase();
        const text = `${deckLabel} draw`;
        ctx.fillStyle = `rgba(133, 187, 255, ${0.08 + (0.22 * fade)})`;
        ctx.fillRect(barX - 34, barY - 20 - (progress * 10), 114, 22);
        ctx.fillStyle = `rgba(214, 234, 255, ${0.22 + (0.68 * fade)})`;
        ctx.font = '11px Arial';
        ctx.fillText(text, barX - 30, barY - (progress * 10));
      }
    });
    effectState.events = activeEvents;
    ctx.restore();
    facilityWarEffectsHandle = requestAnimationFrame(draw);
  };
  draw();
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  if (modalId === 'facility-war-modal') {
    document.body.classList.add('facility-war-active');
    suspendMapRuntime('facility-war');
  }
  dom.modalBackdrop.classList.remove('hidden');
  modal.classList.remove('hidden');
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('hidden');
  if (modalId === 'facility-war-modal') {
    stopFacilityWarEffects();
    document.body.classList.remove('facility-war-active');
    document.body.classList.remove('facility-drag-attacking');
    modalUiState.facilityWar.hoverHandCardId = null;
    modalUiState.facilityWar.dragAttackSourceIndex = null;
    resumeMapRuntime();
  }
  const anyOpen = [
    dom.gatewayModal,
    dom.galaxyCreatorModal,
    dom.aiEditorModal,
    dom.threatInspectModal,
    dom.conquestModal,
    dom.worldManagementModal,
    dom.facilityWarModal,
    dom.conquestMatSettingsModal,
    dom.conquestDeckEditorModal,
    dom.conquestCardCreatorModal,
  ].some((entry) => entry && !entry.classList.contains('hidden'));
  if (!anyOpen) dom.modalBackdrop.classList.add('hidden');
}

function findCampaignWorldByNode(profile, nodeId) {
  const campaign = getMapWorld(profile).campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  return campaign.worldStates?.[nodeId] ?? null;
}

function findCampaignWorld(profile, worldId) {
  const campaign = getMapWorld(profile).campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  return campaign.worldStates?.[worldId] ?? null;
}

function threatChipMarkup(chips = [], className = '') {
  const list = toArray(chips)
    .map((entry) => String(entry ?? '').trim())
    .filter(Boolean)
    .slice(0, 8);
  if (!list.length) return '<span class="threat-chip empty">none</span>';
  return list.map((chip) => {
    const chipClass = slugifyId(chip) || 'tag';
    const extra = className ? ` ${className}` : '';
    return `<span class="threat-chip${extra} tag-${chipClass}">${chip}</span>`;
  }).join('');
}

function openPirateInspectModal(pirate, pirateHouse, node, profiles) {
  if (!pirate || !dom.threatInspectBody) return;
  const resolvedNode = node ?? mapNodeById(pirate.currentNodeId ?? pirate.targetNodeId ?? '');
  const activity = pirateActivityState(pirate, getDimensionalAttackers(getMapWorld(loadProfile())));
  const dangerTier = pirateDangerTier(pirate);
  const role = String(pirate.role ?? 'raider');
  const objective = String(pirate.objective ?? 'patrol');
  const houseName = pirateHouse?.name ?? pirate.houseName ?? 'Independent House';
  const routeLabel = resolvedNode
    ? `${resolvedNode.name} (${resolvedNode.universe ?? 'Unknown'})`
    : 'Unknown route';
  modalUiState.threat = { threatId: pirate.id, nodeId: resolvedNode?.id ?? null, type: 'pirate' };
  if (dom.threatInspectBattleBtn) dom.threatInspectBattleBtn.textContent = `Intercept ${pirate.name}`;
  if (dom.threatInspectCenterBtn) dom.threatInspectCenterBtn.textContent = 'Center Fleet';
  dom.threatInspectBody.innerHTML = `
    <div class="threat-row"><strong>Name</strong><br/>${pirate.name}</div>
    <div class="threat-row"><strong>Type</strong><br/>PIRATE FLEET</div>
    <div class="threat-row"><strong>House</strong><br/>${houseName}</div>
    <div class="threat-row"><strong>Danger</strong><br/><span class="threat-tier tier-${dangerTier}">${dangerTier.toUpperCase()}</span></div>
    <div class="threat-row"><strong>Activity</strong><br/>${activity}</div>
    <div class="threat-row"><strong>Objective</strong><br/>${objective}</div>
    <div class="threat-row"><strong>Role</strong><br/>${role}</div>
    <div class="threat-row"><strong>Level</strong><br/>${Math.max(1, Math.round(toFiniteNumber(pirate.level, 1)))}</div>
    <div class="threat-row"><strong>Threat Rating</strong><br/>${Math.max(1, Math.round(toFiniteNumber(pirate.threat, 1)))}</div>
    <div class="threat-row"><strong>Current Route</strong><br/>${routeLabel}</div>
    <div class="threat-row"><strong>Escape Countdown</strong><br/>${Math.max(0, Math.round(toFiniteNumber(pirate.escapeCountdown, 0)))} ticks</div>
    <div class="threat-row"><strong>Traits</strong><br/>${threatChipMarkup([role, objective, activity, dangerTier])}</div>
  `;
  dom.threatInspectCenterBtn.onclick = () => {
    if (resolvedNode?.id) centerMapOnNode(resolvedNode.id);
    closeModal('threat-inspect-modal');
  };
  dom.threatInspectBattleBtn.onclick = () => {
    const result = beginPirateIntercept(profiles, pirate.id);
    if (!result.ok && dom.invasionThreatSummary) dom.invasionThreatSummary.textContent = result.message;
  };
  openModal('threat-inspect-modal');
}

function openThreatInspectModal(threat, node, profiles) {
  if (!threat || !dom.threatInspectBody) return;
  const resolvedNode = node ?? mapNodeById(threat.currentNodeId ?? threat.targetNodeId ?? threat.nodeId) ?? {
    id: String(threat.targetNodeId ?? threat.currentNodeId ?? threat.nodeId ?? `threat-${threat.id}`),
    name: String(threat.region ?? threat.factionName ?? 'Unknown Region'),
    universe: String(threat.region ?? 'Unknown'),
    styleId: 'astral-cartographer',
  };
  const centerNode = mapNodeById(resolvedNode.id);
  modalUiState.threat = { threatId: threat.id, nodeId: resolvedNode.id };
  const commanderLabel = threatCommanderLabel(threat);
  const rankLabel = threatRankDisplay(threat.commanderRank ?? 'standard');
  const mechanics = toArray(threat.signatureMechanics);
  const cards = toArray(threat.signatureCards);
  const objectiveText = threat.objective ?? 'advance';
  const tri = clamp(Math.round(toFiniteNumber(threat.deckTriangles, toFiniteNumber(threat.deckSizeEstimate, 30) / 10)), 1, 6);
  const doctrine = conquestDoctrineLabelForThreat(threat.factionId, threat.aiSkillStars);
  const variant = threat.deckVariant ?? conquestDeckVariantForStars(threat.aiSkillStars);
  const deckSeries = threat.deckSeries ?? conquestDeckSeriesName(threat.factionId, tri, variant);
  const dangerTier = invasionThreatDangerTier(threat);
  const urgency = Math.round(invasionThreatUrgencyScore(threat));
  const chips = invasionThreatDeckChips(threat);
  const pattern = String(threat.attackPattern ?? threat.behaviorNotes ?? 'Unknown attack pattern');
  const strengths = toArray(threat.strengths);
  const weaknesses = toArray(threat.weaknesses);
  const roster = toArray(threat.unitRoster);
  const worldState = findCampaignWorldByNode(loadProfile(), resolvedNode.id);
  const targetPlanet = chooseInvasionPlanetForWorld(worldState, threat.targetPlanetId);
  if (dom.threatInspectBattleBtn) dom.threatInspectBattleBtn.textContent = 'Launch Defense Battle';
  if (dom.threatInspectCenterBtn) dom.threatInspectCenterBtn.textContent = 'Center Threat';
  dom.threatInspectBody.innerHTML = `
    <div class="threat-row"><strong>Name</strong><br/>${threat.factionName ?? 'Unknown Threat'}</div>
    <div class="threat-row"><strong>Type</strong><br/>${String(threat.threatType ?? 'threat').toUpperCase()}</div>
    <div class="threat-row"><strong>Danger Tier</strong><br/><span class="threat-tier tier-${dangerTier}">${dangerTier.toUpperCase()}</span></div>
    <div class="threat-row"><strong>Urgency Score</strong><br/>${urgency}</div>
    <div class="threat-row"><strong>Region</strong><br/>${resolvedNode.name}</div>
    <div class="threat-row"><strong>Target Planet</strong><br/>${targetPlanet?.name ?? threat.targetPlanetId ?? 'Unknown'}</div>
    <div class="threat-row"><strong>Deck Force</strong><br/>${threat.deckSizeEstimate ?? ((threat.deckTriangles ?? 0) * 10)} cards</div>
    <div class="threat-row"><strong>Triangles</strong><br/>${tri}</div>
    <div class="threat-row"><strong>Deck Series</strong><br/>${deckSeries}</div>
    <div class="threat-row"><strong>Deck Variant</strong><br/>${variant}</div>
    <div class="threat-row"><strong>Attacker Doctrine</strong><br/>${doctrine}</div>
    <div class="threat-row"><strong>AI Skill</strong><br/>${'★'.repeat(clamp(Number(threat.aiSkillStars ?? 1), 1, 5))}</div>
    <div class="threat-row"><strong>Tech Level</strong><br/>${Math.max(1, Number(threat.techLevel ?? 1))}</div>
    <div class="threat-row"><strong>Threat Style</strong><br/>${threat.threatStyle ?? 'standard'}</div>
    <div class="threat-row"><strong>Objective</strong><br/>${objectiveText}</div>
    <div class="threat-row"><strong>Traits</strong><br/>${threatChipMarkup(toArray(threat.specialTraits))}</div>
    <div class="threat-row"><strong>Deck Style Chips</strong><br/>${threatChipMarkup(chips, 'is-style')}</div>
    <div class="threat-row"><strong>Command Rank</strong><br/>${rankLabel}</div>
    <div class="threat-row"><strong>Commander</strong><br/>${commanderLabel ?? 'Field cell (unnamed)'}</div>
    <div class="threat-row"><strong>Commander Style</strong><br/>${threat.commanderPlaystyle ?? 'Adaptive invasion doctrine.'}</div>
    <div class="threat-row"><strong>Commander Personality</strong><br/>${threat.commanderPersonality ?? 'Unknown'}</div>
    <div class="threat-row"><strong>Signature Mechanics</strong><br/>${mechanics.length ? mechanics.join(', ') : 'none registered'}</div>
    <div class="threat-row"><strong>Signature Cards</strong><br/>${cards.length ? cards.join(', ') : 'none registered'}</div>
    <div class="threat-row"><strong>Attack Pattern</strong><br/>${pattern}</div>
    <div class="threat-row"><strong>Strengths</strong><br/>${strengths.length ? strengths.join(' • ') : 'No special strengths listed.'}</div>
    <div class="threat-row"><strong>Weaknesses</strong><br/>${weaknesses.length ? weaknesses.join(' • ') : 'No special weaknesses listed.'}</div>
    <div class="threat-row"><strong>Unit Roster</strong><br/>${roster.length ? roster.map((entry) => {
      const name = String(entry?.name ?? 'Unknown unit');
      const role = String(entry?.role ?? 'combat role');
      const tags = toArray(entry?.tags).join('/');
      return `${name} (${role}${tags ? ` • ${tags}` : ''})`;
    }).slice(0, 6).join('<br/>') : 'No roster metadata registered.'}</div>
    <div class="threat-row"><strong>Intro Line</strong><br/>${threat.commanderDialogue?.intro ?? `${threat.factionName} incursion force entering combat range.`}</div>
    <div class="threat-row"><strong>Risk</strong><br/>${threat.aiSkillStars >= 4 ? 'High' : 'Moderate'}</div>
    <div class="threat-row"><strong>Reward</strong><br/>Gold ${80 + Math.floor((threat.deckSizeEstimate ?? 20) * 0.7)}</div>
  `;
  dom.threatInspectCenterBtn.onclick = () => {
    if (centerNode?.id) centerMapOnNode(centerNode.id);
    closeModal('threat-inspect-modal');
  };
  dom.threatInspectBattleBtn.onclick = () => {
    launchAlienThreatBattle(threat, resolvedNode);
  };
  openModal('threat-inspect-modal');
}

function objectiveByIds(world, planetId, objectiveId) {
  const planet = (world?.planets ?? []).find((entry) => entry.id === planetId) ?? null;
  const objective = (planet?.objectives ?? []).find((entry) => entry.id === objectiveId) ?? null;
  return { planet, objective };
}

function renderConquestModal(profile, profiles) {
  const worldId = modalUiState.conquest.worldId;
  if (!worldId || !dom.conquestWorldMeta) return;
  const world = findCampaignWorld(profile, worldId);
  if (!world) {
    dom.conquestWorldMeta.textContent = 'World state unavailable.';
    return;
  }
  const completed = Number(world.conquest?.completedObjectives ?? 0);
  const total = Number(world.conquest?.totalObjectives ?? 0);
  const meter = Number(world.conquest?.meter ?? 0);
  dom.conquestWorldMeta.textContent = `${world.worldName} • ${world.universe} • Tech ${world.techLevel} • Favor ${Math.round(world.favor)} • ${world.secured ? 'Secured' : 'Contested'} • ${world.duelDefeated ? 'Guardian Defeated' : 'Guardian Active'}`;
  dom.conquestMeterFill.style.width = `${meter.toFixed(1)}%`;
  dom.conquestMeterText.textContent = `${completed}/${total} strongholds seized • ${meter.toFixed(0)}%`;
  const planets = Array.isArray(world.planets) ? world.planets : [];
  planets.forEach((planet) => ensurePlanetConquestState(world, planet));
  if (!modalUiState.conquest.planetId || !planets.some((planet) => planet.id === modalUiState.conquest.planetId)) {
    modalUiState.conquest.planetId = planets[0]?.id ?? null;
    modalUiState.conquest.objectiveId = null;
  }
  dom.conquestPlanetList.innerHTML = '';
  planets.forEach((planet) => {
    const completion = objectiveCompletion(planet);
    const button = document.createElement('button');
    button.className = `conquest-item ${planet.id === modalUiState.conquest.planetId ? 'active' : ''}`;
    button.textContent = `${planet.name} • ${completion.done}/${completion.total} strongholds • ${planet.sizeClass ?? 'medium'} • ${planet.biome}`;
    button.onclick = () => {
      modalUiState.conquest.planetId = planet.id;
      modalUiState.conquest.objectiveId = null;
      renderConquestModal(loadProfile(), profiles);
    };
    dom.conquestPlanetList.appendChild(button);
  });
  const activePlanet = planets.find((planet) => planet.id === modalUiState.conquest.planetId) ?? null;
  const objectives = Array.isArray(activePlanet?.objectives) ? activePlanet.objectives : [];
  if (!modalUiState.conquest.objectiveId || !objectives.some((objective) => objective.id === modalUiState.conquest.objectiveId)) {
    modalUiState.conquest.objectiveId = objectives.find((entry) => entry.status !== 'completed')?.id ?? objectives[0]?.id ?? null;
  }
  dom.conquestObjectiveList.innerHTML = '';
  objectives.forEach((objective) => {
    const button = document.createElement('button');
    button.className = `conquest-item ${objective.id === modalUiState.conquest.objectiveId ? 'active' : ''}`;
    button.innerHTML = `<strong>${objective.title}</strong><div>${objective.regionName} • ${objective.deckSizeEstimate} cards • ${'★'.repeat(clamp(Number(objective.aiSkillStars ?? 1), 1, 5))}</div><div>Status: ${objective.status}</div>`;
    button.onclick = () => {
      modalUiState.conquest.objectiveId = objective.id;
      renderConquestModal(loadProfile(), profiles);
    };
    button.oncontextmenu = (event) => {
      event.preventDefault();
      modalUiState.conquest.objectiveId = objective.id;
      renderConquestModal(loadProfile(), profiles);
    };
    dom.conquestObjectiveList.appendChild(button);
  });
  const activeObjective = objectives.find((entry) => entry.id === modalUiState.conquest.objectiveId) ?? null;
  if (!activeObjective) {
    dom.conquestObjectiveDetail.innerHTML = '<div>No objectives available.</div>';
    dom.conquestBattleBtn.disabled = true;
    return;
  }
  dom.conquestObjectiveDetail.innerHTML = `
    <div><strong>${activeObjective.title}</strong></div>
    <div><strong>Region:</strong> ${activeObjective.regionName}</div>
    <div><strong>Planet Strongholds:</strong> ${activePlanet?.strongholdsCaptured ?? 0}/${activePlanet?.strongholdsRequired ?? objectiveCompletion(activePlanet).total}</div>
    <div><strong>Faction:</strong> ${world.factionId}</div>
    <div><strong>Strategic Effect:</strong> ${activeObjective.strategicEffect}</div>
    <div><strong>Threat:</strong> ${activeObjective.deckSizeEstimate} cards • ${'★'.repeat(clamp(Number(activeObjective.aiSkillStars ?? 1), 1, 5))} • Tech ${activeObjective.techLevel}</div>
          <div><strong>Attacker Deck:</strong> ${activeObjective.deckTriangles ?? conquestTrianglesFromDeckSize(activeObjective.deckSizeEstimate)}△ • ${activeObjective.deckSeries ?? conquestDeckSeriesName(world.factionId, activeObjective.deckTriangles ?? conquestTrianglesFromDeckSize(activeObjective.deckSizeEstimate), activeObjective.deckVariant ?? conquestDeckVariantForStars(activeObjective.aiSkillStars))} • ${activeObjective.deckDoctrine ?? conquestDoctrineLabelForThreat(world.factionId, activeObjective.aiSkillStars)}</div>
    <div><strong>Rewards:</strong> Gold ${activeObjective.rewards?.gold ?? 0}, Production +${activeObjective.rewards?.production ?? 0}</div>
    <div><strong>Status:</strong> ${activeObjective.status}</div>
    <div><strong>Lore:</strong> ${activeObjective.lore ?? 'No additional records.'}</div>
  `;
  dom.conquestBattleBtn.disabled = activeObjective.status === 'completed';
  dom.conquestBattleBtn.onclick = () => {
    const objectiveAiLevel = clamp((Number(activeObjective.aiSkillStars ?? 1) * 5) + Number(activeObjective.techLevel ?? 1), 3, 55);
    const objectiveAi = {
      id: `obj-ai-${activeObjective.id}`,
      name: `${world.worldName} Garrison`,
      level: objectiveAiLevel,
      archetype: `conquest-${world.factionId}`,
      personality: {
        title: `${world.worldName} Objective Commander`,
        dimensionTag: `#${world.universe}`,
        backstory: `Defends objective ${activeObjective.title}.`,
        loadingFlavor: activeObjective.lore ?? `${activeObjective.title} is under heavy resistance.`,
      },
      deckIdentity: `${activeObjective.deckSizeEstimate}-card defense force`,
      styleId: mapNodeById(world.nodeId)?.styleId ?? 'astral-cartographer',
      faction: world.factionId,
      assignedPacks: [world.factionId],
      deck: buildAlienPlaceholderDeck({
        id: `objective-${activeObjective.id}`,
        factionId: world.factionId,
        factionName: world.factionId,
        deckSizeEstimate: activeObjective.deckSizeEstimate,
        aiSkillStars: activeObjective.aiSkillStars,
        techLevel: activeObjective.techLevel,
      }, activePlanet?.name ?? world.worldName),
    };
    startCinematic('Novice', objectiveAi, {
      rulesetId: activeObjective.deckSizeEstimate >= 60 ? 'massive-invasion' : 'planetary-defense',
      battleType: 'defense_conquest',
      routeTarget: 'facility_war',
      forceReset: true,
      worldId: world.worldId,
      planetId: activePlanet?.id ?? null,
      targetPlanetId: activePlanet?.id ?? null,
      objectiveId: activeObjective.id,
      sourceNodeId: world.nodeId,
      deckSize: activeObjective.deckSizeEstimate,
      threatDeckSize: activeObjective.deckSizeEstimate,
      deckTriangles: clamp(Math.round(toFiniteNumber(activeObjective.deckTriangles, activeObjective.deckSizeEstimate / 10)), 1, 6),
      aiSkillStars: activeObjective.aiSkillStars,
      techLevel: activeObjective.techLevel,
      metadata: {
        conquest: true,
        threatType: 'objective',
        objectiveTitle: activeObjective.title,
        factionId: world.factionId,
      },
    });
  };
  dom.conquestWorldOpsBtn.onclick = () => {
    modalUiState.worldOps.worldId = world.worldId;
    modalUiState.worldOps.planetId = activePlanet?.id ?? null;
    openWorldOpsModal(loadProfile());
  };
  if (dom.conquestFacilityBtn) {
    const canOpenFacility = !!activePlanet && (activePlanet.ownership === 'owned' || objectiveCompletion(activePlanet).done >= objectiveCompletion(activePlanet).total);
    dom.conquestFacilityBtn.disabled = !canOpenFacility;
    dom.conquestFacilityBtn.onclick = () => {
      if (!activePlanet) return;
      openFacilityWarModal(world.worldId, activePlanet.id);
    };
    if (
      canOpenFacility
      && activePlanet?.facilityWar?.phase === 'battle-ready'
      && !activePlanet?.facilityWar?.autoOpenedAt
    ) {
      activePlanet.facilityWar.autoOpenedAt = Date.now();
      const profileNow = loadProfile();
      const mapWorldNow = getMapWorld(profileNow);
      const campaignNow = mapWorldNow.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
      if (campaignNow.worldStates?.[world.worldId]) {
        campaignNow.worldStates[world.worldId].planets = (campaignNow.worldStates[world.worldId].planets ?? []).map((entry) => (entry.id === activePlanet.id ? activePlanet : entry));
        mapWorldNow.campaign = campaignNow;
        profileNow.mapWorld = mapWorldNow;
        saveProfile(profileNow);
      }
      setTimeout(() => openFacilityWarModal(world.worldId, activePlanet.id), 80);
    }
  }
  if (dom.conquestDeckEditorBtn) {
    dom.conquestDeckEditorBtn.onclick = () => {
      if (!activePlanet) return;
      openConquestDeckEditorModal(world.worldId, activePlanet.id);
    };
  }
  if (dom.conquestCardCreatorBtn) {
    dom.conquestCardCreatorBtn.onclick = () => {
      openConquestCardCreatorModal();
    };
  }
}

function openConquestModal(nodeId, profiles, selectedPlanetId = null) {
  const profile = loadProfile();
  const world = findCampaignWorldByNode(profile, nodeId);
  if (!world) return;
  if (!world.duelDefeated) {
    if (dom.worldOpsFeedback) dom.worldOpsFeedback.textContent = 'Defeat the guardian wielder first to unlock planetary conquest.';
    return;
  }
  const preferredPlanetId = selectedPlanetId
    ?? chooseInvasionPlanetForWorld(world)?.id
    ?? null;
  const selectedPlanet = (world.planets ?? []).find((planet) => planet.id === preferredPlanetId)
    ?? chooseInvasionPlanetForWorld(world)
    ?? null;
  if (selectedPlanet) ensurePlanetConquestState(world, selectedPlanet);
  saveProfile(profile);
  modalUiState.conquest.worldId = world.worldId;
  modalUiState.conquest.planetId = selectedPlanet?.id ?? null;
  modalUiState.conquest.objectiveId = null;
  renderConquestModal(profile, profiles);
  openModal('conquest-modal');
}

function renderWorldOpsModal(profile) {
  const worldId = modalUiState.worldOps.worldId;
  if (!worldId || !dom.worldOpsHeader) return;
  const world = findCampaignWorld(profile, worldId);
  if (!world) {
    dom.worldOpsHeader.textContent = 'World not found.';
    return;
  }
  dom.worldOpsHeader.textContent = `${world.worldName} • Favor ${Math.round(world.favor)} • Income +${Number(world.economy?.income ?? 0)} • Production +${Number(world.economy?.production ?? 0)} • Defense +${Number(world.economy?.defenseBonus ?? 0)}`;
  const planets = Array.isArray(world.planets) ? world.planets : [];
  if (!modalUiState.worldOps.planetId || !planets.some((planet) => planet.id === modalUiState.worldOps.planetId)) {
    modalUiState.worldOps.planetId = chooseInvasionPlanetForWorld(world)?.id ?? null;
  }
  dom.worldOpsPlanetSelect.innerHTML = '';
  planets.forEach((planet) => {
    const option = document.createElement('option');
    option.value = planet.id;
    option.textContent = `${planet.name} • Favor ${Math.round(planet.favor ?? world.favor ?? 50)} • Buildings ${(planet.buildings ?? []).length}/${planet.buildingCapacity ?? 8}`;
    if (planet.id === modalUiState.worldOps.planetId) option.selected = true;
    dom.worldOpsPlanetSelect.appendChild(option);
  });
  const planet = planets.find((entry) => entry.id === modalUiState.worldOps.planetId) ?? null;
  if (planet) ensurePlanetConquestState(world, planet);
  const completion = objectiveCompletion(planet);
  dom.worldOpsPlanetMeta.innerHTML = planet
    ? `<div><strong>Biome:</strong> ${planet.biome}</div><div><strong>Danger:</strong> ${planet.danger}</div><div><strong>Size:</strong> ${planet.sizeClass ?? 'medium'}</div><div><strong>Strongholds:</strong> ${planet.strongholdsCaptured ?? completion.done}/${planet.strongholdsRequired ?? completion.total}</div><div><strong>Income:</strong> +${planet.income ?? 0}</div><div><strong>Production:</strong> +${planet.production ?? 0}</div><div><strong>Ownership:</strong> ${planet.ownership}</div>`
    : '<div>Select a planet.</div>';
  dom.worldOpsBuildings.innerHTML = '';
  Object.values(BUILDING_LIBRARY).forEach((meta) => {
    const row = document.createElement('button');
    row.className = `world-build-item ${modalUiState.worldOps.selectedBuildingId === meta.id ? 'selected' : ''}`;
    row.innerHTML = `<span><strong>${meta.name}</strong><br/><small>Cost ${meta.costGold}g • Income +${meta.income} • Prod +${meta.production} • Def +${meta.defense} • Favor ${meta.favor >= 0 ? '+' : ''}${meta.favor}</small></span><span>${modalUiState.worldOps.selectedBuildingId === meta.id ? 'Selected' : 'Select'}</span>`;
    row.onclick = () => {
      modalUiState.worldOps.selectedBuildingId = meta.id;
      renderWorldOpsModal(loadProfile());
    };
    dom.worldOpsBuildings.appendChild(row);
  });
  const pool = cardFactoryPool(profile, world).slice(0, 36);
  if (!modalUiState.worldOps.selectedProduceCardId || !pool.some((card) => card.id === modalUiState.worldOps.selectedProduceCardId)) {
    modalUiState.worldOps.selectedProduceCardId = pool[0]?.id ?? null;
  }
  dom.worldOpsProduceCards.innerHTML = '';
  pool.forEach((card) => {
    const cost = Math.max(25, (Number(card.cost ?? 1) * 16) + (String(card.rarity ?? 'common') === 'legendary' ? 42 : String(card.rarity ?? 'common') === 'epic' ? 24 : 0));
    const availability = card.availability ?? cardAvailabilityForWorld(profile, world, card, { forProduction: true });
    const canPick = !!availability.available;
    const selected = modalUiState.worldOps.selectedProduceCardId === card.id;
    const row = document.createElement('button');
    row.className = `world-produce-row ${selected ? 'selected' : ''} ${canPick ? '' : 'disabled'}`;
    row.disabled = !canPick;
    const reason = canPick ? '' : `<br/><small class="warning">${availability.reason || 'Unavailable'}</small>`;
    row.innerHTML = `<span><strong>${card.name}</strong><br/><small>${card.rarity ?? 'common'} • Cost ${card.cost ?? 0} mana • Build ${cost}g</small>${reason}</span><span>${selected ? 'Selected' : canPick ? 'Pick' : 'Locked'}</span>`;
    row.onclick = () => {
      if (!canPick) return;
      modalUiState.worldOps.selectedProduceCardId = card.id;
      renderWorldOpsModal(loadProfile());
    };
    dom.worldOpsProduceCards.appendChild(row);
  });
  dom.worldOpsPlanetSelect.onchange = () => {
    modalUiState.worldOps.planetId = dom.worldOpsPlanetSelect.value;
    renderWorldOpsModal(loadProfile());
  };
  if (dom.worldOpsFacilityBtn) {
    dom.worldOpsFacilityBtn.disabled = !planet;
    dom.worldOpsFacilityBtn.onclick = () => {
      if (!planet) return;
      openFacilityWarModal(world.worldId, planet.id);
    };
  }
  if (dom.worldOpsDeckEditorBtn) {
    dom.worldOpsDeckEditorBtn.disabled = !planet;
    dom.worldOpsDeckEditorBtn.onclick = () => {
      if (!planet) return;
      openConquestDeckEditorModal(world.worldId, planet.id);
    };
  }
  if (dom.worldOpsCardCreatorBtn) {
    dom.worldOpsCardCreatorBtn.onclick = () => openConquestCardCreatorModal();
  }
}

function openWorldOpsModal(profile = loadProfile()) {
  renderWorldOpsModal(profile);
  openModal('world-management-modal');
}

function applyBuildingToPlanet(profile, worldId, planetId, buildingId) {
  const mapWorld = getMapWorld(profile);
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const world = campaign.worldStates?.[worldId];
  const planet = world?.planets?.find((entry) => entry.id === planetId);
  const meta = BUILDING_LIBRARY[buildingId];
  if (!world || !planet || !meta) return { ok: false, message: 'Invalid world/planet/building selection.' };
  profile.economy = profile.economy ?? { gold: 0, lifeforce: 0 };
  if (Number(profile.economy.gold ?? 0) < meta.costGold) return { ok: false, message: `Need ${meta.costGold} gold.` };
  if ((planet.buildings ?? []).length >= Number(planet.buildingCapacity ?? 8)) return { ok: false, message: 'Planet building capacity reached.' };
  profile.economy.gold = Number(profile.economy.gold ?? 0) - meta.costGold;
  planet.buildings = Array.isArray(planet.buildings) ? planet.buildings : [];
  planet.buildings.push(meta.id);
  world.buildHistory = Array.isArray(world.buildHistory) ? world.buildHistory : [];
  world.buildHistory.push({ ts: Date.now(), planetId, buildingId: meta.id, costGold: meta.costGold });
  applyPlanetEconomy(world);
  reconcileWorldOwnership(campaign, world, profile);
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  return { ok: true, message: `${meta.name} built on ${planet.name}.` };
}

function produceCardForWorld(profile, worldId, planetId, cardId, quantity = 1) {
  const mapWorld = getMapWorld(profile);
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const world = campaign.worldStates?.[worldId];
  const planet = world?.planets?.find((entry) => entry.id === planetId);
  if (!world || !planet) return { ok: false, message: 'Invalid world/planet selection.' };
  const qty = clamp(Math.floor(toFiniteNumber(quantity, 1)), 1, 10);
  const pool = cardFactoryPool(profile, world);
  const card = pool.find((entry) => entry.id === cardId);
  if (!card) return { ok: false, message: 'Select a valid card blueprint.' };
  const availability = card.availability ?? cardAvailabilityForWorld(profile, world, card, { forProduction: true });
  if (!availability.available) return { ok: false, message: availability.reason || 'Card is unavailable for production.' };
  const meta = cardCampaignMeta(card);
  const rarity = String(card.rarity ?? 'common').toLowerCase();
  const baseCost = Math.max(25, (Number(card.cost ?? 1) * 16) + (rarity === 'legendary' ? 42 : rarity === 'epic' ? 24 : rarity === 'rare' ? 12 : 0));
  const favor = clamp(toFiniteNumber(world.favor, 50), 0, 100);
  const favorDiscount = favor >= 70 ? 0.86 : favor <= 30 ? 1.15 : 1;
  const metaCostGold = Math.max(0, toFiniteNumber(meta.productionCostGold, 0));
  const totalCost = Math.max(1, Math.round((baseCost + metaCostGold) * qty * favorDiscount));
  profile.economy = profile.economy ?? { gold: 0, lifeforce: 0 };
  profile.economy.lifeforce = Math.max(0, toFiniteNumber(profile.economy.lifeforce, 0));
  if (Number(profile.economy.gold ?? 0) < totalCost) return { ok: false, message: `Need ${totalCost} gold.` };
  const lifeforceCost = Math.max(0, Math.round(toFiniteNumber(meta.productionCostLifeforce, 0) * qty));
  if (profile.economy.lifeforce < lifeforceCost) return { ok: false, message: `Need ${lifeforceCost} lifeforce.` };
  profile.economy.gold = Number(profile.economy.gold ?? 0) - totalCost;
  profile.economy.lifeforce = profile.economy.lifeforce - lifeforceCost;
  profile.collection = profile.collection ?? {};
  profile.collection[card.id] = Math.max(0, Number(profile.collection[card.id] ?? 0) + qty);
  world.producedCards = world.producedCards ?? {};
  world.producedCards[card.id] = Math.max(0, Number(world.producedCards[card.id] ?? 0) + qty);
  planet.reinforcementPool = planet.reinforcementPool ?? {};
  planet.reinforcementPool[card.id] = Math.max(0, Number(planet.reinforcementPool[card.id] ?? 0) + qty);
  const reinKey = `reinforcement:${world.worldId}`;
  campaign.reinforcementPool[reinKey] = Math.max(0, Number(campaign.reinforcementPool[reinKey] ?? 0) + qty);
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  return { ok: true, message: `Produced ${qty}x ${card.name} for ${totalCost} gold${lifeforceCost ? ` + ${lifeforceCost} lifeforce` : ''}.` };
}

function getWorldPlanet(profile, worldId, planetId) {
  const mapWorld = getMapWorld(profile);
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const world = campaign.worldStates?.[worldId] ?? null;
  const planet = world?.planets?.find((entry) => entry.id === planetId) ?? null;
  return { mapWorld, campaign, world, planet };
}

function normalizeFacilityGridShape(rawGrid, seedGrid = blankFacilityGrid()) {
  const expectedSize = conquestExpectedGridSize();
  const normalizeOcc = (cell) => {
    const occ = cell?.occupant;
    if (!occ || typeof occ !== 'object') return null;
    return {
      ...occ,
      cardId: normalizeConquestCardId(occ.cardId),
    };
  };
  const mergeCell = (sourceCell, fallbackCell, idx) => {
    const { col } = facilityCellFromIndex(idx);
    const zone = conquestZoneForCol(col);
    const occ = normalizeOcc(sourceCell);
    let owner = String(sourceCell?.owner ?? fallbackCell?.owner ?? 'neutral').toLowerCase();
    if (!occ && zone === 'no-mans-land') owner = 'neutral';
    if (occ?.side === 'attacker') owner = 'attacker';
    else if (occ?.side === 'defender') owner = 'defender';
    if (!['attacker', 'defender', 'neutral'].includes(owner)) owner = 'neutral';
    return {
      ...(fallbackCell ?? { owner: 'neutral', occupant: null }),
      ...(sourceCell ?? {}),
      owner,
      occupant: occ,
    };
  };
  if (Array.isArray(rawGrid) && rawGrid.length === expectedSize) {
    return rawGrid.map((cell, idx) => mergeCell(cell, seedGrid[idx], idx));
  }
  if (!Array.isArray(rawGrid) || !rawGrid.length) return seedGrid;
  const knownLegacy = [
    { rows: 5, cols: 10 },
    { rows: 5, cols: 8 },
    { rows: 5, cols: 5 },
  ];
  const legacyLayout = knownLegacy.find((layout) => (layout.rows * layout.cols) === rawGrid.length);
  if (!legacyLayout) return seedGrid;
  const migrated = seedGrid.map((cell) => ({ ...cell, occupant: null }));
  const rowOffset = Math.max(0, Math.floor((CONQUEST_GRID_ROWS - legacyLayout.rows) / 2));
  const colOffset = Math.max(0, Math.floor((CONQUEST_GRID_COLS - legacyLayout.cols) / 2));
  for (let oldIdx = 0; oldIdx < rawGrid.length; oldIdx += 1) {
    const oldRow = Math.floor(oldIdx / legacyLayout.cols);
    const oldCol = oldIdx % legacyLayout.cols;
    const row = oldRow + rowOffset;
    const col = oldCol + colOffset;
    if (row < 0 || row >= CONQUEST_GRID_ROWS || col < 0 || col >= CONQUEST_GRID_COLS) continue;
    const idx = facilityCellIndex(row, col);
    migrated[idx] = mergeCell(rawGrid[oldIdx], seedGrid[idx], idx);
  }
  return migrated;
}

function normalizeFacilityWarState(facilityState, worldId, planetId, conquestDecks) {
  const seedState = createFacilityWarState(worldId, planetId, conquestDecks);
  if (!facilityState || typeof facilityState !== 'object') return seedState;
  const normalizeHandEntries = (list = []) => (Array.isArray(list) ? list : [])
    .filter((entry) => entry && typeof entry === 'object')
    .map((entry) => ({
      ...entry,
      cardId: normalizeConquestCardId(entry.cardId),
    }))
    .filter((entry) => !!entry.cardId);
  const normalizeDeckList = (list = []) => conquestDeckCopy(list).filter(Boolean);
  const preferredConquestDecks = normalizeConquestDecks(facilityState.conquestDecks ?? conquestDecks);
  const normalizedDrawDeck = (key) => {
    const raw = normalizeDeckList(facilityState.defender?.drawDecks?.[key] ?? preferredConquestDecks[key]);
    return shouldUpgradeLegacyConquestDeck(key, raw)
      ? conquestDeckCopy(preferredConquestDecks[key])
      : raw;
  };
  const normalizedGrid = normalizeFacilityGridShape(facilityState.grid, seedState.grid);
  const merged = {
    ...seedState,
    ...facilityState,
    defender: {
      ...seedState.defender,
      ...(facilityState.defender ?? {}),
      drawDecks: CONQUEST_DEFENDER_DECK_KEYS.reduce((acc, deckKey) => {
        acc[deckKey] = normalizedDrawDeck(deckKey);
        return acc;
      }, {}),
      hand: normalizeHandEntries(facilityState.defender?.hand),
      discard: normalizeDeckList(facilityState.defender?.discard),
      drawHistory: CONQUEST_DEFENDER_DECK_KEYS.reduce((acc, deckKey) => {
        acc[deckKey] = normalizeDeckList(facilityState.defender?.drawHistory?.[deckKey]);
        return acc;
      }, {}),
    },
    attacker: {
      ...seedState.attacker,
      ...(facilityState.attacker ?? {}),
      hand: normalizeHandEntries(facilityState.attacker?.hand),
      deck: Array.isArray(facilityState.attacker?.deck) ? normalizeDeckList(facilityState.attacker?.deck) : seedState.attacker.deck,
      discard: normalizeDeckList(facilityState.attacker?.discard),
    },
    grid: normalizedGrid,
    log: Array.isArray(facilityState.log) ? facilityState.log.slice(-80) : seedState.log,
    outcomeAppliedAt: Math.max(0, Number(facilityState.outcomeAppliedAt ?? 0)),
    lastDraw: facilityState.lastDraw && typeof facilityState.lastDraw === 'object'
      ? { ...facilityState.lastDraw, cardId: normalizeConquestCardId(facilityState.lastDraw.cardId) }
      : null,
    encounter: facilityState.encounter && typeof facilityState.encounter === 'object'
      ? { ...facilityState.encounter }
      : null,
    matSettings: normalizeConquestMatSettings(facilityState.matSettings ?? seedState.matSettings),
    setupPresets: normalizeFacilitySetupPresets(facilityState.setupPresets ?? seedState.setupPresets),
    conquestDecks: preferredConquestDecks,
    playerSide: String(facilityState.playerSide ?? seedState.playerSide ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender',
    aiControl: {
      attacker: facilityState.aiControl?.attacker ?? seedState.aiControl.attacker ?? true,
      defender: facilityState.aiControl?.defender ?? seedState.aiControl.defender ?? false,
    },
  };
  syncDefenderResourceCaps(merged, { clampOverflow: true });
  return merged;
}

function ensurePlanetConquestState(world, planet) {
  if (!world || !planet) return;
  planet.conquestDecks = normalizeConquestDecks(planet.conquestDecks);
  planet.facilityWar = normalizeFacilityWarState(planet.facilityWar, world.worldId, planet.id, planet.conquestDecks);
}

function facilityLog(state, text, level = 'info') {
  state.log = Array.isArray(state.log) ? state.log : [];
  state.log.push({ ts: Date.now(), text, level });
  state.log = state.log.slice(-90);
  if (facilityDevUiState.enabled) {
    pushFacilityDevTrace(String(text ?? ''), level);
  }
}

function calculateDefenderStorageInfo(state) {
  const defenderOcc = (state?.grid ?? [])
    .map((cell) => cell?.occupant)
    .filter((occ) => occ?.side === 'defender');
  const storageCount = defenderOcc.filter((occ) => toArray(occ.tags).includes('storage')).length;
  const extraWheatCap = defenderOcc.reduce((sum, occ) => sum + Math.max(0, Number(occ?.status?.wheatCapBonus ?? 0)), 0);
  const extraIronCap = defenderOcc.reduce((sum, occ) => sum + Math.max(0, Number(occ?.status?.ironCapBonus ?? 0)), 0);
  const wheatCap = 10 + (storageCount * 5) + extraWheatCap;
  const ironCap = 10 + (storageCount * 5) + extraIronCap;
  return {
    storageCount,
    extraWheatCap,
    extraIronCap,
    wheatCap: Math.max(1, Math.floor(Number(wheatCap ?? 10))),
    ironCap: Math.max(1, Math.floor(Number(ironCap ?? 10))),
  };
}

function syncDefenderResourceCaps(state, options = {}) {
  if (!state?.defender) return {
    storageCount: 0, extraWheatCap: 0, extraIronCap: 0, wheatCap: 10, ironCap: 10, lostWheat: 0, lostIron: 0,
  };
  const clampOverflow = options.clampOverflow !== false;
  const previousWheatCap = Math.max(1, Number(state.defender.wheatCap ?? 10));
  const previousIronCap = Math.max(1, Number(state.defender.ironCap ?? 10));
  const info = calculateDefenderStorageInfo(state);
  state.defender.wheatCap = info.wheatCap;
  state.defender.ironCap = info.ironCap;
  let lostWheat = 0;
  let lostIron = 0;
  if (clampOverflow) {
    const wheat = Math.max(0, Number(state.defender.wheat ?? 0));
    const iron = Math.max(0, Number(state.defender.iron ?? 0));
    if (wheat > info.wheatCap) {
      lostWheat = wheat - info.wheatCap;
      state.defender.wheat = info.wheatCap;
    } else {
      state.defender.wheat = wheat;
    }
    if (iron > info.ironCap) {
      lostIron = iron - info.ironCap;
      state.defender.iron = info.ironCap;
    } else {
      state.defender.iron = iron;
    }
  }
  if (lostWheat > 0 || lostIron > 0 || previousWheatCap !== info.wheatCap || previousIronCap !== info.ironCap) {
    state.defender.lastCapClamp = {
      ts: Date.now(),
      lostWheat,
      lostIron,
      previousWheatCap,
      previousIronCap,
      wheatCap: info.wheatCap,
      ironCap: info.ironCap,
      storageCount: info.storageCount,
    };
  }
  return { ...info, lostWheat, lostIron, previousWheatCap, previousIronCap };
}

function defenderUpgradeTargetReadout(card, target) {
  const cardTags = new Set(toArray(card?.tags).map((tag) => String(tag).toLowerCase()));
  const targetTags = new Set(toArray(target?.tags).map((tag) => String(tag).toLowerCase()));
  const isEquipment = !!card?.equipment
    || cardTags.has('equipment')
    || cardTags.has('weapon')
    || cardTags.has('armor')
    || cardTags.has('armour')
    || cardTags.has('job')
    || cardTags.has('spellcasting')
    || cardTags.has('artifact')
    || cardTags.has('totem')
    || String(card?.cardType ?? '').toLowerCase().includes('equipment');
  if (!target || target.side !== 'defender') {
    return { ok: false, isEquipment, message: 'Select a friendly target for upgrade.' };
  }
  if (isEquipment) {
    const canEquip = (
      target.type === 'unit'
      || target.type === 'building'
      || targetTags.has('infantry')
      || targetTags.has('officer')
      || targetTags.has('ground')
      || targetTags.has('air')
      || targetTags.has('armoured')
      || targetTags.has('structure')
      || targetTags.has('facility')
      || targetTags.has('turret')
      || targetTags.has('barricade')
    );
    if (!canEquip) return { ok: false, isEquipment, message: 'This equipment can only be assigned to friendly troops or structures.' };
    return { ok: true, isEquipment, message: 'Valid equipment target.' };
  }
  const explicitTargets = ['turret', 'barricade', 'farm', 'mine', 'factory', 'training', 'blacksmith']
    .filter((tag) => cardTags.has(tag));
  const normalizedTargets = (explicitTargets.length > 1 && explicitTargets.includes('blacksmith'))
    ? explicitTargets.filter((tag) => tag !== 'blacksmith')
    : explicitTargets.slice();
  if (normalizedTargets.length > 0) {
    const matches = normalizedTargets.some((tag) => targetTags.has(tag));
    if (!matches) {
      const pretty = normalizedTargets
        .map((tag) => (tag === 'training' ? 'training facility' : tag))
        .join(' or ');
      return { ok: false, isEquipment, message: `Target must be ${pretty}.` };
    }
  }
  return { ok: true, isEquipment, message: 'Valid upgrade target.' };
}

function computeDefenderSpendPreview(state, card) {
  const rawCost = card?.cost ?? {};
  const setupBypass = String(state?.phase ?? '') === 'setup';
  const wheatBase = Math.max(0, Number(rawCost.wheat ?? 0));
  const ironBase = Math.max(0, Number(rawCost.iron ?? 0));
  const manaBase = Math.max(0, Number(rawCost.mana ?? 0));
  let wheat = wheatBase;
  let iron = ironBase;
  let mana = manaBase;
  let trainingDiscountUsed = 0;
  let tempWheatUsed = 0;
  let tempIronUsed = 0;
  if (!setupBypass) {
    if (String(card?.sourceBuilding ?? '') === 'training' && Number(state?.defender?.trainingDiscountCharges ?? 0) > 0 && wheat > 0) {
      wheat -= 1;
      trainingDiscountUsed = 1;
    }
    if (Number(state?.defender?.tempWheatDiscount ?? 0) > 0 && wheat > 0) {
      tempWheatUsed = Math.min(wheat, Number(state.defender.tempWheatDiscount ?? 0));
      wheat -= tempWheatUsed;
    }
    if (Number(state?.defender?.tempIronDiscount ?? 0) > 0 && iron > 0) {
      tempIronUsed = Math.min(iron, Number(state.defender.tempIronDiscount ?? 0));
      iron -= tempIronUsed;
    }
  } else {
    wheat = 0;
    iron = 0;
    mana = 0;
  }
  const currentWheat = Math.max(0, Number(state?.defender?.wheat ?? 0));
  const currentIron = Math.max(0, Number(state?.defender?.iron ?? 0));
  const currentMana = Math.max(0, Number(state?.attacker?.mana ?? 0));
  const missingWheat = Math.max(0, wheat - currentWheat);
  const missingIron = Math.max(0, iron - currentIron);
  const missingMana = Math.max(0, mana - currentMana);
  const affordable = setupBypass || ((missingWheat <= 0) && (missingIron <= 0) && (missingMana <= 0));
  let message = 'Affordable.';
  if (setupBypass) {
    message = 'Setup phase: starter placement does not spend resources.';
  } else if (!affordable) {
    const misses = [];
    if (missingWheat > 0) misses.push(`Need +${missingWheat} Wheat`);
    if (missingIron > 0) misses.push(`Need +${missingIron} Iron`);
    if (missingMana > 0) misses.push(`Need +${missingMana} Mana`);
    message = misses.join(' • ');
  } else if (trainingDiscountUsed || tempWheatUsed || tempIronUsed) {
    const parts = [];
    if (trainingDiscountUsed) parts.push('Training discount -1 Wheat');
    if (tempWheatUsed) parts.push(`Temp Wheat discount -${tempWheatUsed}`);
    if (tempIronUsed) parts.push(`Temp Iron discount -${tempIronUsed}`);
    message = parts.join(' • ');
  }
  return {
    setupBypass,
    wheatBase,
    ironBase,
    manaBase,
    wheat,
    iron,
    mana,
    trainingDiscountUsed,
    tempWheatUsed,
    tempIronUsed,
    currentWheat,
    currentIron,
    currentMana,
    missingWheat,
    missingIron,
    missingMana,
    affordable,
    message,
  };
}

function conquestCostText(card = {}) {
  const cost = card.cost ?? {};
  const wheat = Math.max(0, Number(cost.wheat ?? 0));
  const iron = Math.max(0, Number(cost.iron ?? 0));
  const mana = Math.max(0, Number(cost.mana ?? 0));
  const parts = [];
  if (wheat) parts.push(`W${wheat}`);
  if (iron) parts.push(`I${iron}`);
  if (mana) parts.push(`M${mana}`);
  return parts.join(' / ') || 'Free';
}

function conquestStatsText(entry = {}) {
  const atk = Math.max(0, Number(entry.attack ?? entry.atk ?? 0));
  const hp = Math.max(0, Number(entry.health ?? entry.hp ?? 0));
  const def = Math.max(0, Number(entry.defense ?? entry.def ?? 0));
  return `${atk}/${hp}/${def}`;
}

function conquestEntryTypeText(entry = {}) {
  const type = String(entry.cardType ?? entry.type ?? 'card');
  const subtype = String(entry.subtype ?? '').trim();
  return subtype ? `${type} • ${subtype}` : type;
}

function conquestEntryTags(entry = {}) {
  const tags = toArray(entry.tags).map((tag) => String(tag)).filter(Boolean);
  return tags.slice(0, 4).join(' • ');
}

const CONQUEST_KEYWORD_HELP = {
  siege: 'Deals extra pressure to structures/barricades and breach targets.',
  horde: 'Strength scales with remaining members; explosive effects are extra dangerous.',
  large: 'Large battlefield body with high lane impact and deployment constraints.',
  fortified: 'Enhanced defensive posture that improves lane holding.',
  repair: 'Can restore health to structures, barricades, or support assets.',
  schematic: 'Upgrade blueprint that must target a valid card type.',
  equipment: 'Attachable gear that modifies troop/structure combat profile.',
  barricade: 'Lane blocker that must be breached/destroyed to pass legally.',
  facility: 'Production or support structure tied to conquest infrastructure.',
  ranged: 'Attacks from range profile; some cards have minimum range limits.',
  capture: 'Improves territory control/capture pressure.',
  anti_flying: 'Prioritizes or gains bonus versus flying threats.',
  anti_horde: 'Specialized to suppress high-count horde units.',
  anti_large: 'Specialized to counter large units and giant threats.',
};

function conquestRoleSummary(entry = {}) {
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  if (entry.equipment || tags.has('equipment')) return 'Equipment';
  if (entry.upgradeSchematic || tags.has('schematic') || String(entry.type ?? '').toLowerCase() === 'upgrade') return 'Upgrade';
  if (String(entry.type ?? '').toLowerCase() === 'tactic' || String(entry.type ?? '').toLowerCase() === 'spell') return 'Tactic';
  if (String(entry.type ?? '').toLowerCase() === 'building' || tags.has('structure') || tags.has('facility') || tags.has('barricade')) return 'Structure';
  if (String(entry.type ?? '').toLowerCase() === 'unit') return 'Unit';
  return 'Support';
}

function conquestCardDeckCategory(card = {}) {
  const source = String(card.sourceBuilding ?? card.productionSource ?? '').toLowerCase();
  if (source === 'blacksmith') return card.equipment ? 'armour/weapon' : 'upgrade/support';
  if (source === 'training') return 'units';
  if (source === 'factory') return String(card.type ?? '').toLowerCase() === 'unit' ? 'war-machine' : 'factory-structure';
  if (source === 'command') return String(card.type ?? '').toLowerCase() === 'building' ? 'command-structure' : 'orders/tactics';
  if (source === 'vehicle') return 'vehicle-wing';
  if (source === 'ordnance') return 'ordnance/siege';
  if (source === 'air') return 'air-support';
  if (source === 'power') return 'power/shield';
  if (source === 'recovery') return 'medical/recovery';
  if (source === 'experimental') return 'prototype/experimental';
  if (source === 'attacker') return 'attacker';
  return source || 'misc';
}

function conquestEntryTagsHtml(entry = {}) {
  const tags = toArray(entry.tags).map((tag) => String(tag).trim()).filter(Boolean).slice(0, 6);
  if (!tags.length) return '<span class="conquest-tag-pill">No tags</span>';
  return tags.map((tag) => {
    const key = tag.toLowerCase().replace(/[^a-z0-9]+/g, '_');
    const hint = CONQUEST_KEYWORD_HELP[key] ?? '';
    const safeHint = hint.replace(/"/g, '&quot;');
    return `<span class="conquest-tag-pill" title="${safeHint}">${tag}</span>`;
  }).join('');
}

const CONQUEST_TYPE_BADGES = [
  { key: 'flying', label: 'FLY', hint: 'Flying unit' },
  { key: 'giant', label: 'GNT', hint: 'Large / giant-class body' },
  { key: 'horde', label: 'HRD', hint: 'Horde unit' },
  { key: 'siege', label: 'SGE', hint: 'Siege pressure vs structures' },
  { key: 'ranged', label: 'RNG', hint: 'Ranged attack profile' },
  { key: 'anti-flying', label: 'AA', hint: 'Anti-air specialist' },
  { key: 'structure', label: 'STR', hint: 'Structure card' },
  { key: 'facility', label: 'FAC', hint: 'Production/support facility' },
  { key: 'turret', label: 'TUR', hint: 'Turret platform' },
  { key: 'barricade', label: 'BAR', hint: 'Barricade / wall' },
  { key: 'vehicle', label: 'VEH', hint: 'Vehicle class' },
  { key: 'mech', label: 'MECH', hint: 'Mech class' },
  { key: 'command', label: 'CMD', hint: 'Command card' },
  { key: 'upgrade', label: 'UPG', hint: 'Upgrade schematic' },
  { key: 'equipment', label: 'EQP', hint: 'Equipment card' },
  { key: 'repair', label: 'REP', hint: 'Repair relevant' },
];

function conquestTypeBadgesHtml(entry = {}) {
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  const hints = [];
  if (String(entry.type ?? '').toLowerCase() === 'building') tags.add('structure');
  if (String(entry.type ?? '').toLowerCase() === 'upgrade') tags.add('upgrade');
  if (entry.equipment) tags.add('equipment');
  if (entry.upgradeSchematic) tags.add('upgrade');
  if (Number(entry.siege ?? 0) > 0) tags.add('siege');
  if (Number(entry.range ?? 1) > 1) tags.add('ranged');
  CONQUEST_TYPE_BADGES.forEach((badge) => {
    if (!tags.has(badge.key)) return;
    const safeHint = String(badge.hint ?? '').replace(/"/g, '&quot;');
    hints.push(`<span class="conquest-type-badge badge-${badge.key}" title="${safeHint}">${badge.label}</span>`);
  });
  return hints.join('');
}

function conquestHasRapidEntry(entry = {}) {
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  const rapidTags = ['rush', 'blitz', 'immediate-fire', 'fast-deploy', 'overwatch-entry', 'assault-frame'];
  return rapidTags.some((tag) => tags.has(tag));
}

function conquestHandCategory(entry = {}) {
  const type = String(entry.type ?? '').toLowerCase();
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  if (entry.equipment || tags.has('equipment')) return 'equipment';
  if (entry.upgradeSchematic || type === 'upgrade' || tags.has('schematic') || tags.has('upgrade')) return 'upgrade';
  if (type === 'building' || type === 'pylon' || tags.has('structure') || tags.has('facility') || tags.has('barricade') || tags.has('turret')) return 'building';
  if (type === 'spell' || type === 'tactic') return 'tactic';
  if (type === 'unit') {
    if (tags.has('support') || tags.has('officer') || tags.has('command') || tags.has('medic') || tags.has('repair')) return 'support';
    return 'unit';
  }
  return 'support';
}

function conquestReadinessText(entry = {}, turnNumber = 1) {
  const acted = Number(entry?.status?.actedTurn ?? 0) === Number(turnNumber ?? 1);
  if (acted) return 'Acted this turn.';
  const deployedTurn = Number(entry?.status?.deployedTurn ?? 0);
  if (deployedTurn === Number(turnNumber ?? 1) && !conquestHasRapidEntry(entry)) {
    return 'Freshly deployed: cannot attack this turn.';
  }
  return 'Ready';
}

function conquestDeckSummary(deck = [], profile = null) {
  const cards = deck
    .map((cardId) => conquestCardById(profile ?? loadProfile(), cardId))
    .filter(Boolean);
  const byRole = {};
  let totalCost = 0;
  cards.forEach((card) => {
    const role = conquestRoleSummary(card);
    byRole[role] = (byRole[role] ?? 0) + 1;
    totalCost += Number(card.cost?.wheat ?? 0) + Number(card.cost?.iron ?? 0) + Number(card.cost?.mana ?? 0);
  });
  const avgCost = cards.length ? (totalCost / cards.length) : 0;
  return { size: cards.length, byRole, avgCost };
}

function conquestDeckHint(deckKey, summary) {
  const roles = summary?.byRole ?? {};
  if (deckKey === 'training' && (roles.Unit ?? 0) < 20) return 'Hint: training is your troop backbone; add more infantry, officers, and specialist squads.';
  if (deckKey === 'blacksmith' && (roles.Equipment ?? 0) < 18) return 'Hint: blacksmith should be heavy on equipment/upgrades for infantry + machines.';
  if (deckKey === 'factory' && (roles.Unit ?? 0) < 14) return 'Hint: factory should field expensive armored war machines, not mostly walls.';
  if (deckKey === 'command' && (roles.Tactic ?? 0) < 10) return 'Hint: command works best with doctrine cards, lane orders, and support structures.';
  if (deckKey === 'vehicle' && (roles.Unit ?? 0) < 14) return 'Hint: vehicle deck should prioritize mobile armor and lane relocation pressure.';
  if (deckKey === 'ordnance' && (roles.Tactic ?? 0) < 12) return 'Hint: ordnance deck should contain shelling, breach, and siege payload tactics.';
  if (deckKey === 'air' && (roles.Unit ?? 0) < 12) return 'Hint: air support deck wants interceptors, bombers, and recon pressure.';
  if (deckKey === 'power' && (roles.Upgrade ?? 0) < 8) return 'Hint: power/shield deck is strongest with overclocks, barriers, and energy upgrades.';
  if (deckKey === 'recovery' && (roles.Tactic ?? 0) < 8) return 'Hint: recovery deck needs medics, trauma tools, and anti-attrition support.';
  if (deckKey === 'experimental' && (roles.Tactic ?? 0) < 10) return 'Hint: experimental deck should hold swingy prototypes and high-impact tech plays.';
  if (deckKey === 'attacker' && (roles.Unit ?? 0) < 24) return 'Hint: attacker deck should keep high unit pressure with support spells.';
  return 'Deck balance looks healthy.';
}

function conquestEquipTargetSummary(entry = {}) {
  if (!(entry.equipment || toArray(entry.tags).includes('equipment'))) return 'No equipment targeting rules.';
  return 'Equip targets: infantry, officers, mobile ground/air units, and allied structures where valid.';
}

function conquestUpgradeTargetSummary(entry = {}) {
  if (!(entry.upgradeSchematic || toArray(entry.tags).includes('schematic') || String(entry.type ?? '').toLowerCase() === 'upgrade')) return 'No upgrade targeting rules.';
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  if (tags.has('turret')) return 'Upgrade target: Turret only.';
  if (tags.has('barricade')) return 'Upgrade target: Barricade only.';
  if (tags.has('farm')) return 'Upgrade target: Farm only.';
  if (tags.has('mine')) return 'Upgrade target: Mine only.';
  if (tags.has('factory')) return 'Upgrade target: Factory only.';
  if (tags.has('training')) return 'Upgrade target: Training Facility only.';
  if (tags.has('blacksmith')) return 'Upgrade target: Blacksmith only.';
  return 'Upgrade target: valid friendly structure/unit based on tags.';
}

function conquestPlacementRestrictionSummary(entry = {}) {
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  const lines = [];
  if (entry.side === 'attacker') {
    lines.push('Placement: attacker deployment zone only.');
  } else if (entry.side === 'defender') {
    lines.push('Placement: defender deployment zone only.');
  }
  if (tags.has('backline-only')) lines.push('Restriction: can only be placed on your backline.');
  if (tags.has('facility') || tags.has('structure')) lines.push('Restriction: requires empty cell.');
  if (tags.has('upgrade') || String(entry.type ?? '').toLowerCase() === 'upgrade') {
    lines.push(conquestUpgradeTargetSummary(entry));
  }
  if (entry.equipment || tags.has('equipment')) {
    lines.push(conquestEquipTargetSummary(entry));
  }
  const source = String(entry.sourceBuilding ?? entry.productionSource ?? '').trim();
  if (source && source !== 'utility') {
    lines.push(`Produced by: ${source.toUpperCase()}.`);
  }
  return lines.length ? lines.join(' ') : 'No special placement restrictions.';
}

function conquestStatusEffectsSummary(entry = {}) {
  const status = entry?.status ?? {};
  const out = [];
  if (status.shaken) out.push('Shaken');
  if (status.suppressed) out.push('Suppressed');
  if (status.fortified) out.push('Fortified');
  if (status.shielded) out.push(`Shield ${Math.max(0, Number(status.shielded ?? 0))}`);
  if (status.overclocked) out.push('Overclocked');
  if (!out.length) return 'None';
  return out.join(' • ');
}

function conquestInspectCardMarkup(entry = {}, options = {}) {
  if (!entry) return '<div>No card selected.</div>';
  const owner = String(options.owner ?? entry.side ?? 'neutral');
  const playerSide = String(options.playerSide ?? 'defender');
  const role = conquestRoleSummary(entry);
  const rarity = String(entry.rarity ?? entry.status?.gearTier ?? 'common').toLowerCase();
  const hpNow = Math.max(0, Number(entry.hp ?? entry.health ?? 0));
  const hpMax = Math.max(1, Number(entry.maxHp ?? entry.health ?? entry.hp ?? 1));
  const hpPct = clamp((hpNow / hpMax) * 100, 0, 100);
  const readiness = conquestReadinessText(entry, options.turnNumber ?? 1);
  const source = String(entry.sourceBuilding ?? entry.productionSource ?? 'board').toUpperCase();
  const ownerBadge = owner === playerSide ? 'ALLY' : owner === 'neutral' ? 'NEUTRAL' : 'ENEMY';
  const placementText = conquestPlacementRestrictionSummary(entry);
  const acted = Number(entry?.status?.actedTurn ?? 0) === Number(options.turnNumber ?? 1);
  const canAttack = acted ? 'No (already acted)' : (readiness.startsWith('Freshly') ? 'No (summoning sickness)' : 'Yes');
  return `
    <article class="conquest-card-face rarity-${rarity} selected inspect-owner-${owner}">
      <header>
        <strong>${entry.name ?? 'Unknown'}</strong>
        <span>${conquestCostText(entry)}</span>
      </header>
      <div class="conquest-card-meta"><span class="facility-side-pill side-${owner === playerSide ? 'friendly' : owner === 'neutral' ? 'neutral' : 'enemy'}">${ownerBadge}</span> ${conquestEntryTypeText(entry)} • ${role}</div>
      <div class="conquest-card-meta">Stats ${conquestStatsText(entry)} • HP ${hpNow}/${hpMax}</div>
      <div class="facility-cell-health inspect-health">
        <div class="facility-cell-health-track"><span class="facility-cell-health-fill ${hpPct <= 25 ? 'critical' : hpPct <= 55 ? 'warn' : 'healthy'}" style="width:${hpPct.toFixed(2)}%"></span></div>
      </div>
      <div class="conquest-card-meta">Owner: ${owner.toUpperCase()} • Source: ${source}</div>
      <div class="conquest-card-meta">Readiness: ${readiness} • Can attack: ${canAttack}</div>
      <div class="conquest-card-meta">Status effects: ${conquestStatusEffectsSummary(entry)}</div>
      <div class="conquest-type-badges">${conquestTypeBadgesHtml(entry) || '<span class="conquest-type-badge badge-none">STD</span>'}</div>
      <div class="conquest-card-tags">${conquestEntryTagsHtml(entry)}</div>
      <div class="conquest-card-meta">${conquestEquipTargetSummary(entry)}</div>
      <div class="conquest-card-meta">${conquestUpgradeTargetSummary(entry)}</div>
      <div class="conquest-card-meta">${placementText}</div>
      <p>${entry.text ?? 'No rules text.'}</p>
    </article>
  `;
}

function facilityCellFromIndex(idx) {
  const row = Math.floor(idx / CONQUEST_GRID_COLS);
  const col = idx % CONQUEST_GRID_COLS;
  return { row, col };
}

function conquestAiSkillTier(state) {
  return clamp(Math.round(toFiniteNumber(state?.encounter?.aiSkillStars, 2)), 1, 5);
}

function conquestAiDebugEnabled() {
  try {
    if (window?.CF_DEBUG_CONQUEST) return true;
    return localStorage.getItem('cf_conquest_ai_debug') === '1';
  } catch (_) {
    return false;
  }
}

function conquestAiDebugLog(state, text) {
  if (!conquestAiDebugEnabled()) return;
  facilityLog(state, `[AI] ${text}`, 'info');
}

function resolveConquestRangeProfile(occ = {}) {
  const tags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
  const hasExplicitMin = occ.minRange !== null && occ.minRange !== undefined && String(occ.minRange).trim() !== '';
  const hasExplicitMax = occ.maxRange !== null && occ.maxRange !== undefined && String(occ.maxRange).trim() !== '';
  const explicitMin = hasExplicitMin && Number.isFinite(Number(occ.minRange)) ? Number(occ.minRange) : null;
  const explicitMax = hasExplicitMax && Number.isFinite(Number(occ.maxRange)) ? Number(occ.maxRange) : null;
  if (explicitMin !== null && explicitMax !== null) {
    return {
      min: clamp(Math.max(1, explicitMin), 1, 6),
      max: clamp(Math.max(explicitMin, explicitMax), 1, 6),
    };
  }
  const isTurret = tags.has('turret');
  if (isTurret) {
    const upgraded = Math.max(2, Number(occ.range ?? 2));
    return { min: 1, max: clamp(upgraded, 2, 6) };
  }
  const isRanged = tags.has('ranged') || tags.has('bow') || tags.has('archer');
  if (isRanged) {
    return { min: 2, max: 2 };
  }
  const max = clamp(Math.max(1, Number(occ.range ?? 1)), 1, 6);
  return { min: 1, max };
}

function hasLivingHomestead(state) {
  return state.grid.some((cell) => {
    const occ = cell?.occupant;
    if (!occ || occ.side !== 'attacker' || Number(occ.hp ?? 0) <= 0) return false;
    const tags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
    return tags.has('homestead');
  });
}

function findUnitTargetsInLane(state, side, fromRow, fromCol, range = 1, minRange = 1, attackerOcc = null) {
  const enemy = side === 'defender' ? 'attacker' : 'defender';
  const dir = side === 'defender' ? -1 : 1;
  const minStep = Math.max(1, Number(minRange ?? 1));
  const maxStep = Math.max(minStep, Number(range ?? 1));
  const tags = new Set(toArray(attackerOcc?.tags).map((tag) => String(tag).toLowerCase()));
  const bypassBarricade = tags.has('flying') || tags.has('breach') || tags.has('phase');
  for (let step = 1; step <= maxStep; step += 1) {
    const col = fromCol + (dir * step);
    if (col < 0 || col >= CONQUEST_GRID_COLS) break;
    const idx = facilityCellIndex(fromRow, col);
    const cell = state.grid[idx];
    const occ = cell?.occupant;
    if (!occ) continue;
    const occTags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
    const isBarricade = occTags.has('barricade');
    if (occ.side !== enemy) {
      return null;
    }
    if (isBarricade && !bypassBarricade) {
      if (step < minStep) return null;
      return { idx, cell, row: fromRow, col };
    }
    if (step < minStep) return null;
    return { idx, cell, row: fromRow, col };
  }
  return null;
}

function findLaneBlocker(state, side, fromRow, fromCol, range = 1) {
  const dir = side === 'defender' ? -1 : 1;
  const maxStep = Math.max(1, Number(range ?? 1));
  for (let step = 1; step <= maxStep; step += 1) {
    const col = fromCol + (dir * step);
    if (col < 0 || col >= CONQUEST_GRID_COLS) break;
    const idx = facilityCellIndex(fromRow, col);
    const occ = state.grid[idx]?.occupant;
    if (!occ) continue;
    const occTags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
    return { step, occupant: occ, barricade: occTags.has('barricade') };
  }
  return null;
}

function collectConquestAttackTargets(state, sourceCellIndex, occ) {
  if (!state || !occ || !Number.isInteger(sourceCellIndex)) return [];
  const side = String(occ.side ?? '');
  const enemySide = side === 'defender' ? 'attacker' : side === 'attacker' ? 'defender' : '';
  if (!enemySide) return [];
  const { row, col } = facilityCellFromIndex(sourceCellIndex);
  const targets = [];
  const seen = new Set();
  const sourceTags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
  const rangeProfile = resolveConquestRangeProfile(occ);

  const pushTarget = (idx, mode = 'adjacent') => {
    if (!Number.isInteger(idx) || seen.has(idx)) return;
    const cell = state.grid[idx];
    const targetOcc = cell?.occupant;
    if (!targetOcc || targetOcc.side !== enemySide || Number(targetOcc.hp ?? 0) <= 0) return;
    const targetTags = new Set(toArray(targetOcc.tags).map((tag) => String(tag).toLowerCase()));
    const targetCoords = facilityCellFromIndex(idx);
    const distance = Math.max(Math.abs(targetCoords.row - row), Math.abs(targetCoords.col - col));
    const damage = facilityDamageValue(occ, targetOcc);
    let priority = 10 - distance;
    if (mode === 'adjacent') priority += 4;
    if (damage >= Math.max(1, Number(targetOcc.hp ?? 1))) priority += 22;
    if (targetTags.has('homestead')) priority += 28;
    if (targetTags.has('turret')) priority += 8;
    if (targetTags.has('barricade')) priority += 7;
    if (targetTags.has('horde')) priority += 5;
    if (targetOcc.type === 'building' || targetTags.has('structure') || targetTags.has('facility')) priority += 6;
    if (Number(occ.siege ?? 0) > 0 && (targetTags.has('barricade') || targetOcc.type === 'building' || targetTags.has('structure'))) {
      priority += 8;
    }
    targets.push({
      idx,
      row: targetCoords.row,
      col: targetCoords.col,
      occupant: targetOcc,
      mode,
      distance,
      damage,
      priority,
    });
    seen.add(idx);
  };

  // Every combat card gets at least 3x3 local threat (orthogonal + diagonal adjacency).
  for (let dr = -1; dr <= 1; dr += 1) {
    for (let dc = -1; dc <= 1; dc += 1) {
      if (dr === 0 && dc === 0) continue;
      const nextRow = row + dr;
      const nextCol = col + dc;
      if (nextRow < 0 || nextRow >= CONQUEST_GRID_ROWS) continue;
      if (nextCol < 0 || nextCol >= CONQUEST_GRID_COLS) continue;
      pushTarget(facilityCellIndex(nextRow, nextCol), 'adjacent');
    }
  }

  const isTurret = sourceTags.has('turret');
  let laneBlockedByBarricade = false;
  if (isTurret && side === 'defender') {
    const frontCol = col - 1;
    if (frontCol >= 0) {
      const frontIdx = facilityCellIndex(row, frontCol);
      laneBlockedByBarricade = toArray(state.grid[frontIdx]?.occupant?.tags).includes('barricade');
    }
  }

  if (!laneBlockedByBarricade && rangeProfile.max > 1) {
    const laneTarget = findUnitTargetsInLane(state, side, row, col, rangeProfile.max, rangeProfile.min, occ);
    if (laneTarget?.cell?.occupant?.side === enemySide) {
      pushTarget(laneTarget.idx, 'lane');
    }
  }

  targets.sort((a, b) => b.priority - a.priority || a.distance - b.distance || a.idx - b.idx);
  return targets;
}

function listLegalUnitMoves(state, fromIdx, occ) {
  if (!occ || Number(occ.hp ?? 0) <= 0) return [];
  const side = occ.side;
  if (side !== 'defender' && side !== 'attacker') return [];
  const { row, col } = facilityCellFromIndex(fromIdx);
  const forwardDir = side === 'defender' ? -1 : 1;
  const frontCol = col + forwardDir;
  const frontOccupied = frontCol >= 0
    && frontCol < CONQUEST_GRID_COLS
    && !!state.grid[facilityCellIndex(row, frontCol)]?.occupant;
  const candidates = [
    { dir: 'forward', row, col: frontCol, blocked: frontOccupied },
    { dir: 'left', row: row - 1, col },
    { dir: 'right', row: row + 1, col },
    { dir: 'backward', row, col: col - forwardDir },
  ];
  const out = [];
  candidates.forEach((candidate) => {
    if (candidate.dir === 'forward' && candidate.blocked) return;
    if (candidate.row < 0 || candidate.row >= CONQUEST_GRID_ROWS) return;
    if (candidate.col < 0 || candidate.col >= CONQUEST_GRID_COLS) return;
    const idx = facilityCellIndex(candidate.row, candidate.col);
    if (state.grid[idx]?.occupant) return;
    out.push({ ...candidate, idx });
  });

  // Defender barricade pass rule: if friendly barricade is directly ahead and lane is not threatened within 2 nodes, jump past it.
  if (side === 'defender') {
    const frontCol = col - 1;
    const jumpCol = col - 2;
    if (frontCol >= 0 && jumpCol >= 0) {
      const frontIdx = facilityCellIndex(row, frontCol);
      const jumpIdx = facilityCellIndex(row, jumpCol);
      const frontOcc = state.grid[frontIdx]?.occupant;
      const jumpOcc = state.grid[jumpIdx]?.occupant;
      const isFrontBarricade = frontOcc && frontOcc.side === 'defender' && toArray(frontOcc.tags).includes('barricade');
      const threatened = [frontCol, jumpCol].some((c) => {
        const idx = facilityCellIndex(row, c);
        return state.grid[idx]?.occupant?.side === 'attacker';
      });
      if (isFrontBarricade && !jumpOcc && !threatened) {
        out.push({ dir: 'barricade-pass', row, col: jumpCol, idx: jumpIdx });
      }
    }
  }
  return out;
}

function facilityDamageValue(attacker, defender) {
  const atk = Math.max(0, Number(attacker?.atk ?? 0));
  const def = Math.max(0, Number(defender?.def ?? 0));
  return Math.max(1, atk - def);
}

function findFacilityOccupantIndex(state, occupant) {
  if (!occupant || !Array.isArray(state?.grid)) return -1;
  for (let i = 0; i < state.grid.length; i += 1) {
    if (state.grid[i]?.occupant === occupant) return i;
  }
  return -1;
}

function applyFacilityHeal(state, targetOcc, amount, sourceOcc = null, flags = {}) {
  const heal = Math.max(0, Number(amount ?? 0));
  if (!targetOcc || heal <= 0) {
    return { applied: false, amount: 0, targetHp: Math.max(0, Number(targetOcc?.hp ?? 0)) };
  }
  const targetIndex = findFacilityOccupantIndex(state, targetOcc);
  const sourceIndex = findFacilityOccupantIndex(state, sourceOcc);
  const maxHp = Math.max(1, Number(targetOcc.maxHp ?? targetOcc.hp ?? 1));
  const beforeHp = Math.max(0, Number(targetOcc.hp ?? 0));
  targetOcc.hp = Math.min(maxHp, beforeHp + heal);
  const applied = Math.max(0, Number(targetOcc.hp ?? 0) - beforeHp);
  if (applied <= 0) {
    return { applied: false, amount: 0, targetHp: Math.max(0, Number(targetOcc.hp ?? 0)) };
  }
  const sourceTags = conquestVfxTagArray(sourceOcc, toArray(flags.sourceTags));
  const isRepair = !!flags.repair || sourceTags.includes('repair') || sourceTags.includes('engineer') || sourceTags.includes('structure');
  queueConquestActionEvent(isRepair ? 'repair' : 'heal', {
    side: String(sourceOcc?.side ?? targetOcc?.side ?? 'defender'),
    sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
    targetIndex: targetIndex >= 0 ? targetIndex : null,
    amount: applied,
    sourceTags,
    life: 720,
  });
  return {
    applied: true,
    amount: applied,
    targetHp: Math.max(0, Number(targetOcc.hp ?? 0)),
  };
}

function applyFacilityDamage(state, targetOcc, amount, sourceOcc = null, flags = {}) {
  const dmg = Math.max(0, Number(amount ?? 0));
  if (!targetOcc || dmg <= 0) return { applied: false, damage: 0, killed: false, targetHp: Math.max(0, Number(targetOcc?.hp ?? 0)) };
  const targetIndex = findFacilityOccupantIndex(state, targetOcc);
  const sourceIndex = findFacilityOccupantIndex(state, sourceOcc);
  const explosive = !!flags.explosive;
  const isHorde = toArray(targetOcc.tags).includes('horde');
  const side = String(sourceOcc?.side ?? (targetOcc?.side === 'attacker' ? 'defender' : 'attacker'));
  const vfxProfile = resolveConquestAttackVfxProfile(sourceOcc, targetOcc, flags);
  const attackClass = String(flags.attackClass ?? vfxProfile.attackClass);
  const projectileKind = String(flags.projectileKind ?? vfxProfile.projectileKind);
  const impactKind = String(flags.impactKind ?? vfxProfile.impactKind);
  let finalDamage = dmg;
  queueConquestActionEvent('attack-start', {
    side,
    sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
    targetIndex: targetIndex >= 0 ? targetIndex : null,
    attackClass,
    projectileKind,
    impactKind,
    sourceTags: vfxProfile.sourceTags,
    targetTags: vfxProfile.targetTags,
    life: explosive ? 720 : 460,
  });
  queueConquestActionEvent('projectile-fire', {
    side,
    sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
    targetIndex: targetIndex >= 0 ? targetIndex : null,
    attackClass,
    projectileKind,
    sourceTags: vfxProfile.sourceTags,
    targetTags: vfxProfile.targetTags,
    life: 420,
  });
  if (attackClass === 'turret') {
    queueConquestActionEvent('turret-fire', {
      side,
      sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
      targetIndex: targetIndex >= 0 ? targetIndex : null,
      attackClass,
      projectileKind,
      sourceTags: vfxProfile.sourceTags,
      life: 420,
    });
  }
  if (vfxProfile.antiAir) {
    queueConquestActionEvent(vfxProfile.barrage ? 'anti-barrage' : 'anti-air-fire', {
      side,
      sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
      targetIndex: targetIndex >= 0 ? targetIndex : null,
      attackClass,
      projectileKind,
      sourceTags: vfxProfile.sourceTags,
      life: vfxProfile.barrage ? 860 : 520,
    });
  }
  if (explosive && isHorde) {
    const maxHp = Math.max(1, Number(targetOcc.maxHp ?? targetOcc.hp ?? 1));
    finalDamage = Math.max(5, Math.round(5 + (maxHp * 0.2)));
    targetOcc.status = targetOcc.status ?? {};
    targetOcc.status.moraleStunned = 1;
  }
  queueConquestActionEvent('impact', {
    side,
    sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
    targetIndex: targetIndex >= 0 ? targetIndex : null,
    attackClass,
    projectileKind,
    impactKind,
    sourceTags: vfxProfile.sourceTags,
    targetTags: vfxProfile.targetTags,
    life: explosive ? 720 : 520,
  });
  if (vfxProfile.explosive || attackClass === 'explosive' || attackClass === 'anti-barrage') {
    queueConquestActionEvent('explosive-impact', {
      side,
      sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
      targetIndex: targetIndex >= 0 ? targetIndex : null,
      attackClass,
      projectileKind,
      impactKind,
      sourceTags: vfxProfile.sourceTags,
      targetTags: vfxProfile.targetTags,
      shakePower: Math.max(4, Number(vfxProfile.shakePower ?? 6)),
      shakeDuration: Math.max(200, Number(vfxProfile.shakeDuration ?? 260)),
      life: 760,
    });
  } else if (Number(vfxProfile.shakePower ?? 0) > 0) {
    queueConquestActionEvent('impact', {
      side,
      sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
      targetIndex: targetIndex >= 0 ? targetIndex : null,
      attackClass,
      projectileKind,
      impactKind,
      shakePower: Math.max(1.2, Number(vfxProfile.shakePower ?? 2)),
      shakeDuration: Math.max(130, Number(vfxProfile.shakeDuration ?? 160)),
      life: 480,
    });
  }
  targetOcc.hp = Math.max(0, Number(targetOcc.hp ?? 0) - finalDamage);
  const killed = Number(targetOcc.hp ?? 0) <= 0;
  queueConquestActionEvent('damage', {
    side,
    sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
    targetIndex: targetIndex >= 0 ? targetIndex : null,
    amount: finalDamage,
    attackClass,
    projectileKind,
    impactKind,
    sourceTags: vfxProfile.sourceTags,
    targetTags: vfxProfile.targetTags,
    lethal: killed,
    heavy: finalDamage >= Math.max(4, Math.round(Number(targetOcc.maxHp ?? targetOcc.hp ?? 1) * 0.4)),
    life: 760,
  });
  if (isHorde) {
    const ratio = Math.max(0, Number(targetOcc.hp ?? 0)) / Math.max(1, Number(targetOcc.maxHp ?? 1));
    targetOcc.atk = Math.max(1, Math.round(Number(targetOcc.baseAtk ?? targetOcc.atk ?? 1) * ratio));
  }
  if (targetOcc.hp <= 0) {
    targetOcc._dead = true;
    queueConquestActionEvent('death', {
      side,
      sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
      targetIndex: targetIndex >= 0 ? targetIndex : null,
      attackClass,
      sourceTags: vfxProfile.sourceTags,
      targetTags: vfxProfile.targetTags,
      life: 620,
    });
    queueConquestActionEvent('kill', {
      side,
      sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
      targetIndex: targetIndex >= 0 ? targetIndex : null,
      attackClass,
      sourceTags: vfxProfile.sourceTags,
      targetTags: vfxProfile.targetTags,
      life: 640,
    });
    const targetTagSet = new Set(vfxProfile.targetTags);
    if (targetTagSet.has('barricade') || targetTagSet.has('wall')) {
      queueConquestActionEvent('barricade-break', {
        side,
        sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
        targetIndex: targetIndex >= 0 ? targetIndex : null,
        attackClass,
        sourceTags: vfxProfile.sourceTags,
        targetTags: vfxProfile.targetTags,
        shakePower: Math.max(3.8, Number(vfxProfile.shakePower ?? 4.5)),
        shakeDuration: 220,
        life: 760,
      });
    } else if (targetTagSet.has('structure') || targetOcc.type === 'building' || targetTagSet.has('turret') || targetTagSet.has('facility')) {
      queueConquestActionEvent('structure-break', {
        side,
        sourceIndex: sourceIndex >= 0 ? sourceIndex : null,
        targetIndex: targetIndex >= 0 ? targetIndex : null,
        attackClass,
        sourceTags: vfxProfile.sourceTags,
        targetTags: vfxProfile.targetTags,
        shakePower: Math.max(3.2, Number(vfxProfile.shakePower ?? 4)),
        shakeDuration: 200,
        life: 720,
      });
    }
    facilityLog(state, `${sourceOcc?.name ?? 'Unit'} destroyed ${targetOcc.name}.`, targetOcc.side === 'defender' ? 'bad' : 'good');
  }
  return {
    applied: true,
    damage: finalDamage,
    killed,
    targetHp: Math.max(0, Number(targetOcc.hp ?? 0)),
  };
}

function removeDeadFacilityOccupants(state) {
  let storageChanged = false;
  state.grid.forEach((cell) => {
    if (cell?.occupant?._dead) {
      if (cell.occupant.side === 'defender' && toArray(cell.occupant.tags).includes('storage')) {
        storageChanged = true;
      }
      cell.occupant = null;
    }
  });
  if (storageChanged) {
    const capInfo = syncDefenderResourceCaps(state, { clampOverflow: true });
    const overflowNote = (capInfo.lostWheat > 0 || capInfo.lostIron > 0)
      ? ` Overflow discarded W${capInfo.lostWheat}/I${capInfo.lostIron}.`
      : '';
    facilityLog(state, `[Storage] Capacity adjusted to W${capInfo.wheatCap}/I${capInfo.ironCap}.${overflowNote}`, 'warn');
  }
}

function activeFacilityUnits(state, side) {
  const list = [];
  state.grid.forEach((cell, idx) => {
    const occ = cell?.occupant;
    if (!occ || occ.side !== side) return;
    if (occ.status?.moraleStunned > 0) return;
    list.push({ idx, cell, occ, ...facilityCellFromIndex(idx) });
  });
  return list;
}

function attackerPylonCount(state) {
  let total = 0;
  state.grid.forEach((cell) => {
    const occ = cell?.occupant;
    if (!occ || occ.side !== 'attacker' || Number(occ.hp ?? 0) <= 0) return;
    const tags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
    const isPylon = occ.type === 'pylon' || tags.has('pylon') || String(occ.subtype ?? '').toLowerCase().includes('mana pylon');
    if (!isPylon) return;
    const value = Math.max(1, Number(occ.status?.pylonValue ?? (tags.has('elite') ? 2 : 1)));
    total += value;
  });
  return Math.max(0, total);
}

function resolveFacilityAttacksForSide(state, side) {
  const units = activeFacilityUnits(state, side);
  units.forEach(({ idx, occ }) => {
    if (!occ || occ.hp <= 0) return;
    if (occ.status?.disabledTurns > 0) return;
    occ.status = occ.status ?? {};
    if (Number(occ.status.actedTurn ?? 0) === Number(state.turn ?? 1)) return;
    const targets = collectConquestAttackTargets(state, idx, occ);
    if (!targets.length) return;
    const targetPick = targets[0];
    const damage = targetPick.damage ?? facilityDamageValue(occ, targetPick.occupant);
    applyFacilityDamage(state, targetPick.occupant, damage, occ, {});
    occ.status.actedTurn = Number(state.turn ?? 1);
  });
  removeDeadFacilityOccupants(state);
}

function moveFacilityUnits(state, side, aiTier = 2) {
  const units = activeFacilityUnits(state, side)
    .filter(({ occ }) => occ.type === 'unit' || toArray(occ.tags).includes('ground') || toArray(occ.tags).includes('air'))
    .sort((a, b) => side === 'defender' ? a.col - b.col : b.col - a.col);
  units.forEach(({ idx, occ, row, col }) => {
    occ.status = occ.status ?? {};
    if (Number(occ.status.actedTurn ?? 0) === Number(state.turn ?? 1)) return;
    const legalMoves = listLegalUnitMoves(state, idx, occ);
    if (!legalMoves.length) return;
    const rangeProfile = resolveConquestRangeProfile(occ);
    const chooseMove = () => {
      if (aiTier <= 1) return legalMoves[Math.floor(Math.random() * legalMoves.length)];
      if (aiTier <= 2) return legalMoves.find((entry) => entry.dir === 'forward') ?? legalMoves.find((entry) => entry.dir === 'left' || entry.dir === 'right') ?? legalMoves[0];
      let best = legalMoves[0];
      let bestScore = -Infinity;
      legalMoves.forEach((entry) => {
        let score = 0;
        if (entry.dir === 'forward' || entry.dir === 'barricade-pass') score += aiTier >= 4 ? 7 : 5;
        if (entry.dir === 'left' || entry.dir === 'right') score += 2;
        if (entry.dir === 'backward') score += 1;
        const owner = state.grid[entry.idx]?.owner;
        if (owner && owner !== side) score += 3;
        const previewTargetIdx = facilityCellIndex(entry.row, entry.col);
        const targets = collectConquestAttackTargets(state, previewTargetIdx, occ);
        if (targets.length) score += 4;
        if (aiTier >= 4) {
          const enemyFront = side === 'defender' ? entry.col - 1 : entry.col + 1;
          if (enemyFront >= 0 && enemyFront < CONQUEST_GRID_COLS) {
            const frontOcc = state.grid[facilityCellIndex(entry.row, enemyFront)]?.occupant;
            if (frontOcc && frontOcc.side !== side && toArray(frontOcc.tags).includes('turret')) score -= 4;
          }
        }
        const hasAdjacentEnemy = [
          { r: entry.row, c: entry.col + (side === 'defender' ? -1 : 1) },
          { r: entry.row - 1, c: entry.col },
          { r: entry.row + 1, c: entry.col },
        ].some((p) => p.r >= 0 && p.r < CONQUEST_GRID_ROWS && p.c >= 0 && p.c < CONQUEST_GRID_COLS && state.grid[facilityCellIndex(p.r, p.c)]?.occupant?.side !== side && state.grid[facilityCellIndex(p.r, p.c)]?.occupant);
        if (rangeProfile.min > 1 && hasAdjacentEnemy) score -= 3;
        if (score > bestScore) {
          bestScore = score;
          best = entry;
        }
      });
      return best;
    };
    const next = chooseMove();
    if (!next) return;
    const prevOwner = String(state.grid[next.idx]?.owner ?? 'neutral');
    state.grid[next.idx].occupant = occ;
    state.grid[next.idx].owner = side;
    state.grid[idx].occupant = null;
    if (state.grid[idx].owner === side) state.grid[idx].owner = 'neutral';
    occ.status.actedTurn = Number(state.turn ?? 1);
    queueConquestActionEvent('move', {
      side,
      sourceIndex: idx,
      targetIndex: next.idx,
      cardName: occ?.name ?? 'Unit',
      sourceTags: conquestVfxTagArray(occ),
      life: 420,
    });
    if (prevOwner !== side) {
      queueConquestActionEvent('capture', {
        side,
        sourceIndex: idx,
        targetIndex: next.idx,
        cellIndex: next.idx,
        cardName: occ?.name ?? 'Unit',
        sourceTags: conquestVfxTagArray(occ),
        life: 620,
      });
    }
    facilityLog(state, `${occ.name} repositioned ${next.dir}.`, side === 'defender' ? 'good' : 'bad');
  });
}

function applyFacilityResourceTick(state) {
  if (!state.underAttack) return;
  const profile = loadProfile();
  const defenderOcc = state.grid
    .map((cell) => cell?.occupant)
    .filter((occ) => occ?.side === 'defender');
  const capInfo = syncDefenderResourceCaps(state, { clampOverflow: true });
  if (capInfo.lostWheat > 0 || capInfo.lostIron > 0) {
    facilityLog(state, `[Storage] Capacity reduced. Overflow discarded W${capInfo.lostWheat}/I${capInfo.lostIron}.`, 'warn');
  }
  let wheatGain = 0;
  let ironGain = 0;
  const gainSources = [];
  defenderOcc.forEach((occ) => {
    const card = conquestCardById(profile, occ.cardId);
    const baseWheat = Math.max(0, Number(card?.production?.wheatPerTurn ?? 0));
    const baseIron = Math.max(0, Number(card?.production?.ironPerTurn ?? 0));
    const bonusWheat = Math.max(0, Number(occ.status?.wheatPerTurnBonus ?? 0));
    const bonusIron = Math.max(0, Number(occ.status?.ironPerTurnBonus ?? 0));
    const w = baseWheat + bonusWheat;
    const i = baseIron + bonusIron;
    wheatGain += w;
    ironGain += i;
    if (w > 0 || i > 0) gainSources.push(`${occ.name} (+W${w}/I${i})`);
  });
  const prevWheat = Math.max(0, Number(state.defender.wheat ?? 0));
  const prevIron = Math.max(0, Number(state.defender.iron ?? 0));
  state.defender.wheat = Math.min(state.defender.wheatCap, prevWheat + wheatGain);
  state.defender.iron = Math.min(state.defender.ironCap, prevIron + ironGain);
  if (wheatGain > 0 || ironGain > 0) {
    facilityLog(
      state,
      `[Economy] +W${wheatGain}/+I${ironGain} • ${prevWheat}->${state.defender.wheat} Wheat, ${prevIron}->${state.defender.iron} Iron.${gainSources.length ? ` Sources: ${gainSources.slice(0, 4).join(', ')}${gainSources.length > 4 ? '…' : ''}` : ''}`,
      'info',
    );
    queueConquestActionEvent('resource', {
      side: 'defender',
      amountWheat: wheatGain,
      amountIron: ironGain,
      life: 860,
    });
  }
}

function pickConquestDeckDrawIndex(state, deckKey, deck = []) {
  if (!Array.isArray(deck) || !deck.length) return -1;
  if (deck.length === 1) return 0;
  const history = toArray(state?.defender?.drawHistory?.[deckKey]).map((entry) => String(entry));
  const recent = history.slice(-2);
  const candidates = [];
  for (let i = 0; i < deck.length; i += 1) {
    const cardId = String(deck[i]);
    if (!recent.includes(cardId)) candidates.push(i);
  }
  const pool = candidates.length ? candidates : Array.from({ length: deck.length }, (_, i) => i);
  return pool[Math.floor(Math.random() * pool.length)];
}

function recordConquestDeckDraw(state, deckKey, cardId) {
  state.defender = state.defender ?? {};
  state.defender.drawHistory = state.defender.drawHistory ?? {};
  const list = Array.isArray(state.defender.drawHistory[deckKey]) ? state.defender.drawHistory[deckKey] : [];
  list.push(String(cardId));
  state.defender.drawHistory[deckKey] = list.slice(-12);
}

function hasLivingDefenderFacility(state, cardIds = []) {
  const required = new Set((Array.isArray(cardIds) ? cardIds : []).map((entry) => normalizeConquestCardId(String(entry))));
  if (!required.size) return true;
  return toArray(state?.grid).some((cell) => {
    const occ = cell?.occupant;
    if (!occ || String(occ.side ?? '') !== 'defender') return false;
    if (Number(occ.hp ?? 0) <= 0) return false;
    return required.has(normalizeConquestCardId(String(occ.cardId ?? '')));
  });
}

function conquestDeckDrawReadout(state, deckKey) {
  const key = String(deckKey ?? '').trim().toLowerCase();
  if (!key) return { ok: false, message: 'Unknown deck source.' };
  const requirement = CONQUEST_FACILITY_DRAW_REQUIREMENTS[key];
  if (!requirement) return { ok: true, message: '' };
  const requiredIds = toArray(requirement.buildingIds);
  if (!requiredIds.length) return { ok: true, message: '' };
  if (hasLivingDefenderFacility(state, requiredIds)) return { ok: true, message: '' };
  return {
    ok: false,
    message: `${requirement.facilityLabel} must be deployed and standing before drawing from ${CONQUEST_DECK_DRAW_LABELS[key] ?? key}.`,
  };
}

function drawConquestCardDirect(state, deckKey, count = 1) {
  const drawn = [];
  const profile = loadProfile();
  const deck = state.defender.drawDecks?.[deckKey];
  if (!Array.isArray(deck) || !deck.length) return drawn;
  const pulls = Math.max(1, Number(count ?? 1));
  for (let i = 0; i < pulls; i += 1) {
    if (!deck.length) break;
    const drawIdx = pickConquestDeckDrawIndex(state, deckKey, deck);
    if (drawIdx < 0) break;
    const cardId = normalizeConquestCardId(String(deck.splice(drawIdx, 1)[0]));
    const card = conquestCardById(profile, cardId);
    if (!card) continue;
    const instanceId = `${card.id}-${Date.now()}-${Math.floor(Math.random() * 9999)}`;
    state.defender.hand.push({ instanceId, cardId: card.id });
    recordConquestDeckDraw(state, deckKey, card.id);
    state.lastDraw = { instanceId, cardId: card.id, deckKey, ts: Date.now(), source: 'direct' };
    drawn.push(card.name);
  }
  return drawn;
}

function drawConquestCard(state, deckKey) {
  if (state.phase === 'setup') return { ok: false, message: 'Finish setup phase before drawing production cards.' };
  if (state.side !== 'defender') return { ok: false, message: 'You can only draw during defender turn.' };
  if (state.drawActionsLeft <= 0) return { ok: false, message: 'No draw actions left this turn.' };
  const drawGate = conquestDeckDrawReadout(state, deckKey);
  if (!drawGate.ok) return { ok: false, message: drawGate.message };
  if (deckKey === 'blacksmith' && Number(state.defender.blacksmithDrawnOnTurn ?? 0) >= 1) {
    return { ok: false, message: 'Blacksmith can only draw once per turn.' };
  }
  const deck = state.defender.drawDecks?.[deckKey];
  if (!Array.isArray(deck) || !deck.length) return { ok: false, message: `${deckKey} deck is empty.` };
  const drawIdx = pickConquestDeckDrawIndex(state, deckKey, deck);
  if (drawIdx < 0) return { ok: false, message: `${deckKey} deck is empty.` };
  const cardId = normalizeConquestCardId(String(deck.splice(drawIdx, 1)[0]));
  const card = conquestCardById(loadProfile(), cardId);
  if (!card) return { ok: false, message: 'Card blueprint missing.' };
  const instanceId = `${card.id}-${Date.now()}-${Math.floor(Math.random() * 9999)}`;
  state.defender.hand.push({ instanceId, cardId: card.id });
  recordConquestDeckDraw(state, deckKey, card.id);
  state.drawActionsLeft = Math.max(0, Number(state.drawActionsLeft ?? DEFENDER_MAX_DRAWS_PER_TURN) - 1);
  if (deckKey === 'blacksmith') state.defender.blacksmithDrawnOnTurn = Math.max(0, Number(state.defender.blacksmithDrawnOnTurn ?? 0)) + 1;
  state.lastDraw = { instanceId, cardId: card.id, deckKey, ts: Date.now(), source: 'production' };
  facilityLog(state, `[Draw:${String(deckKey).toUpperCase()}] ${card.name}`, 'info');
  return { ok: true, instanceId, cardId: card.id, deckKey };
}

function conquestAttackReadout(state, cellIndex) {
  const cell = state?.grid?.[cellIndex];
  const occ = cell?.occupant;
  if (!occ) return { canAttack: false, reason: 'Empty cell.', target: null, targetCellIndex: null, targets: [] };
  if (Number(occ.hp ?? 0) <= 0) return { canAttack: false, reason: 'Unit is destroyed.', target: null, targetCellIndex: null, targets: [] };
  if (Number(occ.status?.disabledTurns ?? 0) > 0) return { canAttack: false, reason: `Disabled for ${occ.status.disabledTurns} turn(s).`, target: null, targetCellIndex: null, targets: [] };
  if (Number(occ.status?.moraleStunned ?? 0) > 0) return { canAttack: false, reason: `Shaken for ${occ.status.moraleStunned} turn(s).`, target: null, targetCellIndex: null, targets: [] };
  if (Number(occ.status?.actedTurn ?? 0) === Number(state?.turn ?? 1)) return { canAttack: false, reason: `${occ.name} already used its action this turn.`, target: null, targetCellIndex: null, targets: [] };
  if (
    Number(occ.status?.deployedTurn ?? 0) === Number(state?.turn ?? 1)
    && !conquestHasRapidEntry(occ)
  ) {
    return { canAttack: false, reason: `${occ.name} is freshly deployed and cannot attack this turn.`, target: null, targetCellIndex: null, targets: [] };
  }
  const side = String(occ.side ?? '');
  if (side !== 'defender' && side !== 'attacker') return { canAttack: false, reason: 'No combat side assigned.', target: null, targetCellIndex: null, targets: [] };
  if (state?.side && String(state.side) !== side) {
    return { canAttack: false, reason: `It is currently ${String(state.side)} turn.`, target: null, targetCellIndex: null, targets: [] };
  }
  const targets = collectConquestAttackTargets(state, cellIndex, occ);
  if (!targets.length) {
    const rangeProfile = resolveConquestRangeProfile(occ);
    const rangeText = rangeProfile.min === rangeProfile.max
      ? `range ${rangeProfile.max}`
      : `range ${rangeProfile.min}-${rangeProfile.max}`;
    return {
      canAttack: false,
      reason: `No enemy in 3x3 strike zone or lane ${rangeText}.`,
      target: null,
      targetCellIndex: null,
      targets: [],
    };
  }
  const preferred = Number.isInteger(modalUiState.facilityWar.inspectCellIndex)
    ? targets.find((entry) => entry.idx === Number(modalUiState.facilityWar.inspectCellIndex))
    : null;
  const chosen = preferred ?? targets[0];
  return {
    canAttack: true,
    reason: `Attack ready. ${targets.length} legal target${targets.length === 1 ? '' : 's'} in reach.`,
    target: chosen.occupant,
    targetCellIndex: chosen.idx,
    targets,
  };
}

function runFacilityManualAttack(state, sourceCellIndex, preferredTargetCellIndex = null) {
  if (!Number.isInteger(sourceCellIndex)) return { ok: false, message: 'Select a unit or turret first.' };
  const sourceCell = state.grid[sourceCellIndex];
  const sourceOcc = sourceCell?.occupant;
  if (!sourceOcc || sourceOcc.side !== 'defender') return { ok: false, message: 'Select a friendly defender unit or turret.' };
  const readout = conquestAttackReadout(state, sourceCellIndex);
  if (!readout.canAttack) return { ok: false, message: readout.reason || 'Attack not legal.' };
  const legalTargets = toArray(readout.targets);
  const fallbackTargetIdx = readout.targetCellIndex;
  const targetCellIndex = Number.isInteger(preferredTargetCellIndex) ? preferredTargetCellIndex : fallbackTargetIdx;
  const targetMeta = legalTargets.find((entry) => Number(entry.idx) === Number(targetCellIndex));
  if (!targetMeta || !Number.isInteger(targetCellIndex)) {
    return { ok: false, message: 'Choose a legal enemy target in highlighted range.' };
  }
  const targetCell = state.grid[targetCellIndex];
  const targetOcc = targetCell?.occupant;
  if (!targetOcc || targetOcc.side === sourceOcc.side) return { ok: false, message: 'No enemy target in selected cell.' };
  const expectedDamage = targetMeta.damage ?? facilityDamageValue(sourceOcc, targetOcc);
  const damageResult = applyFacilityDamage(state, targetOcc, expectedDamage, sourceOcc, {});
  sourceOcc.status = sourceOcc.status ?? {};
  sourceOcc.status.actedTurn = Number(state.turn ?? 1);
  const dealt = Math.max(0, Number(damageResult?.damage ?? expectedDamage));
  const targetHpNow = Math.max(0, Number(targetOcc.hp ?? 0));
  const targetHpMax = Math.max(1, Number((targetOcc.maxHp ?? targetHpNow) || 1));
  const destroyed = !!damageResult?.killed || Number(targetOcc._dead ?? 0) > 0;
  removeDeadFacilityOccupants(state);
  facilityLog(
    state,
    `[Attack] ${sourceOcc.name} hit ${targetOcc.name} for ${dealt}. ${destroyed ? 'Destroyed.' : `HP ${targetHpNow}/${targetHpMax}.`}`,
    'good',
  );
  return { ok: true, sourceCellIndex, targetCellIndex };
}

function isFacilityStructureCard(entry = {}) {
  const tags = new Set(toArray(entry.tags).map((tag) => String(tag).toLowerCase()));
  const type = String(entry.type ?? '').toLowerCase();
  return type === 'building'
    || type === 'pylon'
    || tags.has('structure')
    || tags.has('facility')
    || tags.has('barricade')
    || tags.has('turret')
    || tags.has('fortress');
}

function getFacilityDeconstructReadout(state, cellIndex) {
  if (!Number.isInteger(cellIndex)) return { ok: false, message: 'Select a cell to deconstruct.' };
  const cell = state.grid[cellIndex];
  const occ = cell?.occupant;
  if (!occ) return { ok: false, message: 'Selected cell is empty.' };
  if (occ.side !== 'defender') return { ok: false, message: 'Only friendly defender structures can be deconstructed.' };
  if (!isFacilityStructureCard(occ)) return { ok: false, message: 'Only structures/facilities can be deconstructed.' };
  if (String(state.phase ?? '') === 'resolved') return { ok: false, message: 'Battle already resolved.' };
  return { ok: true, occupant: occ };
}

function deconstructFacilityCard(state, profile, cellIndex) {
  const readout = getFacilityDeconstructReadout(state, cellIndex);
  if (!readout.ok) return readout;
  const occ = readout.occupant;
  const card = conquestCardById(profile, occ.cardId);
  const wasStorage = toArray(occ.tags).includes('storage');
  const inSetup = String(state.phase ?? '') === 'setup';
  const isStarter = FACILITY_SETUP_STARTER_CARDS.some((entry) => entry.id === occ.cardId);
  const cell = state.grid[cellIndex];
  cell.occupant = null;
  if (cell.owner === 'defender') cell.owner = 'neutral';
  const capInfo = wasStorage ? syncDefenderResourceCaps(state, { clampOverflow: true }) : null;
  queueConquestActionEvent('deconstruct', {
    side: 'defender',
    cardName: occ?.name ?? 'Deconstruct',
    sourceTags: conquestVfxTagArray(occ),
    cellIndex,
    life: 560,
  });
  if (inSetup || isStarter) {
    state.defender.hand.push({
      instanceId: `${occ.cardId}-reclaim-${Date.now()}-${Math.floor(Math.random() * 9999)}`,
      cardId: normalizeConquestCardId(occ.cardId),
    });
    if (capInfo && (capInfo.previousWheatCap !== capInfo.wheatCap || capInfo.previousIronCap !== capInfo.ironCap)) {
      facilityLog(state, `[Storage] Capacity adjusted to W${capInfo.wheatCap}/I${capInfo.ironCap}.`, 'warn');
    }
    facilityLog(state, `[Deconstruct] ${occ.name} removed and returned to hand.`, 'warn');
    return { ok: true, message: `${occ.name} returned to hand.` };
  }
  const refundWheat = Math.floor(Math.max(0, Number(card?.cost?.wheat ?? 0)) * 0.5);
  const refundIron = Math.floor(Math.max(0, Number(card?.cost?.iron ?? 0)) * 0.5);
  if (refundWheat > 0) state.defender.wheat = Math.min(Number(state.defender.wheatCap ?? 10), Number(state.defender.wheat ?? 0) + refundWheat);
  if (refundIron > 0) state.defender.iron = Math.min(Number(state.defender.ironCap ?? 10), Number(state.defender.iron ?? 0) + refundIron);
  if (capInfo && (capInfo.previousWheatCap !== capInfo.wheatCap || capInfo.previousIronCap !== capInfo.ironCap)) {
    const overflowNote = (capInfo.lostWheat > 0 || capInfo.lostIron > 0)
      ? ` Overflow discarded W${capInfo.lostWheat}/I${capInfo.lostIron}.`
      : '';
    facilityLog(state, `[Storage] Capacity adjusted to W${capInfo.wheatCap}/I${capInfo.ironCap}.${overflowNote}`, 'warn');
  }
  facilityLog(state, `[Deconstruct] ${occ.name} removed. Refund +W${refundWheat}/I${refundIron}.`, 'warn');
  return { ok: true, message: `${occ.name} deconstructed. Refund +W${refundWheat}/I${refundIron}.` };
}

function canDefenderPlaceAtDetailed(state, card, row, col) {
  if (!Number.isFinite(Number(row)) || !Number.isFinite(Number(col))) return { ok: false, message: 'Invalid placement coordinates.' };
  if (row < 0 || row >= CONQUEST_GRID_ROWS || col < 0 || col >= CONQUEST_GRID_COLS) return { ok: false, message: 'Placement is outside battlefield bounds.' };
  if (conquestIsNoMansLandCol(col)) return { ok: false, message: 'No Man’s Land does not allow direct placement. Move or capture into it.' };
  if (!conquestCanDeployAt('defender', col)) return { ok: false, message: 'Defender cards can only be placed in defender deployment columns.' };
  const idx = facilityCellIndex(row, col);
  const cell = state.grid[idx];
  if (!cell) return { ok: false, message: 'Target cell unavailable.' };
  if (cell.occupant) return { ok: false, message: `Cell occupied by ${cell.occupant.name}.` };
  return { ok: true };
}

function canDefenderPlaceAt(state, card, row, col) {
  return canDefenderPlaceAtDetailed(state, card, row, col).ok;
}

function spendDefenderResource(state, card) {
  const plan = computeDefenderSpendPreview(state, card);
  if (plan.setupBypass) return { ok: true };
  if (!plan.affordable) return { ok: false, message: plan.message || 'Insufficient resources.' };
  if (plan.trainingDiscountUsed > 0) {
    state.defender.trainingDiscountCharges = Math.max(0, Number(state.defender.trainingDiscountCharges ?? 0) - plan.trainingDiscountUsed);
  }
  if (plan.tempWheatUsed > 0) {
    state.defender.tempWheatDiscount = Math.max(0, Number(state.defender.tempWheatDiscount ?? 0) - plan.tempWheatUsed);
  }
  if (plan.tempIronUsed > 0) {
    state.defender.tempIronDiscount = Math.max(0, Number(state.defender.tempIronDiscount ?? 0) - plan.tempIronUsed);
  }
  state.defender.wheat = Math.max(0, Number(state.defender.wheat ?? 0) - plan.wheat);
  state.defender.iron = Math.max(0, Number(state.defender.iron ?? 0) - plan.iron);
  return { ok: true };
}

function resolveDefenderTacticCard(state, card, cellIndex) {
  const tactic = card.tactic && typeof card.tactic === 'object' ? card.tactic : {};
  const targetCell = Number.isInteger(cellIndex) ? state.grid[cellIndex] : null;
  const targetOcc = targetCell?.occupant ?? null;
  const kind = String(tactic.kind ?? '').toLowerCase();
  const sourceActor = {
    name: card?.name ?? 'Defender Tactic',
    side: 'defender',
    tags: conquestVfxTagArray(card),
  };
  if (kind) {
    queueConquestActionEvent('ability-trigger', {
      side: 'defender',
      cardName: card?.name ?? 'Tactic',
      actionType: kind,
      targetIndex: Number.isInteger(cellIndex) ? cellIndex : null,
      sourceTags: sourceActor.tags,
      life: 520,
    });
  }
  if (kind === 'draw') {
    const deck = String(tactic.deck ?? 'training');
    const count = Math.max(1, Number(tactic.count ?? 1));
    const drawn = drawConquestCardDirect(state, deck, count);
    if (tactic.wheatDiscount) state.defender.tempWheatDiscount = Math.max(0, Number(state.defender.tempWheatDiscount ?? 0) + Number(tactic.wheatDiscount));
    if (tactic.ironDiscount) state.defender.tempIronDiscount = Math.max(0, Number(state.defender.tempIronDiscount ?? 0) + Number(tactic.ironDiscount));
    return { ok: true, message: drawn.length ? `Drew ${drawn.join(', ')}.` : `${deck} deck empty.` };
  }
  if (kind === 'add-hand' && tactic.cardId) {
    const count = Math.max(1, Number(tactic.count ?? 1));
    for (let i = 0; i < count; i += 1) {
      state.defender.hand.push({ instanceId: `${tactic.cardId}-${Date.now()}-${Math.floor(Math.random() * 9999)}`, cardId: String(tactic.cardId) });
    }
    return { ok: true, message: `Added ${count} card(s) to hand.` };
  }
  if (kind === 'resource') {
    const wheatGain = Math.max(0, Number(tactic.wheat ?? 0));
    const ironGain = Math.max(0, Number(tactic.iron ?? 0));
    state.defender.wheat = Math.min(state.defender.wheatCap, Number(state.defender.wheat ?? 0) + wheatGain);
    state.defender.iron = Math.min(state.defender.ironCap, Number(state.defender.iron ?? 0) + ironGain);
    if (tactic.drawDeck) drawConquestCardDirect(state, String(tactic.drawDeck), Number(tactic.drawCount ?? 1));
    return { ok: true, message: `Resources +W${wheatGain}/I${ironGain}.` };
  }
  if (kind === 'repair') {
    const repeats = Math.max(1, Number(tactic.repeats ?? 1));
    const amount = Math.max(1, Number(tactic.amount ?? 2));
    let applied = 0;
    for (let i = 0; i < repeats; i += 1) {
      const pick = i === 0 && targetOcc?.side === 'defender'
        ? targetOcc
        : state.grid.map((cell) => cell?.occupant).find((occ) => occ?.side === 'defender' && Number(occ.hp ?? 0) < Number(occ.maxHp ?? occ.hp ?? 0));
      if (!pick) continue;
      const healResult = applyFacilityHeal(state, pick, amount, sourceActor, { repair: true, sourceTags: sourceActor.tags });
      if (healResult.applied) applied += 1;
    }
    return applied ? { ok: true, message: `Repaired ${applied} target(s).` } : { ok: false, message: 'No damaged friendly target for repair.' };
  }
  if (kind === 'global-repair') {
    const amount = Math.max(1, Number(tactic.amount ?? 2));
    const targets = state.grid
      .map((cell) => cell?.occupant)
      .filter((occ) => occ?.side === 'defender' && Number(occ.hp ?? 0) < Number(occ.maxHp ?? occ.hp ?? 0));
    targets.forEach((occ) => applyFacilityHeal(state, occ, amount, sourceActor, { repair: true, sourceTags: sourceActor.tags }));
    return targets.length
      ? { ok: true, message: `Mass repair restored ${targets.length} target(s).` }
      : { ok: false, message: 'No damaged friendly targets for mass repair.' };
  }
  if (kind === 'buff') {
    if (!targetOcc || targetOcc.side !== 'defender') return { ok: false, message: 'Select a friendly target for buff.' };
    targetOcc.atk = Math.max(0, Number(targetOcc.atk ?? 0) + Math.max(0, Number(tactic.attack ?? card.attack ?? 0)));
    targetOcc.def = Math.max(0, Number(targetOcc.def ?? 0) + Math.max(0, Number(tactic.defense ?? card.defense ?? 0)));
    const hpBoost = Math.max(0, Number(tactic.health ?? card.health ?? 0));
    if (hpBoost > 0) {
      targetOcc.maxHp = Math.max(1, Number(targetOcc.maxHp ?? targetOcc.hp ?? 1) + hpBoost);
      applyFacilityHeal(state, targetOcc, hpBoost, sourceActor, { sourceTags: sourceActor.tags });
    }
    if (Math.max(0, Number(tactic.defense ?? card.defense ?? 0)) > 0) {
      queueConquestActionEvent('shield-gain', {
        side: 'defender',
        targetIndex: findFacilityOccupantIndex(state, targetOcc),
        amount: Math.max(0, Number(tactic.defense ?? card.defense ?? 0)),
        sourceTags: sourceActor.tags,
        life: 620,
      });
    }
    return { ok: true, message: `${targetOcc.name} buffed.` };
  }
  if (kind === 'global-buff') {
    const atkGain = Math.max(0, Number(tactic.attack ?? card.attack ?? 0));
    const defGain = Math.max(0, Number(tactic.defense ?? card.defense ?? 0));
    const hpGain = Math.max(0, Number(tactic.health ?? card.health ?? 0));
    const targets = state.grid.map((cell) => cell?.occupant).filter((occ) => occ?.side === 'defender');
    targets.forEach((occ) => {
      occ.atk = Math.max(0, Number(occ.atk ?? 0) + atkGain);
      occ.def = Math.max(0, Number(occ.def ?? 0) + defGain);
      if (hpGain > 0) {
        occ.maxHp = Math.max(1, Number(occ.maxHp ?? occ.hp ?? 1) + hpGain);
        applyFacilityHeal(state, occ, hpGain, sourceActor, { sourceTags: sourceActor.tags });
      }
      if (defGain > 0) {
        queueConquestActionEvent('shield-gain', {
          side: 'defender',
          targetIndex: findFacilityOccupantIndex(state, occ),
          amount: defGain,
          sourceTags: sourceActor.tags,
          life: 620,
        });
      }
    });
    return targets.length
      ? { ok: true, message: `Global buff applied to ${targets.length} allied cards.` }
      : { ok: false, message: 'No allied targets for global buff.' };
  }
  if (kind === 'fortify-lane') {
    const atkGain = Math.max(0, Number(tactic.attack ?? 0));
    const defGain = Math.max(0, Number(tactic.defense ?? 0));
    const hpGain = Math.max(0, Number(tactic.health ?? 0));
    let laneRow = Number.isInteger(cellIndex) ? facilityCellFromIndex(cellIndex).row : -1;
    if (laneRow < 0) {
      const laneScores = lanePressureSnapshot(state).sort((a, b) => (b.attackerPower - b.defenderPower) - (a.attackerPower - a.defenderPower));
      laneRow = laneScores[0]?.row ?? 0;
    }
    const targets = [];
    for (let col = 0; col < CONQUEST_GRID_COLS; col += 1) {
      const occ = state.grid[facilityCellIndex(laneRow, col)]?.occupant;
      if (occ?.side !== 'defender') continue;
      targets.push(occ);
      occ.atk = Math.max(0, Number(occ.atk ?? 0) + atkGain);
      occ.def = Math.max(0, Number(occ.def ?? 0) + defGain);
      if (hpGain > 0) {
        occ.maxHp = Math.max(1, Number(occ.maxHp ?? occ.hp ?? 1) + hpGain);
        applyFacilityHeal(state, occ, hpGain, sourceActor, { sourceTags: sourceActor.tags });
      }
      if (defGain > 0) {
        queueConquestActionEvent('shield-gain', {
          side: 'defender',
          targetIndex: findFacilityOccupantIndex(state, occ),
          amount: defGain,
          sourceTags: sourceActor.tags,
          life: 620,
        });
      }
    }
    return targets.length
      ? { ok: true, message: `Lane ${laneRow + 1} fortified (${targets.length} allied card(s)).` }
      : { ok: false, message: 'No allied cards in selected lane.' };
  }
  if (kind === 'blast-cell') {
    const amount = Math.max(1, Number(tactic.amount ?? 3));
    if (!targetOcc || targetOcc.side !== 'attacker') return { ok: false, message: 'Select an enemy cell for blast.' };
    applyFacilityDamage(state, targetOcc, amount, sourceActor, {
      explosive: true,
      sourceTags: sourceActor.tags,
      attackClass: 'explosive',
      projectileKind: 'mortar-shell',
      impactKind: 'blast-impact',
    });
    removeDeadFacilityOccupants(state);
    return { ok: true, message: `${card.name} detonated.` };
  }
  if (kind === 'anti-air-barrage') {
    const amount = Math.max(1, Number(tactic.amount ?? 4));
    const targets = state.grid
      .map((cell) => cell?.occupant)
      .filter((occ) => occ?.side === 'attacker' && (occ.flying || toArray(occ.tags).includes('flying')));
    targets.forEach((occ) => applyFacilityDamage(state, occ, amount, sourceActor, {
      explosive: true,
      barrage: true,
      antiAir: true,
      sourceTags: [...sourceActor.tags, 'anti-air', 'barrage', 'flak'],
      attackClass: 'anti-barrage',
      projectileKind: 'flak-barrage',
      impactKind: 'flak-burst',
    }));
    removeDeadFacilityOccupants(state);
    return targets.length
      ? { ok: true, message: `Anti-air barrage hit ${targets.length} flying target(s).` }
      : { ok: false, message: 'No flying enemies to barrage.' };
  }
  if (kind === 'overclock-turrets') {
    const atkGain = Math.max(1, Number(tactic.attack ?? 1));
    const targets = state.grid
      .map((cell) => cell?.occupant)
      .filter((occ) => occ?.side === 'defender' && toArray(occ.tags).includes('turret'));
    targets.forEach((occ) => {
      occ.atk = Math.max(0, Number(occ.atk ?? 0) + atkGain);
      occ.status = occ.status ?? {};
      occ.status.disabledTurns = Math.max(0, Number(occ.status.disabledTurns ?? 0) - 1);
      queueConquestActionEvent('upgrade', {
        side: 'defender',
        cardName: card?.name ?? 'Overclock',
        targetIndex: findFacilityOccupantIndex(state, occ),
        amount: atkGain,
        sourceTags: sourceActor.tags,
        life: 620,
      });
    });
    return targets.length
      ? { ok: true, message: `Overclocked ${targets.length} turret(s).` }
      : { ok: false, message: 'No friendly turrets to overclock.' };
  }
  if (kind === 'spawn-barricade') {
    if (!Number.isInteger(cellIndex)) return { ok: false, message: 'Select an empty defender cell to reconstruct barricade.' };
    const { row, col } = facilityCellFromIndex(cellIndex);
    if (!conquestCanDeployAt('defender', col)) return { ok: false, message: 'Barricades can only be rebuilt on defender deployment cells.' };
    if (conquestIsNoMansLandCol(col)) return { ok: false, message: 'Cannot rebuild barricades directly in No Man’s Land.' };
    if (targetCell?.occupant) return { ok: false, message: 'Target cell is occupied.' };
    const blueprint = conquestCardById(loadProfile(), String(tactic.cardId ?? 'cq-barricade'));
    if (!blueprint) return { ok: false, message: 'Barricade blueprint missing.' };
    const occ = {
      instanceId: `${blueprint.id}-${Date.now()}-${Math.floor(Math.random() * 9999)}`,
      cardId: blueprint.id,
      rarity: String(blueprint.rarity ?? 'common').toLowerCase(),
      side: 'defender',
      type: blueprint.type,
      subtype: blueprint.subtype ?? '',
      sourceBuilding: blueprint.sourceBuilding ?? 'factory',
      name: blueprint.name,
      atk: Math.max(0, Number(blueprint.attack ?? 0)),
      baseAtk: Math.max(0, Number(blueprint.attack ?? 0)),
      hp: Math.max(1, Number(blueprint.health ?? 1)),
      maxHp: Math.max(1, Number(blueprint.health ?? 1)),
      def: Math.max(0, Number(blueprint.defense ?? 0)),
      range: clamp(Math.max(1, Number(blueprint.range ?? 1)), 1, 5),
      minRange: Number.isFinite(Number(blueprint.minRange)) ? clamp(Math.max(1, Number(blueprint.minRange)), 1, 6) : null,
      maxRange: Number.isFinite(Number(blueprint.maxRange)) ? clamp(Math.max(1, Number(blueprint.maxRange)), 1, 6) : null,
      siege: Math.max(0, Number(blueprint.siege ?? 0)),
      flying: !!blueprint.flying,
      horde: !!blueprint.horde,
      large: !!blueprint.large,
      tags: toArray(blueprint.tags),
      status: {
        wheatPerTurnBonus: 0,
        ironPerTurnBonus: 0,
        upgradeCount: 0,
        gearTier: 'common',
        equipment: [],
        deployedTurn: Number(state.turn ?? 1),
      },
    };
    targetCell.occupant = occ;
    targetCell.owner = 'defender';
    queueConquestActionEvent('summon', {
      side: 'defender',
      cardName: blueprint?.name ?? 'Barricade',
      cellIndex,
      targetIndex: Number.isInteger(cellIndex) ? cellIndex : null,
      sourceTags: conquestVfxTagArray(occ),
      structure: true,
      life: 620,
    });
    return { ok: true, message: `Reconstructed ${blueprint.name} at R${row + 1} C${col + 1}.` };
  }
  if (kind === 'disable-target') {
    if (!targetOcc || targetOcc.side !== 'attacker') return { ok: false, message: 'Select an enemy target to disable.' };
    targetOcc.status = targetOcc.status ?? {};
    targetOcc.status.disabledTurns = Math.max(1, Number(targetOcc.status.disabledTurns ?? 0) + Math.max(1, Number(tactic.turns ?? 1)));
    queueConquestActionEvent('impact', {
      side: 'defender',
      cardName: card?.name ?? 'Disrupt',
      targetIndex: findFacilityOccupantIndex(state, targetOcc),
      attackClass: 'control',
      projectileKind: 'pulse',
      impactKind: 'shock-impact',
      sourceTags: sourceActor.tags,
      targetTags: conquestVfxTagArray(targetOcc),
      life: 640,
    });
    return { ok: true, message: `${targetOcc.name} disabled.` };
  }
  if (kind === 'strike-structure') {
    if (!targetOcc || targetOcc.side !== 'attacker') return { ok: false, message: 'Select an enemy structure target.' };
    const tags = new Set(toArray(targetOcc.tags).map((tag) => String(tag).toLowerCase()));
    if (!(targetOcc.type === 'building' || tags.has('structure') || tags.has('barricade') || tags.has('turret') || tags.has('facility'))) {
      return { ok: false, message: 'Target is not a structure.' };
    }
    const amount = Math.max(1, Number(tactic.amount ?? 4));
    applyFacilityDamage(state, targetOcc, amount, sourceActor, {
      sourceTags: [...sourceActor.tags, 'siege'],
      attackClass: 'siege',
      projectileKind: 'siege-strike',
      impactKind: 'debris-impact',
    });
    removeDeadFacilityOccupants(state);
    return { ok: true, message: `Struck structure for ${amount}.` };
  }
  if (kind === 'capture-boost') {
    const targetCellForCapture = state.grid.find((cell) => cell?.occupant?.side === 'defender' && cell.owner !== 'defender');
    if (!targetCellForCapture) return { ok: false, message: 'No contested cell to secure.' };
    const captureIdx = state.grid.indexOf(targetCellForCapture);
    targetCellForCapture.owner = 'defender';
    queueConquestActionEvent('capture', {
      side: 'defender',
      cellIndex: captureIdx >= 0 ? captureIdx : null,
      targetIndex: captureIdx >= 0 ? captureIdx : null,
      sourceTags: sourceActor.tags,
      life: 640,
    });
    return { ok: true, message: 'Secured contested cell immediately.' };
  }
  if (kind === 'discount') {
    state.defender.tempWheatDiscount = Math.max(0, Number(state.defender.tempWheatDiscount ?? 0) + Math.max(0, Number(tactic.wheat ?? 0)));
    state.defender.tempIronDiscount = Math.max(0, Number(state.defender.tempIronDiscount ?? 0) + Math.max(0, Number(tactic.iron ?? 0)));
    return { ok: true, message: 'Resource discounts applied.' };
  }
  return { ok: false, message: 'No valid tactic effect on this card.' };
}

function placeDefenderCard(state, handInstanceId, cellIndex, profile) {
  const handIndex = state.defender.hand.findIndex((entry) => entry.instanceId === handInstanceId);
  if (handIndex < 0) return { ok: false, message: 'Card not found in hand.' };
  const handEntry = state.defender.hand[handIndex];
  const card = conquestCardById(profile, handEntry.cardId);
  if (!card) return { ok: false, message: 'Card blueprint missing.' };
  const { row, col } = facilityCellFromIndex(cellIndex);
  if (card.type === 'tactic' || card.type === 'spell') {
    const spend = spendDefenderResource(state, card);
    if (!spend.ok) return spend;
    const result = resolveDefenderTacticCard(state, card, cellIndex);
    if (!result.ok) return result;
    state.defender.discard.push(handEntry.cardId);
    state.defender.hand.splice(handIndex, 1);
    facilityLog(state, result.message || `Resolved ${card.name}.`, 'good');
    const tacticKind = String(card?.tactic?.kind ?? '').toLowerCase();
    queueConquestActionEvent('ability-trigger', {
      side: 'defender',
      cardName: card?.name ?? 'Tactic',
      actionType: tacticKind || 'tactic',
      sourceTags: conquestVfxTagArray(card),
      targetIndex: Number.isInteger(cellIndex) ? cellIndex : null,
      life: 560,
    });
    queueConquestActionEvent('tactic', {
      side: 'defender',
      cardName: card?.name ?? 'Tactic',
      actionType: tacticKind || 'tactic',
      sourceTags: conquestVfxTagArray(card),
      targetIndex: Number.isInteger(cellIndex) ? cellIndex : null,
      life: 520,
    });
    return { ok: true };
  }
  if (card.type === 'upgrade') {
    const target = state.grid[cellIndex]?.occupant;
    const targetReadout = defenderUpgradeTargetReadout(card, target);
    if (!targetReadout.ok) return { ok: false, message: targetReadout.message };
    const tagSet = new Set(toArray(target.tags));
    const cardTags = toArray(card.tags);
    const isEquipment = !!targetReadout.isEquipment;
    const upgradeTurret = cardTags.includes('turret');
    const upgradeBarricade = cardTags.includes('barricade');
    const upgradeFarm = cardTags.includes('farm');
    const upgradeMine = cardTags.includes('mine');
    const upgradeFactory = cardTags.includes('factory');
    const upgradeTraining = cardTags.includes('training');
    const upgradeBlacksmith = cardTags.includes('blacksmith');
    const spend = spendDefenderResource(state, card);
    if (!spend.ok) return spend;
    const attackGain = (Number(card.attack ?? 0) || (upgradeTurret ? 2 : 0));
    let defenseGain = (Number(card.defense ?? 0) || (upgradeTurret ? 2 : 1));
    if (isEquipment && defenseGain < 1) defenseGain = 1;
    const hpGain = (Number(card.health ?? 0) || (upgradeBarricade ? 4 : 0));
    target.atk = Math.max(0, Number(target.atk ?? 0) + attackGain);
    target.def = Math.max(0, Number(target.def ?? 0) + defenseGain);
    target.maxHp = Math.max(1, Number(target.maxHp ?? target.hp ?? 1) + hpGain);
    const upgradeSource = { name: card.name, side: 'defender', tags: conquestVfxTagArray(card) };
    const healAmount = Math.max(0, target.maxHp - Number(target.hp ?? 0));
    if (healAmount > 0) {
      applyFacilityHeal(state, target, healAmount, upgradeSource, { repair: false, sourceTags: upgradeSource.tags });
    }
    target.status = target.status ?? {};
    target.status.disabledTurns = Math.max(1, Number(target.status.disabledTurns ?? 0) + (upgradeTurret ? 1 : 0));
    target.status.upgradeCount = Math.max(0, Number(target.status.upgradeCount ?? 0) + 1);
    const tier = target.status.upgradeCount >= 6
      ? 'legendary'
      : target.status.upgradeCount >= 4
        ? 'epic'
        : target.status.upgradeCount >= 2
          ? 'rare'
          : 'common';
    target.status.gearTier = tier;
    if (isEquipment) {
      target.status.equipment = Array.isArray(target.status.equipment) ? target.status.equipment : [];
      target.status.equipment.push(card.name);
      target.status.equipment = target.status.equipment.slice(-6);
      if (Number(card.range ?? 0) > 1) {
        target.range = clamp(Math.max(1, Number(target.range ?? 1) + 1), 1, 5);
      }
      if (card.fortified && !tagSet.has('fortified')) target.tags = [...new Set([...toArray(target.tags), 'fortified'])];
    }
    if (upgradeFarm) target.status.wheatPerTurnBonus = Math.max(0, Number(target.status.wheatPerTurnBonus ?? 0) + 2);
    if (upgradeMine) target.status.ironPerTurnBonus = Math.max(0, Number(target.status.ironPerTurnBonus ?? 0) + 2);
    if (upgradeFactory) state.defender.factoryBonusDrawEveryOther = true;
    if (upgradeTraining) {
      state.defender.trainingDiscountChargesPerTurn = Math.max(1, Number(state.defender.trainingDiscountChargesPerTurn ?? 0));
      state.defender.trainingDiscountCharges = Math.max(Number(state.defender.trainingDiscountCharges ?? 0), Number(state.defender.trainingDiscountChargesPerTurn ?? 0));
    }
    state.defender.discard.push(handEntry.cardId);
    state.defender.hand.splice(handIndex, 1);
    facilityLog(state, `[Upgrade] ${card.name} -> ${target.name} (${target.status.gearTier ?? 'common'} tier).`, 'good');
    queueConquestActionEvent(isEquipment ? 'equip' : 'upgrade', {
      side: 'defender',
      cardName: card?.name ?? 'Upgrade',
      actionType: isEquipment ? 'equip' : 'upgrade',
      sourceTags: conquestVfxTagArray(card),
      targetIndex: Number.isInteger(cellIndex) ? cellIndex : null,
      life: isEquipment ? 660 : 760,
    });
    return { ok: true };
  }
  const placement = canDefenderPlaceAtDetailed(state, card, row, col);
  if (!placement.ok) return placement;
  const spend = spendDefenderResource(state, card);
  if (!spend.ok) return spend;
  const occ = {
    instanceId: `${card.id}-${Date.now()}-${Math.floor(Math.random() * 9999)}`,
    cardId: card.id,
    rarity: String(card.rarity ?? 'common').toLowerCase(),
    side: 'defender',
    type: card.type,
    name: card.name,
    atk: Math.max(0, Number(card.attack ?? 0)),
    baseAtk: Math.max(0, Number(card.attack ?? 0)),
    hp: Math.max(1, Number(card.health ?? 1)),
    maxHp: Math.max(1, Number(card.health ?? 1)),
    def: Math.max(0, Number(card.defense ?? 0)),
    range: clamp(Math.max(1, Number(card.range ?? 1)), 1, 5),
    minRange: Number.isFinite(Number(card.minRange)) ? clamp(Math.max(1, Number(card.minRange)), 1, 6) : null,
    maxRange: Number.isFinite(Number(card.maxRange)) ? clamp(Math.max(1, Number(card.maxRange)), 1, 6) : null,
    siege: Math.max(0, Number(card.siege ?? 0)),
    flying: !!card.flying,
    horde: !!card.horde,
    large: !!card.large,
    tags: toArray(card.tags),
    status: {
      wheatPerTurnBonus: 0,
      ironPerTurnBonus: 0,
      upgradeCount: 0,
      gearTier: 'common',
      equipment: [],
      deployedTurn: Number(state.turn ?? 1),
    },
  };
  if (toArray(occ.tags).includes('turret') && !Number.isFinite(Number(card.maxRange))) {
    occ.range = 2;
  }
  const cell = state.grid[cellIndex];
  cell.occupant = occ;
  cell.owner = 'defender';
  if (toArray(occ.tags).includes('storage')) {
    const capInfo = syncDefenderResourceCaps(state, { clampOverflow: true });
    if (capInfo.previousWheatCap !== capInfo.wheatCap || capInfo.previousIronCap !== capInfo.ironCap) {
      facilityLog(state, `[Storage] Capacity increased to W${capInfo.wheatCap}/I${capInfo.ironCap}.`, 'good');
    }
  }
  state.defender.discard.push(handEntry.cardId);
  state.defender.hand.splice(handIndex, 1);
  facilityLog(state, `[Deploy] ${card.name} at ${row + 1},${col + 1}.`, 'good');
  queueConquestActionEvent('summon', {
    side: 'defender',
    cardName: card?.name ?? occ.name,
    sourceTags: conquestVfxTagArray(occ),
    cellIndex,
    large: !!occ.large,
    flying: !!occ.flying,
    structure: occ.type === 'building' || toArray(occ.tags).includes('structure'),
    life: occ.large ? 820 : 620,
  });
  return { ok: true };
}

function moveFacilityUnitByPlayer(state, fromIdx, toIdx, side = 'defender') {
  if (!Number.isInteger(fromIdx) || !Number.isInteger(toIdx) || fromIdx === toIdx) return { ok: false, message: 'Invalid movement target.' };
  const fromCell = state.grid[fromIdx];
  const toCell = state.grid[toIdx];
  if (!fromCell?.occupant || fromCell.occupant.side !== side) return { ok: false, message: 'Select a friendly unit to move.' };
  if (toCell?.occupant) return { ok: false, message: 'Destination is occupied.' };
  const occ = fromCell.occupant;
  if (!(occ.type === 'unit' || toArray(occ.tags).includes('ground') || toArray(occ.tags).includes('air'))) {
    return { ok: false, message: 'Only units can move.' };
  }
  occ.status = occ.status ?? {};
  if (Number(occ.status.actedTurn ?? 0) === Number(state.turn ?? 1)) return { ok: false, message: `${occ.name} has already acted this turn.` };
  const legal = listLegalUnitMoves(state, fromIdx, occ);
  const destination = legal.find((entry) => entry.idx === toIdx);
  if (!destination) return { ok: false, message: 'That move is not legal for this unit.' };
  const prevOwner = String(toCell?.owner ?? 'neutral');
  state.grid[toIdx].occupant = occ;
  state.grid[toIdx].owner = side;
  state.grid[fromIdx].occupant = null;
  if (state.grid[fromIdx].owner === side) state.grid[fromIdx].owner = 'neutral';
  occ.status.actedTurn = Number(state.turn ?? 1);
  queueConquestActionEvent('move', {
    side,
    sourceIndex: fromIdx,
    targetIndex: toIdx,
    cardName: occ?.name ?? 'Unit',
    sourceTags: conquestVfxTagArray(occ),
    life: 460,
  });
  if (prevOwner !== side) {
    queueConquestActionEvent('capture', {
      side,
      sourceIndex: fromIdx,
      targetIndex: toIdx,
      cellIndex: toIdx,
      cardName: occ?.name ?? 'Unit',
      sourceTags: conquestVfxTagArray(occ),
      life: 620,
    });
  }
  facilityLog(state, `[Move] ${occ.name} ${destination.dir}.`, 'good');
  return { ok: true };
}

function findFirstEmptyDefenderCell(state, preferredCols = []) {
  const validCols = preferredCols
    .map((col) => Math.floor(Number(col)))
    .filter((col) => conquestCanDeployAt('defender', col));
  const scanCols = validCols.length
    ? validCols
    : conquestDeploymentColumns('defender');
  for (let r = 0; r < CONQUEST_GRID_ROWS; r += 1) {
    for (let i = 0; i < scanCols.length; i += 1) {
      const c = scanCols[i];
      const idx = facilityCellIndex(r, c);
      if (!state.grid[idx]?.occupant) return idx;
    }
  }
  return -1;
}

function autoDeployDefenderSetup(state, profile) {
  let safety = 0;
  while (safety < 96) {
    safety += 1;
    const remaining = facilitySetupCardsRemaining(state);
    const pending = Object.entries(remaining).filter(([, count]) => Number(count) > 0);
    if (!pending.length) return true;
    const handEntry = (state.defender.hand ?? []).find((entry) => {
      const cardId = String(entry?.cardId ?? '');
      return Number(remaining[cardId] ?? 0) > 0;
    });
    if (!handEntry) return false;
    const card = conquestCardById(profile, handEntry.cardId);
    if (!card) return false;
    const tags = new Set(toArray(card.tags));
    let slot = -1;
    const defenderFront = conquestFrontlineDeployCol('defender');
    const defenderBack = conquestBacklineCol('defender');
    if (tags.has('barricade')) {
      slot = findFirstEmptyDefenderCell(state, [defenderFront]);
    } else if (tags.has('turret')) {
      slot = findFirstEmptyDefenderCell(state, [defenderFront + 1, defenderFront + 2]);
    } else {
      slot = findFirstEmptyDefenderCell(state, [defenderBack, defenderBack - 1, defenderBack - 2]);
      if (slot < 0) slot = findFirstEmptyDefenderCell(state);
    }
    if (slot < 0) return false;
    const placed = placeDefenderCard(state, handEntry.instanceId, slot, profile);
    if (!placed.ok) return false;
  }
  return false;
}

function attackerPlayableCardIds(state, profile) {
  const mana = Math.max(0, Number(state.attacker.mana ?? 0));
  const homesteadLive = hasLivingHomestead(state);
  return state.attacker.hand
    .map((entry) => ({ entry, card: conquestCardById(profile, entry.cardId) }))
    .filter(({ card }) => card && Number(card.cost?.mana ?? 0) <= mana)
    .filter(({ card }) => {
      if (homesteadLive) return true;
      const tags = new Set(toArray(card.tags));
      return tags.has('homestead') || String(card.subtype ?? '').toLowerCase() === 'homestead';
    });
}

function lanePressureSnapshot(state) {
  return Array.from({ length: CONQUEST_GRID_ROWS }, (_, row) => {
    let attackerPower = 0;
    let defenderPower = 0;
    for (let col = 0; col < CONQUEST_GRID_COLS; col += 1) {
      const occ = state.grid[facilityCellIndex(row, col)]?.occupant;
      if (!occ) continue;
      const value = Number(occ.atk ?? 0) + Number(occ.hp ?? 0) + Number(occ.def ?? 0);
      if (occ.side === 'attacker') attackerPower += value;
      if (occ.side === 'defender') defenderPower += value;
    }
    return { row, attackerPower, defenderPower, delta: attackerPower - defenderPower };
  });
}

function chooseAttackerPlacementIndex(state, card, aiTier = 2) {
  const rows = Array.from({ length: CONQUEST_GRID_ROWS }, (_, idx) => idx);
  const pressure = lanePressureSnapshot(state);
  let bestIdx = -1;
  let bestScore = -Infinity;
  const attackerCols = conquestDeploymentColumns('attacker');
  const backline = conquestBacklineCol('attacker');
  rows.forEach((row) => {
    for (let colIdx = attackerCols.length - 1; colIdx >= 0; colIdx -= 1) {
      const col = attackerCols[colIdx];
      const idx = facilityCellIndex(row, col);
      if (state.grid[idx]?.occupant) continue;
      let score = 0;
      const lane = pressure[row] ?? { delta: 0, attackerPower: 0, defenderPower: 0 };
      const tags = new Set(toArray(card.tags).map((tag) => String(tag).toLowerCase()));
      score += (col * 1.2);
      if (tags.has('pylon')) {
        score += ((CONQUEST_ATTACKER_DEPLOY_MAX_COL - col) * 3);
        if (col === backline) score += 8;
      }
      if (aiTier >= 3) score += Math.max(0, -lane.delta) * 0.25;
      if (aiTier >= 4 && tags.has('siege')) score += lane.defenderPower * 0.2;
      if (aiTier >= 4 && tags.has('flying')) score += 2;
      if (aiTier >= 5 && lane.delta > 8) score -= 2.5;
      if (score > bestScore) {
        bestScore = score;
        bestIdx = idx;
      }
    }
  });
  return bestIdx;
}

function firstAttackerPlacementIndex(state, preferredRows = null) {
  const rows = Array.isArray(preferredRows) && preferredRows.length
    ? preferredRows
    : Array.from({ length: CONQUEST_GRID_ROWS }, (_, idx) => idx);
  const attackerCols = conquestDeploymentColumns('attacker');
  for (let r = 0; r < rows.length; r += 1) {
    const row = rows[r];
    if (row < 0 || row >= CONQUEST_GRID_ROWS) continue;
    for (let i = 0; i < attackerCols.length; i += 1) {
      const col = attackerCols[i];
      const idx = facilityCellIndex(row, col);
      if (!state.grid[idx].occupant) return idx;
    }
  }
  return -1;
}

function attackerBacklinePlacementIndex(state) {
  const backCol = conquestBacklineCol('attacker');
  const center = Math.floor(CONQUEST_GRID_ROWS / 2);
  const rows = [center, center - 1, center + 1, center - 2, center + 2]
    .filter((row) => row >= 0 && row < CONQUEST_GRID_ROWS);
  for (let i = 0; i < rows.length; i += 1) {
    const idx = facilityCellIndex(rows[i], backCol);
    if (!state.grid[idx].occupant) return idx;
  }
  return firstAttackerPlacementIndex(state);
}

function ensureAttackerHomestead(state, profile) {
  if (hasLivingHomestead(state)) {
    state.attacker.homesteadDeployed = true;
    return true;
  }
  let homesteadEntry = state.attacker.hand.find((entry) => {
    const card = conquestCardById(profile, entry.cardId);
    if (!card) return false;
    const tags = new Set(toArray(card.tags));
    return tags.has('homestead') || String(card.subtype ?? '').toLowerCase() === 'homestead';
  });
  while (!homesteadEntry && state.attacker.deck.length && state.attacker.hand.length < 8) {
    const cardId = String(state.attacker.deck.shift());
    const instanceId = `${cardId}-${Date.now()}-${Math.floor(Math.random() * 9999)}`;
    state.attacker.hand.push({ instanceId, cardId });
    const card = conquestCardById(profile, cardId);
    const tags = new Set(toArray(card?.tags));
    if (tags.has('homestead') || String(card?.subtype ?? '').toLowerCase() === 'homestead') {
      homesteadEntry = { instanceId, cardId };
      break;
    }
  }
  if (!homesteadEntry) {
    facilityLog(state, 'Attacker cannot deploy: Homestead blueprint unavailable.', 'good');
    return false;
  }
  const homesteadCard = conquestCardById(profile, homesteadEntry.cardId);
  const manaCost = Math.max(0, Number(homesteadCard?.cost?.mana ?? 0));
  if (Number(state.attacker.mana ?? 0) < manaCost) {
    facilityLog(state, 'Attacker delayed: insufficient mana to deploy Homestead.', 'good');
    return false;
  }
  const slot = attackerBacklinePlacementIndex(state);
  if (slot < 0) {
    facilityLog(state, 'Attacker delayed: no backline slot for Homestead.', 'good');
    return false;
  }
  state.attacker.mana = Math.max(0, Number(state.attacker.mana ?? 0) - manaCost);
  const handIndex = state.attacker.hand.findIndex((entry) => entry.instanceId === homesteadEntry.instanceId);
  if (handIndex >= 0) state.attacker.hand.splice(handIndex, 1);
  spawnAttackerCardToBoard(state, homesteadCard, slot);
  state.attacker.discard.push(homesteadCard.id);
  state.attacker.homesteadDeployed = true;
  facilityLog(state, `[Enemy Deploy] ${homesteadCard.name} established on backline.`, 'bad');
  return true;
}

function spawnAttackerCardToBoard(state, card, forcedSlot = null) {
  const slot = Number.isInteger(forcedSlot) ? forcedSlot : firstAttackerPlacementIndex(state);
  if (slot < 0) return false;
  const normalizedId = normalizeConquestCardId(card.id);
  const baseTags = new Set(toArray(card.tags).map((tag) => String(tag).toLowerCase()));
  const isPylon = String(card.type ?? '').toLowerCase() === 'pylon'
    || baseTags.has('pylon')
    || String(card.subtype ?? '').toLowerCase().includes('mana pylon');
  if (isPylon) baseTags.add('structure');
  const occ = {
    instanceId: `${normalizedId}-${Date.now()}-${Math.floor(Math.random() * 9999)}`,
    cardId: normalizedId,
    rarity: String(card.rarity ?? 'common').toLowerCase(),
    side: 'attacker',
    type: isPylon ? 'building' : card.type,
    subtype: card.subtype ?? '',
    sourceBuilding: card.sourceBuilding ?? card.productionSource ?? 'attacker',
    name: card.name,
    atk: Math.max(0, Number(card.attack ?? 0)),
    baseAtk: Math.max(0, Number(card.attack ?? 0)),
    hp: Math.max(1, Number(card.health ?? 1)),
    maxHp: Math.max(1, Number(card.health ?? 1)),
    def: Math.max(0, Number(card.defense ?? 0)),
    range: clamp(Math.max(1, Number(card.range ?? 1)), 1, 5),
    minRange: Number.isFinite(Number(card.minRange)) ? clamp(Math.max(1, Number(card.minRange)), 1, 6) : null,
    maxRange: Number.isFinite(Number(card.maxRange)) ? clamp(Math.max(1, Number(card.maxRange)), 1, 6) : null,
    siege: Math.max(0, Number(card.siege ?? 0)),
    flying: !!card.flying,
    horde: !!card.horde,
    large: !!card.large,
    tags: Array.from(baseTags),
    status: {
      pylonValue: isPylon && baseTags.has('elite') ? 2 : (isPylon ? 1 : 0),
      deployedTurn: Number(state.turn ?? 1),
    },
  };
  if (toArray(occ.tags).includes('turret') && !Number.isFinite(Number(card.maxRange))) {
    occ.range = 2;
  }
  state.grid[slot].occupant = occ;
  state.grid[slot].owner = 'attacker';
  if (toArray(card.tags).includes('homestead') || String(card.subtype ?? '').toLowerCase() === 'homestead') {
    state.attacker.homesteadDeployed = true;
  }
  queueConquestActionEvent('summon', {
    side: 'attacker',
    cardName: card?.name ?? occ.name,
    sourceTags: conquestVfxTagArray(occ),
    cellIndex: slot,
    large: !!occ.large,
    flying: !!occ.flying,
    structure: occ.type === 'building' || toArray(occ.tags).includes('structure'),
    life: occ.large ? 820 : 620,
  });
  return true;
}

function resolveAttackerSpellCard(state, card, profile, aiTier = 2) {
  const tactic = card.tactic && typeof card.tactic === 'object' ? card.tactic : {};
  const kind = String(tactic.kind ?? '').toLowerCase();
  const sourceActor = {
    name: card?.name ?? 'Enemy Cast',
    side: 'attacker',
    tags: conquestVfxTagArray(card),
  };
  if (kind) {
    queueConquestActionEvent('ability-trigger', {
      side: 'attacker',
      cardName: card?.name ?? 'Enemy Cast',
      actionType: kind,
      sourceTags: sourceActor.tags,
      life: 560,
    });
  }
  const attackerOcc = state.grid.map((cell) => cell?.occupant).filter((occ) => occ?.side === 'attacker');
  const defenderOcc = state.grid.map((cell) => cell?.occupant).filter((occ) => occ?.side === 'defender');
  const defenderStructures = defenderOcc.filter((occ) => toArray(occ.tags).includes('structure') || occ.type === 'building');
  const defenderBarricades = defenderOcc.filter((occ) => toArray(occ.tags).includes('barricade'));

  const pickEnemy = (list, mode = 'generic') => {
    if (!Array.isArray(list) || !list.length) return null;
    if (aiTier <= 2) return list[Math.floor(Math.random() * list.length)];
    const scored = list.map((occ) => {
      const tags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
      let score = Number(occ.atk ?? 0) + Number(occ.def ?? 0) + (Number(occ.hp ?? 0) * 0.45);
      if (mode === 'barricade' && tags.has('barricade')) score += 20;
      if (mode === 'structure' && (tags.has('structure') || occ.type === 'building')) score += 12;
      if (mode === 'turret' && tags.has('turret')) score += 14;
      if (mode === 'blast' && tags.has('horde')) score += 10;
      if (aiTier >= 4 && tags.has('homestead')) score += 30;
      return { occ, score };
    }).sort((a, b) => b.score - a.score);
    return scored[0]?.occ ?? null;
  };
  if (kind === 'gain-mana-from-pylons') {
    const maxGain = Math.max(1, Number(tactic.max ?? 3));
    state.attacker.manaPylons = Math.max(1, attackerPylonCount(state));
    const gain = Math.min(maxGain, Math.max(1, Number(state.attacker.manaPylons ?? 1)));
    state.attacker.mana = Math.max(0, Number(state.attacker.mana ?? 0) + gain);
    facilityLog(state, `${card.name} granted +${gain} mana.`, 'bad');
    queueConquestActionEvent('resource', {
      side: 'attacker',
      cardName: card?.name ?? 'Mana Gain',
      amountMana: gain,
      sourceTags: sourceActor.tags,
      life: 560,
    });
    return;
  }
  if (kind === 'gain-mana') {
    const gain = Math.max(1, Number(tactic.amount ?? 2));
    state.attacker.mana = Math.max(0, Number(state.attacker.mana ?? 0) + gain);
    facilityLog(state, `${card.name} granted +${gain} mana.`, 'bad');
    queueConquestActionEvent('resource', {
      side: 'attacker',
      cardName: card?.name ?? 'Mana Gain',
      amountMana: gain,
      sourceTags: sourceActor.tags,
      life: 560,
    });
    return;
  }
  if (kind === 'summon-multi') {
    const summonCards = Array.isArray(tactic.cards) ? tactic.cards : [];
    let summoned = 0;
    summonCards.forEach((cardId) => {
      const summon = conquestCardById(profile, cardId);
      if (!summon) return;
      if (spawnAttackerCardToBoard(state, summon)) summoned += 1;
    });
    facilityLog(state, `${card.name} summoned ${summoned} attackers.`, 'bad');
    return;
  }
  if (kind === 'strike-barricade') {
    const target = pickEnemy(defenderBarricades, 'barricade');
    if (target) {
      applyFacilityDamage(state, target, Math.max(1, Number(tactic.amount ?? 5)), sourceActor, {
        sourceTags: [...sourceActor.tags, 'siege', 'anti-structure'],
        attackClass: 'siege',
        projectileKind: 'siege-strike',
        impactKind: 'debris-impact',
      });
    }
    removeDeadFacilityOccupants(state);
    return;
  }
  if (kind === 'strike-structure') {
    const target = pickEnemy(defenderStructures.length ? defenderStructures : defenderOcc, 'structure');
    if (target) {
      applyFacilityDamage(state, target, Math.max(1, Number(tactic.amount ?? 4)), sourceActor, {
        sourceTags: [...sourceActor.tags, 'siege'],
        attackClass: 'siege',
        projectileKind: 'siege-strike',
        impactKind: 'debris-impact',
      });
    }
    removeDeadFacilityOccupants(state);
    return;
  }
  if (kind === 'blast-cell') {
    const target = pickEnemy(defenderOcc, 'blast');
    if (target) {
      applyFacilityDamage(state, target, Math.max(1, Number(tactic.amount ?? 4)), sourceActor, {
        explosive: true,
        sourceTags: [...sourceActor.tags, 'explosive'],
        attackClass: 'explosive',
        projectileKind: 'mortar-shell',
        impactKind: 'blast-impact',
      });
    }
    removeDeadFacilityOccupants(state);
    return;
  }
  if (kind === 'capture-boost') {
    const captured = state.grid.find((cell) => cell.owner !== 'attacker' && cell.occupant?.side === 'attacker');
    if (captured) {
      const captureIdx = state.grid.indexOf(captured);
      captured.owner = 'attacker';
      queueConquestActionEvent('capture', {
        side: 'attacker',
        cellIndex: captureIdx >= 0 ? captureIdx : null,
        targetIndex: captureIdx >= 0 ? captureIdx : null,
        sourceTags: sourceActor.tags,
        life: 640,
      });
    }
    if (state.attacker.deck.length) {
      const drawId = String(state.attacker.deck.shift());
      state.attacker.hand.push({ instanceId: `${drawId}-${Date.now()}-${Math.floor(Math.random() * 9999)}`, cardId: drawId });
    }
    return;
  }
  if (kind === 'disable-target') {
    const target = pickEnemy(defenderOcc.filter((occ) => toArray(occ.tags).includes('turret')).length
      ? defenderOcc.filter((occ) => toArray(occ.tags).includes('turret'))
      : defenderOcc, 'turret');
    if (target) {
      target.status = target.status ?? {};
      target.status.disabledTurns = Math.max(1, Number(target.status.disabledTurns ?? 0) + Math.max(1, Number(tactic.turns ?? 1)));
      queueConquestActionEvent('impact', {
        side: 'attacker',
        cardName: card?.name ?? 'Disable',
        targetIndex: findFacilityOccupantIndex(state, target),
        attackClass: 'control',
        projectileKind: 'pulse',
        impactKind: 'shock-impact',
        sourceTags: sourceActor.tags,
        targetTags: conquestVfxTagArray(target),
        life: 640,
      });
    }
    return;
  }
  const buffAttack = Math.max(0, Number(tactic.attack ?? card.attack ?? 0));
  const buffRepeats = Math.max(1, Number(tactic.repeats ?? 1));
  for (let i = 0; i < buffRepeats; i += 1) {
    const target = attackerOcc[i];
    if (!target) break;
    target.atk = Math.max(0, Number(target.atk ?? 0) + buffAttack);
  }
}

function runAttackerTurn(state, profile) {
  state.side = 'attacker';
  state.attackerPlaysLeft = ATTACKER_MAX_PLAYS_PER_TURN;
  state.attacker.manaPylons = Math.max(1, attackerPylonCount(state));
  state.attacker.mana = Math.max(0, Number(state.attacker.mana ?? 0) + Number(state.attacker.manaPylons ?? 1));
  const aiTier = conquestAiSkillTier(state);
  while (state.attacker.hand.length < 4 && state.attacker.deck.length) {
    const cardId = String(state.attacker.deck.shift());
    state.attacker.hand.push({ instanceId: `${cardId}-${Date.now()}-${Math.floor(Math.random() * 9999)}`, cardId });
  }
  ensureAttackerHomestead(state, profile);
  let safety = 0;
  const triedCards = new Set();
  while (state.attackerPlaysLeft > 0 && safety < 18) {
    safety += 1;
    const playable = attackerPlayableCardIds(state, profile)
      .filter((entry) => !triedCards.has(entry.entry.instanceId));
    if (!playable.length) break;
    const choice = playable
      .map((entry) => {
        const card = entry.card;
        const tags = new Set(toArray(card.tags));
        let score = Number(card.cost?.mana ?? 0);
        if (tags.has('homestead')) score += 100;
        if (aiTier >= 3 && tags.has('siege')) score += 3;
        if (aiTier >= 4 && tags.has('flying')) score += 1.5;
        if (aiTier >= 4 && (card.type === 'spell' || card.type === 'tactic')) score += 2;
        if (aiTier <= 2 && (card.type === 'unit' || tags.has('horde'))) score += 2;
        if (!hasLivingHomestead(state) && !tags.has('homestead')) score -= 999;
        if (aiTier >= 5 && hasLivingHomestead(state) && tags.has('homestead')) score -= 90;
        return { ...entry, score };
      })
      .sort((a, b) => b.score - a.score)[0];
    const card = choice.card;
    const handIndex = state.attacker.hand.findIndex((entry) => entry.instanceId === choice.entry.instanceId);
    if (handIndex < 0) break;
    const manaCost = Math.max(0, Number(card.cost?.mana ?? 0));
    state.attacker.mana = Math.max(0, Number(state.attacker.mana ?? 0) - manaCost);
    state.attackerPlaysLeft = Math.max(0, state.attackerPlaysLeft - 1);
    if (card.type === 'spell' || card.type === 'tactic') {
      resolveAttackerSpellCard(state, card, profile, aiTier);
      facilityLog(state, `[Enemy Cast] ${card.name}.`, 'bad');
      state.attacker.discard.push(card.id);
      state.attacker.hand.splice(handIndex, 1);
      continue;
    }
    const slot = chooseAttackerPlacementIndex(state, card, aiTier);
    const placed = spawnAttackerCardToBoard(state, card, slot >= 0 ? slot : null);
    if (!placed) {
      triedCards.add(choice.entry.instanceId);
      conquestAiDebugLog(state, `Attacker skipped ${card.name}: no legal placement.`);
      continue;
    }
    state.attacker.discard.push(card.id);
    state.attacker.hand.splice(handIndex, 1);
    facilityLog(state, `[Enemy Deploy] ${card.name}.`, 'bad');
    state.attacker.manaPylons = Math.max(1, attackerPylonCount(state));
    conquestAiDebugLog(state, `Attacker deployed ${card.name}.`);
  }
  resolveFacilityAttacksForSide(state, 'attacker');
  moveFacilityUnits(state, 'attacker', aiTier);
}

function defenderPlayablePlacements(state, profile, aiTier = 2) {
  const out = [];
  const lanePressure = lanePressureSnapshot(state);
  const hand = Array.isArray(state?.defender?.hand) ? state.defender.hand : [];
  const defenderCols = conquestDeploymentColumns('defender');
  hand.forEach((entry) => {
    const card = conquestCardById(profile, entry.cardId);
    if (!card) return;
    if (card.type === 'spell' || card.type === 'tactic' || card.type === 'upgrade') return;
    for (let row = 0; row < CONQUEST_GRID_ROWS; row += 1) {
      for (let colIdx = 0; colIdx < defenderCols.length; colIdx += 1) {
        const col = defenderCols[colIdx];
        if (!canDefenderPlaceAt(state, card, row, col)) continue;
        const laneBias = col;
        const tags = new Set(toArray(card.tags));
        const pressure = lanePressure[row] ?? { attackerPower: 0, defenderPower: 0, delta: 0 };
        let score = (Number(card.attack ?? 0) * 2) + Number(card.health ?? 0) + Number(card.defense ?? 0) + laneBias;
        if (aiTier >= 3 && tags.has('turret')) score += 4;
        if (aiTier >= 3 && tags.has('barricade')) score += 3;
        if (aiTier >= 4 && tags.has('siege')) score += 2;
        if (aiTier >= 4 && tags.has('ranged')) score += 2;
        if (aiTier <= 2 && tags.has('horde')) score += 2;
        if (aiTier >= 3) score += Math.max(0, pressure.attackerPower - pressure.defenderPower) * 0.2;
        if (aiTier >= 4 && tags.has('barricade') && pressure.attackerPower > pressure.defenderPower) score += 4;
        if (aiTier >= 5 && tags.has('turret') && col <= (CONQUEST_DEFENDER_DEPLOY_MIN_COL + 2)) score += 3;
        out.push({ instanceId: entry.instanceId, card, row, col, score });
      }
    }
  });
  out.sort((a, b) => b.score - a.score);
  return out;
}

function runDefenderAiTurn(state, profile) {
  state.side = 'defender';
  state.drawActionsLeft = DEFENDER_MAX_DRAWS_PER_TURN;
  state.defender.blacksmithDrawnOnTurn = 0;
  const aiTier = conquestAiSkillTier(state);
  applyFacilityResourceTick(state);
  const drawPlan = aiTier >= 5
    ? ['experimental', 'ordnance', 'power', 'vehicle', 'factory', 'air', 'training', 'recovery', 'blacksmith', 'command']
    : aiTier >= 4
      ? ['ordnance', 'power', 'factory', 'vehicle', 'air', 'training', 'blacksmith', 'command', 'recovery']
      : aiTier >= 3
        ? ['factory', 'training', 'vehicle', 'blacksmith', 'command', 'ordnance']
        : ['training', 'factory', 'blacksmith', 'command'];
  drawPlan.forEach((deckKey) => {
    if (state.drawActionsLeft <= 0) return;
    const drawGate = conquestDeckDrawReadout(state, deckKey);
    if (!drawGate.ok) return;
    const deck = state.defender.drawDecks?.[deckKey];
    if (!Array.isArray(deck) || !deck.length) return;
    if (deckKey === 'blacksmith' && Number(state.defender.blacksmithDrawnOnTurn ?? 0) >= 1) return;
    const result = drawConquestCard(state, deckKey);
    if (!result.ok) return;
  });
  let safety = 0;
  while (safety < 12) {
    safety += 1;
    const options = defenderPlayablePlacements(state, profile, aiTier);
    if (!options.length) break;
    const best = options[0];
    const idx = facilityCellIndex(best.row, best.col);
    const placed = placeDefenderCard(state, best.instanceId, idx, profile);
    if (!placed.ok) break;
    conquestAiDebugLog(state, `Defender AI placed ${best.card.name} at R${best.row + 1} C${best.col + 1}.`);
  }
  resolveFacilityAttacksForSide(state, 'defender');
  moveFacilityUnits(state, 'defender', aiTier);
}

function decrementStatusDurations(state) {
  state.grid.forEach((cell) => {
    const occ = cell?.occupant;
    if (!occ || !occ.status) return;
    if (occ.status.disabledTurns > 0) occ.status.disabledTurns -= 1;
    if (occ.status.moraleStunned > 0) occ.status.moraleStunned -= 1;
  });
}

function checkFacilityWinner(state) {
  const homesteadAlive = hasLivingHomestead(state);
  const homesteadWasRequired = !!state?.attacker?.homesteadDeployed;
  if (homesteadWasRequired && !homesteadAlive) return 'defender';
  const attackersInLastColumn = state.grid.some((cell, idx) => {
    const col = idx % CONQUEST_GRID_COLS;
    return col === (CONQUEST_GRID_COLS - 1) && cell?.occupant?.side === 'attacker';
  });
  if (attackersInLastColumn) return 'attacker';
  const defendersInEnemyEnd = state.grid.some((cell, idx) => {
    const col = idx % CONQUEST_GRID_COLS;
    return col === 0 && cell?.occupant?.side === 'defender';
  });
  if (defendersInEnemyEnd) return 'defender';
  const attackerUnits = state.grid.some((cell) => cell?.occupant?.side === 'attacker');
  if (!attackerUnits && !state.attacker.hand.length && !state.attacker.deck.length) return 'defender';
  return null;
}

function concludeFacilityRound(state, profile) {
  const playerSide = String(state.playerSide ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender';
  const attackerAi = state.aiControl?.attacker ?? (playerSide !== 'attacker');
  const defenderAi = state.aiControl?.defender ?? (playerSide !== 'defender');
  facilityLog(state, `Turn ${state.turn}: resolving ${defenderAi ? 'Defender AI' : 'Defender Player'} then ${attackerAi ? 'Attacker AI' : 'Attacker Player'}.`, 'info');
  // Resolve only AI-controlled sides. Player-controlled side should never be auto-driven by AI planner.
  if (defenderAi) {
    runDefenderAiTurn(state, profile);
  } else {
    resolveFacilityAttacksForSide(state, 'defender');
    conquestAiDebugLog(state, 'Player defender end-step resolved (attacks only, no AI movement).');
  }
  let winner = checkFacilityWinner(state);
  if (!winner) {
    if (attackerAi) {
      runAttackerTurn(state, profile);
    } else {
      resolveFacilityAttacksForSide(state, 'attacker');
      conquestAiDebugLog(state, 'Player attacker end-step resolved (attacks only, no AI movement).');
    }
    winner = checkFacilityWinner(state);
  }
  decrementStatusDurations(state);
  state.turn = Math.max(1, Number(state.turn ?? 1) + 1);
  state.side = 'defender';
  state.drawActionsLeft = DEFENDER_MAX_DRAWS_PER_TURN;
  state.defender.blacksmithDrawnOnTurn = 0;
  state.defender.tempWheatDiscount = 0;
  state.defender.tempIronDiscount = 0;
  state.defender.trainingDiscountCharges = Math.max(0, Number(state.defender.trainingDiscountChargesPerTurn ?? 0));
  if (state.defender.factoryBonusDrawEveryOther && state.turn % 2 === 0) {
    drawConquestCardDirect(state, 'factory', 1);
    facilityLog(state, 'Factory overdrive generated a bonus draw.', 'good');
  }
  applyFacilityResourceTick(state);
  if (winner) {
    state.winner = winner;
    state.underAttack = false;
    state.phase = 'resolved';
    facilityLog(state, winner === 'defender' ? 'Defenders held the facility line.' : 'Invaders broke through the final column.', winner === 'defender' ? 'good' : 'bad');
  }
}

function persistFacilityState(profile, worldId, planetId, state) {
  const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return false;
  planet.facilityWar = state;
  planet.conquestDecks = normalizeConquestDecks(state.conquestDecks ?? planet.conquestDecks);
  campaign.worldStates[worldId] = world;
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  return true;
}

function applyFacilityEncounterOutcome(profile, worldId, planetId, state) {
  if (!state?.winner) return false;
  const encounter = state.encounter && typeof state.encounter === 'object' ? state.encounter : null;
  const outcomeStamp = `${state.winner}:${encounter?.encounterId ?? 'generic'}`;
  if (state.lastOutcomeStamp === outcomeStamp && Number(state.outcomeAppliedAt ?? 0) > 0) return false;

  const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return false;
  const attackers = getDimensionalAttackers(mapWorld);
  const threatType = String(encounter?.threatType ?? '').toLowerCase();
  ensureProfileStats(profile);
  profile.stats.battles = Math.max(0, Number(profile.stats.battles ?? 0)) + 1;
  const playerWon = state.winner === 'defender';
  if (playerWon) profile.stats.wins = Math.max(0, Number(profile.stats.wins ?? 0)) + 1;
  else profile.stats.losses = Math.max(0, Number(profile.stats.losses ?? 0)) + 1;
  profile.stats.modes = profile.stats.modes ?? {};
  profile.stats.modes.defense = profile.stats.modes.defense ?? { wins: 0, losses: 0, battles: 0 };
  profile.stats.modes.defense.battles = Math.max(0, Number(profile.stats.modes.defense.battles ?? 0)) + 1;
  if (playerWon) profile.stats.modes.defense.wins = Math.max(0, Number(profile.stats.modes.defense.wins ?? 0)) + 1;
  else profile.stats.modes.defense.losses = Math.max(0, Number(profile.stats.modes.defense.losses ?? 0)) + 1;
  let changed = false;

  if (threatType === 'alien' && encounter?.threatId) {
    const threatId = String(encounter.threatId);
    const idx = (campaign.activeThreats ?? []).findIndex((entry) => entry?.id === threatId && !entry.resolved);
    const threat = idx >= 0 ? campaign.activeThreats[idx] : null;
    if (idx >= 0) {
      if (state.winner === 'defender') {
        campaign.activeThreats.splice(idx, 1);
        profile.economy = profile.economy ?? { gold: 0, lifeforce: 0 };
        profile.stats.invasions = profile.stats.invasions ?? { intercepted: 0, piratesEscaped: 0 };
        profile.stats.invasions.intercepted = Math.max(0, Number(profile.stats.invasions.intercepted ?? 0)) + 1;
        const reward = 70 + Math.round(toFiniteNumber(threat?.deckSizeEstimate, 20) * 0.65);
        profile.economy.gold = Number(profile.economy.gold ?? 0) + reward;
        campaign.eventHistory = [...(campaign.eventHistory ?? []), {
          ts: Date.now(),
          severity: 'good',
          text: `${threat?.factionName ?? 'Alien fleet'} was repelled over ${planet.name}. Reward: +${reward} gold.`,
        }].slice(-80);
      } else {
        planet.ownership = 'lost';
        world.lost = true;
        world.secured = false;
        campaign.eventHistory = [...(campaign.eventHistory ?? []), {
          ts: Date.now(),
          severity: 'danger',
          text: `${threat?.factionName ?? 'Alien fleet'} seized ${planet.name}. ${world.worldName} is now lost.`,
        }].slice(-80);
      }
      changed = true;
    }
  }

  if (threatType === 'pirate' && encounter?.threatId) {
    const pirateId = String(encounter.threatId);
    const pirateIdx = (attackers.activePirates ?? []).findIndex((entry) => entry?.id === pirateId);
    const pirate = pirateIdx >= 0 ? attackers.activePirates[pirateIdx] : null;
    if (pirate) {
      if (state.winner === 'defender') {
        onPirateDefeated(attackers, pirate, profile);
      } else {
        onPirateEscaped(attackers, pirate, profile);
      }
      attackers.activePirates.splice(pirateIdx, 1);
      attackers.pendingIntercept = null;
      clearWarpKeyCompromised(attackers);
      campaign.eventHistory = [...(campaign.eventHistory ?? []), {
        ts: Date.now(),
        severity: state.winner === 'defender' ? 'good' : 'danger',
        text: state.winner === 'defender'
          ? `${pirate.name} and its raiders were destroyed over ${planet.name}.`
          : `${pirate.name} broke the line over ${planet.name} and escaped.`,
      }].slice(-80);
      changed = true;
    }
  }

  if (changed) {
    world.planets = Array.isArray(world.planets) ? world.planets : [];
    if (reconcileWorldOwnership(campaign, world, profile)) changed = true;
    campaign.worldStates[worldId] = world;
    mapWorld.campaign = campaign;
    mapWorld.dimensionalAttackers = attackers;
    profile.mapWorld = mapWorld;
  }
  state.outcomeAppliedAt = Date.now();
  state.lastOutcomeStamp = outcomeStamp;
  return changed;
}

function runFacilityDraw(worldId, planetId, deckKey) {
  const profile = loadProfile();
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  ensurePlanetConquestState(world, planet);
  const state = planet.facilityWar;
  if (state.winner) return;
  const result = drawConquestCard(state, deckKey);
  if (!result.ok) {
    facilityLog(state, result.message, 'bad');
  } else {
    queueConquestActionEvent('draw', {
      side: 'defender',
      deckKey: String(deckKey),
      cardId: String(result.cardId ?? ''),
      life: 420,
    });
  }
  persistFacilityState(profile, worldId, planetId, state);
  renderFacilityWarModal(loadProfile());
}

function runFacilityAttackAction(worldId, planetId) {
  const profile = loadProfile();
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  ensurePlanetConquestState(world, planet);
  const state = planet.facilityWar;
  if (state.winner) return;
  if (state.phase === 'setup') {
    facilityLog(state, 'Combat has not started. Finish setup before attacking.', 'bad');
    persistFacilityState(profile, worldId, planetId, state);
    renderFacilityWarModal(loadProfile());
    return;
  }
  if (String(state.side ?? '') !== 'defender') {
    facilityLog(state, 'You can only attack during defender turn.', 'bad');
    persistFacilityState(profile, worldId, planetId, state);
    renderFacilityWarModal(loadProfile());
    return;
  }
  const sourceIdx = Number.isInteger(modalUiState.facilityWar.selectedUnitCellIndex)
    ? Number(modalUiState.facilityWar.selectedUnitCellIndex)
    : (Number.isInteger(modalUiState.facilityWar.selectedAttackSourceIndex)
      ? Number(modalUiState.facilityWar.selectedAttackSourceIndex)
      : (Number.isInteger(modalUiState.facilityWar.inspectCellIndex) ? Number(modalUiState.facilityWar.inspectCellIndex) : null));
  const inspectIdx = Number.isInteger(modalUiState.facilityWar.inspectCellIndex)
    ? Number(modalUiState.facilityWar.inspectCellIndex)
    : null;
  const targetIdx = Number.isInteger(inspectIdx)
    && inspectIdx !== sourceIdx
    && state.grid[inspectIdx]?.occupant?.side === 'attacker'
    ? inspectIdx
    : null;
  const result = runFacilityManualAttack(state, sourceIdx, targetIdx);
  if (!result.ok) {
    facilityLog(state, result.message || 'Attack failed.', 'bad');
  } else {
    modalUiState.facilityWar.inspectCellIndex = result.targetCellIndex;
  }
  modalUiState.facilityWar.dragAttackSourceIndex = null;
  document.body.classList.remove('facility-drag-attacking');
  persistFacilityState(profile, worldId, planetId, state);
  renderFacilityWarModal(loadProfile());
}

function runFacilityDeconstructAction(worldId, planetId) {
  const profile = loadProfile();
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  ensurePlanetConquestState(world, planet);
  const state = planet.facilityWar;
  if (state.winner) return;
  if (String(state.playerSide ?? 'defender') !== 'defender') {
    facilityLog(state, 'Deconstruct is available only while controlling defenders.', 'bad');
    persistFacilityState(profile, worldId, planetId, state);
    renderFacilityWarModal(loadProfile());
    return;
  }
  if (state.phase !== 'setup' && String(state.side ?? '') !== 'defender') {
    facilityLog(state, 'You can deconstruct only during defender turn.', 'bad');
    persistFacilityState(profile, worldId, planetId, state);
    renderFacilityWarModal(loadProfile());
    return;
  }
  const inspectIdx = Number.isInteger(modalUiState.facilityWar.inspectCellIndex)
    ? Number(modalUiState.facilityWar.inspectCellIndex)
    : null;
  const check = getFacilityDeconstructReadout(state, inspectIdx);
  if (!check.ok) {
    facilityLog(state, check.message, 'bad');
    persistFacilityState(profile, worldId, planetId, state);
    renderFacilityWarModal(loadProfile());
    return;
  }
  const occ = check.occupant;
  const card = conquestCardById(profile, occ.cardId);
  const refundWheat = Math.floor(Math.max(0, Number(card?.cost?.wheat ?? 0)) * 0.5);
  const refundIron = Math.floor(Math.max(0, Number(card?.cost?.iron ?? 0)) * 0.5);
  const warning = state.phase === 'setup'
    ? `Deconstruct ${occ.name}? It will be removed and returned to your hand.`
    : `Deconstruct ${occ.name}? It will be removed permanently and refund +W${refundWheat}/I${refundIron}.`;
  if (!window.confirm(warning)) return;
  const result = deconstructFacilityCard(state, profile, inspectIdx);
  if (!result.ok) facilityLog(state, result.message, 'bad');
  persistFacilityState(profile, worldId, planetId, state);
  renderFacilityWarModal(loadProfile());
}

function runFacilityEndTurn(worldId, planetId) {
  const profile = loadProfile();
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  ensurePlanetConquestState(world, planet);
  const state = planet.facilityWar;
  const playerSide = String(state.playerSide ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender';
  const defenderAi = state.aiControl?.defender ?? (playerSide !== 'defender');
  conquestAiDebugLog(state, `End turn pressed. playerSide=${playerSide} attackerAi=${state.aiControl?.attacker ?? (playerSide !== 'attacker')} defenderAi=${defenderAi} phase=${state.phase} turn=${state.turn}`);
  if (!state.winner && state.phase === 'setup') {
    if (defenderAi) {
      autoDeployDefenderSetup(state, profile);
    }
    const remaining = facilitySetupCardsRemaining(state);
    const pending = Object.entries(remaining).filter(([, count]) => Number(count) > 0);
    if (pending.length) {
      const pendingText = pending
        .map(([id, count]) => `${conquestCardById(profile, id)?.name ?? id} x${count}`)
        .join(', ');
      facilityLog(state, `Setup incomplete. Place all starter assets before beginning the assault: ${pendingText}.`, 'bad');
    } else {
      state.phase = 'battle';
      state.underAttack = true;
      state.drawActionsLeft = DEFENDER_MAX_DRAWS_PER_TURN;
      state.side = 'defender';
      state.defender.blacksmithDrawnOnTurn = 0;
      state.defender.tempWheatDiscount = 0;
      state.defender.tempIronDiscount = 0;
      state.defender.trainingDiscountCharges = Math.max(0, Number(state.defender.trainingDiscountChargesPerTurn ?? 0));
      applyFacilityResourceTick(state);
      facilityLog(state, 'Setup complete. Invasion wave entering combat range.', 'warn');
    }
  } else if (!state.winner) {
    concludeFacilityRound(state, profile);
  }
  if (state.winner) {
    applyFacilityEncounterOutcome(profile, worldId, planetId, state);
  }
  modalUiState.facilityWar.dragAttackSourceIndex = null;
  document.body.classList.remove('facility-drag-attacking');
  persistFacilityState(profile, worldId, planetId, state);
  renderFacilityWarModal(loadProfile());
}

function facilityProductionSummary(state, profile) {
  const defenderOcc = (state?.grid ?? [])
    .map((cell) => cell?.occupant)
    .filter((occ) => occ?.side === 'defender');
  let wheatPerTurn = 0;
  let ironPerTurn = 0;
  defenderOcc.forEach((occ) => {
    const card = conquestCardById(profile, occ.cardId);
    const baseWheat = Math.max(0, Number(card?.production?.wheatPerTurn ?? 0));
    const baseIron = Math.max(0, Number(card?.production?.ironPerTurn ?? 0));
    const bonusWheat = Math.max(0, Number(occ?.status?.wheatPerTurnBonus ?? 0));
    const bonusIron = Math.max(0, Number(occ?.status?.ironPerTurnBonus ?? 0));
    wheatPerTurn += baseWheat + bonusWheat;
    ironPerTurn += baseIron + bonusIron;
  });
  return { wheatPerTurn, ironPerTurn };
}

function facilityResourceGaugeMarkup({
  icon = '',
  label = 'Resource',
  current = 0,
  cap = 10,
  previewSpend = 0,
  gainPerTurn = 0,
  capBonus = 0,
  missing = 0,
  previewActive = false,
}) {
  const safeCap = Math.max(1, Number(cap ?? 10));
  const safeCurrent = clamp(Math.max(0, Number(current ?? 0)), 0, safeCap);
  const safeSpend = clamp(Math.max(0, Number(previewSpend ?? 0)), 0, safeCurrent);
  const projected = Math.max(0, safeCurrent - safeSpend);
  const fillPct = clamp((safeCurrent / safeCap) * 100, 0, 100);
  const projectedPct = clamp((projected / safeCap) * 100, 0, 100);
  const hollowPct = clamp(fillPct - projectedPct, 0, 100);
  const statusClass = fillPct >= 98 ? 'is-capped' : fillPct <= 24 ? 'is-low' : 'is-healthy';
  const affordabilityClass = missing > 0 ? 'is-unaffordable' : '';
  const previewText = previewActive
    ? `${projected}/${safeCap}`
    : `${safeCurrent}/${safeCap}`;
  return `
    <div class="facility-resource-block ${statusClass} ${affordabilityClass}">
      <div class="facility-resource-head">
        <span class="facility-resource-label"><img class="facility-resource-icon" src="${icon}" alt="${label}" /> <strong>${label}</strong></span>
        <span class="facility-resource-value">${safeCurrent}/${safeCap}${previewActive ? ` <small>→ ${previewText}</small>` : ''}</span>
      </div>
      <div class="facility-resource-gauge" role="presentation">
        <span class="facility-resource-fill" style="width:${fillPct.toFixed(2)}%"></span>
        ${previewActive && hollowPct > 0 ? `<span class="facility-resource-hollow" style="left:${projectedPct.toFixed(2)}%;width:${hollowPct.toFixed(2)}%"></span>` : ''}
      </div>
      <div class="facility-resource-meta">
        <small>+${Math.max(0, Number(gainPerTurn ?? 0))}/turn</small>
        <small>${capBonus > 0 ? `Cap +${capBonus}` : 'Base cap'}</small>
        ${missing > 0 ? `<small class="warning">Missing ${missing}</small>` : ''}
      </div>
    </div>
  `;
}

function renderFacilityWarResourceHud(state, profile, previewCard = null) {
  if (!dom.facilityWarResources || !state?.defender) return;
  const capInfo = calculateDefenderStorageInfo(state);
  const production = facilityProductionSummary(state, profile);
  const wheatCurrent = Math.max(0, Number(state.defender.wheat ?? 0));
  const ironCurrent = Math.max(0, Number(state.defender.iron ?? 0));
  const spend = previewCard ? computeDefenderSpendPreview(state, previewCard) : null;
  const wheatSpend = spend && !spend.setupBypass ? spend.wheat : 0;
  const ironSpend = spend && !spend.setupBypass ? spend.iron : 0;
  const manaSpend = spend && !spend.setupBypass ? spend.mana : 0;
  const storageBonusW = Math.max(0, capInfo.wheatCap - 10);
  const storageBonusI = Math.max(0, capInfo.ironCap - 10);
  const ratioW = capInfo.wheatCap > 0 ? (wheatCurrent / capInfo.wheatCap) : 0;
  const ratioI = capInfo.ironCap > 0 ? (ironCurrent / capInfo.ironCap) : 0;
  const nearCapText = ratioW >= 0.9 || ratioI >= 0.9
    ? '<div class="facility-resource-warning">Storage nearing capacity.</div>'
    : '';
  const clampNote = state.defender.lastCapClamp
    && (Date.now() - Number(state.defender.lastCapClamp.ts ?? 0)) < 4800
    && (Number(state.defender.lastCapClamp.lostWheat ?? 0) > 0 || Number(state.defender.lastCapClamp.lostIron ?? 0) > 0)
    ? `<div class="facility-resource-warning">Overflow discarded: W${Math.max(0, Number(state.defender.lastCapClamp.lostWheat ?? 0))}/I${Math.max(0, Number(state.defender.lastCapClamp.lostIron ?? 0))}</div>`
    : '';
  const previewText = spend
    ? `<div class="facility-resource-preview-note ${spend.affordable ? '' : 'warning'}">${previewCard?.name ?? 'Card'} • ${spend.message}</div>`
    : '<div class="facility-resource-preview-note">Hover or select a card to preview projected spend.</div>';
  const attackerMana = Math.max(0, Number(state.attacker?.mana ?? 0));
  const attackerPylons = Math.max(0, Number(state.attacker?.manaPylons ?? 0));
  const manaMissing = spend ? Math.max(0, Number(spend.missingMana ?? 0)) : 0;
  dom.facilityWarResources.innerHTML = `
    ${facilityResourceGaugeMarkup({
    icon: './game/icons/wheat.svg',
    label: 'Wheat',
    current: wheatCurrent,
    cap: capInfo.wheatCap,
    previewSpend: wheatSpend,
    gainPerTurn: production.wheatPerTurn,
    capBonus: storageBonusW,
    missing: spend ? spend.missingWheat : 0,
    previewActive: !!spend,
  })}
    ${facilityResourceGaugeMarkup({
    icon: './game/icons/iron.svg',
    label: 'Iron',
    current: ironCurrent,
    cap: capInfo.ironCap,
    previewSpend: ironSpend,
    gainPerTurn: production.ironPerTurn,
    capBonus: storageBonusI,
    missing: spend ? spend.missingIron : 0,
    previewActive: !!spend,
  })}
    ${nearCapText}
    ${clampNote}
    <div class="facility-resource-row compact"><strong>Draws Left</strong><span>${state.phase === 'setup' ? '—' : state.drawActionsLeft}</span></div>
    <div class="facility-resource-row compact"><strong>Discounts</strong><span>W-${Number(state.defender.tempWheatDiscount ?? 0)} / I-${Number(state.defender.tempIronDiscount ?? 0)}${Number(state.defender.trainingDiscountCharges ?? 0) > 0 ? ` • Training ${Number(state.defender.trainingDiscountCharges ?? 0)}` : ''}</span></div>
    <div class="facility-resource-row compact ${manaMissing > 0 ? 'warning' : ''}"><span class="facility-resource-label"><img class="facility-resource-icon" src="./game/icons/mana.svg" alt="Mana" /> <strong>Attacker Mana</strong></span><span>${attackerMana} (Pylons ${attackerPylons})${manaSpend > 0 ? ` → ${Math.max(0, attackerMana - manaSpend)}` : ''}</span></div>
    ${previewText}
  `;
}

function normalizedFacilityBoardZoom() {
  return clamp(toFiniteNumber(modalUiState.facilityWar.boardZoom, 1), 0.65, 2.2);
}

function bindFacilityBoardPan(shell) {
  if (!shell || facilityBoardPanBound) return;
  shell.addEventListener('pointerdown', (event) => {
    if (shell.dataset.viewMode !== 'focus') return;
    if (event.button !== 0 || !event.shiftKey) return;
    facilityBoardPanState = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      scrollLeft: shell.scrollLeft,
      scrollTop: shell.scrollTop,
    };
    shell.classList.add('is-panning');
    if (shell.setPointerCapture) shell.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  shell.addEventListener('pointermove', (event) => {
    if (!facilityBoardPanState) return;
    if (event.pointerId !== facilityBoardPanState.pointerId) return;
    const dx = event.clientX - facilityBoardPanState.startX;
    const dy = event.clientY - facilityBoardPanState.startY;
    shell.scrollLeft = facilityBoardPanState.scrollLeft - dx;
    shell.scrollTop = facilityBoardPanState.scrollTop - dy;
    event.preventDefault();
  });
  const endPan = (event) => {
    if (!facilityBoardPanState) return;
    if (event?.pointerId && facilityBoardPanState.pointerId !== event.pointerId) return;
    facilityBoardPanState = null;
    shell.classList.remove('is-panning');
  };
  shell.addEventListener('pointerup', endPan);
  shell.addEventListener('pointercancel', endPan);
  shell.addEventListener('mouseleave', endPan);
  facilityBoardPanBound = true;
}

function bindFacilityBoardResize() {
  if (facilityBoardResizeBound) return;
  window.addEventListener('resize', () => {
    if (!dom.facilityWarModal || dom.facilityWarModal.classList.contains('hidden')) return;
    requestAnimationFrame(() => {
      applyFacilityBoardViewState();
    });
  }, { passive: true });
  facilityBoardResizeBound = true;
}

function centerFacilityBoardViewport() {
  const shell = dom.facilityWarGrid?.parentElement;
  if (!shell) return;
  shell.scrollLeft = Math.max(0, (shell.scrollWidth - shell.clientWidth) * 0.5);
  shell.scrollTop = Math.max(0, (shell.scrollHeight - shell.clientHeight) * 0.5);
}

function applyFacilityBoardViewState() {
  const grid = dom.facilityWarGrid;
  const shell = grid?.parentElement;
  if (!grid || !shell) return;
  bindFacilityBoardPan(shell);
  bindFacilityBoardResize();
  const mode = String(modalUiState.facilityWar.boardViewMode ?? 'fit') === 'focus' ? 'focus' : 'fit';
  const zoom = normalizedFacilityBoardZoom();
  shell.dataset.viewMode = mode;
  grid.dataset.viewMode = mode;
  grid.style.setProperty('--facility-board-zoom', zoom.toFixed(3));
  const gridStyles = window.getComputedStyle(grid);
  const gapX = Math.max(0, Number.parseFloat(gridStyles.columnGap || gridStyles.gap || '0') || 0);
  const gapY = Math.max(0, Number.parseFloat(gridStyles.rowGap || gridStyles.gap || '0') || gapX);
  const baseCellW = 112;
  const baseCellH = 82;
  const totalGapX = gapX * Math.max(0, CONQUEST_GRID_COLS - 1);
  const totalGapY = gapY * Math.max(0, CONQUEST_GRID_ROWS - 1);
  grid.style.minWidth = '0';
  grid.style.minHeight = '0';
  grid.style.maxWidth = 'none';
  grid.style.maxHeight = 'none';
  grid.style.alignContent = 'start';
  grid.style.justifyContent = 'start';
  if (mode === 'focus') {
    const cellW = Math.round(baseCellW * zoom);
    const cellH = Math.round(baseCellH * zoom);
    const boardW = (cellW * CONQUEST_GRID_COLS) + totalGapX;
    const boardH = (cellH * CONQUEST_GRID_ROWS) + totalGapY;
    shell.style.overflow = 'auto';
    shell.title = 'Focus Mode: Shift + drag to pan the board.';
    grid.style.margin = '0';
    grid.style.width = `${boardW}px`;
    grid.style.height = `${boardH}px`;
    grid.style.gridTemplateColumns = `repeat(${CONQUEST_GRID_COLS}, minmax(${cellW}px, ${cellW}px))`;
    grid.style.gridTemplateRows = `repeat(${CONQUEST_GRID_ROWS}, minmax(${cellH}px, ${cellH}px))`;
  } else {
    const shellStyles = window.getComputedStyle(shell);
    const shellPadX = (Number.parseFloat(shellStyles.paddingLeft || '0') || 0) + (Number.parseFloat(shellStyles.paddingRight || '0') || 0);
    const shellPadY = (Number.parseFloat(shellStyles.paddingTop || '0') || 0) + (Number.parseFloat(shellStyles.paddingBottom || '0') || 0);
    const usableW = Math.max(280, shell.clientWidth - shellPadX - 2);
    const usableH = Math.max(220, shell.clientHeight - shellPadY - 2);
    // Fit mode should consume the available shell area so the grid does not leave dead space.
    const rawCellW = (usableW - totalGapX) / Math.max(1, CONQUEST_GRID_COLS);
    const rawCellH = (usableH - totalGapY) / Math.max(1, CONQUEST_GRID_ROWS);
    const cellW = Math.max(26, Math.floor(rawCellW));
    const cellH = Math.max(26, Math.floor(rawCellH));
    const boardW = (cellW * CONQUEST_GRID_COLS) + totalGapX;
    const boardH = (cellH * CONQUEST_GRID_ROWS) + totalGapY;
    shell.style.overflow = 'hidden';
    shell.title = 'Fit Mode: entire battlemat auto-scales to visible area.';
    shell.scrollLeft = 0;
    shell.scrollTop = 0;
    grid.style.margin = '0';
    grid.style.width = `${boardW}px`;
    grid.style.height = `${boardH}px`;
    grid.style.gridTemplateColumns = `repeat(${CONQUEST_GRID_COLS}, minmax(${cellW}px, ${cellW}px))`;
    grid.style.gridTemplateRows = `repeat(${CONQUEST_GRID_ROWS}, minmax(${cellH}px, ${cellH}px))`;
  }
  if (dom.facilityFitBoardBtn) dom.facilityFitBoardBtn.classList.toggle('active', mode === 'fit');
  if (dom.facilityFocusBoardBtn) dom.facilityFocusBoardBtn.classList.toggle('active', mode === 'focus');
  if (dom.facilityZoomInBtn) dom.facilityZoomInBtn.disabled = mode !== 'focus' || zoom >= 2.15;
  if (dom.facilityZoomOutBtn) dom.facilityZoomOutBtn.disabled = mode !== 'focus' || zoom <= 0.7;
  if (dom.facilityResetBoardBtn) dom.facilityResetBoardBtn.disabled = mode === 'fit' && Math.abs(zoom - 1) < 0.01;
}

function conquestCardTotalCost(card = {}) {
  return Math.max(0, Number(card.cost?.wheat ?? 0))
    + Math.max(0, Number(card.cost?.iron ?? 0))
    + Math.max(0, Number(card.cost?.mana ?? 0));
}

function getFilteredSortedFacilityHand(state, profile) {
  const hand = Array.isArray(state?.defender?.hand) ? state.defender.hand.slice() : [];
  const filter = String(modalUiState.facilityWar.handCategoryFilter ?? 'all').toLowerCase();
  const sortMode = String(modalUiState.facilityWar.handSort ?? 'none').toLowerCase();
  const enriched = hand.map((entry) => {
    const card = conquestCardById(profile, entry.cardId);
    return {
      entry,
      card,
      category: card ? conquestHandCategory(card) : 'support',
    };
  }).filter((row) => !!row.card);
  let filtered = enriched;
  if (filter !== 'all') {
    filtered = enriched.filter((row) => row.category === filter);
  }
  const sorted = filtered.slice();
  if (sortMode === 'cost') {
    sorted.sort((a, b) => conquestCardTotalCost(a.card) - conquestCardTotalCost(b.card) || String(a.card.name).localeCompare(String(b.card.name)));
  } else if (sortMode === 'type') {
    sorted.sort((a, b) => String(a.category).localeCompare(String(b.category)) || String(a.card.name).localeCompare(String(b.card.name)));
  } else if (sortMode === 'source') {
    sorted.sort((a, b) => String(a.card.sourceBuilding ?? a.card.productionSource ?? '').localeCompare(String(b.card.sourceBuilding ?? b.card.productionSource ?? '')) || String(a.card.name).localeCompare(String(b.card.name)));
  }
  return sorted;
}

function getConquestInspectCandidateIndices(state) {
  if (!state?.grid?.length) return [];
  return state.grid
    .map((cell, idx) => ({ cell, idx }))
    .filter((row) => !!row.cell?.occupant)
    .map((row) => row.idx);
}

function buildConquestThreatHeatmap(state, perspective = 'defender') {
  const side = String(perspective ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender';
  const enemy = side === 'defender' ? 'attacker' : 'defender';
  const dangerCounts = new Map();
  const supportCounts = new Map();
  const turretDangerCounts = new Map();
  toArray(state?.grid).forEach((cell, idx) => {
    const occ = cell?.occupant;
    if (!occ || Number(occ.hp ?? 0) <= 0) return;
    const occSide = String(occ.side ?? '').toLowerCase();
    if (occSide !== side && occSide !== enemy) return;
    const tags = new Set(toArray(occ.tags).map((tag) => String(tag).toLowerCase()));
    const targets = collectConquestAttackTargets(state, idx, occ);
    targets.forEach((target) => {
      if (!Number.isInteger(target?.idx)) return;
      const map = occSide === side ? supportCounts : dangerCounts;
      map.set(target.idx, Number(map.get(target.idx) ?? 0) + 1);
      if (occSide === enemy && tags.has('turret')) {
        turretDangerCounts.set(target.idx, Number(turretDangerCounts.get(target.idx) ?? 0) + 1);
      }
    });
  });
  const contested = new Set([...dangerCounts.keys()].filter((idx) => supportCounts.has(idx)));
  const maxDanger = Math.max(1, ...dangerCounts.values(), ...turretDangerCounts.values());
  const maxSupport = Math.max(1, ...supportCounts.values());
  return { side, enemy, dangerCounts, supportCounts, turretDangerCounts, contested, maxDanger, maxSupport };
}

function buildConquestLaneControl(state, perspective = 'defender', heatmap = null) {
  const side = String(perspective ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender';
  const enemy = side === 'defender' ? 'attacker' : 'defender';
  return Array.from({ length: CONQUEST_GRID_ROWS }, (_, row) => {
    let alliedUnits = 0;
    let enemyUnits = 0;
    let alliedControl = 0;
    let enemyControl = 0;
    let dangerCells = 0;
    let supportCells = 0;
    let enemyBreak = 0;
    for (let col = 0; col < CONQUEST_GRID_COLS; col += 1) {
      const idx = facilityCellIndex(row, col);
      const cell = state.grid[idx];
      const occ = cell?.occupant;
      const zone = conquestZoneForCol(col);
      if (cell?.owner === side) alliedControl += 1;
      else if (cell?.owner === enemy) enemyControl += 1;
      if (occ?.side === side) alliedUnits += 1;
      else if (occ?.side === enemy) {
        enemyUnits += 1;
        if (zone === side) enemyBreak += 1;
      }
      if (heatmap?.dangerCounts?.has(idx)) dangerCells += Number(heatmap.dangerCounts.get(idx) ?? 0);
      if (heatmap?.supportCounts?.has(idx)) supportCells += Number(heatmap.supportCounts.get(idx) ?? 0);
    }
    const score = ((alliedUnits * 2) + alliedControl + supportCells) - ((enemyUnits * 2) + enemyControl + dangerCells + (enemyBreak * 2));
    let stateKey = 'contested';
    let label = 'Contested';
    if (score >= 4) {
      stateKey = 'allied';
      label = 'Secured';
    } else if (score <= -4) {
      stateKey = 'enemy';
      label = 'Pressured';
    }
    return {
      row,
      alliedUnits,
      enemyUnits,
      alliedControl,
      enemyControl,
      dangerCells,
      supportCells,
      enemyBreak,
      score,
      stateKey,
      label,
    };
  });
}

function renderConquestBattleStatus(state, profile, perspective = 'defender', heatmap = null, laneRows = []) {
  if (!dom.facilityBattleStatusChips) return;
  const side = String(perspective ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender';
  const enemy = side === 'defender' ? 'attacker' : 'defender';
  const production = facilityProductionSummary(state, profile);
  let enemyFrontline = 0;
  let alliedFrontline = 0;
  let activeBuffs = 0;
  let activeDebuffs = 0;
  toArray(state?.grid).forEach((cell, idx) => {
    const occ = cell?.occupant;
    if (!occ) return;
    const col = idx % CONQUEST_GRID_COLS;
    const zone = conquestZoneForCol(col);
    if (occ.side === enemy && zone === side) enemyFrontline += 1;
    if (occ.side === side && zone === enemy) alliedFrontline += 1;
    const status = occ.status ?? {};
    const buffKeys = ['attackBonus', 'defenseBonus', 'hpBonus', 'fortified', 'shield', 'moraleBoost', 'wheatPerTurnBonus', 'ironPerTurnBonus'];
    const debuffKeys = ['moraleStunned', 'disabledTurns', 'shaken', 'weakened'];
    buffKeys.forEach((key) => {
      const value = status[key];
      if (value === true || Number(value ?? 0) > 0) activeBuffs += 1;
    });
    debuffKeys.forEach((key) => {
      const value = status[key];
      if (value === true || Number(value ?? 0) > 0) activeDebuffs += 1;
    });
  });
  const laneBreaks = laneRows.filter((entry) => Number(entry.enemyBreak ?? 0) > 0).length;
  const pressuredLanes = laneRows.filter((entry) => entry.stateKey === 'enemy').length;
  const weather = String(state?.weather?.active ?? state?.weather?.name ?? 'Clear');
  const chips = [
    { label: 'Attacker Pressure', value: `${enemyFrontline} breach${enemyFrontline === 1 ? '' : 'es'}`, tone: enemyFrontline > 0 ? 'danger' : 'ok' },
    { label: 'Defender Economy', value: `+W${production.wheatPerTurn}/+I${production.ironPerTurn}`, tone: (production.wheatPerTurn + production.ironPerTurn) >= 8 ? 'ok' : 'warn' },
    { label: 'Lane Breaks', value: `${laneBreaks}/${CONQUEST_GRID_ROWS}`, tone: laneBreaks > 0 ? 'danger' : 'ok' },
    { label: 'Threat Cells', value: `${heatmap?.dangerCounts?.size ?? 0} hot`, tone: (heatmap?.dangerCounts?.size ?? 0) > 8 ? 'danger' : 'warn' },
    { label: 'Buff/Debuff', value: `${activeBuffs}/${activeDebuffs}`, tone: activeDebuffs > activeBuffs ? 'warn' : 'ok' },
    { label: 'Weather', value: weather, tone: weather.toLowerCase() === 'clear' ? 'neutral' : 'warn' },
    { label: 'Forward Control', value: `${alliedFrontline} push • ${pressuredLanes} pressured lanes`, tone: pressuredLanes > 0 ? 'warn' : 'ok' },
  ];
  dom.facilityBattleStatusChips.innerHTML = chips.map((chip) => `
    <article class="facility-status-chip tone-${chip.tone}">
      <small>${chip.label}</small>
      <strong>${chip.value}</strong>
    </article>
  `).join('');
}

function renderConquestLaneControl(laneRows = [], heatmap = null) {
  if (!dom.facilityLaneControl) return;
  if (!Array.isArray(laneRows) || !laneRows.length) {
    dom.facilityLaneControl.innerHTML = '';
    return;
  }
  dom.facilityLaneControl.innerHTML = laneRows.map((lane) => {
    const dangerScore = Math.max(0, Number(lane.dangerCells ?? 0));
    const supportScore = Math.max(0, Number(lane.supportCells ?? 0));
    const pressure = clamp((Math.abs(Number(lane.score ?? 0)) / 14) * 100, 4, 100);
    const className = lane.stateKey === 'allied'
      ? 'lane-allied'
      : lane.stateKey === 'enemy'
        ? 'lane-enemy'
        : 'lane-contested';
    const threatTone = dangerScore > supportScore ? 'danger' : supportScore > dangerScore ? 'support' : 'neutral';
    const turretThreat = heatmap
      ? Array.from({ length: CONQUEST_GRID_COLS }, (_, col) => facilityCellIndex(lane.row, col))
        .reduce((acc, idx) => acc + Number(heatmap.turretDangerCounts.get(idx) ?? 0), 0)
      : 0;
    return `
      <article class="facility-lane-chip ${className}">
        <header>
          <strong>Lane ${lane.row + 1}</strong>
          <span>${lane.label}</span>
        </header>
        <div class="facility-lane-meta">${lane.alliedUnits} ally • ${lane.enemyUnits} enemy • ctrl ${lane.alliedControl}:${lane.enemyControl}</div>
        <div class="facility-lane-bar">
          <span class="facility-lane-fill tone-${threatTone}" style="width:${pressure.toFixed(1)}%"></span>
        </div>
        <div class="facility-lane-meta">${dangerScore} threat • ${supportScore} support${turretThreat > 0 ? ` • turret ${turretThreat}` : ''}${lane.enemyBreak > 0 ? ` • breach ${lane.enemyBreak}` : ''}</div>
      </article>
    `;
  }).join('');
}

function renderConquestHeatmapLegend(heatmap = null, laneRows = [], enabled = false) {
  if (!dom.facilityHeatmapLegend) return;
  dom.facilityHeatmapLegend.classList.toggle('hidden', !enabled);
  if (!enabled || !heatmap) {
    dom.facilityHeatmapLegend.innerHTML = '';
    return;
  }
  const hotCells = Number(heatmap?.dangerCounts?.size ?? 0);
  const supportCells = Number(heatmap?.supportCounts?.size ?? 0);
  const contested = Number(heatmap?.contested?.size ?? 0);
  const turretCells = Number(heatmap?.turretDangerCounts?.size ?? 0);
  const hottestLane = (Array.isArray(laneRows) ? laneRows : [])
    .slice()
    .sort((a, b) => Number(b?.dangerCells ?? 0) - Number(a?.dangerCells ?? 0))[0];
  dom.facilityHeatmapLegend.innerHTML = `
    <span class="chip chip-danger">Danger ${hotCells}</span>
    <span class="chip chip-support">Support ${supportCells}</span>
    <span class="chip chip-contested">Contested ${contested}</span>
    <span class="chip chip-turret">Turret Coverage ${turretCells}</span>
    <span class="chip chip-lane">Hot Lane ${hottestLane ? (hottestLane.row + 1) : '—'}</span>
  `;
}

function ensureFacilityDevPanelState() {
  FACILITY_DEV_PANEL_REGISTRY.forEach((panel) => {
    if (typeof facilityDevUiState.visibility[panel.id] !== 'boolean') facilityDevUiState.visibility[panel.id] = false;
    if (typeof facilityDevUiState.collapsed[panel.id] !== 'boolean') facilityDevUiState.collapsed[panel.id] = false;
  });
}

function resolveFacilityDevPanelIds(spec = '') {
  const key = String(spec ?? '').trim().replace(/^-+/, '').toLowerCase();
  if (!key) return [];
  if (FACILITY_DEV_GROUPS[key]) return FACILITY_DEV_GROUPS[key].slice();
  const direct = FACILITY_DEV_ALIAS[key];
  return direct ? [direct] : [];
}

function listFacilityDevPanelNames() {
  return FACILITY_DEV_PANEL_REGISTRY.map((panel) => panel.id);
}

function setFacilityDevPanelVisible(panelId, visible = true) {
  ensureFacilityDevPanelState();
  const normalized = FACILITY_DEV_ALIAS[String(panelId ?? '').toLowerCase()];
  if (!normalized) return false;
  facilityDevUiState.visibility[normalized] = !!visible;
  return true;
}

function setFacilityDevPanelsVisible(ids = [], visible = true) {
  let changed = false;
  ids.forEach((id) => {
    changed = setFacilityDevPanelVisible(id, visible) || changed;
  });
  return changed;
}

function showAllFacilityDevPanels() {
  ensureFacilityDevPanelState();
  FACILITY_DEV_PANEL_REGISTRY.forEach((panel) => {
    facilityDevUiState.visibility[panel.id] = true;
  });
  facilityDevUiState.enabled = true;
  localStorage.setItem('cf_conquest_ai_debug', '1');
}

function hideAllFacilityDevPanels() {
  ensureFacilityDevPanelState();
  FACILITY_DEV_PANEL_REGISTRY.forEach((panel) => {
    facilityDevUiState.visibility[panel.id] = false;
  });
  facilityDevUiState.enabled = false;
  localStorage.setItem('cf_conquest_ai_debug', '0');
}

function pushFacilityDevTrace(text = '', type = 'info') {
  if (!text) return;
  facilityDevUiState.metrics.actionTrace.push({
    ts: Date.now(),
    type,
    text: String(text),
  });
  if (facilityDevUiState.metrics.actionTrace.length > 120) facilityDevUiState.metrics.actionTrace.shift();
}

function sampleFacilityDevMetrics(state, laneRows = [], heatmap = null) {
  const now = Date.now();
  if ((now - Number(facilityDevUiState.lastSampleAt ?? 0)) < 260) return;
  facilityDevUiState.lastSampleAt = now;
  const laneDelta = Array.isArray(laneRows) ? laneRows.reduce((sum, lane) => sum + Number(lane.score ?? 0), 0) : 0;
  const production = facilityProductionSummary(state, loadProfile());
  facilityDevUiState.metrics.aiTimeline.push({
    ts: now,
    turn: Number(state?.turn ?? 0),
    phase: String(state?.phase ?? 'setup'),
    side: String(state?.side ?? 'defender'),
    laneDelta,
    aiTier: conquestAiSkillTier(state),
  });
  if (facilityDevUiState.metrics.aiTimeline.length > 90) facilityDevUiState.metrics.aiTimeline.shift();
  facilityDevUiState.metrics.economyTimeline.push({
    ts: now,
    wheat: Number(state?.defender?.wheat ?? 0),
    iron: Number(state?.defender?.iron ?? 0),
    mana: Number(state?.attacker?.mana ?? 0),
    wheatPerTurn: Number(production?.wheatPerTurn ?? 0),
    ironPerTurn: Number(production?.ironPerTurn ?? 0),
  });
  if (facilityDevUiState.metrics.economyTimeline.length > 90) facilityDevUiState.metrics.economyTimeline.shift();
  facilityDevUiState.metrics.laneDeltaTimeline.push({
    ts: now,
    delta: laneDelta,
    threatCells: Number(heatmap?.dangerCounts?.size ?? 0),
  });
  if (facilityDevUiState.metrics.laneDeltaTimeline.length > 90) facilityDevUiState.metrics.laneDeltaTimeline.shift();
}

function facilityDevSparkline(values = [], toneFn = null) {
  if (!values.length) return '<div class="facility-dev-note">No samples yet.</div>';
  const max = Math.max(1, ...values.map((value) => Math.abs(Number(value ?? 0))));
  return `<div class="facility-dev-spark">${values.map((raw) => {
    const value = Number(raw ?? 0);
    const height = Math.max(4, Math.round((Math.abs(value) / max) * 100));
    const tone = typeof toneFn === 'function' ? String(toneFn(value) ?? '') : '';
    return `<i class="${tone}" style="height:${height}%"></i>`;
  }).join('')}</div>`;
}

function renderFacilityDevPanelBody(panelId, state, profile, laneRows = [], heatmap = null) {
  if (panelId === 'aiPlanner') {
    const aiTier = conquestAiSkillTier(state);
    const latestLogs = toArray(state?.log).slice(-6).reverse();
    return `
      <div class="facility-dev-kv">
        <strong>AI Tier</strong><div>${aiTier}★</div>
        <strong>Phase</strong><div>${state.phase ?? 'setup'} • side ${state.side ?? 'defender'}</div>
        <strong>Turn</strong><div>${state.turn ?? 1}</div>
        <strong>Skill Stars</strong><div>${clamp(Number(state?.encounter?.aiSkillStars ?? 1), 1, 5)}★</div>
      </div>
      <ul class="facility-dev-list">${latestLogs.map((entry) => `<li>${String(entry?.text ?? '').slice(0, 120)}</li>`).join('')}</ul>
    `;
  }
  if (panelId === 'aiGraphs') {
    const laneSeries = facilityDevUiState.metrics.laneDeltaTimeline.slice(-36).map((row) => Number(row.delta ?? 0));
    const threatSeries = facilityDevUiState.metrics.laneDeltaTimeline.slice(-36).map((row) => Number(row.threatCells ?? 0));
    return `
      <div class="facility-dev-note">Lane delta over time</div>
      ${facilityDevSparkline(laneSeries)}
      <div class="facility-dev-note">Threat-cell pressure</div>
      ${facilityDevSparkline(threatSeries)}
    `;
  }
  if (panelId === 'deckViewer' || panelId === 'conquestDecks') {
    const drawDecks = state?.defender?.drawDecks ?? {};
    const pile = Object.entries(drawDecks).map(([key, cards]) => `<li>${key}: ${(cards ?? []).length} cards</li>`).join('');
    return `
      <div class="facility-dev-kv">
        <strong>Attacker Deck</strong><div>${state?.attacker?.deck?.length ?? 0}</div>
        <strong>Attacker Hand</strong><div>${state?.attacker?.hand?.length ?? 0}</div>
        <strong>Defender Hand</strong><div>${state?.defender?.hand?.length ?? 0}</div>
        <strong>Draw Actions</strong><div>${state?.drawActionsLeft ?? 0}</div>
      </div>
      <ul class="facility-dev-list">${pile || '<li>No draw decks found.</li>'}</ul>
    `;
  }
  if (panelId === 'deckGraphs') {
    const attackerCosts = toArray(state?.attacker?.deck).slice(0, 40).map((cardId) => Number(conquestCardById(profile, cardId)?.cost?.mana ?? 0));
    const handCosts = toArray(state?.defender?.hand).map((entry) => {
      const card = conquestCardById(profile, entry?.cardId);
      return Number(card?.cost?.wheat ?? 0) + Number(card?.cost?.iron ?? 0);
    });
    return `
      <div class="facility-dev-note">Attacker mana curve</div>
      ${facilityDevSparkline(attackerCosts)}
      <div class="facility-dev-note">Defender hand cost curve</div>
      ${facilityDevSparkline(handCosts)}
    `;
  }
  if (panelId === 'economy') {
    const economy = facilityDevUiState.metrics.economyTimeline.slice(-36);
    return `
      <div class="facility-dev-kv">
        <strong>Wheat</strong><div>${state?.defender?.wheat ?? 0}</div>
        <strong>Iron</strong><div>${state?.defender?.iron ?? 0}</div>
        <strong>Mana</strong><div>${state?.attacker?.mana ?? 0}</div>
        <strong>Storage</strong><div>W ${calculateDefenderStorageInfo(state).wheatCap} / I ${calculateDefenderStorageInfo(state).ironCap}</div>
      </div>
      <div class="facility-dev-note">Wheat trend</div>
      ${facilityDevSparkline(economy.map((row) => Number(row.wheat ?? 0)))}
      <div class="facility-dev-note">Iron trend</div>
      ${facilityDevSparkline(economy.map((row) => Number(row.iron ?? 0)))}
    `;
  }
  if (panelId === 'threatMap') {
    return `
      <div class="facility-dev-kv">
        <strong>Danger Cells</strong><div>${Number(heatmap?.dangerCounts?.size ?? 0)}</div>
        <strong>Support Cells</strong><div>${Number(heatmap?.supportCounts?.size ?? 0)}</div>
        <strong>Contested</strong><div>${Number(heatmap?.contested?.size ?? 0)}</div>
        <strong>Turret Coverage</strong><div>${Number(heatmap?.turretDangerCounts?.size ?? 0)}</div>
      </div>
    `;
  }
  if (panelId === 'lanePressure') {
    const lanes = laneRows.slice().sort((a, b) => Number(b.score ?? 0) - Number(a.score ?? 0));
    return `<ul class="facility-dev-list">${lanes.map((lane) => `<li>Lane ${lane.row + 1}: score ${Math.round(lane.score)} • ally ${lane.alliedUnits} / enemy ${lane.enemyUnits}</li>`).join('')}</ul>`;
  }
  if (panelId === 'battleStats' || panelId === 'warStats') {
    const winner = state?.winner ?? 'none';
    const attackerUnits = toArray(state?.grid).filter((cell) => cell?.occupant?.side === 'attacker').length;
    const defenderUnits = toArray(state?.grid).filter((cell) => cell?.occupant?.side === 'defender').length;
    return `
      <div class="facility-dev-kv">
        <strong>Turn</strong><div>${state?.turn ?? 1}</div>
        <strong>Phase</strong><div>${state?.phase ?? 'setup'}</div>
        <strong>Winner</strong><div>${winner}</div>
        <strong>Units</strong><div>Def ${defenderUnits} / Att ${attackerUnits}</div>
      </div>
    `;
  }
  if (panelId === 'handStats') {
    const hand = toArray(state?.defender?.hand);
    const byType = hand.reduce((acc, entry) => {
      const card = conquestCardById(profile, entry.cardId);
      const key = conquestHandCategory(card);
      acc[key] = Number(acc[key] ?? 0) + 1;
      return acc;
    }, {});
    return `<ul class="facility-dev-list">${Object.entries(byType).map(([type, count]) => `<li>${type}: ${count}</li>`).join('') || '<li>No hand cards.</li>'}</ul>`;
  }
  if (panelId === 'turnFlow' || panelId === 'debugLog' || panelId === 'actionTrace') {
    const trace = facilityDevUiState.metrics.actionTrace.slice(-20).reverse();
    return trace.length
      ? `<ul class="facility-dev-list">${trace.map((entry) => `<li>[${new Date(entry.ts).toLocaleTimeString()}] ${entry.text}</li>`).join('')}</ul>`
      : '<div class="facility-dev-note">No trace events yet.</div>';
  }
  if (panelId === 'ownership') {
    const ownerCounts = toArray(state?.grid).reduce((acc, cell) => {
      const key = String(cell?.owner ?? 'neutral');
      acc[key] = Number(acc[key] ?? 0) + 1;
      return acc;
    }, {});
    return `<ul class="facility-dev-list">${Object.entries(ownerCounts).map(([owner, count]) => `<li>${owner}: ${count}</li>`).join('')}</ul>`;
  }
  if (panelId === 'movement') {
    const selectedIdx = Number.isInteger(modalUiState.facilityWar.selectedUnitCellIndex) ? modalUiState.facilityWar.selectedUnitCellIndex : null;
    if (!Number.isInteger(selectedIdx)) return '<div class="facility-dev-note">Select a unit to inspect legal moves.</div>';
    const occ = state?.grid?.[selectedIdx]?.occupant;
    const moves = occ ? listLegalUnitMoves(state, selectedIdx, occ) : [];
    return `<div class="facility-dev-kv"><strong>Selected</strong><div>${occ?.name ?? 'none'}</div><strong>Legal Moves</strong><div>${moves.length}</div></div>`;
  }
  if (panelId === 'targeting' || panelId === 'ranges') {
    const selectedIdx = Number.isInteger(modalUiState.facilityWar.selectedAttackSourceIndex) ? modalUiState.facilityWar.selectedAttackSourceIndex : null;
    if (!Number.isInteger(selectedIdx)) return '<div class="facility-dev-note">Select an attacker to inspect targeting.</div>';
    const readout = conquestAttackReadout(state, selectedIdx);
    return `<div class="facility-dev-kv"><strong>Source</strong><div>Cell ${selectedIdx + 1}</div><strong>Can Attack</strong><div>${readout?.canAttack ? 'yes' : 'no'}</div><strong>Targets</strong><div>${toArray(readout?.targets).length}</div></div>`;
  }
  if (panelId === 'structureState') {
    const structures = toArray(state?.grid).map((cell) => cell?.occupant).filter((occ) => occ && (occ.type === 'building' || toArray(occ.tags).includes('structure')));
    return `<ul class="facility-dev-list">${structures.slice(0, 20).map((entry) => `<li>${entry.name}: HP ${entry.hp}/${entry.maxHp ?? entry.hp}</li>`).join('') || '<li>No structures.</li>'}</ul>`;
  }
  if (panelId === 'homesteadState') {
    const homeIdx = findHomesteadIndex(state);
    const home = Number.isInteger(homeIdx) ? state.grid[homeIdx]?.occupant : null;
    return `
      <div class="facility-dev-kv">
        <strong>Homestead</strong><div>${home ? `${home.name} at ${homeIdx + 1}` : 'missing'}</div>
        <strong>Alive</strong><div>${home && Number(home.hp ?? 0) > 0 ? 'yes' : 'no'}</div>
      </div>
    `;
  }
  if (panelId === 'unitTypes') {
    const unitCounts = toArray(state?.grid).map((cell) => cell?.occupant).filter(Boolean).reduce((acc, occ) => {
      toArray(occ.tags).forEach((tag) => {
        const key = String(tag).toLowerCase();
        acc[key] = Number(acc[key] ?? 0) + 1;
      });
      return acc;
    }, {});
    const entries = Object.entries(unitCounts).sort((a, b) => b[1] - a[1]).slice(0, 12);
    return `<ul class="facility-dev-list">${entries.map(([name, count]) => `<li>${name}: ${count}</li>`).join('') || '<li>No tagged units.</li>'}</ul>`;
  }
  if (panelId === 'vfx') {
    return '<div class="facility-dev-note">Conquest VFX events are live. Use this panel with Action Trace to inspect trigger cadence.</div>';
  }
  return '<div class="facility-dev-note">Panel active.</div>';
}

function renderFacilityDevSuite(state, profile, laneRows = [], heatmap = null) {
  if (!dom.facilityDevSuite) return;
  ensureFacilityDevPanelState();
  sampleFacilityDevMetrics(state, laneRows, heatmap);
  const visible = FACILITY_DEV_PANEL_REGISTRY.map((panel) => panel.id).filter((id) => !!facilityDevUiState.visibility[id]);
  const shouldShow = !!facilityDevUiState.enabled && visible.length > 0;
  dom.facilityDevSuite.classList.toggle('hidden', !shouldShow);
  if (!shouldShow) {
    dom.facilityDevSuite.innerHTML = '';
    return;
  }
  dom.facilityDevSuite.innerHTML = visible.map((panelId) => {
    const panel = FACILITY_DEV_PANEL_REGISTRY.find((entry) => entry.id === panelId) ?? { id: panelId, title: panelId };
    const collapsed = !!facilityDevUiState.collapsed[panelId];
    return `
      <article class="facility-dev-panel ${collapsed ? 'collapsed' : ''}">
        <header class="facility-dev-panel-head">
          <button class="facility-dev-collapse" data-facility-dev-collapse="${panelId}">${collapsed ? '>' : 'v'}</button>
          <h5>${panel.title}</h5>
          <small>${panelId}</small>
        </header>
        <div class="facility-dev-panel-body">${renderFacilityDevPanelBody(panelId, state, profile, laneRows, heatmap)}</div>
      </article>
    `;
  }).join('');
  dom.facilityDevSuite.querySelectorAll('[data-facility-dev-collapse]').forEach((button) => {
    button.addEventListener('click', () => {
      const panelId = String(button.dataset.facilityDevCollapse ?? '');
      if (!panelId) return;
      facilityDevUiState.collapsed[panelId] = !facilityDevUiState.collapsed[panelId];
      renderFacilityDevSuite(state, profile, laneRows, heatmap);
    });
  });
}

function handleFacilityDevCommand(raw = '', profile = null) {
  const command = String(raw ?? '').trim();
  if (!command) return { ok: false, message: 'No command entered.' };
  const tokens = command.split(/\s+/).filter(Boolean);
  const key = String(tokens[0] ?? '').toLowerCase();
  const args = tokens.slice(1);
  const activeProfile = profile || loadProfile();
  const worldId = modalUiState.facilityWar.worldId;
  const planetId = modalUiState.facilityWar.planetId;
  const ctx = worldId && planetId ? getWorldPlanet(activeProfile, worldId, planetId) : null;
  const state = ctx?.planet?.facilityWar ?? null;
  ensureFacilityDevPanelState();
  const response = (ok, message) => ({ ok: !!ok, message: String(message ?? '') });
  if (key === './dev') {
    const specs = args.filter((arg) => /^-/.test(String(arg ?? '')));
    if (!specs.length) {
      showAllFacilityDevPanels();
      if (state) pushFacilityDevTrace('Conquest dev suite enabled.', 'dev');
      return response(true, 'Conquest dev suite enabled (all panels).');
    }
    if (specs.some((spec) => /^-help$/i.test(String(spec)))) {
      return response(true, `Hidable panels: ${listFacilityDevPanelNames().join(', ')}`);
    }
    const ids = specs.flatMap((spec) => resolveFacilityDevPanelIds(spec));
    if (!ids.length) return response(false, `Unknown panel specifier(s): ${specs.join(', ')}`);
    setFacilityDevPanelsVisible(ids, true);
    facilityDevUiState.enabled = true;
    localStorage.setItem('cf_conquest_ai_debug', '1');
    return response(true, `Enabled panels: ${ids.join(', ')}`);
  }
  if (key === './hide') {
    const specs = args.filter((arg) => /^-/.test(String(arg ?? '')));
    if (!specs.length) {
      hideAllFacilityDevPanels();
      return response(true, 'Conquest dev suite hidden.');
    }
    if (specs.some((spec) => /^-help$/i.test(String(spec)))) {
      return response(true, `Hidable panels: ${listFacilityDevPanelNames().join(', ')}`);
    }
    const ids = specs.flatMap((spec) => resolveFacilityDevPanelIds(spec));
    if (!ids.length) return response(false, `Unknown panel specifier(s): ${specs.join(', ')}`);
    setFacilityDevPanelsVisible(ids, false);
    const anyVisible = listFacilityDevPanelNames().some((id) => !!facilityDevUiState.visibility[id]);
    facilityDevUiState.enabled = anyVisible;
    if (!anyVisible) localStorage.setItem('cf_conquest_ai_debug', '0');
    return response(true, `Hidden panels: ${ids.join(', ')}`);
  }
  if (key === './cleardev') {
    hideAllFacilityDevPanels();
    facilityDevUiState.metrics.aiTimeline = [];
    facilityDevUiState.metrics.economyTimeline = [];
    facilityDevUiState.metrics.laneDeltaTimeline = [];
    facilityDevUiState.metrics.actionTrace = [];
    return response(true, 'Conquest dev suite reset.');
  }
  if (key === './resetgraphs') {
    facilityDevUiState.metrics.aiTimeline = [];
    facilityDevUiState.metrics.economyTimeline = [];
    facilityDevUiState.metrics.laneDeltaTimeline = [];
    return response(true, 'Conquest graph history reset.');
  }
  if (key === './resetplanner') {
    facilityDevUiState.metrics.lastAiPhase = 'idle';
    facilityDevUiState.metrics.actionTrace = [];
    return response(true, 'Conquest planner trace reset.');
  }
  if (key === './aiplanner' || key === './aidebug') {
    const next = !facilityDevUiState.visibility.aiPlanner;
    setFacilityDevPanelVisible('aiPlanner', next);
    facilityDevUiState.enabled = listFacilityDevPanelNames().some((id) => !!facilityDevUiState.visibility[id]);
    if (facilityDevUiState.enabled) localStorage.setItem('cf_conquest_ai_debug', '1');
    return response(true, `aiPlanner ${next ? 'shown' : 'hidden'}.`);
  }
  if (key === './aigraphs') {
    const next = !facilityDevUiState.visibility.aiGraphs;
    setFacilityDevPanelVisible('aiGraphs', next);
    facilityDevUiState.enabled = listFacilityDevPanelNames().some((id) => !!facilityDevUiState.visibility[id]);
    if (facilityDevUiState.enabled) localStorage.setItem('cf_conquest_ai_debug', '1');
    return response(true, `aiGraphs ${next ? 'shown' : 'hidden'}.`);
  }
  if (key === './deckviewer') {
    const next = !facilityDevUiState.visibility.deckViewer;
    setFacilityDevPanelVisible('deckViewer', next);
    facilityDevUiState.enabled = listFacilityDevPanelNames().some((id) => !!facilityDevUiState.visibility[id]);
    return response(true, `deckViewer ${next ? 'shown' : 'hidden'}.`);
  }
  if (key === './deckgraph' || key === './deckgraphs') {
    const next = !facilityDevUiState.visibility.deckGraphs;
    setFacilityDevPanelVisible('deckGraphs', next);
    facilityDevUiState.enabled = listFacilityDevPanelNames().some((id) => !!facilityDevUiState.visibility[id]);
    return response(true, `deckGraphs ${next ? 'shown' : 'hidden'}.`);
  }
  if (key === './unlockall') {
    const summary = applyLauncherUnlockAll(activeProfile);
    return response(
      true,
      `UnlockAll complete: ${summary.cardsUpdated}/${summary.cardsTotal} cards set to >=4 copies, ${summary.aiUnlocked} AI unlocked, ${summary.dimensionsUnlocked} dimensions discovered.`,
    );
  }
  if (key === './help') {
    return response(true, 'Conquest dev commands: ./dev, ./hide, ./hide -help, ./aiplanner, ./aigraphs, ./deckviewer, ./deckgraph, ./unlockall, ./cleardev, ./resetgraphs, ./resetplanner');
  }
  if (/^\.\/show/.test(key) || key === './aitrace') {
    const ids = resolveFacilityDevPanelIds(key.replace(/^\.\//, ''));
    if (!ids.length) return response(false, `Unknown command: ${key}`);
    setFacilityDevPanelsVisible(ids, true);
    facilityDevUiState.enabled = true;
    return response(true, `Enabled panels: ${ids.join(', ')}`);
  }
  return response(false, `Unknown command: ${key}`);
}

function buildGroupedFacilityLogEntries(log = []) {
  const grouped = [];
  toArray(log).forEach((entry) => {
    const text = String(entry?.text ?? '').trim();
    if (!text) return;
    const level = String(entry?.level ?? 'info');
    const ts = Number(entry?.ts ?? Date.now());
    const prev = grouped[grouped.length - 1];
    if (prev && prev.text === text && prev.level === level) {
      prev.count += 1;
      prev.lastTs = ts;
      return;
    }
    grouped.push({
      text,
      level,
      count: 1,
      firstTs: ts,
      lastTs: ts,
    });
  });
  return grouped;
}

function renderFacilityWarLog(state, groupedMode = false) {
  if (!dom.facilityWarLog) return;
  const sourceEntries = toArray(state?.log);
  if (!sourceEntries.length) {
    dom.facilityWarLog.innerHTML = '<div class="facility-log-entry">No battle events yet.</div>';
    return;
  }
  dom.facilityWarLog.innerHTML = '';
  const entries = groupedMode
    ? buildGroupedFacilityLogEntries(sourceEntries).slice(-20).reverse()
    : sourceEntries.slice(-22).reverse().map((entry) => ({
      text: String(entry?.text ?? ''),
      level: String(entry?.level ?? 'info'),
      count: 1,
      firstTs: Number(entry?.ts ?? Date.now()),
      lastTs: Number(entry?.ts ?? Date.now()),
    }));
  entries.forEach((entry) => {
    const item = document.createElement('div');
    item.className = `facility-log-entry ${entry.level === 'good' ? 'good' : entry.level === 'bad' ? 'bad' : ''}`;
    const time = new Date(entry.lastTs ?? Date.now()).toLocaleTimeString();
    const repeat = Number(entry.count ?? 1) > 1 ? ` ×${Number(entry.count)}` : '';
    item.textContent = `${time} • ${entry.text}${repeat}`;
    dom.facilityWarLog.appendChild(item);
  });
}

function renderFacilityWarModal(profile) {
  const worldId = modalUiState.facilityWar.worldId;
  const planetId = modalUiState.facilityWar.planetId;
  if (!worldId || !planetId || !dom.facilityWarHeader) return;
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) {
    dom.facilityWarHeader.textContent = 'Facility world/planet not found.';
    return;
  }
  ensurePlanetConquestState(world, planet);
  const state = planet.facilityWar;
  applyConquestMatToModal(state);
  state.attacker.manaPylons = Math.max(1, attackerPylonCount(state));
  const inSetup = state.phase === 'setup';
  const playerSide = String(state.playerSide ?? 'defender').toLowerCase() === 'attacker' ? 'attacker' : 'defender';
  const attackerAi = state.aiControl?.attacker ?? (playerSide !== 'attacker');
  const defenderAi = state.aiControl?.defender ?? (playerSide !== 'defender');
  const completion = objectiveCompletion(planet);
  const encounterType = String(state.encounter?.threatType ?? 'manual').toLowerCase();
  const attackerMeta = state.encounter?.attackerDeckMeta ?? state.attacker?.deckMeta ?? null;
  const encounterLabel = encounterType === 'alien'
    ? 'Alien Incursion'
    : encounterType === 'pirate'
      ? 'Pirate Raid'
      : encounterType === 'objective'
        ? 'Stronghold Assault'
        : 'Facility War';
  const attackerFactionLabel = String(
    state.encounter?.factionName
    ?? attackerMeta?.faction
    ?? state.encounter?.factionId
    ?? state.encounter?.aiName
    ?? encounterLabel,
  );
  const attackerStars = clamp(Math.round(toFiniteNumber(state.encounter?.aiSkillStars, 1)), 1, 5);
  const attackerStarLabel = '★'.repeat(attackerStars);
  const deckSeriesLabel = attackerMeta?.deckName
    ?? state.encounter?.deckSeries
    ?? conquestDeckSeriesName(state.encounter?.factionId, state.encounter?.deckTriangles, attackerMeta?.variant ?? conquestDeckVariantForStars(state.encounter?.aiSkillStars));
  const doctrineLabel = attackerMeta?.doctrine ?? conquestDoctrineLabelForThreat(state.encounter?.factionId, state.encounter?.aiSkillStars);
  const facilityWarTitle = document.querySelector('#facility-war-modal > h3');
  if (facilityWarTitle) {
    facilityWarTitle.textContent = `Attacker Intel • ${attackerFactionLabel} • ${attackerStarLabel}`;
  }
  dom.facilityWarHeader.textContent = `${deckSeriesLabel} • ${state.attacker.deck.length} cards • ${doctrineLabel} • ${world.worldName} / ${planet.name} • Strongholds ${completion.done}/${completion.total} • ${inSetup ? 'Setup Phase' : `Turn ${state.turn}`}${state.winner ? ` • Winner: ${state.winner}` : ''}`;
  if (dom.facilityGridSizeLabel) {
    dom.facilityGridSizeLabel.textContent = `${CONQUEST_GRID_COLS}x${CONQUEST_GRID_ROWS} Tactical Grid`;
  }
  dom.facilityWarAttackerInfo.innerHTML = `
    <div><strong>Encounter:</strong> ${encounterLabel}${state.encounter?.aiName ? ` • ${state.encounter.aiName}` : ''}</div>
    <div><strong>Attacker Deck:</strong> ${state.attacker.deck.length}</div>
    <div><strong>Deck Series:</strong> ${attackerMeta?.deckName ?? state.encounter?.deckSeries ?? conquestDeckSeriesName(state.encounter?.factionId, state.encounter?.deckTriangles, attackerMeta?.variant ?? conquestDeckVariantForStars(state.encounter?.aiSkillStars))}</div>
    <div><strong>Attacker Doctrine:</strong> ${attackerMeta?.doctrine ?? conquestDoctrineLabelForThreat(state.encounter?.factionId, state.encounter?.aiSkillStars)}</div>
    <div><strong>Deck Variant:</strong> ${attackerMeta?.variant ?? (Number(state.encounter?.aiSkillStars ?? 1) >= 4 ? 'advanced' : 'basic')} • Triangles ${attackerMeta?.triangles ?? clamp(Math.round(toFiniteNumber(state.encounter?.deckTriangles, state.attacker.deck.length / 10)), 1, 6)}</div>
    <div><strong>Attacker Hand:</strong> ${state.attacker.hand.length}</div>
    <div><strong>Attacker Plays/Turn:</strong> ${ATTACKER_MAX_PLAYS_PER_TURN}</div>
    <div><strong>Player Side:</strong> ${playerSide}</div>
    <div><strong>AI Control:</strong> ${attackerAi ? 'Attacker AI' : 'Attacker Player'} • ${defenderAi ? 'Defender AI' : 'Defender Player'}</div>
  `;
  const selectedHandId = modalUiState.facilityWar.selectedHandCardId;
  const hoverHandId = modalUiState.facilityWar.hoverHandCardId;
  const selectedEntry = state.defender.hand.find((entry) => entry.instanceId === selectedHandId);
  const hoverEntry = state.defender.hand.find((entry) => entry.instanceId === hoverHandId);
  const selectedCard = selectedEntry ? conquestCardById(profile, selectedEntry.cardId) : null;
  const hoverCard = hoverEntry ? conquestCardById(profile, hoverEntry.cardId) : null;
  renderFacilityWarResourceHud(state, profile, hoverCard ?? selectedCard ?? null);
  const selectedUnitIdx = Number.isInteger(modalUiState.facilityWar.selectedUnitCellIndex)
    ? clamp(Number(modalUiState.facilityWar.selectedUnitCellIndex), 0, Math.max(0, state.grid.length - 1))
    : null;
  const selectedUnitOcc = Number.isInteger(selectedUnitIdx) ? state.grid[selectedUnitIdx]?.occupant : null;
  const selectedUnitMoves = (Number.isInteger(selectedUnitIdx) && selectedUnitOcc?.side === 'defender')
    ? listLegalUnitMoves(state, selectedUnitIdx, selectedUnitOcc)
    : [];
  const selectedUnitMoveSet = new Set(selectedUnitMoves.map((entry) => entry.idx));
  const inspectCellIndex = Number.isInteger(modalUiState.facilityWar.inspectCellIndex)
    ? clamp(Number(modalUiState.facilityWar.inspectCellIndex), 0, Math.max(0, state.grid.length - 1))
    : null;
  const inspectCell = Number.isInteger(inspectCellIndex) ? state.grid[inspectCellIndex] : null;
  const inspectOcc = inspectCell?.occupant ?? null;
  const inspectCoords = Number.isInteger(inspectCellIndex) ? facilityCellFromIndex(inspectCellIndex) : null;
  const inspectAttack = Number.isInteger(inspectCellIndex) ? conquestAttackReadout(state, inspectCellIndex) : null;
  const dragAttackSourceIdx = Number.isInteger(modalUiState.facilityWar.dragAttackSourceIndex)
    ? clamp(Number(modalUiState.facilityWar.dragAttackSourceIndex), 0, Math.max(0, state.grid.length - 1))
    : null;
  const explicitAttackIdx = Number.isInteger(modalUiState.facilityWar.selectedAttackSourceIndex)
    ? clamp(Number(modalUiState.facilityWar.selectedAttackSourceIndex), 0, Math.max(0, state.grid.length - 1))
    : null;
  const attackSourceIdx = Number.isInteger(explicitAttackIdx)
    ? explicitAttackIdx
    : (Number.isInteger(selectedUnitIdx)
      ? selectedUnitIdx
      : (inspectOcc?.side === 'defender' ? inspectCellIndex : null));
  const activeSourceIdx = Number.isInteger(dragAttackSourceIdx) ? dragAttackSourceIdx : attackSourceIdx;
  const targetedInspectIdx = Number.isInteger(inspectCellIndex) && inspectOcc?.side === 'attacker'
    ? inspectCellIndex
    : null;
  const attackReadout = Number.isInteger(activeSourceIdx)
    ? conquestAttackReadout(state, activeSourceIdx)
    : null;
  const attackTargets = toArray(attackReadout?.targets);
  const preferredAttackTarget = Number.isInteger(targetedInspectIdx)
    ? attackTargets.find((entry) => Number(entry.idx) === Number(targetedInspectIdx))
    : null;
  const resolvedAttackTarget = preferredAttackTarget ?? attackTargets[0] ?? null;
  const attackTargetSet = new Set(attackTargets.map((entry) => Number(entry.idx)).filter((idx) => Number.isInteger(idx)));
  const threatHeatmap = buildConquestThreatHeatmap(state, playerSide);
  const laneControlRows = buildConquestLaneControl(state, playerSide, threatHeatmap);
  const attackDamagePreview = (attackReadout?.canAttack && Number.isInteger(activeSourceIdx) && resolvedAttackTarget?.occupant)
    ? facilityDamageValue(state.grid[activeSourceIdx]?.occupant, resolvedAttackTarget.occupant)
    : 0;
  if (Number.isInteger(dragAttackSourceIdx)) document.body.classList.add('facility-drag-attacking');
  else document.body.classList.remove('facility-drag-attacking');
  const showHeatmap = !!modalUiState.facilityWar.showHeatmap;
  const cinematicMode = !!modalUiState.facilityWar.cinematicMode;
  if (dom.facilityWarModal) {
    dom.facilityWarModal.classList.toggle('show-heatmap', showHeatmap);
    dom.facilityWarModal.classList.toggle('cinematic-mode', cinematicMode);
  }
  const deconstructReadout = Number.isInteger(inspectCellIndex)
    ? getFacilityDeconstructReadout(state, inspectCellIndex)
    : { ok: false, message: 'Select a friendly structure to deconstruct.' };
  const latestDrawCard = state.lastDraw?.cardId ? conquestCardById(profile, state.lastDraw.cardId) : null;
  const drawFresh = (Date.now() - Number(state.lastDraw?.ts ?? 0)) < 2600;
  const selectedSpend = selectedCard ? computeDefenderSpendPreview(state, selectedCard) : null;
  const handRows = getFilteredSortedFacilityHand(state, profile);
  const inspectPinned = !!modalUiState.facilityWar.inspectPinned;
  if (inspectPinned && !Number.isInteger(modalUiState.facilityWar.inspectCellIndex)) {
    const candidateIdx = getConquestInspectCandidateIndices(state)[0] ?? null;
    modalUiState.facilityWar.inspectCellIndex = Number.isInteger(candidateIdx) ? candidateIdx : null;
  }
  const compareIdxRaw = Number.isInteger(modalUiState.facilityWar.compareCellIndex)
    ? clamp(Number(modalUiState.facilityWar.compareCellIndex), 0, Math.max(0, state.grid.length - 1))
    : null;
  const compareOcc = Number.isInteger(compareIdxRaw) ? state.grid[compareIdxRaw]?.occupant : null;
  if (!compareOcc) modalUiState.facilityWar.compareCellIndex = null;
  const inspectCandidates = getConquestInspectCandidateIndices(state);
  const inspectCyclePos = Number.isInteger(inspectCellIndex) ? inspectCandidates.indexOf(inspectCellIndex) : -1;
  dom.facilityWarSelectedCard.innerHTML = selectedCard
    ? `
      <article class="conquest-card-face rarity-${String(selectedCard.rarity ?? 'common').toLowerCase()} selected">
        <header>
          <strong>${selectedCard.name}</strong>
          <span>${conquestCostText(selectedCard)}</span>
        </header>
        <div class="conquest-card-meta">${conquestEntryTypeText(selectedCard)} • ${conquestStatsText(selectedCard)}</div>
        <div class="conquest-type-badges">${conquestTypeBadgesHtml(selectedCard)}</div>
        <div class="conquest-card-tags">${conquestEntryTagsHtml(selectedCard)}</div>
        <div class="conquest-card-meta">Source: ${String(selectedCard.sourceBuilding ?? selectedCard.productionSource ?? 'utility').toUpperCase()} • Role: ${conquestRoleSummary(selectedCard)}</div>
        <div class="conquest-card-meta">${conquestEquipTargetSummary(selectedCard)}</div>
        <div class="conquest-card-meta">${conquestUpgradeTargetSummary(selectedCard)}</div>
        <div class="conquest-card-meta ${selectedSpend && !selectedSpend.affordable ? 'warning' : ''}">${selectedSpend?.message ?? ''}</div>
        <p>${selectedCard.text ?? 'No rules text.'}</p>
      </article>
    `
      : (selectedUnitOcc
        ? `
          <article class="conquest-card-face rarity-${String(selectedUnitOcc.rarity ?? selectedUnitOcc.status?.gearTier ?? 'common').toLowerCase()} selected">
            <header>
              <strong>${selectedUnitOcc.name}</strong>
              <span>MOVE MODE</span>
            </header>
            <div class="conquest-card-meta">${conquestEntryTypeText(selectedUnitOcc)} • ${conquestStatsText(selectedUnitOcc)}</div>
            <div class="conquest-type-badges">${conquestTypeBadgesHtml(selectedUnitOcc)}</div>
            <div class="conquest-card-tags">${conquestEntryTagsHtml(selectedUnitOcc)} <span class="conquest-tag-pill">Legal moves: ${selectedUnitMoves.length}</span></div>
            <div class="conquest-card-meta">${attackReadout?.canAttack ? `Ready to attack: ${resolvedAttackTarget?.occupant?.name ?? attackReadout.target?.name ?? 'target'} (${attackDamagePreview} dmg)` : `Attack status: ${attackReadout?.reason ?? 'No target'}`}</div>
            <p>Click a highlighted tile to move. Movement consumes this unit's action. Attack by dragging this unit onto an enemy or tap attacker then tap enemy.</p>
          </article>
        `
      : (inspectOcc
        ? `
          ${conquestInspectCardMarkup(inspectOcc, {
      owner: inspectOcc.side ?? inspectCell?.owner ?? 'neutral',
      playerSide,
      turnNumber: state.turn,
    })}
          <div class="conquest-card-meta">Cell: R${(inspectCoords?.row ?? 0) + 1} C${(inspectCoords?.col ?? 0) + 1}</div>
          <div class="conquest-card-meta">${inspectAttack?.reason ?? 'No combat readout.'}</div>
          ${inspectAttack?.target ? `<div class="conquest-card-meta">Target in lane: <strong>${inspectAttack.target.name}</strong> (${conquestStatsText(inspectAttack.target)})</div>` : ''}
          <div class="conquest-card-meta">${deconstructReadout.ok ? 'Eligible for Deconstruct action.' : deconstructReadout.message}</div>
        `
      : (latestDrawCard && drawFresh
        ? `
        <article class="conquest-card-face rarity-${String(latestDrawCard.rarity ?? 'common').toLowerCase()} selected">
          <header>
            <strong>${latestDrawCard.name}</strong>
            <span>${conquestCostText(latestDrawCard)}</span>
          </header>
          <div class="conquest-card-meta">${conquestEntryTypeText(latestDrawCard)} • ${conquestStatsText(latestDrawCard)}</div>
          <div class="conquest-type-badges">${conquestTypeBadgesHtml(latestDrawCard)}</div>
          <div class="conquest-card-tags"><span class="conquest-tag-pill">Fresh Draw</span> <span class="conquest-tag-pill">From ${String(state.lastDraw?.deckKey ?? 'deck').toUpperCase()}</span> ${conquestEntryTagsHtml(latestDrawCard)}</div>
          <p>${latestDrawCard.text ?? 'No rules text.'}</p>
        </article>
      `
        : `<div>${inSetup ? 'Setup: place all starter buildings, barricades, and turrets before beginning combat.' : (playerSide === 'defender' ? 'Select a defender hand card to place, or select a defender unit to move one tile.' : 'Defender side is AI-controlled this encounter.')}</div>`)));
  if (dom.facilityWarCompareCard) {
    const hasCompare = !!compareOcc;
    dom.facilityWarCompareCard.classList.toggle('hidden', !hasCompare);
    if (hasCompare) {
      dom.facilityWarCompareCard.innerHTML = `
        <h5>Compare</h5>
        ${conquestInspectCardMarkup(compareOcc, {
        owner: compareOcc.side ?? state.grid[compareIdxRaw]?.owner ?? 'neutral',
        playerSide,
        turnNumber: state.turn,
      })}
      `;
    } else {
      dom.facilityWarCompareCard.innerHTML = '';
    }
  }
  if (dom.facilityInspectPinBtn) dom.facilityInspectPinBtn.classList.toggle('active', inspectPinned);
  if (dom.facilityInspectCompareBtn) dom.facilityInspectCompareBtn.classList.toggle('active', !!compareOcc);
  if (dom.facilityInspectPrevBtn) dom.facilityInspectPrevBtn.disabled = inspectCandidates.length < 2 || inspectCyclePos < 0;
  if (dom.facilityInspectNextBtn) dom.facilityInspectNextBtn.disabled = inspectCandidates.length < 2 || inspectCyclePos < 0;
  const drawDisabled = inSetup || state.side !== 'defender' || !!state.winner || playerSide !== 'defender';
  const setDrawButtonState = (button, deckKey, extraLocked = false) => {
    if (!button) return;
    const gate = conquestDeckDrawReadout(state, deckKey);
    const locked = drawDisabled || state.drawActionsLeft <= 0 || !gate.ok || extraLocked;
    button.disabled = locked;
    if (!gate.ok) button.title = gate.message;
    else if (locked && state.drawActionsLeft <= 0) button.title = 'No production draws left this turn.';
    else button.title = `Draw from ${CONQUEST_DECK_DRAW_LABELS[deckKey] ?? deckKey}.`;
  };
  setDrawButtonState(dom.facilityDrawTrainingBtn, 'training');
  setDrawButtonState(dom.facilityDrawFactoryBtn, 'factory');
  setDrawButtonState(dom.facilityDrawBlacksmithBtn, 'blacksmith', Number(state.defender.blacksmithDrawnOnTurn ?? 0) >= 1);
  setDrawButtonState(dom.facilityDrawCommandBtn, 'command');
  setDrawButtonState(dom.facilityDrawVehicleBtn, 'vehicle');
  setDrawButtonState(dom.facilityDrawOrdnanceBtn, 'ordnance');
  setDrawButtonState(dom.facilityDrawAirBtn, 'air');
  setDrawButtonState(dom.facilityDrawPowerBtn, 'power');
  setDrawButtonState(dom.facilityDrawRecoveryBtn, 'recovery');
  setDrawButtonState(dom.facilityDrawExperimentalBtn, 'experimental');
  if (dom.facilityWarEndTurnBtn) {
    dom.facilityWarEndTurnBtn.disabled = !!state.winner;
    dom.facilityWarEndTurnBtn.textContent = inSetup ? 'Begin Assault' : 'End Turn';
  }
  if (dom.facilityWarAttackBtn) {
    const attackLocked = inSetup
      || !!state.winner
      || playerSide !== 'defender'
      || String(state.side ?? '') !== 'defender'
      || !Number.isInteger(activeSourceIdx)
      || !attackReadout?.canAttack;
    dom.facilityWarAttackBtn.disabled = attackLocked;
    dom.facilityWarAttackBtn.title = attackLocked
      ? (attackReadout?.reason ?? (inSetup ? 'Setup phase active.' : 'Select a defender unit/turret to attack.'))
      : `Attack ${resolvedAttackTarget?.occupant?.name ?? attackReadout?.target?.name ?? 'target'} (${attackDamagePreview})`;
  }
  if (dom.facilityWarDeconstructBtn) {
    const deconstructLocked = !!state.winner || playerSide !== 'defender' || !deconstructReadout?.ok;
    dom.facilityWarDeconstructBtn.disabled = deconstructLocked;
    dom.facilityWarDeconstructBtn.title = deconstructLocked
      ? (deconstructReadout?.message ?? 'Select a friendly structure.')
      : `Remove ${deconstructReadout.occupant?.name ?? 'selected structure'}`;
  }
  if (dom.facilityHeatmapToggleBtn) {
    dom.facilityHeatmapToggleBtn.classList.toggle('active', showHeatmap);
    dom.facilityHeatmapToggleBtn.title = showHeatmap
      ? 'Threat heatmap enabled. Click to return to normal tile view.'
      : 'Show live enemy pressure and allied support overlays.';
  }
  if (dom.facilityCinematicToggleBtn) {
    dom.facilityCinematicToggleBtn.classList.toggle('active', cinematicMode);
    dom.facilityCinematicToggleBtn.title = cinematicMode
      ? 'Cinematic mode enabled. Click to restore full tactical side panels.'
      : 'Reduce panel clutter and enlarge battlemat focus.';
  }
  if (dom.facilitySetupPresetSelect) {
    const slot = String(modalUiState.facilityWar.setupPresetSlot ?? 'alpha').toLowerCase();
    if (!['alpha', 'beta', 'gamma'].includes(slot)) modalUiState.facilityWar.setupPresetSlot = 'alpha';
    dom.facilitySetupPresetSelect.value = String(modalUiState.facilityWar.setupPresetSlot ?? 'alpha');
  }
  if (dom.facilitySaveSetupBtn) {
    const slot = String(modalUiState.facilityWar.setupPresetSlot ?? 'alpha').toLowerCase();
    dom.facilitySaveSetupBtn.disabled = !!state.winner;
    dom.facilitySaveSetupBtn.title = `Save current layout into ${slot} preset slot.`;
  }
  if (dom.facilityLoadSetupBtn) {
    const slot = String(modalUiState.facilityWar.setupPresetSlot ?? 'alpha').toLowerCase();
    const presetReady = !!state.setupPresets?.[slot];
    dom.facilityLoadSetupBtn.disabled = !!state.winner || !presetReady;
    dom.facilityLoadSetupBtn.title = presetReady
      ? `Load ${slot} setup preset.`
      : `No ${slot} setup preset saved yet.`;
  }
  if (dom.facilityLogGroupBtn) {
    const grouped = !!modalUiState.facilityWar.logGrouped;
    dom.facilityLogGroupBtn.classList.toggle('active', grouped);
    dom.facilityLogGroupBtn.title = grouped
      ? 'Grouped mode: repeated entries are condensed.'
      : 'Chronological mode: show raw event stream.';
  }
  renderConquestBattleStatus(state, profile, playerSide, threatHeatmap, laneControlRows);
  renderConquestLaneControl(laneControlRows, threatHeatmap);
  renderConquestHeatmapLegend(threatHeatmap, laneControlRows, showHeatmap);
  dom.facilityWarDefenderHand.innerHTML = '';
  if (dom.facilityWarHandCount) {
    const total = state.defender.hand.length;
    const filtered = handRows.length;
    dom.facilityWarHandCount.textContent = filtered === total
      ? `${total} card${total === 1 ? '' : 's'}`
      : `${filtered}/${total} visible`;
  }
  if (dom.facilityWarDefenderHand) {
    dom.facilityWarDefenderHand.dataset.handMode = String(modalUiState.facilityWar.handViewMode ?? 'expanded');
  }
  if (dom.facilityHandCategoryChips) {
    const activeFilter = String(modalUiState.facilityWar.handCategoryFilter ?? 'all').toLowerCase();
    dom.facilityHandCategoryChips.querySelectorAll('button[data-filter]').forEach((chip) => {
      chip.classList.toggle('active', String(chip.dataset.filter ?? '').toLowerCase() === activeFilter);
    });
  }
  if (dom.facilityHandSortCostBtn) dom.facilityHandSortCostBtn.classList.toggle('active', modalUiState.facilityWar.handSort === 'cost');
  if (dom.facilityHandSortTypeBtn) dom.facilityHandSortTypeBtn.classList.toggle('active', modalUiState.facilityWar.handSort === 'type');
  if (dom.facilityHandSortSourceBtn) dom.facilityHandSortSourceBtn.classList.toggle('active', modalUiState.facilityWar.handSort === 'source');
  handRows.forEach((rowData) => {
    const { entry, card, category } = rowData;
    const selected = selectedHandId === entry.instanceId;
    const justDrawn = state.lastDraw?.instanceId === entry.instanceId && (Date.now() - Number(state.lastDraw?.ts ?? 0)) < 2200;
    const spendPlan = computeDefenderSpendPreview(state, card);
    const affordableNow = spendPlan.affordable || spendPlan.setupBypass;
    const sourceKey = String(card.sourceBuilding ?? card.productionSource ?? 'utility').toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const typeKey = String(category ?? card.type ?? 'card').toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const row = document.createElement('button');
    row.className = `facility-card-chip type-${typeKey} source-${sourceKey} ${selected ? 'selected' : ''} ${justDrawn ? 'just-drawn' : ''} ${affordableNow ? '' : 'unaffordable'}`;
    row.dataset.source = sourceKey;
    row.dataset.cardType = category ?? typeKey;
    row.innerHTML = `
      <article class="conquest-card-face rarity-${String(card.rarity ?? 'common').toLowerCase()} compact ${selected ? 'selected' : ''}">
        <header>
          <strong>${card.name}</strong>
          <span>${conquestCostText(card)}</span>
        </header>
        <div class="conquest-card-meta">${conquestEntryTypeText(card)} • ${conquestStatsText(card)}</div>
        <div class="conquest-card-meta">Source: ${String(card.sourceBuilding ?? card.productionSource ?? 'utility').toUpperCase()} • ${conquestRoleSummary(card)}</div>
        <div class="conquest-type-badges">${conquestTypeBadgesHtml(card)}</div>
        <div class="conquest-card-tags">${conquestEntryTagsHtml(card)}</div>
        <div class="conquest-card-meta ${affordableNow ? '' : 'warning'}">${spendPlan.message}</div>
        <p>${card.text ?? '—'}</p>
      </article>
      <span class="facility-card-select-label">${selected ? 'Selected' : 'Select'}</span>
    `;
    row.onmouseenter = () => {
      modalUiState.facilityWar.hoverHandCardId = entry.instanceId;
      renderFacilityWarResourceHud(state, profile, card);
    };
    row.onmouseleave = () => {
      if (modalUiState.facilityWar.hoverHandCardId !== entry.instanceId) return;
      modalUiState.facilityWar.hoverHandCardId = null;
      renderFacilityWarResourceHud(state, profile, selectedCard ?? null);
    };
    row.onclick = () => {
      if (playerSide !== 'defender') return;
      modalUiState.facilityWar.selectedHandCardId = selected ? null : entry.instanceId;
      modalUiState.facilityWar.hoverHandCardId = null;
      modalUiState.facilityWar.dragAttackSourceIndex = null;
      document.body.classList.remove('facility-drag-attacking');
      if (!selected) {
        modalUiState.facilityWar.selectedUnitCellIndex = null;
        modalUiState.facilityWar.selectedAttackSourceIndex = null;
      }
      renderFacilityWarModal(loadProfile());
    };
    dom.facilityWarDefenderHand.appendChild(row);
  });
  if (!handRows.length) {
    const hasCards = state.defender.hand.length > 0;
    dom.facilityWarDefenderHand.innerHTML = `<div class="facility-log-entry">${hasCards ? 'No cards match the selected hand filter.' : 'No cards in hand.'}</div>`;
  }
  if (dom.facilityWarDefenderHand && !dom.facilityWarDefenderHand.dataset.wheelBound) {
    dom.facilityWarDefenderHand.addEventListener('wheel', (event) => {
      const el = dom.facilityWarDefenderHand;
      if (!el) return;
      const compactMode = String(el.dataset.handMode ?? '') === 'compact';
      if (compactMode) {
        const canScrollY = el.scrollHeight > el.clientHeight;
        if (!canScrollY) return;
        event.preventDefault();
        el.scrollTop += event.deltaY;
        return;
      }
      const canScrollX = el.scrollWidth > el.clientWidth;
      if (!canScrollX) return;
      event.preventDefault();
      el.scrollLeft += event.deltaY;
    }, { passive: false });
    dom.facilityWarDefenderHand.dataset.wheelBound = '1';
  }
  dom.facilityWarGrid.innerHTML = '';
  dom.facilityWarGrid.style.setProperty('--facility-cols', String(CONQUEST_GRID_COLS));
  dom.facilityWarGrid.style.setProperty('--facility-rows', String(CONQUEST_GRID_ROWS));
  dom.facilityWarGrid.style.gridTemplateColumns = `repeat(${CONQUEST_GRID_COLS}, minmax(0, 1fr))`;
  dom.facilityWarGrid.style.gridTemplateRows = `repeat(${CONQUEST_GRID_ROWS}, minmax(0, 1fr))`;
  applyFacilityBoardViewState();
  state.grid.forEach((cell, idx) => {
    const btn = document.createElement('button');
    const occ = cell?.occupant;
    const controlClass = cell.owner === 'defender' ? 'control-defender' : cell.owner === 'attacker' ? 'control-attacker' : '';
    const relationClass = occ ? (occ.side === playerSide ? 'occupant-friendly' : 'occupant-enemy') : '';
    const dangerCount = Number(threatHeatmap?.dangerCounts?.get(idx) ?? 0);
    const supportCount = Number(threatHeatmap?.supportCounts?.get(idx) ?? 0);
    const turretDanger = Number(threatHeatmap?.turretDangerCounts?.get(idx) ?? 0);
    const contestedThreat = threatHeatmap?.contested?.has(idx);
    btn.className = `facility-cell ${controlClass} ${occ ? 'occupied' : ''} ${relationClass}`;
    const coords = facilityCellFromIndex(idx);
    const inNoMansLand = conquestIsNoMansLandCol(coords.col);
    if (inNoMansLand) btn.classList.add('no-mans-land');
    if (showHeatmap) {
      btn.classList.add('heatmap-on');
      if (contestedThreat) btn.classList.add('heat-contested');
      else if (dangerCount > 0) btn.classList.add('heat-danger');
      else if (supportCount > 0) btn.classList.add('heat-support');
      const intensity = dangerCount > 0
        ? clamp((dangerCount / Math.max(1, threatHeatmap.maxDanger)) * 100, 8, 100)
        : supportCount > 0
          ? clamp((supportCount / Math.max(1, threatHeatmap.maxSupport)) * 100, 8, 100)
          : 0;
      btn.style.setProperty('--facility-threat-intensity', `${intensity.toFixed(1)}%`);
      btn.style.setProperty('--facility-threat-alpha', `${(intensity / 100).toFixed(3)}`);
      btn.style.setProperty('--facility-turret-threat', `${clamp((turretDanger / Math.max(1, threatHeatmap.maxDanger)) * 100, 0, 100).toFixed(1)}%`);
      btn.style.setProperty('--facility-turret-alpha', `${(clamp((turretDanger / Math.max(1, threatHeatmap.maxDanger)) * 100, 0, 100) / 100).toFixed(3)}`);
    }
    const isAttackSource = Number.isInteger(activeSourceIdx) && activeSourceIdx === idx;
    if (isAttackSource) btn.classList.add('attack-source');
    if (Number.isInteger(dragAttackSourceIdx) && dragAttackSourceIdx === idx) btn.classList.add('attack-drag-source');
    if (attackReadout?.canAttack && attackTargetSet.has(idx)) btn.classList.add('attack-target');
    let canDrop = false;
    let canMove = false;
    if (selectedHandId) {
      const selected = state.defender.hand.find((entry) => entry.instanceId === selectedHandId);
      const card = selected ? conquestCardById(profile, selected.cardId) : null;
      const spendPlan = card ? computeDefenderSpendPreview(state, card) : null;
      const affordable = !spendPlan || spendPlan.setupBypass || spendPlan.affordable;
      if (card?.type === 'upgrade') {
        const targetCheck = occ ? defenderUpgradeTargetReadout(card, occ) : { ok: false, message: 'Select a friendly target.' };
        canDrop = !!occ && targetCheck.ok && affordable;
        if (occ && !targetCheck.ok) btn.title = targetCheck.message;
        if (!affordable && spendPlan) btn.title = spendPlan.message;
      } else if (!occ && card) {
        const placeCheck = canDefenderPlaceAtDetailed(state, card, coords.row, coords.col);
        canDrop = placeCheck.ok && affordable;
        if (!placeCheck.ok) btn.title = placeCheck.message;
        if (!affordable && spendPlan) btn.title = spendPlan.message;
      }
    }
    if (!selectedHandId && selectedUnitMoveSet.has(idx) && !occ) canMove = true;
    if (canDrop) btn.classList.add('can-drop');
    if (canMove) btn.classList.add('move-target');
    const rarity = String(occ?.rarity ?? occ?.status?.gearTier ?? 'common').toLowerCase();
    const hpNow = Math.max(0, Number(occ?.hp ?? 0));
    const hpMax = Math.max(1, Number(occ?.maxHp ?? occ?.hp ?? 1));
    const hpPct = clamp((hpNow / hpMax) * 100, 0, 100);
    const hpClass = hpPct <= 25 ? 'critical' : hpPct <= 55 ? 'warn' : 'healthy';
    const readinessText = occ ? conquestReadinessText(occ, state.turn) : '';
    const actedThisTurn = Number(occ?.status?.actedTurn ?? 0) === Number(state.turn ?? 1);
    const readinessStateClass = occ
      ? (actedThisTurn
        ? 'readiness-exhausted'
        : readinessText.startsWith('Freshly')
          ? 'readiness-fresh'
          : 'readiness-ready')
      : '';
    const cellAtk = Math.max(0, Number(occ?.attack ?? occ?.atk ?? 0));
    const cellDef = Math.max(0, Number(occ?.defense ?? occ?.def ?? 0));
    const cellNameWords = String(occ?.name ?? '').trim().split(/\s+/).filter(Boolean);
    const cellShortName = cellNameWords.length > 2 ? cellNameWords.slice(0, 2).join(' ') : (occ?.name ?? 'Unit');
    const cellDamagePreview = (attackReadout?.canAttack && attackTargetSet.has(idx) && occ && Number.isInteger(activeSourceIdx))
      ? facilityDamageValue(state.grid[activeSourceIdx]?.occupant, occ)
      : 0;
    const cellLethal = cellDamagePreview > 0 && cellDamagePreview >= hpNow;
    if (readinessStateClass) btn.classList.add(readinessStateClass);
    if (showHeatmap && (dangerCount > 0 || supportCount > 0)) {
      btn.title = `${btn.title ? `${btn.title}\n` : ''}Threat: ${dangerCount} • Support: ${supportCount}${turretDanger > 0 ? ` • Turret: ${turretDanger}` : ''}`;
    }
    if (cellDamagePreview > 0) {
      btn.title = `${btn.title ? `${btn.title}\n` : ''}Projected damage: ${cellDamagePreview}${cellLethal ? ' (lethal)' : ''}`;
    }
    btn.innerHTML = occ
      ? `
        <div class="facility-cell-head">
          <small>R${coords.row + 1} C${coords.col + 1}</small>
          <span class="facility-side-pill side-${occ.side === playerSide ? 'friendly' : 'enemy'}">${occ.side === playerSide ? 'ALLY' : 'ENEMY'}</span>
        </div>
        <article class="facility-cell-card side-${occ.side} rarity-${rarity}">
          <div class="facility-readiness-ring ${readinessStateClass}" aria-hidden="true"></div>
          <div class="facility-cell-card-top">
            <div class="facility-cell-card-name" title="${occ.name}">${cellShortName}</div>
            <div class="facility-cell-card-statline">ATK ${cellAtk} • DEF ${cellDef}</div>
          </div>
          <div class="facility-cell-health">
            <div class="facility-cell-health-head"><span>HP ${hpNow}/${hpMax}</span><span>${Math.round(hpPct)}%</span></div>
            <div class="facility-cell-health-track"><span class="facility-cell-health-fill ${hpClass}" style="width:${hpPct.toFixed(2)}%"></span></div>
          </div>
          <div class="facility-cell-card-bottom">
            <span>${conquestRoleSummary(occ)}</span>
            <span class="facility-cell-card-ready">${actedThisTurn ? 'Acted' : (readinessText.startsWith('Freshly') ? 'Fresh' : 'Ready')}</span>
          </div>
          ${cellDamagePreview > 0 ? `<div class="facility-cell-target-preview ${cellLethal ? 'lethal' : ''}">-${cellDamagePreview}${cellLethal ? ' KO' : ''}</div>` : ''}
        </article>
      `
      : `
        <div class="facility-cell-head">
          <small>R${coords.row + 1} C${coords.col + 1}</small>
          <small>${inNoMansLand ? "NO MAN'S LAND" : String(cell.owner ?? 'neutral').toUpperCase()}</small>
        </div>
        <div class="facility-cell-empty">${canDrop ? 'Deploy here' : 'Empty lane'}</div>
      `;
    if (occ?.status?.gearTier) btn.classList.add(`tier-${String(occ.status.gearTier)}`);
    btn.onclick = () => {
      if (playerSide !== 'defender') return;
      const live = loadProfile();
      const liveCtx = getWorldPlanet(live, worldId, planetId);
      if (!liveCtx.world || !liveCtx.planet) return;
      ensurePlanetConquestState(liveCtx.world, liveCtx.planet);
      const liveState = liveCtx.planet.facilityWar;
      const activeSelected = modalUiState.facilityWar.selectedHandCardId;
      const activeUnitIdx = Number.isInteger(modalUiState.facilityWar.selectedUnitCellIndex)
        ? Number(modalUiState.facilityWar.selectedUnitCellIndex)
        : null;
      const activeAttackSourceIdx = Number.isInteger(modalUiState.facilityWar.selectedAttackSourceIndex)
        ? Number(modalUiState.facilityWar.selectedAttackSourceIndex)
        : activeUnitIdx;
      const liveInSetup = String(liveState.phase ?? '') === 'setup';
      if (liveState.winner) return;
      if (activeSelected) {
        const result = placeDefenderCard(liveState, activeSelected, idx, live);
        if (result.ok) {
          modalUiState.facilityWar.selectedHandCardId = null;
          modalUiState.facilityWar.selectedUnitCellIndex = null;
          modalUiState.facilityWar.selectedAttackSourceIndex = null;
          modalUiState.facilityWar.dragAttackSourceIndex = null;
          document.body.classList.remove('facility-drag-attacking');
        } else {
          facilityLog(liveState, result.message, 'bad');
        }
      } else if (
        !liveInSetup
        && Number.isInteger(activeAttackSourceIdx)
        && activeAttackSourceIdx !== idx
        && liveState.grid[idx]?.occupant?.side === 'attacker'
      ) {
        const attacked = runFacilityManualAttack(liveState, activeAttackSourceIdx, idx);
        if (attacked.ok) {
          modalUiState.facilityWar.selectedUnitCellIndex = null;
          modalUiState.facilityWar.selectedAttackSourceIndex = activeAttackSourceIdx;
        } else {
          facilityLog(liveState, attacked.message ?? 'Attack failed.', 'bad');
        }
        modalUiState.facilityWar.dragAttackSourceIndex = null;
        document.body.classList.remove('facility-drag-attacking');
      } else if (Number.isInteger(activeUnitIdx) && !liveState.grid[idx]?.occupant && !liveInSetup) {
        const moved = moveFacilityUnitByPlayer(liveState, activeUnitIdx, idx, 'defender');
        if (moved.ok) {
          modalUiState.facilityWar.selectedUnitCellIndex = null;
          modalUiState.facilityWar.selectedAttackSourceIndex = null;
        }
        else facilityLog(liveState, moved.message, 'bad');
      } else if (liveState.grid[idx]?.occupant?.side === 'defender' && (liveState.grid[idx].occupant.type === 'unit' || toArray(liveState.grid[idx].occupant.tags).includes('ground') || toArray(liveState.grid[idx].occupant.tags).includes('air'))) {
        modalUiState.facilityWar.selectedUnitCellIndex = activeUnitIdx === idx ? null : idx;
        modalUiState.facilityWar.selectedHandCardId = null;
        modalUiState.facilityWar.selectedAttackSourceIndex = modalUiState.facilityWar.selectedUnitCellIndex;
      } else if (liveState.grid[idx]?.occupant?.side === 'defender') {
        modalUiState.facilityWar.selectedUnitCellIndex = null;
        modalUiState.facilityWar.selectedAttackSourceIndex = idx;
        modalUiState.facilityWar.selectedHandCardId = null;
      }
      modalUiState.facilityWar.inspectCellIndex = idx;
      persistFacilityState(live, worldId, planetId, liveState);
      renderFacilityWarModal(loadProfile());
    };
    const canBeginDragAttack = !!(
      occ
      && occ.side === 'defender'
      && !selectedHandId
      && !inSetup
      && !state.winner
      && String(state.side ?? '') === 'defender'
      && conquestAttackReadout(state, idx).canAttack
    );
    btn.draggable = canBeginDragAttack;
    btn.ondragstart = (event) => {
      if (!canBeginDragAttack) {
        event.preventDefault();
        return;
      }
      modalUiState.facilityWar.dragAttackSourceIndex = idx;
      modalUiState.facilityWar.selectedAttackSourceIndex = idx;
      modalUiState.facilityWar.selectedUnitCellIndex = idx;
      modalUiState.facilityWar.selectedHandCardId = null;
      document.body.classList.add('facility-drag-attacking');
      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', String(idx));
      }
    };
    btn.ondragover = (event) => {
      const sourceIdx = Number.isInteger(modalUiState.facilityWar.dragAttackSourceIndex)
        ? Number(modalUiState.facilityWar.dragAttackSourceIndex)
        : null;
      if (!Number.isInteger(sourceIdx) || sourceIdx === idx) return;
      const dragReadout = conquestAttackReadout(state, sourceIdx);
      const canDropAttack = !!(dragReadout?.canAttack && toArray(dragReadout.targets).some((entry) => Number(entry.idx) === idx));
      if (!canDropAttack) return;
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    };
    btn.ondrop = (event) => {
      event.preventDefault();
      const sourceIdx = Number.isInteger(modalUiState.facilityWar.dragAttackSourceIndex)
        ? Number(modalUiState.facilityWar.dragAttackSourceIndex)
        : null;
      if (!Number.isInteger(sourceIdx) || sourceIdx === idx) return;
      const live = loadProfile();
      const liveCtx = getWorldPlanet(live, worldId, planetId);
      if (!liveCtx.world || !liveCtx.planet) return;
      ensurePlanetConquestState(liveCtx.world, liveCtx.planet);
      const liveState = liveCtx.planet.facilityWar;
      const attacked = runFacilityManualAttack(liveState, sourceIdx, idx);
      if (attacked.ok) {
        modalUiState.facilityWar.inspectCellIndex = idx;
        modalUiState.facilityWar.selectedAttackSourceIndex = sourceIdx;
        modalUiState.facilityWar.selectedUnitCellIndex = null;
      } else {
        facilityLog(liveState, attacked.message ?? 'Attack failed.', 'bad');
      }
      modalUiState.facilityWar.dragAttackSourceIndex = null;
      document.body.classList.remove('facility-drag-attacking');
      persistFacilityState(live, worldId, planetId, liveState);
      renderFacilityWarModal(loadProfile());
    };
    btn.ondragend = () => {
      if (!Number.isInteger(modalUiState.facilityWar.dragAttackSourceIndex)) return;
      modalUiState.facilityWar.dragAttackSourceIndex = null;
      document.body.classList.remove('facility-drag-attacking');
      renderFacilityWarModal(loadProfile());
    };
    btn.oncontextmenu = (event) => {
      event.preventDefault();
      modalUiState.facilityWar.inspectCellIndex = idx;
      modalUiState.facilityWar.selectedAttackSourceIndex = occ?.side === 'defender' ? idx : null;
      modalUiState.facilityWar.dragAttackSourceIndex = null;
      document.body.classList.remove('facility-drag-attacking');
      renderFacilityWarModal(loadProfile());
    };
    dom.facilityWarGrid.appendChild(btn);
  });
  renderFacilityWarLog(state, !!modalUiState.facilityWar.logGrouped);
  renderFacilityDevSuite(state, profile, laneControlRows, threatHeatmap);
  if (String(modalUiState.facilityWar.boardViewMode ?? 'fit') !== 'focus') {
    centerFacilityBoardViewport();
  }
  startFacilityWarEffects(state);
}

function openFacilityWarModal(worldId, planetId) {
  const profile = loadProfile();
  const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  ensurePlanetConquestState(world, planet);
  const state = planet.facilityWar;
  state.active = true;
  syncDefenderResourceCaps(state, { clampOverflow: true });
  if (state.phase === 'idle') state.phase = 'setup';
  if (!state.encounter || typeof state.encounter !== 'object') {
    state.encounter = {
      encounterId: `manual:${worldId}:${planetId}`,
      threatType: 'manual',
      worldId,
      planetId,
      openedAt: Date.now(),
    };
  }
  if (!Array.isArray(state.defender?.hand) || !state.defender.hand.length) {
    state.defender.hand = buildFacilitySetupHand(profile);
  }
  if (state.phase === 'setup') {
    state.underAttack = false;
  } else {
    state.underAttack = true;
  }
  modalUiState.facilityWar.worldId = worldId;
  modalUiState.facilityWar.planetId = planetId;
  modalUiState.facilityWar.selectedHandCardId = null;
  modalUiState.facilityWar.hoverHandCardId = null;
  modalUiState.facilityWar.inspectCellIndex = null;
  modalUiState.facilityWar.inspectPinned = false;
  modalUiState.facilityWar.compareCellIndex = null;
  modalUiState.facilityWar.selectedUnitCellIndex = null;
  modalUiState.facilityWar.selectedAttackSourceIndex = null;
  modalUiState.facilityWar.dragAttackSourceIndex = null;
  document.body.classList.remove('facility-drag-attacking');
  campaign.worldStates[worldId] = world;
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  renderFacilityWarModal(loadProfile());
  openModal('facility-war-modal');
}

function resetFacilityWarForPlanet(worldId, planetId) {
  const profile = loadProfile();
  const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  planet.conquestDecks = normalizeConquestDecks(planet.conquestDecks);
  planet.facilityWar = createFacilityWarState(worldId, planetId, planet.conquestDecks);
  campaign.worldStates[worldId] = world;
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  modalUiState.facilityWar.inspectCellIndex = null;
  modalUiState.facilityWar.inspectPinned = false;
  modalUiState.facilityWar.compareCellIndex = null;
  modalUiState.facilityWar.selectedUnitCellIndex = null;
  modalUiState.facilityWar.selectedAttackSourceIndex = null;
  modalUiState.facilityWar.dragAttackSourceIndex = null;
  modalUiState.facilityWar.hoverHandCardId = null;
  document.body.classList.remove('facility-drag-attacking');
  renderFacilityWarModal(loadProfile());
}

function openConquestDeckEditorModal(worldId, planetId) {
  const profile = loadProfile();
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  ensurePlanetConquestState(world, planet);
  modalUiState.conquestDeckEditor.worldId = worldId;
  modalUiState.conquestDeckEditor.planetId = planetId;
  modalUiState.conquestDeckEditor.selectedDeckKey = modalUiState.conquestDeckEditor.selectedDeckKey || 'training';
  modalUiState.conquestDeckEditor.workingDecks = normalizeConquestDecks(planet.conquestDecks);
  renderConquestDeckEditorModal(loadProfile());
  openModal('conquest-deck-editor-modal');
}

function renderConquestDeckEditorModal(profile) {
  const worldId = modalUiState.conquestDeckEditor.worldId;
  const planetId = modalUiState.conquestDeckEditor.planetId;
  if (!worldId || !planetId || !dom.conquestDeckEditorHeader) return;
  const { world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) {
    dom.conquestDeckEditorHeader.textContent = 'World or planet not found.';
    return;
  }
  const working = normalizeConquestDecks(modalUiState.conquestDeckEditor.workingDecks ?? planet.conquestDecks);
  modalUiState.conquestDeckEditor.workingDecks = working;
  modalUiState.conquestDeckEditor.libraryQuery = String(modalUiState.conquestDeckEditor.libraryQuery ?? '');
  modalUiState.conquestDeckEditor.libraryRoleFilter = String(modalUiState.conquestDeckEditor.libraryRoleFilter ?? 'all');
  modalUiState.conquestDeckEditor.librarySort = String(modalUiState.conquestDeckEditor.librarySort ?? 'name');
  const selectedDeckKey = modalUiState.conquestDeckEditor.selectedDeckKey || 'training';
  const summary = conquestDeckSummary(working[selectedDeckKey], profile);
  const roleSummaryText = Object.entries(summary.byRole)
    .sort((a, b) => b[1] - a[1])
    .map(([role, count]) => `${role}:${count}`)
    .join(' • ') || 'No cards';
  dom.conquestDeckEditorHeader.textContent = `${world.worldName} • ${planet.name} • Editing ${selectedDeckKey} deck • ${summary.size} cards • Avg Cost ${summary.avgCost.toFixed(2)}`;
  dom.conquestDeckEditorDecks.innerHTML = '';
  Object.keys(working).forEach((deckKey) => {
    const row = document.createElement('button');
    row.className = `conquest-deck-editor-row ${deckKey === selectedDeckKey ? 'active' : ''}`;
    row.innerHTML = `<span><strong>${deckKey}</strong><br/><small>${working[deckKey].length} cards</small></span><span>${deckKey === selectedDeckKey ? 'Active' : 'Open'}</span>`;
    row.onclick = () => {
      modalUiState.conquestDeckEditor.selectedDeckKey = deckKey;
      renderConquestDeckEditorModal(loadProfile());
    };
    dom.conquestDeckEditorDecks.appendChild(row);
  });
  dom.conquestDeckEditorCards.innerHTML = '';
  working[selectedDeckKey].forEach((cardId, idx) => {
    const card = conquestCardById(profile, cardId);
    const row = document.createElement('div');
    row.className = 'conquest-deck-editor-row';
    row.innerHTML = `<span><strong>${card?.name ?? cardId}</strong><br/><small>${card?.cardType ?? card?.type ?? 'unknown'} • ${card?.subtype ?? ''} • ${conquestCardDeckCategory(card ?? {})} • W${card?.cost?.wheat ?? 0}/I${card?.cost?.iron ?? 0}/M${card?.cost?.mana ?? 0}</small><br/><small>${conquestEntryTags(card ?? {})}</small></span><button data-remove="${idx}">Remove</button>`;
    row.querySelector('button')?.addEventListener('click', () => {
      working[selectedDeckKey].splice(idx, 1);
      renderConquestDeckEditorModal(loadProfile());
    });
    dom.conquestDeckEditorCards.appendChild(row);
  });
  if (!working[selectedDeckKey].length) dom.conquestDeckEditorCards.innerHTML = '<div class="conquest-deck-editor-row"><span>Deck empty.</span></div>';
  const allowedSources = {
    training: new Set(['training', 'command', 'recovery', 'utility']),
    factory: new Set(['factory', 'vehicle', 'ordnance', 'power', 'command', 'utility']),
    blacksmith: new Set(['blacksmith', 'ordnance', 'power', 'command', 'utility']),
    command: new Set(['command', 'experimental', 'recovery', 'utility']),
    vehicle: new Set(['vehicle', 'factory', 'command', 'utility']),
    ordnance: new Set(['ordnance', 'factory', 'blacksmith', 'command', 'utility']),
    air: new Set(['air', 'power', 'experimental', 'command', 'utility']),
    power: new Set(['power', 'experimental', 'blacksmith', 'command', 'utility']),
    recovery: new Set(['recovery', 'training', 'command', 'utility']),
    experimental: new Set(['experimental', 'power', 'air', 'command', 'utility']),
    utility: new Set(['utility', 'command']),
    attacker: new Set(['attacker']),
  };
  const library = conquestCardLibrary(profile).filter((card) => {
    const source = String(card.sourceBuilding ?? card.productionSource ?? '').toLowerCase();
    return (allowedSources[selectedDeckKey] ?? new Set([selectedDeckKey])).has(source);
  });
  const controls = document.createElement('div');
  controls.className = 'conquest-deck-editor-row';
  controls.innerHTML = `
    <span>
      <strong>Filter Library</strong><br/>
      <small>${roleSummaryText}</small><br/>
      <small>${conquestDeckHint(selectedDeckKey, summary)}</small>
    </span>
    <span style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end">
      <input id="cq-editor-query" type="text" placeholder="Search cards..." value="${modalUiState.conquestDeckEditor.libraryQuery.replace(/"/g, '&quot;')}" style="min-width:180px;" />
      <select id="cq-editor-role">
        <option value="all">All Roles</option>
        <option value="unit">Unit</option>
        <option value="equipment">Equipment</option>
        <option value="upgrade">Upgrade</option>
        <option value="structure">Structure</option>
        <option value="tactic">Tactic</option>
      </select>
      <select id="cq-editor-sort">
        <option value="name">Sort: Name</option>
        <option value="cost">Sort: Cost</option>
        <option value="role">Sort: Role</option>
      </select>
    </span>
  `;
  dom.conquestDeckEditorLibrary.innerHTML = '';
  dom.conquestDeckEditorLibrary.appendChild(controls);
  controls.querySelector('#cq-editor-role').value = modalUiState.conquestDeckEditor.libraryRoleFilter;
  controls.querySelector('#cq-editor-sort').value = modalUiState.conquestDeckEditor.librarySort;
  controls.querySelector('#cq-editor-query')?.addEventListener('input', (event) => {
    modalUiState.conquestDeckEditor.libraryQuery = String(event.target?.value ?? '');
    renderConquestDeckEditorModal(loadProfile());
  });
  controls.querySelector('#cq-editor-role')?.addEventListener('change', (event) => {
    modalUiState.conquestDeckEditor.libraryRoleFilter = String(event.target?.value ?? 'all');
    renderConquestDeckEditorModal(loadProfile());
  });
  controls.querySelector('#cq-editor-sort')?.addEventListener('change', (event) => {
    modalUiState.conquestDeckEditor.librarySort = String(event.target?.value ?? 'name');
    renderConquestDeckEditorModal(loadProfile());
  });

  const query = String(modalUiState.conquestDeckEditor.libraryQuery ?? '').trim().toLowerCase();
  const roleFilter = String(modalUiState.conquestDeckEditor.libraryRoleFilter ?? 'all');
  const sortMode = String(modalUiState.conquestDeckEditor.librarySort ?? 'name');
  const filtered = library
    .filter((card) => {
      if (!query) return true;
      return [
        card.name,
        card.id,
        card.subtype,
        card.cardType,
        card.text,
        conquestEntryTags(card),
      ].some((value) => String(value ?? '').toLowerCase().includes(query));
    })
    .filter((card) => {
      if (roleFilter === 'all') return true;
      return conquestRoleSummary(card).toLowerCase() === roleFilter;
    })
    .sort((a, b) => {
      if (sortMode === 'cost') {
        const aCost = Number(a.cost?.wheat ?? 0) + Number(a.cost?.iron ?? 0) + Number(a.cost?.mana ?? 0);
        const bCost = Number(b.cost?.wheat ?? 0) + Number(b.cost?.iron ?? 0) + Number(b.cost?.mana ?? 0);
        return aCost - bCost || String(a.name).localeCompare(String(b.name));
      }
      if (sortMode === 'role') {
        const aRole = conquestRoleSummary(a);
        const bRole = conquestRoleSummary(b);
        return aRole.localeCompare(bRole) || String(a.name).localeCompare(String(b.name));
      }
      return String(a.name).localeCompare(String(b.name));
    });
  filtered.forEach((card) => {
    const row = document.createElement('div');
    row.className = 'conquest-deck-editor-row';
    row.innerHTML = `<span><strong>${card.name}</strong><br/><small>${card.cardType ?? card.type} • ${card.subtype ?? '—'} • ${card.sourceBuilding} • ${card.techTier ?? 'Bronze 1'} • ${conquestRoleSummary(card)}<br/>${card.text}</small><br/><small>${conquestEntryTags(card)}</small></span><button>Add</button>`;
    row.querySelector('button')?.addEventListener('click', () => {
      working[selectedDeckKey].push(card.id);
      renderConquestDeckEditorModal(loadProfile());
    });
    dom.conquestDeckEditorLibrary.appendChild(row);
  });
  if (!filtered.length) {
    const empty = document.createElement('div');
    empty.className = 'conquest-deck-editor-row';
    empty.innerHTML = '<span>No library cards match current filters.</span>';
    dom.conquestDeckEditorLibrary.appendChild(empty);
  }
  if (dom.conquestDeckEditorFeedback) {
    dom.conquestDeckEditorFeedback.textContent = `Deck summary: ${roleSummaryText}. ${conquestDeckHint(selectedDeckKey, summary)}`;
  }
}

function saveConquestDeckEditor() {
  const worldId = modalUiState.conquestDeckEditor.worldId;
  const planetId = modalUiState.conquestDeckEditor.planetId;
  const decks = normalizeConquestDecks(modalUiState.conquestDeckEditor.workingDecks);
  const profile = loadProfile();
  const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, worldId, planetId);
  if (!world || !planet) return;
  planet.conquestDecks = decks;
  ensurePlanetConquestState(world, planet);
  planet.facilityWar.conquestDecks = decks;
  CONQUEST_DEFENDER_DECK_KEYS.forEach((deckKey) => {
    planet.facilityWar.defender.drawDecks[deckKey] = conquestDeckCopy(decks[deckKey]);
  });
  campaign.worldStates[worldId] = world;
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  if (dom.conquestDeckEditorFeedback) dom.conquestDeckEditorFeedback.textContent = 'Conquest decks saved.';
  renderConquestDeckEditorModal(loadProfile());
}

function openConquestCardCreatorModal() {
  if (dom.conquestCardCreatorForm) dom.conquestCardCreatorForm.reset();
  if (dom.conquestCardCreatorFeedback) dom.conquestCardCreatorFeedback.textContent = '';
  openModal('conquest-card-creator-modal');
}

function createConquestCardFromForm() {
  if (!dom.conquestCardCreatorForm) return;
  const data = new FormData(dom.conquestCardCreatorForm);
  const id = slugifyId(String(data.get('id') || '').trim());
  const name = String(data.get('name') || '').trim();
  if (!id || !name) {
    if (dom.conquestCardCreatorFeedback) dom.conquestCardCreatorFeedback.textContent = 'Card ID and name are required.';
    return;
  }
  const card = {
    id,
    name,
    mode: 'conquest',
    side: String(data.get('side') || 'defender').toLowerCase(),
    cardType: String(data.get('cardType') || 'Unit').trim() || 'Unit',
    subtype: String(data.get('subtype') || '').trim(),
    techTier: String(data.get('techTier') || 'Bronze 1').trim() || 'Bronze 1',
    type: String(data.get('type') || 'unit'),
    sourceBuilding: String(data.get('sourceBuilding') || 'utility').toLowerCase(),
    productionSource: String(data.get('sourceBuilding') || 'utility').toLowerCase(),
    attackerPackage: String(data.get('attackerPackage') || '').trim() || null,
    cost: {
      wheat: Math.max(0, Number(data.get('wheatCost') || 0)),
      iron: Math.max(0, Number(data.get('ironCost') || 0)),
      mana: Math.max(0, Number(data.get('manaCost') || 0)),
    },
    wheatCost: Math.max(0, Number(data.get('wheatCost') || 0)),
    ironCost: Math.max(0, Number(data.get('ironCost') || 0)),
    manaCost: Math.max(0, Number(data.get('manaCost') || 0)),
    attack: Math.max(0, Number(data.get('attack') || 0)),
    health: Math.max(0, Number(data.get('health') || 0)),
    defense: Math.max(0, Number(data.get('defense') || 0)),
    range: clamp(Math.max(1, Number(data.get('range') || 1)), 1, 5),
    siege: Math.max(0, Number(data.get('siege') || 0)),
    flying: data.get('flying') === 'on',
    horde: data.get('horde') === 'on',
    large: data.get('large') === 'on',
    fortified: data.get('fortified') === 'on',
    structure: data.get('structure') === 'on',
    barricade: data.get('barricade') === 'on',
    facility: data.get('facility') === 'on',
    equipment: data.get('equipment') === 'on',
    upgradeSchematic: data.get('upgradeSchematic') === 'on',
    repairRelevant: data.get('repairRelevant') === 'on',
    captureRelevant: data.get('captureRelevant') === 'on',
    tags: String(data.get('tags') || '')
      .split(',')
      .map((entry) => entry.trim().toLowerCase())
      .filter(Boolean),
    text: String(data.get('text') || 'Custom conquest card.'),
    flavorText: String(data.get('flavorText') || '').trim(),
  };
  if (!card.tags.includes('conquest')) card.tags.push('conquest');
  if (card.sourceBuilding && !card.tags.includes(card.sourceBuilding)) card.tags.push(card.sourceBuilding);
  if (card.side && !card.tags.includes(card.side)) card.tags.push(card.side);
  if (card.flying && !card.tags.includes('flying')) card.tags.push('flying');
  if (card.horde && !card.tags.includes('horde')) card.tags.push('horde');
  if (card.large && !card.tags.includes('large')) card.tags.push('large');
  if (card.barricade && !card.tags.includes('barricade')) card.tags.push('barricade');
  if (card.structure && !card.tags.includes('structure')) card.tags.push('structure');
  if (card.attackerPackage && !card.tags.includes(`pkg:${card.attackerPackage.toLowerCase()}`)) card.tags.push(`pkg:${card.attackerPackage.toLowerCase()}`);
  const profile = loadProfile();
  const mapWorld = getMapWorld(profile);
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  campaign.conquestCardLibrary = Array.isArray(campaign.conquestCardLibrary) ? campaign.conquestCardLibrary : [];
  const existingIdx = campaign.conquestCardLibrary.findIndex((entry) => entry.id === card.id);
  if (existingIdx >= 0) campaign.conquestCardLibrary[existingIdx] = card;
  else campaign.conquestCardLibrary.push(card);
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  if (dom.conquestCardCreatorFeedback) dom.conquestCardCreatorFeedback.textContent = `Conquest card "${card.name}" saved.`;
  if (!dom.conquestDeckEditorModal?.classList.contains('hidden')) renderConquestDeckEditorModal(loadProfile());
}

function buildStyleOptions() {
  const optionHtml = cachedMapStyles.map((style) => `<option value="${style.id}">${style.name}</option>`).join('');
  [dom.mapStyleSelect, dom.galaxyStyleSelect, dom.aiStyleSelect, dom.mapStyleFilter].forEach((select) => {
    if (!select) return;
    const isFilter = select === dom.mapStyleFilter;
    select.innerHTML = isFilter ? `<option value="all">All Styles</option>${optionHtml}` : optionHtml;
  });
}

function buildPackOptions() {
  if (!dom.aiPackSelect) return;
  dom.aiPackSelect.innerHTML = '';
  cachedCardPacks.forEach((pack) => {
    const option = document.createElement('option');
    option.value = pack.id;
    option.textContent = `${pack.name} (${pack.source})`;
    dom.aiPackSelect.appendChild(option);
  });
}

function unoccupiedCreatedGalaxies(profile, includeId = null) {
  const mapWorld = getMapWorld(profile);
  return (mapWorld.createdGalaxies ?? []).filter((galaxy) => {
    if (!galaxy?.id) return false;
    if (includeId && galaxy.id === includeId) return true;
    return !galaxy.occupiedByAIId;
  });
}

function populateAssignableGalaxies(selectedId = '') {
  const profile = loadProfile();
  const query = String(dom.aiGalaxySearch?.value ?? '').trim().toLowerCase();
  const nodes = unoccupiedCreatedGalaxies(profile, selectedId).filter((galaxy) => {
    if (!query) return true;
    return `${galaxy.name} ${galaxy.seed} ${galaxy.universe ?? ''}`.toLowerCase().includes(query);
  });
  dom.aiAssignedGalaxySelect.innerHTML = '<option value="">Unassigned</option>';
  nodes.forEach((galaxy) => {
    const option = document.createElement('option');
    option.value = galaxy.id;
    option.textContent = `${galaxy.name} [${normalizeSeed(galaxy.seed)}] • ${galaxy.universe ?? 'Unknown'}`;
    if (galaxy.id === selectedId) option.selected = true;
    dom.aiAssignedGalaxySelect.appendChild(option);
  });
}

function hydrateGalaxyForm(nodeId = null) {
  const form = dom.galaxyCreatorForm;
  if (!form) return;
  const node = nodeId ? mapNodeById(nodeId) : null;
  if (!node) {
    form.reset();
    form.elements.seed.value = autoSeed('GX');
    form.elements.styleId.value = dom.mapStyleSelect?.value || 'astral-cartographer';
    return;
  }
  form.elements.name.value = node.name ?? '';
  form.elements.seed.value = node.seed ?? '';
  form.elements.universe.value = node.universe ?? '';
  form.elements.sunCount.value = node.sunCount ?? 1;
  form.elements.planetCount.value = node.planetCount ?? 6;
  form.elements.orbitLayout.value = node.orbitLayout ?? 'stable';
  form.elements.styleId.value = node.styleId ?? dom.mapStyleSelect?.value ?? 'astral-cartographer';
  form.elements.paletteName.value = node.paletteName ?? '';
  form.elements.nebulaStyle.value = node.nebulaStyle ?? '';
  form.elements.ringedPlanets.checked = !!node.ringedPlanets;
  form.elements.moonDensity.value = node.moonDensity ?? 2;
  form.elements.hazardType.value = node.hazardType ?? '';
  form.elements.occupiedDefault.value = node.occupiedByAIId ? 'occupied' : 'unoccupied';
  form.elements.discoveryDefault.value = node.discoveryDefault ?? 'discovered';
  form.elements.rarityTier.value = node.rarityTier ?? 'common';
  form.elements.gatewaySignature.value = node.gatewaySignature ?? '';
  form.elements.emblem.value = node.emblem ?? '';
  form.elements.ambienceTag.value = node.ambienceTag ?? '';
  form.elements.packSource.value = Array.isArray(node.packSource) ? node.packSource.join(',') : (node.packSource ?? '');
  form.elements.lore.value = node.lore ?? '';
}

function hydrateAiEditor(targetGalaxyId = null) {
  const form = dom.aiEditorForm;
  if (!form) return;
  form.reset();
  if (dom.aiGalaxySearch) dom.aiGalaxySearch.value = '';
  const selectedNode = targetGalaxyId ? mapNodeById(targetGalaxyId) : mapNodeById(mapView.selectedNodeId);
  const assignedId = selectedNode?.id ?? '';
  populateAssignableGalaxies(assignedId);
  if (selectedNode) {
    form.elements.assignedGalaxyId.value = assignedId;
    form.elements.styleId.value = selectedNode.styleId ?? dom.mapStyleSelect?.value ?? 'astral-cartographer';
    form.elements.universe.value = selectedNode.universe ?? '';
  }
  if (!form.elements.id.value) form.elements.id.value = `custom-ai-${Date.now()}`;
}

function saveGalaxyFromForm(baseProfiles) {
  const form = dom.galaxyCreatorForm;
  const data = new FormData(form);
  const name = String(data.get('name') || '').trim();
  const seed = normalizeSeed(data.get('seed'));
  if (!name || !seed) {
    dom.galaxyCreatorFeedback.textContent = 'Name and seed are required.';
    return;
  }
  const sourcePacks = String(data.get('packSource') || '').split(',').map((entry) => entry.trim()).filter(Boolean);
  withProfile((profile) => {
    const mapWorld = getMapWorld(profile);
    const existingIdx = mapWorld.createdGalaxies.findIndex((galaxy) => normalizeSeed(galaxy.seed) === seed || galaxy.name === name);
    const generated = generateGalaxyFromSeed(seed, {
      id: existingIdx >= 0 ? mapWorld.createdGalaxies[existingIdx].id : `user-${seed.toLowerCase()}`,
      name,
      universe: data.get('universe'),
      sunCount: Number(data.get('sunCount') || 1),
      planetCount: Number(data.get('planetCount') || 6),
      orbitLayout: data.get('orbitLayout'),
      styleId: data.get('styleId') || mapWorld.globalMapStyleId,
      paletteName: data.get('paletteName'),
      nebulaStyle: data.get('nebulaStyle'),
      ringedPlanets: data.get('ringedPlanets') === 'on',
      moonDensity: Number(data.get('moonDensity') || 2),
      hazardType: data.get('hazardType'),
      lore: data.get('lore'),
      state: data.get('occupiedDefault') === 'occupied' ? 'occupied' : 'unoccupied',
      discoveryDefault: data.get('discoveryDefault') || 'discovered',
      rarityTier: data.get('rarityTier'),
      gatewaySignature: data.get('gatewaySignature'),
      emblem: data.get('emblem'),
      ambienceTag: data.get('ambienceTag'),
      packSource: sourcePacks,
      nodeType: 'created',
      gatewayImported: true,
    });
    if (existingIdx >= 0) mapWorld.createdGalaxies[existingIdx] = { ...mapWorld.createdGalaxies[existingIdx], ...generated };
    else mapWorld.createdGalaxies.push(generated);
    mapWorld.gatewayIndexBySeed[seed] = generated.id;
    mapWorld.selectedNodeId = generated.id;
    profile.mapWorld = mapWorld;
  });
  dom.galaxyCreatorFeedback.textContent = `Saved galaxy ${name} (${seed}).`;
  renderBattleMap(baseProfiles, loadProfile());
}

function saveAiFromForm(baseProfiles) {
  const form = dom.aiEditorForm;
  const data = new FormData(form);
  const id = String(data.get('id') || '').trim();
  const name = String(data.get('name') || '').trim();
  if (!id || !name) {
    dom.aiEditorFeedback.textContent = 'AI id and name are required.';
    return;
  }
  withProfile((profile) => {
    const mapWorld = getMapWorld(profile);
    const assignedPacks = Array.from(dom.aiPackSelect.selectedOptions).map((entry) => entry.value);
    const aiProfile = {
      type: MAP_TYPES.CustomAiProfile,
      id,
      name,
      level: Number(data.get('level') || 1),
      difficultyLabel: data.get('difficultyLabel') || buildDifficultyLabel(Number(data.get('level') || 1)),
      archetype: data.get('archetype') || 'custom',
      deckId: data.get('deckId') || null,
      styleId: data.get('styleId') || mapWorld.globalMapStyleId,
      assignedGalaxyId: data.get('assignedGalaxyId') || null,
      assignedPacks,
      universe: data.get('universe') || null,
      faction: data.get('faction') || null,
      behaviorNotes: String(data.get('behaviorNotes') || '').split(',').map((entry) => entry.trim()).filter(Boolean),
      rewardMeta: data.get('rewardMeta') || '',
      personality: {
        title: data.get('title') || 'Dimensional Wielder',
        dimensionTag: data.get('universe') ? `#${String(data.get('universe')).replace(/\s+/g, '-')}` : '#Custom',
        chatStyle: data.get('archetype') || 'adaptive',
      },
      voiceLines: {
        pre_match: [data.get('introLine') || `${name}: Systems check complete.`],
        victory_near: [data.get('victoryLine') || `${name}: The line is closing.`],
        defeat: [data.get('defeatLine') || `${name}: You earned this one.`],
        lobby_greeting: [data.get('idleLine') || `${name}: Ready to run another match.`],
        strong_play: [data.get('challengeLine') || `${name}: Challenge accepted.`],
        post_defeat_lobby: [data.get('rematchLine') || `${name}: Rematch when ready.`],
        big_enemy_seen: [data.get('loreLine') || `${name}: That unit is a problem.`],
        low_health: [data.get('lowHealthLine') || `${name}: Stabilizing.`],
        combo_ready: [data.get('specialLine') || `${name}: Sequence online.`],
      },
    };
    const idx = mapWorld.customAiProfiles.findIndex((entry) => entry.id === id);
    const previous = idx >= 0 ? mapWorld.customAiProfiles[idx] : null;
    if (idx >= 0) mapWorld.customAiProfiles[idx] = { ...previous, ...aiProfile };
    else mapWorld.customAiProfiles.push(aiProfile);

    (mapWorld.createdGalaxies ?? []).forEach((galaxy) => {
      if (galaxy.occupiedByAIId === id) galaxy.occupiedByAIId = null;
    });
    const assignedGalaxyId = aiProfile.assignedGalaxyId;
    if (assignedGalaxyId) {
      const galaxy = mapWorld.createdGalaxies.find((entry) => entry.id === assignedGalaxyId);
      if (galaxy) {
        galaxy.occupiedByAIId = id;
        galaxy.state = 'occupied';
        galaxy.styleId = aiProfile.styleId || galaxy.styleId;
        galaxy.packSource = assignedPacks.length ? assignedPacks : (galaxy.packSource ?? []);
      }
      mapWorld.nodeAssignments[assignedGalaxyId] = id;
    }
    mapWorld.selectedNodeId = assignedGalaxyId || mapWorld.selectedNodeId;
    profile.mapWorld = mapWorld;
  });
  dom.aiEditorFeedback.textContent = `Saved AI profile ${name}.`;
  renderBattleMap(baseProfiles, loadProfile());
}

function resolveSeedToGalaxy(seedInput, profile) {
  const seed = normalizeSeed(seedInput);
  if (!seed || seed.length < 3) return null;
  const mapWorld = getMapWorld(profile);
  const candidates = [...cachedStarterGalaxies, ...(mapWorld.createdGalaxies ?? [])];
  const existing = candidates.find((entry) => normalizeSeed(entry.seed) === seed);
  if (!existing) return null;
  return generateGalaxyFromSeed(existing.seed, {
    ...existing,
    id: existing.id,
    gatewayImported: true,
    state: existing.state === 'hidden' ? 'discovered' : (existing.state ?? 'unoccupied'),
  });
}

function importGatewaySeed(seedInput, baseProfiles) {
  const profile = loadProfile();
  const mapWorld = getMapWorld(profile);
  const seed = normalizeSeedWithMode(seedInput, dom.gatewaySeedMode?.value ?? 'auto');
  if (!seed || seed.length < 3) {
    dom.gatewayFeedback.textContent = 'Invalid seed format.';
    return;
  }
  const alreadyId = mapWorld.gatewayIndexBySeed[seed];
  if (alreadyId) {
    mapView.selectedNodeId = alreadyId;
    centerMapOnNode(alreadyId);
    dom.gatewayFeedback.textContent = `Gateway ${seed} already active. Focused existing node.`;
    renderBattleMap(baseProfiles, profile);
    return;
  }
  const found = resolveSeedToGalaxy(seed, profile);
  if (!found) {
    dom.gatewayFeedback.textContent = 'Unknown seed. Create this galaxy first, then import it.';
    return;
  }
  withProfile((next) => {
    const mw = getMapWorld(next);
    const idx = mw.createdGalaxies.findIndex((entry) => normalizeSeed(entry.seed) === seed || entry.id === found.id);
    if (idx >= 0) mw.createdGalaxies[idx] = { ...mw.createdGalaxies[idx], ...found, gatewayImported: true };
    else mw.createdGalaxies.push({ ...found, source: 'created', gatewayImported: true });
    mw.gatewayIndexBySeed[seed] = found.id;
    mw.selectedNodeId = found.id;
    next.mapWorld = mw;
  });
  dom.gatewayFeedback.textContent = `Gateway ${seed} spawned and focused.`;
  mapView.selectedNodeId = found.id;
  mapView.focusedNodeId = found.id;
  mapView.animatingNodeId = found.id;
  renderBattleMap(baseProfiles, loadProfile());
  centerMapOnNode(found.id);
  setTimeout(() => {
    if (mapView.animatingNodeId === found.id) {
      mapView.animatingNodeId = null;
      updateMapNodeInteractionVisuals();
    }
  }, 1200);
}

function bindMapInteractionHandlers(baseProfiles) {
  mapProfilesRef = [...baseProfiles];
  if (!mapInteractionsBound) {
    const PAN_DRAG_THRESHOLD = 6;
    dom.mapSvg.addEventListener('wheel', (event) => {
      event.preventDefault();
      const delta = event.deltaY < 0 ? 0.12 : -0.12;
      const currentZoom = Number.isFinite(mapView.zoom) ? mapView.zoom : 1;
      mapView.zoom = Math.max(0.6, Math.min(2.5, currentZoom + delta));
      applyMapTransform();
      updateMapNodeInteractionVisuals();
    }, { passive: false });

    dom.mapStage?.addEventListener('dragstart', suppressMapNativeEvent);
    dom.mapStage?.addEventListener('selectstart', suppressMapNativeEvent);
    dom.mapSvg.addEventListener('mousedown', (event) => {
      if (event.button !== 0) return;
      if (!canStartMapPanFromTarget(event.target)) return;
      if (event.cancelable) event.preventDefault();
    }, { passive: false });
    dom.mapSvg.addEventListener('contextmenu', (event) => {
      if (!event.target) return;
      if (event.cancelable) event.preventDefault();
    });

    dom.mapSvg.addEventListener('pointerdown', (event) => {
      if (event.button !== 0) return;
      if (!canStartMapPanFromTarget(event.target)) return;
      setMapLeftPointerHeld(true);
      mapView.panPointerId = event.pointerId;
      mapView.panCandidate = true;
      mapView.dragging = false;
      mapView.hoveredNodeId = null;
      mapView.dragStartX = event.clientX;
      mapView.dragStartY = event.clientY;
      mapView.lastX = event.clientX;
      mapView.lastY = event.clientY;
      if (event.cancelable) event.preventDefault();
      dom.mapSvg.setPointerCapture?.(event.pointerId);
      updateMapNodeInteractionVisuals();
    });
    dom.mapSvg.addEventListener('pointermove', (event) => {
      if (mapView.panPointerId !== null && event.pointerId !== mapView.panPointerId) return;
      if (!mapView.panCandidate && !mapView.dragging) return;
      if (!mapView.dragging) {
        const travel = Math.hypot(event.clientX - mapView.dragStartX, event.clientY - mapView.dragStartY);
        if (travel < PAN_DRAG_THRESHOLD) return;
        mapView.dragging = true;
        mapView.suppressClickUntil = Date.now() + 120;
        dom.mapSvg.classList.add('dragging');
      }
      const dx = event.clientX - mapView.lastX;
      const dy = event.clientY - mapView.lastY;
      mapView.lastX = event.clientX;
      mapView.lastY = event.clientY;
      mapView.panX = (Number.isFinite(mapView.panX) ? mapView.panX : 0) + dx;
      mapView.panY = (Number.isFinite(mapView.panY) ? mapView.panY : 0) + dy;
      mapView.offscreenGuardCount = 0;
      if (event.cancelable) event.preventDefault();
      applyMapTransform();
      updateMapNodeInteractionVisuals();
    });
    const endDrag = (event) => {
      if (mapView.panPointerId !== null && event?.pointerId !== undefined && event.pointerId !== mapView.panPointerId) return;
      const wasDragging = mapView.dragging;
      mapView.panCandidate = false;
      mapView.dragging = false;
      mapView.panPointerId = null;
      dom.mapSvg.classList.remove('dragging');
      dom.mapSvg.releasePointerCapture?.(event.pointerId);
      if (wasDragging) {
        mapView.suppressClickUntil = Date.now() + 180;
        if (event?.cancelable) event.preventDefault();
      }
      if (!event || event.button === 0 || event.buttons === 0) setMapLeftPointerHeld(false);
      updateMapNodeInteractionVisuals();
    };
    dom.mapSvg.addEventListener('pointerup', endDrag);
    dom.mapSvg.addEventListener('pointercancel', endDrag);
    dom.mapSvg.addEventListener('pointerleave', () => {
      if (!mapView.dragging && !mapView.panCandidate) {
        mapView.hoveredNodeId = null;
        updateMapNodeInteractionVisuals();
      }
    });
    document.addEventListener('pointerup', (event) => {
      if (mapView.panPointerId !== null && event.pointerId === mapView.panPointerId) {
        mapView.panCandidate = false;
        mapView.dragging = false;
        mapView.panPointerId = null;
        dom.mapSvg.classList.remove('dragging');
        updateMapNodeInteractionVisuals();
      }
      if (event.button === 0 || event.buttons === 0) setMapLeftPointerHeld(false);
    });
    document.addEventListener('pointercancel', (event) => {
      if (mapView.panPointerId !== null && event.pointerId === mapView.panPointerId) {
        mapView.panCandidate = false;
        mapView.dragging = false;
        mapView.panPointerId = null;
        dom.mapSvg.classList.remove('dragging');
        updateMapNodeInteractionVisuals();
      }
      setMapLeftPointerHeld(false);
    });
    window.addEventListener('blur', () => {
      mapView.panCandidate = false;
      mapView.dragging = false;
      mapView.panPointerId = null;
      dom.mapSvg.classList.remove('dragging');
      setMapLeftPointerHeld(false);
    });

    dom.mapCenterSelectedBtn.onclick = () => centerMapOnNode(mapView.selectedNodeId);
    dom.mapResetViewBtn.onclick = () => resetMapView();
    dom.mapExpandToggle.onclick = () => {
      dom.battlemapPanel.classList.toggle('expanded');
      dom.mapExpandToggle.textContent = dom.battlemapPanel.classList.contains('expanded') ? 'Collapse Map' : 'Expand Map';
      setTimeout(() => {
        resizeMapEffectsCanvas();
        startMapEffects(findStyleById(dom.mapStyleSelect.value), mapView.nodes, mapView.sceneStaticSig || buildStaticSceneSignature(mapView.nodes));
      }, 100);
    };
    dom.mapNodeSearch.oninput = () => {
      withProfile((profile) => {
        const mw = getMapWorld(profile);
        mw.mapFilters.search = dom.mapNodeSearch.value;
        profile.mapWorld = mw;
      });
      renderBattleMap(mapProfilesRef, loadProfile());
    };
    dom.mapStatusFilter.onchange = () => {
      withProfile((profile) => {
        const mw = getMapWorld(profile);
        mw.mapFilters.status = dom.mapStatusFilter.value;
        profile.mapWorld = mw;
      });
      renderBattleMap(mapProfilesRef, loadProfile());
    };
    dom.mapStyleFilter.onchange = () => {
      withProfile((profile) => {
        const mw = getMapWorld(profile);
        mw.mapFilters.style = dom.mapStyleFilter.value;
        profile.mapWorld = mw;
      });
      renderBattleMap(mapProfilesRef, loadProfile());
    };
    if (dom.invasionThreatFilter) {
      dom.invasionThreatFilter.onchange = () => {
        const value = String(dom.invasionThreatFilter.value ?? 'all').toLowerCase();
        mapView.threatFilter = value || 'all';
        renderBattleMap(mapProfilesRef, loadProfile());
      };
    }
    dom.mapStyleSelect.onchange = () => {
      withProfile((profile) => {
        const mw = getMapWorld(profile);
        mw.globalMapStyleId = dom.mapStyleSelect.value;
        profile.mapWorld = mw;
      });
      renderBattleMap(mapProfilesRef, loadProfile());
    };
    [dom.viewerModeSplitBtn, dom.viewerModeVisualBtn, dom.viewerModeInfoBtn].forEach((button) => {
      if (!button) return;
      button.onclick = () => setSystemViewerMode(button.dataset.viewerMode);
    });
    if (dom.systemFocusBtn) {
      dom.systemFocusBtn.onclick = () => setSystemViewerFocus(!mapView.systemViewerFocus);
    }
    window.addEventListener('resize', () => {
      resizeMapEffectsCanvas();
      startMapEffects(findStyleById(dom.mapStyleSelect.value), mapView.nodes, mapView.sceneStaticSig || buildStaticSceneSignature(mapView.nodes));
    });
    mapInteractionsBound = true;
  }
  if (!mapModalsBound) {
    dom.findGatewayBtn.onclick = () => openModal('gateway-modal');
    dom.openGalaxyCreatorBtn.onclick = () => {
      hydrateGalaxyForm();
      openModal('galaxy-creator-modal');
    };
    dom.openAiEditorBtn.onclick = () => {
      hydrateAiEditor();
      openModal('ai-editor-modal');
    };
    dom.modalBackdrop.onclick = () => {
      closeModal('gateway-modal');
      closeModal('galaxy-creator-modal');
      closeModal('ai-editor-modal');
      closeModal('threat-inspect-modal');
      closeModal('conquest-modal');
      closeModal('world-management-modal');
      closeModal('facility-war-modal');
      closeModal('conquest-mat-settings-modal');
      closeModal('conquest-deck-editor-modal');
      closeModal('conquest-card-creator-modal');
    };
    document.querySelectorAll('[data-close-modal]').forEach((button) => {
      button.onclick = () => closeModal(button.dataset.closeModal);
    });
    dom.gatewayAutoSeedBtn.onclick = () => { dom.gatewaySeedInput.value = autoSeed('GX'); };
    dom.gatewayCopySeedBtn.onclick = async () => {
      if (!dom.gatewaySeedInput.value.trim()) dom.gatewaySeedInput.value = autoSeed('GX');
      await navigator.clipboard.writeText(dom.gatewaySeedInput.value.trim());
      dom.gatewayFeedback.textContent = 'Seed copied.';
    };
    dom.gatewayImportBtn.onclick = () => importGatewaySeed(dom.gatewaySeedInput.value, mapProfilesRef);
    dom.galaxySeedFromNameBtn.onclick = () => {
      const name = String(dom.galaxyCreatorForm.elements.name.value || 'GATEWAY').trim().toUpperCase().replace(/\s+/g, '-');
      dom.galaxyCreatorForm.elements.seed.value = `${name}-${Math.floor(Math.random() * 999)}`;
    };
    dom.galaxySaveBtn.onclick = () => saveGalaxyFromForm(mapProfilesRef);
    dom.galaxyExportBtn.onclick = () => {
      const mapWorld = getMapWorld(loadProfile());
      dom.galaxyImportExport.value = JSON.stringify(mapWorld.createdGalaxies, null, 2);
      dom.galaxyCreatorFeedback.textContent = 'Created galaxies exported to textbox.';
    };
    dom.galaxyImportBtn.onclick = () => {
      try {
        const incoming = JSON.parse(dom.galaxyImportExport.value || '[]');
        if (!Array.isArray(incoming)) throw new Error('Expected array');
        withProfile((profile) => {
          const mw = getMapWorld(profile);
          incoming.forEach((entry) => {
            if (!entry?.seed || !entry?.name) return;
            const generated = generateGalaxyFromSeed(entry.seed, { ...entry, id: entry.id ?? `user-${normalizeSeed(entry.seed).toLowerCase()}` });
            const idx = mw.createdGalaxies.findIndex((galaxy) => galaxy.id === generated.id || normalizeSeed(galaxy.seed) === normalizeSeed(generated.seed));
            if (idx >= 0) mw.createdGalaxies[idx] = { ...mw.createdGalaxies[idx], ...generated };
            else mw.createdGalaxies.push(generated);
            mw.gatewayIndexBySeed[normalizeSeed(generated.seed)] = generated.id;
          });
          profile.mapWorld = mw;
        });
        dom.galaxyCreatorFeedback.textContent = 'Imported galaxies.';
        renderBattleMap(mapProfilesRef, loadProfile());
      } catch {
        dom.galaxyCreatorFeedback.textContent = 'Invalid galaxy JSON.';
      }
    };
    dom.aiSaveBtn.onclick = () => saveAiFromForm(mapProfilesRef);
    dom.aiUnassignBtn.onclick = () => {
      const aiId = String(dom.aiEditorForm.elements.id.value || '').trim();
      if (!aiId) return;
      withProfile((profile) => {
        const mw = getMapWorld(profile);
        mw.createdGalaxies.forEach((galaxy) => {
          if (galaxy.occupiedByAIId === aiId) galaxy.occupiedByAIId = null;
        });
        Object.keys(mw.nodeAssignments).forEach((key) => {
          if (mw.nodeAssignments[key] === aiId) delete mw.nodeAssignments[key];
        });
        const idx = mw.customAiProfiles.findIndex((ai) => ai.id === aiId);
        if (idx >= 0) mw.customAiProfiles[idx].assignedGalaxyId = null;
        profile.mapWorld = mw;
      });
      dom.aiEditorFeedback.textContent = `AI ${aiId} unassigned.`;
      renderBattleMap(mapProfilesRef, loadProfile());
    };
    dom.aiExportBtn.onclick = () => {
      const mw = getMapWorld(loadProfile());
      dom.aiImportExport.value = JSON.stringify(mw.customAiProfiles, null, 2);
      dom.aiEditorFeedback.textContent = 'Custom AIs exported to textbox.';
    };
    dom.aiImportBtn.onclick = () => {
      try {
        const incoming = JSON.parse(dom.aiImportExport.value || '[]');
        if (!Array.isArray(incoming)) throw new Error('Expected array');
        withProfile((profile) => {
          const mw = getMapWorld(profile);
          incoming.forEach((entry) => {
            if (!entry?.id || !entry?.name) return;
            const idx = mw.customAiProfiles.findIndex((ai) => ai.id === entry.id);
            if (idx >= 0) mw.customAiProfiles[idx] = { ...mw.customAiProfiles[idx], ...entry };
            else mw.customAiProfiles.push(entry);
          });
          profile.mapWorld = mw;
        });
        dom.aiEditorFeedback.textContent = 'Imported custom AI profiles.';
        renderBattleMap(mapProfilesRef, loadProfile());
      } catch {
        dom.aiEditorFeedback.textContent = 'Invalid AI JSON.';
      }
    };
    dom.aiPreviewLineBtn.onclick = () => {
      const name = dom.aiEditorForm.elements.name.value || 'AI';
      const line = dom.aiEditorForm.elements.introLine.value || `${name}: Systems ready.`;
      dom.aiEditorFeedback.textContent = `${name} preview: "${line}"`;
    };
    if (dom.aiGalaxySearch) {
      dom.aiGalaxySearch.oninput = () => populateAssignableGalaxies(dom.aiAssignedGalaxySelect.value);
    }
    if (dom.worldOpsBuildBtn) {
      dom.worldOpsBuildBtn.onclick = () => {
        const worldId = modalUiState.worldOps.worldId;
        const planetId = modalUiState.worldOps.planetId;
        const buildingId = modalUiState.worldOps.selectedBuildingId;
        if (!worldId || !planetId || !buildingId) return;
        const res = applyBuildingToPlanet(loadProfile(), worldId, planetId, buildingId);
        if (dom.worldOpsFeedback) dom.worldOpsFeedback.textContent = res.message;
        renderWorldOpsModal(loadProfile());
      };
    }
    if (dom.worldOpsProduceBtn) {
      dom.worldOpsProduceBtn.onclick = () => {
        const worldId = modalUiState.worldOps.worldId;
        const planetId = modalUiState.worldOps.planetId;
        const cardId = modalUiState.worldOps.selectedProduceCardId;
        if (!worldId || !planetId || !cardId) return;
        const qty = clamp(Math.floor(toFiniteNumber(dom.worldOpsProduceCount?.value, 1)), 1, 10);
        const res = produceCardForWorld(loadProfile(), worldId, planetId, cardId, qty);
        if (dom.worldOpsFeedback) dom.worldOpsFeedback.textContent = res.message;
        renderWorldOpsModal(loadProfile());
      };
    }
    const runFacilityDevCommand = () => {
      const input = dom.facilityDevCommandInput;
      if (!input) return;
      const raw = String(input.value ?? '').trim();
      if (!raw) return;
      const profile = loadProfile();
      const result = handleFacilityDevCommand(raw, profile);
      const worldId = modalUiState.facilityWar.worldId;
      const planetId = modalUiState.facilityWar.planetId;
      const { world, planet } = worldId && planetId ? getWorldPlanet(profile, worldId, planetId) : { world: null, planet: null };
      if (world && planet?.facilityWar) {
        ensurePlanetConquestState(world, planet);
        facilityLog(planet.facilityWar, `[Dev] ${result.message}`, result.ok ? 'info' : 'bad');
        pushFacilityDevTrace(`[Command] ${raw} -> ${result.message}`, result.ok ? 'dev' : 'bad');
        persistFacilityState(profile, worldId, planetId, planet.facilityWar);
        renderFacilityWarModal(loadProfile());
      }
      input.value = '';
    };
    if (dom.facilityDevCommandRun) dom.facilityDevCommandRun.onclick = runFacilityDevCommand;
    if (dom.facilityDevCommandInput) {
      dom.facilityDevCommandInput.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        runFacilityDevCommand();
      });
    }
    if (dom.facilityDrawTrainingBtn) {
      dom.facilityDrawTrainingBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'training');
    }
    if (dom.facilityDrawFactoryBtn) {
      dom.facilityDrawFactoryBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'factory');
    }
    if (dom.facilityDrawBlacksmithBtn) {
      dom.facilityDrawBlacksmithBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'blacksmith');
    }
    if (dom.facilityDrawCommandBtn) {
      dom.facilityDrawCommandBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'command');
    }
    if (dom.facilityDrawVehicleBtn) {
      dom.facilityDrawVehicleBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'vehicle');
    }
    if (dom.facilityDrawOrdnanceBtn) {
      dom.facilityDrawOrdnanceBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'ordnance');
    }
    if (dom.facilityDrawAirBtn) {
      dom.facilityDrawAirBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'air');
    }
    if (dom.facilityDrawPowerBtn) {
      dom.facilityDrawPowerBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'power');
    }
    if (dom.facilityDrawRecoveryBtn) {
      dom.facilityDrawRecoveryBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'recovery');
    }
    if (dom.facilityDrawExperimentalBtn) {
      dom.facilityDrawExperimentalBtn.onclick = () => runFacilityDraw(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId, 'experimental');
    }
    if (dom.facilityWarEndTurnBtn) {
      dom.facilityWarEndTurnBtn.onclick = () => runFacilityEndTurn(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
    }
    if (dom.facilityWarAttackBtn) {
      dom.facilityWarAttackBtn.onclick = () => runFacilityAttackAction(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
    }
    if (dom.facilityWarDeconstructBtn) {
      dom.facilityWarDeconstructBtn.onclick = () => runFacilityDeconstructAction(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
    }
    if (dom.facilityWarResetBtn) {
      dom.facilityWarResetBtn.onclick = () => resetFacilityWarForPlanet(modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
    }
    if (dom.facilityFitBoardBtn) {
      dom.facilityFitBoardBtn.onclick = () => {
        modalUiState.facilityWar.boardViewMode = 'fit';
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityFocusBoardBtn) {
      dom.facilityFocusBoardBtn.onclick = () => {
        modalUiState.facilityWar.boardViewMode = 'focus';
        if (!Number.isFinite(modalUiState.facilityWar.boardZoom) || modalUiState.facilityWar.boardZoom <= 0) {
          modalUiState.facilityWar.boardZoom = 1;
        }
        renderFacilityWarModal(loadProfile());
        centerFacilityBoardViewport();
      };
    }
    if (dom.facilityZoomInBtn) {
      dom.facilityZoomInBtn.onclick = () => {
        modalUiState.facilityWar.boardViewMode = 'focus';
        modalUiState.facilityWar.boardZoom = clamp(toFiniteNumber(modalUiState.facilityWar.boardZoom, 1) + 0.12, 0.65, 2.2);
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityZoomOutBtn) {
      dom.facilityZoomOutBtn.onclick = () => {
        modalUiState.facilityWar.boardViewMode = 'focus';
        modalUiState.facilityWar.boardZoom = clamp(toFiniteNumber(modalUiState.facilityWar.boardZoom, 1) - 0.12, 0.65, 2.2);
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityResetBoardBtn) {
      dom.facilityResetBoardBtn.onclick = () => {
        modalUiState.facilityWar.boardViewMode = 'fit';
        modalUiState.facilityWar.boardZoom = 1;
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityHeatmapToggleBtn) {
      dom.facilityHeatmapToggleBtn.onclick = () => {
        modalUiState.facilityWar.showHeatmap = !modalUiState.facilityWar.showHeatmap;
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityCinematicToggleBtn) {
      dom.facilityCinematicToggleBtn.onclick = () => {
        modalUiState.facilityWar.cinematicMode = !modalUiState.facilityWar.cinematicMode;
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilitySetupPresetSelect) {
      dom.facilitySetupPresetSelect.onchange = () => {
        const selected = String(dom.facilitySetupPresetSelect.value ?? 'alpha').toLowerCase();
        modalUiState.facilityWar.setupPresetSlot = ['alpha', 'beta', 'gamma'].includes(selected) ? selected : 'alpha';
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilitySaveSetupBtn) {
      dom.facilitySaveSetupBtn.onclick = () => {
        const profile = loadProfile();
        const worldId = modalUiState.facilityWar.worldId;
        const planetId = modalUiState.facilityWar.planetId;
        const { world, planet } = getWorldPlanet(profile, worldId, planetId);
        if (!world || !planet) return;
        ensurePlanetConquestState(world, planet);
        const slot = String(modalUiState.facilityWar.setupPresetSlot ?? 'alpha').toLowerCase();
        const snapshot = snapshotDefenderSetupPreset(planet.facilityWar);
        if (!snapshot) {
          facilityLog(planet.facilityWar, 'No defender placements available to save as a setup preset.', 'bad');
          persistFacilityState(profile, worldId, planetId, planet.facilityWar);
          renderFacilityWarModal(loadProfile());
          return;
        }
        planet.facilityWar.setupPresets = normalizeFacilitySetupPresets(planet.facilityWar.setupPresets);
        planet.facilityWar.setupPresets[slot] = {
          ...snapshot,
          label: `${slot[0].toUpperCase()}${slot.slice(1)} Setup`,
        };
        facilityLog(planet.facilityWar, `Saved setup preset to ${slot}.`, 'good');
        persistFacilityState(profile, worldId, planetId, planet.facilityWar);
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityLoadSetupBtn) {
      dom.facilityLoadSetupBtn.onclick = () => {
        const profile = loadProfile();
        const worldId = modalUiState.facilityWar.worldId;
        const planetId = modalUiState.facilityWar.planetId;
        const { world, planet } = getWorldPlanet(profile, worldId, planetId);
        if (!world || !planet) return;
        ensurePlanetConquestState(world, planet);
        const slot = String(modalUiState.facilityWar.setupPresetSlot ?? 'alpha').toLowerCase();
        const preset = planet.facilityWar.setupPresets?.[slot] ?? null;
        const result = restoreDefenderSetupPreset(planet.facilityWar, preset);
        facilityLog(planet.facilityWar, result.message, result.ok ? 'good' : 'bad');
        persistFacilityState(profile, worldId, planetId, planet.facilityWar);
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityLogGroupBtn) {
      dom.facilityLogGroupBtn.onclick = () => {
        modalUiState.facilityWar.logGrouped = !modalUiState.facilityWar.logGrouped;
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityHandExpandBtn) {
      dom.facilityHandExpandBtn.onclick = () => {
        modalUiState.facilityWar.handViewMode = 'expanded';
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityHandCompactBtn) {
      dom.facilityHandCompactBtn.onclick = () => {
        modalUiState.facilityWar.handViewMode = 'compact';
        renderFacilityWarModal(loadProfile());
      };
    }
    const toggleHandSort = (mode) => {
      modalUiState.facilityWar.handSort = modalUiState.facilityWar.handSort === mode ? 'none' : mode;
      renderFacilityWarModal(loadProfile());
    };
    if (dom.facilityHandSortCostBtn) dom.facilityHandSortCostBtn.onclick = () => toggleHandSort('cost');
    if (dom.facilityHandSortTypeBtn) dom.facilityHandSortTypeBtn.onclick = () => toggleHandSort('type');
    if (dom.facilityHandSortSourceBtn) dom.facilityHandSortSourceBtn.onclick = () => toggleHandSort('source');
    if (dom.facilityHandCategoryChips) {
      dom.facilityHandCategoryChips.querySelectorAll('button[data-filter]').forEach((chip) => {
        chip.onclick = () => {
          modalUiState.facilityWar.handCategoryFilter = String(chip.dataset.filter ?? 'all').toLowerCase();
          renderFacilityWarModal(loadProfile());
        };
      });
    }
    const cycleInspect = (direction) => {
      const profile = loadProfile();
      const { world, planet } = getWorldPlanet(profile, modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
      if (!world || !planet) return;
      ensurePlanetConquestState(world, planet);
      const state = planet.facilityWar;
      const indices = getConquestInspectCandidateIndices(state);
      if (!indices.length) return;
      const current = Number.isInteger(modalUiState.facilityWar.inspectCellIndex)
        ? Number(modalUiState.facilityWar.inspectCellIndex)
        : indices[0];
      const at = Math.max(0, indices.indexOf(current));
      const step = direction < 0 ? -1 : 1;
      const nextPos = (at + step + indices.length) % indices.length;
      modalUiState.facilityWar.inspectCellIndex = indices[nextPos];
      renderFacilityWarModal(profile);
    };
    if (dom.facilityInspectPinBtn) {
      dom.facilityInspectPinBtn.onclick = () => {
        modalUiState.facilityWar.inspectPinned = !modalUiState.facilityWar.inspectPinned;
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityInspectCompareBtn) {
      dom.facilityInspectCompareBtn.onclick = () => {
        const inspectIdx = Number.isInteger(modalUiState.facilityWar.inspectCellIndex)
          ? Number(modalUiState.facilityWar.inspectCellIndex)
          : null;
        if (!Number.isInteger(inspectIdx)) return;
        modalUiState.facilityWar.compareCellIndex = modalUiState.facilityWar.compareCellIndex === inspectIdx ? null : inspectIdx;
        renderFacilityWarModal(loadProfile());
      };
    }
    if (dom.facilityInspectPrevBtn) dom.facilityInspectPrevBtn.onclick = () => cycleInspect(-1);
    if (dom.facilityInspectNextBtn) dom.facilityInspectNextBtn.onclick = () => cycleInspect(1);
    if (dom.facilityWarMatSettingsBtn) {
      dom.facilityWarMatSettingsBtn.onclick = () => {
        const profile = loadProfile();
        const { world, planet } = getWorldPlanet(profile, modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
        if (!world || !planet) return;
        ensurePlanetConquestState(world, planet);
        const settings = normalizeConquestMatSettings(planet.facilityWar?.matSettings);
        if (dom.conquestMatPresetSelect) dom.conquestMatPresetSelect.value = settings.preset;
        if (dom.conquestMatTintRange) dom.conquestMatTintRange.value = String(settings.tint);
        if (dom.conquestMatCustomUrl) dom.conquestMatCustomUrl.value = settings.customUrl;
        if (dom.conquestMatUpload) dom.conquestMatUpload.value = '';
        openModal('conquest-mat-settings-modal');
      };
    }
    if (dom.conquestMatApplyBtn) {
      dom.conquestMatApplyBtn.onclick = () => {
        const profile = loadProfile();
        const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
        if (!world || !planet) return;
        ensurePlanetConquestState(world, planet);
        const preset = String(dom.conquestMatPresetSelect?.value ?? CONQUEST_MAT_DEFAULT.preset).toLowerCase();
        const tint = clamp(Math.round(toFiniteNumber(dom.conquestMatTintRange?.value, CONQUEST_MAT_DEFAULT.tint)), 0, 70);
        const customUrl = String(dom.conquestMatCustomUrl?.value ?? '').trim();
        const applySettings = (customDataUrl = '') => {
          planet.facilityWar.matSettings = normalizeConquestMatSettings({
            preset,
            tint,
            customUrl,
            customDataUrl: customDataUrl || '',
          });
          campaign.worldStates[world.worldId] = world;
          mapWorld.campaign = campaign;
          profile.mapWorld = mapWorld;
          saveProfile(profile);
          renderFacilityWarModal(loadProfile());
          closeModal('conquest-mat-settings-modal');
        };
        const file = dom.conquestMatUpload?.files?.[0] ?? null;
        if (file) {
          const reader = new FileReader();
          reader.onload = () => applySettings(String(reader.result ?? ''));
          reader.onerror = () => applySettings('');
          reader.readAsDataURL(file);
          return;
        }
        applySettings('');
      };
    }
    if (dom.conquestMatResetBtn) {
      dom.conquestMatResetBtn.onclick = () => {
        const profile = loadProfile();
        const { mapWorld, campaign, world, planet } = getWorldPlanet(profile, modalUiState.facilityWar.worldId, modalUiState.facilityWar.planetId);
        if (!world || !planet) return;
        ensurePlanetConquestState(world, planet);
        planet.facilityWar.matSettings = normalizeConquestMatSettings(null);
        campaign.worldStates[world.worldId] = world;
        mapWorld.campaign = campaign;
        profile.mapWorld = mapWorld;
        saveProfile(profile);
        renderFacilityWarModal(loadProfile());
        closeModal('conquest-mat-settings-modal');
      };
    }
    if (dom.conquestDeckEditorSaveBtn) {
      dom.conquestDeckEditorSaveBtn.onclick = () => saveConquestDeckEditor();
    }
    if (dom.conquestCardCreateBtn) {
      dom.conquestCardCreateBtn.onclick = () => createConquestCardFromForm();
    }
    mapModalsBound = true;
  }

  const activeProfile = loadProfile();
  const mapWorld = getMapWorld(activeProfile);
  dom.mapNodeSearch.value = mapWorld.mapFilters.search ?? '';
  dom.mapStatusFilter.value = mapWorld.mapFilters.status ?? 'all';
  dom.mapStyleFilter.value = mapWorld.mapFilters.style ?? 'all';
  dom.mapStyleSelect.value = mapWorld.globalMapStyleId ?? (cachedMapStyles[0]?.id ?? 'astral-cartographer');
}

function addDialogLine(role, text) {
  const row = document.createElement('div');
  row.className = `dialog-row ${role}`;
  row.textContent = `${role === 'ai' ? 'AI' : 'You'}: ${text}`;
  dom.dialogLog.prepend(row);
}

function buildDialogueChoices(ai, profileState) {
  const status = mapStatus(profileState, ai);
  const codeUnlocked = !!(profileState.carnexCodes ?? {})[ai.id];
  return [
    {
      label: 'Challenge',
      action: () => {
        addDialogLine('you', 'I challenge your dimension.');
        addDialogLine('ai', status.unlocked ? aiLine(ai, 'pre_match', 'Then sharpen your deck and step into the rift.') : `You are not ready. Win ${status.gate} matches first.`);
        if (status.unlocked) startCinematic('Novice', ai);
      },
    },
    {
      label: 'Ask Strategy',
      action: () => {
        addDialogLine('you', 'How do you usually win?');
        addDialogLine('ai', `${ai.deckIdentity ?? ai.archetype ?? 'Adaptive control line.'} ${aiLine(ai, 'mulligan', 'I prioritize stable opening lines.')}`);
      },
    },
    {
      label: 'Ask Formation',
      action: () => {
        addDialogLine('you', 'What formation do you prefer?');
        const bias = Object.entries(ai.formationBias ?? {}).sort((a, b) => Number(b[1]) - Number(a[1]))[0];
        const note = (ai.behaviorNotes ?? [])[0] ?? 'I adjust by board pressure.';
        addDialogLine('ai', `${bias ? `Usually ${bias[0]}.` : 'Formation shifts per matchup.'} ${note}`);
      },
    },
    {
      label: 'Ask Deck',
      action: () => {
        addDialogLine('you', 'Describe your deck.');
        const deckMeta = cachedDecks.find((deck) => deck.id === ai.deckId);
        addDialogLine('ai', deckMeta ? `${deckMeta.name}: ${deckMeta.aiNotes}` : (ai.deckIdentity ?? 'Deck configured for this dimension.'));
      },
    },
    {
      label: 'Ask Lore',
      action: () => {
        addDialogLine('you', 'Tell me about your world.');
        addDialogLine('ai', ai.personality?.backstory ?? `${ai.name}'s world remains undocumented.`);
      },
    },
    {
      label: 'Ask Carnex Code',
      action: () => {
        addDialogLine('you', 'Give me your Carnex dimensional code.');
        if (codeUnlocked) {
          addDialogLine('ai', `Code verified: ${(profileState.carnexCodes ?? {})[ai.id]}. You may hunt this dimension's creatures.`);
        } else {
          addDialogLine('ai', 'Defeat me first. The code is earned, never gifted.');
        }
      },
    },
    {
      label: 'Capture Rights',
      action: () => {
        addDialogLine('you', 'Authorize creature capture rights.');
        if (status.defeated) addDialogLine('ai', aiLine(ai, 'post_defeat_lobby', 'Rights granted. Survive the reaction trial and the creatures are yours.'));
        else addDialogLine('ai', 'No rights. Win the battle for this dimension first.');
      },
    },
    {
      label: 'Talk',
      action: () => {
        addDialogLine('you', 'Any advice before we duel again?');
        addDialogLine('ai', aiLine(ai, 'lobby_greeting', `${ai.name}: Keep your board spacing clean.`));
      },
    },
    {
      label: 'Leave',
      action: () => {
        addDialogLine('you', 'We are done for now.');
        addDialogLine('ai', aiLine(ai, 'post_defeat_lobby', 'Then we speak again across the next rift.'));
      },
    },
  ];
}

function openDialogue(ai) {
  if (!ai) return;
  showTab('world');
  activeDialogAi = ai;
  const profileState = loadProfile();
  const status = mapStatus(profileState, ai);
  const intro = status.defeated
    ? aiLine(ai, 'post_defeat_lobby', `${ai.name} is available in the lobby.`)
    : aiLine(ai, 'lobby_greeting', `${ai.name}, ${ai.personality?.title ?? 'Dimensional Warden'} of ${ai.personality?.dimensionTag ?? '#Unknown'}.`);
  addDialogLine('ai', intro);

  dom.dialogChoices.innerHTML = '';
  const choices = buildDialogueChoices(ai, profileState);
  choices.forEach((choice) => {
    const button = document.createElement('button');
    button.textContent = choice.label;
    button.onclick = () => choice.action();
    dom.dialogChoices.appendChild(button);
  });
}

function pickLoadingTipForAi(aiProfile) {
  const pool = cachedLoadingTips.length ? cachedLoadingTips : (LOCAL_DATA.loadingTips ?? []);
  if (!pool.length) return null;
  const faction = (aiProfile?.id ?? '').split('-')[0];
  const focused = pool.filter((entry) => (entry.faction ?? 'neutral') === faction);
  return pickRandom(focused.length ? focused : pool, `${Date.now()}-${aiProfile?.id ?? 'unknown'}`);
}

function isConquestEncounterContext(context = {}) {
  const routeTarget = String(context?.routeTarget ?? '').toLowerCase();
  const threatType = String(context?.metadata?.threatType ?? '').toLowerCase();
  const battleType = String(context?.battleType ?? '').toLowerCase();
  const rulesetId = String(context?.rulesetId ?? '').toLowerCase();
  return routeTarget === 'facility_war'
    || !!context?.forceConquestScene
    || !!context?.objectiveId
    || battleType === 'defense_conquest'
    || battleType === 'facility_war'
    || battleType === 'conquest'
    || rulesetId === 'planetary-defense'
    || rulesetId === 'massive-invasion'
    || rulesetId.includes('conquest')
    || rulesetId.includes('invasion')
    || rulesetId.includes('defense')
    || threatType === 'alien'
    || threatType === 'pirate';
}

function conquestEncounterId(context = {}) {
  const threatType = String(context?.metadata?.threatType ?? (context.objectiveId ? 'objective' : 'conquest')).toLowerCase();
  const anchor = String(context.threatId ?? context.objectiveId ?? context.worldId ?? context.sourceNodeId ?? Date.now());
  return `${threatType}:${anchor}`;
}

function resolveConquestLaunchTarget(context = {}) {
  const profile = loadProfile();
  const mapWorld = getMapWorld(profile);
  const campaign = mapWorld.campaign ?? structuredClone(CAMPAIGN_DEFAULTS);
  const attackers = getDimensionalAttackers(mapWorld);
  const worldHints = [
    String(context.worldId ?? '').trim(),
    String(context.sourceNodeId ?? '').trim(),
    String(context.metadata?.worldId ?? '').trim(),
    String(context.metadata?.targetNodeId ?? '').trim(),
  ].filter(Boolean);
  let world = null;
  for (const hint of worldHints) {
    world = campaign.worldStates?.[hint] ?? null;
    if (world) break;
  }
  const activeThreat = context.threatId
    ? (campaign.activeThreats ?? []).find((entry) => entry?.id === context.threatId && !entry.resolved)
    : null;
  if (!world && activeThreat) {
    const threatWorldId = String(activeThreat.targetNodeId ?? activeThreat.currentNodeId ?? activeThreat.nodeId ?? '').trim();
    if (threatWorldId) world = campaign.worldStates?.[threatWorldId] ?? null;
  }
  if (!world) world = preferredWorldOpsWorld(profile, attackers);
  if (!world) return null;

  const preferredPlanetId = String(
    context.planetId
    ?? context.targetPlanetId
    ?? context.metadata?.targetPlanetId
    ?? activeThreat?.targetPlanetId
    ?? '',
  ).trim();
  let planet = (world.planets ?? []).find((entry) => entry.id === preferredPlanetId) ?? null;
  if (!planet) {
    planet = chooseInvasionPlanetForWorld(world, preferredPlanetId) ?? null;
  }
  if (!planet) return null;
  ensurePlanetConquestState(world, planet);

  const encounterId = conquestEncounterId(context);
  const currentEncounterId = String(planet.facilityWar?.encounter?.encounterId ?? '');
  const forceReset = !!context.forceReset || (encounterId && currentEncounterId && encounterId !== currentEncounterId);
  if (!planet.facilityWar || forceReset) {
    planet.facilityWar = createFacilityWarState(world.worldId, planet.id, planet.conquestDecks);
  }
  const encounterThreatType = String(context?.metadata?.threatType ?? (context.objectiveId ? 'objective' : 'conquest')).toLowerCase();
  const derivedTriangles = context?.deckTriangles
    ?? context?.metadata?.deckTriangles
    ?? activeThreat?.deckTriangles
    ?? conquestTrianglesFromDeckSize(context?.deckSize ?? context?.threatDeckSize ?? activeThreat?.deckSizeEstimate ?? 30);
  const derivedDeckSize = conquestDeckSizeFromTriangles(derivedTriangles);
  const derivedFaction = normalizeConquestInvasionFactionId(
    context?.metadata?.factionId
    ?? context?.factionId
    ?? activeThreat?.factionId
    ?? world?.factionId
    ?? (encounterThreatType === 'pirate' ? 'iron-carrion-mandate' : 'iron-carrion-mandate'),
  );
  const deckPackage = buildEncounterAttackerDeck(profile, {
    ...context,
    metadata: { ...(context?.metadata ?? {}), threatType: encounterThreatType, factionId: derivedFaction, deckTriangles: derivedTriangles },
  }, activeThreat);
  applyEncounterAttackerDeck(planet.facilityWar, deckPackage);
  if (deckPackage?.meta) {
    facilityLog(
      planet.facilityWar,
      `[Enemy Deck] ${deckPackage.meta.factionId} • ${deckPackage.meta.doctrine} • ${deckPackage.meta.variant} • ${deckPackage.meta.deckSize} cards (${deckPackage.meta.triangles}△)`,
      'info',
    );
  }
  planet.facilityWar.encounter = {
    encounterId,
    threatType: encounterThreatType,
    threatId: context.threatId ?? null,
    objectiveId: context.objectiveId ?? null,
    sourceNodeId: context.sourceNodeId ?? null,
    worldId: world.worldId,
    planetId: planet.id,
    factionId: derivedFaction,
    deckTriangles: clamp(Math.round(toFiniteNumber(derivedTriangles, 3)), 1, 6),
    deckSizeEstimate: derivedDeckSize,
    deckVariant: deckPackage?.meta?.variant ?? conquestDeckVariantForStars(context?.aiSkillStars ?? activeThreat?.aiSkillStars ?? 2),
    deckSeries: deckPackage?.meta?.deckName ?? conquestDeckSeriesName(derivedFaction, derivedTriangles, deckPackage?.meta?.variant ?? conquestDeckVariantForStars(context?.aiSkillStars ?? activeThreat?.aiSkillStars ?? 2)),
    aiName: context.aiName ?? null,
    aiSkillStars: context.aiSkillStars ?? activeThreat?.aiSkillStars ?? deckPackage?.meta?.stars ?? null,
    techLevel: context.techLevel ?? null,
    attackerDeckMeta: deckPackage?.meta ?? null,
    openedAt: Date.now(),
  };
  const requestedPlayerSide = String(context?.metadata?.playerSide ?? context?.playerSide ?? '').toLowerCase();
  const inferredPlayerSide = requestedPlayerSide === 'attacker' || requestedPlayerSide === 'defender'
    ? requestedPlayerSide
    : 'defender';
  planet.facilityWar.playerSide = inferredPlayerSide;
  planet.facilityWar.aiControl = {
    attacker: inferredPlayerSide !== 'attacker',
    defender: inferredPlayerSide !== 'defender',
  };
  if (!Array.isArray(planet.facilityWar.defender?.hand) || !planet.facilityWar.defender.hand.length) {
    planet.facilityWar.defender.hand = buildFacilitySetupHand(profile);
  }
  planet.facilityWar.winner = null;
  planet.facilityWar.outcomeAppliedAt = 0;
  campaign.worldStates[world.worldId] = world;
  mapWorld.campaign = campaign;
  profile.mapWorld = mapWorld;
  saveProfile(profile);
  return { worldId: world.worldId, planetId: planet.id };
}

function startCinematic(playerName, aiProfile, context = {}) {
  if (!aiProfile || !aiProfile.id) {
    console.error('startCinematic called without a valid AI profile.', aiProfile);
    return;
  }
  withProfile((profile) => {
    const mapWorld = getMapWorld(profile);
    const attackers = getDimensionalAttackers(mapWorld);
    recordBattleTrace(attackers, aiProfile?.level ?? 1);
    mapWorld.customAiProfiles = Array.isArray(mapWorld.customAiProfiles) ? mapWorld.customAiProfiles : [];
    if (aiProfile?.id) {
      const idx = mapWorld.customAiProfiles.findIndex((entry) => entry.id === aiProfile.id);
      if (idx >= 0) mapWorld.customAiProfiles[idx] = { ...mapWorld.customAiProfiles[idx], ...aiProfile };
      else mapWorld.customAiProfiles.push({ ...aiProfile });
    }
    mapWorld.dimensionalAttackers = attackers;
    profile.mapWorld = mapWorld;
  });
  const conquestRoute = isConquestEncounterContext(context);
  if (conquestRoute) {
    localStorage.removeItem(MATCH_KEY);
    localStorage.removeItem(MATCH_CONTEXT_KEY);
  } else {
    localStorage.setItem(MATCH_KEY, aiProfile.id);
    localStorage.setItem(MATCH_CONTEXT_KEY, JSON.stringify(battleContextPayload(aiProfile, context)));
  }
  dom.cinematicPlayer.textContent = playerName;
  dom.cinematicOpponent.textContent = aiProfile.name;
  const tip = pickLoadingTipForAi(aiProfile);
  if (dom.cinematicFlavor) dom.cinematicFlavor.textContent = aiProfile?.personality?.loadingFlavor ?? '';
  if (dom.cinematicTip) {
    dom.cinematicTip.textContent = tip
      ? `${tip.title}: ${tip.gameplayTip}`
      : 'Tip: Formation and spacing win more games than raw stats.';
  }
  dom.cinematic.classList.remove('fade');
  dom.cinematic.classList.remove('hidden');
  dom.cinematic.classList.remove('charged');
  setTimeout(() => dom.cinematic.classList.add('fade'), 240);
  setTimeout(() => dom.cinematic.classList.add('charged'), 1200);
  let launched = false;
  const launchBattle = () => {
    if (launched) return;
    launched = true;
    if (conquestRoute) {
      const target = resolveConquestLaunchTarget({
        ...context,
        aiName: aiProfile.name,
      });
      dom.cinematic.classList.add('hidden');
      dom.cinematic.classList.remove('fade');
      if (target) {
        openFacilityWarModal(target.worldId, target.planetId);
        return;
      }
    }
    window.location.assign('./game/index.html');
  };
  setTimeout(launchBattle, 3900);
  // Fallback in case a UI exception interrupts the first timer path.
  setTimeout(launchBattle, 4800);
}

async function renderMatchTab(profiles) {
  const host = dom.matchTab;
  const profileState = loadProfile();
  const mergedProfiles = allAiProfiles(profiles, profileState);
  host.innerHTML = '<h3>Select Opponent Dimension</h3>';
  const list = document.createElement('div');
  list.id = 'deck-list';

  mergedProfiles.forEach((ai) => {
    const status = mapStatus(profileState, ai);
    const deckMeta = cachedDecks.find((deck) => deck.id === ai.deckId);
    const row = document.createElement('article');
    const statusLabel = status.defeated ? 'Defeated (in lobby)' : status.unlocked ? 'Unlocked' : `Locked: win ${status.gate} total matches`;
    row.innerHTML = `
      <strong>${ai.name}</strong> — Lvl ${ai.level ?? 1}
      <div>${ai.personality?.title ?? 'Unknown'} ${ai.personality?.dimensionTag ?? '#Unknown'}</div>
      <small>${ai.personality?.backstory ?? ''}</small>
      <div><strong>Deck:</strong> ${deckMeta?.name ?? ai.deckId ?? 'native'} • ${ai.archetype ?? ai.strategy ?? 'unknown'}</div>
      <div><strong>Status:</strong> ${statusLabel}</div>
    `;

    const matchButton = document.createElement('button');
    matchButton.textContent = 'Matchmake';
    matchButton.disabled = !status.unlocked;
    matchButton.onclick = () => startCinematic('Novice', ai);

    const talkButton = document.createElement('button');
    talkButton.textContent = 'Talk';
    talkButton.onclick = () => openDialogue(ai);

    row.appendChild(matchButton);
    row.appendChild(talkButton);
    list.appendChild(row);
  });

  host.appendChild(list);
  renderBattleMap(mergedProfiles, profileState);
}

async function loadAllQuestEntries() {
  if (LOCAL_MODE) return Array.isArray(LOCAL_DATA.quests?.quests) ? LOCAL_DATA.quests.quests : [];
  try {
    const idx = await loadJson('./game/quest_packs/index.json', { entries: ['daily.json'] });
    const all = [];
    for (const entry of idx.entries ?? []) {
      const pack = await loadJson(`./game/quest_packs/${entry}`, null);
      if (Array.isArray(pack?.quests)) all.push(...pack.quests);
    }
    return all;
  } catch {
    const qp = await loadJson('./game/quest_packs/daily.json', LOCAL_DATA.quests);
    return qp.quests || [];
  }
}

async function renderQuestTab() {
  const host = dom.questsTab;
  const profile = loadProfile();
  const quests = await loadAllQuestEntries();
  host.innerHTML = '<h3>Quest Board</h3>';

  if (!quests.length) {
    host.innerHTML += '<article>No quests available.</article>';
    return;
  }

  quests.forEach((q) => {
    const current = profile.questProgress?.[q.metric] ?? 0;
    const done = current >= q.target;
    const claimed = !!(profile.questClaims || {})[q.id];
    const row = document.createElement('article');
    row.innerHTML = `<strong>${q.goal}</strong><div>${current}/${q.target} • Reward ${q.reward}g</div>`;

    const button = document.createElement('button');
    button.textContent = claimed ? 'Claimed' : 'Claim';
    button.disabled = claimed || !done;
    button.onclick = () => {
      profile.questClaims = profile.questClaims || {};
      profile.economy = profile.economy || { gold: 0, lifeforce: 0 };
      profile.questClaims[q.id] = true;
      profile.economy.gold = (profile.economy.gold || 0) + q.reward;
      saveProfile(profile);
      renderQuestTab();
      renderShopTab();
    };

    row.appendChild(button);
    host.appendChild(row);
  });
}

function formatPercent(numerator = 0, denominator = 0) {
  if (!denominator) return '0.0%';
  return `${((numerator / denominator) * 100).toFixed(1)}%`;
}

function renderQuickStats() {
  if (!dom.profileQuickStats) return;
  const profile = loadProfile();
  const stats = profile.stats ?? mergeProfileStats();
  const battles = Math.max(0, Number(stats.battlesPlayed ?? 0));
  const wins = Math.max(0, Number(stats.wins ?? 0));
  const losses = Math.max(0, Number(stats.losses ?? 0));
  const winRate = formatPercent(wins, Math.max(1, wins + losses));
  const packsOpened = Math.max(0, Number(stats.packsOpened ?? 0));
  const uniqueCards = Math.max(0, Number(stats.collectionProgress?.uniqueOwned ?? 0));
  dom.profileQuickStats.innerHTML = `
    <strong>Profile</strong>
    <span>Matches ${battles}</span>
    <span>W/L ${wins}-${losses} (${winRate})</span>
    <span>Packs ${packsOpened}</span>
    <span>Unique ${uniqueCards}</span>
  `;
}

async function renderStatsTab() {
  if (!dom.statsTab) return;
  const profile = loadProfile();
  const stats = profile.stats ?? mergeProfileStats();
  const battles = Math.max(0, Number(stats.battlesPlayed ?? 0));
  const wins = Math.max(0, Number(stats.wins ?? 0));
  const losses = Math.max(0, Number(stats.losses ?? 0));
  const winRate = formatPercent(wins, Math.max(1, wins + losses));
  const duel = stats.modes?.duel ?? { wins: 0, losses: 0, battles: 0 };
  const defense = stats.modes?.defense ?? { wins: 0, losses: 0, battles: 0 };
  const pirate = stats.threats?.pirate ?? { wins: 0, losses: 0, battles: 0 };
  const alien = stats.threats?.alien ?? { wins: 0, losses: 0, battles: 0 };
  const boss = stats.threats?.boss ?? { wins: 0, losses: 0, battles: 0 };
  const wielder = stats.threats?.wielder ?? { wins: 0, losses: 0, battles: 0 };
  const packs = stats.packs ?? mergeProfileStats().packs;
  const byPackEntries = Object.entries(packs.byPack ?? {}).sort((a, b) => Number(b[1]) - Number(a[1]));
  const factionEntries = Object.entries(stats.factionsFought ?? {})
    .map(([factionId, bucket]) => {
      const battlesForFaction = Math.max(0, Number(bucket?.battles ?? 0));
      const winsForFaction = Math.max(0, Number(bucket?.wins ?? 0));
      const lossesForFaction = Math.max(0, Number(bucket?.losses ?? 0));
      return { factionId, battles: battlesForFaction, wins: winsForFaction, losses: lossesForFaction };
    })
    .filter((bucket) => bucket.battles > 0)
    .sort((a, b) => b.battles - a.battles || b.wins - a.wins);
  const recent = Array.isArray(stats.battleHistory) ? [...stats.battleHistory].reverse().slice(0, 16) : [];

  dom.statsTab.innerHTML = `
    <h3>Profile Stats</h3>
    <article class="panel-sub">
      <div class="map-inspect-grid">
        <div><strong>Total Battles</strong><br/>${battles}</div>
        <div><strong>Total Wins</strong><br/>${wins}</div>
        <div><strong>Total Defeats</strong><br/>${losses}</div>
        <div><strong>Win Rate</strong><br/>${winRate}</div>
        <div><strong>Current Streak</strong><br/>${Math.max(0, Number(stats.streak ?? 0))}</div>
        <div><strong>Best Streak</strong><br/>${Math.max(0, Number(stats.bestStreak ?? 0))}</div>
      </div>
    </article>
    <article class="panel-sub">
      <h4>Modes</h4>
      <div class="map-inspect-grid">
        <div><strong>Duel</strong><br/>${duel.wins ?? 0}W / ${duel.losses ?? 0}L (${duel.battles ?? 0})</div>
        <div><strong>Defense</strong><br/>${defense.wins ?? 0}W / ${defense.losses ?? 0}L (${defense.battles ?? 0})</div>
      </div>
      <h4>Threat Types</h4>
      <div class="map-inspect-grid">
        <div><strong>Pirate</strong><br/>${pirate.wins ?? 0}W / ${pirate.losses ?? 0}L (${pirate.battles ?? 0})</div>
        <div><strong>Alien</strong><br/>${alien.wins ?? 0}W / ${alien.losses ?? 0}L (${alien.battles ?? 0})</div>
        <div><strong>Boss</strong><br/>${boss.wins ?? 0}W / ${boss.losses ?? 0}L (${boss.battles ?? 0})</div>
        <div><strong>Wielder</strong><br/>${wielder.wins ?? 0}W / ${wielder.losses ?? 0}L (${wielder.battles ?? 0})</div>
        <div><strong>Bosses Defeated</strong><br/>${Math.max(0, Number(stats.bossesDefeated ?? 0))}</div>
        <div><strong>Wielders Defeated</strong><br/>${Math.max(0, Number(stats.namedWieldersDefeated ?? 0))}</div>
      </div>
      <h4>Faction Encounters</h4>
      <div class="scroll-list">${factionEntries.length
        ? factionEntries.slice(0, 12).map((bucket) => `<div>${bucket.factionId}: ${bucket.wins}W/${bucket.losses}L (${bucket.battles})</div>`).join('')
        : '<div>No faction encounter data yet.</div>'}</div>
    </article>
    <article class="panel-sub">
      <h4>Campaign</h4>
      <div class="map-inspect-grid">
        <div><strong>Worlds Conquered</strong><br/>${stats.worlds?.conquered ?? 0}</div>
        <div><strong>Worlds Lost</strong><br/>${stats.worlds?.lost ?? 0}</div>
        <div><strong>Planets Conquered</strong><br/>${stats.planets?.conquered ?? 0}</div>
        <div><strong>Planets Lost</strong><br/>${stats.planets?.lost ?? 0}</div>
        <div><strong>Invasions Intercepted</strong><br/>${stats.invasions?.intercepted ?? 0}</div>
        <div><strong>Pirates Escaped</strong><br/>${stats.invasions?.piratesEscaped ?? 0}</div>
      </div>
    </article>
    <article class="panel-sub">
      <h4>Packs & Collection</h4>
      <div class="map-inspect-grid">
        <div><strong>Packs Opened</strong><br/>${stats.packsOpened ?? 0}</div>
        <div><strong>Legendary Pulls</strong><br/>${packs.legendaryPulls ?? 0}</div>
        <div><strong>Total Copies</strong><br/>${stats.collectionProgress?.totalCopiesOwned ?? 0}</div>
        <div><strong>Unique Cards</strong><br/>${stats.collectionProgress?.uniqueOwned ?? 0}</div>
      </div>
      <div style="margin-top:0.5rem;">
        <strong>Pack Openings by Product</strong>
        <div class="scroll-list">${byPackEntries.length ? byPackEntries.map(([packId, count]) => `<div>${packId}: ${count}</div>`).join('') : '<div>No packs opened yet.</div>'}</div>
      </div>
    </article>
    <article class="panel-sub">
      <h4>Recent Battles</h4>
      <div class="scroll-list">${recent.length ? recent.map((entry) => {
        const ts = entry.ts ? new Date(entry.ts).toLocaleString() : 'Unknown time';
        const result = entry.result === 'win' ? 'WIN' : 'LOSS';
        const mode = entry.mode ?? 'unknown';
        const threat = entry.threatType ?? 'none';
        const opponent = entry.opponentName ?? entry.opponentId ?? 'Unknown';
        return `<div>[${result}] ${opponent} • ${mode} • ${threat} • ${ts}</div>`;
      }).join('') : '<div>No battle history recorded yet.</div>'}</div>
    </article>
  `;
}

async function renderDeckTab() {
  if (typeof window.renderDeckTabOverhaul === 'function') {
    return window.renderDeckTabOverhaul({
      host: dom.deckTab,
      loadProfile,
      saveProfile,
      loadJson,
      localCardexFallback: LOCAL_DATA.cardex,
      getCachedDecks: () => cachedDecks,
    });
  }
  const host = dom.deckTab;
  const profile = loadProfile();
  const cards = (await loadJson('./cardex.json', LOCAL_DATA.cardex)).cards;
  const allDecks = [...cachedDecks, ...(profile.customDecks || [])];

  host.innerHTML = '<h3>Deck Builder + Simulator</h3>';
  if (!allDecks.length) {
    host.innerHTML += '<div>No decks available.</div>';
    return;
  }
  const select = document.createElement('select');
  allDecks.forEach((deck) => {
    const option = document.createElement('option');
    option.value = deck.id;
    option.textContent = `${deck.name} (${deck.entries.reduce((sum, entry) => sum + entry.count, 0)}/30)`;
    option.selected = deck.id === profile.starterDeckId;
    select.appendChild(option);
  });
  host.appendChild(select);

  const setButton = document.createElement('button');
  setButton.textContent = 'Set as Simulation Deck';
  setButton.onclick = () => {
    profile.starterDeckId = select.value;
    saveProfile(profile);
  };
  host.appendChild(setButton);

  const cloneButton = document.createElement('button');
  cloneButton.textContent = 'Save Copy to Custom Decks';
  cloneButton.onclick = () => {
    const chosen = allDecks.find((deck) => deck.id === select.value);
    if (!chosen) return;
    const cloned = { ...chosen, id: `${chosen.id}-custom-${Date.now()}`, name: `${chosen.name} (Custom)` };
    profile.customDecks = [...(profile.customDecks || []), cloned];
    saveProfile(profile);
    renderDeckTab();
  };
  host.appendChild(cloneButton);

  const list = document.createElement('div');
  list.id = 'deck-list';
  const renderSelectedDeck = () => {
    list.innerHTML = '';
    const selectedDeck = allDecks.find((deck) => deck.id === select.value) || allDecks[0];
    (selectedDeck?.entries || []).forEach((entry) => {
      const card = cards.find((c) => c.id === entry.cardId);
      const row = document.createElement('article');
      row.textContent = `${entry.count}x ${card?.name || entry.cardId}`;
      list.appendChild(row);
    });
    if (selectedDeck?.archetype || selectedDeck?.aiNotes) {
      const meta = document.createElement('article');
      meta.innerHTML = `<strong>Deck Notes</strong><div>${selectedDeck.archetype ?? ''}</div><small>${selectedDeck.aiNotes ?? ''}</small>`;
      list.appendChild(meta);
    }
  };
  select.onchange = renderSelectedDeck;
  renderSelectedDeck();
  host.appendChild(list);
}

function mergeLauncherCardCatalog(cardexCards = []) {
  const mergedById = new Map();
  (cardexCards ?? []).forEach((card) => {
    if (card?.id) mergedById.set(card.id, { ...card });
  });
  Object.values(cachedPackCardsById ?? {}).flat().forEach((card) => {
    if (card?.id) mergedById.set(card.id, { ...card });
  });
  return [...mergedById.values()];
}

async function loadLauncherCardCatalog() {
  const payload = await loadJson('./cardex.json', LOCAL_DATA.cardex);
  return mergeLauncherCardCatalog([
    ...(payload?.cards ?? []),
    ...loadCreatorCustomCards(),
  ]);
}

function currentMarketNodes() {
  const base = mapView.baseNodes?.length ? mapView.baseNodes : mapView.nodes;
  return Array.isArray(base) ? base.filter((node) => node && node.id) : [];
}

function countDeckCommittedCopies(profile = loadProfile()) {
  const usage = {};
  const decks = [...(profile.customDecks ?? []), ...(Array.isArray(cachedDecks) ? cachedDecks : [])];
  decks.forEach((deck) => {
    (deck?.entries ?? []).forEach((entry) => {
      if (!entry?.cardId) return;
      usage[entry.cardId] = Math.max(0, Number(usage[entry.cardId] ?? 0)) + Math.max(0, Number(entry.count ?? 0));
    });
  });
  const starterDeckIds = [profile.starterDeckId, profile.starterDefenseDeckId].filter(Boolean);
  starterDeckIds.forEach((deckId) => {
    const deck = decks.find((entry) => entry?.id === deckId);
    if (!deck) return;
    (deck.entries ?? []).forEach((entry) => {
      if (!entry?.cardId) return;
      usage[entry.cardId] = Math.max(0, Number(usage[entry.cardId] ?? 0)) + Math.max(0, Number(entry.count ?? 0));
    });
  });
  return usage;
}

function ensureMarketState(profile, cards = [], now = Date.now()) {
  if (!window.CardForgeMarket) return null;
  return window.CardForgeMarket.tickMarket(profile, currentMarketNodes(), cards, now);
}

function marketTraderList(marketState) {
  return [
    ...(marketState?.activeTraders ?? []),
    ...(marketState?.tradeShips ?? []),
  ].filter((trader) => trader && trader.visible !== false);
}

function findMarketTrader(marketState, traderId) {
  return marketTraderList(marketState).find((trader) => trader.id === traderId) ?? null;
}

function relationChip(factionId, marketState) {
  const score = Number(marketState?.relations?.[factionId] ?? 0);
  const meta = window.CardForgeMarket?.getRelationMeta(score);
  return {
    score,
    label: meta?.label ?? 'Neutral',
    className: `relation-${meta?.key ?? 'neutral'}`,
  };
}

function traderCollectionValue(profile, cardById) {
  const collection = profile.collection ?? {};
  return Object.entries(collection).reduce((sum, [cardId, count]) => {
    const card = cardById[cardId];
    if (!card) return sum;
    return sum + ((window.CardForgeMarket?.computeCardBaseValue(card).baseValue ?? 0) * Math.max(0, Number(count ?? 0)));
  }, 0);
}

function buildTradeInventory(profile, cardById, selectedTrader, marketState) {
  const favorites = new Set(profile.favoriteCards ?? []);
  const committed = countDeckCommittedCopies(profile);
  const collection = profile.collection ?? {};
  const rows = Object.entries(collection).map(([cardId, owned]) => {
    const card = cardById[cardId];
    if (!card || owned <= 0) return null;
    const favoriteProtected = favorites.has(cardId);
    const committedCopies = Math.max(0, Number(committed[cardId] ?? 0));
    const protectedCount = (marketUiState.excludeFavorites && favoriteProtected ? owned : 0) + (marketUiState.excludeDecked ? committedCopies : 0);
    const freeCount = Math.max(0, Number(owned ?? 0) - protectedCount);
    const price = selectedTrader && window.CardForgeMarket
      ? window.CardForgeMarket.computeMarketPrice(card, marketState, selectedTrader)
      : { sellValue: 0, tradeValue: 0, buyValue: 0, baseValue: 0 };
    return {
      card,
      owned: Math.max(0, Number(owned ?? 0)),
      favoriteProtected,
      committedCopies,
      protectedCount: Math.min(Math.max(0, Number(owned ?? 0)), protectedCount),
      freeCount,
      price,
    };
  }).filter(Boolean);
  const query = marketUiState.inventoryQuery.trim().toLowerCase();
  const filtered = rows.filter((row) => {
    if (marketUiState.duplicatesOnly && row.owned < 2) return false;
    if (query && !`${row.card.name} ${row.card.type} ${(row.card.tags ?? []).join(' ')}`.toLowerCase().includes(query)) return false;
    return true;
  });
  return filtered.sort((a, b) => b.price.sellValue - a.price.sellValue || a.card.name.localeCompare(b.card.name));
}

function resolveMarketSelection(traders = []) {
  if (!traders.length) {
    marketUiState.selectedTraderId = null;
    return null;
  }
  if (!marketUiState.selectedTraderId || !traders.some((entry) => entry.id === marketUiState.selectedTraderId)) {
    marketUiState.selectedTraderId = traders[0].id;
  }
  return traders.find((entry) => entry.id === marketUiState.selectedTraderId) ?? traders[0];
}

function currentOfferEntries(offerMap) {
  return Object.entries(offerMap ?? {})
    .filter(([, count]) => Number(count) > 0)
    .map(([cardId, count]) => ({ cardId, count: Math.max(0, Number(count ?? 0)) }));
}

function setOfferCount(target, cardId, nextCount) {
  const safe = Math.max(0, Number(nextCount ?? 0));
  if (safe <= 0) delete target[cardId];
  else target[cardId] = safe;
}

function resetMarketOffers() {
  marketUiState.playerOffer = {};
  marketUiState.traderOffer = {};
}

function adjustPlayerOffer(cardId, delta, inventoryRows) {
  const row = inventoryRows.find((entry) => entry.card.id === cardId);
  if (!row) return;
  const current = Math.max(0, Number(marketUiState.playerOffer[cardId] ?? 0));
  const maxFree = row.freeCount;
  setOfferCount(marketUiState.playerOffer, cardId, Math.min(maxFree, current + delta));
}

function adjustTraderOffer(cardId, delta, trader) {
  const stock = (trader?.stock ?? []).find((entry) => entry.cardId === cardId);
  if (!stock) return;
  const current = Math.max(0, Number(marketUiState.traderOffer[cardId] ?? 0));
  setOfferCount(marketUiState.traderOffer, cardId, Math.min(Math.max(0, Number(stock.copies ?? 0)), current + delta));
}

function marketActionMode() {
  const playerCount = currentOfferEntries(marketUiState.playerOffer).length;
  const traderCount = currentOfferEntries(marketUiState.traderOffer).length;
  if (playerCount && traderCount) return 'barter';
  if (traderCount) return 'buy';
  if (playerCount) return 'sell';
  return 'idle';
}

function marketLedgerEntry(mode, trader, totals, fairness) {
  return {
    id: `trade-${Date.now()}`,
    at: Date.now(),
    mode,
    traderId: trader?.id ?? null,
    traderName: trader?.name ?? 'Unknown Trader',
    factionId: trader?.factionId ?? null,
    totals,
    fairness,
  };
}

function marketBestEqualizer(inventoryRows, cardById, trader, marketState) {
  const playerEntries = currentOfferEntries(marketUiState.playerOffer);
  const traderEntries = currentOfferEntries(marketUiState.traderOffer);
  const fairness = window.CardForgeMarket.evaluateTradeOffer(playerEntries, traderEntries, trader, marketState, cardById);
  if (Math.abs(fairness.deltaValue) <= 10) return null;
  if (fairness.deltaValue < 0) {
    return inventoryRows.find((row) => row.freeCount > 0 && row.price.sellValue <= Math.abs(fairness.deltaValue) + 30) ?? inventoryRows[0] ?? null;
  }
  return (trader?.stock ?? [])
    .map((entry) => ({ stock: entry, card: cardById[entry.cardId] }))
    .filter((entry) => entry.card && entry.stock.copies > 0)
    .sort((a, b) => {
      const av = window.CardForgeMarket.computeMarketPrice(a.card, marketState, trader).buyValue;
      const bv = window.CardForgeMarket.computeMarketPrice(b.card, marketState, trader).buyValue;
      return Math.abs(fairness.deltaValue - av) - Math.abs(fairness.deltaValue - bv);
    })[0] ?? null;
}

function refreshTraderManifest(trader, cardById) {
  if (!trader) return;
  trader.manifestPreview = (trader.stock ?? []).slice(0, 4).map((entry) => {
    const card = cardById?.[entry.cardId];
    return {
      cardId: entry.cardId,
      name: card?.name ?? entry.cardId,
      rarity: String(card?.rarity ?? 'common').toLowerCase(),
      type: String(card?.type ?? 'card').toLowerCase(),
      copies: Math.max(0, Number(entry.copies ?? 0)),
    };
  });
  trader.manifestSummary = trader.manifestPreview.map((entry) => `${entry.name} x${entry.copies}`).join(' • ');
  trader.specialtyPreview = [...new Set((trader.manifestPreview ?? []).flatMap((entry) => [entry.rarity, entry.type]))].slice(0, 4);
}

function openMarketFromMap(options = {}) {
  marketUiState.selectedTraderId = options.traderId ?? marketUiState.selectedTraderId;
  marketUiState.selectedNodeId = options.nodeId ?? marketUiState.selectedNodeId;
  marketUiState.selectedShipId = options.shipId ?? marketUiState.selectedShipId;
  ensureLobbyPanelOpen(true).then(() => {
    showTab('market');
  });
}

function hasNodeMarketAccess(profileState, nodeId) {
  const marketState = profileState?.mapWorld?.campaign?.market ?? null;
  const directTrader = marketTraderList(marketState).find((trader) => trader.nodeId === nodeId || trader.dockedNodeId === nodeId) ?? null;
  if (directTrader) return directTrader;
  const world = findCampaignWorldByNode(profileState, nodeId);
  const hasTradePort = (world?.planets ?? []).some((planet) => (planet.buildings ?? []).includes('trade_port'));
  if (!hasTradePort) return null;
  return marketTraderList(marketState).find((trader) => trader.traderType === 'port_trader') ?? null;
}

function syncTraderOfferAfterTrade(trader, traderEntries, playerEntries) {
  const stockMap = Object.fromEntries((trader?.stock ?? []).map((entry) => [entry.cardId, entry]));
  traderEntries.forEach((entry) => {
    if (!stockMap[entry.cardId]) return;
    stockMap[entry.cardId].copies = Math.max(0, Number(stockMap[entry.cardId].copies ?? 0) - entry.count);
  });
  playerEntries.forEach((entry) => {
    if (!stockMap[entry.cardId]) stockMap[entry.cardId] = { cardId: entry.cardId, copies: 0 };
    stockMap[entry.cardId].copies = Math.max(0, Number(stockMap[entry.cardId].copies ?? 0) + entry.count);
  });
  trader.stock = Object.values(stockMap).filter((entry) => Number(entry.copies ?? 0) > 0);
}

function commitMarketTransaction(profile, trader, marketState, cardById) {
  const mode = marketActionMode();
  if (mode === 'idle') return { ok: false, message: 'No cards selected.' };
  const playerEntries = currentOfferEntries(marketUiState.playerOffer);
  const traderEntries = currentOfferEntries(marketUiState.traderOffer);
  const fairness = window.CardForgeMarket.evaluateTradeOffer(playerEntries, traderEntries, trader, marketState, cardById);
  const playerValue = fairness.playerSellValue ?? fairness.playerValue;
  const traderValue = fairness.traderBuyValue ?? fairness.traderValue;
  const traderFaction = window.CardForgeMarket.TRADER_FACTIONS[trader.factionId];
  const liveInventoryRows = buildTradeInventory(profile, cardById, trader, marketState);
  const inventoryById = Object.fromEntries(liveInventoryRows.map((row) => [row.card.id, row]));
  playerEntries.forEach((entry) => {
    const row = inventoryById[entry.cardId];
    const freeCount = Math.max(0, Number(row?.freeCount ?? 0));
    if (entry.count > freeCount) {
      throw new Error(`Protected or unavailable copies selected for ${entry.cardId}`);
    }
  });
  traderEntries.forEach((entry) => {
    const stockEntry = (trader?.stock ?? []).find((row) => row.cardId === entry.cardId);
    const available = Math.max(0, Number(stockEntry?.copies ?? 0));
    if (entry.count > available) {
      throw new Error(`Trader stock changed for ${entry.cardId}`);
    }
  });
  let currencyKey = trader.traderType === 'black_market' ? 'lifeforce' : 'gold';
  let currencyDelta = 0;

  if (mode === 'buy') {
    const required = currencyKey === 'lifeforce' ? window.CardForgeMarket.bandRound(traderValue * 0.45) : traderValue;
    if (Number(profile.economy?.[currencyKey] ?? 0) < required) {
      return { ok: false, message: `Not enough ${currencyKey}.` };
    }
    profile.economy[currencyKey] -= required;
    currencyDelta = -required;
    traderEntries.forEach((entry) => {
      profile.collection[entry.cardId] = Math.max(0, Number(profile.collection[entry.cardId] ?? 0)) + entry.count;
    });
  } else if (mode === 'sell') {
    playerEntries.forEach((entry) => {
      if (Number(profile.collection?.[entry.cardId] ?? 0) < entry.count) throw new Error(`Sale underflow for ${entry.cardId}`);
    });
    playerEntries.forEach((entry) => {
      profile.collection[entry.cardId] = Math.max(0, Number(profile.collection[entry.cardId] ?? 0) - entry.count);
      if (profile.collection[entry.cardId] <= 0) delete profile.collection[entry.cardId];
    });
    const payout = currencyKey === 'lifeforce' ? window.CardForgeMarket.bandRound(playerValue * 0.45) : playerValue;
    profile.economy[currencyKey] = Math.max(0, Number(profile.economy?.[currencyKey] ?? 0)) + payout;
    currencyDelta = payout;
  } else {
    if (!fairness.accepted) {
      return { ok: false, message: `Trade rejected (${fairness.status}, ${fairness.fairnessPct}% delta).` };
    }
    playerEntries.forEach((entry) => {
      if (Number(profile.collection?.[entry.cardId] ?? 0) < entry.count) throw new Error(`Trade underflow for ${entry.cardId}`);
    });
    playerEntries.forEach((entry) => {
      profile.collection[entry.cardId] = Math.max(0, Number(profile.collection[entry.cardId] ?? 0) - entry.count);
      if (profile.collection[entry.cardId] <= 0) delete profile.collection[entry.cardId];
    });
    traderEntries.forEach((entry) => {
      profile.collection[entry.cardId] = Math.max(0, Number(profile.collection[entry.cardId] ?? 0)) + entry.count;
    });
  }

  syncTraderOfferAfterTrade(trader, traderEntries, playerEntries);
  refreshTraderManifest(trader, cardById);
  const buyout = traderEntries.some((entry) => {
    const stock = (trader.stock ?? []).find((row) => row.cardId === entry.cardId);
    return !stock;
  });
  const ledger = marketLedgerEntry(mode, trader, { playerValue, traderValue }, fairness);
  profile.economy.marketLedger.push(ledger);
  profile.economy.marketLedger = profile.economy.marketLedger.slice(-80);
  window.CardForgeMarket.recordTrade(profile, trader, {
    mode,
    currencyKey,
    currencyDelta,
    fairness,
    playerCards: playerEntries,
    traderCards: traderEntries,
    cardsById: cardById,
    buyout,
  });
  saveProfile(profile);
  resetMarketOffers();
  return {
    ok: true,
    message: `${mode === 'buy' ? 'Purchase' : mode === 'sell' ? 'Sale' : 'Trade'} completed with ${trader?.name ?? traderFaction?.name ?? 'trader'}.`,
  };
}

async function renderMarketTab() {
  if (!dom.marketTab) return;
  const profile = loadProfile();
  const allCards = await loadLauncherCardCatalog();
  const cardById = Object.fromEntries(allCards.filter((card) => card?.id).map((card) => [card.id, card]));
  const marketState = ensureMarketState(profile, allCards);
  const traders = marketTraderList(marketState);
  const selectedTrader = resolveMarketSelection(traders);
  const inventoryRows = buildTradeInventory(profile, cardById, selectedTrader, marketState);
  const playerEntries = currentOfferEntries(marketUiState.playerOffer);
  const traderEntries = currentOfferEntries(marketUiState.traderOffer);
  const fairness = selectedTrader
    ? window.CardForgeMarket.evaluateTradeOffer(playerEntries, traderEntries, selectedTrader, marketState, cardById)
    : { playerValue: 0, traderValue: 0, fairnessPct: 0, deltaValue: 0, status: 'idle', accepted: false, tolerancePct: 15 };
  const actionMode = marketActionMode();
  const totalCollection = traderCollectionValue(profile, cardById);
  const liquidValue = inventoryRows.reduce((sum, row) => sum + (row.freeCount * row.price.sellValue), 0);
  const relation = selectedTrader ? relationChip(selectedTrader.factionId, marketState) : { label: 'Neutral', score: 0, className: 'relation-neutral' };
  const inspectCard = cardById[marketUiState.inspectCardId] ?? (selectedTrader?.stock?.[0]?.cardId ? cardById[selectedTrader.stock[0].cardId] : inventoryRows[0]?.card ?? null);
  if (!marketUiState.inspectCardId && inspectCard?.id) marketUiState.inspectCardId = inspectCard.id;
  const inspectPrice = inspectCard && selectedTrader
    ? window.CardForgeMarket.computeMarketPrice(inspectCard, marketState, selectedTrader)
    : null;
  const activeNews = (marketState.newsFeed ?? []).slice(0, 6);
  const activeDemands = (marketState.activeDemands ?? []).slice(0, 8);
  const ledger = [...(profile.economy?.marketLedger ?? [])].reverse().slice(0, 6);
  const marketLine = window.CardForgeMarket.createSparklineSvg((marketState.marketIndices?.history ?? []).map((entry) => entry.global), { width: 220, height: 54, color: '#7fd5ff' });
  const relationLine = selectedTrader
    ? window.CardForgeMarket.createSparklineSvg((marketState.relationHistory?.[selectedTrader.factionId] ?? []).map((entry) => entry.score), { width: 220, height: 54, color: '#ffca78' })
    : '';
  const inspectedHistory = inspectCard
    ? window.CardForgeMarket.createSparklineSvg((marketState.priceHistory?.[inspectCard.id] ?? []).map((entry) => entry.tradeValue), { width: 220, height: 54, color: '#87f1b9' })
    : '';
  const equalizer = selectedTrader ? marketBestEqualizer(inventoryRows, cardById, selectedTrader, marketState) : null;
  const inventoryById = Object.fromEntries(inventoryRows.map((row) => [row.card.id, row]));
  const stockById = Object.fromEntries((selectedTrader?.stock ?? []).map((row) => [row.cardId, row]));
  const wishlist = new Set(profile.economy?.wishlist ?? []);
  const watched = new Set(profile.economy?.watchedCards ?? []);
  const topCollections = Object.entries(marketState.marketIndices?.collections ?? {})
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([collectionId, value]) => ({
      collectionId,
      value,
      chart: window.CardForgeMarket.createSparklineSvg((marketState.collectionHistory?.[collectionId] ?? []).map((entry) => entry.value), { width: 180, height: 36, color: '#ffca78' }),
    }));
  const factionVolumes = Object.entries(window.CardForgeMarket.TRADER_FACTIONS ?? {})
    .map(([factionId, faction]) => ({
      factionId,
      faction,
      relationMeta: relationChip(factionId, marketState),
      lastVolume: Number((marketState.factionTradeHistory?.[factionId] ?? []).slice(-1)[0]?.volume ?? 0),
      chart: window.CardForgeMarket.createSparklineSvg((marketState.factionTradeHistory?.[factionId] ?? []).map((entry) => entry.volume), { width: 168, height: 34, color: faction?.palette?.primary ?? '#7fd5ff' }),
    }))
    .sort((a, b) => b.lastVolume - a.lastVolume)
    .slice(0, 4);
  const arrivalShips = (marketState.tradeShips ?? [])
    .filter((ship) => ship?.visible !== false)
    .sort((a, b) => Number(a.eta ?? 9999) - Number(b.eta ?? 9999))
    .slice(0, 4);
  const routeHeatRows = Object.entries(marketState.routeHeat ?? {})
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([routeKey, heat]) => ({ routeKey, heat, label: routeKey.replace('|', ' -> ') }));
  const watchedCards = [...watched]
    .map((cardId) => cardById[cardId])
    .filter(Boolean)
    .slice(0, 4)
    .map((card) => ({
      card,
      price: selectedTrader ? window.CardForgeMarket.computeMarketPrice(card, marketState, selectedTrader) : null,
      chart: window.CardForgeMarket.createSparklineSvg((marketState.priceHistory?.[card.id] ?? []).map((entry) => entry.tradeValue), { width: 180, height: 36, color: '#9ce6ff' }),
    }));
  const profitLine = window.CardForgeMarket.createSparklineSvg((marketState.playerProfitHistory ?? []).map((entry) => entry.delta), { width: 220, height: 54, color: '#9ff6b3' });
  const selectedManifest = selectedTrader?.manifestPreview ?? [];
  const traderMeta = selectedTrader ? (window.CardForgeMarket.TRADER_ARCHETYPES?.[selectedTrader.traderType] ?? null) : null;
  const stockQuery = marketUiState.stockQuery.trim().toLowerCase();
  const allStockRows = (selectedTrader?.stock ?? [])
    .map((entry) => ({ stock: entry, card: cardById[entry.cardId] }))
    .filter((entry) => entry.card && (!stockQuery || `${entry.card.name} ${entry.card.type} ${(entry.card.tags ?? []).join(' ')}`.toLowerCase().includes(stockQuery)))
    .sort((a, b) => {
      const av = window.CardForgeMarket.computeMarketPrice(a.card, marketState, selectedTrader).buyValue;
      const bv = window.CardForgeMarket.computeMarketPrice(b.card, marketState, selectedTrader).buyValue;
      return bv - av;
    });
  const stockRows = allStockRows.slice(0, marketUiState.stockLimit);
  const inventoryVisible = inventoryRows.slice(0, marketUiState.inventoryLimit);
  const stockOverflow = Math.max(0, allStockRows.length - stockRows.length);
  const inventoryOverflow = Math.max(0, inventoryRows.length - inventoryVisible.length);
  const tradeDeltaLabel = actionMode === 'buy' ? 'Cost' : actionMode === 'sell' ? 'Payout' : 'Delta';
  const fairnessLabel = actionMode === 'barter' ? 'Fairness' : 'Quote';
  const statusLabel = actionMode === 'buy' ? 'quoted' : actionMode === 'sell' ? 'liquidating' : fairness.status;
  const meterValue = actionMode === 'barter'
    ? Math.min(100, Math.max(8, 50 + fairness.fairnessPct))
    : Math.min(100, Math.max(8, selectedTrader ? 100 : 8));
  const yourSideValue = actionMode === 'barter' ? fairness.playerTradeValue : fairness.playerValue;
  const traderSideValue = actionMode === 'barter' ? fairness.traderTradeValue : fairness.traderValue;
  const deltaDisplayValue = actionMode === 'buy'
    ? fairness.traderBuyValue
    : actionMode === 'sell'
      ? fairness.playerSellValue
      : fairness.deltaValue;

  dom.marketTab.innerHTML = `
    <section class="market-shell">
      <aside class="market-sidebar panel-sub">
        <div class="market-overview-card">
          <h3>Market Command</h3>
          <div class="market-summary-grid">
            <div><span>Gold</span><strong>${Math.max(0, Number(profile.economy?.gold ?? 0))}</strong></div>
            <div><span>Lifeforce</span><strong>${Math.max(0, Number(profile.economy?.lifeforce ?? 0))}</strong></div>
            <div><span>Collection Value</span><strong>${window.CardForgeMarket.bandRound(totalCollection)}</strong></div>
            <div><span>Liquid Value</span><strong>${window.CardForgeMarket.bandRound(liquidValue)}</strong></div>
          </div>
          <div class="market-graph-card">
            <div class="market-graph-head"><strong>Global Market Index</strong><span>${Number(marketState.marketIndices?.global ?? 1).toFixed(2)}x</span></div>
            ${marketLine}
          </div>
          <div class="market-graph-card">
            <div class="market-graph-head"><strong>Player Trade Flow</strong><span>${(marketState.playerProfitHistory ?? []).length} events</span></div>
            ${profitLine}
          </div>
        </div>
        <div class="market-section">
          <h4>Collection Leaders</h4>
          <div class="market-mini-list">
            ${topCollections.map((entry) => `<article class="market-mini-card">
              <div class="market-graph-head"><strong>${entry.collectionId}</strong><span>${Number(entry.value).toFixed(2)}x</span></div>
              ${entry.chart}
            </article>`).join('') || '<div class="hint">Collection indices are still forming.</div>'}
          </div>
        </div>
        <div class="market-section">
          <h4>Active Demands</h4>
          <div class="market-chip-wrap">
            ${activeDemands.map((demand) => `<button class="market-chip" data-market-demand="${demand.id}">${demand.factionName}: ${demand.collectionId ?? demand.tag} x${demand.bonus}</button>`).join('') || '<span class="hint">No active demands.</span>'}
          </div>
        </div>
        <div class="market-section">
          <h4>News Wire</h4>
          <div class="market-news-list">
            ${activeNews.map((news) => `<article class="market-news-row">${news.text}</article>`).join('') || '<div class="hint">Market channels are quiet.</div>'}
          </div>
        </div>
        <div class="market-section">
          <h4>Arrival Windows</h4>
          <div class="market-mini-list">
            ${arrivalShips.map((ship) => `<article class="market-mini-card">
              <div class="market-graph-head"><strong>${ship.name}</strong><span>ETA ${Math.max(0, Number(ship.eta ?? 0))}s</span></div>
              <div class="market-card-meta">${ship.nodeName ?? ship.dockedNodeId ?? 'Deep Route'} • ${ship.shipClass ?? ship.traderType}</div>
              <div class="market-card-tags">${(ship.specialtyPreview ?? []).map((tag) => `<span class="tag-chip">${tag}</span>`).join('')}</div>
              <div class="market-card-meta">${escapeHtml(ship.manifestSummary ?? 'Rotating cargo')}</div>
            </article>`).join('') || '<div class="hint">No active trade ships on the routes.</div>'}
          </div>
        </div>
        <div class="market-section">
          <h4>Route Heatmap</h4>
          <div class="market-news-list">
            ${routeHeatRows.map((row) => `<article class="market-news-row"><strong>${row.label}</strong><span>Heat ${row.heat}</span></article>`).join('') || '<div class="hint">Trade lanes are calm.</div>'}
          </div>
        </div>
        <div class="market-section">
          <h4>Traders</h4>
          <div class="market-trader-list">
            ${traders.map((trader) => {
              const faction = window.CardForgeMarket.TRADER_FACTIONS[trader.factionId];
              const traderRelation = relationChip(trader.factionId, marketState);
              return `<button class="market-trader-row ${marketUiState.selectedTraderId === trader.id ? 'selected' : ''}" data-market-trader="${trader.id}">
                <span class="market-trader-icon" style="--faction-color:${faction?.palette?.primary ?? '#7fd5ff'}">${trader.icon ?? faction?.emblem ?? '◈'}</span>
                <span class="market-trader-copy">
                  <strong>${trader.name}</strong>
                  <small>${trader.shipClass ?? trader.subtitle ?? ''} • ${traderRelation.label}</small>
                </span>
              </button>`;
            }).join('')}
          </div>
        </div>
      </aside>
      <section class="market-center">
        <article class="panel-sub market-trader-header">
          <div>
            <h3>${selectedTrader?.name ?? 'No Active Trader'}</h3>
            <div class="market-trader-meta">${selectedTrader?.subtitle ?? ''} • ${selectedTrader?.nodeName ?? 'Deep Route'} • <span class="market-relation-chip ${relation.className}">${relation.label} ${relation.score >= 0 ? '+' : ''}${relation.score}</span></div>
            <div class="market-card-tags">
              ${(selectedTrader?.specialties ?? []).slice(0, 5).map((tag) => `<span class="tag-chip">${tag}</span>`).join('')}
            </div>
          </div>
          <div class="market-trader-header-side">
            <input id="market-stock-search" placeholder="Search trader stock..." value="${escapeHtml(marketUiState.stockQuery)}" />
            <input id="market-inventory-search" placeholder="Search your inventory..." value="${escapeHtml(marketUiState.inventoryQuery)}" />
          </div>
        </article>
        <article class="panel-sub market-trader-strip">
          <div class="market-summary-grid">
            <div><span>Buy Spread</span><strong>${Number(traderMeta?.buySpread ?? 1).toFixed(2)}x</strong></div>
            <div><span>Sell Factor</span><strong>${Number(traderMeta?.sellFactor ?? 1).toFixed(2)}x</strong></div>
            <div><span>Access Tier</span><strong>${relation.label}</strong></div>
            <div><span>Manifest</span><strong>${selectedManifest.length ? `${selectedManifest.length} crates` : 'Rotating'}</strong></div>
          </div>
          <div class="market-manifest-strip">
            ${selectedManifest.map((entry) => `<div class="market-manifest-card rarity-${entry.rarity}">
              <strong>${entry.name}</strong>
              <span>${entry.type} • x${entry.copies}</span>
            </div>`).join('') || '<div class="hint">No manifest preview available.</div>'}
          </div>
        </article>
        <div class="market-grid">
          <article class="panel-sub">
            <div class="market-panel-head">
              <h4>Trader Stock</h4>
              <span>${stockRows.length}/${allStockRows.length} visible</span>
            </div>
            <div class="market-stock-grid">
              ${stockRows.map(({ stock, card }) => {
                const price = window.CardForgeMarket.computeMarketPrice(card, marketState, selectedTrader);
                const wished = wishlist.has(card.id);
                const watchedCard = watched.has(card.id);
                return `<div class="market-card-card rarity-${card.rarity ?? 'common'} ${marketUiState.inspectCardId === card.id ? 'inspected' : ''}">
                  <button class="market-card-wishlist ${wished ? 'active' : ''}" data-market-wishlist="${card.id}">★</button>
                  <strong>${card.name}</strong>
                  <div class="market-card-meta">${card.type} • ${price.buyValue}g • x${stock.copies}</div>
                  <div class="market-card-tags">${(card.tags ?? []).slice(0, 3).map((tag) => `<span class="tag-chip">${tag}</span>`).join('')}</div>
                  <div class="market-card-actions">
                    <button data-market-inspect="${card.id}">Inspect</button>
                    <button data-market-watch="${card.id}" class="${watchedCard ? 'active' : ''}">${watchedCard ? 'Watching' : 'Watch'}</button>
                    <button data-market-add-stock="${card.id}">Add</button>
                    <button data-market-remove-stock="${card.id}">-</button>
                  </div>
                  <div class="market-card-spark">${window.CardForgeMarket.createSparklineSvg((marketState.priceHistory?.[card.id] ?? []).map((entry) => entry.tradeValue), { width: 140, height: 36, color: '#7fd5ff' })}</div>
                </div>`;
              }).join('') || '<div class="hint">No stock matches current filters.</div>'}
            </div>
            ${stockOverflow > 0 ? `<div class="market-list-actions"><button data-market-more-stock="1">Load ${Math.min(48, stockOverflow)} More</button><span class="hint">${stockOverflow} more stock cards hidden for performance.</span></div>` : ''}
          </article>
          <article class="panel-sub">
            <div class="market-panel-head">
              <h4>Your Inventory</h4>
              <div class="market-toggle-row">
                <label><input id="market-toggle-favorites" type="checkbox" ${marketUiState.excludeFavorites ? 'checked' : ''}/> Exclude favorites</label>
                <label><input id="market-toggle-decked" type="checkbox" ${marketUiState.excludeDecked ? 'checked' : ''}/> Exclude decked</label>
                <label><input id="market-toggle-duplicates" type="checkbox" ${marketUiState.duplicatesOnly ? 'checked' : ''}/> Duplicates only</label>
              </div>
            </div>
            <div class="market-stock-grid">
              ${inventoryVisible.map((row) => `<div class="market-card-card rarity-${row.card.rarity ?? 'common'} ${marketUiState.inspectCardId === row.card.id ? 'inspected' : ''}">
                <strong>${row.card.name}</strong>
                <div class="market-card-meta">Owned ${row.owned} • Free ${row.freeCount} • Sell ${row.price.sellValue}</div>
                <div class="market-card-tags">
                  ${row.favoriteProtected ? '<span class="tag-chip">Favorite</span>' : ''}
                  ${row.committedCopies ? `<span class="tag-chip">Deck ${row.committedCopies}</span>` : ''}
                  ${(row.card.tags ?? []).slice(0, 2).map((tag) => `<span class="tag-chip">${tag}</span>`).join('')}
                </div>
                <div class="market-card-actions">
                  <button data-market-inspect="${row.card.id}">Inspect</button>
                  <button data-market-watch="${row.card.id}" class="${watched.has(row.card.id) ? 'active' : ''}">${watched.has(row.card.id) ? 'Watching' : 'Watch'}</button>
                  <button data-market-add-player="${row.card.id}" ${row.freeCount <= 0 ? 'disabled' : ''}>Offer</button>
                  <button data-market-remove-player="${row.card.id}">-</button>
                </div>
              </div>`).join('') || '<div class="hint">No inventory cards match current filters.</div>'}
            </div>
            ${inventoryOverflow > 0 ? `<div class="market-list-actions"><button data-market-more-inventory="1">Load ${Math.min(60, inventoryOverflow)} More</button><span class="hint">${inventoryOverflow} more owned cards hidden for performance.</span></div>` : ''}
          </article>
        </div>
      </section>
      <aside class="market-offer-rail panel-sub">
        <div class="market-panel-head">
          <h4>Trade Resolver</h4>
          <span class="market-fairness-pill status-${fairness.status}">${statusLabel}</span>
        </div>
        <div class="market-offer-columns">
          <div>
            <h5>Your Offer</h5>
            ${(playerEntries.map((entry) => {
              const row = inventoryById[entry.cardId];
              const remain = Math.max(0, Number(row?.owned ?? 0) - entry.count);
              return `<div class="market-offer-row">${cardById[entry.cardId]?.name ?? entry.cardId} x${entry.count}<span>remain ${remain}</span></div>`;
            }).join('')) || '<div class="hint">Nothing selected.</div>'}
          </div>
          <div>
            <h5>Trader Offer</h5>
            ${(traderEntries.map((entry) => {
              const stock = stockById[entry.cardId];
              const remain = Math.max(0, Number(stock?.copies ?? 0) - entry.count);
              return `<div class="market-offer-row">${cardById[entry.cardId]?.name ?? entry.cardId} x${entry.count}<span>remain ${remain}</span></div>`;
            }).join('')) || '<div class="hint">Nothing selected.</div>'}
          </div>
        </div>
        <div class="market-summary-grid">
          <div><span>Your Side</span><strong>${yourSideValue}</strong></div>
          <div><span>Trader Side</span><strong>${traderSideValue}</strong></div>
          <div><span>${tradeDeltaLabel}</span><strong>${actionMode === 'barter' ? `${deltaDisplayValue >= 0 ? '+' : ''}${deltaDisplayValue}` : deltaDisplayValue}</strong></div>
          <div><span>${fairnessLabel}</span><strong>${actionMode === 'barter' ? `${fairness.fairnessPct}%` : (actionMode === 'buy' ? `${fairness.traderBuyValue} ${selectedTrader?.traderType === 'black_market' ? 'LF' : 'Gold'}` : `${fairness.playerSellValue} ${selectedTrader?.traderType === 'black_market' ? 'LF' : 'Gold'}`)}</strong></div>
        </div>
        <div class="market-meter"><span style="width:${meterValue}%"></span></div>
        <div class="market-offer-actions">
          <button id="market-confirm-btn" ${selectedTrader ? '' : 'disabled'}>${actionMode === 'buy' ? 'Confirm Buy' : actionMode === 'sell' ? 'Confirm Sale' : actionMode === 'barter' ? 'Confirm Trade' : 'No Offer Yet'}</button>
          <button id="market-auto-balance-btn" ${equalizer ? '' : 'disabled'}>Auto Balance</button>
          <button id="market-clear-btn">Clear Offer</button>
        </div>
        <div class="market-equalizer">${equalizer ? `Suggested equalizer: ${equalizer.card?.name ?? equalizer.cardId ?? equalizer.stock?.cardId}` : 'Offer already balanced enough or no filler found.'}</div>
        <div id="market-feedback" class="hint">${escapeHtml(marketUiState.feedbackMessage || '')}</div>
        <div class="market-section">
          <h5>Valuation Inspect</h5>
          ${inspectCard && inspectPrice ? `
            <article class="market-inspect-card">
              <strong>${inspectCard.name}</strong>
              <div class="market-card-meta">${inspectCard.type} • Base ${inspectPrice.baseValue} • Trade ${inspectPrice.tradeValue} • Buy ${inspectPrice.buyValue} • Sell ${inspectPrice.sellValue}</div>
              <div class="market-card-tags">${(inspectCard.tags ?? []).slice(0, 6).map((tag) => `<span class="tag-chip">${tag}</span>`).join('')}</div>
              <div class="market-card-actions">
                <button data-market-watch="${inspectCard.id}" class="${watched.has(inspectCard.id) ? 'active' : ''}">${watched.has(inspectCard.id) ? 'Watching' : 'Watch Card'}</button>
                <button data-market-wishlist="${inspectCard.id}" class="${wishlist.has(inspectCard.id) ? 'active' : ''}">${wishlist.has(inspectCard.id) ? 'Wishlisted' : 'Wishlist'}</button>
              </div>
              <div class="market-graph-card">
                <div class="market-graph-head"><strong>Price History</strong><span>${inspectPrice.marketIndex.toFixed(2)}x</span></div>
                ${inspectedHistory}
              </div>
              <div class="market-graph-card">
                <div class="market-graph-head"><strong>Relation Trend</strong><span>${relation.label}</span></div>
                ${relationLine}
              </div>
              <div class="market-breakdown">
                ${inspectPrice.breakdown.map((part) => `<div><span>${part.label}</span><strong>${part.value}</strong>${part.meta ? `<small>${part.meta}</small>` : ''}</div>`).join('')}
              </div>
            </article>
          ` : '<div class="hint">Inspect a card to see pricing logic.</div>'}
        </div>
        <div class="market-section">
          <h5>Watched Cards</h5>
          <div class="market-mini-list">
            ${watchedCards.map((entry) => `<article class="market-mini-card">
              <div class="market-graph-head"><strong>${entry.card.name}</strong><span>${entry.price?.tradeValue ?? 0}</span></div>
              ${entry.chart}
            </article>`).join('') || '<div class="hint">Watch cards to keep their price graphs live.</div>'}
          </div>
        </div>
        <div class="market-section">
          <h5>Faction Flow</h5>
          <div class="market-mini-list">
            ${factionVolumes.map((entry) => `<article class="market-mini-card">
              <div class="market-graph-head"><strong>${entry.faction.name}</strong><span class="market-relation-chip ${entry.relationMeta.className}">${entry.relationMeta.label}</span></div>
              ${entry.chart}
            </article>`).join('') || '<div class="hint">No faction trade volume captured yet.</div>'}
          </div>
        </div>
        <div class="market-section">
          <h5>Recent Trades</h5>
          <div class="market-news-list">
            ${ledger.map((entry) => `<article class="market-news-row">${entry.mode.toUpperCase()} • ${entry.traderName} • ${entry.totals.playerValue}/${entry.totals.traderValue}</article>`).join('') || '<div class="hint">No market ledger yet.</div>'}
          </div>
        </div>
      </aside>
    </section>
  `;
  dom.marketTab.onclick = (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.marketTrader) {
      marketUiState.selectedTraderId = button.dataset.marketTrader;
      marketUiState.stockLimit = 72;
      resetMarketOffers();
      renderMarketTab();
      return;
    }
    if (button.dataset.marketInspect) {
      marketUiState.inspectCardId = button.dataset.marketInspect;
      renderMarketTab();
      return;
    }
    if (button.dataset.marketWishlist) {
      const live = loadProfile();
      const list = new Set(live.economy?.wishlist ?? []);
      if (list.has(button.dataset.marketWishlist)) list.delete(button.dataset.marketWishlist);
      else list.add(button.dataset.marketWishlist);
      live.economy.wishlist = [...list];
      saveProfile(live);
      marketUiState.feedbackMessage = `Wishlist ${list.has(button.dataset.marketWishlist) ? 'updated' : 'cleared'}.`;
      renderMarketTab();
      return;
    }
    if (button.dataset.marketWatch) {
      const live = loadProfile();
      const list = new Set(live.economy?.watchedCards ?? []);
      if (list.has(button.dataset.marketWatch)) list.delete(button.dataset.marketWatch);
      else list.add(button.dataset.marketWatch);
      live.economy.watchedCards = [...list].slice(0, 12);
      saveProfile(live);
      marketUiState.feedbackMessage = `${list.has(button.dataset.marketWatch) ? 'Watching' : 'Stopped watching'} ${cardById[button.dataset.marketWatch]?.name ?? 'card'}.`;
      renderMarketTab();
      return;
    }
    if (button.dataset.marketDemand) {
      const demand = activeDemands.find((entry) => entry.id === button.dataset.marketDemand);
      const query = demand?.collectionId ?? demand?.tag ?? '';
      marketUiState.stockQuery = query;
      marketUiState.inventoryQuery = query;
      marketUiState.stockLimit = 72;
      marketUiState.inventoryLimit = 120;
      marketUiState.feedbackMessage = query ? `Filtered market to ${query}.` : '';
      renderMarketTab();
      return;
    }
    if (button.dataset.marketAddPlayer) {
      adjustPlayerOffer(button.dataset.marketAddPlayer, 1, inventoryRows);
      renderMarketTab();
      return;
    }
    if (button.dataset.marketRemovePlayer) {
      adjustPlayerOffer(button.dataset.marketRemovePlayer, -1, inventoryRows);
      renderMarketTab();
      return;
    }
    if (button.dataset.marketAddStock) {
      adjustTraderOffer(button.dataset.marketAddStock, 1, selectedTrader);
      renderMarketTab();
      return;
    }
    if (button.dataset.marketRemoveStock) {
      adjustTraderOffer(button.dataset.marketRemoveStock, -1, selectedTrader);
      renderMarketTab();
      return;
    }
    if (button.dataset.marketMoreStock) {
      marketUiState.stockLimit += 48;
      renderMarketTab();
      return;
    }
    if (button.dataset.marketMoreInventory) {
      marketUiState.inventoryLimit += 60;
      renderMarketTab();
      return;
    }
  };

  const stockInput = dom.marketTab.querySelector('#market-stock-search');
  if (stockInput) stockInput.oninput = () => {
    marketUiState.stockQuery = stockInput.value;
    marketUiState.stockLimit = 72;
    renderMarketTab();
  };
  const invInput = dom.marketTab.querySelector('#market-inventory-search');
  if (invInput) invInput.oninput = () => {
    marketUiState.inventoryQuery = invInput.value;
    marketUiState.inventoryLimit = 120;
    renderMarketTab();
  };
  const toggleFavorites = dom.marketTab.querySelector('#market-toggle-favorites');
  if (toggleFavorites) toggleFavorites.onchange = () => { marketUiState.excludeFavorites = toggleFavorites.checked; resetMarketOffers(); renderMarketTab(); };
  const toggleDecked = dom.marketTab.querySelector('#market-toggle-decked');
  if (toggleDecked) toggleDecked.onchange = () => { marketUiState.excludeDecked = toggleDecked.checked; resetMarketOffers(); renderMarketTab(); };
  const toggleDuplicates = dom.marketTab.querySelector('#market-toggle-duplicates');
  if (toggleDuplicates) toggleDuplicates.onchange = () => { marketUiState.duplicatesOnly = toggleDuplicates.checked; resetMarketOffers(); renderMarketTab(); };

  const clearBtn = dom.marketTab.querySelector('#market-clear-btn');
  if (clearBtn) clearBtn.onclick = () => { resetMarketOffers(); marketUiState.feedbackMessage = ''; renderMarketTab(); };
  const autoBtn = dom.marketTab.querySelector('#market-auto-balance-btn');
  if (autoBtn) autoBtn.onclick = () => {
    if (!equalizer) return;
    if (fairness.deltaValue < 0) adjustPlayerOffer(equalizer.card.id, 1, inventoryRows);
    else if (equalizer.stock?.cardId) adjustTraderOffer(equalizer.stock.cardId, 1, selectedTrader);
    marketUiState.feedbackMessage = 'Offer auto-balanced using the closest legal filler.';
    renderMarketTab();
  };
  const confirmBtn = dom.marketTab.querySelector('#market-confirm-btn');
  if (confirmBtn) confirmBtn.onclick = () => {
    const live = loadProfile();
    const liveMarket = ensureMarketState(live, allCards);
    const liveTrader = findMarketTrader(liveMarket, selectedTrader?.id);
    const feedback = dom.marketTab.querySelector('#market-feedback');
    try {
      const result = commitMarketTransaction(live, liveTrader, liveMarket, cardById);
      marketUiState.feedbackMessage = result.message;
      if (feedback) feedback.textContent = result.message;
      renderQuickStats();
      renderMarketTab();
    } catch (error) {
      console.error('[market] trade failed', error);
      marketUiState.feedbackMessage = 'Trade failed. Inventory remained unchanged.';
      if (feedback) feedback.textContent = marketUiState.feedbackMessage;
    }
  };
}

function applyLauncherUnlockAll(profile = loadProfile()) {
  const target = profile && typeof profile === 'object' ? profile : loadProfile();
  target.devUnlocked = true;
  target.collection = target.collection ?? {};
  target.economy = target.economy ?? { gold: 0, lifeforce: 0 };
  target.economy.pityByProduct = target.economy.pityByProduct ?? {};
  target.questProgress = target.questProgress ?? {};
  target.carnexCodes = target.carnexCodes ?? {};

  const allCards = mergeLauncherCardCatalog([
    ...(LOCAL_DATA.cardex?.cards ?? []),
    ...loadCreatorCustomCards(),
  ]);
  let cardsUpdated = 0;
  allCards.forEach((card) => {
    if (!card?.id) return;
    const prev = Math.max(0, Number(target.collection[card.id] ?? 0));
    const next = Math.max(prev, 4);
    if (next > prev) cardsUpdated += 1;
    target.collection[card.id] = next;
  });

  const aiPool = Array.isArray(cachedAiProfiles) && cachedAiProfiles.length ? cachedAiProfiles : (LOCAL_DATA.aiProfiles ?? []);
  const aiIds = [];
  const dimensions = [];
  aiPool.forEach((ai) => {
    const aiId = String(ai?.id ?? '').trim();
    if (!aiId) return;
    aiIds.push(aiId);
    const dimTag = String(ai?.personality?.dimensionTag ?? '#Frontier').trim() || '#Frontier';
    const level = Math.max(1, Math.floor(toFiniteNumber(ai?.level, 1)));
    if (!target.carnexCodes[aiId]) target.carnexCodes[aiId] = `${dimTag}-${level}-${aiId}`;
    const dimName = dimTag.replace(/^#+\s*/, '').trim();
    if (dimName) dimensions.push(dimName);
  });
  target.defeatedAiIds = [...new Set([...(target.defeatedAiIds ?? []), ...aiIds])];
  target.lobbyResidents = [...new Set([...(target.lobbyResidents ?? []), ...aiIds])];
  target.discoveredDimensions = [...new Set([...(target.discoveredDimensions ?? []), ...dimensions])];

  target.economy.gold = Math.max(250000, Math.max(0, Number(target.economy.gold ?? 0)));
  target.economy.lifeforce = Math.max(25000, Math.max(0, Number(target.economy.lifeforce ?? 0)));
  target.questProgress.packsOpened = Math.max(999, Math.max(0, Number(target.questProgress.packsOpened ?? 0)));
  ensureProfileStats(target);
  target.stats.packsOpened = Math.max(999, Math.max(0, Number(target.stats.packsOpened ?? 0)));
  target.stats.packs.openedTotal = Math.max(999, Math.max(0, Number(target.stats.packs?.openedTotal ?? 0)));
  saveProfile(target);

  return {
    cardsTotal: allCards.length,
    cardsUpdated,
    aiUnlocked: aiIds.length,
    dimensionsUnlocked: dimensions.length,
  };
}

function resolveStoreProductPool(product, allCards = []) {
  const poolTag = String(product.poolTag ?? '').trim();
  if (!poolTag) return allCards;
  const upper = poolTag.toUpperCase();
  const lower = poolTag.toLowerCase();
  const tagged = allCards.filter((card) => {
    const tags = Array.isArray(card.tags) ? card.tags.map((entry) => String(entry).toLowerCase()) : [];
    const race = String(card.race ?? '').toLowerCase();
    const faction = String(card.factionId ?? card.invasionFaction ?? '').toLowerCase();
    return tags.includes(lower) || tags.includes(upper.toLowerCase()) || race === lower || faction === lower;
  });
  if (tagged.length) return tagged;

  const thematicFallback = {
    ashen_armadas: ['siege', 'fortress', 'iron-carrion-mandate', 'armor', 'structure'],
    broken_stars: ['halo-censors', 'heal', 'radiant', 'silence', 'support'],
    feral_shard: ['chitin-ascendancy', 'swarm', 'adjacency', 'aggressive', 'summon'],
    black_signals: ['glass-null-collective', 'tax', 'control', 'spellcraft', 'value'],
  };
  const fallbackTags = thematicFallback[lower] ?? [];
  if (fallbackTags.length) {
    const fallbackPool = allCards.filter((card) => {
      const tags = Array.isArray(card.tags) ? card.tags.map((entry) => String(entry).toLowerCase()) : [];
      return fallbackTags.some((tag) => tags.includes(tag));
    });
    if (fallbackPool.length) return fallbackPool;
  }
  return allCards;
}

function weightedRarityRoll(weights = {}) {
  const entries = Object.entries(weights).filter(([, weight]) => Number(weight) > 0);
  if (!entries.length) return 'common';
  const total = entries.reduce((sum, [, weight]) => sum + Number(weight), 0);
  let roll = Math.random() * Math.max(0.0001, total);
  for (const [rarity, weight] of entries) {
    roll -= Number(weight);
    if (roll <= 0) return String(rarity).toLowerCase();
  }
  return String(entries[entries.length - 1][0]).toLowerCase();
}

function openStorePack(product, pool, pityState = { missesUntilGuaranteed: 0 }) {
  const byRarity = {};
  pool.forEach((card) => {
    const rarity = String(card.rarity ?? 'common').toLowerCase();
    byRarity[rarity] = byRarity[rarity] ?? [];
    byRarity[rarity].push(card);
  });
  const pityTarget = String(product.pity?.rarity ?? 'rare').toLowerCase();
  let misses = Math.max(0, Number(pityState.missesUntilGuaranteed ?? 0));
  const pulls = [];
  const count = Math.max(1, Number(product.count ?? 10));
  for (let i = 0; i < count; i += 1) {
    let rarity = weightedRarityRoll(product.weights ?? { common: 1 });
    if (product.pity && misses >= Math.max(1, Number(product.pity.threshold ?? 4))) {
      rarity = pityTarget;
      misses = 0;
    }
    const candidates = byRarity[rarity] ?? byRarity.common ?? pool;
    const picked = candidates[Math.floor(Math.random() * candidates.length)] ?? pool[0];
    pulls.push({ ...picked, rarity });
    const rarityRank = ['common', 'rare', 'epic', 'legendary'];
    if (rarityRank.indexOf(rarity) >= rarityRank.indexOf(pityTarget)) misses = 0;
    else misses += 1;
  }
  return { pulls, pityState: { missesUntilGuaranteed: misses } };
}

async function renderShopTab() {
  const host = dom.shopTab;
  const profile = loadProfile();
  ensureProfileStats(profile);
  const store = await loadJson('./game/store_packs/starter_store.json', LOCAL_DATA.store);
  const cardPayload = await loadJson('./cardex.json', LOCAL_DATA.cardex);
  const allCards = mergeLauncherCardCatalog(cardPayload?.cards ?? []);
  host.innerHTML = `<h3>Shop</h3><div>Gold: ${profile.economy?.gold ?? 0}</div>`;

  (store.products || []).forEach((product) => {
    const row = document.createElement('article');
    const openedCount = Number(profile.stats?.packs?.byPack?.[product.id] ?? 0);
    const pool = resolveStoreProductPool(product, allCards);
    row.innerHTML = `
      <strong>${product.name}</strong> (${product.price}g)
      <div>${product.description ?? 'Dimensional pack'}</div>
      <small>${Math.max(1, Number(product.count ?? 0))} cards per pack • tag ${product.poolTag ?? 'ALL'} • opened ${openedCount} • pool ${pool.length}</small>
    `;
    const buy = document.createElement('button');
    buy.textContent = `Buy Pack (${product.price}g)`;
    buy.disabled = Number(profile.economy?.gold ?? 0) < Number(product.price ?? 0) || pool.length === 0;
    buy.onclick = async () => {
      const live = loadProfile();
      ensureProfileStats(live);
      live.economy = live.economy ?? { gold: 0, lifeforce: 0 };
      live.economy.pityByProduct = live.economy.pityByProduct ?? {};
      if (Number(live.economy.gold ?? 0) < Number(product.price ?? 0)) {
        row.querySelector('.shop-feedback')?.remove();
        row.insertAdjacentHTML('beforeend', '<div class="shop-feedback">Not enough gold.</div>');
        return;
      }
      const livePool = resolveStoreProductPool(product, allCards);
      if (!livePool.length) {
        row.querySelector('.shop-feedback')?.remove();
        row.insertAdjacentHTML('beforeend', '<div class="shop-feedback">This pack has no available cards yet.</div>');
        return;
      }
      live.economy.gold = Number(live.economy.gold ?? 0) - Number(product.price ?? 0);
      const pityState = live.economy.pityByProduct[product.id] ?? { missesUntilGuaranteed: 0 };
      const opened = openStorePack(product, livePool, pityState);
      live.economy.pityByProduct[product.id] = opened.pityState;
      live.collection = live.collection ?? {};
      opened.pulls.forEach((card) => {
        live.collection[card.id] = Math.max(0, Number(live.collection[card.id] ?? 0)) + 1;
        const rarity = String(card.rarity ?? 'common').toLowerCase();
        live.stats.packs.rarityPulls[rarity] = Math.max(0, Number(live.stats.packs.rarityPulls[rarity] ?? 0)) + 1;
        if (rarity === 'legendary') {
          live.stats.packs.legendaryPulls = Math.max(0, Number(live.stats.packs.legendaryPulls ?? 0)) + 1;
        }
      });
      live.stats.packsOpened = Math.max(0, Number(live.stats.packsOpened ?? 0)) + 1;
      live.stats.packs.openedTotal = Math.max(0, Number(live.stats.packs.openedTotal ?? 0)) + 1;
      live.stats.packs.byPack[product.id] = Math.max(0, Number(live.stats.packs.byPack[product.id] ?? 0)) + 1;
      live.stats.packs.cardsByPack[product.id] = Math.max(0, Number(live.stats.packs.cardsByPack[product.id] ?? 0)) + opened.pulls.length;
      const uniqueInPool = livePool.filter((card) => Number(live.collection?.[card.id] ?? 0) > 0).length;
      live.stats.packs.uniqueByPack[product.id] = uniqueInPool;
      live.questProgress = live.questProgress ?? {};
      live.questProgress.packsOpened = Math.max(0, Number(live.questProgress.packsOpened ?? 0)) + 1;
      ensureProfileStats(live);
      saveProfile(live);
      await renderQuestTab();
      await renderStatsTab();
      await renderShopTab();
      renderQuickStats();
    };
    row.appendChild(buy);
    host.appendChild(row);
  });
  renderQuickStats();
}

function drawDimensionByName(name) {
  startOrbitAnimation(dom.dimensionCanvas, 'codex', name, 8, 'Codex Projection');
}

function describeRarity(cardName) {
  const n = cardName.toLowerCase();
  if (n.includes('legend') || n.includes('tyrant') || n.includes('reaper')) return { rarity: 'legendary', scrap: 14 };
  if (n.includes('epic') || n.includes('fractal') || n.includes('axiom')) return { rarity: 'epic', scrap: 9 };
  if (n.includes('rare') || n.includes('warden')) return { rarity: 'rare', scrap: 6 };
  return { rarity: 'common', scrap: 4 };
}

function traderPool(profiles) {
  const pool = [];
  profiles.forEach((ai) => {
    (ai.deck ?? ai.summons ?? []).forEach((unit) => {
      pool.push({
        name: unit.name,
        owner: ai.name,
        dimension: ai.personality?.dimensionTag ?? '#Unknown',
        level: ai.level ?? 1,
      });
    });
  });
  if (pool.length) return pool;
  const fallbackCards = Object.values(cachedPackCardsById ?? {})
    .flat()
    .filter((card) => {
      const type = String(card?.type ?? 'minion').toLowerCase();
      return type === 'minion' || type === 'creature' || type === 'token';
    })
    .slice(0, 80);
  fallbackCards.forEach((card) => {
    pool.push({
      name: card.name ?? 'Unknown Unit',
      owner: card.factionId ?? card.invasionFaction ?? card.race ?? 'Dimensional Trader',
      dimension: `#${card.homeDimension ?? card.universe ?? card.packSource ?? 'Frontier'}`,
      level: Math.max(1, Math.floor(toFiniteNumber(card.cost, 1)) + 1),
    });
  });
  return pool;
}

function getTraderOffer(profile, profiles) {
  const today = new Date().toISOString().slice(0, 10);
  if (profile.traderOffer?.day === today) return profile.traderOffer;

  const pool = traderPool(profiles);
  if (!pool.length) return null;

  const rand = seededRandom(`${today}-${getSessionSeed()}-trader`);
  const pick = pool[Math.floor(rand() * pool.length)];
  const cost = 18 + Math.floor((pick.level ?? 1) * 1.6);
  const offer = {
    day: today,
    card: pick.name,
    owner: pick.owner,
    dimension: pick.dimension,
    cost,
  };
  profile.traderOffer = offer;
  saveProfile(profile);
  return offer;
}

function renderInventoryAndTrader(profiles) {
  const profile = loadProfile();
  const cards = Object.entries(profile.capturedCards ?? {}).filter(([, count]) => count > 0);
  const marketState = ensureMarketState(profile, mergeLauncherCardCatalog(loadCreatorCustomCards()));
  const marketTraders = marketTraderList(marketState).slice(0, 3);

  dom.lifeforceMeta.textContent = `Lifeforce: ${profile.economy?.lifeforce ?? 0}`;
  dom.capturedList.innerHTML = cards.length ? '' : '<div>No captured creatures yet.</div>';

  cards.forEach(([name, count]) => {
    const row = document.createElement('div');
    row.className = 'inventory-row';
    row.innerHTML = `<span>${name} x${count}</span>`;

    const scrapButton = document.createElement('button');
    scrapButton.textContent = 'Scrap 1';
    scrapButton.onclick = () => {
      const rarity = describeRarity(name);
      const next = loadProfile();
      next.capturedCards[name] = Math.max(0, (next.capturedCards[name] ?? 0) - 1);
      if (next.capturedCards[name] === 0) delete next.capturedCards[name];
      next.economy.lifeforce = (next.economy.lifeforce ?? 0) + rarity.scrap;
      saveProfile(next);
      renderInventoryAndTrader(profiles);
      dom.captureFeedback.textContent = `Scrapped ${name} for ${rarity.scrap} lifeforce.`;
    };

    row.appendChild(scrapButton);
    dom.capturedList.appendChild(row);
  });

  dom.traderOffer.innerHTML = `
    <h4>Market Relay</h4>
    <div>The live economy now runs through the Market tab and roaming trade ships.</div>
    <div class="market-chip-wrap">
      ${marketTraders.map((trader) => {
        const relation = relationChip(trader.factionId, marketState);
        return `<button class="market-chip ${relation.className}" data-world-market-trader="${trader.id}">${trader.name} • ${relation.label}</button>`;
      }).join('') || '<span class="tag-chip">No traders in range</span>'}
    </div>
    <div class="hint">Scrap captured creatures here for lifeforce. Buy, sell, and barter real cards in the Market tab.</div>
  `;
  dom.traderOffer.querySelectorAll('[data-world-market-trader]').forEach((button) => {
    button.onclick = () => openMarketFromMap({ traderId: button.dataset.worldMarketTrader });
  });

  dom.paywallToggle.checked = !!profile.paywallMode;
  dom.paywallToggle.onchange = () => {
    const next = loadProfile();
    next.paywallMode = dom.paywallToggle.checked;
    saveProfile(next);
  };
}
function closestResident() {
  let closest = null;
  let bestDist = Infinity;
  for (const resident of worldRoom.residents) {
    const dist = Math.hypot(resident.x - worldRoom.player.x, resident.y - worldRoom.player.y);
    if (dist < bestDist) {
      bestDist = dist;
      closest = resident;
    }
  }
  return bestDist <= 70 ? closest : null;
}

function renderWorldRoom(aiProfiles) {
  const canvas = dom.lobbyRoomCanvas;
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  const bg = ctx.createLinearGradient(0, 0, 0, canvas.height);
  bg.addColorStop(0, '#0f1a32');
  bg.addColorStop(1, '#111428');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = '#44588f';
  ctx.lineWidth = 3;
  ctx.strokeRect(8, 8, canvas.width - 16, canvas.height - 16);

  for (let i = 0; i < 90; i += 1) {
    ctx.fillStyle = `rgba(180, 210, 255, ${0.08 + (i % 5) * 0.02})`;
    ctx.fillRect((i * 41) % canvas.width, (i * 67) % canvas.height, 2, 2);
  }

  worldRoom.residents.forEach((resident) => {
    const color = resident.defeated ? '#7dffa2' : '#9ab7ff';
    ctx.fillStyle = color;
    ctx.fillRect(resident.x - 11, resident.y - 11, 22, 22);
    ctx.fillStyle = '#dbe9ff';
    ctx.font = '11px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText(resident.name, resident.x, resident.y - 16);
  });

  ctx.fillStyle = '#ffd977';
  ctx.fillRect(worldRoom.player.x - 10, worldRoom.player.y - 10, 20, 20);
  ctx.fillStyle = '#111';
  ctx.font = '11px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText('You', worldRoom.player.x, worldRoom.player.y - 14);

  const nearby = closestResident();
  dom.roomHint.textContent = nearby
    ? `Near ${nearby.name}. Press Talk Nearby to open dialogue.`
    : 'Move around the room to approach defeated AI residents.';

  canvas.onclick = (event) => {
    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) * (canvas.width / rect.width);
    const y = (event.clientY - rect.top) * (canvas.height / rect.height);
    const hit = worldRoom.residents.find((resident) => Math.hypot(resident.x - x, resident.y - y) <= 16);
    if (hit) {
      const ai = aiProfiles.find((entry) => entry.id === hit.id);
      if (ai) openDialogue(ai);
    }
  };
}

function movePlayer(direction, aiProfiles) {
  const speed = 18;
  if (direction === 'up') worldRoom.player.y -= speed;
  if (direction === 'down') worldRoom.player.y += speed;
  if (direction === 'left') worldRoom.player.x -= speed;
  if (direction === 'right') worldRoom.player.x += speed;

  worldRoom.player.x = Math.max(18, Math.min(dom.lobbyRoomCanvas.width - 18, worldRoom.player.x));
  worldRoom.player.y = Math.max(18, Math.min(dom.lobbyRoomCanvas.height - 18, worldRoom.player.y));
  renderWorldRoom(aiProfiles);
}

function updateCaptureTargetSelect(aiProfiles) {
  const profile = loadProfile();
  dom.captureTarget.innerHTML = '';

  const defeated = aiProfiles.filter((ai) => mapStatus(profile, ai).defeated);
  defeated.forEach((ai) => {
    const option = document.createElement('option');
    option.value = ai.id;
    option.textContent = `${ai.name} (${ai.personality?.dimensionTag ?? '#Unknown'})`;
    dom.captureTarget.appendChild(option);
  });

  if (!defeated.length) {
    const option = document.createElement('option');
    option.value = '';
    option.textContent = 'Defeat an AI to unlock captures';
    dom.captureTarget.appendChild(option);
  }
}

function clearCaptureTimers() {
  if (!captureState) return;
  (captureState.timers ?? []).forEach((timer) => clearTimeout(timer));
  captureState = null;
}

function reactionRating(ms) {
  if (ms <= 180) return { label: 'perfect', points: 4 };
  if (ms <= 290) return { label: 'good', points: 3 };
  if (ms <= 430) return { label: 'awful', points: 1 };
  return { label: 'pathetic', points: 0 };
}

function captureCardName(ai, index) {
  const pool = (ai.deck ?? ai.summons ?? [{ name: `${ai.name} Echoling` }]).map((unit) => unit.name);
  const base = pool[index % Math.max(1, pool.length)] ?? `${ai.name} Echoling`;
  return `${base} (Captured)`;
}

function startCaptureMinigame(aiProfiles) {
  const targetId = dom.captureTarget.value;
  const ai = aiProfiles.find((entry) => entry.id === targetId);
  if (!ai) {
    dom.captureFeedback.textContent = 'No valid capture target selected.';
    return;
  }

  const profile = loadProfile();
  const status = mapStatus(profile, ai);
  if (!status.defeated) {
    dom.captureFeedback.textContent = 'You must defeat that AI before capture expeditions unlock.';
    return;
  }

  clearCaptureTimers();
  dom.captureStage.innerHTML = '';
  dom.captureStage.classList.add('active');
  dom.captureFeedback.textContent = `Capture trial initiated against ${ai.name}...`;

  const rounds = 8;
  const difficulty = Math.min(12, ai.level ?? 1);
  captureState = { timers: [], running: true, points: 0, round: 0 };

  const runRound = () => {
    if (!captureState?.running) return;

    if (captureState.round >= rounds) {
      const score = captureState.points;
      const chance = Math.max(0.12, Math.min(0.92, (score / (rounds * 4)) + (0.22 - (difficulty * 0.01))));
      const won = Math.random() < chance;
      if (won) {
        const cardName = captureCardName(ai, Math.floor(Math.random() * 50));
        const next = loadProfile();
        next.capturedCards[cardName] = (next.capturedCards[cardName] ?? 0) + 1;
        saveProfile(next);
        dom.captureFeedback.textContent = `Capture success: ${cardName}`;
        renderInventoryAndTrader(aiProfiles);
      } else {
        dom.captureFeedback.textContent = 'Capture failed. Try again after calibrating your reactions.';
      }
      dom.captureStage.classList.remove('active');
      dom.captureStage.innerHTML = '';
      captureState.running = false;
      return;
    }

    captureState.round += 1;
    dom.captureStage.innerHTML = '';

    const delay = 220 + Math.floor(Math.random() * 380);
    const spawnTimer = setTimeout(() => {
      if (!captureState?.running) return;

      const target = document.createElement('button');
      target.className = 'capture-target';
      const colors = ['#ff356e', '#48d7ff', '#8eff62'];
      target.style.background = colors[(captureState.round + difficulty) % colors.length];
      target.style.left = `${12 + Math.random() * 76}%`;
      target.style.top = `${12 + Math.random() * 70}%`;
      dom.captureStage.appendChild(target);

      const spawnedAt = performance.now();
      let settled = false;

      const resolveRound = (rating) => {
        if (settled) return;
        settled = true;
        dom.captureFeedback.textContent = `${ai.name} trial: ${rating.label}`;
        captureState.points += rating.points;
        target.remove();
        const nextTimer = setTimeout(runRound, 320);
        captureState.timers.push(nextTimer);
      };

      target.onclick = () => {
        const reaction = performance.now() - spawnedAt;
        resolveRound(reactionRating(reaction));
      };

      const timeout = setTimeout(() => resolveRound({ label: 'pathetic', points: 0 }), Math.max(360, 860 - (difficulty * 35)));
      captureState.timers.push(timeout);
    }, delay);

    captureState.timers.push(spawnTimer);
  };

  runRound();
}
function startIdleChatter(aiProfiles) {
  if (idleChatterTimer) clearInterval(idleChatterTimer);
  const profile = loadProfile();
  const residents = aiProfiles.filter((ai) => mapStatus(profile, ai).inLobby);

  if (residents.length < 2) {
    dom.idleChatter.innerHTML = '<div>Defeat more AIs to populate lobby chatter.</div>';
    return;
  }

  const pushLine = () => {
    const a = residents[Math.floor(Math.random() * residents.length)];
    let b = residents[Math.floor(Math.random() * residents.length)];
    if (residents.length > 1) {
      while (b.id === a.id) b = residents[Math.floor(Math.random() * residents.length)];
    }
    const lineA = aiLine(a, 'post_defeat_lobby', aiLine(a, 'lobby_greeting', 'Rematch data is available.'));
    const lineB = aiLine(b, 'post_defeat_lobby', aiLine(b, 'lobby_greeting', 'Noted.'));
    const row = document.createElement('div');
    row.textContent = `${a.name}: "${lineA}"  |  ${b.name}: "${lineB}"`;
    dom.idleChatter.prepend(row);
    while (dom.idleChatter.childElementCount > 14) dom.idleChatter.removeChild(dom.idleChatter.lastChild);
  };

  pushLine();
  idleChatterTimer = setInterval(pushLine, 6000);
}

function buildWorldResidents(aiProfiles) {
  const profile = loadProfile();
  const residents = aiProfiles.filter((ai) => mapStatus(profile, ai).inLobby);
  const rand = seededRandom(`${getSessionSeed()}-room-${residents.length}`);

  worldRoom = {
    player: worldRoom.player ?? { x: 70, y: 270 },
    residents: residents.map((ai, idx) => ({
      id: ai.id,
      name: ai.personality?.title ?? ai.name,
      sourceName: ai.name,
      defeated: mapStatus(profile, ai).defeated,
      x: 90 + ((idx % 5) * 95) + (rand() * 26),
      y: 86 + (Math.floor(idx / 5) * 86) + (rand() * 22),
    })),
  };
}

function renderWorldTab(aiProfiles) {
  buildWorldResidents(aiProfiles);
  renderWorldRoom(aiProfiles);
  updateCaptureTargetSelect(aiProfiles);
  renderInventoryAndTrader(aiProfiles);
  startIdleChatter(aiProfiles);
}

async function renderCarnifex() {
  const payload = await loadJson('./cardex.json', LOCAL_DATA.cardex);
  const mergedById = new Map();
  (payload.cards ?? []).forEach((card) => {
    if (card?.id) mergedById.set(card.id, card);
  });
  Object.values(cachedPackCardsById ?? {}).flat().forEach((card) => {
    if (card?.id) mergedById.set(card.id, { ...card });
  });
  const allCards = [...mergedById.values()];
  dom.cardexMeta.textContent = `Updated: ${payload.updatedAt ?? 'runtime'} • Cards: ${allCards.length}`;

  const render = () => {
    const q = dom.cardexSearch.value.trim().toLowerCase();
    dom.cardexList.innerHTML = '';

    allCards
      .filter((card) => `${card.name} ${card.type} ${(card.tags || []).join(' ')} ${JSON.stringify(card.ability || {})} ${card.bibliography || ''}`.toLowerCase().includes(q))
      .slice(0, 800)
      .forEach((card) => {
        const row = document.createElement('article');
        row.className = `rarity-${card.rarity} cardex-card`;
        const action = String(card.ability?.action ?? card.effect?.action ?? '').toLowerCase();
        const amount = Number(card.ability?.amount ?? card.effect?.amount ?? card.damage ?? 0) || 0;
        const rules = [
          card.type === 'minion'
            ? `Summon: ${card.attack ?? 0} ATK / ${card.health ?? 0} HP / ${Math.max(0, Number(card.def ?? card.baseDef ?? 0) || 0)} DEF.`
            : `Spell: ${action || 'effect'}${amount ? ` (${amount})` : ''}.`,
          card.taunt ? 'Guard: must be attacked first.' : '',
          card.pierce ? `Pierce ${card.pierce}: ignores DEF.` : '',
          card.trueDamage ? 'True Damage: ignores DEF.' : '',
          action === 'grantdefense' ? 'Defense Mod: grants DEF and Guard.' : '',
          action === 'shatterfront' ? 'Shatter: removes Defense/DEF for duration.' : '',
        ].filter(Boolean).join(' ');
        row.innerHTML = `<strong>${card.name}</strong> <span>${card.type} • ${card.rarity}</span><div>Cost ${card.cost} • ${action || 'none'} ${amount || ''}</div><small>${rules}</small>`;
        dom.cardexList.appendChild(row);
      });
  };

  dom.cardexSearch.oninput = render;
  render();

  dom.dimensionLocate.onclick = () => {
    const name = dom.dimensionInput.value.trim() || 'Unknown';
    drawDimensionByName(name);
    const profile = loadProfile();
    if (!(profile.discoveredDimensions ?? []).includes(name)) {
      profile.discoveredDimensions.push(name);
      saveProfile(profile);
    }
  };
}

function bindWorldControls() {
  document.querySelectorAll('[data-move]').forEach((button) => {
    button.onclick = () => movePlayer(button.dataset.move, cachedAiProfiles);
  });

  dom.talkNearby.onclick = () => {
    const nearby = closestResident();
    if (!nearby) {
      dom.roomHint.textContent = 'No AI close enough to talk. Move closer.';
      return;
    }
    const ai = cachedAiProfiles.find((entry) => entry.id === nearby.id);
    if (ai) openDialogue(ai);
  };

  dom.startCapture.onclick = () => startCaptureMinigame(cachedAiProfiles);
  if (dom.openMarketHubBtn) {
    dom.openMarketHubBtn.onclick = () => showTab('market');
  }

  window.addEventListener('keydown', (event) => {
    if (dom.worldTab.classList.contains('hidden')) return;
    if (event.key === 'ArrowUp' || event.key.toLowerCase() === 'w') movePlayer('up', cachedAiProfiles);
    if (event.key === 'ArrowDown' || event.key.toLowerCase() === 's') movePlayer('down', cachedAiProfiles);
    if (event.key === 'ArrowLeft' || event.key.toLowerCase() === 'a') movePlayer('left', cachedAiProfiles);
    if (event.key === 'ArrowRight' || event.key.toLowerCase() === 'd') movePlayer('right', cachedAiProfiles);
  });
}

function configureSchemeToggle() {
  const schemeSelect = document.getElementById('lobby-scheme');
  const saved = localStorage.getItem('cardforge.lobby.scheme') || 'arcane';
  schemeSelect.value = saved;
  document.body.classList.toggle('scheme-monarch', saved === 'monarch');
  schemeSelect.onchange = () => {
    const value = schemeSelect.value;
    localStorage.setItem('cardforge.lobby.scheme', value);
    document.body.classList.toggle('scheme-monarch', value === 'monarch');
  };
}

async function openLobbyPanel() {
  const push = (msg) => {
    const row = document.createElement('div');
    row.textContent = msg;
    dom.loadingFiles.prepend(row);
  };

  dom.loadingPanel.classList.remove('hidden');
  dom.loadingFiles.innerHTML = '';

  push('Loading AI packs and dimension statuses...');
  cachedAiProfiles = await loadAiProfiles();

  push('Loading battle mode rulesets...');
  cachedModeRulesets = await loadModeRulesets();

  push('Loading deck packs...');
  cachedDecks = await loadAllDecks();

  push('Loading faction flavor tips...');
  cachedLoadingTips = await loadLoadingTips();

  push('Loading battle map styles...');
  cachedMapStyles = await loadMapStyles();

  push('Loading galaxy seed packs...');
  cachedStarterGalaxies = await loadStarterGalaxies();

  push('Indexing pack assignment catalog...');
  cachedCardPacks = await loadPackCatalog();
  cachedPackCardsById = await loadPackCardsById();

  push('Loading Dimensional Attackers master pool...');
  const piratePoolBundle = await loadPirateMasterPool();
  cachedPirateMasterPool = piratePoolBundle.cards ?? [];
  cachedPirateHouses = piratePoolBundle.houses ?? [];

  push('Loading alien invasion factions...');
  cachedAlienFactions = await loadAlienFactions();

  push('Loading event category scaffolds...');
  cachedEventCategories = await loadEventCategories();

  const profileForQueuedResult = loadProfile();
  if (applyQueuedMatchResult(profileForQueuedResult)) {
    push('Applied queued battle outcome to campaign state.');
  }

  buildStyleOptions();
  buildPackOptions();

  push('Rendering matchmaking map...');
  await renderMatchTab(cachedAiProfiles);

  push('Rendering deck systems...');
  await renderDeckTab();

  push('Loading quests...');
  await renderQuestTab();

  push('Rendering shop...');
  await renderShopTab();

  push('Staging live market systems...');
  await renderMarketTab();

  push('Compiling profile stats...');
  await renderStatsTab();
  renderQuickStats();

  push('Loading codex and orbit systems...');
  await renderCarnifex();

  push('Booting lobby dimension room...');
  renderWorldTab(cachedAiProfiles);

  dom.loadingPanel.classList.add('hidden');
  dom.lobbyPanel.classList.remove('hidden');
  showTab('match');
  lobbyLoaded = true;
}

function ensureLobbyPanelOpen(force = false) {
  if (lobbyLoaded && !force) {
    dom.lobbyPanel.classList.remove('hidden');
    resumeMapRuntime();
    return Promise.resolve();
  }
  if (lobbyInitPromise && !force) return lobbyInitPromise;
  lobbyInitPromise = openLobbyPanel()
    .catch((error) => {
      console.error(error);
      dom.loadingFiles.prepend(Object.assign(document.createElement('div'), { textContent: `Failed to load lobby: ${error?.message ?? error}` }));
    })
    .finally(() => {
      lobbyInitPromise = null;
    });
  return lobbyInitPromise;
}

function clearCardforgeStorageKeys() {
  const keysToClear = [];
  for (let i = 0; i < localStorage.length; i += 1) {
    const key = localStorage.key(i);
    if (!key) continue;
    if (/^cardforge\./i.test(key)) keysToClear.push(key);
  }
  keysToClear.push(WORLD_KEY, MATCH_KEY, MATCH_CONTEXT_KEY, MATCH_RESULT_KEY);
  [...new Set(keysToClear)].forEach((key) => localStorage.removeItem(key));
  return [...new Set(keysToClear)].length;
}

function setNewGamePanelVisible(visible) {
  if (!dom.newGamePanel) return;
  dom.newGamePanel.classList.toggle('hidden', !visible);
}

function startFreshNewGame() {
  const cleared = clearCardforgeStorageKeys();
  const freshProfile = loadProfile();
  ensureProfileStats(freshProfile);
  saveProfile(freshProfile);
  cachedCardPacks = [];
  cachedPackCardsById = {};
  cachedDecks = [];
  cachedAiProfiles = [];
  mapProfilesRef = [];
  lobbyLoaded = false;
  suspendMapRuntime('new-game');
  setNewGamePanelVisible(false);
  ensureLobbyPanelOpen(true);
  renderQuickStats();
  if (dom.loadingFiles) {
    const row = document.createElement('div');
    row.textContent = `New Game initialized. Cleared ${cleared} persisted keys.`;
    dom.loadingFiles.prepend(row);
  }
}

configureSchemeToggle();
bindWorldControls();
renderQuickStats();
dom.openLobby.onclick = () => ensureLobbyPanelOpen(true);
if (dom.continueGameBtn) dom.continueGameBtn.onclick = () => ensureLobbyPanelOpen(true);
if (dom.openStatsBtn) {
  dom.openStatsBtn.onclick = async () => {
    await ensureLobbyPanelOpen(true);
    showTab('stats');
    renderStatsTab();
  };
}
if (dom.newGameBtn) dom.newGameBtn.onclick = () => setNewGamePanelVisible(true);
if (dom.cancelNewGameBtn) dom.cancelNewGameBtn.onclick = () => setNewGamePanelVisible(false);
if (dom.confirmNewGameBtn) dom.confirmNewGameBtn.onclick = () => startFreshNewGame();
document.addEventListener('visibilitychange', () => {
  if (document.hidden) suspendMapRuntime('hidden');
  else resumeMapRuntime();
});
if (window.location.hash === '#lobby') ensureLobbyPanelOpen(true);
else ensureLobbyPanelOpen(false);
