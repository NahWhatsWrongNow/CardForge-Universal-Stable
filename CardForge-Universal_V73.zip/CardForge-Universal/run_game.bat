@echo off
setlocal
call "%~dp0QualityControl\RunGame.bat" %*
endlocal
