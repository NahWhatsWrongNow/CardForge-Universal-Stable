import { Registry } from '../core/registry.js';
import { loadPlugins } from '../core/loader.js';
import { raceIconGlyph, raceMeta, RACE_LIBRARY } from '../game/engine/race_logic.js';

const registry = new Registry();

const STORAGE = {
  customCards: 'cardforge.creator.customCards.v1',
  profile: 'cardforge.profile.v1',
  projectDraft: 'cardforge.creator.studio.project.v2',
  userTemplates: 'cardforge.creator.studio.userTemplates.v2',
  versions: 'cardforge.creator.studio.versions.v2',
  recentCards: 'cardforge.creator.studio.recent.v2',
  uiPrefs: 'cardforge.creator.studio.ui.v2',
  conquestContext: 'cardforge.creator.conquest_context.v1',
};

const EXTERNAL_USER_PACK_CACHE_KEY = 'cardforge.external_user_packs.v1';
const CREATOR_USER_PACKS_DIR = '../user_packs';
const CREATOR_USER_PACKS_EXAMPLE = '../user_packs/examples/example_full_card_pack.json';

const RARITIES = ['common', 'rare', 'epic', 'legendary'];
const DUEL_TYPES = ['minion', 'spell', 'relic', 'field', 'trap', 'structure', 'token'];
const CONQUEST_TYPES = ['unit', 'building', 'facility', 'turret', 'barricade', 'equipment', 'upgrade', 'tactic', 'support'];
const HYBRID_TYPES = [...new Set([...DUEL_TYPES, ...CONQUEST_TYPES])];
const PREVIEW_MODES = ['full', 'hand', 'board', 'conquest'];
const DUEL_FAMILIES = RACE_LIBRARY
  .map((entry) => entry.id)
  .filter((id) => !['token', 'ship'].includes(id));
const ABILITY_TRIGGER_OPTIONS = [
  'battlecry', 'on_play', 'start_turn', 'end_turn', 'on_summon_friendly', 'on_minion_death', 'aura', 'passive',
  'deploy', 'capture', 'breach', 'repair', 'structure_destroyed', 'horde_formed', 'veteran_promoted', 'venerated_promoted',
  'synthesis_completed', 'attacker_turn_start', 'defender_turn_start', 'facility_damaged', 'lane_secured',
];
const ABILITY_TARGET_OPTIONS = [
  'self', 'friendly_minion', 'enemy_minion', 'all_friendly', 'all_enemy', 'hero', 'friendly_hand', 'friendly_deck',
  'lane', 'no_mans_land', 'friendly_structure', 'enemy_structure', 'horde', 'formation', 'veteran', 'venerated', 'evo',
  'attacker_reserve', 'attacker_deck', 'cell_class',
];
const ABILITY_EFFECT_OPTIONS = [
  'dealDamage', 'buffAttack', 'buffHealth', 'gainStats', 'draw', 'summon', 'reduceCost', 'gainFamiliarity', 'spendFamiliarity',
  'transform', 'copy', 'revive', 'repair', 'grantShield', 'capturePressure', 'summonFormation', 'spawnEquipment', 'laneFortify',
];
const ABILITY_ZONE_OPTIONS = ['board', 'hand', 'deck', 'graveyard'];
const CONQUEST_ELEMENT_OPTIONS = ['fire', 'water', 'forest', 'earth', 'storm', 'light', 'shadow', 'metal', 'arcane'];
const CONQUEST_ROLE_OPTIONS = ['frontline', 'backline', 'support', 'ranged', 'siege', 'engine', 'formation', 'hero', 'structure'];
const CONQUEST_BRANCH_OPTIONS = ['none', 'horde', 'formation', 'veteran', 'venerated', 'evo', 'hero', 'building', 'support'];
const CONQUEST_CELL_CLASS_OPTIONS = ['any', 'lane', 'lane-center', 'lane-edge', 'no-mans-land', 'frontline', 'backline', 'structure-slot'];

const KEYWORD_DEFS = [
  { key: 'taunt', label: 'Taunt' },
  { key: 'stealth', label: 'Stealth' },
  { key: 'charge', label: 'Charge' },
  { key: 'lifesteal', label: 'Lifesteal' },
  { key: 'flying', label: 'Flying' },
  { key: 'immune', label: 'Immune' },
  { key: 'horde', label: 'Horde' },
  { key: 'giant', label: 'Giant' },
  { key: 'siege', label: 'Siege' },
  { key: 'ranged', label: 'Ranged' },
  { key: 'antiAir', label: 'Anti-Air' },
  { key: 'structure', label: 'Structure' },
  { key: 'facility', label: 'Facility' },
  { key: 'turret', label: 'Turret' },
  { key: 'barricade', label: 'Barricade' },
  { key: 'vehicle', label: 'Vehicle' },
  { key: 'mech', label: 'Mech' },
  { key: 'command', label: 'Command' },
  { key: 'upgrade', label: 'Upgrade' },
  { key: 'equipment', label: 'Equipment' },
  { key: 'repair', label: 'Repair' },
];

const CONQUEST_SOURCES = [
  'training',
  'blacksmith',
  'factory',
  'command',
  'vehicle',
  'ordnance',
  'air_support',
  'power_shield',
  'recovery',
  'experimental',
];

const FALLBACK_ABILITY_TEMPLATES = [
  { id: 'tribal-board-buff', name: 'Race Board Scaling', category: 'race', trigger: 'battlecry', target: 'self', effect: { action: 'gainStats', amount: 1 }, family: 'dragon', familyZone: 'board', notes: 'For every Dragon you control, gain +1/+1.' },
  { id: 'tribal-threshold-draw', name: 'Race Threshold Draw', category: 'race', trigger: 'end_turn', target: 'self', effect: { action: 'draw', amount: 1 }, family: 'spirit', familyZone: 'board', threshold: 3, notes: 'If you control 3 or more Spirits, draw 1.' },
  { id: 'hand-family-discount', name: 'Family Hand Discount', category: 'cost', trigger: 'passive', target: 'self', effect: { action: 'reduceCost', amount: 1 }, family: 'dragon', familyZone: 'hand', notes: 'Costs (1) less for each Dragon in your hand.' },
  { id: 'gain-familiarity', name: 'Gain Familiarity', category: 'familiarity', trigger: 'on_summon_friendly', target: 'self', effect: { action: 'gainFamiliarity', amount: 1 }, family: 'beast', notes: 'Whenever you summon a Beast, gain 1 Beast Familiarity.' },
  { id: 'familiarity-threshold', name: 'Familiarity Threshold', category: 'familiarity', trigger: 'passive', target: 'friendly_minion', effect: { action: 'buffHealth', amount: 1 }, familiarityRace: 'human', familiarityThreshold: 3, notes: 'Human Familiarity 3: your followers get +1 Health.' },
  { id: 'dragon-brood-token', name: 'Dragon Brood Summon', category: 'dragon', trigger: 'battlecry', target: 'self', effect: { action: 'summon', amount: 1 }, family: 'dragonkin', tokenRace: 'dragonkin', notes: 'Battlecry: summon a Dragonkin token.' },
];

const PACK_SCHEMA_FIELD_DOCS = [
  { path: 'id', scope: 'pack', description: 'Stable slug for the imported pack.' },
  { path: 'name', scope: 'pack', description: 'Display name shown in compendium and shop.' },
  { path: 'description', scope: 'pack', description: 'Pack summary for players and merchants.' },
  { path: 'enabled', scope: 'pack', description: 'Set false to keep a JSON file dormant without deleting it.' },
  { path: 'exampleOnly', scope: 'pack', description: 'Marks sample files that should stay out of runtime loading.' },
  { path: 'mode', scope: 'pack', description: 'duel, conquest, or hybrid. Used for section placement and defaults.' },
  { path: 'collection', scope: 'pack', description: 'Default collection/group label for cards in the pack.' },
  { path: 'world', scope: 'pack', description: 'Default world or origin tag applied to cards.' },
  { path: 'defaultRarity', scope: 'pack', description: 'Fallback rarity if a card omits it.' },
  { path: 'defaultTags', scope: 'pack', description: 'CSV or array of tags added to every card.' },
  { path: 'defaultKeywords', scope: 'pack', description: 'Keyword array applied to every card unless overridden.' },
  { path: 'packType', scope: 'pack', description: 'booster, event, merchant, conquest, or custom label.' },
  { path: 'shopProduct / shopProducts[]', scope: 'pack', description: 'Optional store products referencing this pack.' },
  { path: 'shopProduct.id', scope: 'pack', description: 'Stable product id for the shop listing.' },
  { path: 'shopProduct.name', scope: 'pack', description: 'Shop-facing product label.' },
  { path: 'shopProduct.description', scope: 'pack', description: 'Player-facing product summary.' },
  { path: 'shopProduct.price', scope: 'pack', description: 'Gold price shown in the shop.' },
  { path: 'shopProduct.count', scope: 'pack', description: 'How many cards the pack awards when opened.' },
  { path: 'shopProduct.poolTag', scope: 'pack', description: 'Pool selector used to resolve which cards belong to the pack product.' },
  { path: 'shopProduct.weights', scope: 'pack', description: 'Optional rarity weights controlling pack opening odds.' },
  { path: 'shopProduct.pity.threshold', scope: 'pack', description: 'Optional pity timer miss threshold before a guaranteed rarity upgrade.' },
  { path: 'shopProduct.pity.rarity', scope: 'pack', description: 'The rarity guaranteed when the pity threshold is hit.' },
  { path: 'marketDefaults', scope: 'pack', description: 'Default merchant inclusion, sell value, and trade tuning for all cards.' },
  { path: 'marketDefaults.merchantInclusion', scope: 'pack', description: 'Default merchant, trader, or faction allow list for pack cards.' },
  { path: 'marketDefaults.merchantExclusion', scope: 'pack', description: 'Default merchant, trader, or faction block list for pack cards.' },
  { path: 'marketDefaults.sellValue', scope: 'pack', description: 'Default sell value applied to pack cards unless a card overrides it.' },
  { path: 'marketDefaults.buyValue', scope: 'pack', description: 'Default merchant buy price applied to pack cards unless overridden.' },
  { path: 'marketDefaults.baseValue', scope: 'pack', description: 'Default explicit valuation baseline used by the market runtime.' },
  { path: 'fieldDocumentation.pack[]', scope: 'pack', description: 'Optional self-documented field list inside example or tutorial packs.' },
  { path: 'fieldDocumentation.card[]', scope: 'pack', description: 'Optional self-documented card field list inside example or tutorial packs.' },
  { path: 'cards[]', scope: 'pack', description: 'Card array. Every entry is normalized into the live game catalog.' },
];

const CARD_SCHEMA_FIELD_DOCS = [
  { path: 'id', scope: 'card', description: 'Unique card id used by saves, decks, and shops.' },
  { path: 'name', scope: 'card', description: 'Player-facing card name.' },
  { path: 'type / cardType', scope: 'card', description: 'Card category such as minion, spell, unit, building, support, tactic, or equipment.' },
  { path: 'rarity', scope: 'card', description: 'common, rare, epic, legendary, or any custom rarity your runtime supports.' },
  { path: 'cost / mana / manaCost', scope: 'card', description: 'Primary duel mana cost.' },
  { path: 'wheatCost / ironCost', scope: 'card', description: 'Conquest resource costs.' },
  { path: 'attack / health / def / range / movement', scope: 'card', description: 'Combat stats and battlefield profile.' },
  { path: 'race / races / species / tribe / subtype', scope: 'card', description: 'Species, family, or unit identity fields used by compendium filters and gameplay.' },
  { path: 'element / primaryElement / secondaryElement', scope: 'card', description: 'Element identity and resonance fields.' },
  { path: 'text / description / rulesText / flavorText / lore', scope: 'card', description: 'Rules text, flavor, and lore presentation.' },
  { path: 'keywords[]', scope: 'card', description: 'Keyword list such as taunt, charge, flying, horde, repair, or equipment.' },
  { path: 'ability', scope: 'card', description: 'Single structured ability object.' },
  { path: 'ability.name / ability.text', scope: 'card', description: 'Optional human-readable name and explicit rules text for the primary ability block.' },
  { path: 'ability.trigger / ability.effect / ability.action / ability.amount / ability.target', scope: 'card', description: 'Core structured fields for compact primary abilities.' },
  { path: 'abilities[]', scope: 'card', description: 'Multi-block ability builder payload from the advanced creator.' },
  { path: 'abilities[].trigger', scope: 'card', description: 'Structured trigger such as battlecry, start_turn, deploy, breach, or lane_secured.' },
  { path: 'abilities[].target', scope: 'card', description: 'Target selector such as self, enemy_minion, lane, no_mans_land, formation, or evo.' },
  { path: 'abilities[].effect', scope: 'card', description: 'Structured effect such as draw, dealDamage, buffAttack, summon, repair, or capturePressure.' },
  { path: 'abilities[].condition / threshold / countThreshold', scope: 'card', description: 'Conditional gates and count checks for when the ability should fire.' },
  { path: 'abilities[].family / race / roleFilter / branchFilter', scope: 'card', description: 'Race, family, role, and conquest-branch filters used by the creator and compendium.' },
  { path: 'abilities[].sourceElement / targetElement', scope: 'card', description: 'Element-aware filtering for conquest and duel interactions.' },
  { path: 'abilities[].laneScope / targetCellClass / controller', scope: 'card', description: 'Lane, board cell, and controller routing for conquest-specific logic.' },
  { path: 'abilities[].effectScale / effectGrowth / effectCap', scope: 'card', description: 'Scaling controls for dynamic abilities and future power tuning.' },
  { path: 'tags[]', scope: 'card', description: 'Open-ended tags used by search, pack pools, merchants, and compendium filters.' },
  { path: 'packType / includeInPacks / localExclusive', scope: 'card', description: 'Pack/shop and legality controls for duel-mode content.' },
  { path: 'requiredModes / battleCompatibility', scope: 'card', description: 'Mode legality and compatibility routing.' },
  { path: 'metadata.collection / metadata.packName / metadata.world', scope: 'card', description: 'Collection and world presentation data shown in compendium, inspect, and shop surfaces.' },
  { path: 'metadata.role / metadata.notes / metadata.creatorTags', scope: 'card', description: 'High-level role summary, dev notes, and creator search tags.' },
  { path: 'mtgMeta.*', scope: 'card', description: 'Collection/world metadata mirror used by some runtime panels.' },
  { path: 'art.src', scope: 'card', description: 'External art URL or image source reference.' },
  { path: 'art.fit / art.x / art.y / art.zoom', scope: 'card', description: 'Crop and framing controls used by the creator preview.' },
  { path: 'art.overlay / art.background / art.emblem', scope: 'card', description: 'Overlay, background, emblem, or scene styling hooks.' },
  { path: 'art.frameTheme / art.frameTint', scope: 'card', description: 'Frame theme and tint color used by card rendering.' },
  { path: 'art.borderStyle / art.colorEffect', scope: 'card', description: 'Border styling and color-effect metadata for premium card presentation.' },
  { path: 'art.rarityBadge / art.notes', scope: 'card', description: 'Rarity badge visibility and art-production notes.' },
  { path: 'normal.race / normal.races / normal.element', scope: 'card', description: 'Duel-mode race and element metadata used by filters and rules text helpers.' },
  { path: 'normal.familiarity*', scope: 'card', description: 'Familiarity race, thresholds, rewards, and notes for duel-mode progression hooks.' },
  { path: 'normal.includeInPacks / normal.packType / normal.requiredModes', scope: 'card', description: 'Duel-mode pack distribution and legality controls.' },
  { path: 'conquest.side / conquest.branch / conquest.productionSource', scope: 'card', description: 'Attacker or defender side, conquest branch, and facility source routing.' },
  { path: 'conquest.isBuilding / isTurret / isBarricade / isFacility', scope: 'card', description: 'Battlefield structure flags used by conquest placement and rules.' },
  { path: 'conquest.isUpgrade / isEquipment / isHero / isLand', scope: 'card', description: 'Conquest-specific identity flags for upgrades, equipment, heroes, and mana lands.' },
  { path: 'conquest.generatedConquestOnly / localMultiplayerExcluded', scope: 'card', description: 'Legality flags that keep conquest-only content out of local multiplayer.' },
  { path: 'targeting.source / scope / team', scope: 'card', description: 'Who can use the card and what target scope it operates across.' },
  { path: 'targeting.placementRule / requirement / lineOfFire', scope: 'card', description: 'Placement restrictions and fire-line notes for conquest cards.' },
  { path: 'targeting.laneScope / cellClass / controller / filters', scope: 'card', description: 'Conquest lane and cell targeting data for structured rules text.' },
  { path: 'tokenLinks.summons / generatedBy / upgradesInto / equipmentLinks', scope: 'card', description: 'Linked-card references for tokens, evolutions, equipment, and generated units.' },
  { path: 'production', scope: 'card', description: 'Per-card production metadata for conquest factories, queues, or resource systems.' },
  { path: 'campaignMeta.originWorldId / originPlanetId / blueprintId', scope: 'card', description: 'Campaign origin and blueprint lineage hooks for conquest content.' },
  { path: 'campaignMeta.generatorSeed / lineage / discoveryLineage', scope: 'card', description: 'Seed and lineage tracking for generated or transformed conquest cards.' },
  { path: 'merchantInclusion / merchantExclusion', scope: 'card', description: 'Explicit merchant/faction allow and block lists.' },
  { path: 'sellValue / buyValue / baseValue', scope: 'card', description: 'Optional explicit market valuation overrides.' },
  { path: 'market.merchantInclusion / market.merchantExclusion', scope: 'card', description: 'Grouped merchant routing controls kept inside a market object.' },
  { path: 'market.sellValue / market.buyValue / market.baseValue', scope: 'card', description: 'Grouped valuation overrides respected by the market runtime.' },
  { path: 'customMade / sourceType / creatorStudioVersion', scope: 'card', description: 'Provenance and creator metadata.' },
];

const RACE_ARCHETYPE_PRESETS = {
  dragon_flight: {
    label: 'Dragon Flight',
    races: ['dragon'],
    synergy: 'dragon,flying,fire,hoard',
    role: 'Dragon finisher / aerial threat',
    keywords: { flying: true },
  },
  brood_swarm: {
    label: 'Brood Swarm',
    races: ['dragonkin', 'dragon'],
    synergy: 'dragonkin,tokens,brood,tempo',
    role: 'Brood swarm / hatchling engine',
  },
  spirit_choir: {
    label: 'Spirit Choir',
    races: ['spirit', 'wraith'],
    synergy: 'spirit,death,value,echo',
    role: 'Spirit recursion / threshold payoff',
  },
  beast_pack: {
    label: 'Beast Pack',
    races: ['beast'],
    synergy: 'beast,pack,tempo,heal',
    role: 'Beast pressure / familiarity payoff',
  },
};

const BUILTIN_TEMPLATES = [
  {
    id: 'tmpl-basic-minion',
    label: 'Basic Minion',
    mode: 'duel',
    type: 'minion',
    summary: 'Simple baseline creature.',
    patch: { cost: { mana: 2 }, stats: { attack: 2, health: 2 }, text: 'No text.' },
  },
  {
    id: 'tmpl-spell-buff',
    label: 'Buff Spell',
    mode: 'duel',
    type: 'spell',
    summary: 'Targeted buff spell shell.',
    patch: { cost: { mana: 2 }, normal: { damage: 0 }, text: 'Give a friendly minion +2/+2 this turn.' },
  },
  {
    id: 'tmpl-relic',
    label: 'Relic Engine',
    mode: 'duel',
    type: 'relic',
    summary: 'Passive relic setup.',
    patch: { cost: { mana: 3 }, text: 'At the end of your turn, trigger a small effect.' },
  },
  {
    id: 'tmpl-field',
    label: 'Field Rule',
    mode: 'duel',
    type: 'field',
    summary: 'Board-wide continuous rule.',
    patch: { cost: { mana: 4 }, text: 'At end of turn, apply a board effect.' },
  },
  {
    id: 'tmpl-dragon-hatchling',
    label: 'Dragon Hatchling',
    mode: 'duel',
    type: 'minion',
    summary: 'Low-cost dragonkin setup piece.',
    patch: { cost: { mana: 1 }, stats: { attack: 1, health: 2 }, normal: { race: 'dragonkin', races: 'dragonkin, dragon' }, metadata: { role: 'Dragon opener' }, text: 'Battlecry: gain 1 Dragon Familiarity.' },
  },
  {
    id: 'tmpl-elder-dragon',
    label: 'Elder Dragon',
    mode: 'duel',
    type: 'minion',
    summary: 'Legendary dragon finisher shell.',
    patch: { rarity: 'legendary', cost: { mana: 8 }, stats: { attack: 7, health: 9 }, keywords: { flying: true }, normal: { race: 'dragon', races: 'dragon, ancient' }, metadata: { role: 'Dragon finisher' }, text: 'Battlecry: deal 3 damage split among enemies.' },
  },
  {
    id: 'tmpl-race-lord',
    label: 'Race Lord',
    mode: 'duel',
    type: 'minion',
    summary: 'Board-wide race champion shell.',
    patch: { cost: { mana: 4 }, stats: { attack: 3, health: 5 }, normal: { race: 'beast', races: 'beast' }, metadata: { role: 'Race lord' }, text: 'Aura: Your chosen race has +1 Attack.' },
  },
  {
    id: 'tmpl-conquest-unit',
    label: 'Conquest Unit',
    mode: 'conquest',
    type: 'unit',
    summary: 'Frontline conquest unit shell.',
    patch: { cost: { wheat: 2, iron: 1 }, stats: { attack: 2, health: 3, range: 1, movement: 1 }, conquest: { side: 'defender', productionSource: 'training' } },
  },
  {
    id: 'tmpl-conquest-building',
    label: 'Conquest Building',
    mode: 'conquest',
    type: 'building',
    summary: 'Production/utility structure.',
    patch: { cost: { wheat: 2, iron: 2 }, stats: { attack: 0, health: 6 }, conquest: { isBuilding: true, productionSource: 'factory' } },
  },
  {
    id: 'tmpl-turret',
    label: 'Turret',
    mode: 'conquest',
    type: 'turret',
    summary: 'Ranged defensive emplacement.',
    patch: { cost: { wheat: 1, iron: 3 }, stats: { attack: 3, health: 4, range: 2 }, conquest: { isBuilding: true, isTurret: true, productionSource: 'factory' }, keywords: { turret: true, ranged: true } },
  },
  {
    id: 'tmpl-barricade',
    label: 'Barricade',
    mode: 'conquest',
    type: 'barricade',
    summary: 'Lane blocking fortification.',
    patch: { cost: { wheat: 2, iron: 2 }, stats: { attack: 0, health: 8 }, conquest: { isBuilding: true, isBarricade: true, productionSource: 'command' }, keywords: { barricade: true, structure: true } },
  },
  {
    id: 'tmpl-weapon-upgrade',
    label: 'Weapon Upgrade',
    mode: 'conquest',
    type: 'upgrade',
    summary: 'Blacksmith upgrade shell.',
    patch: { cost: { wheat: 0, iron: 3 }, conquest: { isUpgrade: true, productionSource: 'blacksmith' }, keywords: { upgrade: true }, text: 'Attach to a unit. Gain +2 attack.' },
  },
  {
    id: 'tmpl-armour',
    label: 'Armour Equipment',
    mode: 'conquest',
    type: 'equipment',
    summary: 'Durability-focused equipment.',
    patch: { cost: { wheat: 1, iron: 2 }, conquest: { isEquipment: true, productionSource: 'blacksmith' }, keywords: { equipment: true }, text: 'Equip to friendly unit. Gain +0/+3.' },
  },
  {
    id: 'tmpl-horde',
    label: 'Horde Unit',
    mode: 'conquest',
    type: 'unit',
    summary: 'Low-cost swarm attacker.',
    patch: { cost: { wheat: 2, iron: 0 }, stats: { attack: 1, health: 2 }, keywords: { horde: true }, conquest: { side: 'attacker', productionSource: 'training' } },
  },
  {
    id: 'tmpl-giant',
    label: 'Giant Unit',
    mode: 'conquest',
    type: 'unit',
    summary: 'Large lane breaker.',
    patch: { cost: { wheat: 4, iron: 5 }, stats: { attack: 7, health: 10, range: 1, movement: 1 }, keywords: { giant: true, siege: true } },
  },
  {
    id: 'tmpl-flying',
    label: 'Flying Unit',
    mode: 'hybrid',
    type: 'unit',
    summary: 'Mobility-focused flyer.',
    patch: { cost: { mana: 4, wheat: 2, iron: 2 }, stats: { attack: 4, health: 3, range: 2 }, keywords: { flying: true, ranged: true } },
  },
  {
    id: 'tmpl-summon-spell',
    label: 'Summon Spell',
    mode: 'duel',
    type: 'spell',
    summary: 'Token generator spell shell.',
    patch: { cost: { mana: 3 }, text: 'Summon two 1/1 tokens.' },
  },
  {
    id: 'tmpl-heal-spell',
    label: 'Healing Spell',
    mode: 'duel',
    type: 'spell',
    summary: 'Single target healing.',
    patch: { cost: { mana: 2 }, text: 'Restore 4 Health to a friendly character.' },
  },
  {
    id: 'tmpl-legendary-buildaround',
    label: 'Legendary Build-around',
    mode: 'hybrid',
    type: 'minion',
    summary: 'High complexity legendary shell.',
    patch: { rarity: 'legendary', cost: { mana: 7, wheat: 4, iron: 4 }, stats: { attack: 6, health: 8 }, text: 'Build-around payoff effect.' },
  },
  {
    id: 'tmpl-conquest-support',
    label: 'Conquest Support',
    mode: 'conquest',
    type: 'support',
    summary: 'Command support action.',
    patch: { cost: { wheat: 3, iron: 1 }, conquest: { productionSource: 'command' }, keywords: { command: true }, text: 'Support your lane with tactical orders.' },
  },
];

const state = {
  ready: false,
  ui: {
    mode: 'duel',
    experience: 'beginner',
    workspace: 'balanced',
    moduleSearch: '',
    commandQuery: '',
    leftCollapsed: false,
    rightCollapsed: false,
    bottomCollapsed: false,
    moduleOrder: [],
    moduleCollapsed: {},
    modulePinned: {},
    abilityCollapsed: {},
    activeModule: 'identity',
    previewMode: 'full',
    previewShowTags: true,
    previewZoom: 1,
    bottomTab: 'activity',
    commandOpen: false,
  },
  draft: null,
  activity: [],
  validation: { errors: [], warnings: [] },
  abilityTemplates: [],
  pluginTemplates: [],
  externalUserPacks: [],
  userTemplates: [],
  cardLibrary: {},
  profile: {},
  versions: [],
  recentCards: [],
  history: { stack: [], index: -1 },
  autosave: { pending: null, label: 'Autosave idle', at: 0 },
  conquestContext: null,
};

function safeClone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function uid(prefix = 'id') {
  if (globalThis.crypto?.randomUUID) return `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
  return `${prefix}-${Math.random().toString(16).slice(2, 10)}`;
}

function num(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function bool(value) {
  return !!value;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function slug(value = '') {
  return String(value).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function parseCsv(value = '') {
  return String(value || '')
    .split(',')
    .map((entry) => slug(entry))
    .filter(Boolean);
}

function uniqCompact(values = []) {
  return [...new Set((values ?? []).map((entry) => String(entry ?? '').trim()).filter(Boolean))];
}

function titleCaseWords(value = '') {
  return String(value ?? '')
    .split(/[\s_-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

async function loadRemoteJson(path, fallback = null) {
  try {
    const response = await fetch(path);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch {
    return fallback;
  }
}

function joinRelativePath(baseDir = '.', target = '') {
  if (/^(https?:)?\//i.test(target)) return target;
  const stack = baseDir.replace(/\\/g, '/').split('/').filter(Boolean);
  String(target ?? '').replace(/\\/g, '/').split('/').forEach((part) => {
    if (!part || part === '.') return;
    if (part === '..') stack.pop();
    else stack.push(part);
  });
  return `./${stack.join('/')}`.replace('./../', '../');
}

function shouldIgnoreExternalPackPath(path = '') {
  const normalized = String(path ?? '').toLowerCase();
  return normalized.includes('/examples/')
    || normalized.includes('/disabled/')
    || normalized.includes('/_disabled/')
    || normalized.endsWith('/index.json')
    || normalized.includes('.example.');
}

async function discoverExternalPackPaths(baseDir = CREATOR_USER_PACKS_DIR) {
  const discovered = new Set();
  const manifest = await loadRemoteJson(`${baseDir}/index.json`, null);
  const manifestEntries = Array.isArray(manifest?.entries) ? manifest.entries : Array.isArray(manifest?.packs) ? manifest.packs : [];
  manifestEntries.forEach((entry) => {
    const raw = typeof entry === 'string' ? entry : entry?.file ?? entry?.path ?? entry?.src;
    if (!raw) return;
    const resolved = joinRelativePath(baseDir, raw);
    if (!shouldIgnoreExternalPackPath(resolved)) discovered.add(resolved);
  });
  try {
    const response = await fetch(`${baseDir}/`);
    if (response.ok) {
      const html = await response.text();
      [...html.matchAll(/href="([^"]+\.json)"/gi)].forEach((match) => {
        const href = String(match[1] ?? '').trim();
        if (!href) return;
        const resolved = href.startsWith('./') || href.startsWith('../') || href.startsWith('/')
          ? href
          : joinRelativePath(baseDir, href.replace(/&amp;/g, '&'));
        if (!shouldIgnoreExternalPackPath(resolved)) discovered.add(resolved);
      });
    }
  } catch {}
  return [...discovered];
}

function normalizeExternalPackCard(card = {}, pack = {}, index = 0) {
  const metadata = card.metadata && typeof card.metadata === 'object' ? { ...card.metadata } : {};
  return {
    ...card,
    id: String(card.id ?? slug(`${pack.id || 'user-pack'}-${card.name ?? `card-${index + 1}`}`)),
    name: String(card.name ?? `Imported Card ${index + 1}`),
    rarity: String(card.rarity ?? pack.defaultRarity ?? 'common').toLowerCase(),
    metadata: {
      ...metadata,
      collection: card.collection ?? metadata.collection ?? pack.collection ?? pack.name ?? '',
      packName: card.packName ?? metadata.packName ?? pack.name ?? '',
      world: card.world ?? metadata.world ?? pack.world ?? '',
      packId: pack.id,
    },
    keywords: uniqCompact([...(Array.isArray(card.keywords) ? card.keywords : []), ...(Array.isArray(pack.defaultKeywords) ? pack.defaultKeywords : [])]),
    tags: uniqCompact([
      ...(Array.isArray(card.tags) ? card.tags : []),
      ...String(metadata.tags ?? '').split(','),
      ...String(pack.defaultTags ?? '').split(','),
      'json-pack',
      pack.id,
    ]).map((entry) => slug(entry)),
    market: {
      ...(pack.marketDefaults && typeof pack.marketDefaults === 'object' ? pack.marketDefaults : {}),
      ...(card.market && typeof card.market === 'object' ? card.market : {}),
    },
    userPackId: pack.id,
    sourceType: 'json-pack',
  };
}

function normalizeExternalPack(raw = {}, path = '') {
  const id = String(raw.id ?? path.split('/').pop()?.replace(/\.json$/i, '') ?? 'user-pack').toLowerCase();
  return {
    ...raw,
    id,
    name: String(raw.name ?? titleCaseWords(id)),
    mode: String(raw.mode ?? 'hybrid').toLowerCase(),
    cards: (Array.isArray(raw.cards) ? raw.cards : []).map((card, index) => normalizeExternalPackCard(card, { ...raw, id }, index)),
  };
}

function cardModeFlags(card = {}) {
  const requiredModes = String(card.requiredModes ?? card.conquest?.requiredModes ?? card.normal?.requiredModes ?? '').toLowerCase();
  const type = String(card.type ?? card.cardType ?? '').toLowerCase();
  const conquestType = CONQUEST_TYPES.includes(type);
  const duelType = DUEL_TYPES.includes(type);
  const conquest = !!(card.conquest?.generatedConquestOnly || /conquest/.test(requiredModes) || (card.conquest?.side && conquestType) || conquestType);
  const duel = /duel|normal/.test(requiredModes) || duelType || (!conquest);
  return { duel, conquest };
}

function creatorCatalogCards() {
  const merged = new Map();
  const sources = [
    ...Object.values(state.cardLibrary ?? {}),
    ...registry.list('creatorCardPacks').flatMap((pack) => pack.cards ?? []),
    ...registry.list('sharedCardPacks').flatMap((pack) => pack.cards ?? []),
    ...state.externalUserPacks.flatMap((pack) => pack.cards ?? []),
  ];
  sources.forEach((card) => {
    if (card?.id) merged.set(String(card.id), safeClone(card));
  });
  return [...merged.values()];
}

function normalizeFamilyId(value = '') {
  return DUEL_FAMILIES.includes(slug(value)) ? slug(value) : '';
}

function draftRaceList() {
  const races = new Set(parseCsv(state.draft?.normal?.races || ''));
  const primary = normalizeFamilyId(state.draft?.normal?.race || '');
  if (primary) races.add(primary);
  return [...races];
}

function setDraftRaceList(nextList = []) {
  const clean = [...new Set(nextList.map((entry) => normalizeFamilyId(entry)).filter(Boolean))];
  state.draft.normal.races = clean.join(', ');
  state.draft.normal.race = clean[0] ?? '';
}

function familiarityLabel(family = '') {
  const meta = raceMeta(family || 'dragon');
  return `${raceIconGlyph(meta.id)} ${meta.label}`;
}

function selectedRaceSummary() {
  const races = draftRaceList();
  return races.length ? races.map((entry) => raceMeta(entry).label).join(' / ') : 'Neutral';
}

function generatedRulesText() {
  const manual = String(state.draft.text || '').trim();
  const abilityText = state.draft.abilities.map((ability) => abilitySummary(ability)).filter(Boolean);
  return [manual, ...abilityText].filter(Boolean).join('\n');
}

function archetypeSuggestion() {
  const races = draftRaceList();
  if (races.includes('dragon')) return 'Dragon pressure / flying payoff';
  if (races.includes('spirit')) return 'Spirit threshold / echo value';
  if (races.includes('beast')) return 'Beast curve / familiarity tempo';
  if (races.includes('construct')) return 'Construct board-control shell';
  return state.draft.metadata.role || 'Flexible custom archetype';
}

function loadJsonStorage(key, fallback) {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) || '');
    return parsed && typeof parsed === 'object' ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function saveJsonStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function byPathGet(obj, path, fallback = undefined) {
  const parts = String(path || '').split('.').filter(Boolean);
  let ref = obj;
  for (const part of parts) {
    if (!ref || typeof ref !== 'object') return fallback;
    ref = ref[part];
  }
  return ref === undefined ? fallback : ref;
}

function byPathSet(obj, path, value) {
  const parts = String(path || '').split('.').filter(Boolean);
  if (!parts.length) return;
  let ref = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const key = parts[i];
    if (!ref[key] || typeof ref[key] !== 'object') ref[key] = {};
    ref = ref[key];
  }
  ref[parts[parts.length - 1]] = value;
}

function mergeDeep(target, patch) {
  if (!patch || typeof patch !== 'object') return target;
  Object.entries(patch).forEach(([key, value]) => {
    if (Array.isArray(value)) target[key] = value.slice();
    else if (value && typeof value === 'object') {
      target[key] = target[key] && typeof target[key] === 'object' ? target[key] : {};
      mergeDeep(target[key], value);
    } else target[key] = value;
  });
  return target;
}

function parseGenVersion(tags = []) {
  for (const tag of Array.isArray(tags) ? tags : []) {
    const match = String(tag).toUpperCase().match(/^GEN(\d+)$/);
    if (match) return Number(match[1]);
  }
  return 1;
}

function persistCustomCard(card) {
  if (!card?.id) return { savedCard: card, isNew: false };
  const library = loadJsonStorage(STORAGE.customCards, {});
  const existing = library[card.id] ?? null;
  const now = Date.now();
  const nextGen = existing ? Number(existing.genVersion ?? 1) + 1 : parseGenVersion(card.tags ?? []);
  const sourceTags = new Set([...(card.tags ?? []), 'custom-made']);
  const savedCard = {
    ...existing,
    ...card,
    tags: [...sourceTags],
    genVersion: nextGen,
    customMade: true,
    sourceType: 'custom-made',
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };
  library[card.id] = savedCard;
  saveJsonStorage(STORAGE.customCards, library);

  const profile = loadJsonStorage(STORAGE.profile, {});
  profile.collection = profile.collection ?? {};
  profile.collection[savedCard.id] = Number(profile.collection[savedCard.id] ?? 0);
  if (!existing) profile.collection[savedCard.id] += 1;
  saveJsonStorage(STORAGE.profile, profile);
  state.cardLibrary = library;
  state.profile = profile;
  return { savedCard, isNew: !existing };
}

function typeOptionsForMode(mode = state.ui.mode) {
  if (mode === 'duel') return DUEL_TYPES;
  if (mode === 'conquest') return CONQUEST_TYPES;
  return HYBRID_TYPES;
}

function createAbilityBlock(preset = null) {
  return {
    id: uid('ability'),
    name: preset?.name ?? 'New Ability',
    trigger: preset?.trigger ?? 'battlecry',
    target: preset?.target ?? 'enemy_minion',
    condition: '',
    effect: preset?.effect?.action ?? 'dealDamage',
    amount: num(preset?.effect?.amount, 1),
    duration: 1,
    filters: '',
    scope: 'single',
    family: preset?.family ?? '',
    familyZone: preset?.familyZone ?? 'board',
    sourceFamily: preset?.sourceFamily ?? '',
    targetFamily: preset?.targetFamily ?? '',
    controllerFamily: preset?.controllerFamily ?? '',
    deadFamily: preset?.deadFamily ?? '',
    threshold: num(preset?.threshold, 0),
    familiarityRace: preset?.familiarityRace ?? '',
    familiarityAmount: num(preset?.familiarityAmount, 0),
    familiarityThreshold: num(preset?.familiarityThreshold, 0),
    deckRule: '',
    tokenRace: preset?.tokenRace ?? '',
    counterKey: '',
    timing: 'instant',
    oncePerTurn: false,
    cooldown: 0,
    charges: 0,
    sourceElement: '',
    targetElement: '',
    roleFilter: '',
    branchFilter: 'none',
    targetCellClass: 'any',
    laneScope: '',
    countThreshold: 0,
    effectScale: 'flat',
    effectGrowth: 0,
    effectCap: 0,
    notes: '',
    script: '',
    templateId: preset?.id ?? '',
  };
}

function createDefaultDraft(mode = 'duel') {
  return {
    id: '',
    name: '',
    mode,
    type: mode === 'conquest' ? 'unit' : 'minion',
    rarity: 'common',
    text: '',
    cost: { mana: 1, wheat: 0, iron: 0 },
    stats: { attack: 1, health: 1, defense: 0, range: 1, movement: 1 },
    keywords: Object.fromEntries(KEYWORD_DEFS.map((entry) => [entry.key, false])),
    targeting: {
      source: 'any',
      scope: 'single',
      team: 'enemy',
      placement: '',
      requirement: '',
      filters: '',
      lineOfFire: '',
      laneScope: '',
      cellClass: 'any',
      controller: 'either',
      countThreshold: 0,
    },
    art: {
      src: '',
      fit: 'cover',
      x: 50,
      y: 50,
      zoom: 1,
      overlay: '',
      frameTheme: 'default',
      frameTint: '#3ad4c6',
      background: '',
      emblem: '',
      rarityBadge: true,
      notes: '',
    },
    metadata: {
      collection: '',
      packName: 'Gen 4 Booster',
      world: '',
      generation: 'Gen 4',
      tags: '',
      productionSource: '',
      role: '',
      notes: '',
      creatorTags: '',
    },
    normal: {
      race: '',
      races: '',
      element: '',
      damage: 0,
      synergy: '',
      familiarityRace: '',
      familiarityStart: 0,
      familiarityThreshold: 0,
      familiarityReward: '',
      familiarityNotes: '',
      battleCompatibility: 'both',
      requiredModes: '',
      localExclusive: false,
      homeDimension: '',
      includeInPacks: true,
      packType: 'booster',
      catchLimit: 0,
    },
    conquest: {
      side: 'defender',
      productionSource: 'training',
      buildingType: '',
      isBuilding: false,
      isTurret: false,
      isBarricade: false,
      isFacility: false,
      isUpgrade: false,
      isEquipment: false,
      homestead: false,
      pylon: false,
      horde: false,
      giant: false,
      flying: false,
      siege: false,
      attackRange: 1,
      movement: 1,
      battleCompatibility: 'both',
      requiredModes: '',
      producible: true,
      generatedConquestOnly: true,
      localMultiplayerExcluded: true,
      conquestBranch: 'standard',
    },
    tokenLinks: {
      summons: '',
      generatedBy: '',
      upgradesInto: '',
      equippedBy: '',
    },
    abilities: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    creatorStudioVersion: 2,
  };
}

function applyModeDefaults(mode) {
  state.ui.mode = mode;
  state.draft.mode = mode;
  const options = typeOptionsForMode(mode);
  if (!options.includes(state.draft.type)) state.draft.type = options[0];
}

function pushHistory(reason = 'change') {
  const snapshot = {
    draft: safeClone(state.draft),
    ui: {
      mode: state.ui.mode,
      experience: state.ui.experience,
      workspace: state.ui.workspace,
      previewMode: state.ui.previewMode,
      previewShowTags: state.ui.previewShowTags,
      previewZoom: state.ui.previewZoom,
      moduleCollapsed: { ...state.ui.moduleCollapsed },
      modulePinned: { ...state.ui.modulePinned },
      moduleOrder: state.ui.moduleOrder.slice(),
    },
    reason,
    at: Date.now(),
  };
  state.history.stack = state.history.stack.slice(0, state.history.index + 1);
  state.history.stack.push(snapshot);
  if (state.history.stack.length > 120) state.history.stack.shift();
  state.history.index = state.history.stack.length - 1;
}

function restoreHistory(index) {
  const snap = state.history.stack[index];
  if (!snap) return;
  state.history.index = index;
  state.draft = safeClone(snap.draft);
  state.ui.mode = snap.ui.mode;
  state.ui.experience = snap.ui.experience;
  state.ui.workspace = snap.ui.workspace;
  state.ui.previewMode = snap.ui.previewMode;
  state.ui.previewShowTags = snap.ui.previewShowTags;
  state.ui.previewZoom = snap.ui.previewZoom;
  state.ui.moduleCollapsed = { ...snap.ui.moduleCollapsed };
  state.ui.modulePinned = { ...snap.ui.modulePinned };
  state.ui.moduleOrder = snap.ui.moduleOrder.slice();
  queueAutosave();
  validateDraft();
  renderAll();
  logActivity(`History restored (${snap.reason}).`);
}

function undo() {
  if (state.history.index <= 0) return;
  restoreHistory(state.history.index - 1);
}

function redo() {
  if (state.history.index >= state.history.stack.length - 1) return;
  restoreHistory(state.history.index + 1);
}

function queueAutosave() {
  if (state.autosave.pending) clearTimeout(state.autosave.pending);
  state.autosave.label = 'Autosave pending...';
  renderStatusRow();
  state.autosave.pending = setTimeout(() => {
    state.autosave.pending = null;
    saveProjectDraft();
  }, 550);
}

function saveProjectDraft() {
  const payload = {
    draft: state.draft,
    ui: {
      mode: state.ui.mode,
      experience: state.ui.experience,
      workspace: state.ui.workspace,
      moduleOrder: state.ui.moduleOrder,
      moduleCollapsed: state.ui.moduleCollapsed,
      modulePinned: state.ui.modulePinned,
      previewMode: state.ui.previewMode,
      previewShowTags: state.ui.previewShowTags,
      previewZoom: state.ui.previewZoom,
      bottomTab: state.ui.bottomTab,
    },
    updatedAt: Date.now(),
  };
  saveJsonStorage(STORAGE.projectDraft, payload);
  state.autosave.at = Date.now();
  state.autosave.label = `Autosaved ${new Date(state.autosave.at).toLocaleTimeString()}`;
  renderStatusRow();
}

function loadProjectDraft(options = {}) {
  const preserveMode = !!options.preserveMode;
  const forcedMode = String(options.forcedMode || '').trim().toLowerCase();
  const payload = loadJsonStorage(STORAGE.projectDraft, null);
  if (!payload?.draft) return false;
  const resolvedMode = forcedMode || (preserveMode ? state.ui.mode : (payload.ui?.mode ?? payload.draft?.mode ?? state.ui.mode));
  state.draft = mergeDeep(createDefaultDraft(resolvedMode), safeClone(payload.draft));
  if (payload.ui) {
    if (!forcedMode && !preserveMode) {
      state.ui.mode = payload.ui.mode ?? payload.draft?.mode ?? state.ui.mode;
    }
    state.ui.experience = payload.ui.experience ?? state.ui.experience;
    state.ui.workspace = payload.ui.workspace ?? state.ui.workspace;
    state.ui.moduleOrder = Array.isArray(payload.ui.moduleOrder) ? payload.ui.moduleOrder.slice() : state.ui.moduleOrder;
    state.ui.moduleCollapsed = payload.ui.moduleCollapsed ?? state.ui.moduleCollapsed;
    state.ui.modulePinned = payload.ui.modulePinned ?? state.ui.modulePinned;
    state.ui.previewMode = payload.ui.previewMode ?? state.ui.previewMode;
    state.ui.previewShowTags = payload.ui.previewShowTags ?? state.ui.previewShowTags;
    state.ui.previewZoom = payload.ui.previewZoom ?? state.ui.previewZoom;
    state.ui.bottomTab = payload.ui.bottomTab ?? state.ui.bottomTab;
  }
  if (forcedMode) {
    state.ui.mode = forcedMode;
    state.draft.mode = forcedMode;
  }
  return true;
}

function complexityScore() {
  const keywordCount = KEYWORD_DEFS.filter((def) => state.draft.keywords[def.key]).length;
  const abilityCount = state.draft.abilities.length;
  const costWeight = num(state.draft.cost.mana, 0) + num(state.draft.cost.wheat, 0) + num(state.draft.cost.iron, 0);
  const statWeight = num(state.draft.stats.attack, 0) + num(state.draft.stats.health, 0) + num(state.draft.stats.range, 0) + num(state.draft.stats.movement, 0);
  const textWeight = Math.ceil((state.draft.text || '').length / 70);
  return clamp(keywordCount + (abilityCount * 3) + Math.round(costWeight * 0.7) + Math.round(statWeight * 0.45) + textWeight, 1, 100);
}

function complexityTier(score) {
  if (score < 18) return 'Simple';
  if (score < 34) return 'Moderate';
  if (score < 55) return 'Advanced';
  return 'Expert';
}

function draftTagsArray() {
  return String(state.draft.metadata.tags || '')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function raceChipMarkup(selected = []) {
  return DUEL_FAMILIES.map((family) => {
    const meta = raceMeta(family);
    const active = selected.includes(family);
    return `<button type="button" class="race-chip ${active ? 'active' : ''}" data-action="toggle-race-tag" data-race="${family}">${raceIconGlyph(family)} ${escapeHtml(meta.label)}</button>`;
  }).join('');
}

function raceArchetypeMarkup() {
  return Object.entries(RACE_ARCHETYPE_PRESETS).map(([id, preset]) => (
    `<button type="button" class="ghost" data-action="apply-race-archetype" data-archetype="${id}">${escapeHtml(preset.label)}</button>`
  )).join('');
}

function moduleStatus(moduleId) {
  const errors = state.validation.errors.filter((item) => item.module === moduleId);
  const warnings = state.validation.warnings.filter((item) => item.module === moduleId);
  if (errors.length) return { tone: 'bad', label: `${errors.length} issue(s)` };
  if (warnings.length) return { tone: 'warn', label: `${warnings.length} warning(s)` };
  return { tone: 'good', label: 'Complete' };
}

function moduleRegistry() {
  return [
    { id: 'identity', title: 'Card Identity', subtitle: 'Name, ID, rarity, primary text', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderIdentityModule },
    { id: 'type-mode', title: 'Type & Mode', subtitle: 'Card type + mode behavior', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderTypeModeModule },
    { id: 'costs-stats', title: 'Costs & Stats', subtitle: 'Mana/resources and combat stats', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderCostsStatsModule },
    { id: 'race-familiarity', title: 'Race & Familiarity', subtitle: 'Species identity, tribe mix and familiarity growth', modes: ['duel', 'hybrid'], levels: ['beginner', 'advanced'], render: renderRaceFamiliarityModule },
    { id: 'keywords', title: 'Keywords', subtitle: 'Fast tactical markers and identities', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderKeywordsModule },
    { id: 'abilities', title: 'Ability Builder', subtitle: 'Composable trigger-condition-effect blocks', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderAbilityModule },
    { id: 'targeting', title: 'Targeting & Rules', subtitle: 'Target filters and placement restrictions', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderTargetingModule },
    { id: 'art-frame', title: 'Art / PNG / Overlay Studio', subtitle: 'Upload, crop, frame and readability checks', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderArtModule },
    { id: 'normal-options', title: 'Normal Mode Options', subtitle: 'Duel-specific metadata and behaviors', modes: ['duel', 'hybrid'], levels: ['beginner', 'advanced'], render: renderNormalModeModule },
    { id: 'conquest-options', title: 'Conquest Options', subtitle: 'Production source, side and structure flags', modes: ['conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderConquestModule },
    { id: 'tokens-links', title: 'Tokens / Linked Cards', subtitle: 'Generated cards and relationships', modes: ['duel', 'conquest', 'hybrid'], levels: ['advanced'], render: renderTokenLinksModule },
    { id: 'collection-meta', title: 'Collection Metadata', subtitle: 'Pack, collection, role and tags', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderCollectionModule },
    { id: 'compendium', title: 'Compendium & JSON Schema', subtitle: 'Live abilities, rarities, races, and import field documentation', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderCompendiumModule },
    { id: 'templates', title: 'Template Library', subtitle: 'Start from preset archetypes', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderTemplatesModule },
    { id: 'validation', title: 'Validation', subtitle: 'Schema and gameplay safety checks', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderValidationModule },
    { id: 'save-export', title: 'Save / Export / Clone', subtitle: 'Persistence and interchange', modes: ['duel', 'conquest', 'hybrid'], levels: ['beginner', 'advanced'], render: renderSaveExportModule },
  ];
}

function visibleModules() {
  const modules = moduleRegistry().filter((mod) => mod.modes.includes(state.ui.mode) && mod.levels.includes(state.ui.experience));
  const order = state.ui.moduleOrder.length ? state.ui.moduleOrder : modules.map((mod) => mod.id);
  const orderIndex = new Map(order.map((id, idx) => [id, idx]));
  modules.sort((a, b) => (orderIndex.get(a.id) ?? 999) - (orderIndex.get(b.id) ?? 999));
  modules.sort((a, b) => {
    const aPinned = state.ui.modulePinned[a.id] ? 1 : 0;
    const bPinned = state.ui.modulePinned[b.id] ? 1 : 0;
    return bPinned - aPinned;
  });
  const q = state.ui.moduleSearch.trim().toLowerCase();
  if (!q) return modules;
  return modules.filter((mod) => `${mod.title} ${mod.subtitle}`.toLowerCase().includes(q));
}

function syncTopbarSelections() {
  const modeSelect = document.querySelector('#creator-card-mode');
  const expSelect = document.querySelector('#creator-experience');
  const typeSelect = document.querySelector('#creator-type-quick');
  const workspaceSelect = document.querySelector('#workspace-preset-select');
  if (modeSelect) modeSelect.value = state.ui.mode;
  if (expSelect) expSelect.value = state.ui.experience;
  if (workspaceSelect) workspaceSelect.value = state.ui.workspace;
  if (!typeSelect) return;
  const options = typeOptionsForMode();
  typeSelect.innerHTML = options.map((type) => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join('');
  if (!options.includes(state.draft.type)) state.draft.type = options[0];
  typeSelect.value = state.draft.type;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function previewCardTitle() {
  return state.draft.name || 'Untitled Card';
}

function parseTagsForCard() {
  const tags = draftTagsArray();
  const keywordTags = KEYWORD_DEFS.filter((entry) => state.draft.keywords[entry.key]).map((entry) => entry.label);
  const raceTags = draftRaceList().map((entry) => raceMeta(entry).label);
  return [...tags, ...keywordTags, ...raceTags];
}

function renderStatusRow() {
  const autosave = document.querySelector('#autosave-indicator');
  const validation = document.querySelector('#validation-summary');
  const complexity = document.querySelector('#complexity-meter');
  const draftMeta = document.querySelector('#draft-meta');
  if (autosave) autosave.textContent = state.autosave.label;
  if (validation) {
    const errorCount = state.validation.errors.length;
    const warningCount = state.validation.warnings.length;
    validation.textContent = errorCount ? `${errorCount} errors` : warningCount ? `${warningCount} warnings` : 'Validation clear';
    validation.classList.remove('good', 'warn', 'bad');
    validation.classList.add(errorCount ? 'bad' : warningCount ? 'warn' : 'good');
  }
  if (complexity) {
    const score = complexityScore();
    complexity.textContent = `Complexity: ${complexityTier(score)} (${score})`;
  }
  if (draftMeta) {
    const updated = state.draft.updatedAt ? new Date(state.draft.updatedAt).toLocaleTimeString() : 'unsaved';
    draftMeta.textContent = `Draft: ${state.draft.id || 'new'} • ${updated}`;
  }
}

function renderLeftPane() {
  const host = document.querySelector('#studio-left');
  if (!host) return;
  const modules = visibleModules();
  const templates = allTemplates().filter((tmpl) => tmpl.mode === state.ui.mode || tmpl.mode === 'hybrid');
  const recent = state.recentCards.slice(0, 8);
  host.innerHTML = `
    <div class="left-head">
      <strong>Creator Navigation</strong>
      <button type="button" data-action="toggle-left">${state.ui.leftCollapsed ? '>' : 'v'}</button>
    </div>
    <div class="left-body">
      <div class="field-search-wrap">
        <label>Search Modules
          <input type="text" id="module-search" value="${escapeHtml(state.ui.moduleSearch)}" placeholder="Search sections..." />
        </label>
      </div>
      <div class="nav-list">
        ${modules.map((module) => {
          const status = moduleStatus(module.id);
          return `
            <div class="nav-item" data-module-nav="${module.id}">
              <div class="row">
                <button type="button" data-action="jump-module" data-module="${module.id}">${escapeHtml(module.title)}</button>
                <span class="status-dot ${status.tone}"></span>
              </div>
              <div class="meta">${escapeHtml(module.subtitle)} • ${status.label}</div>
            </div>
          `;
        }).join('')}
      </div>

      <div class="template-search-wrap" style="margin-top:0.7rem;">
        <strong>Template Quickstart</strong>
      </div>
      <div class="template-list">
        ${templates.slice(0, 8).map((template) => `
          <div class="template-item">
            <div class="row">
              <button type="button" data-action="apply-template" data-template-id="${template.id}">${escapeHtml(template.label)}</button>
              <small>${escapeHtml(template.type)}</small>
            </div>
            <div class="meta">${escapeHtml(template.summary || '')}</div>
          </div>
        `).join('')}
      </div>

      <div style="margin-top:0.7rem;"><strong>Recent Cards</strong></div>
      <div class="quick-list">
        ${recent.length ? recent.map((entry) => `
          <div class="quick-item">
            <div class="row">
              <button type="button" data-action="load-card-id" data-card-id="${escapeHtml(entry.id)}">${escapeHtml(entry.name || entry.id)}</button>
              <small>${escapeHtml(entry.type || 'card')}</small>
            </div>
          </div>
        `).join('') : '<div class="note">No recent cards saved yet.</div>'}
      </div>

      <div class="workspace-preset-grid">
        <button type="button" data-action="workspace-preset" data-preset="balanced">Balanced</button>
        <button type="button" data-action="workspace-preset" data-preset="compact">Compact</button>
        <button type="button" data-action="workspace-preset" data-preset="ability_forge">Ability Forge</button>
        <button type="button" data-action="workspace-preset" data-preset="preview_focus">Preview Focus</button>
      </div>
    </div>
  `;
}

function renderCenterPane() {
  const host = document.querySelector('#studio-center');
  if (!host) return;
  const modules = visibleModules();
  host.innerHTML = modules.map((module, index) => {
    const collapsed = state.ui.moduleCollapsed[module.id];
    const pinned = !!state.ui.modulePinned[module.id];
    return `
      <article class="module-panel" id="module-${module.id}" data-module="${module.id}">
        <header class="module-head">
          <div class="title-wrap">
            <h3>${escapeHtml(module.title)}</h3>
            <small>${escapeHtml(module.subtitle)}</small>
          </div>
          <div class="module-tools">
            <button type="button" data-action="module-pin" data-module="${module.id}" title="Pin">${pinned ? '★' : '☆'}</button>
            <button type="button" data-action="module-move-up" data-module="${module.id}" ${index === 0 ? 'disabled' : ''}>↑</button>
            <button type="button" data-action="module-move-down" data-module="${module.id}" ${index === modules.length - 1 ? 'disabled' : ''}>↓</button>
            <button type="button" data-action="module-collapse" data-module="${module.id}">${collapsed ? '>' : 'v'}</button>
          </div>
        </header>
        <div class="module-body ${collapsed ? 'collapsed' : ''}">
          ${module.render()}
        </div>
      </article>
    `;
  }).join('');
  bindDropzone();
}

function renderRightPane() {
  const host = document.querySelector('#studio-right');
  if (!host) return;
  const tags = parseTagsForCard();
  const races = draftRaceList();
  const previewClass = PREVIEW_MODES.includes(state.ui.previewMode) ? state.ui.previewMode : 'full';
  const artStyle = state.draft.art.src
    ? `background-image:url('${state.draft.art.src}');background-size:${state.draft.art.fit};background-position:${state.draft.art.x}% ${state.draft.art.y}%;`
    : 'background-image:linear-gradient(135deg,#203555,#11253f);';
  const manaCost = `M:${num(state.draft.cost.mana, 0)} W:${num(state.draft.cost.wheat, 0)} I:${num(state.draft.cost.iron, 0)}`;
  host.innerHTML = `
    <div class="right-head">
      <strong>Live Preview</strong>
      <button type="button" data-action="toggle-right">${state.ui.rightCollapsed ? '>' : 'v'}</button>
    </div>
    <div class="right-body">
      <section class="preview-controls">
        <div class="field-grid">
          <label>Preview Mode
            <select id="preview-mode-select">
              ${PREVIEW_MODES.map((mode) => `<option value="${mode}" ${mode === state.ui.previewMode ? 'selected' : ''}>${mode}</option>`).join('')}
            </select>
          </label>
          <label>Preview Zoom
            <input type="range" min="0.7" max="1.35" step="0.05" id="preview-zoom" value="${state.ui.previewZoom}" />
          </label>
          <label>Show Tags
            <select id="preview-show-tags">
              <option value="yes" ${state.ui.previewShowTags ? 'selected' : ''}>Visible</option>
              <option value="no" ${!state.ui.previewShowTags ? 'selected' : ''}>Hidden</option>
            </select>
          </label>
        </div>
        <div class="inline-chips">
          <button type="button" data-action="preview-popout">Popout</button>
          <button type="button" data-action="quick-validate">Run Validation</button>
          <button type="button" data-action="save-version">Save Version</button>
        </div>
      </section>

      <section class="preview-stage">
        <div class="card-preview ${previewClass}" style="transform:scale(${state.ui.previewZoom}); transform-origin: top center;">
          <div class="card-layer-art" style="${artStyle}"></div>
          <div class="card-content">
            <div class="card-top">
              <div class="card-name">${escapeHtml(previewCardTitle())}</div>
              <div class="card-cost">${escapeHtml(manaCost)}</div>
            </div>
            <div class="preview-family-row">${races.length ? races.map((race) => `<span class="race-chip static">${raceIconGlyph(race)} ${escapeHtml(raceMeta(race).label)}</span>`).join('') : '<span class="race-chip static">NE Neutral</span>'}</div>
            <div class="card-text">${escapeHtml(generatedRulesText() || 'No rules text yet.')}</div>
            <div class="card-bottom">
              <div class="card-stats">
                <span class="stat-pill">ATK ${num(state.draft.stats.attack, 0)}</span>
                <span class="stat-pill">HP ${num(state.draft.stats.health, 0)}</span>
                <span class="stat-pill">DEF ${num(state.draft.stats.defense, 0)}</span>
              </div>
              <div class="stat-pill">${escapeHtml(state.draft.type)} • ${escapeHtml(state.draft.rarity)}</div>
            </div>
          </div>
        </div>
        ${state.ui.previewShowTags ? `<div class="inline-chips" style="margin-top:.55rem;">${tags.length ? tags.map((tag) => `<span class="chip">${escapeHtml(tag)}</span>`).join('') : '<span class="chip">No tags</span>'}</div>` : ''}
      </section>

      <section class="preview-insights">
        <div class="${state.validation.errors.length ? 'error-box' : 'success-box'}">
          ${state.validation.errors.length ? `Errors: ${state.validation.errors.length}` : 'No critical errors.'}
        </div>
        ${state.validation.warnings.length ? `<div class="warning">Warnings: ${state.validation.warnings.length}</div>` : ''}
        <div class="note">Mode: ${escapeHtml(state.ui.mode)} • Workflow: ${escapeHtml(state.ui.experience)} • Abilities: ${state.draft.abilities.length}</div>
        <div class="note">Families: ${escapeHtml(selectedRaceSummary())} • Familiarity: ${state.draft.normal.familiarityRace ? `${familiarityLabel(state.draft.normal.familiarityRace)} start ${num(state.draft.normal.familiarityStart, 0)}` : 'none'}</div>
        <div class="note">Archetype suggestion: ${escapeHtml(archetypeSuggestion())}</div>
      </section>
    </div>
  `;
}

function renderBottomPane() {
  const host = document.querySelector('#studio-bottom');
  if (!host) return;
  const tabs = [
    ['activity', 'Activity'],
    ['ability-json', 'Ability JSON'],
    ['project-json', 'Project JSON'],
    ['docs', 'Docs'],
    ['versions', 'Versions'],
  ];
  let content = '';
  if (state.ui.bottomTab === 'activity') {
    const rows = state.activity.slice(-80).reverse();
    content = rows.length
      ? rows.map((entry) => `<div class="note">${escapeHtml(new Date(entry.at).toLocaleTimeString())} • ${escapeHtml(entry.msg)}</div>`).join('')
      : '<div class="note">No activity yet.</div>';
  } else if (state.ui.bottomTab === 'ability-json') {
    content = `<pre class="mono">${escapeHtml(JSON.stringify(state.draft.abilities, null, 2))}</pre>`;
  } else if (state.ui.bottomTab === 'project-json') {
    content = `
      <textarea id="project-json-editor" class="mono">${escapeHtml(JSON.stringify(state.draft, null, 2))}</textarea>
      <div class="inline-chips">
        <button type="button" data-action="copy-project-json">Copy JSON</button>
        <button type="button" data-action="import-project-json">Import JSON</button>
      </div>
    `;
  } else if (state.ui.bottomTab === 'docs') {
    content = `
      <div class="note">Beginner mode hides advanced modules and focuses on essentials.</div>
      <div class="note">Advanced mode exposes full targeting, production, and scripting metadata.</div>
      <div class="note">Use Ability Builder presets to rapidly scaffold card logic.</div>
      <div class="note">Save versions frequently before major balance edits.</div>
    `;
  } else if (state.ui.bottomTab === 'versions') {
    content = state.versions.length
      ? state.versions.map((version, idx) => `
        <div class="template-item">
          <div class="row">
            <strong>${escapeHtml(version.label || `Version ${idx + 1}`)}</strong>
            <small>${escapeHtml(new Date(version.at).toLocaleString())}</small>
          </div>
          <div class="row" style="margin-top:.28rem;">
            <button type="button" data-action="restore-version" data-version-index="${idx}">Restore</button>
            <button type="button" data-action="delete-version" data-version-index="${idx}">Delete</button>
          </div>
        </div>
      `).join('')
      : '<div class="note">No saved versions.</div>';
  }

  host.innerHTML = `
    <div class="bottom-head">
      <strong>Studio Drawer</strong>
      <button type="button" data-action="toggle-bottom">${state.ui.bottomCollapsed ? '>' : 'v'}</button>
    </div>
    <div class="bottom-tabs">
      ${tabs.map(([id, label]) => `<button type="button" data-action="bottom-tab" data-tab="${id}" ${id === state.ui.bottomTab ? 'class="primary"' : ''}>${label}</button>`).join('')}
    </div>
    <div class="bottom-content">${content}</div>
  `;
}

function renderCommandPalette() {
  const overlay = document.querySelector('#command-palette');
  const list = document.querySelector('#command-list');
  const search = document.querySelector('#command-search');
  if (!overlay || !list || !search) return;
  overlay.classList.toggle('hidden', !state.ui.commandOpen);
  overlay.setAttribute('aria-hidden', state.ui.commandOpen ? 'false' : 'true');
  search.value = state.ui.commandQuery;
  if (state.ui.commandOpen) search.focus();
  const items = commandItems().filter((item) => {
    const q = state.ui.commandQuery.trim().toLowerCase();
    if (!q) return true;
    return `${item.label} ${item.group}`.toLowerCase().includes(q);
  });
  list.innerHTML = items.map((item) => `
    <button type="button" class="command-item" data-action="run-command" data-command-id="${item.id}">
      <span>${escapeHtml(item.label)}</span>
      <small>${escapeHtml(item.group)}</small>
    </button>
  `).join('') || '<div class="note">No matching command.</div>';
}

function renderAll() {
  if (!state.ready) return;
  syncTopbarSelections();
  applyLayoutClasses();
  renderStatusRow();
  renderLeftPane();
  renderCenterPane();
  renderRightPane();
  renderBottomPane();
  renderCommandPalette();
}

function applyLayoutClasses() {
  document.body.classList.toggle('left-collapsed', state.ui.leftCollapsed);
  document.body.classList.toggle('right-collapsed', state.ui.rightCollapsed);
  document.body.classList.toggle('bottom-collapsed', state.ui.bottomCollapsed);
}

function allTemplates() {
  const pluginTemplates = state.pluginTemplates.map((card) => ({
    id: `plugin-${card.id}`,
    label: card.name || card.id,
    mode: deduceModeFromTemplate(card),
    type: card.type || 'minion',
    summary: 'Plugin template',
    patch: card,
  }));
  const userTemplates = state.userTemplates.map((entry) => ({ ...entry, id: `user-${entry.id}` }));
  return [...BUILTIN_TEMPLATES, ...pluginTemplates, ...userTemplates];
}

function deduceModeFromTemplate(template) {
  const compat = String(template.battleCompatibility || template.requiredModes || '').toLowerCase();
  if (compat.includes('conquest') || template.productionBuildingType || template.producible) return 'conquest';
  if (compat.includes('both')) return 'hybrid';
  return 'duel';
}

function logActivity(msg) {
  state.activity.push({ at: Date.now(), msg });
  if (state.activity.length > 300) state.activity.shift();
}

function validateDraft() {
  const errors = [];
  const warnings = [];
  const races = draftRaceList();
  if (!state.draft.id.trim()) errors.push({ module: 'identity', path: 'id', message: 'Card ID is required.' });
  if (!/^[a-z0-9][a-z0-9-_]*$/i.test(state.draft.id.trim())) warnings.push({ module: 'identity', path: 'id', message: 'Use stable slug-like card IDs.' });
  if (!state.draft.name.trim()) errors.push({ module: 'identity', path: 'name', message: 'Card name is required.' });
  if (!typeOptionsForMode().includes(state.draft.type)) errors.push({ module: 'type-mode', path: 'type', message: 'Card type is invalid for current mode.' });
  if (num(state.draft.cost.mana, 0) < 0 || num(state.draft.cost.wheat, 0) < 0 || num(state.draft.cost.iron, 0) < 0) {
    errors.push({ module: 'costs-stats', path: 'cost', message: 'Costs must be non-negative.' });
  }
  if (num(state.draft.stats.health, 0) <= 0 && !['spell', 'relic', 'field', 'tactic', 'support', 'upgrade', 'equipment'].includes(state.draft.type)) {
    errors.push({ module: 'costs-stats', path: 'stats.health', message: 'Units/buildings need health above 0.' });
  }
  if (state.ui.mode === 'conquest') {
    if (!state.draft.conquest.productionSource) warnings.push({ module: 'conquest-options', path: 'conquest.productionSource', message: 'Set a production source for conquest cards.' });
    if (state.draft.conquest.isBuilding && num(state.draft.stats.attack, 0) > 0 && !state.draft.keywords.turret) warnings.push({ module: 'conquest-options', path: 'conquest.isBuilding', message: 'Attacking buildings should usually be tagged as turret.' });
    if (state.draft.conquest.localMultiplayerExcluded !== true) warnings.push({ module: 'conquest-options', path: 'conquest.localMultiplayerExcluded', message: 'Conquest-authored cards should stay excluded from Local Multiplayer.' });
    if (String(state.draft.conquest.requiredModes || '').toLowerCase().includes('local')) warnings.push({ module: 'conquest-options', path: 'conquest.requiredModes', message: 'Conquest cards should not target Local Multiplayer legality.' });
    if (String(state.draft.conquest.requiredModes || '').trim() === '') warnings.push({ module: 'conquest-options', path: 'conquest.requiredModes', message: 'Set conquest required modes, typically conquest-attack for attack-side authored cards.' });
  }
  if (state.ui.mode === 'duel' && state.draft.conquest.isBuilding) warnings.push({ module: 'conquest-options', path: 'conquest.isBuilding', message: 'Conquest flags are set while in duel mode.' });
  if (state.ui.mode !== 'conquest' && !races.length) warnings.push({ module: 'race-familiarity', path: 'normal.race', message: 'Set at least one race/family for duel cards that use tribe or familiarity mechanics.' });
  if (state.draft.normal.familiarityRace && !races.includes(state.draft.normal.familiarityRace)) warnings.push({ module: 'race-familiarity', path: 'normal.familiarityRace', message: 'Familiarity race should usually be part of the card family mix.' });
  if (state.draft.normal.familiarityThreshold > 0 && !state.draft.normal.familiarityReward.trim()) warnings.push({ module: 'race-familiarity', path: 'normal.familiarityReward', message: 'Familiarity threshold is set but no reward text is described.' });
  if (state.draft.normal.localExclusive && state.draft.normal.includeInPacks) warnings.push({ module: 'normal-mode', path: 'normal.localExclusive', message: 'Local-exclusive cards are usually excluded from normal pack progression.' });
  if (!state.draft.text.trim() && state.draft.abilities.length === 0) warnings.push({ module: 'identity', path: 'text', message: 'Card has no text or ability blocks.' });
  if (state.draft.abilities.some((ability) => !ability.trigger || !ability.effect)) errors.push({ module: 'abilities', path: 'abilities', message: 'Every ability needs trigger and effect.' });
  if (state.draft.abilities.some((ability) => ability.family && !DUEL_FAMILIES.includes(ability.family))) warnings.push({ module: 'abilities', path: 'abilities.family', message: 'Ability family filter should use a standardized race/type.' });
  if (state.draft.abilities.some((ability) => ability.familiarityThreshold > 0 && !ability.familiarityRace)) warnings.push({ module: 'abilities', path: 'abilities.familiarityRace', message: 'Familiarity threshold ability is missing a familiarity race.' });
  if (state.draft.abilities.some((ability) => ability.targetFamily && !ability.family && !ability.sourceFamily && !ability.controllerFamily)) warnings.push({ module: 'abilities', path: 'abilities.targetFamily', message: 'Target race filters work best with a source/controller race filter.' });
  if (state.ui.mode === 'conquest' && state.draft.abilities.some((ability) => ability.branchFilter !== 'none' && !['horde', 'formation', 'veteran', 'venerated', 'evo', 'hero'].includes(String(ability.target)))) {
    warnings.push({ module: 'abilities', path: 'abilities.branchFilter', message: 'Branch filters are strongest when paired with conquest-aware targets like horde, veteran, venerated, EVO, or formation.' });
  }
  if (state.ui.mode === 'conquest' && state.draft.abilities.some((ability) => String(ability.target).toLowerCase() === 'cell_class' && String(ability.targetCellClass || 'any') === 'any')) {
    warnings.push({ module: 'abilities', path: 'abilities.targetCellClass', message: 'Cell-class targeting should specify a lane or structure cell class.' });
  }
  if (state.draft.art.src && !/^data:image\/|^https?:\/\//i.test(state.draft.art.src)) warnings.push({ module: 'art-frame', path: 'art.src', message: 'Art source should be a URL or uploaded data image.' });
  if (!state.draft.metadata.packName.trim()) warnings.push({ module: 'collection-meta', path: 'metadata.packName', message: 'Pack assignment is empty.' });
  if (state.draft.id && state.cardLibrary[state.draft.id]) warnings.push({ module: 'save-export', path: 'id', message: 'Saving will overwrite existing custom card with same ID.' });
  state.validation = { errors, warnings };
}

function abilitySummary(block) {
  const trigger = String(block.trigger || 'Trigger').replace(/_/g, ' ');
  const family = normalizeFamilyId(block.family);
  const familyLabel = family ? raceMeta(family).label : '';
  const familiarityRace = normalizeFamilyId(block.familiarityRace);
  const familiarityLabelText = familiarityRace ? raceMeta(familiarityRace).label : '';
  const sourceFamily = normalizeFamilyId(block.sourceFamily);
  const targetFamily = normalizeFamilyId(block.targetFamily);
  const controllerFamily = normalizeFamilyId(block.controllerFamily);
  const target = block.target ? String(block.target).replace(/_/g, ' ') : 'target';
  const duration = num(block.duration, 1) > 1 ? ` for ${num(block.duration, 1)} turns` : '';
  const filterBits = [
    sourceFamily ? `source ${raceMeta(sourceFamily).label}` : '',
    targetFamily ? `target ${raceMeta(targetFamily).label}` : '',
    controllerFamily ? `controller has ${raceMeta(controllerFamily).label}` : '',
    block.sourceElement ? `source ${block.sourceElement}` : '',
    block.targetElement ? `target ${block.targetElement}` : '',
    block.roleFilter ? `role ${block.roleFilter}` : '',
    block.branchFilter && block.branchFilter !== 'none' ? `branch ${block.branchFilter}` : '',
    block.laneScope ? `lane ${block.laneScope}` : '',
    block.targetCellClass && block.targetCellClass !== 'any' ? `cell ${block.targetCellClass}` : '',
  ].filter(Boolean);
  const filterSuffix = filterBits.length ? ` [${filterBits.join(' • ')}]` : '';
  const scaleSuffix = block.effectScale && block.effectScale !== 'flat'
    ? ` (${block.effectScale}${num(block.effectGrowth, 0) ? ` +${num(block.effectGrowth, 0)}/step` : ''}${num(block.effectCap, 0) ? ` cap ${num(block.effectCap, 0)}` : ''})`
    : '';

  if (block.effect === 'gainStats' && familyLabel) {
    const zone = block.familyZone || 'board';
    return `${trigger}: For every ${familyLabel} in your ${zone}, gain +${num(block.amount, 1)}/+${num(block.amount, 1)}${scaleSuffix}${duration}${filterSuffix}.`;
  }
  if (block.effect === 'reduceCost' && familyLabel) {
    return `${trigger}: This costs (${num(block.amount, 1)}) less for each ${familyLabel} in your ${block.familyZone || 'hand'}${filterSuffix}.`;
  }
  if (block.effect === 'draw' && familyLabel && num(block.threshold, 0) > 0) {
    return `${trigger}: If you control ${num(block.threshold, 0)} or more ${familyLabel}, draw ${num(block.amount, 1)}.`;
  }
  if (block.effect === 'gainFamiliarity' && familyLabel) {
    return `${trigger}: Gain ${num(block.amount, 1)} ${familyLabel} Familiarity.`;
  }
  if (block.effect === 'spendFamiliarity' && familiarityLabelText) {
    return `${trigger}: Spend ${num(block.familiarityAmount || block.amount, 1)} ${familiarityLabelText} Familiarity.`;
  }
  if (familiarityLabelText && num(block.familiarityThreshold, 0) > 0) {
    return `${trigger}: ${familiarityLabelText} Familiarity ${num(block.familiarityThreshold, 0)} -> ${String(block.effect).replace(/([A-Z])/g, ' $1').trim()} ${num(block.amount, 0)} on ${target}${scaleSuffix}${duration}.`;
  }
  if (String(block.target).toLowerCase() === 'cell_class' && String(block.targetCellClass || 'any') !== 'any') {
    return `${trigger}: ${String(block.effect || 'effect').replace(/([A-Z])/g, ' $1').trim()} ${num(block.amount, 0)} on ${block.targetCellClass.replace(/-/g, ' ')} cells${scaleSuffix}${filterSuffix}${duration}.`;
  }
  const base = `${trigger}: ${String(block.effect || 'effect').replace(/([A-Z])/g, ' $1').trim()} ${num(block.amount, 0)}`;
  const targetText = target ? ` on ${target}` : '';
  const condition = block.condition ? ` if ${block.condition}` : '';
  return `${base}${targetText}${condition}${scaleSuffix}${filterSuffix}${duration}.`;
}

function renderIdentityModule() {
  return `
    <div class="field-grid">
      <label>Card ID<input type="text" data-path="id" value="${escapeHtml(state.draft.id)}" placeholder="gen4-card-id" /></label>
      <label>Card Name<input type="text" data-path="name" value="${escapeHtml(state.draft.name)}" placeholder="Card Name" /></label>
      <label>Rarity
        <select data-path="rarity">
          ${RARITIES.map((rarity) => `<option value="${rarity}" ${state.draft.rarity === rarity ? 'selected' : ''}>${rarity}</option>`).join('')}
        </select>
      </label>
      <label>Generation<input type="text" data-path="metadata.generation" value="${escapeHtml(state.draft.metadata.generation)}" /></label>
    </div>
    <div class="stack">
      <label>Rules Text<textarea data-path="text" placeholder="Rules text...">${escapeHtml(state.draft.text)}</textarea></label>
      <label>Design Notes<textarea data-path="metadata.notes" placeholder="Internal dev notes...">${escapeHtml(state.draft.metadata.notes)}</textarea></label>
    </div>
  `;
}

function renderTypeModeModule() {
  return `
    <div class="field-grid">
      <label>Card Mode
        <select id="module-mode-select">
          <option value="duel" ${state.ui.mode === 'duel' ? 'selected' : ''}>Normal Mode</option>
          <option value="conquest" ${state.ui.mode === 'conquest' ? 'selected' : ''}>Conquest Mode</option>
          <option value="hybrid" ${state.ui.mode === 'hybrid' ? 'selected' : ''}>Hybrid</option>
        </select>
      </label>
      <label>Card Type
        <select data-path="type">
          ${typeOptionsForMode().map((type) => `<option value="${type}" ${state.draft.type === type ? 'selected' : ''}>${type}</option>`).join('')}
        </select>
      </label>
      <label>Workflow
        <select id="module-experience-select">
          <option value="beginner" ${state.ui.experience === 'beginner' ? 'selected' : ''}>Beginner</option>
          <option value="advanced" ${state.ui.experience === 'advanced' ? 'selected' : ''}>Advanced</option>
        </select>
      </label>
      <label>Workspace Preset
        <select id="module-workspace-select">
          <option value="balanced" ${state.ui.workspace === 'balanced' ? 'selected' : ''}>Balanced</option>
          <option value="compact" ${state.ui.workspace === 'compact' ? 'selected' : ''}>Compact</option>
          <option value="ability_forge" ${state.ui.workspace === 'ability_forge' ? 'selected' : ''}>Ability Forge</option>
          <option value="preview_focus" ${state.ui.workspace === 'preview_focus' ? 'selected' : ''}>Preview Focus</option>
        </select>
      </label>
    </div>
    <div class="note">Mode-adaptive modules will auto-show relevant controls and hide incompatible sections.</div>
  `;
}

function renderCostsStatsModule() {
  const type = state.draft.type;
  const spellLike = ['spell', 'tactic', 'support', 'upgrade', 'equipment', 'field', 'relic', 'trap'].includes(type);
  return `
    <div class="field-grid">
      <label>Mana Cost<input type="number" min="0" data-path="cost.mana" value="${num(state.draft.cost.mana, 0)}" /></label>
      <label>Wheat Cost<input type="number" min="0" data-path="cost.wheat" value="${num(state.draft.cost.wheat, 0)}" /></label>
      <label>Iron Cost<input type="number" min="0" data-path="cost.iron" value="${num(state.draft.cost.iron, 0)}" /></label>
      ${spellLike ? `<label>Spell Damage<input type="number" min="0" data-path="normal.damage" value="${num(state.draft.normal.damage, 0)}" /></label>` : ''}
      ${!spellLike ? `<label>Attack<input type="number" min="0" data-path="stats.attack" value="${num(state.draft.stats.attack, 0)}" /></label>` : ''}
      ${!spellLike ? `<label>Health<input type="number" min="1" data-path="stats.health" value="${num(state.draft.stats.health, 1)}" /></label>` : ''}
      <label>Defense<input type="number" min="0" data-path="stats.defense" value="${num(state.draft.stats.defense, 0)}" /></label>
      <label>Range<input type="number" min="1" data-path="stats.range" value="${num(state.draft.stats.range, 1)}" /></label>
      <label>Movement<input type="number" min="0" data-path="stats.movement" value="${num(state.draft.stats.movement, 1)}" /></label>
    </div>
  `;
}

function renderKeywordsModule() {
  return `
    <div class="inline-chips">
      ${KEYWORD_DEFS.map((keyword) => `
        <label class="chip">
          <input type="checkbox" data-path="keywords.${keyword.key}" ${state.draft.keywords[keyword.key] ? 'checked' : ''} />
          ${escapeHtml(keyword.label)}
        </label>
      `).join('')}
    </div>
    <div class="note">Type markers are used in preview, inspect panels, and deck/debug tooling.</div>
  `;
}

function renderRaceFamiliarityModule() {
  const selected = draftRaceList();
  return `
    <div class="note">Pick the species mix first, then define how the card rewards race counts or familiarity.</div>
    <div class="inline-chips race-archetype-row">
      ${raceArchetypeMarkup()}
    </div>
    <div class="field-grid">
      <label>Primary Race
        <select data-path="normal.race">
          <option value="">neutral</option>
          ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${state.draft.normal.race === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
        </select>
      </label>
      <label>Race Mix (CSV)<input type="text" data-path="normal.races" value="${escapeHtml(state.draft.normal.races)}" placeholder="dragon, ancient" /></label>
      <label>Element<input type="text" data-path="normal.element" value="${escapeHtml(state.draft.normal.element)}" /></label>
      <label>Archetype Role<input type="text" data-path="metadata.role" value="${escapeHtml(state.draft.metadata.role)}" placeholder="Dragon finisher / race lord" /></label>
      <label>Synergy Hints<input type="text" data-path="normal.synergy" value="${escapeHtml(state.draft.normal.synergy)}" placeholder="dragon,flying,hoard" /></label>
      <label>Familiarity Race
        <select data-path="normal.familiarityRace">
          <option value="">none</option>
          ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${state.draft.normal.familiarityRace === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
        </select>
      </label>
      <label>Starting Familiarity<input type="number" min="0" data-path="normal.familiarityStart" value="${num(state.draft.normal.familiarityStart, 0)}" /></label>
      <label>Threshold<input type="number" min="0" data-path="normal.familiarityThreshold" value="${num(state.draft.normal.familiarityThreshold, 0)}" /></label>
      <label>Threshold Reward<input type="text" data-path="normal.familiarityReward" value="${escapeHtml(state.draft.normal.familiarityReward)}" placeholder="your Dragons cost 1 less" /></label>
    </div>
    <div class="race-chip-grid">${raceChipMarkup(selected)}</div>
    <label>Familiarity Notes<textarea data-path="normal.familiarityNotes">${escapeHtml(state.draft.normal.familiarityNotes)}</textarea></label>
    <div class="note">Current family identity: ${escapeHtml(selectedRaceSummary())}.</div>
    <div class="note">Suggested archetype: ${escapeHtml(archetypeSuggestion())}.</div>
  `;
}

function renderAbilityModule() {
  const presets = state.abilityTemplates;
  return `
    <div class="field-grid">
      <label>Add Preset
        <select id="ability-preset-select">
          <option value="">Custom Empty Block</option>
          ${presets.map((preset) => `<option value="${preset.id}">${escapeHtml(preset.name)} (${escapeHtml(preset.category || 'general')})</option>`).join('')}
        </select>
      </label>
      <label>Ability Ops
        <div class="inline-chips">
          <button type="button" data-action="ability-add">Add Ability</button>
          <button type="button" data-action="ability-save-template">Save Ability Layout</button>
        </div>
      </label>
    </div>
    ${state.draft.abilities.length ? state.draft.abilities.map((block, idx) => {
      const collapsed = !!state.ui.abilityCollapsed[block.id];
      return `
        <div class="ability-block" data-ability-id="${block.id}">
          <div class="ability-head">
            <div>
              <strong>#${idx + 1} ${escapeHtml(block.name || 'Ability')}</strong>
              <div class="ability-summary">${escapeHtml(abilitySummary(block))}</div>
            </div>
            <div class="module-tools">
              <button type="button" data-action="ability-duplicate" data-ability-id="${block.id}">Dupe</button>
              <button type="button" data-action="ability-up" data-ability-id="${block.id}" ${idx === 0 ? 'disabled' : ''}>↑</button>
              <button type="button" data-action="ability-down" data-ability-id="${block.id}" ${idx === state.draft.abilities.length - 1 ? 'disabled' : ''}>↓</button>
              <button type="button" data-action="ability-collapse" data-ability-id="${block.id}">${collapsed ? '>' : 'v'}</button>
              <button type="button" data-action="ability-delete" data-ability-id="${block.id}">X</button>
            </div>
          </div>
          <div class="ability-body ${collapsed ? 'collapsed' : ''}">
            <div class="inline-chips ability-rail">
              <span class="chip subtle">Trigger</span>
              <span class="chip subtle">Condition</span>
              <span class="chip subtle">Target</span>
              <span class="chip subtle">Effect</span>
            </div>
            <div class="field-grid">
              <label>Name<input type="text" data-ability-field="name" data-ability-id="${block.id}" value="${escapeHtml(block.name)}" /></label>
              <label>Trigger
                <select data-ability-field="trigger" data-ability-id="${block.id}">
                  ${ABILITY_TRIGGER_OPTIONS.map((entry) => `<option value="${entry}" ${block.trigger === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Target
                <select data-ability-field="target" data-ability-id="${block.id}">
                  ${ABILITY_TARGET_OPTIONS.map((entry) => `<option value="${entry}" ${block.target === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Condition<input type="text" data-ability-field="condition" data-ability-id="${block.id}" value="${escapeHtml(block.condition)}" /></label>
              <label>Effect
                <select data-ability-field="effect" data-ability-id="${block.id}">
                  ${ABILITY_EFFECT_OPTIONS.map((entry) => `<option value="${entry}" ${block.effect === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Amount<input type="number" data-ability-field="amount" data-ability-id="${block.id}" value="${num(block.amount, 0)}" /></label>
              <label>Duration<input type="number" min="1" data-ability-field="duration" data-ability-id="${block.id}" value="${num(block.duration, 1)}" /></label>
              <label>Scope<input type="text" data-ability-field="scope" data-ability-id="${block.id}" value="${escapeHtml(block.scope)}" /></label>
              <label>Filters<input type="text" data-ability-field="filters" data-ability-id="${block.id}" value="${escapeHtml(block.filters)}" /></label>
              <label>Timing<input type="text" data-ability-field="timing" data-ability-id="${block.id}" value="${escapeHtml(block.timing)}" /></label>
              <label>Race / Type
                <select data-ability-field="family" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.family === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Count Zone
                <select data-ability-field="familyZone" data-ability-id="${block.id}">
                  ${ABILITY_ZONE_OPTIONS.map((zone) => `<option value="${zone}" ${block.familyZone === zone ? 'selected' : ''}>${zone}</option>`).join('')}
                </select>
              </label>
              <label>Source Race
                <select data-ability-field="sourceFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.sourceFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Target Race
                <select data-ability-field="targetFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.targetFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Controller Has Race
                <select data-ability-field="controllerFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.controllerFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Dead Race Count
                <select data-ability-field="deadFamily" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.deadFamily === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Threshold<input type="number" min="0" data-ability-field="threshold" data-ability-id="${block.id}" value="${num(block.threshold, 0)}" /></label>
              <label>Familiarity Race
                <select data-ability-field="familiarityRace" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${DUEL_FAMILIES.map((family) => `<option value="${family}" ${block.familiarityRace === family ? 'selected' : ''}>${escapeHtml(raceMeta(family).label)}</option>`).join('')}
                </select>
              </label>
              <label>Familiarity Gain/Spend<input type="number" min="0" data-ability-field="familiarityAmount" data-ability-id="${block.id}" value="${num(block.familiarityAmount, 0)}" /></label>
              <label>Familiarity Threshold<input type="number" min="0" data-ability-field="familiarityThreshold" data-ability-id="${block.id}" value="${num(block.familiarityThreshold, 0)}" /></label>
              <label>Deck Rule<input type="text" data-ability-field="deckRule" data-ability-id="${block.id}" value="${escapeHtml(block.deckRule)}" placeholder="deck contains only dragon" /></label>
              <label>Token Race<input type="text" data-ability-field="tokenRace" data-ability-id="${block.id}" value="${escapeHtml(block.tokenRace)}" placeholder="dragonkin" /></label>
              <label>Persistent Counter<input type="text" data-ability-field="counterKey" data-ability-id="${block.id}" value="${escapeHtml(block.counterKey)}" placeholder="brood, omen, fury" /></label>
              <label>Cooldown<input type="number" min="0" data-ability-field="cooldown" data-ability-id="${block.id}" value="${num(block.cooldown, 0)}" /></label>
              <label>Charges<input type="number" min="0" data-ability-field="charges" data-ability-id="${block.id}" value="${num(block.charges, 0)}" /></label>
              <label>Source Element
                <select data-ability-field="sourceElement" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${CONQUEST_ELEMENT_OPTIONS.map((entry) => `<option value="${entry}" ${block.sourceElement === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Target Element
                <select data-ability-field="targetElement" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${CONQUEST_ELEMENT_OPTIONS.map((entry) => `<option value="${entry}" ${block.targetElement === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Role Filter
                <select data-ability-field="roleFilter" data-ability-id="${block.id}">
                  <option value="">none</option>
                  ${CONQUEST_ROLE_OPTIONS.map((entry) => `<option value="${entry}" ${block.roleFilter === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Branch Filter
                <select data-ability-field="branchFilter" data-ability-id="${block.id}">
                  ${CONQUEST_BRANCH_OPTIONS.map((entry) => `<option value="${entry}" ${block.branchFilter === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Lane Scope<input type="text" data-ability-field="laneScope" data-ability-id="${block.id}" value="${escapeHtml(block.laneScope)}" placeholder="same-lane, adjacent-lanes" /></label>
              <label>Cell Class
                <select data-ability-field="targetCellClass" data-ability-id="${block.id}">
                  ${CONQUEST_CELL_CLASS_OPTIONS.map((entry) => `<option value="${entry}" ${block.targetCellClass === entry ? 'selected' : ''}>${entry}</option>`).join('')}
                </select>
              </label>
              <label>Count Threshold<input type="number" min="0" data-ability-field="countThreshold" data-ability-id="${block.id}" value="${num(block.countThreshold, 0)}" /></label>
              <label>Scale
                <select data-ability-field="effectScale" data-ability-id="${block.id}">
                  <option value="flat" ${block.effectScale === 'flat' ? 'selected' : ''}>flat</option>
                  <option value="linear" ${block.effectScale === 'linear' ? 'selected' : ''}>linear</option>
                  <option value="threshold" ${block.effectScale === 'threshold' ? 'selected' : ''}>threshold</option>
                  <option value="resonance" ${block.effectScale === 'resonance' ? 'selected' : ''}>resonance</option>
                </select>
              </label>
              <label>Growth / Step<input type="number" min="0" data-ability-field="effectGrowth" data-ability-id="${block.id}" value="${num(block.effectGrowth, 0)}" /></label>
              <label>Effect Cap<input type="number" min="0" data-ability-field="effectCap" data-ability-id="${block.id}" value="${num(block.effectCap, 0)}" /></label>
              <label class="chip"><input type="checkbox" data-ability-field="oncePerTurn" data-ability-id="${block.id}" ${block.oncePerTurn ? 'checked' : ''} />Once/Turn</label>
            </div>
            <label>Notes<textarea data-ability-field="notes" data-ability-id="${block.id}">${escapeHtml(block.notes)}</textarea></label>
            <label>Advanced Script Hook<textarea data-ability-field="script" data-ability-id="${block.id}">${escapeHtml(block.script)}</textarea></label>
          </div>
        </div>
      `;
    }).join('') : '<div class="note">No abilities yet. Add one from preset or empty block.</div>'}
  `;
}

function renderTargetingModule() {
  return `
    <div class="field-grid">
      <label>Source
        <select data-path="targeting.source">
          <option value="any" ${state.draft.targeting.source === 'any' ? 'selected' : ''}>any</option>
          <option value="self" ${state.draft.targeting.source === 'self' ? 'selected' : ''}>self</option>
          <option value="friendly-board" ${state.draft.targeting.source === 'friendly-board' ? 'selected' : ''}>friendly-board</option>
          <option value="enemy-board" ${state.draft.targeting.source === 'enemy-board' ? 'selected' : ''}>enemy-board</option>
          <option value="attacker-reserve" ${state.draft.targeting.source === 'attacker-reserve' ? 'selected' : ''}>attacker-reserve</option>
        </select>
      </label>
      <label>Scope
        <select data-path="targeting.scope">
          <option value="single" ${state.draft.targeting.scope === 'single' ? 'selected' : ''}>single</option>
          <option value="lane" ${state.draft.targeting.scope === 'lane' ? 'selected' : ''}>lane</option>
          <option value="adjacent" ${state.draft.targeting.scope === 'adjacent' ? 'selected' : ''}>adjacent</option>
          <option value="all" ${state.draft.targeting.scope === 'all' ? 'selected' : ''}>all</option>
          <option value="reserve" ${state.draft.targeting.scope === 'reserve' ? 'selected' : ''}>reserve</option>
        </select>
      </label>
      <label>Team
        <select data-path="targeting.team">
          <option value="enemy" ${state.draft.targeting.team === 'enemy' ? 'selected' : ''}>enemy</option>
          <option value="friendly" ${state.draft.targeting.team === 'friendly' ? 'selected' : ''}>friendly</option>
          <option value="either" ${state.draft.targeting.team === 'either' ? 'selected' : ''}>either</option>
        </select>
      </label>
      <label>Placement Rule<input type="text" data-path="targeting.placement" value="${escapeHtml(state.draft.targeting.placement)}" placeholder="Can only be placed on..." /></label>
      <label>Requirement<input type="text" data-path="targeting.requirement" value="${escapeHtml(state.draft.targeting.requirement)}" placeholder="Requires Blacksmith..." /></label>
      <label>Line of Fire<input type="text" data-path="targeting.lineOfFire" value="${escapeHtml(state.draft.targeting.lineOfFire)}" /></label>
      <label>Lane Scope<input type="text" data-path="targeting.laneScope" value="${escapeHtml(state.draft.targeting.laneScope)}" placeholder="same-lane, forward-lane, adjacent-lane" /></label>
      <label>Cell Class
        <select data-path="targeting.cellClass">
          ${CONQUEST_CELL_CLASS_OPTIONS.map((entry) => `<option value="${entry}" ${state.draft.targeting.cellClass === entry ? 'selected' : ''}>${entry}</option>`).join('')}
        </select>
      </label>
      <label>Controller<input type="text" data-path="targeting.controller" value="${escapeHtml(state.draft.targeting.controller)}" placeholder="attacker, defender, either" /></label>
      <label>Count Threshold<input type="number" min="0" data-path="targeting.countThreshold" value="${num(state.draft.targeting.countThreshold, 0)}" /></label>
      <label>Filters<textarea data-path="targeting.filters">${escapeHtml(state.draft.targeting.filters)}</textarea></label>
    </div>
    <div class="note">Use structured source, lane, and cell-class filters for conquest cards so the resulting rules text and targeting warnings stay readable instead of relying on raw free-form filters alone.</div>
  `;
}

function renderArtModule() {
  return `
    <div class="dropzone" id="art-dropzone">Drop PNG/JPG here or <button type="button" data-action="open-art-upload">choose file</button></div>
    <div class="field-grid">
      <label>Art URL / Data<input type="text" data-path="art.src" value="${escapeHtml(state.draft.art.src)}" placeholder="https://... or data:image/..." /></label>
      <label>Fit
        <select data-path="art.fit">
          <option value="cover" ${state.draft.art.fit === 'cover' ? 'selected' : ''}>cover</option>
          <option value="contain" ${state.draft.art.fit === 'contain' ? 'selected' : ''}>contain</option>
          <option value="fill" ${state.draft.art.fit === 'fill' ? 'selected' : ''}>fill</option>
        </select>
      </label>
      <label>X Position<input type="range" min="0" max="100" step="1" data-path="art.x" value="${num(state.draft.art.x, 50)}" /></label>
      <label>Y Position<input type="range" min="0" max="100" step="1" data-path="art.y" value="${num(state.draft.art.y, 50)}" /></label>
      <label>Zoom<input type="range" min="0.5" max="1.8" step="0.05" data-path="art.zoom" value="${num(state.draft.art.zoom, 1)}" /></label>
      <label>Frame Theme<input type="text" data-path="art.frameTheme" value="${escapeHtml(state.draft.art.frameTheme)}" /></label>
      <label>Frame Tint<input type="color" data-path="art.frameTint" value="${escapeHtml(state.draft.art.frameTint)}" /></label>
      <label>Overlay<input type="text" data-path="art.overlay" value="${escapeHtml(state.draft.art.overlay)}" /></label>
      <label>Background<input type="text" data-path="art.background" value="${escapeHtml(state.draft.art.background)}" /></label>
      <label>Emblem<input type="text" data-path="art.emblem" value="${escapeHtml(state.draft.art.emblem)}" /></label>
      <label class="chip"><input type="checkbox" data-path="art.rarityBadge" ${state.draft.art.rarityBadge ? 'checked' : ''}/>Show Rarity Badge</label>
    </div>
    <label>Art Notes<textarea data-path="art.notes">${escapeHtml(state.draft.art.notes)}</textarea></label>
  `;
}

function renderNormalModeModule() {
  return `
    <div class="field-grid">
      <label>Battle Compatibility
        <select data-path="normal.battleCompatibility">
          <option value="both" ${state.draft.normal.battleCompatibility === 'both' ? 'selected' : ''}>both</option>
          <option value="duel_only" ${state.draft.normal.battleCompatibility === 'duel_only' ? 'selected' : ''}>duel_only</option>
          <option value="defense_only" ${state.draft.normal.battleCompatibility === 'defense_only' ? 'selected' : ''}>defense_only</option>
        </select>
      </label>
      <label>Required Modes<input type="text" data-path="normal.requiredModes" value="${escapeHtml(state.draft.normal.requiredModes)}" /></label>
      <label>Home Dimension<input type="text" data-path="normal.homeDimension" value="${escapeHtml(state.draft.normal.homeDimension)}" /></label>
      <label>Pack Type<input type="text" data-path="normal.packType" value="${escapeHtml(state.draft.normal.packType)}" /></label>
      <label>Catch Limit<input type="number" min="0" data-path="normal.catchLimit" value="${num(state.draft.normal.catchLimit, 0)}" /></label>
      <label class="chip"><input type="checkbox" data-path="normal.includeInPacks" ${state.draft.normal.includeInPacks ? 'checked' : ''} />Include in Packs</label>
      <label class="chip"><input type="checkbox" data-path="normal.localExclusive" ${state.draft.normal.localExclusive ? 'checked' : ''} />Exclusive to Local Multiplayer</label>
    </div>
    <div class="note">Use the Race & Familiarity step for species selection, threshold scaling, and dragon-family setup. Local-exclusive cards stay out of the standard normal pool and only enter Local Player.</div>
  `;
}

function renderConquestModule() {
  const context = state.conquestContext;
  return `
    ${context ? `<div class="success-box">Conquest context: ${escapeHtml(context.planetName ?? 'Capital')} • ${escapeHtml(context.worldName ?? 'World')} • ${(context.elements ?? []).map((entry) => escapeHtml(entry)).join(' / ') || 'No element data'}</div>` : ''}
    <div class="field-grid">
      <label>Side
        <select data-path="conquest.side">
          <option value="defender" ${state.draft.conquest.side === 'defender' ? 'selected' : ''}>defender</option>
          <option value="attacker" ${state.draft.conquest.side === 'attacker' ? 'selected' : ''}>attacker</option>
        </select>
      </label>
      <label>Production Source
        <select data-path="conquest.productionSource">
          ${CONQUEST_SOURCES.map((source) => `<option value="${source}" ${state.draft.conquest.productionSource === source ? 'selected' : ''}>${source}</option>`).join('')}
        </select>
      </label>
      <label>Building Type<input type="text" data-path="conquest.buildingType" value="${escapeHtml(state.draft.conquest.buildingType)}" /></label>
      <label>Attack Range<input type="number" min="1" data-path="conquest.attackRange" value="${num(state.draft.conquest.attackRange, 1)}" /></label>
      <label>Movement<input type="number" min="0" data-path="conquest.movement" value="${num(state.draft.conquest.movement, 1)}" /></label>
      <label>Required Modes<input type="text" data-path="conquest.requiredModes" value="${escapeHtml(state.draft.conquest.requiredModes)}" /></label>
      <label>Battle Compatibility<input type="text" data-path="conquest.battleCompatibility" value="${escapeHtml(state.draft.conquest.battleCompatibility)}" /></label>
      <label>Conquest Branch
        <select data-path="conquest.conquestBranch">
          <option value="standard" ${state.draft.conquest.conquestBranch === 'standard' ? 'selected' : ''}>standard</option>
          <option value="attack" ${state.draft.conquest.conquestBranch === 'attack' ? 'selected' : ''}>attack</option>
          <option value="support" ${state.draft.conquest.conquestBranch === 'support' ? 'selected' : ''}>support</option>
          <option value="hero" ${state.draft.conquest.conquestBranch === 'hero' ? 'selected' : ''}>hero</option>
        </select>
      </label>
      <label class="chip"><input type="checkbox" data-path="conquest.producible" ${state.draft.conquest.producible ? 'checked' : ''}/>Producible</label>
      <label class="chip"><input type="checkbox" data-path="conquest.generatedConquestOnly" ${state.draft.conquest.generatedConquestOnly ? 'checked' : ''}/>Conquest-only</label>
      <label class="chip"><input type="checkbox" data-path="conquest.localMultiplayerExcluded" ${state.draft.conquest.localMultiplayerExcluded ? 'checked' : ''}/>Exclude Local Multiplayer</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isBuilding" ${state.draft.conquest.isBuilding ? 'checked' : ''}/>Building</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isTurret" ${state.draft.conquest.isTurret ? 'checked' : ''}/>Turret</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isBarricade" ${state.draft.conquest.isBarricade ? 'checked' : ''}/>Barricade</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isFacility" ${state.draft.conquest.isFacility ? 'checked' : ''}/>Facility</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isUpgrade" ${state.draft.conquest.isUpgrade ? 'checked' : ''}/>Upgrade</label>
      <label class="chip"><input type="checkbox" data-path="conquest.isEquipment" ${state.draft.conquest.isEquipment ? 'checked' : ''}/>Equipment</label>
      <label class="chip"><input type="checkbox" data-path="conquest.homestead" ${state.draft.conquest.homestead ? 'checked' : ''}/>Homestead</label>
      <label class="chip"><input type="checkbox" data-path="conquest.pylon" ${state.draft.conquest.pylon ? 'checked' : ''}/>Mana Pylon</label>
    </div>
    <div class="note">Conquest-authored cards are expected to stay conquest-only by default, especially when launched from a conquest planet context. The advanced creator now supports attacker/defender triggers, branch-aware targeting, lane scope, and local-leakage warnings.</div>
  `;
}

function renderTokenLinksModule() {
  return `
    <div class="field-grid">
      <label>Summons<input type="text" data-path="tokenLinks.summons" value="${escapeHtml(state.draft.tokenLinks.summons)}" placeholder="token-id-1,token-id-2" /></label>
      <label>Generated By<input type="text" data-path="tokenLinks.generatedBy" value="${escapeHtml(state.draft.tokenLinks.generatedBy)}" /></label>
      <label>Upgrades Into<input type="text" data-path="tokenLinks.upgradesInto" value="${escapeHtml(state.draft.tokenLinks.upgradesInto)}" /></label>
      <label>Equipped By<input type="text" data-path="tokenLinks.equippedBy" value="${escapeHtml(state.draft.tokenLinks.equippedBy)}" /></label>
    </div>
    <div class="note">Use IDs to form card relationship graphs and generator links.</div>
  `;
}

function renderCollectionModule() {
  return `
    <div class="field-grid">
      <label>Collection<input type="text" data-path="metadata.collection" value="${escapeHtml(state.draft.metadata.collection)}" placeholder="Volcanic Ash Collection" /></label>
      <label>Pack Name<input type="text" data-path="metadata.packName" value="${escapeHtml(state.draft.metadata.packName)}" placeholder="Gen 4 Booster" /></label>
      <label>World<input type="text" data-path="metadata.world" value="${escapeHtml(state.draft.metadata.world)}" /></label>
      <label>Production Source Label<input type="text" data-path="metadata.productionSource" value="${escapeHtml(state.draft.metadata.productionSource)}" /></label>
      <label>Role<input type="text" data-path="metadata.role" value="${escapeHtml(state.draft.metadata.role)}" /></label>
      <label>Creator Tags<input type="text" data-path="metadata.creatorTags" value="${escapeHtml(state.draft.metadata.creatorTags)}" /></label>
      <label>Tags CSV<textarea data-path="metadata.tags">${escapeHtml(state.draft.metadata.tags)}</textarea></label>
    </div>
  `;
}

function buildCreatorCompendiumSnapshot(modeKey = 'duel') {
  const abilities = new Map();
  const rarities = new Map();
  const races = new Map();
  const cards = creatorCatalogCards().filter((card) => cardModeFlags(card)[modeKey]);
  cards.forEach((card) => {
    const rarity = String(card.rarity ?? 'common').toLowerCase();
    rarities.set(rarity, (rarities.get(rarity) ?? 0) + 1);
    uniqCompact([card.race, ...(Array.isArray(card.races) ? card.races : []), card.species]).forEach((race) => {
      const normalized = slug(race);
      if (normalized) races.set(normalized, (races.get(normalized) ?? 0) + 1);
    });
    uniqCompact([
      ...(Array.isArray(card.keywords) ? card.keywords : []),
      ...KEYWORD_DEFS.filter((entry) => card[entry.key] === true).map((entry) => entry.key),
    ]).forEach((keyword) => {
      const label = KEYWORD_DEFS.find((entry) => entry.key === keyword)?.label ?? titleCaseWords(keyword);
      const key = `keyword:${keyword}`;
      const bucket = abilities.get(key) ?? { label, description: `Keyword: ${label}.`, count: 0, examples: new Set() };
      bucket.count += 1;
      if (bucket.examples.size < 4 && card.name) bucket.examples.add(card.name);
      abilities.set(key, bucket);
    });
    const abilityBlocks = []
      .concat(Array.isArray(card.abilities) ? card.abilities : [])
      .concat(card.ability && typeof card.ability === 'object' ? [card.ability] : []);
    abilityBlocks.forEach((block, index) => {
      const label = String(block.name ?? titleCaseWords(String(block.effect ?? block.action ?? `ability ${index + 1}`)));
      const description = String(block.text ?? '').trim() || abilitySummary({
        ...createAbilityBlock(),
        ...block,
        id: block.id ?? `import-${index}`,
      });
      const key = `ability:${slug(label)}:${slug(description.slice(0, 80))}`;
      const bucket = abilities.get(key) ?? { label, description, count: 0, examples: new Set() };
      bucket.count += 1;
      if (bucket.examples.size < 4 && card.name) bucket.examples.add(card.name);
      abilities.set(key, bucket);
    });
  });
  return {
    cards,
    abilities: [...abilities.values()].sort((a, b) => b.count - a.count || a.label.localeCompare(b.label)),
    rarities: [...rarities.entries()].sort((a, b) => (RARITIES.indexOf(a[0]) - RARITIES.indexOf(b[0])) || a[0].localeCompare(b[0])),
    races: [...races.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])),
  };
}

function renderDocFieldList(items = []) {
  return items.map((entry) => `
    <div class="compendium-doc-row">
      <strong>${escapeHtml(entry.path)}</strong>
      <span>${escapeHtml(entry.scope)}</span>
      <small>${escapeHtml(entry.description)}</small>
    </div>
  `).join('');
}

function renderCompendiumModule() {
  const duel = buildCreatorCompendiumSnapshot('duel');
  const conquest = buildCreatorCompendiumSnapshot('conquest');
  const externalPackCount = state.externalUserPacks.length;
  return `
    <div class="compendium-stack">
      <div class="success-box">
        Drop pack JSON files into <code>user_packs/</code>. The launcher/shop will detect them automatically, and this compendium refreshes from saved cards + shared packs + external JSON packs.
        Example path: <code>${escapeHtml(CREATOR_USER_PACKS_EXAMPLE.replace('../', ''))}</code>
      </div>
      <div class="field-grid">
        <div class="compendium-stat-card"><strong>Duel Cards</strong><span>${duel.cards.length}</span></div>
        <div class="compendium-stat-card"><strong>Conquest Cards</strong><span>${conquest.cards.length}</span></div>
        <div class="compendium-stat-card"><strong>External Packs</strong><span>${externalPackCount}</span></div>
        <div class="compendium-stat-card"><strong>Triggers</strong><span>${ABILITY_TRIGGER_OPTIONS.length}</span></div>
      </div>
      <div class="compendium-grid">
        <section class="compendium-panel">
          <div class="compendium-head"><strong>Duel Ability Compendium</strong><span>${duel.abilities.length}</span></div>
          <div class="compendium-scroll">
            ${duel.abilities.slice(0, 120).map((entry) => `
              <article class="compendium-entry">
                <div class="row"><strong>${escapeHtml(entry.label)}</strong><small>${entry.count} card(s)</small></div>
                <div class="compendium-copy">${escapeHtml(entry.description)}</div>
                <small>${[...entry.examples].map((value) => escapeHtml(value)).join(' • ')}</small>
              </article>
            `).join('') || '<div class="note">No duel abilities indexed yet.</div>'}
          </div>
        </section>
        <section class="compendium-panel">
          <div class="compendium-head"><strong>Conquest Ability Compendium</strong><span>${conquest.abilities.length}</span></div>
          <div class="compendium-scroll">
            ${conquest.abilities.slice(0, 120).map((entry) => `
              <article class="compendium-entry">
                <div class="row"><strong>${escapeHtml(entry.label)}</strong><small>${entry.count} card(s)</small></div>
                <div class="compendium-copy">${escapeHtml(entry.description)}</div>
                <small>${[...entry.examples].map((value) => escapeHtml(value)).join(' • ')}</small>
              </article>
            `).join('') || '<div class="note">No conquest abilities indexed yet.</div>'}
          </div>
        </section>
      </div>
      <div class="compendium-grid">
        <section class="compendium-panel">
          <div class="compendium-head"><strong>Rarities</strong><span>${[...new Set([...duel.rarities.map(([key]) => key), ...conquest.rarities.map(([key]) => key), ...RARITIES])].length}</span></div>
          <div class="chip-bucket">
            ${[...new Set([...RARITIES, ...duel.rarities.map(([key]) => key), ...conquest.rarities.map(([key]) => key)])].map((rarity) => {
              const duelCount = duel.rarities.find(([key]) => key === rarity)?.[1] ?? 0;
              const conquestCount = conquest.rarities.find(([key]) => key === rarity)?.[1] ?? 0;
              return `<span class="race-chip static">${escapeHtml(rarity)} • D ${duelCount} • C ${conquestCount}</span>`;
            }).join('')}
          </div>
          <div class="compendium-head"><strong>Races</strong><span>${DUEL_FAMILIES.length}</span></div>
          <div class="chip-bucket">
            ${DUEL_FAMILIES.map((family) => {
              const meta = raceMeta(family);
              const duelCount = duel.races.find(([key]) => key === family)?.[1] ?? 0;
              const conquestCount = conquest.races.find(([key]) => key === family)?.[1] ?? 0;
              return `<span class="race-chip static">${raceIconGlyph(meta.id)} ${escapeHtml(meta.label)} • D ${duelCount} • C ${conquestCount}</span>`;
            }).join('')}
          </div>
          <div class="compendium-head"><strong>Ability Builder Options</strong><span>${ABILITY_TRIGGER_OPTIONS.length + ABILITY_TARGET_OPTIONS.length + ABILITY_EFFECT_OPTIONS.length}</span></div>
          <div class="chip-bucket">
            ${ABILITY_TRIGGER_OPTIONS.map((entry) => `<span class="race-chip static">${escapeHtml(entry)}</span>`).join('')}
            ${ABILITY_TARGET_OPTIONS.map((entry) => `<span class="race-chip static">${escapeHtml(entry)}</span>`).join('')}
            ${ABILITY_EFFECT_OPTIONS.map((entry) => `<span class="race-chip static">${escapeHtml(entry)}</span>`).join('')}
          </div>
        </section>
        <section class="compendium-panel">
          <div class="compendium-head"><strong>JSON Pack Fields</strong><span>${PACK_SCHEMA_FIELD_DOCS.length}</span></div>
          <div class="compendium-scroll">${renderDocFieldList(PACK_SCHEMA_FIELD_DOCS)}</div>
          <div class="compendium-head"><strong>Card Fields</strong><span>${CARD_SCHEMA_FIELD_DOCS.length}</span></div>
          <div class="compendium-scroll">${renderDocFieldList(CARD_SCHEMA_FIELD_DOCS)}</div>
        </section>
      </div>
    </div>
  `;
}

function renderTemplatesModule() {
  const templates = allTemplates().filter((entry) => entry.mode === state.ui.mode || entry.mode === 'hybrid');
  return `
    <div class="field-grid">
      <label>Template
        <select id="template-select-module">
          ${templates.map((template) => `<option value="${template.id}">${escapeHtml(template.label)} (${escapeHtml(template.type)})</option>`).join('')}
        </select>
      </label>
      <label>Template Name for Save<input type="text" id="save-template-name" placeholder="My custom template" /></label>
    </div>
    <div class="inline-chips">
      <button type="button" data-action="apply-template-from-module">Apply Template</button>
      <button type="button" data-action="save-user-template">Save as User Template</button>
      <button type="button" data-action="duplicate-card">Duplicate Card</button>
      <button type="button" data-action="clone-variant">Clone Variant</button>
    </div>
    <div class="template-list">
      ${state.userTemplates.length ? state.userTemplates.map((template, idx) => `
        <div class="template-item">
          <div class="row">
            <strong>${escapeHtml(template.label)}</strong>
            <small>${escapeHtml(template.mode)} • ${escapeHtml(template.type)}</small>
          </div>
          <div class="row" style="margin-top:.28rem;">
            <button type="button" data-action="apply-user-template" data-user-template-index="${idx}">Apply</button>
            <button type="button" data-action="delete-user-template" data-user-template-index="${idx}">Delete</button>
          </div>
        </div>
      `).join('') : '<div class="note">No user templates saved yet.</div>'}
    </div>
  `;
}

function renderValidationModule() {
  const errors = state.validation.errors;
  const warnings = state.validation.warnings;
  return `
    ${errors.length ? errors.map((entry) => `<div class="error-box">${escapeHtml(entry.message)} <button type="button" data-action="jump-to-path" data-path="${escapeHtml(entry.path || '')}">Jump</button></div>`).join('') : '<div class="success-box">No blocking errors detected.</div>'}
    ${warnings.length ? warnings.map((entry) => `<div class="warning">${escapeHtml(entry.message)} <button type="button" data-action="jump-to-path" data-path="${escapeHtml(entry.path || '')}">Jump</button></div>`).join('') : '<div class="note">No warnings.</div>'}
  `;
}

function renderSaveExportModule() {
  return `
    <div class="inline-chips">
      <button type="button" class="primary" data-action="save-card">Save Card</button>
      <button type="button" data-action="save-version">Save Version</button>
      <button type="button" data-action="export-card-json">Export Card JSON</button>
      <button type="button" data-action="import-card-json">Import Card JSON</button>
      <button type="button" data-action="reset-draft">New Draft</button>
    </div>
    <textarea id="exchange-json" class="mono" placeholder="JSON exchange area"></textarea>
  `;
}

function applyWorkspacePreset(name) {
  state.ui.workspace = name;
  if (name === 'compact') {
    state.ui.leftCollapsed = false;
    state.ui.rightCollapsed = false;
    state.ui.bottomCollapsed = true;
  } else if (name === 'ability_forge') {
    state.ui.leftCollapsed = false;
    state.ui.rightCollapsed = true;
    state.ui.bottomCollapsed = false;
    state.ui.activeModule = 'abilities';
    state.ui.modulePinned.abilities = true;
  } else if (name === 'preview_focus') {
    state.ui.leftCollapsed = true;
    state.ui.rightCollapsed = false;
    state.ui.bottomCollapsed = true;
  } else {
    state.ui.leftCollapsed = false;
    state.ui.rightCollapsed = false;
    state.ui.bottomCollapsed = false;
  }
  saveJsonStorage(STORAGE.uiPrefs, {
    workspace: state.ui.workspace,
    leftCollapsed: state.ui.leftCollapsed,
    rightCollapsed: state.ui.rightCollapsed,
    bottomCollapsed: state.ui.bottomCollapsed,
  });
  renderAll();
  logActivity(`Workspace preset applied: ${name}`);
}

function applyTemplateById(id) {
  const template = allTemplates().find((entry) => entry.id === id);
  if (!template) return;
  pushHistory(`template:${template.label}`);
  if (template.mode && template.mode !== 'hybrid') applyModeDefaults(template.mode);
  if (template.type) state.draft.type = template.type;
  mergeDeep(state.draft, safeClone(template.patch || {}));
  if (!state.draft.id) state.draft.id = slug(template.label);
  if (!state.draft.name) state.draft.name = template.label;
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Template applied: ${template.label}`);
}

function saveUserTemplate(name) {
  const label = String(name || '').trim();
  if (!label) {
    logActivity('Template save skipped (missing name).');
    return;
  }
  const template = {
    id: uid('usr-tmpl'),
    label,
    mode: state.ui.mode,
    type: state.draft.type,
    summary: 'User-saved template',
    patch: safeClone(state.draft),
  };
  state.userTemplates.push(template);
  saveJsonStorage(STORAGE.userTemplates, state.userTemplates);
  renderAll();
  logActivity(`Saved user template "${label}".`);
}

function applyUserTemplate(index) {
  const template = state.userTemplates[index];
  if (!template) return;
  pushHistory(`user-template:${template.label}`);
  state.draft = safeClone(template.patch);
  applyModeDefaults(template.mode || 'duel');
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Applied user template "${template.label}".`);
}

function removeUserTemplate(index) {
  if (!state.userTemplates[index]) return;
  const [removed] = state.userTemplates.splice(index, 1);
  saveJsonStorage(STORAGE.userTemplates, state.userTemplates);
  renderAll();
  logActivity(`Deleted user template "${removed.label}".`);
}

function addAbilityBlockFromPreset(presetId = '') {
  const preset = state.abilityTemplates.find((entry) => entry.id === presetId) ?? null;
  const block = createAbilityBlock(preset);
  state.draft.abilities.push(block);
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Ability block added${preset ? ` (${preset.name})` : ''}.`);
}

function updateAbilityField(abilityId, field, value) {
  const block = state.draft.abilities.find((entry) => entry.id === abilityId);
  if (!block) return;
  const numericFields = new Set(['amount', 'duration', 'cooldown', 'charges', 'threshold', 'familiarityAmount', 'familiarityThreshold']);
  if (numericFields.has(field)) block[field] = num(value, 0);
  else if (field === 'oncePerTurn') block[field] = bool(value);
  else block[field] = value;
  state.draft.updatedAt = Date.now();
  validateDraft();
  renderStatusRow();
  renderRightPane();
  if (state.ui.bottomTab === 'ability-json') renderBottomPane();
}

function moveAbility(abilityId, delta) {
  const idx = state.draft.abilities.findIndex((entry) => entry.id === abilityId);
  if (idx < 0) return;
  const next = idx + delta;
  if (next < 0 || next >= state.draft.abilities.length) return;
  const [entry] = state.draft.abilities.splice(idx, 1);
  state.draft.abilities.splice(next, 0, entry);
  queueAutosave();
  renderAll();
}

function duplicateAbility(abilityId) {
  const block = state.draft.abilities.find((entry) => entry.id === abilityId);
  if (!block) return;
  const clone = safeClone(block);
  clone.id = uid('ability');
  clone.name = `${clone.name || 'Ability'} Copy`;
  state.draft.abilities.push(clone);
  queueAutosave();
  renderAll();
}

function toggleDraftRace(family = '') {
  const next = draftRaceList();
  const normalized = normalizeFamilyId(family);
  if (!normalized) return;
  const idx = next.indexOf(normalized);
  if (idx >= 0) next.splice(idx, 1);
  else next.push(normalized);
  setDraftRaceList(next);
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
}

function applyRaceArchetype(archetypeId = '') {
  const preset = RACE_ARCHETYPE_PRESETS[archetypeId];
  if (!preset) return;
  setDraftRaceList(preset.races);
  state.draft.normal.synergy = preset.synergy;
  state.draft.metadata.role = preset.role;
  Object.assign(state.draft.keywords, preset.keywords ?? {});
  state.draft.normal.familiarityRace = preset.races[0] ?? '';
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Applied race archetype: ${preset.label}.`);
}

function deleteAbility(abilityId) {
  const idx = state.draft.abilities.findIndex((entry) => entry.id === abilityId);
  if (idx < 0) return;
  state.draft.abilities.splice(idx, 1);
  delete state.ui.abilityCollapsed[abilityId];
  validateDraft();
  queueAutosave();
  renderAll();
}

function toggleAbilityCollapse(abilityId) {
  state.ui.abilityCollapsed[abilityId] = !state.ui.abilityCollapsed[abilityId];
  renderCenterPane();
}

function toggleModuleCollapse(moduleId) {
  state.ui.moduleCollapsed[moduleId] = !state.ui.moduleCollapsed[moduleId];
  renderCenterPane();
}

function toggleModulePin(moduleId) {
  state.ui.modulePinned[moduleId] = !state.ui.modulePinned[moduleId];
  renderCenterPane();
}

function moveModule(moduleId, delta) {
  const modules = visibleModules();
  const ids = modules.map((mod) => mod.id);
  const idx = ids.indexOf(moduleId);
  if (idx < 0) return;
  const next = idx + delta;
  if (next < 0 || next >= ids.length) return;
  const currentOrder = state.ui.moduleOrder.length ? state.ui.moduleOrder.slice() : moduleRegistry().map((mod) => mod.id);
  const a = currentOrder.indexOf(moduleId);
  const b = currentOrder.indexOf(ids[next]);
  if (a < 0 || b < 0) return;
  const tmp = currentOrder[a];
  currentOrder[a] = currentOrder[b];
  currentOrder[b] = tmp;
  state.ui.moduleOrder = currentOrder;
  queueAutosave();
  renderCenterPane();
}

function jumpToModule(moduleId) {
  state.ui.activeModule = moduleId;
  const node = document.querySelector(`#module-${moduleId}`);
  if (node) node.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function draftToCardPayload() {
  const tagSet = new Set(draftTagsArray());
  const races = draftRaceList();
  tagSet.add('GEN4');
  tagSet.add(state.ui.mode === 'conquest' ? 'conquest' : 'duel');
  races.forEach((race) => tagSet.add(race));
  const ability = state.draft.abilities[0]
    ? {
      trigger: state.draft.abilities[0].trigger,
      action: state.draft.abilities[0].effect,
      amount: state.draft.abilities[0].amount,
      duration: state.draft.abilities[0].duration,
      condition: state.draft.abilities[0].condition || null,
      family: state.draft.abilities[0].family || null,
      familyZone: state.draft.abilities[0].familyZone || null,
      sourceFamily: state.draft.abilities[0].sourceFamily || null,
      targetFamily: state.draft.abilities[0].targetFamily || null,
      controllerFamily: state.draft.abilities[0].controllerFamily || null,
      deadFamily: state.draft.abilities[0].deadFamily || null,
      threshold: num(state.draft.abilities[0].threshold, 0),
      familiarityRace: state.draft.abilities[0].familiarityRace || null,
      familiarityThreshold: num(state.draft.abilities[0].familiarityThreshold, 0),
      familiarityAmount: num(state.draft.abilities[0].familiarityAmount, 0),
      text: abilitySummary(state.draft.abilities[0]),
    }
    : null;
  const card = {
    id: state.draft.id.trim(),
    name: state.draft.name.trim(),
    type: state.draft.type,
    cost: num(state.draft.cost.mana, 0),
    wheatCost: num(state.draft.cost.wheat, 0),
    ironCost: num(state.draft.cost.iron, 0),
    attack: num(state.draft.stats.attack, 0),
    health: num(state.draft.stats.health, 1),
    def: num(state.draft.stats.defense, 0),
    range: num(state.draft.stats.range, 1),
    movement: num(state.draft.stats.movement, 1),
    rarity: state.draft.rarity,
    race: races[0] || state.draft.normal.race || null,
    races,
    element: state.draft.normal.element || null,
    damage: num(state.draft.normal.damage, 0),
    text: state.draft.text,
    keywords: KEYWORD_DEFS.filter((entry) => state.draft.keywords[entry.key]).map((entry) => entry.key),
    ability,
    abilities: safeClone(state.draft.abilities),
    synergy: String(state.draft.normal.synergy || '').split(',').map((item) => item.trim()).filter(Boolean),
    includeInPacks: !!state.draft.normal.includeInPacks,
    localExclusive: !!state.draft.normal.localExclusive,
    packType: state.draft.normal.packType || 'booster',
    catchLimit: num(state.draft.normal.catchLimit, 0),
    homeDimension: state.draft.normal.homeDimension || '',
    familiarity: {
      race: state.draft.normal.familiarityRace || null,
      start: num(state.draft.normal.familiarityStart, 0),
      threshold: num(state.draft.normal.familiarityThreshold, 0),
      reward: state.draft.normal.familiarityReward || '',
      notes: state.draft.normal.familiarityNotes || '',
    },
    battleCompatibility: state.ui.mode === 'conquest' ? state.draft.conquest.battleCompatibility : state.draft.normal.battleCompatibility,
    requiredModes: state.ui.mode === 'conquest' ? state.draft.conquest.requiredModes : state.draft.normal.requiredModes,
    production: {
      producible: !!state.draft.conquest.producible,
      buildingType: state.draft.conquest.buildingType,
      speciesOrigin: races[0] || state.draft.normal.race,
      worldOrigin: state.draft.metadata.world,
      unlockByWorld: state.draft.metadata.world,
      loseWithWorld: false,
      techRequirement: 0,
      favorRequirement: 0,
      productionCostGold: num(state.draft.cost.iron, 0),
      productionCostLifeforce: num(state.draft.cost.wheat, 0),
      reinforcementTier: 1,
      requiredModes: state.draft.conquest.requiredModes || '',
    },
    campaignMeta: {
      battleCompatibility: state.ui.mode === 'conquest' ? state.draft.conquest.battleCompatibility : state.draft.normal.battleCompatibility,
      producible: !!state.draft.conquest.producible,
      productionBuildingType: state.draft.conquest.productionSource,
      speciesOrigin: races[0] || state.draft.normal.race,
      worldOrigin: state.draft.metadata.world,
      unlockByWorld: state.draft.metadata.world,
      loseWithWorld: false,
      techRequirement: 0,
      favorRequirement: 0,
      productionCostGold: num(state.draft.cost.iron, 0),
      productionCostLifeforce: num(state.draft.cost.wheat, 0),
      reinforcementTier: 1,
      requiredModes: state.ui.mode === 'conquest' ? state.draft.conquest.requiredModes : state.draft.normal.requiredModes,
    },
    mtgMeta: {
      collection: state.draft.metadata.collection,
      packName: state.draft.metadata.packName,
      world: state.draft.metadata.world,
      role: state.draft.metadata.role,
      notes: state.draft.metadata.notes,
    },
    art: safeClone(state.draft.art),
    targeting: safeClone(state.draft.targeting),
    tokenLinks: safeClone(state.draft.tokenLinks),
    conquest: safeClone(state.draft.conquest),
    metadata: safeClone(state.draft.metadata),
    tags: [...tagSet, 'custom-made'],
    creatorStudioVersion: 2,
    sourceType: 'custom-made',
    customMade: true,
  };
  KEYWORD_DEFS.forEach((entry) => { card[entry.key] = !!state.draft.keywords[entry.key]; });
  return card;
}

function loadCardToDraft(card) {
  const next = createDefaultDraft(card?.conquest?.productionSource ? 'conquest' : 'duel');
  next.id = card.id || '';
  next.name = card.name || '';
  next.type = card.type || next.type;
  next.rarity = card.rarity || next.rarity;
  next.text = card.text || '';
  next.cost.mana = num(card.cost, 0);
  next.cost.wheat = num(card.wheatCost, 0);
  next.cost.iron = num(card.ironCost, 0);
  next.stats.attack = num(card.attack, next.stats.attack);
  next.stats.health = num(card.health, next.stats.health);
  next.stats.defense = num(card.def, 0);
  next.stats.range = num(card.range, 1);
  next.stats.movement = num(card.movement, 1);
  next.normal.race = card.race || card.races?.[0] || '';
  next.normal.races = Array.isArray(card.races) ? card.races.join(', ') : (card.race ? String(card.race) : '');
  next.normal.element = card.element || '';
  next.normal.damage = num(card.damage, 0);
  next.normal.synergy = Array.isArray(card.synergy) ? card.synergy.join(',') : '';
  next.normal.familiarityRace = card.familiarity?.race || '';
  next.normal.familiarityStart = num(card.familiarity?.start, 0);
  next.normal.familiarityThreshold = num(card.familiarity?.threshold, 0);
  next.normal.familiarityReward = card.familiarity?.reward || '';
  next.normal.familiarityNotes = card.familiarity?.notes || '';
  next.normal.battleCompatibility = card.battleCompatibility || 'both';
  next.normal.requiredModes = card.requiredModes || '';
  next.normal.localExclusive = !!card.localExclusive;
  next.normal.homeDimension = card.homeDimension || '';
  next.normal.packType = card.packType || 'booster';
  next.normal.includeInPacks = card.includeInPacks !== false;
  next.normal.catchLimit = num(card.catchLimit, 0);
  next.abilities = Array.isArray(card.abilities)
    ? card.abilities.map((entry) => ({
      ...createAbilityBlock(),
      ...entry,
      id: entry.id || uid('ability'),
      effect: entry.effect?.action ?? entry.action ?? entry.effect ?? 'dealDamage',
      amount: num(entry.amount ?? entry.effect?.amount, 1),
      duration: num(entry.duration, 1),
      family: entry.family || '',
      familyZone: entry.familyZone || 'board',
      sourceFamily: entry.sourceFamily || '',
      targetFamily: entry.targetFamily || '',
      controllerFamily: entry.controllerFamily || '',
      deadFamily: entry.deadFamily || '',
      threshold: num(entry.threshold, 0),
      familiarityRace: entry.familiarityRace || '',
      familiarityAmount: num(entry.familiarityAmount, 0),
      familiarityThreshold: num(entry.familiarityThreshold, 0),
    }))
    : (card.ability ? [{
      ...createAbilityBlock(),
      trigger: card.ability.trigger || 'battlecry',
      effect: card.ability.action || 'dealDamage',
      amount: num(card.ability.amount, 1),
      duration: num(card.ability.duration, 1),
      condition: card.ability.condition || '',
      notes: card.ability.text || '',
      family: card.ability.family || '',
      familyZone: card.ability.familyZone || 'board',
      sourceFamily: card.ability.sourceFamily || '',
      targetFamily: card.ability.targetFamily || '',
      controllerFamily: card.ability.controllerFamily || '',
      deadFamily: card.ability.deadFamily || '',
      threshold: num(card.ability.threshold, 0),
      familiarityRace: card.ability.familiarityRace || '',
      familiarityAmount: num(card.ability.familiarityAmount, 0),
      familiarityThreshold: num(card.ability.familiarityThreshold, 0),
    }] : []);
  const tagSet = new Set(card.keywords || []);
  KEYWORD_DEFS.forEach((entry) => {
    next.keywords[entry.key] = bool(card[entry.key]) || tagSet.has(entry.key);
  });
  next.conquest = {
    ...next.conquest,
    ...(card.conquest || {}),
    productionSource: card.conquest?.productionSource || card.production?.buildingType || next.conquest.productionSource,
    side: card.conquest?.side || 'defender',
  };
  next.metadata = {
    ...next.metadata,
    ...(card.metadata || {}),
    tags: Array.isArray(card.tags) ? card.tags.join(', ') : next.metadata.tags,
  };
  next.art = { ...next.art, ...(card.art || {}) };
  next.tokenLinks = { ...next.tokenLinks, ...(card.tokenLinks || {}) };
  next.targeting = { ...next.targeting, ...(card.targeting || {}) };
  next.creatorStudioVersion = 2;
  state.draft = next;
  const mode = card?.conquest?.productionSource || card?.conquest?.isBuilding ? 'conquest' : deduceModeFromTemplate(card);
  applyModeDefaults(mode);
  validateDraft();
}

function saveCurrentCard() {
  validateDraft();
  if (state.validation.errors.length) {
    logActivity('Save blocked: resolve validation errors first.');
    renderRightPane();
    renderBottomPane();
    return;
  }
  const payload = draftToCardPayload();
  const persisted = persistCustomCard(payload);
  state.draft.updatedAt = Date.now();
  state.recentCards = [{ id: payload.id, name: payload.name, type: payload.type, at: Date.now() }, ...state.recentCards.filter((entry) => entry.id !== payload.id)].slice(0, 20);
  saveJsonStorage(STORAGE.recentCards, state.recentCards);
  queueAutosave();
  logActivity(`${persisted.savedCard.name} ${persisted.isNew ? 'created' : 'updated'} in custom card library.`);
  renderStatusRow();
  renderLeftPane();
  renderBottomPane();
}

function saveVersion(label = '') {
  const version = {
    at: Date.now(),
    label: label || `${state.draft.name || state.draft.id || 'Card'} snapshot`,
    draft: safeClone(state.draft),
  };
  state.versions.unshift(version);
  state.versions = state.versions.slice(0, 60);
  saveJsonStorage(STORAGE.versions, state.versions);
  logActivity(`Version saved: ${version.label}`);
  renderBottomPane();
}

function restoreVersion(index) {
  const version = state.versions[index];
  if (!version) return;
  pushHistory('restore-version');
  state.draft = safeClone(version.draft);
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity(`Version restored: ${version.label}`);
}

function deleteVersion(index) {
  const version = state.versions[index];
  if (!version) return;
  state.versions.splice(index, 1);
  saveJsonStorage(STORAGE.versions, state.versions);
  renderBottomPane();
  logActivity(`Version deleted: ${version.label}`);
}

function exportCardJson() {
  const area = document.querySelector('#exchange-json');
  if (!area) return;
  area.value = JSON.stringify(draftToCardPayload(), null, 2);
  logActivity('Card JSON exported to exchange area.');
}

function importCardJson() {
  const area = document.querySelector('#exchange-json');
  if (!area) return;
  try {
    const parsed = JSON.parse(area.value || '{}');
    pushHistory('import-json');
    loadCardToDraft(parsed);
    queueAutosave();
    renderAll();
    logActivity('Card JSON imported successfully.');
  } catch {
    logActivity('Import failed: invalid JSON.');
    renderBottomPane();
  }
}

function copyProjectJson() {
  const area = document.querySelector('#project-json-editor');
  if (!area) return;
  area.select();
  document.execCommand('copy');
  logActivity('Project JSON copied.');
}

function importProjectJson() {
  const area = document.querySelector('#project-json-editor');
  if (!area) return;
  try {
    const parsed = JSON.parse(area.value || '{}');
    pushHistory('import-project');
    state.draft = mergeDeep(createDefaultDraft(state.ui.mode), parsed);
    validateDraft();
    queueAutosave();
    renderAll();
    logActivity('Project JSON imported.');
  } catch {
    logActivity('Project JSON import failed: invalid JSON.');
    renderBottomPane();
  }
}

function duplicateCard() {
  pushHistory('duplicate-card');
  state.draft.id = `${state.draft.id || 'card'}-copy`;
  state.draft.name = `${state.draft.name || 'Card'} Copy`;
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity('Card duplicated.');
}

function cloneVariant() {
  pushHistory('clone-variant');
  state.draft.id = `${state.draft.id || 'card'}-variant-${Math.floor(Math.random() * 90 + 10)}`;
  state.draft.name = `${state.draft.name || 'Card'} Variant`;
  state.draft.rarity = state.draft.rarity === 'legendary' ? 'epic' : state.draft.rarity;
  state.draft.updatedAt = Date.now();
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity('Variant clone created.');
}

function evaluateCurrentCard() {
  if (!window.CardForgeDeckRater?.open) {
    logActivity('Deck evaluator runtime unavailable.');
    return;
  }
  if (state.ui.mode !== 'duel') {
    logActivity('Card evaluation is only available for Normal Mode cards.');
    renderBottomPane();
    return;
  }
  const payload = draftToCardPayload();
  window.CardForgeDeckRater.open({ entry: 'creator', mode: 'card', suppliedCard: payload });
  logActivity(`Opened evaluator for ${payload.name || payload.id}.`);
}

function resetDraft() {
  pushHistory('reset-draft');
  state.draft = createDefaultDraft(state.ui.mode);
  validateDraft();
  queueAutosave();
  renderAll();
  logActivity('Started a new draft.');
}

function commandItems() {
  const base = [
    { id: 'save-card', label: 'Save Card', group: 'File' },
    { id: 'evaluate-card', label: 'Evaluate Card', group: 'Quality' },
    { id: 'save-version', label: 'Save Version Snapshot', group: 'File' },
    { id: 'export-card-json', label: 'Export Card JSON', group: 'File' },
    { id: 'import-card-json', label: 'Import Card JSON', group: 'File' },
    { id: 'undo', label: 'Undo', group: 'Edit' },
    { id: 'redo', label: 'Redo', group: 'Edit' },
    { id: 'duplicate-card', label: 'Duplicate Card', group: 'Edit' },
    { id: 'clone-variant', label: 'Clone Variant', group: 'Edit' },
    { id: 'quick-validate', label: 'Run Validation', group: 'Quality' },
    { id: 'preview-popout', label: 'Preview Popout', group: 'View' },
    { id: 'toggle-left', label: 'Toggle Left Sidebar', group: 'View' },
    { id: 'toggle-right', label: 'Toggle Right Sidebar', group: 'View' },
    { id: 'toggle-bottom', label: 'Toggle Bottom Drawer', group: 'View' },
  ];
  const moduleCommands = moduleRegistry().map((module) => ({ id: `goto:${module.id}`, label: `Go to ${module.title}`, group: 'Modules' }));
  const templateCommands = allTemplates().slice(0, 20).map((template) => ({ id: `template:${template.id}`, label: `Apply Template: ${template.label}`, group: 'Templates' }));
  return [...base, ...moduleCommands, ...templateCommands];
}

function runCommand(commandId) {
  if (commandId.startsWith('goto:')) {
    jumpToModule(commandId.split(':')[1]);
    return;
  }
  if (commandId.startsWith('template:')) {
    applyTemplateById(commandId.split(':')[1]);
    return;
  }
  const directMap = {
    'save-card': saveCurrentCard,
    'evaluate-card': evaluateCurrentCard,
    'save-version': () => saveVersion('Palette Snapshot'),
    'export-card-json': exportCardJson,
    'import-card-json': importCardJson,
    undo,
    redo,
    'duplicate-card': duplicateCard,
    'clone-variant': cloneVariant,
    'quick-validate': () => {
      validateDraft();
      renderStatusRow();
      renderRightPane();
      renderCenterPane();
      logActivity('Validation refreshed.');
    },
    'preview-popout': openPreviewPopout,
    'toggle-left': () => { state.ui.leftCollapsed = !state.ui.leftCollapsed; renderAll(); },
    'toggle-right': () => { state.ui.rightCollapsed = !state.ui.rightCollapsed; renderAll(); },
    'toggle-bottom': () => { state.ui.bottomCollapsed = !state.ui.bottomCollapsed; renderAll(); },
  };
  if (directMap[commandId]) directMap[commandId]();
}

function bindDropzone() {
  const zone = document.querySelector('#art-dropzone');
  if (!zone || zone.dataset.bound === 'yes') return;
  zone.dataset.bound = 'yes';
  zone.addEventListener('dragover', (event) => {
    event.preventDefault();
    zone.classList.add('dragging');
  });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragging'));
  zone.addEventListener('drop', (event) => {
    event.preventDefault();
    zone.classList.remove('dragging');
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    loadArtFile(file);
  });
}

function loadArtFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    pushHistory('art-upload');
    state.draft.art.src = String(reader.result || '');
    state.draft.updatedAt = Date.now();
    queueAutosave();
    renderRightPane();
    renderCenterPane();
    logActivity(`Art uploaded: ${file.name}`);
  };
  reader.readAsDataURL(file);
}

function openPreviewPopout() {
  const overlay = document.querySelector('#preview-popout');
  const body = document.querySelector('#preview-popout-body');
  const source = document.querySelector('.preview-stage');
  if (!overlay || !body || !source) return;
  body.innerHTML = source.innerHTML;
  overlay.classList.remove('hidden');
  overlay.setAttribute('aria-hidden', 'false');
}

function closePreviewPopout() {
  const overlay = document.querySelector('#preview-popout');
  if (!overlay) return;
  overlay.classList.add('hidden');
  overlay.setAttribute('aria-hidden', 'true');
}

function updateDraftFieldFromInput(input) {
  const path = input.dataset.path;
  if (!path) return;
  const type = input.type;
  let value;
  if (type === 'checkbox') value = input.checked;
  else if (type === 'number' || type === 'range') value = num(input.value, 0);
  else value = input.value;
  byPathSet(state.draft, path, value);
  if (path === 'normal.race') setDraftRaceList([value, ...draftRaceList().filter((entry) => entry !== normalizeFamilyId(value))]);
  if (path === 'normal.races') setDraftRaceList(parseCsv(value));
  state.draft.updatedAt = Date.now();
  validateDraft();
  renderStatusRow();
  renderRightPane();
  if (state.ui.bottomTab === 'project-json' || state.ui.bottomTab === 'ability-json') renderBottomPane();
}

function bindGlobalEvents() {
  document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const action = target.dataset.action;
    if (!action) return;

    if (action === 'module-collapse') toggleModuleCollapse(target.dataset.module);
    else if (action === 'module-pin') toggleModulePin(target.dataset.module);
    else if (action === 'module-move-up') moveModule(target.dataset.module, -1);
    else if (action === 'module-move-down') moveModule(target.dataset.module, 1);
    else if (action === 'jump-module') jumpToModule(target.dataset.module);
    else if (action === 'toggle-left') { state.ui.leftCollapsed = !state.ui.leftCollapsed; renderAll(); }
    else if (action === 'toggle-right') { state.ui.rightCollapsed = !state.ui.rightCollapsed; renderAll(); }
    else if (action === 'toggle-bottom') { state.ui.bottomCollapsed = !state.ui.bottomCollapsed; renderAll(); }
    else if (action === 'bottom-tab') { state.ui.bottomTab = target.dataset.tab; renderBottomPane(); }
    else if (action === 'apply-template') applyTemplateById(target.dataset.templateId);
    else if (action === 'apply-template-from-module') {
      const select = document.querySelector('#template-select-module');
      applyTemplateById(select?.value || '');
    }
    else if (action === 'toggle-race-tag') toggleDraftRace(target.dataset.race);
    else if (action === 'apply-race-archetype') applyRaceArchetype(target.dataset.archetype);
    else if (action === 'save-user-template') {
      const input = document.querySelector('#save-template-name');
      saveUserTemplate(input?.value || '');
    }
    else if (action === 'apply-user-template') applyUserTemplate(num(target.dataset.userTemplateIndex, -1));
    else if (action === 'delete-user-template') removeUserTemplate(num(target.dataset.userTemplateIndex, -1));
    else if (action === 'ability-add') {
      pushHistory('ability-add');
      const presetId = document.querySelector('#ability-preset-select')?.value || '';
      addAbilityBlockFromPreset(presetId);
    }
    else if (action === 'ability-duplicate') { pushHistory('ability-duplicate'); duplicateAbility(target.dataset.abilityId); }
    else if (action === 'ability-delete') { pushHistory('ability-delete'); deleteAbility(target.dataset.abilityId); }
    else if (action === 'ability-up') { pushHistory('ability-move'); moveAbility(target.dataset.abilityId, -1); }
    else if (action === 'ability-down') { pushHistory('ability-move'); moveAbility(target.dataset.abilityId, 1); }
    else if (action === 'ability-collapse') toggleAbilityCollapse(target.dataset.abilityId);
    else if (action === 'ability-save-template') {
      const label = `Ability Template ${state.userTemplates.length + 1}`;
      saveUserTemplate(label);
    }
    else if (action === 'save-card') saveCurrentCard();
    else if (action === 'evaluate-card') evaluateCurrentCard();
    else if (action === 'export-card-json') exportCardJson();
    else if (action === 'import-card-json') importCardJson();
    else if (action === 'save-version') saveVersion();
    else if (action === 'restore-version') restoreVersion(num(target.dataset.versionIndex, -1));
    else if (action === 'delete-version') deleteVersion(num(target.dataset.versionIndex, -1));
    else if (action === 'copy-project-json') copyProjectJson();
    else if (action === 'import-project-json') importProjectJson();
    else if (action === 'duplicate-card') duplicateCard();
    else if (action === 'clone-variant') cloneVariant();
    else if (action === 'reset-draft') resetDraft();
    else if (action === 'preview-popout') openPreviewPopout();
    else if (action === 'close-preview-popout') closePreviewPopout();
    else if (action === 'open-art-upload') document.querySelector('#art-file-input')?.click();
    else if (action === 'open-command-palette') { state.ui.commandOpen = true; renderCommandPalette(); }
    else if (action === 'close-command-palette') { state.ui.commandOpen = false; renderCommandPalette(); }
    else if (action === 'run-command') runCommand(target.dataset.commandId);
    else if (action === 'workspace-preset') applyWorkspacePreset(target.dataset.preset);
    else if (action === 'load-card-id') {
      const card = state.cardLibrary[target.dataset.cardId];
      if (card) {
        pushHistory('load-card');
        loadCardToDraft(card);
        renderAll();
        logActivity(`Loaded card ${card.name || card.id}.`);
      }
    }
    else if (action === 'jump-to-path') {
      const moduleGuess = state.validation.errors.find((entry) => entry.path === target.dataset.path)?.module
        || state.validation.warnings.find((entry) => entry.path === target.dataset.path)?.module;
      if (moduleGuess) jumpToModule(moduleGuess);
    }
    else if (action === 'undo') undo();
    else if (action === 'redo') redo();
    else if (action === 'quick-validate') {
      validateDraft();
      renderAll();
      logActivity('Validation refreshed.');
    }
  });

  document.addEventListener('input', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (target.matches('[data-path]')) {
      updateDraftFieldFromInput(target);
      queueAutosave();
      return;
    }
    if (target.matches('[data-ability-field]')) {
      const input = target;
      const abilityId = input.dataset.abilityId;
      const field = input.dataset.abilityField;
      if (abilityId && field) {
        let value;
        if (input.type === 'checkbox') value = input.checked;
        else value = input.value;
        updateAbilityField(abilityId, field, value);
        queueAutosave();
      }
      return;
    }
    if (target.id === 'module-search') {
      state.ui.moduleSearch = target.value;
      renderLeftPane();
      renderCenterPane();
      return;
    }
    if (target.id === 'command-search') {
      state.ui.commandQuery = target.value;
      renderCommandPalette();
      return;
    }
    if (target.id === 'preview-zoom') {
      state.ui.previewZoom = num(target.value, 1);
      renderRightPane();
      return;
    }
  });

  document.addEventListener('change', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (target.id === 'creator-card-mode' || target.id === 'module-mode-select') {
      pushHistory('mode-change');
      applyModeDefaults(target.value);
      validateDraft();
      queueAutosave();
      renderAll();
      return;
    }
    if (target.id === 'creator-experience' || target.id === 'module-experience-select') {
      state.ui.experience = target.value;
      queueAutosave();
      renderAll();
      return;
    }
    if (target.id === 'workspace-preset-select' || target.id === 'module-workspace-select') {
      applyWorkspacePreset(target.value);
      return;
    }
    if (target.id === 'creator-type-quick') {
      pushHistory('type-change');
      state.draft.type = target.value;
      validateDraft();
      queueAutosave();
      renderAll();
      return;
    }
    if (target.id === 'preview-mode-select') {
      state.ui.previewMode = target.value;
      renderRightPane();
      queueAutosave();
      return;
    }
    if (target.id === 'preview-show-tags') {
      state.ui.previewShowTags = target.value === 'yes';
      renderRightPane();
      queueAutosave();
      return;
    }
    if (target.matches('[data-path]')) {
      pushHistory(`edit:${target.dataset.path}`);
    }
  });

  document.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault();
      saveCurrentCard();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      state.ui.commandOpen = true;
      renderCommandPalette();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
      event.preventDefault();
      undo();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') {
      event.preventDefault();
      redo();
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === 's') {
      event.preventDefault();
      saveVersion('Shortcut Snapshot');
      return;
    }
    if (event.key === 'Escape') {
      state.ui.commandOpen = false;
      renderCommandPalette();
      closePreviewPopout();
    }
  });

  const fileInput = document.querySelector('#art-file-input');
  fileInput?.addEventListener('change', () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    pushHistory('art-upload');
    loadArtFile(file);
    fileInput.value = '';
  });
}

async function loadPluginData() {
  const logs = [];
  const errors = await loadPlugins(
    registry,
    [
      { manifest: './plugins/index.json', base: './plugins', type: 'card-pack', kind: 'creatorCardPacks' },
      { manifest: './ability_packs/index.json', base: './ability_packs', type: 'ability-pack', kind: 'abilityPacks' },
      { manifest: '../packs/index.json', base: '../packs', type: 'card-pack', kind: 'sharedCardPacks' },
      { manifest: '../game/ai_packs/index.json', base: '../game/ai_packs', type: 'ai-pack', kind: 'aiPacks' },
    ],
    (line) => logs.push(line),
  );
  state.abilityTemplates = [...FALLBACK_ABILITY_TEMPLATES, ...registry.list('abilityPacks').flatMap((pack) => pack.templates ?? [])];
  state.pluginTemplates = registry.list('creatorCardPacks').flatMap((pack) => (pack.cards ?? []).filter((card) => card.template));
  const externalPackPaths = await discoverExternalPackPaths();
  const externalPacks = [];
  for (const path of externalPackPaths) {
    const raw = await loadRemoteJson(path, null);
    if (!raw || typeof raw !== 'object') continue;
    if (raw.enabled === false || raw.exampleOnly === true) continue;
    const pack = normalizeExternalPack(raw, path);
    if (!pack.cards.length) continue;
    externalPacks.push(pack);
  }
  state.externalUserPacks = externalPacks;
  try { localStorage.setItem(EXTERNAL_USER_PACK_CACHE_KEY, JSON.stringify(externalPacks)); } catch {}
  logs.push(`External user packs detected: ${externalPacks.length}`);
  [...logs, ...errors.map((msg) => `Error: ${msg}`)].forEach((msg) => logActivity(msg));
}

function hydratePersistentState() {
  state.userTemplates = loadJsonStorage(STORAGE.userTemplates, []);
  state.versions = loadJsonStorage(STORAGE.versions, []);
  state.recentCards = loadJsonStorage(STORAGE.recentCards, []);
  state.cardLibrary = loadJsonStorage(STORAGE.customCards, {});
  state.profile = loadJsonStorage(STORAGE.profile, {});
  const uiPrefs = loadJsonStorage(STORAGE.uiPrefs, {});
  state.ui.workspace = uiPrefs.workspace ?? state.ui.workspace;
  state.ui.leftCollapsed = !!uiPrefs.leftCollapsed;
  state.ui.rightCollapsed = !!uiPrefs.rightCollapsed;
  state.ui.bottomCollapsed = !!uiPrefs.bottomCollapsed;
}

function hydrateConquestContext() {
  const params = new URLSearchParams(window.location.search);
  const requestedMode = String(params.get('mode') || '').toLowerCase();
  const payload = loadJsonStorage(STORAGE.conquestContext, null);
  if (requestedMode !== 'conquest') return;
  state.conquestContext = {
    worldId: payload?.worldId ?? null,
    worldName: payload?.worldName ?? '',
    planetId: payload?.planetId ?? null,
    planetName: payload?.planetName ?? '',
    elements: [payload?.primaryElement, payload?.secondaryElement].filter(Boolean),
    species: Array.isArray(payload?.species) ? payload.species.slice(0, 6) : [],
  };
  state.ui.mode = 'conquest';
}

function bootstrapDraft() {
  state.draft = createDefaultDraft(state.ui.mode);
  const restored = loadProjectDraft({
    preserveMode: !!state.conquestContext,
    forcedMode: state.conquestContext ? 'conquest' : '',
  });
  if (!restored) {
    const starter = BUILTIN_TEMPLATES.find((template) => template.id === 'tmpl-basic-minion');
    if (starter) mergeDeep(state.draft, safeClone(starter.patch));
  }
  if (state.conquestContext) {
    state.ui.mode = 'conquest';
    state.draft.mode = 'conquest';
    state.draft.type = CONQUEST_TYPES.includes(state.draft.type) ? state.draft.type : 'unit';
    state.draft.metadata.world = state.conquestContext.worldName || state.draft.metadata.world;
    state.draft.metadata.collection = state.conquestContext.planetName || state.draft.metadata.collection;
    state.draft.metadata.tags = Array.from(new Set([
      ...String(state.draft.metadata.tags || '').split(',').map((entry) => entry.trim()).filter(Boolean),
      'conquest',
      'conquest-attack',
      'generated-conquest-only',
    ])).join(', ');
    state.draft.conquest.side = 'attacker';
    state.draft.conquest.requiredModes = state.draft.conquest.requiredModes || 'conquest-attack';
    state.draft.conquest.battleCompatibility = state.draft.conquest.battleCompatibility || 'conquest_attack';
    state.draft.conquest.generatedConquestOnly = true;
    state.draft.conquest.localMultiplayerExcluded = true;
  }
  state.ui.moduleOrder = moduleRegistry().map((module) => module.id);
  if (state.ui.workspace) applyWorkspacePreset(state.ui.workspace);
}

async function boot() {
  hydratePersistentState();
  hydrateConquestContext();
  bootstrapDraft();
  await loadPluginData();
  validateDraft();
  pushHistory('boot');
  state.ready = true;
  bindGlobalEvents();
  renderAll();
  logActivity('Creator Studio ready.');
}

boot();
