# Gen 4 Ability Runtime Reference

This project supports two ways to author card logic:

1. Structured ability fields (`trigger`, `action`, `amount`, etc.)
2. Rules-text phrase parsing (the same style used by Gen 4 collection cards)

## Creator usage

In the card creator:

- Set `Ability Trigger`
- Set `Ability Action` to `Run Rules Text` (or any other action)
- Fill `Ability Script Text` with one or more rules phrases, separated by `;` for chained actions

Example:

`devour a friendly minion; gain its stats and keywords.`

## Runtime phrases added/confirmed in this pass

The following Gen 4 phrases are now handled in runtime:

- `deal X damage to adjacent enemies.`
- `deal X damage to itself and gain +A/+H.`
- `if it survives, gain stealth.`
- `deal X damage to all enemy Ashlings/tokens.`
- `attack again.`
- `damage all other minions for X.`
- `gain X Armor.`
- `your lowest-Attack Beast eats your highest-Attack damaged Beast and gains its stats.`
- `deal X damage to the enemy hero.`
- `deal X damage to the enemy hero if this was damaged.`
- `pull a 1-Attack enemy minion into combat with this.`
- `deal X damage.`
- `freeze the attacker or a random enemy minion.`
- `if it dies, draw a card.`
- `summon two Skeleton Deckhands.`
- `summon a random Skeleton and a random Beast that costs (N) or less.`
- `deal X damage to a damaged enemy.`
- `give a random friendly 2-Attack-or-less minion Stealth.`
- `give another friendly minion Stealth until your next turn.`
- `devour a friendly minion.`
- `gain its stats and keywords.`
- `reduce its cost by (N).`
- `this gains +A Attack this turn.`
- `summon a random 2-cost follower and give it Divine Shield.`
- `store it here.`

## Notes

- `store it here.` is implemented with tracked stored-healing state and threshold summon behavior for The Seventh Embrace pattern.
- Hero `Armor` is mapped to core defense in duel runtime.
- End-of-turn hand return effects are supported via turn-end resolution status.
