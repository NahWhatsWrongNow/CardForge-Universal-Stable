# Gen 4 Ability Functions (Duel Runtime + Creator)

This file documents the reusable trigger/action ability functions now supported for Gen 4-style cards in duel runtime and exposed in Creator.

## Trigger Keys

- `onPlay`
- `onAttack`
- `onDeath`
- `onDamage` (survived damage)
- `onHeal`
- `onSpell`
- `startTurn`
- `endTurn`
- `onDraw`

## Action Keys

- `dealDamage`
- `draw`
- `heal`
- `buffAttack`
- `buffHealth`
- `grantDefense`
- `summon`
- `timeLock`
- `weakenAllEnemies`

## Creator Wiring

In `/creator/index.html` Card Creator now has:

- `Rules Text`
- `Ability Trigger`
- `Ability Action`
- `Ability Amount`
- `Ability Duration`
- `Ability Def Amount`
- `Ability Condition (optional)`

When trigger/action are set, Creator emits:

- `card.ability` (for all card types)
- `card.effect` (for spell-like cards)

## Runtime Text Ability Support

For text-driven cards (especially Gen 4 booster collections), the duel runtime now parses and executes trigger clauses from `card.text`, including:

- `Battlecry: ...`
- `Death/Deathrattle: ...`
- `End of turn: ...`
- `At the start of your turn: ...`
- `Whenever ...`
- inline `If ... , ...` conditionals

Supported action phrase families include:

- summon token lines (`summon two 1/1 ...`)
- damage lines (`deal X damage ...`)
- healing lines (`restore X health ...`)
- buffs (`give ... +X/+Y`)
- draw
- add-card-to-hand
- destroy/return/freeze/silence
- hand cost reduction lines
- top-deck look/reveal lines (with preview panel)

## Top Deck Preview

Deck-look effects now open an in-battle top deck panel that supports:

- viewing the top card(s)
- closing preview
- optional “put top card on bottom” flow

This is used by effects such as:

- “Look at the top card of your deck. You may leave it or put it on the bottom.”
