from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def log(message: str) -> None:
    print(f"[update_cardex] {message}")


def read_json_file(path: Path, default: Any, *, label: str) -> Any:
    if not path.exists():
        log(f"warning: {label} not found at {path}; using fallback data.")
        return default
    try:
        raw = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        log(f"warning: failed to read {label} ({exc}); using fallback data.")
        return default
    if not raw.strip():
        log(f"warning: {label} is empty; using fallback data.")
        return default
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        log(f"warning: failed to parse {label} ({exc}); using fallback data.")
        return default


def discover_pack_entries(packs_dir: Path) -> list[str]:
    index_path = packs_dir / "index.json"
    index_data = read_json_file(index_path, default={}, label="packs/index.json")

    entries: list[str] = []
    if isinstance(index_data, dict):
        maybe_entries = index_data.get("entries")
        if isinstance(maybe_entries, list):
            for i, entry in enumerate(maybe_entries):
                if isinstance(entry, str) and entry.strip():
                    entries.append(entry.strip())
                else:
                    log(f"warning: ignoring invalid pack index entry at position {i}.")

    if entries:
        return entries

    fallback_entries = sorted(
        path.name for path in packs_dir.glob("*.json") if path.name.lower() != "index.json"
    )
    if fallback_entries:
        log(
            f"warning: using fallback pack discovery ({len(fallback_entries)} files) because pack index was unavailable."
        )
    else:
        log("warning: no packs discovered in fallback scan.")
    return fallback_entries


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def normalize_card(card: dict[str, Any], pack: dict[str, Any], pack_file: str) -> dict[str, Any]:
    ability = card.get("ability")
    if not isinstance(ability, dict):
        ability = card.get("effect")
    if not isinstance(ability, dict):
        ability = {"action": "none", "amount": 0}

    tags = card.get("tags")
    if not isinstance(tags, list):
        tags = []

    cost = safe_int(card.get("cost", card.get("mana", card.get("manaCost", 0))), default=0)

    return {
        "id": str(card.get("id", "")),
        "name": str(card.get("name", "Unnamed Card")),
        "type": card.get("type") or card.get("cardType") or "unknown",
        "rarity": str(card.get("rarity", "common")),
        "cost": cost,
        "attack": safe_int(card.get("attack", 0), default=0),
        "health": safe_int(card.get("health", card.get("hp", 0)), default=0),
        "def": safe_int(card.get("def", card.get("baseDef", 0)), default=0),
        "text": str(card.get("text", "")),
        "ability": ability,
        "tags": tags,
        "bibliography": card.get("bibliography") or card.get("flavorText") or "",
        "collectionName": card.get("collectionName", ""),
        "packSource": card.get("packSource", ""),
        "genVersion": card.get("genVersion", card.get("generationVersion", None)),
        "packId": pack.get("id", ""),
        "packName": pack.get("name", ""),
        "packFile": pack_file,
    }


def build_cardex(root: Path) -> dict[str, Any]:
    packs_dir = root / "packs"
    entries = discover_pack_entries(packs_dir)
    cards: list[dict[str, Any]] = []
    packs_loaded = 0

    for rel_path in entries:
        pack_path = packs_dir / rel_path
        pack_data = read_json_file(pack_path, default={}, label=f"pack '{rel_path}'")
        if not isinstance(pack_data, dict):
            log(f"warning: skipping pack '{rel_path}' because root JSON is not an object.")
            continue

        pack_cards = pack_data.get("cards", [])
        if not isinstance(pack_cards, list):
            log(f"warning: skipping pack '{rel_path}' because 'cards' is not an array.")
            continue

        packs_loaded += 1
        for idx, card in enumerate(pack_cards):
            if not isinstance(card, dict):
                log(f"warning: skipping invalid card in '{rel_path}' at index {idx}.")
                continue
            cards.append(normalize_card(card, pack_data, rel_path))

    payload = {
        "updatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "count": len(cards),
        "packsLoaded": packs_loaded,
        "cards": cards,
    }
    return payload


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    output_path = root / "cardex.json"
    payload = build_cardex(root)
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    log(f"cardex rebuilt: {payload['count']} cards across {payload['packsLoaded']} packs.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
