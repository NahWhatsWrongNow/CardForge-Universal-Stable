$ErrorActionPreference = 'Stop'

function Get-Rarity([int]$i) {
  if ($i -le 40) { return 'common' }
  if ($i -le 70) { return 'rare' }
  if ($i -le 90) { return 'epic' }
  return 'legendary'
}

function Pick-One($rng, $arr) {
  return $arr[$rng.Next(0, $arr.Count)]
}

function Build-CardText($type, $action, $amount, $pack) {
  switch ($type) {
    'minion' { return "On Play: ${action} pattern engages for ${amount}." }
    'spell' {
      switch ($action) {
        'dealDamage' { return "Deal ${amount} damage to an enemy target." }
        'draw' { return "Draw ${amount} card(s)." }
        'heal' { return "Restore ${amount} health to a friendly target." }
        'buffAttack' { return "Give a friendly unit +${amount} ATK this turn." }
        'buffHealth' { return "Give a friendly unit +${amount} Health." }
        'grantArmor' { return "Gain ${amount} Core DEF." }
        'grantDefense' { return "Grant a friendly unit +${amount} DEF and Defense Stance." }
        'weakenAllEnemies' { return "All enemy units get -${amount} ATK this turn." }
        'timeLock' { return "Time-Lock an enemy unit for 1 turn." }
        'summon' { return "Summon ${amount} token unit(s) into open slots." }
        default { return "Resolve ${action} for ${amount}." }
      }
    }
    'instant' { return "Instant: Resolve ${action} for ${amount} at response speed." }
    'sorcery' { return "Sorcery: Resolve ${action} for ${amount}." }
    'field' { return "Field: Persistent zone effect. ${action} +${amount} each turn." }
    'barricade' { return "Barricade: Protect this lane. Break to pass through." }
    'relic' { return "Relic: Ongoing support. ${action} +${amount}." }
    'structure' { return "Structure: Deploy for sustained control and lane pressure." }
    'trap' { return "Trap: Arm a delayed response in this lane." }
    'aura' { return "Aura: Ongoing modifier for your formation." }
    default { return "Operational doctrine from $($pack.Name)." }
  }
}

function New-PackCards($pack) {
  $rng = [System.Random]::new([Math]::Abs($pack.Id.GetHashCode()))
  $cards = New-Object System.Collections.Generic.List[object]
  $usedNames = New-Object 'System.Collections.Generic.HashSet[string]'

  $actions = @('dealDamage','draw','heal','buffAttack','buffHealth','grantArmor','grantDefense','weakenAllEnemies','timeLock','summon')

  for ($i = 1; $i -le 100; $i++) {
    $rarity = Get-Rarity $i
    $rarityBonus = switch ($rarity) {
      'common' { 0 }
      'rare' { 1 }
      'epic' { 2 }
      'legendary' { 3 }
    }

    $typeRoll = $rng.NextDouble()
    if ($typeRoll -lt 0.58) {
      $type = 'minion'
    } elseif ($typeRoll -lt 0.76) {
      $type = 'spell'
    } elseif ($typeRoll -lt 0.84) {
      $type = 'instant'
    } elseif ($typeRoll -lt 0.9) {
      $type = 'sorcery'
    } else {
      $type = Pick-One $rng $pack.SupportTypes
    }

    $costFloor = if ($type -in @('field','relic','structure','barricade')) { 3 } else { 1 }
    $costCeil = if ($rarity -eq 'legendary') { 10 } elseif ($rarity -eq 'epic') { 8 } elseif ($rarity -eq 'rare') { 7 } else { 6 }
    $cost = [Math]::Max($costFloor, [Math]::Min($costCeil, $rng.Next(1, $costCeil + 1) + [Math]::Floor($rarityBonus / 2)))

    $species = Pick-One $rng $pack.Species
    $keyword = Pick-One $rng $pack.Keywords
    $unit = Pick-One $rng $pack.UnitNouns
    $title = Pick-One $rng $pack.Titles
    $name = "$title $unit"
    if (-not $usedNames.Add($name)) { $name = "$name Prime" }
    if (-not $usedNames.Add($name)) { $name = "$name $i" }

    $id = "$($pack.Id)-$($name.ToLower().Replace("'",'').Replace(' ','-').Replace('--','-'))"
    if (($cards | Where-Object { $_.id -eq $id }).Count -gt 0) { $id = "$id-$i" }

    $action = Pick-One $rng $actions
    $scale = if ($action -eq 'draw') { 0.5 } else { 0.8 }
    $amount = [Math]::Max(1, [Math]::Min(8, [Math]::Floor($cost * $scale) + 1))

    $atk = 0
    $hp = 0
    $def = 0
    if ($type -eq 'minion') {
      $atk = [Math]::Max(1, [Math]::Min(12, $cost + $rarityBonus + $rng.Next(-1, 2)))
      $hp = [Math]::Max(1, [Math]::Min(14, $cost + 1 + $rarityBonus + $rng.Next(-1, 3)))
      $def = [Math]::Max(0, [Math]::Min(4, [Math]::Floor(($cost + $rarityBonus)/3) + $rng.Next(0,2)))
    } elseif ($type -eq 'barricade') {
      $atk = 0
      $hp = [Math]::Max(4, [Math]::Min(16, $cost + 4 + $rarityBonus + $rng.Next(0, 3)))
      $def = [Math]::Max(1, [Math]::Min(6, 1 + [Math]::Floor($cost/3) + $rng.Next(0,2)))
      $action = 'grantDefense'
      $amount = [Math]::Max(1, [Math]::Floor($cost/2))
    }

    $battleCompat = if ($type -in @('field','relic','structure','barricade')) { 'defense_only' } else { 'both' }
    $rulesCompat = if ($battleCompat -eq 'defense_only') { 'defense_invasion' } else { 'duel_and_defense' }

    $tags = @(
      $pack.PoolTag,
      'GEN5',
      $pack.Tag,
      "faction:$($pack.Faction)",
      "species:$species",
      (Pick-One $rng $pack.Archetypes)
    )

    $card = [ordered]@{
      id = $id
      name = $name
      type = $type
      cost = $cost
      race = $species
      species = $species
      faction = $pack.Faction
      element = (Pick-One $rng $pack.Elements)
      rarity = $rarity
      tags = $tags
      text = (Build-CardText $type $action $amount $pack)
      bibliography = (Pick-One $rng $pack.FlavorLines)
      universe = $pack.Universe
      dimension = $pack.Dimension
      homeDimension = $pack.Dimension
      genVersion = 5
      generationVersion = 5
      packSource = $pack.Id
      sourcePack = $pack.Id
      sourceType = 'expansion-pack'
      sourceLabel = $pack.Name
      battleCompatibility = $battleCompat
      rulesetCompatibility = $rulesCompat
      effect = [ordered]@{
        action = $action
        amount = $amount
      }
    }

    if ($type -eq 'minion' -or $type -eq 'barricade') {
      $card.attack = $atk
      $card.health = $hp
      $card.def = $def
      if ($keyword -eq 'Guard') { $card.taunt = $true }
      if ($keyword -eq 'Haste') { $card.charge = $true }
      if ($keyword -eq 'Piercing') { $card.pierce = 1 }
      if ($keyword -eq 'Swarm') { $card.swarm = $true }
      if ($keyword -eq 'Large') { $card.large = $true }
      if ($keyword -eq 'Flying') { $card.flying = $true }
      if ($keyword -eq 'Siege') { $card.siege = $true }
      if ($keyword -eq 'Reach') { $card.reach = $true }
      $card.keywords = @($keyword)
    }

    $cards.Add($card)
  }

  return $cards
}

$packs = @(
  [ordered]@{
    File = 'ashen_void_armadas.json'; Id = 'ashen-void-armadas'; Name = 'Ashen Void Armadas';
    Lore = 'War-fleet legions of void marines, breach infantry, and dread fauna pushing siege doctrine through collapsing sectors.';
    Theme = 'grimdark void war and armored attrition'; Universe = 'Ashen Expanse'; Dimension = 'Dreadline Crucible';
    Faction = 'ashen_void_armadas'; PoolTag = 'ASHEN_ARMADAS'; Tag = 'ashen_void_armadas';
    SupportTypes = @('barricade','structure','field','relic');
    Species = @('void_marines','armor_cult','dread_beast','war_servitor','breach_infantry');
    Elements = @('fire','steel','shadow','arcane','earth');
    Keywords = @('Guard','Siege','Piercing','Haste','Large','Reach');
    UnitNouns = @('Legionnaire','Breachgunner','Hullwarden','Siege Hound','Dread Pike','Armor Scribe','Ruin Charger','Bastion Operative');
    Titles = @('Ashen','Voidforged','Ironwake','Fleetline','Breachborn','Cinderplate','Gravehull','Warcrest');
    Archetypes = @('aggro','midrange','control','fortification','attrition','siege');
    FlavorLines = @('Every bulkhead remembers the first breach.','They march by reactor light and funerary hymns.','Armor doctrine is prayer translated into steel.','The fleet survives by refusing to retreat.')
  },
  [ordered]@{
    File = 'cathedral_of_broken_stars.json'; Id = 'cathedral-of-broken-stars'; Name = 'Cathedral of Broken Stars';
    Lore = 'Fallen choirs, radiant ruins, and sanctified monsters wield healing, suppression, and doctrine-bound judgment.';
    Theme = 'sacred tragedy with radiant control'; Universe = 'Luminant Reliquary'; Dimension = 'Cathedral Meridian';
    Faction = 'cathedral_broken_stars'; PoolTag = 'BROKEN_STARS'; Tag = 'cathedral_broken_stars';
    SupportTypes = @('field','relic','structure','aura');
    Species = @('star_clergy','halo_entity','relic_guardian','shrineborn','fallen_saint');
    Elements = @('holy','light','shadow','arcane','water');
    Keywords = @('Guard','Flying','Reach','Piercing','Large');
    UnitNouns = @('Cantor','Reliquary Guard','Halo Seraph','Shrine Beast','Doctrine Keeper','Choir Warden','Lumen Knight','Star Penitent');
    Titles = @('Radiant','Broken','Sanctified','Votive','Astral','Choirbound','Edict','Halo');
    Archetypes = @('heal','support','control','silence','value','midrange');
    FlavorLines = @('Their mercy arrives with a sentence attached.','Choirs still sing where suns have already died.','Every prayer is cataloged as tactical supply.','In the broken nave, discipline becomes law.')
  },
  [ordered]@{
    File = 'feral_shard_wilds.json'; Id = 'feral-shard-wilds'; Name = 'Feral Shard Wilds';
    Lore = 'Crystal predators and rift-mutated packs hunt in mirrored jungles where violence evolves by the minute.';
    Theme = 'primal shard aggression and hunt chains'; Universe = 'Shardwild Verge'; Dimension = 'Feral Prism Belt';
    Faction = 'feral_shard_wilds'; PoolTag = 'FERAL_SHARD'; Tag = 'feral_shard_wilds';
    SupportTypes = @('field','trap','structure','barricade');
    Species = @('crystal_predator','shard_pack','rift_beast','hunting_colony','mirror_fauna');
    Elements = @('nature','arcane','earth','air','poison');
    Keywords = @('Haste','Swarm','Piercing','Large','Reach','Flying');
    UnitNouns = @('Prowler','Razorcat','Shardrunner','Pack Alpha','Echo Stalker','Glassfang','Rift Lynx','Mirror Drake');
    Titles = @('Feral','Shardbound','Howling','Riftborn','Mirrorclaw','Prismhide','Wildline','Gnarl');
    Archetypes = @('aggro','swarm','adjacency','tempo','value','combo');
    FlavorLines = @('Predators learn your deck by tasting blood once.','The jungle mirrors every fear you fail to kill.','Hunts begin before footprints appear.','Shardlight flashes just before the strike.')
  },
  [ordered]@{
    File = 'throne_of_black_signals.json'; Id = 'throne-of-black-signals'; Name = 'Throne of Black Signals';
    Lore = 'Signal lords and parasite courts enforce distant control through taxation, denial, and precision manipulation.';
    Theme = 'cold disruption and command intelligence'; Universe = 'Noctilith Broadcast'; Dimension = 'Obsidian Relay Throne';
    Faction = 'black_signal_throne'; PoolTag = 'BLACK_SIGNALS'; Tag = 'throne_black_signals';
    SupportTypes = @('relic','field','structure','trap');
    Species = @('signal_lord','parasite_court','control_intelligence','black_choir_operator','nerve_web_overseer');
    Elements = @('shadow','arcane','void','steel','holy');
    Keywords = @('Guard','Piercing','Reach','Large','Flying');
    UnitNouns = @('Overseer','Protocol Warden','Signal Baron','Choir Operator','Web Marshal','Censor Engine','Relay Knight','Cipher Regent');
    Titles = @('Black','Signalbound','Nerveweb','Obsidian','Cipher','Throned','Directive','Noctilith');
    Archetypes = @('control','tax','draw','disruption','steal','value');
    FlavorLines = @('They conquer by editing what your deck is allowed to do.','Every command is signed in static and blood.','Signals arrive clean; mercy never does.','The throne speaks once, and systems comply.')
  }
)

$packDir = Join-Path (Get-Location) 'packs'
foreach ($pack in $packs) {
  $cards = New-PackCards $pack
  $payload = [ordered]@{ type = 'card-pack'; id = $pack.Id; name = $pack.Name; lore = $pack.Lore; theme = $pack.Theme; cards = $cards }
  $json = $payload | ConvertTo-Json -Depth 16
  Set-Content -Path (Join-Path $packDir $pack.File) -Value $json -Encoding UTF8
}

$indexPath = Join-Path $packDir 'index.json'
$index = Get-Content $indexPath -Raw | ConvertFrom-Json
$entries = New-Object System.Collections.Generic.List[string]
foreach ($e in $index.entries) { [void]$entries.Add([string]$e) }
foreach ($pack in $packs) { if (-not $entries.Contains($pack.File)) { [void]$entries.Add($pack.File) } }
$indexOut = [ordered]@{ entries = $entries }
Set-Content -Path $indexPath -Value ($indexOut | ConvertTo-Json -Depth 6) -Encoding UTF8

Write-Output 'Generated 4 booster packs with 100 cards each and updated packs/index.json.'
