const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const PACKS_DIR = path.join(ROOT, 'packs');
const CARDEX_PATH = path.join(ROOT, 'cardex.json');
const ALIEN_FACTIONS_PATH = path.join(ROOT, 'game', 'alien_packs', 'alien_factions_v1.json');
const PACK_INDEX_PATH = path.join(ROOT, 'packs', 'index.json');

const STRUCTURE_BUILDINGS = ['fortress', 'turret_grid', 'factory'];
const FIELD_BUILDINGS = ['mana_reactor', 'card_factory'];
const CREATURE_BUILDINGS = ['training_center', 'factory', 'card_factory'];

const FACTIONS = [
  {
    id: 'chitin-ascendancy',
    name: 'The Chitin Ascendancy',
    species: 'chitin_hive',
    worldOrigin: 'chitin-ascendancy',
    factionColor: '#74f08f',
    icon: '△',
    techProfile: 'void-insect hive adaptation',
    deckTags: ['swarm', 'brood', 'token', 'pressure', 'adaptation'],
    behaviorNotes: 'Floods the board with brood bodies, then amplifies with synapse engines.',
    reinforcementStyle: 'brood-wave',
    regionPreference: ['riftstorm', 'astral-cartographer'],
    aiSkillRange: [1, 4],
    techLevelRange: [2, 8],
    deckSizePreference: [20, 70],
    specialTraits: ['synapse-web', 'hatch-burst', 'death-spawn'],
    minionPrefixes: ['Brood', 'Mandible', 'Synapse', 'Scuttle', 'Maw', 'Skitter', 'Burrow', 'Larval', 'Chitin', 'Apex'],
    minionBases: ['Raker', 'Spitter', 'Hunter', 'Tender', 'Howler', 'Reaper', 'Drone', 'Ripper', 'Seeder', 'Tyrant'],
    spellNames: [
      'Hive Hatch Protocol',
      'Acid Brood Surge',
      'Synapse Overrun',
      'Larval Ambush',
      'Predator Instinct Pulse',
      'Void Molt Directive',
      'Chitin Rainfall',
      'Devour the Fallen',
      'Nesting Frenzy',
      'Venom Tunnel Burst',
      'Broodline Reconstitution',
      'Queen\'s Imperative',
      'Apex Molting Storm',
      'Infinite Brood Mandate'
    ],
    permanentNames: [
      'Nestspire Bulwark',
      'Spine Hatchery Gate',
      'Apex Resin Barricade',
      'Synapse Overgrowth Field',
      'Brood Pressure Lattice',
      'Queen\'s War-Nest'
    ],
    flavorBits: [
      'The brood-mind records every wound and hatches an answer by dusk.',
      'No corridor remains empty after the first chitin signal.',
      'The Ascendancy calls this hunger, but it functions like strategy.',
      'When one form dies, three smaller forms inherit the objective.',
      'Their queens write doctrine directly into nerve clusters.',
      'The hive does not retreat; it redistributes mass.'
    ],
    traitProfile: 'swarm',
    spellProfile: 'brood',
  },
  {
    id: 'glass-null-collective',
    name: 'The Glass Null Collective',
    species: 'glass_null',
    worldOrigin: 'glass-null-collective',
    factionColor: '#71f5ee',
    icon: '△',
    techProfile: 'crystalline machine geometry',
    deckTags: ['precision', 'copy', 'split', 'control', 'barrier'],
    behaviorNotes: 'Uses fractal precision, reflective barriers, and copy pressure to force efficient trades.',
    reinforcementStyle: 'prism-relay',
    regionPreference: ['voidglass', 'memory-fracture'],
    aiSkillRange: [2, 5],
    techLevelRange: [3, 9],
    deckSizePreference: [20, 70],
    specialTraits: ['mirror-fracture', 'null-prism', 'facet-replication'],
    minionPrefixes: ['Prism', 'Null', 'Facet', 'Mirror', 'Fractal', 'Lattice', 'Shard', 'Refraction', 'Axiom', 'Crystal'],
    minionBases: ['Sentinel', 'Sniper', 'Warden', 'Duplicant', 'Caster', 'Cutlass', 'Array', 'Oracle', 'Anchor', 'Overmind'],
    spellNames: [
      'Prismline Sever',
      'Facet Echo',
      'Mirror-Split Directive',
      'Nullglass Refit',
      'Refraction Lock',
      'Shardstorm Vector',
      'Axiomatic Realignment',
      'Cold Geometry Verdict',
      'Fractal Countershape',
      'Crystal Lance Equation',
      'Lattice Reframing',
      'Prismatic Overwrite',
      'Mirror Collapse Canon',
      'Null Cathedral Algorithm'
    ],
    permanentNames: [
      'Nullglass Barrier Array',
      'Facet-Screen Bulwark',
      'Refraction Bastion',
      'Prism Equation Field',
      'Mirrorline Calibration Field',
      'Fractal Judicator Engine'
    ],
    flavorBits: [
      'Their tactical language is geometry rendered as force.',
      'A broken shard still contains a complete command chain.',
      'The Collective calls mercy an inefficient branching state.',
      'Precision becomes cruelty when every error is permanent.',
      'Mirror warriors split by design, not by damage.',
      'Cold light can still be predatory.'
    ],
    traitProfile: 'precision',
    spellProfile: 'control',
  },
  {
    id: 'verdant-consumers',
    name: 'The Verdant Consumers',
    species: 'verdant_parasite',
    worldOrigin: 'verdant-consumers',
    factionColor: '#85ef6a',
    icon: '△',
    techProfile: 'parasitic bioflora expansion',
    deckTags: ['growth', 'heal', 'spore', 'infestation', 'attrition'],
    behaviorNotes: 'Spreads root zones, heals through attrition, and turns board space into hostile terrain.',
    reinforcementStyle: 'spore-front',
    regionPreference: ['verdant-expanse', 'riftstorm'],
    aiSkillRange: [1, 4],
    techLevelRange: [2, 8],
    deckSizePreference: [20, 70],
    specialTraits: ['sporefield', 'rootlock', 'bloom-wave'],
    minionPrefixes: ['Spore', 'Root', 'Bloom', 'Vine', 'Thorn', 'Husk', 'Grove', 'Mold', 'Seed', 'Canopy'],
    minionBases: ['Crawler', 'Warden', 'Stalker', 'Tender', 'Maw', 'Shepherd', 'Harvester', 'Bearer', 'Titan', 'Oracle'],
    spellNames: [
      'Sporeburst Bloom',
      'Rootweb Grasp',
      'Parasitic Germination',
      'Canopy Regrowth',
      'Pollen Choke',
      'Thornline Entrapment',
      'Verdant Consumption',
      'Infestation Cycle',
      'Suffocating Overgrowth',
      'Seedbank Recall',
      'Husk Renewal',
      'Bloomchain Cataclysm',
      'Ancient Grove Verdict',
      'Worldroot Assimilation'
    ],
    permanentNames: [
      'Rootwall Barricade',
      'Thorn-Ring Palisade',
      'Spore Bastion Lattice',
      'Overgrowth Canopy Field',
      'Living Reactor Grove',
      'Everdawn Bloomheart'
    ],
    flavorBits: [
      'Every wound fertilizes another ring of conquest.',
      'The forest does not march; it appears where breath should be.',
      'Their vines learn your routes before your scouts do.',
      'Patience is their sharpest weapon.',
      'Spores turn steel corridors into gardens of teeth.',
      'Growth can be a siege doctrine.'
    ],
    traitProfile: 'growth',
    spellProfile: 'heal',
  },
  {
    id: 'halo-censors',
    name: 'The Halo Censors',
    species: 'radiant_censor',
    worldOrigin: 'halo-censors',
    factionColor: '#f2dc86',
    icon: '△',
    techProfile: 'radiant doctrinal enforcement',
    deckTags: ['formation', 'shield', 'suppression', 'silence', 'elite'],
    behaviorNotes: 'Fields elite disciplined units backed by suppression beams and sanction structures.',
    reinforcementStyle: 'choir-phalanx',
    regionPreference: ['luminous-tribunal', 'solar-dominion'],
    aiSkillRange: [2, 5],
    techLevelRange: [4, 10],
    deckSizePreference: [20, 70],
    specialTraits: ['doctrine-aura', 'radiant-cage', 'judgment-beam'],
    minionPrefixes: ['Halo', 'Radiant', 'Choir', 'Doctrine', 'Sanctum', 'Vow', 'Edict', 'Censor', 'Seraph', 'Lumen'],
    minionBases: ['Enforcer', 'Warden', 'Marshal', 'Lancer', 'Arbiter', 'Custodian', 'Spear', 'Paragon', 'Justicar', 'Executor'],
    spellNames: [
      'Radiant Purge Beam',
      'Doctrine Alignment',
      'Sanctioned Silence',
      'Halo Ward Pulse',
      'Edict of Closed Wings',
      'Choirline Interdiction',
      'Luminous Reprimand',
      'Vowbound Retaliation',
      'Judgment Prism',
      'Canon of Discipline',
      'Sanctified Counterline',
      'Merciless Benediction',
      'Celestial Suppression Wave',
      'Final Halo Decree'
    ],
    permanentNames: [
      'Sanctum Bastion Screen',
      'Doctrine Shieldwall',
      'Halo Bastion Prism',
      'Luminous Doctrine Field',
      'Choir Discipline Field',
      'Cathedral of Censored Suns'
    ],
    flavorBits: [
      'They call conquest a correction of unauthorized futures.',
      'Mercy exists only where doctrine remains intact.',
      'Their choirs sing in frequencies that erase dissent.',
      'Every halo is also a targeting reticle.',
      'Suppression is framed as compassion in their sermons.',
      'Order can be beautiful and still be monstrous.'
    ],
    traitProfile: 'elite',
    spellProfile: 'suppression',
  },
  {
    id: 'iron-carrion-mandate',
    name: 'The Iron Carrion Mandate',
    species: 'iron_carrion',
    worldOrigin: 'iron-carrion-mandate',
    factionColor: '#9fb3bb',
    icon: '△',
    techProfile: 'necro-industrial siege recursion',
    deckTags: ['siege', 'salvage', 'structure', 'attrition', 'recycle'],
    behaviorNotes: 'Builds artillery shells, recycles losses, and crushes lanes with heavy engines.',
    reinforcementStyle: 'forge-column',
    regionPreference: ['iron-orchard', 'drowned-ledger'],
    aiSkillRange: [2, 5],
    techLevelRange: [4, 10],
    deckSizePreference: [20, 70],
    specialTraits: ['scrap-cycle', 'siege-column', 'corpse-furnace'],
    minionPrefixes: ['Iron', 'Carrion', 'Forge', 'Scrap', 'Rust', 'Mandate', 'Furnace', 'Harvest', 'Mortar', 'Grinder'],
    minionBases: ['Walker', 'Reaver', 'Artillery', 'Trawler', 'Bastion', 'Exactor', 'Ravager', 'Operator', 'Engine', 'Titan'],
    spellNames: [
      'Scrapline Detonation',
      'Carrion Recovery Order',
      'Furnace Fuel Injection',
      'Ruststorm Barrage',
      'Industrial Requisition',
      'Mandate Siege Protocol',
      'Corpseforge Conversion',
      'Mortarline Saturation',
      'Heavy Breach Charge',
      'Salvage Dividend',
      'Iron Debt Collection',
      'Breaker Cannon Salvo',
      'Catastrophic Refinery Vent',
      'Mandate of Endless Harvest'
    ],
    permanentNames: [
      'Rustplate Barricade Grid',
      'Carrion Foundry Wall',
      'Siege Platform Bulwark',
      'Refinery Pressure Field',
      'Corpse-Furnace Reactor',
      'Mandate Dread-Factory'
    ],
    flavorBits: [
      'They recycle losses faster than enemies can celebrate them.',
      'Every ruin is treated as ore waiting for instruction.',
      'The Mandate calls this efficiency; survivors call it carrion law.',
      'Siege crews sleep beside smelters and wake to artillery prayers.',
      'A shattered wall is merely component stock for a larger wall.',
      'Their peace terms are delivered as invoices for ammunition.'
    ],
    traitProfile: 'siege',
    spellProfile: 'salvage',
  }
];

const SPELL_ACTION_SETS = {
  brood: ['summon', 'dealDamage', 'poisonHero', 'weakenAllEnemies', 'buffAttack', 'summon', 'timeLock', 'dealDamage', 'summon', 'sentence', 'buffHealth', 'grantDefense', 'dealDamage', 'summon'],
  control: ['dealDamage', 'draw', 'timeLock', 'grantDefense', 'shatterFront', 'weakenAllEnemies', 'draw', 'tax', 'sentence', 'dealDamage', 'timeLock', 'draw', 'shatterFront', 'dealDamage'],
  heal: ['summon', 'heal', 'buffHealth', 'grantDefense', 'poisonHero', 'timeLock', 'heal', 'summon', 'weakenAllEnemies', 'draw', 'heal', 'buffAttack', 'dealDamage', 'summon'],
  suppression: ['dealDamage', 'buffAttack', 'timeLock', 'grantDefense', 'shatterFront', 'weakenAllEnemies', 'dealDamage', 'tax', 'sentence', 'grantArmor', 'timeLock', 'grantDefense', 'dealDamage', 'shatterFront'],
  salvage: ['dealDamage', 'draw', 'grantArmor', 'dealDamage', 'tax', 'buffAttack', 'summon', 'dealDamage', 'shatterFront', 'draw', 'sentence', 'dealDamage', 'buffHealth', 'summon']
};

function rarityForUnit(i) {
  if (i < 14) return 'common';
  if (i < 24) return 'rare';
  if (i < 28) return 'epic';
  return 'legendary';
}

function rarityForSpell(i) {
  if (i < 6) return 'common';
  if (i < 10) return 'rare';
  if (i < 13) return 'epic';
  return 'legendary';
}

function rarityForPermanent(i) {
  if (i < 2) return 'rare';
  if (i < 4) return 'epic';
  return 'legendary';
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function effectText(effect) {
  const action = String(effect.action || 'dealDamage');
  const amount = Number(effect.amount || 0);
  const duration = Number(effect.duration || 1);
  if (action === 'dealDamage') return `Cast: Deal ${amount} damage to an enemy unit (or enemy hero if no unit remains).`;
  if (action === 'summon') return `Cast: Summon ${Math.max(1, Number(effect.summonCount || amount || 1))} 1/1 token units into open slots.`;
  if (action === 'poisonHero') return `Cast: Apply Poison ${amount} to the enemy hero.`;
  if (action === 'weakenAllEnemies') return `Cast: Weaken all enemy units for ${duration} turn(s).`;
  if (action === 'buffAttack') return `Cast: Give a priority allied unit +${amount} ATK this turn.`;
  if (action === 'buffHealth') return `Cast: Give a priority allied unit +${amount} max HP and heal ${amount}.`;
  if (action === 'grantDefense') return `Cast: Give a priority allied unit +${effect.defAmount || amount} DEF and Guard.`;
  if (action === 'grantArmor') return `Cast: Gain +${amount} Core DEF.`;
  if (action === 'draw') return `Cast: Draw ${amount} card(s).`;
  if (action === 'timeLock') return `Cast: Time-Lock a priority enemy unit for ${duration} turn(s).`;
  if (action === 'shatterFront') return `Cast: Shatter a priority enemy defender for ${duration} turn(s).`;
  if (action === 'tax') return `Cast: Tax opponent by ${amount} mana on their next turn.`;
  if (action === 'sentence') return `Cast: Sentence a priority enemy unit for ${duration} turn(s).`;
  return `Cast: Resolve ${action}.`;
}

function baseMeta(faction, card, cardType, rarity, cost, index) {
  const techBase = rarity === 'legendary' ? 4 : rarity === 'epic' ? 3 : rarity === 'rare' ? 2 : 1;
  const favorBase = rarity === 'legendary' ? 24 : rarity === 'epic' ? 16 : rarity === 'rare' ? 10 : 0;
  const reinforcementTier = rarity === 'legendary' ? 4 : rarity === 'epic' ? 3 : rarity === 'rare' ? 2 : 1;
  const buildingType = cardType === 'spell' || cardType === 'instant' || cardType === 'sorcery'
    ? 'card_factory'
    : (cardType === 'field' || cardType === 'relic'
      ? FIELD_BUILDINGS[index % FIELD_BUILDINGS.length]
      : ((cardType === 'structure' || cardType === 'barricade')
        ? STRUCTURE_BUILDINGS[index % STRUCTURE_BUILDINGS.length]
        : CREATURE_BUILDINGS[index % CREATURE_BUILDINGS.length]));

  const campaignMeta = {
    battleCompatibility: 'defense_only',
    producible: true,
    productionBuildingType: buildingType,
    speciesOrigin: faction.species,
    worldOrigin: faction.worldOrigin,
    unlockByWorld: faction.worldOrigin,
    loseWithWorld: true,
    techRequirement: techBase,
    favorRequirement: favorBase,
    productionCostGold: Math.max(20, cost * 24 + (reinforcementTier * 12)),
    productionCostLifeforce: reinforcementTier * 3,
    reinforcementTier,
    requiredModes: 'defense_conquest,invasion_massive',
  };

  card.battleCompatibility = 'defense_only';
  card.rulesetCompatibility = 'defense_invasion';
  card.factionId = faction.id;
  card.invasionFaction = faction.id;
  card.packSource = faction.id;
  card.sourceType = 'invasion-pack';
  card.sourceLabel = faction.name;
  card.genVersion = 4;
  card.generationVersion = 4;
  card.homeDimension = faction.worldOrigin;
  card.campaignMeta = campaignMeta;
  card.mtgMeta = { ...campaignMeta };
  card.production = {
    producible: campaignMeta.producible,
    buildingType: campaignMeta.productionBuildingType,
    speciesOrigin: campaignMeta.speciesOrigin,
    worldOrigin: campaignMeta.worldOrigin,
    unlockByWorld: campaignMeta.unlockByWorld,
    loseWithWorld: campaignMeta.loseWithWorld,
    techRequirement: campaignMeta.techRequirement,
    favorRequirement: campaignMeta.favorRequirement,
    productionCostGold: campaignMeta.productionCostGold,
    productionCostLifeforce: campaignMeta.productionCostLifeforce,
    reinforcementTier: campaignMeta.reinforcementTier,
    requiredModes: campaignMeta.requiredModes,
  };
}

function unitStats(cost, traitProfile, i) {
  let atk = Math.max(1, Math.floor((cost * 0.75) + (i % 3) - (cost >= 7 ? 1 : 0)));
  let hp = Math.max(1, Math.ceil((cost * 1.15) + ((i % 4) - 1)));
  let def = 0;
  if (traitProfile === 'swarm') {
    hp = Math.max(1, hp - 1);
    atk = Math.max(1, atk + (i % 2));
    def = i % 7 === 0 ? 1 : 0;
  } else if (traitProfile === 'precision') {
    atk = Math.max(1, atk + 1);
    hp = Math.max(1, hp - 1);
    def = i % 5 === 0 ? 1 : 0;
  } else if (traitProfile === 'growth') {
    hp = Math.max(1, hp + 1);
    def = i % 4 === 0 ? 1 : 0;
  } else if (traitProfile === 'elite') {
    atk = Math.max(1, atk + 1);
    hp = Math.max(1, hp + 1);
    def = i % 3 === 0 ? 1 : 0;
  } else if (traitProfile === 'siege') {
    atk = Math.max(1, atk + (cost >= 4 ? 1 : 0));
    hp = Math.max(1, hp + 1);
    def = i % 2 === 0 ? 1 : 2;
  }
  return { atk, hp, def };
}

function uniqueUnitNames(prefixes, bases, count) {
  const combos = [];
  prefixes.forEach((prefix) => {
    bases.forEach((base) => {
      combos.push(`${prefix} ${base}`);
    });
  });
  combos.sort((a, b) => a.localeCompare(b));
  if (combos.length >= count) return combos.slice(0, count);
  const out = [...combos];
  let idx = 0;
  while (out.length < count) {
    out.push(`${combos[idx % combos.length]} ${Math.floor(idx / combos.length) + 2}`);
    idx += 1;
  }
  return out;
}

function spellEffect(action, cost, i) {
  const amountBase = Math.max(1, Math.ceil(cost / 2));
  if (action === 'dealDamage') return { action, amount: Math.max(2, amountBase + 1) };
  if (action === 'summon') return { action, amount: Math.max(1, Math.min(3, Math.ceil(cost / 3))), summonCount: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  if (action === 'poisonHero') return { action, amount: Math.max(1, Math.min(4, Math.ceil(cost / 2))) };
  if (action === 'weakenAllEnemies') return { action, amount: 1, duration: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  if (action === 'buffAttack') return { action, amount: Math.max(1, Math.min(4, Math.ceil(cost / 2))) };
  if (action === 'buffHealth') return { action, amount: Math.max(1, Math.min(4, Math.ceil(cost / 2))) };
  if (action === 'grantDefense') return { action, amount: Math.max(1, Math.min(4, Math.ceil(cost / 2))), defAmount: Math.max(1, Math.min(4, Math.ceil(cost / 2))) };
  if (action === 'grantArmor') return { action, amount: Math.max(1, Math.min(5, Math.ceil(cost / 2))) };
  if (action === 'draw') return { action, amount: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  if (action === 'timeLock') return { action: 'timeLock', amount: 1, duration: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  if (action === 'shatterFront') return { action, amount: 1, duration: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  if (action === 'tax') return { action, amount: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  if (action === 'sentence') return { action, amount: 1, duration: Math.max(1, Math.min(3, Math.ceil(cost / 3))) };
  return { action: 'dealDamage', amount: Math.max(2, amountBase + 1) };
}

function minionKeywordProfile(faction, i, cost) {
  const tags = [
    'invasion',
    faction.id,
    `faction:${faction.id}`,
    `species:${faction.species}`,
    'defense-mode',
    'GEN4'
  ];
  const keywords = [];
  const flags = {
    taunt: false,
    charge: false,
    flying: false,
    reach: false,
    siege: false,
    swarm: false,
    large: false,
    pierce: 0,
  };

  if (faction.traitProfile === 'swarm') {
    if (i % 2 === 0) { flags.swarm = true; keywords.push('Swarm'); tags.push('swarm'); }
    if (i % 7 === 0) { flags.pierce = 1; keywords.push('Piercing'); tags.push('pierce'); }
    if (cost >= 7 && i % 3 === 0) { flags.large = true; keywords.push('Large'); tags.push('large'); }
    if (i % 11 === 0) { flags.charge = true; keywords.push('Haste'); tags.push('haste'); }
  }

  if (faction.traitProfile === 'precision') {
    if (i % 3 === 0) { flags.pierce = 1; keywords.push('Piercing'); tags.push('pierce'); }
    if (i % 5 === 0) { flags.reach = true; keywords.push('Reach'); tags.push('reach'); }
    if (cost >= 7 && i % 4 === 0) { flags.large = true; keywords.push('Large'); tags.push('large'); }
  }

  if (faction.traitProfile === 'growth') {
    if (i % 3 === 0) { flags.swarm = true; keywords.push('Swarm'); tags.push('swarm'); }
    if (i % 4 === 0) { flags.taunt = true; keywords.push('Guard'); tags.push('guard'); }
    if (cost >= 8 && i % 2 === 0) { flags.large = true; keywords.push('Large'); tags.push('large'); }
  }

  if (faction.traitProfile === 'elite') {
    if (i % 2 === 0) { flags.taunt = true; keywords.push('Guard'); tags.push('guard'); }
    if (i % 5 === 0) { flags.flying = true; keywords.push('Flying'); tags.push('flying'); }
    if (i % 7 === 0) { flags.pierce = 1; keywords.push('Piercing'); tags.push('pierce'); }
    if (cost >= 8 && i % 3 === 0) { flags.large = true; keywords.push('Large'); tags.push('large'); }
  }

  if (faction.traitProfile === 'siege') {
    if (i % 2 === 0) { flags.siege = true; keywords.push('Siege'); tags.push('siege'); }
    if (i % 3 === 0) { flags.taunt = true; keywords.push('Guard'); tags.push('guard'); }
    if (i % 5 === 0) { flags.pierce = 1; keywords.push('Piercing'); tags.push('pierce'); }
    if (cost >= 7) { flags.large = true; keywords.push('Large'); tags.push('large'); }
  }

  return { tags: [...new Set(tags)], keywords: [...new Set(keywords)], flags };
}

function generateFactionCards(faction) {
  const cards = [];
  const minionNames = uniqueUnitNames(faction.minionPrefixes, faction.minionBases, 30);
  const minionCosts = [1,1,1,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,5,5,5,5,6,6,6,7,7,8,8,9];

  minionNames.forEach((name, i) => {
    const cost = minionCosts[i];
    const rarity = rarityForUnit(i);
    const stats = unitStats(cost, faction.traitProfile, i);
    const keywordPack = minionKeywordProfile(faction, i, cost);
    const id = `${faction.id}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
    const textBits = [];
    if (keywordPack.flags.swarm) textBits.push('Swarm: On death, spawn a 1/1 Fragment if a slot is open.');
    if (keywordPack.flags.large) textBits.push('Large: Occupies two adjacent slots in the same row.');
    if (keywordPack.flags.taunt) textBits.push('Guard: Enemy attacks must target this unit while it holds the lane.');
    if (keywordPack.flags.siege) textBits.push('Siege: Excels at pressuring barricades and fortified lanes.');
    if (keywordPack.flags.flying) textBits.push('Flying: Can pressure protected back-row targets.');
    if (keywordPack.flags.reach) textBits.push('Reach: Can contest flying targets.');
    if (keywordPack.flags.charge) textBits.push('Haste: Can attack the turn it is summoned.');
    if (keywordPack.flags.pierce) textBits.push(`Piercing: Ignores ${keywordPack.flags.pierce} DEF on hit.`);
    if (!textBits.length) textBits.push('Frontline invader tuned for defense/conquest operations.');

    const card = {
      id,
      name,
      type: 'minion',
      cost,
      attack: stats.atk,
      health: stats.hp,
      def: stats.def,
      race: faction.species,
      element: faction.traitProfile === 'precision' ? 'arcane' : (faction.traitProfile === 'growth' ? 'nature' : (faction.traitProfile === 'elite' ? 'light' : (faction.traitProfile === 'siege' ? 'metal' : 'poison'))),
      rarity,
      taunt: keywordPack.flags.taunt,
      charge: keywordPack.flags.charge,
      flying: keywordPack.flags.flying,
      reach: keywordPack.flags.reach,
      siege: keywordPack.flags.siege,
      swarm: keywordPack.flags.swarm,
      large: keywordPack.flags.large,
      pierce: keywordPack.flags.pierce,
      keywords: keywordPack.keywords,
      tags: keywordPack.tags,
      text: textBits.join(' '),
      bibliography: faction.flavorBits[i % faction.flavorBits.length],
    };
    baseMeta(faction, card, card.type, rarity, cost, i);
    cards.push(card);
  });

  faction.spellNames.forEach((name, i) => {
    const cost = clamp(1 + Math.floor(i / 2), 1, 9);
    const rarity = rarityForSpell(i);
    const action = SPELL_ACTION_SETS[faction.spellProfile][i % SPELL_ACTION_SETS[faction.spellProfile].length];
    const effect = spellEffect(action, cost, i);
    const type = i % 5 === 0 ? 'instant' : (i % 4 === 0 ? 'sorcery' : 'spell');
    const id = `${faction.id}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
    const tags = [
      'invasion',
      faction.id,
      `faction:${faction.id}`,
      `species:${faction.species}`,
      `ability:${String(effect.action).toLowerCase()}`,
      'defense-mode',
      'GEN4'
    ];
    const card = {
      id,
      name,
      type,
      cost,
      damage: effect.action === 'dealDamage' ? effect.amount : 0,
      effect,
      ability: { ...effect },
      race: faction.species,
      element: faction.traitProfile === 'elite' ? 'light' : (faction.traitProfile === 'growth' ? 'nature' : 'arcane'),
      rarity,
      tags,
      text: effectText(effect),
      bibliography: faction.flavorBits[(i + 1) % faction.flavorBits.length],
    };
    baseMeta(faction, card, card.type, rarity, cost, 40 + i);
    cards.push(card);
  });

  faction.permanentNames.forEach((name, i) => {
    const rarity = rarityForPermanent(i);
    const cost = clamp(3 + i, 3, 9);
    const id = `${faction.id}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
    const baseTags = [
      'invasion',
      faction.id,
      `faction:${faction.id}`,
      `species:${faction.species}`,
      'defense-mode',
      'GEN4'
    ];

    let card;
    if (i <= 2) {
      const structureEffects = [
        { action: 'grantArmor', amount: 1 },
        { action: 'grantDefense', amount: 2, defAmount: 2 },
        { action: 'timeLock', amount: 1, duration: 1 }
      ];
      card = {
        id,
        name,
        type: i === 0 ? 'barricade' : 'structure',
        cost,
        health: 6 + i,
        def: 1 + (i % 2),
        effect: structureEffects[i],
        ability: { ...structureEffects[i] },
        race: faction.species,
        element: faction.traitProfile === 'siege' ? 'metal' : 'arcane',
        rarity,
        tags: [...baseTags, 'structure', 'barricade'],
        text: 'Deploy to a front lane. This structure must be broken before attacks pass through that lane.',
        bibliography: faction.flavorBits[(i + 2) % faction.flavorBits.length],
      };
    } else if (i === 3 || i === 4) {
      const fieldEffects = [
        { action: 'grantArmor', amount: 1, manaGain: 1, coreDefBonus: 1 },
        { action: 'draw', amount: 1, firstSpellDiscount: 1 }
      ];
      const effect = fieldEffects[i - 3];
      card = {
        id,
        name,
        type: 'field',
        cost,
        effect,
        ability: { ...effect },
        race: faction.species,
        element: faction.traitProfile === 'growth' ? 'nature' : 'arcane',
        rarity,
        tags: [...baseTags, 'field', 'engine'],
        text: i === 3
          ? 'Field: Start of your turn gain +1 mana and +1 Core DEF while this remains active.'
          : 'Field: Your first spell each turn costs 1 less and improves tactical tempo.',
        bibliography: faction.flavorBits[(i + 3) % faction.flavorBits.length],
      };
    } else {
      const effect = { action: 'summon', amount: 1, summonCount: 1, manaGain: 1, coreDefBonus: 1, firstSpellDiscount: 1 };
      card = {
        id,
        name,
        type: 'relic',
        cost,
        effect,
        ability: { ...effect },
        race: faction.species,
        element: 'void',
        rarity,
        tags: [...baseTags, 'relic', 'boss-engine'],
        text: 'Relic: Persistent command engine that accelerates mana, defense, and reinforcement pressure.',
        bibliography: faction.flavorBits[(i + 4) % faction.flavorBits.length],
      };
    }

    baseMeta(faction, card, card.type, rarity, cost, 80 + i);
    cards.push(card);
  });

  return cards;
}

function writeJson(filepath, data) {
  fs.writeFileSync(filepath, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
}

function main() {
  const generatedByFaction = [];

  for (const faction of FACTIONS) {
    const cards = generateFactionCards(faction);
    if (cards.length < 50) throw new Error(`Faction ${faction.id} generated only ${cards.length} cards.`);
    const pack = {
      type: 'card-pack',
      id: faction.id,
      name: `${faction.name} Invasion Arsenal`,
      cards,
    };
    writeJson(path.join(PACKS_DIR, `${faction.id}.json`), pack);
    generatedByFaction.push({ faction, cards });
  }

  const packIndex = JSON.parse(fs.readFileSync(PACK_INDEX_PATH, 'utf8'));
  const entrySet = new Set(Array.isArray(packIndex.entries) ? packIndex.entries : []);
  FACTIONS.forEach((faction) => entrySet.add(`${faction.id}.json`));
  packIndex.entries = Array.from(entrySet);
  writeJson(PACK_INDEX_PATH, packIndex);

  const alienPack = {
    type: 'alien-faction-pack',
    id: 'alien-factions-v1',
    name: 'Alien Invasion Factions V1',
    factions: FACTIONS.map((f) => ({
      id: f.id,
      name: f.name,
      color: f.factionColor,
      icon: f.icon,
      threatGeometry: 'triangle',
      deckTags: f.deckTags,
      techProfile: f.techProfile,
      behaviorNotes: f.behaviorNotes,
      reinforcementStyle: f.reinforcementStyle,
      regionPreference: f.regionPreference,
      aiSkillRange: f.aiSkillRange,
      techLevelRange: f.techLevelRange,
      deckSizePreference: f.deckSizePreference,
      specialTraits: f.specialTraits,
      cardPackId: f.id,
      cardPoolSize: generatedByFaction.find((entry) => entry.faction.id === f.id)?.cards.length ?? 0,
    })),
  };
  writeJson(ALIEN_FACTIONS_PATH, alienPack);

  const cardex = JSON.parse(fs.readFileSync(CARDEX_PATH, 'utf8'));
  const cardMap = new Map();
  for (const card of Array.isArray(cardex.cards) ? cardex.cards : []) {
    if (card && card.id) cardMap.set(card.id, card);
  }

  generatedByFaction.forEach(({ cards }) => {
    cards.forEach((card) => {
      cardMap.set(card.id, {
        ...card,
        ability: card.ability ?? card.effect ?? { action: 'none', amount: 0 },
      });
    });
  });

  const mergedCards = Array.from(cardMap.values());
  mergedCards.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')) || String(a.id || '').localeCompare(String(b.id || '')));
  cardex.cards = mergedCards;
  cardex.count = mergedCards.length;
  cardex.updatedAt = new Date().toISOString();
  writeJson(CARDEX_PATH, cardex);

  const summary = generatedByFaction.map(({ faction, cards }) => `${faction.id}:${cards.length}`).join(', ');
  console.log(`Generated packs -> ${summary}`);
}

main();
