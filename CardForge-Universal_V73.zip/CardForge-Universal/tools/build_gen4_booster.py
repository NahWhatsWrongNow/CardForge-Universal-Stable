import json
import re
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VOLCANIC_PATH = ROOT / "packs" / "gen4_volcanic_ash_collection.json"
BASE_BOOSTER_PATH = ROOT / "packs" / "gen4_booster.json"
EXTRA_INPUT_PATH = ROOT / "tools" / "gen4_collections_input.txt"
OUTPUT_PATH = ROOT / "packs" / "gen4_booster.json"

RARITIES = {"common", "rare", "epic", "legendary"}
CARD_TYPE_HINTS = ("minion", "spell", "relic", "field", "structure", "token", "trap", "artifact", "aura")


def normalize_text(text: str) -> str:
    swaps = {
        "\u2019": "'",
        "\u2018": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u2212": "-",
    }
    for src, dst in swaps.items():
        text = text.replace(src, dst)
    return text


def slugify(value: str) -> str:
    value = normalize_text(value)
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = value.lower()
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value or "card"


def parse_stats(token: str):
    token = normalize_text(token).strip().rstrip(".")
    m = re.match(r"^(\d+)\s*/\s*(\d+)(?:\s+(.*))?$", token)
    if not m:
        return None
    atk = int(m.group(1))
    hp = int(m.group(2))
    tail = (m.group(3) or "").strip()
    return atk, hp, tail


def infer_collection(line: str, current: str) -> str:
    line_n = normalize_text(line)
    line_l = line_n.lower()
    if line_l.startswith("gen 4 - sea of talis collection"):
        return "Sea of Talis Collection"
    if line_l.startswith("gen 4 - shadows of the aldari collection"):
        return "Shadows Of The Aldari Collection"
    if line_l.startswith("gen 4 - the tectonic armory collection"):
        return "The Tectonic Armory Collection"
    if line_l.startswith("gen 4 - goddesses embrace collection"):
        return "Goddesses Embrace Collection"
    if line_l.startswith("fragile tribe tempo"):
        return "Scions of the West Collection"
    return current


def card_shell(name: str, collection_name: str):
    cslug = slugify(collection_name)
    return {
        "id": f"gen4-{slugify(name)}",
        "name": name,
        "rarity": "common",
        "element": "water",
        "tags": ["GEN4", "gen4-booster", f"collection:{cslug}"],
        "bibliography": f"{collection_name} field record.",
        "genVersion": 4,
        "generationVersion": 4,
        "packSource": "gen4-booster",
        "sourceType": "booster-pack",
        "sourceLabel": "Gen 4 Booster",
        "collectionName": collection_name,
        "battleCompatibility": "duel_only",
        "rulesetCompatibility": "duel_only",
    }


def parse_kind(kind_text: str):
    k = normalize_text(kind_text).lower()
    card_type = "minion"
    extra_tags = []
    race = None
    if "spell" in k:
        card_type = "spell"
    elif "relic" in k:
        card_type = "relic"
    elif "field" in k:
        card_type = "field"
    else:
        card_type = "minion"

    if "beast" in k:
        race = "beast"
    if "ship" in k:
        extra_tags.append("ship")
    if "structure" in k:
        extra_tags.append("structure")
    if "trap" in k:
        extra_tags.append("trap")

    return card_type, race, extra_tags


def apply_keywords(card: dict, text: str):
    text_l = normalize_text(text).lower()
    if " taunt" in f" {text_l}" or text_l.startswith("taunt"):
        card["taunt"] = True
    if "stealth" in text_l:
        card["stealth"] = True
    if "flying" in text_l:
        card["flying"] = True
    if "lifesteal" in text_l:
        card["lifesteal"] = True
    if "poisonous" in text_l:
        card["poisonous"] = True
    if "charge" in text_l or " rush" in f" {text_l}":
        card["charge"] = True


def parse_collectible(parts, collection_name):
    name = normalize_text(parts[0].strip())
    rarity = normalize_text(parts[1]).lower().strip()
    kind = normalize_text(parts[2]).strip()
    cost_token = normalize_text(parts[3]).strip()

    cm = re.search(r"cost\s*(\d+)", cost_token, flags=re.IGNORECASE)
    if not cm:
        return None
    cost = int(cm.group(1))

    card = card_shell(name, collection_name)
    card["rarity"] = rarity if rarity in RARITIES else "common"

    ctype, race, extra_tags = parse_kind(kind)
    card["type"] = ctype
    if race:
        card["race"] = race
    for tag in extra_tags:
        if tag not in card["tags"]:
            card["tags"].append(tag)

    card["cost"] = cost

    idx = 4
    stats = None
    if idx < len(parts):
        stats = parse_stats(parts[idx])
    if stats:
        atk, hp, tail = stats
        card["attack"] = atk
        card["health"] = hp
        card["def"] = 0
        idx += 1
        if tail:
            parts = parts[:idx] + [tail] + parts[idx:]

    text = " - ".join(normalize_text(p).strip() for p in parts[idx:]).strip()
    if text:
        card["text"] = text
        apply_keywords(card, text)

    if ctype == "spell" and "attack" in card:
        card.pop("attack", None)
        card.pop("health", None)
        card.pop("def", None)

    return card


def parse_token(parts, collection_name):
    name = normalize_text(parts[0].strip())
    descriptor = normalize_text(parts[1].strip()).lower()
    if "token" not in descriptor and "generated" not in descriptor:
        return None

    card = card_shell(name, collection_name)
    card["type"] = "minion"
    card["rarity"] = "common"
    if "token" not in card["tags"]:
        card["tags"].append("token")
    card["collectible"] = False

    idx = 2
    if len(parts) > idx:
        maybe_type = normalize_text(parts[idx]).strip().lower()
        if any(hint in maybe_type for hint in CARD_TYPE_HINTS):
            ctype, race, extra_tags = parse_kind(parts[idx])
            card["type"] = ctype
            if race:
                card["race"] = race
            for tag in extra_tags:
                if tag not in card["tags"]:
                    card["tags"].append(tag)
            idx += 1

    if len(parts) > idx:
        cm = re.search(r"cost\s*(\d+)", normalize_text(parts[idx]), flags=re.IGNORECASE)
        if cm:
            card["cost"] = int(cm.group(1))
            idx += 1

    stats = None
    if len(parts) > idx:
        stats = parse_stats(parts[idx])

    if stats:
        atk, hp, tail = stats
        card["attack"] = atk
        card["health"] = hp
        card["def"] = 0
        if card.get("type") != "spell" and "cost" not in card:
            card["cost"] = max(1, atk)
        idx += 1
        text_parts = []
        if tail:
            text_parts.append(tail)
        text_parts.extend(parts[idx:])
        text = " - ".join(normalize_text(p).strip() for p in text_parts).strip().rstrip(".")
    else:
        if "cost" not in card:
            card["cost"] = 1
        text = " - ".join(normalize_text(p).strip() for p in parts[idx:]).strip().rstrip(".")

    if text:
        card["text"] = text
        apply_keywords(card, text)

    if card.get("type") == "spell":
        card.pop("attack", None)
        card.pop("health", None)
        card.pop("def", None)

    return card


def parse_new_cards(text: str):
    cards = []
    collection_name = "Unknown Collection"
    for raw in text.splitlines():
        line = normalize_text(raw).strip()
        if not line:
            continue

        updated_collection = infer_collection(line, collection_name)
        if updated_collection != collection_name:
            collection_name = updated_collection
            continue

        if " - " not in line:
            continue

        parts = [p.strip() for p in line.split(" - ")]
        if len(parts) < 2:
            continue

        rarity = parts[1].lower().strip()
        card = None
        if rarity in RARITIES and len(parts) >= 4:
            card = parse_collectible(parts, collection_name)
        else:
            card = parse_token(parts, collection_name)

        if card:
            cards.append(card)

    return cards


def uniquify_ids(cards):
    used = set()
    for card in cards:
        base = card.get("id") or f"gen4-{slugify(card.get('name', 'card'))}"
        candidate = base
        n = 2
        while candidate in used:
            candidate = f"{base}-{n}"
            n += 1
        card["id"] = candidate
        used.add(candidate)


def normalize_volcanic(cards):
    out = []
    for c in cards:
        card = dict(c)
        card["packSource"] = "gen4-booster"
        card["sourceType"] = "booster-pack"
        card["sourceLabel"] = "Gen 4 Booster"
        card["collectionName"] = "Volcanic Ash Collection"
        tags = list(card.get("tags", []))
        if "gen4-booster" not in tags:
            tags.append("gen4-booster")
        if "collection:volcanic-ash-collection" not in tags:
            tags.append("collection:volcanic-ash-collection")
        card["tags"] = tags
        out.append(card)
    return out


def load_base_cards():
    if BASE_BOOSTER_PATH.exists():
        booster = json.loads(BASE_BOOSTER_PATH.read_text(encoding="utf-8"))
        return booster.get("cards", [])

    if VOLCANIC_PATH.exists():
        volcanic = json.loads(VOLCANIC_PATH.read_text(encoding="utf-8"))
        return normalize_volcanic(volcanic.get("cards", []))

    return []


def normalize_existing(cards):
    out = []
    for c in cards:
        card = dict(c)
        card["packSource"] = "gen4-booster"
        card["sourceType"] = "booster-pack"
        card["sourceLabel"] = "Gen 4 Booster"
        card["battleCompatibility"] = "duel_only"
        card["rulesetCompatibility"] = "duel_only"
        tags = list(card.get("tags", []))
        if "GEN4" not in tags:
            tags.append("GEN4")
        if "gen4-booster" not in tags:
            tags.append("gen4-booster")
        card["tags"] = tags
        out.append(card)
    return out


def main():
    base_cards = load_base_cards()
    existing_cards = normalize_existing(base_cards) if base_cards else []

    new_text = EXTRA_INPUT_PATH.read_text(encoding="utf-8")
    new_cards = parse_new_cards(new_text)

    existing_keys = {(c.get("name", ""), c.get("collectionName", "")) for c in existing_cards}
    deduped_new = [c for c in new_cards if (c.get("name", ""), c.get("collectionName", "")) not in existing_keys]

    all_cards = existing_cards + deduped_new
    uniquify_ids(all_cards)

    pack = {
        "type": "card-pack",
        "id": "gen4-booster",
        "name": "Gen 4 Booster",
        "description": "GEN4 booster pack containing all GEN4 world collections.",
        "cards": all_cards,
    }

    OUTPUT_PATH.write_text(json.dumps(pack, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    per_collection = {}
    for c in all_cards:
        key = c.get("collectionName", "Unknown")
        per_collection[key] = per_collection.get(key, 0) + 1

    print(f"Wrote {OUTPUT_PATH} with {len(all_cards)} cards")
    for name, count in sorted(per_collection.items()):
        print(f"- {name}: {count}")


if __name__ == "__main__":
    main()
