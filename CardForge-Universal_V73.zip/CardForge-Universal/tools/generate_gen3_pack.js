const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const PACKS_DIR = path.join(ROOT, 'packs');
const PACK_INDEX_PATH = path.join(PACKS_DIR, 'index.json');
const STORE_PATH = path.join(ROOT, 'game', 'store_packs', 'starter_store.json');

const PACK_ID = 'gen3-collapsed-dimensional-creatures';
const PACK_FILE = 'gen3_collapsed_dimensional_creatures.json';

const BASE_TAGS = ['GEN3', 'collapsed_dimensional_creatures'];

const NAME_FAMILIES = [
  { key: 'swarm', race: 'rift_kin', element: 'shadow', prefixes: ['Riftling', 'Threadling', 'Shardborn', 'Nestbound', 'Fractureborn'], nouns: ['Skirmisher', 'Swarmcaller', 'Latcher', 'Packrunner', 'Broodguide'] },
  { key: 'heal_value', race: 'sanctified', element: 'holy', prefixes: ['Lumen', 'Dawnthread', 'Mercy', 'Sanctum', 'Halo'], nouns: ['Caretaker', 'Archivist', 'Restorer', 'Channeler', 'Keeper'] },
  { key: 'adjacency', race: 'engineer', element: 'arcane', prefixes: ['Linkline', 'Node', 'Vector', 'Relay', 'Conduit'], nouns: ['Coordinator', 'Tutor', 'Marshal', 'Calibrator', 'Guide'] },
  { key: 'draw_engine', race: 'scholar', element: 'arcane', prefixes: ['Archive', 'Cipher', 'Chronicle', 'Lens', 'Script'], nouns: ['Savant', 'Broker', 'Planner', 'Observer', 'Curator'] },
  { key: 'death_synergy', race: 'undead', element: 'shadow', prefixes: ['Graveshard', 'Hollow', 'Mourning', 'Crypt', 'Dirge'], nouns: ['Collector', 'Harvester', 'Tithebearer', 'Echo', 'Reclaimer'] },
  { key: 'spell_synergy', race: 'elemental', element: 'fire', prefixes: ['Emberfold', 'Stormthread', 'Flux', 'Spark', 'Pyrestitch'], nouns: ['Adept', 'Invoker', 'Conductor', 'Lancer', 'Disciple'] },
  { key: 'ramp_big', race: 'giant', element: 'earth', prefixes: ['Titanic', 'Worldbreak', 'Stonewake', 'Cragline', 'Monolith'], nouns: ['Warden', 'Colossus', 'Breaker', 'Keeper', 'Sentinel'] },
  { key: 'control', race: 'mystic', element: 'water', prefixes: ['Frostline', 'Veil', 'Nullwake', 'Mirror', 'Abyssal'], nouns: ['Tactician', 'Interdictor', 'Banishor', 'Sentencer', 'Arbiter'] },
  { key: 'summon_support', race: 'beast', element: 'nature', prefixes: ['Packborn', 'Wildthread', 'Grove', 'Rootmark', 'Primal'], nouns: ['Caller', 'Howler', 'Tender', 'Pathfinder', 'Matron'] },
  { key: 'hybrid', race: 'construct', element: 'metal', prefixes: ['Ironweave', 'Copper', 'Steelrift', 'Ferric', 'Chainline'], nouns: ['Engineer', 'Overseer', 'Battlemind', 'Foreman', 'Guardian'] },
];

const SPELL_ACTIONS = ['dealDamage', 'draw', 'heal', 'buffAttack', 'buffHealth', 'grantDefense', 'timeLock', 'tax', 'summon', 'weakenAllEnemies', 'grantArmor', 'sentence', 'shatterFront'];

const SUPPORT_TYPES = ['field', 'structure', 'barricade', 'relic'];

const STARTER_ANCHORS = [
  {
    id: 'gen3-riftway-pathfinder',
    name: 'Riftway Pathfinder',
    type: 'minion',
    cost: 1,
    attack: 1,
    health: 2,
    def: 0,
    race: 'rift_kin',
    element: 'arcane',
    rarity: 'common',
    tags: ['starter-friendly', 'summon_support', ...BASE_TAGS],
    text: 'On Play: Add a 1-cost support card from your deck top 3 to your hand.',
    bibliography: 'The first survivors learned to read collapse currents before they learned to sleep.'
  },
  {
    id: 'gen3-collapse-channeler',
    name: 'Collapse Channeler',
    type: 'minion',
    cost: 2,
    attack: 2,
    health: 3,
    def: 0,
    race: 'mystic',
    element: 'arcane',
    rarity: 'common',
    tags: ['starter-friendly', 'draw_engine', ...BASE_TAGS],
    text: 'When you cast a spell, gain +1 ATK this turn.',
    bibliography: 'Her hands remember dimensions that no longer exist.'
  },
  {
    id: 'gen3-threadline-mentor',
    name: 'Threadline Mentor',
    type: 'minion',
    cost: 2,
    attack: 2,
    health: 2,
    def: 1,
    race: 'scholar',
    element: 'holy',
    rarity: 'common',
    tags: ['starter-friendly', 'adjacency', ...BASE_TAGS],
    text: 'Adjacent allies gain +1 DEF while this is in front row.',
    bibliography: 'Mentors carry chalk, maps, and emergency doctrine in equal measure.'
  },
  {
    id: 'gen3-ember-thread-medic',
    name: 'Ember Thread Medic',
    type: 'minion',
    cost: 2,
    attack: 1,
    health: 3,
    def: 0,
    race: 'sanctified',
    element: 'fire',
    rarity: 'common',
    tags: ['starter-friendly', 'heal_value', ...BASE_TAGS],
    text: 'On Play: Heal your hero 2.',
    bibliography: 'Every burn scar in the refuge has a matching record in her logbook.'
  },
  {
    id: 'gen3-arc-skein-defender',
    name: 'Arc Skein Defender',
    type: 'minion',
    cost: 3,
    attack: 2,
    health: 4,
    def: 1,
    taunt: true,
    race: 'construct',
    element: 'arcane',
    rarity: 'common',
    tags: ['starter-friendly', 'control', ...BASE_TAGS],
    text: 'Guard. On block, gain +1 DEF this turn.',
    bibliography: 'It was built to stand where panic would otherwise spread.'
  },
  {
    id: 'gen3-faultline-howler',
    name: 'Faultline Howler',
    type: 'minion',
    cost: 3,
    attack: 4,
    health: 2,
    def: 0,
    charge: true,
    race: 'beast',
    element: 'earth',
    rarity: 'rare',
    tags: ['summon_support', 'starter-friendly', ...BASE_TAGS],
    text: 'Charge. If an ally was summoned this turn, gain +1 ATK.',
    bibliography: 'Its howl rattles rivets loose before the charge even begins.'
  },
  {
    id: 'gen3-archive-stitcher',
    name: 'Archive Stitcher',
    type: 'minion',
    cost: 3,
    attack: 2,
    health: 4,
    def: 0,
    race: 'scholar',
    element: 'shadow',
    rarity: 'rare',
    tags: ['draw_engine', 'death_synergy', ...BASE_TAGS],
    text: 'When a friendly unit dies, draw 1 then discard 1.',
    bibliography: 'They catalog losses so they can weaponize memory later.'
  },
  {
    id: 'gen3-bastion-scribe',
    name: 'Bastion Scribe',
    type: 'minion',
    cost: 4,
    attack: 3,
    health: 5,
    def: 1,
    race: 'engineer',
    element: 'holy',
    rarity: 'rare',
    tags: ['adjacency', 'control', ...BASE_TAGS],
    text: 'Adjacent allies gain +1/+1 while this is in back row.',
    bibliography: 'He writes fortification plans directly onto active hull plating.'
  },
  {
    id: 'gen3-voidwell-sentinel',
    name: 'Voidwell Sentinel',
    type: 'minion',
    cost: 5,
    attack: 4,
    health: 6,
    def: 2,
    taunt: true,
    race: 'giant',
    element: 'shadow',
    rarity: 'epic',
    tags: ['ramp_big', 'control', ...BASE_TAGS],
    text: 'Guard. On entry, grant your hero +1 Core DEF.',
    bibliography: 'Sentinels are deployed only where worlds refuse to stay stable.'
  },
  {
    id: 'gen3-collapse-drake',
    name: 'Collapse Drake',
    type: 'minion',
    cost: 6,
    attack: 6,
    health: 6,
    def: 1,
    flying: true,
    race: 'beast',
    element: 'air',
    rarity: 'legendary',
    tags: ['ramp_big', 'finisher', ...BASE_TAGS],
    text: 'Flying. On attack, deal 1 splash damage to adjacent enemies.',
    bibliography: 'Its wingbeats shear open the weak seams between dimensions.'
  },
  {
    id: 'gen3-thread-draw',
    name: 'Thread Draw',
    type: 'spell',
    cost: 2,
    rarity: 'common',
    effect: { action: 'draw', amount: 2 },
    ability: { action: 'draw', amount: 2 },
    tags: ['draw_engine', 'starter-friendly', ...BASE_TAGS],
    text: 'Cast: Draw 2 cards.',
    bibliography: 'You survive collapse by finding one more line to pull.'
  },
  {
    id: 'gen3-emergency-mend',
    name: 'Emergency Mend',
    type: 'spell',
    cost: 2,
    rarity: 'common',
    effect: { action: 'heal', amount: 4 },
    ability: { action: 'heal', amount: 4 },
    tags: ['heal_value', 'starter-friendly', ...BASE_TAGS],
    text: 'Cast: Restore 4 health to a damaged ally or your hero.',
    bibliography: 'Most victories start with refusing to collapse first.'
  },
  {
    id: 'gen3-fault-bolt',
    name: 'Fault Bolt',
    type: 'spell',
    cost: 2,
    rarity: 'common',
    damage: 3,
    effect: { action: 'dealDamage', amount: 3 },
    ability: { action: 'dealDamage', amount: 3 },
    tags: ['starter-friendly', 'control', ...BASE_TAGS],
    text: 'Cast: Deal 3 damage to an enemy unit or hero.',
    bibliography: 'A crack in reality is still a crack; all force needs is an opening.'
  },
  {
    id: 'gen3-guardian-mandate',
    name: 'Guardian Mandate',
    type: 'sorcery',
    cost: 3,
    rarity: 'rare',
    effect: { action: 'grantDefense', amount: 2, defAmount: 2 },
    ability: { action: 'grantDefense', amount: 2, defAmount: 2 },
    tags: ['defense', 'starter-friendly', ...BASE_TAGS],
    text: 'Cast: Give an ally +2 DEF and Guard.',
    bibliography: 'Command was simple: hold the line until the young can breathe again.'
  },
  {
    id: 'gen3-war-chorus',
    name: 'War Chorus',
    type: 'spell',
    cost: 3,
    rarity: 'rare',
    effect: { action: 'buffAttack', amount: 2 },
    ability: { action: 'buffAttack', amount: 2 },
    tags: ['spell_synergy', 'starter-friendly', ...BASE_TAGS],
    text: 'Cast: Give an allied unit +2 ATK this turn.',
    bibliography: 'When the chorus starts, hesitation leaves the room first.'
  },
  {
    id: 'gen3-reinforce-line',
    name: 'Reinforce Line',
    type: 'spell',
    cost: 3,
    rarity: 'rare',
    effect: { action: 'summon', amount: 2, summonCount: 2 },
    ability: { action: 'summon', amount: 2, summonCount: 2 },
    tags: ['summon_support', 'starter-friendly', ...BASE_TAGS],
    text: 'Cast: Summon 2 token defenders into open slots.',
    bibliography: 'Reinforcements arrive as fast as your resolve can hold.'
  },
  {
    id: 'gen3-null-tax-order',
    name: 'Null Tax Order',
    type: 'instant',
    cost: 2,
    rarity: 'rare',
    effect: { action: 'tax', amount: 1 },
    ability: { action: 'tax', amount: 1 },
    tags: ['control', ...BASE_TAGS],
    text: 'Instant: Tax opponent by 1 mana next turn.',
    bibliography: 'A single delay can erase a whole offensive doctrine.'
  },
  {
    id: 'gen3-time-snag',
    name: 'Time Snag',
    type: 'instant',
    cost: 2,
    rarity: 'rare',
    effect: { action: 'timeLock', amount: 1, duration: 1 },
    ability: { action: 'timeLock', amount: 1, duration: 1 },
    tags: ['control', 'starter-friendly', ...BASE_TAGS],
    text: 'Instant: Time-Lock an enemy unit for 1 turn.',
    bibliography: 'The cleanest answer is often to make the problem arrive later.'
  },
  {
    id: 'gen3-frontier-barricade',
    name: 'Frontier Barricade',
    type: 'barricade',
    cost: 3,
    health: 8,
    def: 2,
    rarity: 'common',
    battleCompatibility: 'defense_only',
    tags: ['structure_support', 'starter-friendly', ...BASE_TAGS],
    text: 'Deploy: Blocks its lane until destroyed. On break, draw 1.',
    bibliography: 'They built these from cargo doors and stubbornness.'
  },
  {
    id: 'gen3-turret-spire',
    name: 'Turret Spire',
    type: 'structure',
    cost: 4,
    health: 7,
    def: 2,
    rarity: 'rare',
    battleCompatibility: 'defense_only',
    effect: { action: 'dealDamage', amount: 2 },
    ability: { action: 'dealDamage', amount: 2 },
    tags: ['structure_support', ...BASE_TAGS],
    text: 'Structure: At end of turn, ping the strongest enemy for 2.',
    bibliography: 'Every spire is calibrated to erase momentum, not just targets.'
  },
  {
    id: 'gen3-mana-harbor-field',
    name: 'Mana Harbor Field',
    type: 'field',
    cost: 3,
    rarity: 'rare',
    battleCompatibility: 'defense_only',
    effect: { action: 'grantArmor', amount: 1, manaGain: 1 },
    ability: { action: 'grantArmor', amount: 1, manaGain: 1 },
    tags: ['structure_support', 'ramp_big', ...BASE_TAGS],
    text: 'Field: Start of turn gain +1 mana this turn and +1 Core DEF.',
    bibliography: 'A steady harbor of power matters more than one bright burst.'
  },
  {
    id: 'gen3-reactor-ramp',
    name: 'Reactor Ramp',
    type: 'field',
    cost: 4,
    rarity: 'epic',
    battleCompatibility: 'defense_only',
    effect: { action: 'draw', amount: 1, manaGain: 2 },
    ability: { action: 'draw', amount: 1, manaGain: 2 },
    tags: ['structure_support', 'draw_engine', ...BASE_TAGS],
    text: 'Field: First spell each turn costs 1 less and draw 1 at start of turn.',
    bibliography: 'Once the reactor is stable, options become inevitability.'
  },
  {
    id: 'gen3-supply-relay',
    name: 'Supply Relay',
    type: 'relic',
    cost: 3,
    rarity: 'rare',
    battleCompatibility: 'defense_only',
    effect: { action: 'draw', amount: 1 },
    ability: { action: 'draw', amount: 1 },
    tags: ['structure_support', 'draw_engine', ...BASE_TAGS],
    text: 'Relic: First unit you play each turn draws 1 then discards 1.',
    bibliography: 'A disciplined line wins because it never runs out of pieces.'
  },
  {
    id: 'gen3-recovery-grove',
    name: 'Recovery Grove',
    type: 'field',
    cost: 3,
    rarity: 'rare',
    battleCompatibility: 'defense_only',
    effect: { action: 'heal', amount: 3 },
    ability: { action: 'heal', amount: 3 },
    tags: ['heal_value', 'structure_support', ...BASE_TAGS],
    text: 'Field: End step heal your most damaged ally for 3.',
    bibliography: 'Even in collapsed sectors, life still insists on returning.'
  }
];

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function slug(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'card';
}

function spellEffect(action, cost, i) {
  const amount = clamp(Math.ceil(cost / 2), 1, 6);
  if (action === 'dealDamage') return { action, amount: amount + 1 };
  if (action === 'draw') return { action, amount: clamp(Math.ceil(cost / 3), 1, 3) };
  if (action === 'heal') return { action, amount: clamp(amount + 1, 2, 6) };
  if (action === 'buffAttack') return { action, amount: clamp(Math.ceil(cost / 3) + 1, 1, 4) };
  if (action === 'buffHealth') return { action, amount: clamp(Math.ceil(cost / 3) + 1, 1, 4) };
  if (action === 'grantDefense') return { action, amount: clamp(Math.ceil(cost / 3) + 1, 1, 4), defAmount: clamp(Math.ceil(cost / 3) + 1, 1, 4) };
  if (action === 'timeLock') return { action, amount: 1, duration: clamp(Math.ceil(cost / 4), 1, 2) };
  if (action === 'tax') return { action, amount: clamp(Math.ceil(cost / 4), 1, 3) };
  if (action === 'summon') return { action, amount: clamp(Math.ceil(cost / 4), 1, 3), summonCount: clamp(Math.ceil(cost / 4), 1, 3) };
  if (action === 'weakenAllEnemies') return { action, amount: 1, duration: clamp(Math.ceil(cost / 4), 1, 2) };
  if (action === 'grantArmor') return { action, amount: clamp(Math.ceil(cost / 3), 1, 4) };
  if (action === 'sentence') return { action, amount: 1, duration: clamp(Math.ceil(cost / 4), 1, 2) };
  if (action === 'shatterFront') return { action, amount: 1, duration: clamp(Math.ceil(cost / 4), 1, 2) };
  return { action: 'dealDamage', amount: 2 + (i % 3) };
}

function effectText(effect) {
  const action = String(effect.action || 'dealDamage');
  const amount = Number(effect.amount || 0);
  const duration = Number(effect.duration || 1);
  if (action === 'dealDamage') return `Cast: Deal ${amount} damage.`;
  if (action === 'draw') return `Cast: Draw ${amount} card(s).`;
  if (action === 'heal') return `Cast: Heal ${amount}.`;
  if (action === 'buffAttack') return `Cast: Give +${amount} ATK this turn.`;
  if (action === 'buffHealth') return `Cast: Give +${amount} Max HP.`;
  if (action === 'grantDefense') return `Cast: Give +${effect.defAmount || amount} DEF and Guard.`;
  if (action === 'timeLock') return `Cast: Time-Lock an enemy for ${duration} turn(s).`;
  if (action === 'tax') return `Cast: Tax opponent by ${amount} mana next turn.`;
  if (action === 'summon') return `Cast: Summon ${effect.summonCount || amount} token(s).`;
  if (action === 'weakenAllEnemies') return `Cast: Weaken all enemies for ${duration} turn(s).`;
  if (action === 'grantArmor') return `Cast: Gain +${amount} Core DEF.`;
  if (action === 'sentence') return `Cast: Sentence enemy for ${duration} turn(s).`;
  if (action === 'shatterFront') return `Cast: Shatter a defending enemy for ${duration} turn(s).`;
  return `Cast: Resolve ${action}.`;
}

function rarityByIndex(i, total) {
  const p = i / Math.max(1, total - 1);
  if (p < 0.62) return 'common';
  if (p < 0.86) return 'rare';
  if (p < 0.96) return 'epic';
  return 'legendary';
}

function normalizeMeta(card) {
  const out = { ...card };
  out.tags = [...new Set([...(out.tags || []), ...BASE_TAGS])];
  out.genVersion = 3;
  out.generationVersion = 3;
  out.packSource = PACK_ID;
  out.sourceType = 'expansion-pack';
  out.sourceLabel = 'Gen 3 Expansion';
  out.battleCompatibility = out.battleCompatibility || 'both';
  out.rulesetCompatibility = out.battleCompatibility === 'defense_only' ? 'defense_invasion' : 'duel_and_defense';
  out.effect = out.effect || (out.ability && typeof out.ability === 'object' ? { ...out.ability } : undefined);
  out.ability = out.ability || (out.effect && typeof out.effect === 'object' ? { ...out.effect } : undefined);
  return out;
}

function buildProceduralMinions(count, startIndex = 0) {
  const cards = [];
  const curve = [1,1,1,2,2,2,2,3,3,3,3,4,4,4,5,5,6,6,7,8,9];
  for (let i = 0; i < count; i += 1) {
    const idx = startIndex + i;
    const family = NAME_FAMILIES[idx % NAME_FAMILIES.length];
    const prefix = family.prefixes[idx % family.prefixes.length];
    const noun = family.nouns[(idx * 3) % family.nouns.length];
    const name = `${prefix} ${noun}`;
    const cost = curve[idx % curve.length];
    const rarity = rarityByIndex(i, count);
    let attack = Math.max(1, Math.floor(cost * 0.8) + (idx % 2));
    let health = Math.max(1, Math.ceil(cost * 1.1) + ((idx % 3) - 1));
    let def = idx % 5 === 0 ? 1 : 0;
    const taunt = (family.key === 'control' || family.key === 'heal_value' || family.key === 'hybrid') && idx % 4 === 0;
    const charge = (family.key === 'swarm' || family.key === 'spell_synergy') && idx % 6 === 0;
    const swarm = family.key === 'swarm' && idx % 3 !== 1;
    const large = family.key === 'ramp_big' && cost >= 7 && idx % 2 === 0;
    const pierce = (family.key === 'control' || family.key === 'hybrid') && idx % 7 === 0 ? 1 : 0;
    const flying = family.key === 'ramp_big' && idx % 8 === 0;
    if (family.key === 'ramp_big') { health += 1; attack += 1; }
    if (family.key === 'swarm') { health = Math.max(1, health - 1); attack += 1; }
    if (family.key === 'heal_value') { def += 1; }

    const tags = [family.key, `archetype:${family.key}`];
    if (cost <= 3) tags.push('starter-friendly');
    if (swarm) tags.push('swarm');
    if (large) tags.push('large');
    if (taunt) tags.push('guard');
    if (charge) tags.push('haste');
    if (pierce) tags.push('pierce');

    const textTemplates = {
      swarm: 'When another ally is summoned, this gains +1 ATK this turn.',
      heal_value: 'Whenever you heal, this gains +1 DEF this turn.',
      adjacency: 'Adjacent allies gain +1 ATK while this remains in play.',
      draw_engine: 'On death, draw 1 if you cast a spell this turn.',
      death_synergy: 'Whenever an ally dies, gain +1 ATK this turn.',
      spell_synergy: 'Whenever you cast a spell, this gains +1/+0 this turn.',
      ramp_big: 'Costs 1 less while you control a Field or Relic.',
      control: 'On hit, apply Weakened to the defender for 1 turn.',
      summon_support: 'When you summon a unit, heal your hero 1.',
      hybrid: 'If you control both front and back row units, gain +1/+1.',
    };

    cards.push(normalizeMeta({
      id: `gen3-${slug(name)}-${idx + 1}`,
      name,
      type: 'minion',
      cost,
      attack,
      health,
      def,
      race: family.race,
      element: family.element,
      rarity,
      taunt,
      charge,
      swarm,
      large,
      flying,
      pierce,
      tags,
      text: textTemplates[family.key],
      bibliography: `Recovered from collapsed dimensional strata #${(idx % 37) + 1}.`,
    }));
  }
  return cards;
}

function buildProceduralSpells(count, startIndex = 0) {
  const cards = [];
  for (let i = 0; i < count; i += 1) {
    const idx = startIndex + i;
    const family = NAME_FAMILIES[idx % NAME_FAMILIES.length];
    const action = SPELL_ACTIONS[idx % SPELL_ACTIONS.length];
    const cost = clamp(1 + Math.floor((idx % 16) / 2), 1, 8);
    const effect = spellEffect(action, cost, idx);
    const rarity = rarityByIndex(i, count);
    const type = idx % 5 === 0 ? 'instant' : idx % 4 === 0 ? 'sorcery' : 'spell';
    const name = `${family.prefixes[(idx + 2) % family.prefixes.length]} ${['Directive','Pulse','Convergence','Refrain','Cascade','Surge','Protocol','Rescript'][idx % 8]}`;
    const tags = [family.key, `archetype:${family.key}`, `ability:${String(action).toLowerCase()}`];
    if (cost <= 3) tags.push('starter-friendly');

    cards.push(normalizeMeta({
      id: `gen3-${slug(name)}-${idx + 1}`,
      name,
      type,
      cost,
      damage: effect.action === 'dealDamage' ? effect.amount : 0,
      effect,
      ability: { ...effect },
      race: family.race,
      element: family.element,
      rarity,
      tags,
      text: effectText(effect),
      bibliography: `Filed under collapsed script lattice ${String.fromCharCode(65 + (idx % 26))}.`,
    }));
  }
  return cards;
}

function buildProceduralSupports(count, startIndex = 0) {
  const cards = [];
  for (let i = 0; i < count; i += 1) {
    const idx = startIndex + i;
    const family = NAME_FAMILIES[idx % NAME_FAMILIES.length];
    const type = SUPPORT_TYPES[idx % SUPPORT_TYPES.length];
    const cost = clamp(3 + (idx % 5), 3, 8);
    const rarity = rarityByIndex(i, count);
    const action = SPELL_ACTIONS[(idx + 3) % SPELL_ACTIONS.length];
    const effect = spellEffect(action, cost, idx);
    const name = `${family.prefixes[(idx + 1) % family.prefixes.length]} ${['Array','Bastion','Field','Engine','Rampart','Relay','Anchor','Nexus'][idx % 8]}`;
    const tags = ['structure_support', family.key, `archetype:${family.key}`, type];

    const card = {
      id: `gen3-${slug(name)}-${idx + 1}`,
      name,
      type,
      cost,
      rarity,
      race: family.race,
      element: family.element,
      effect,
      ability: { ...effect },
      tags,
      battleCompatibility: 'defense_only',
      text: type === 'barricade'
        ? 'Deploy: Blocks lane attacks until destroyed. Trigger its effect when it enters.'
        : type === 'structure'
          ? 'Structure: Persistent defense installation with a repeating tactical effect.'
          : type === 'field'
            ? 'Field: Ongoing world effect that shifts mana and survivability.'
            : 'Relic: Persistent support engine for defense operations.',
      bibliography: `Constructed from collapsed fragments in sector ${200 + idx}.`,
    };

    if (type === 'barricade' || type === 'structure') {
      card.health = 6 + (idx % 4);
      card.def = 1 + (idx % 2);
    }

    cards.push(normalizeMeta(card));
  }
  return cards;
}

function ensureUnique(cards) {
  const seen = new Set();
  const out = [];
  for (const card of cards) {
    let id = card.id;
    let bump = 2;
    while (seen.has(id)) {
      id = `${card.id}-${bump}`;
      bump += 1;
    }
    seen.add(id);
    out.push({ ...card, id });
  }
  return out;
}

function writeJson(file, payload) {
  fs.writeFileSync(file, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
}

function updatePackIndex() {
  const idx = JSON.parse(fs.readFileSync(PACK_INDEX_PATH, 'utf8'));
  const set = new Set(Array.isArray(idx.entries) ? idx.entries : []);
  set.add(PACK_FILE);
  idx.entries = Array.from(set);
  writeJson(PACK_INDEX_PATH, idx);
}

function updateStore() {
  const store = JSON.parse(fs.readFileSync(STORE_PATH, 'utf8'));
  store.products = Array.isArray(store.products) ? store.products : [];
  const existing = store.products.find((entry) => entry.id === 'gen3-pack');
  const product = {
    id: 'gen3-pack',
    name: 'GEN3 Collapsed Rift Pack',
    description: '6 GEN3 cards focused on dimensional collapse synergy, support engines, and tactical glue cards.',
    price: 260,
    count: 6,
    poolTag: 'GEN3',
    weights: { common: 0.57, rare: 0.3, epic: 0.1, legendary: 0.03 },
    pity: { threshold: 3, rarity: 'epic' },
  };
  if (existing) Object.assign(existing, product);
  else store.products.push(product);
  writeJson(STORE_PATH, store);
}

function main() {
  const anchors = STARTER_ANCHORS.map((card) => normalizeMeta(card));
  const target = 200;
  const minionTarget = 118;
  const spellTarget = 58;
  const supportTarget = 24;

  const currentMinions = anchors.filter((c) => c.type === 'minion').length;
  const currentSpells = anchors.filter((c) => ['spell', 'instant', 'sorcery'].includes(c.type)).length;
  const currentSupports = anchors.length - currentMinions - currentSpells;

  const proceduralMinions = buildProceduralMinions(Math.max(0, minionTarget - currentMinions), 0);
  const proceduralSpells = buildProceduralSpells(Math.max(0, spellTarget - currentSpells), 300);
  const proceduralSupports = buildProceduralSupports(Math.max(0, supportTarget - currentSupports), 700);

  let cards = ensureUnique([...anchors, ...proceduralMinions, ...proceduralSpells, ...proceduralSupports]);
  if (cards.length > target) cards = cards.slice(0, target);
  while (cards.length < target) {
    const i = cards.length;
    const filler = normalizeMeta({
      id: `gen3-filler-node-${i + 1}`,
      name: `Collapsed Node ${i + 1}`,
      type: 'minion',
      cost: 2,
      attack: 2,
      health: 2,
      def: 0,
      race: 'rift_kin',
      element: 'arcane',
      rarity: 'common',
      tags: ['starter-friendly', ...BASE_TAGS],
      text: 'On Play: Stabilize your hand flow for one turn.',
      bibliography: 'Emergency scaffold card generated to preserve pack cardinality.',
    });
    cards.push(filler);
  }

  cards = ensureUnique(cards).slice(0, target);

  const packPayload = {
    type: 'card-pack',
    id: PACK_ID,
    name: 'GEN3 Collapsed Dimensional Creatures',
    cards,
  };

  writeJson(path.join(PACKS_DIR, PACK_FILE), packPayload);
  updatePackIndex();
  updateStore();

  const byType = cards.reduce((acc, card) => {
    acc[card.type] = (acc[card.type] || 0) + 1;
    return acc;
  }, {});
  console.log(`Generated ${cards.length} GEN3 cards -> ${JSON.stringify(byType)}`);
}

main();
