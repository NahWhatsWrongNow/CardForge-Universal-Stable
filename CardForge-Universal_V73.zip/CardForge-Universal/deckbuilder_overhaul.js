
(() => {
  const CUSTOM_CARD_LIBRARY_KEY = 'cardforge.creator.customCards.v1';
  const EXTERNAL_USER_PACK_CACHE_KEY = 'cardforge.external_user_packs.v1';
  const DEFAULT_RULESET = {
    name: 'Standard',
    minSize: 30,
    maxSize: 30,
    targetSize: 30,
    maxCopies: 2,
    factionRestriction: '',
    universeRestriction: '',
    rarityRestriction: '',
  };
  const RULESET_PRESETS = [
    { id: 'standard', name: 'Standard (30 / 2)', minSize: 30, maxSize: 30, targetSize: 30, maxCopies: 2 },
    { id: 'commander', name: 'Commander (40 / 1)', minSize: 40, maxSize: 60, targetSize: 40, maxCopies: 1 },
    { id: 'sandbox', name: 'Sandbox (30-60 / 4)', minSize: 30, maxSize: 60, targetSize: 40, maxCopies: 4 },
    { id: 'unlimited', name: 'Unlimited (1-120 / 99)', minSize: 1, maxSize: 120, targetSize: 60, maxCopies: 99 },
  ];

  const SORT_OPTIONS = {
    newest: 'Newest',
    alphabetical: 'A-Z',
    mana: 'Mana',
    rarity: 'Rarity',
    owned: 'Owned',
    gen: 'Generation',
    custom: 'Custom First',
    unlocked: 'Unlocked First',
    recently_edited: 'Recently Edited',
    recently_used: 'Recently Used',
  };

  const STATE = {
    ctx: null,
    host: null,
    profile: null,
    cards: [],
    cardById: Object.create(null),
    decks: [],
    view: 'deckbuilder',
    collectionView: 'grid',
    selectedDeckId: null,
    draft: null,
    inspectCardId: null,
    compareCardId: null,
    panelSearch: '',
    panelSort: 'alphabetical',
    collectionSearch: '',
    collectionSort: 'alphabetical',
    panelFilters: { type: 'all', rarity: 'all', custom: 'all', gen: 'all', faction: 'all', abilityTag: 'all', owned: 'all', deckUse: 'all', lock: 'all' },
    collectionFilters: { type: 'all', rarity: 'all', custom: 'all', gen: 'all', faction: 'all', abilityTag: 'all', owned: 'all', deckUse: 'all', lock: 'all' },
    savedSearchId: '',
    dragPayload: null,
    importText: '',
    message: 'Deckbuilder ready.',
    inputRenderHandle: null,
  };

  const clone = (v) => JSON.parse(JSON.stringify(v));
  const toNum = (v, f = 0) => (Number.isFinite(Number(v)) ? Number(v) : f);
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const uniq = (arr = []) => [...new Set(arr.filter(Boolean))];
  const safeParse = (raw, fallback) => { try { const parsed = JSON.parse(raw); return parsed && typeof parsed === 'object' ? parsed : fallback; } catch { return fallback; } };
  const readStorage = (k, fallback) => safeParse(localStorage.getItem(k) || '', fallback);
  const slug = (value = '') => String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'item';
  const rarityRank = (r) => ({ common: 1, rare: 2, epic: 3, legendary: 4 }[String(r || 'common').toLowerCase()] || 1);
  const normalizeRarity = (r = 'common') => ['common', 'rare', 'epic', 'legendary'].includes(String(r || '').toLowerCase()) ? String(r).toLowerCase() : 'common';
  const escapeHtml = (t) => String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const setGlobalLeftHold = (active) => document.body.classList.toggle('left-click-hold', !!active);
  const setGlobalDragActive = (active) => document.body.classList.toggle('interaction-drag-active', !!active);
  const clearDragTargets = () => document.querySelectorAll('.drag-target').forEach((node) => node.classList.remove('drag-target'));

  function genVersionFromCard(card) {
    if (Number.isFinite(Number(card?.genVersion))) return Number(card.genVersion);
    if (Number.isFinite(Number(card?.generationVersion))) return Number(card.generationVersion);
    for (const tag of Array.isArray(card?.tags) ? card.tags : []) {
      const m = String(tag).toUpperCase().match(/^GEN(\d+)$/);
      if (m) return Number(m[1]);
    }
    return 1;
  }

  function describeEffect(effect = {}) {
    const action = String(effect.action || '').toLowerCase();
    const amount = toNum(effect.amount, 0);
    if (!action) return '';
    if (action === 'dealdamage') return `Deal ${amount} damage.`;
    if (action === 'heal') return `Heal ${amount}.`;
    if (action === 'draw') return `Draw ${amount}.`;
    if (action === 'grantdefense') return `Grant +${toNum(effect.defAmount, amount)} DEF and Guard.`;
    if (action === 'summon' || action === 'summontoken') return `Summon ${Math.max(1, toNum(effect.summonCount, amount || 1))} token(s).`;
    if (action === 'timelock') return `Time-Lock target for ${Math.max(1, toNum(effect.duration, 1))} turn(s).`;
    if (action === 'tax') return `Tax opponent by ${Math.max(1, amount)} mana next turn.`;
    if (action === 'shatterfront') return 'Shatter target defense and remove Guard this turn.';
    return action.replace(/[_-]+/g, ' ');
  }

  function abilityLines(card) {
    const out = [];
    if (card.text) out.push(String(card.text));
    if (card.rulesText) out.push(String(card.rulesText));
    if (Array.isArray(card.abilities)) {
      card.abilities.forEach((entry) => {
        if (!entry) return;
        if (typeof entry === 'string') out.push(entry);
        else if (entry.text) out.push(entry.text);
        else if (entry.effect) out.push(describeEffect(entry.effect));
      });
    }
    if (card.ability && typeof card.ability === 'object') out.push(describeEffect(card.ability));
    if (card.effect && typeof card.effect === 'object') out.push(describeEffect(card.effect));
    if (!out.length && String(card.type).toLowerCase() === 'spell') {
      const damage = toNum(card.damage, 0);
      out.push(damage > 0 ? `Cast: Deal ${damage} damage.` : 'Cast: Resolve spell effect.');
    }
    return uniq(out.map((line) => String(line || '').trim()).filter(Boolean));
  }

  function externalUserPackCards() {
    const packs = readStorage(EXTERNAL_USER_PACK_CACHE_KEY, []);
    if (!Array.isArray(packs)) return [];
    return packs.flatMap((pack) => Array.isArray(pack?.cards) ? pack.cards : []);
  }

  function deriveTags(card, lines) {
    const tags = new Set((Array.isArray(card.tags) ? card.tags : []).map((x) => String(x).toLowerCase()));
    const text = `${lines.join(' ')} ${card.name || ''}`.toLowerCase();
    const addIf = (needle, tag) => { if (text.includes(needle)) tags.add(tag); };
    addIf('damage', 'damage'); addIf('heal', 'heal'); addIf('summon', 'summon'); addIf('transform', 'transform');
    addIf('copy', 'copy'); addIf('draw', 'draw'); addIf('tax', 'tax'); addIf('def', 'defense'); addIf('guard', 'defense');
    addIf('pierce', 'pierce'); addIf('silence', 'silence'); addIf('aura', 'aura'); addIf('move', 'movement');
    addIf('death', 'death-trigger'); addIf('on hit', 'on-hit'); addIf('start of turn', 'start-turn'); addIf('end of turn', 'end-turn');
    if (String(card.type).toLowerCase() === 'spell') tags.add('spell');
    if (card.customMade) tags.add('custom-made');
    if (card.battleCompatibility) tags.add(`mode:${String(card.battleCompatibility).toLowerCase()}`);
    if (card.speciesOrigin) tags.add(`species:${String(card.speciesOrigin).toLowerCase()}`);
    if (card.worldOrigin) tags.add(`world:${String(card.worldOrigin).toLowerCase()}`);
    if (card.productionBuildingType) tags.add(`building:${String(card.productionBuildingType).toLowerCase()}`);
    if (card.producible) tags.add('producible');
    if (toNum(card.techRequirement, 0) > 0) tags.add('tech-gated');
    if (toNum(card.favorRequirement, 0) > 0) tags.add('favor-gated');
    return [...tags];
  }

  function normalizeCard(raw = {}, source = {}) {
    const rules = abilityLines(raw);
    const mtgMeta = raw.mtgMeta || raw.campaignMeta || {};
    const production = raw.production || {};
    return {
      id: String(raw.id || '').trim(),
      name: String(raw.name || raw.id || 'Unknown Card'),
      type: String(raw.type || 'minion').toLowerCase(),
      cost: Math.max(0, toNum(raw.cost, 0)),
      attack: Math.max(0, toNum(raw.attack, 0)),
      health: Math.max(0, toNum(raw.health ?? raw.maxHealth, 0)),
      def: Math.max(0, toNum(raw.def ?? raw.baseDef, 0)),
      rarity: normalizeRarity(raw.rarity || 'common'),
      race: raw.race || raw.faction || '',
      element: raw.element || '',
      universe: raw.universe || raw.homeDimension || '',
      battleCompatibility: String(raw.battleCompatibility || mtgMeta.battleCompatibility || 'both').toLowerCase(),
      speciesOrigin: String(production.speciesOrigin || mtgMeta.speciesOrigin || raw.race || '').toLowerCase(),
      worldOrigin: String(production.worldOrigin || mtgMeta.worldOrigin || '').trim(),
      unlockByWorld: String(production.unlockByWorld || mtgMeta.unlockByWorld || '').trim(),
      loseWithWorld: !!(production.loseWithWorld || mtgMeta.loseWithWorld),
      techRequirement: Math.max(0, toNum(production.techRequirement ?? mtgMeta.techRequirement, 0)),
      favorRequirement: Math.max(0, toNum(production.favorRequirement ?? mtgMeta.favorRequirement, 0)),
      producible: !!(production.producible ?? mtgMeta.producible),
      productionBuildingType: String(production.buildingType || mtgMeta.productionBuildingType || '').toLowerCase(),
      reinforcementTier: Math.max(1, toNum(production.reinforcementTier ?? mtgMeta.reinforcementTier, 1)),
      sourcePack: source.sourcePack || raw.packSource || raw.pack || '',
      sourceType: source.sourceType || raw.sourceType || 'starter-card',
      sourceLabel: source.sourceLabel || raw.sourceLabel || 'Starter Card',
      customMade: !!(source.customMade || raw.customMade || raw.sourceType === 'custom-made'),
      genVersion: genVersionFromCard(raw),
      rulesLines: rules,
      rulesText: rules.join(' '),
      bibliography: raw.bibliography || '',
      tags: deriveTags(raw, rules),
      createdAt: toNum(raw.createdAt, 0),
      updatedAt: toNum(raw.updatedAt, toNum(raw.createdAt, 0)),
      owned: 0, committed: 0, freeBeforeDraft: 0, free: 0, usedInCurrentDeck: 0, usedInDecks: 0,
      unlocked: false, locked: true, favorite: false, lastUsedAt: 0, available: true, unavailableReason: '', raw,
    };
  }

  function normalizeRules(input = {}) {
    const merged = { ...DEFAULT_RULESET, ...(input || {}) };
    merged.name = String(merged.name || DEFAULT_RULESET.name);
    merged.minSize = clamp(Math.floor(toNum(merged.minSize, 30)), 1, 200);
    merged.maxSize = clamp(Math.floor(toNum(merged.maxSize, merged.minSize)), merged.minSize, 200);
    merged.targetSize = clamp(Math.floor(toNum(merged.targetSize, merged.minSize)), merged.minSize, merged.maxSize);
    merged.maxCopies = clamp(Math.floor(toNum(merged.maxCopies, 2)), 1, 99);
    merged.factionRestriction = String(merged.factionRestriction || '');
    merged.universeRestriction = String(merged.universeRestriction || '');
    merged.rarityRestriction = String(merged.rarityRestriction || '');
    return merged;
  }

  function normalizeDeck(deck = {}, isBuiltIn = false) {
    const entries = Array.isArray(deck.entries)
      ? deck.entries.map((entry) => ({ cardId: String(entry.cardId || '').trim(), count: Math.max(0, toNum(entry.count, 0)) })).filter((entry) => entry.cardId && entry.count > 0)
      : [];
    return {
      id: String(deck.id || `custom-${Date.now()}`),
      name: String(deck.name || 'Untitled Deck'),
      subtitle: String(deck.subtitle || deck.tagline || ''),
      notes: String(deck.notes || ''),
      icon: String(deck.icon || '◆'),
      themeColor: String(deck.themeColor || '#6fa8ff'),
      folder: String(deck.folder || 'Experiments'),
      archetype: String(deck.archetype || ''),
      universe: String(deck.universe || ''),
      faction: String(deck.faction || ''),
      sourceSet: String(deck.sourceSet || ''),
      associatedPacks: Array.isArray(deck.associatedPacks) ? deck.associatedPacks : [],
      signatureCards: Array.isArray(deck.signatureCards) ? deck.signatureCards : [],
      rules: normalizeRules(deck.rules || deck.ruleset || {}),
      entries,
      isBuiltIn,
      createdAt: toNum(deck.createdAt, Date.now()),
      updatedAt: toNum(deck.updatedAt, Date.now()),
    };
  }

  const countMapFromEntries = (entries = []) => {
    const map = Object.create(null);
    entries.forEach((entry) => { map[entry.cardId] = toNum(map[entry.cardId], 0) + toNum(entry.count, 0); });
    return map;
  };

  const countMapFromSlots = (slots = []) => {
    const map = Object.create(null);
    slots.forEach((cardId) => {
      if (!cardId) return;
      map[cardId] = toNum(map[cardId], 0) + 1;
    });
    return map;
  };

  function entriesToSlots(entries = [], targetSize = 30) {
    const slots = [];
    entries.forEach((entry) => {
      for (let i = 0; i < toNum(entry.count, 0); i += 1) slots.push(entry.cardId);
    });
    const size = Math.max(1, Math.floor(toNum(targetSize, 30)));
    if (slots.length > size) return slots.slice(0, size);
    while (slots.length < size) slots.push(null);
    return slots;
  }

  function slotsToEntries(slots = []) {
    const counts = countMapFromSlots(slots);
    return Object.entries(counts).map(([cardId, count]) => ({ cardId, count })).sort((a, b) => a.cardId.localeCompare(b.cardId));
  }

  function ensureProfileFields(profile) {
    profile.customDecks = Array.isArray(profile.customDecks) ? profile.customDecks : [];
    profile.deckFolders = Array.isArray(profile.deckFolders) ? profile.deckFolders : ['Ranked', 'Lore Decks', 'Experiments', 'AI Bosses', 'Tournament Builds', 'Meme Decks'];
    profile.deckRulesets = profile.deckRulesets && typeof profile.deckRulesets === 'object' ? profile.deckRulesets : {};
    profile.deckSnapshots = profile.deckSnapshots && typeof profile.deckSnapshots === 'object' ? profile.deckSnapshots : {};
    profile.deckSearchPresets = Array.isArray(profile.deckSearchPresets) ? profile.deckSearchPresets : [];
    profile.favoriteCards = Array.isArray(profile.favoriteCards) ? profile.favoriteCards : [];
    profile.cardLastUsed = profile.cardLastUsed && typeof profile.cardLastUsed === 'object' ? profile.cardLastUsed : {};
    profile.archivedDeckIds = Array.isArray(profile.archivedDeckIds) ? profile.archivedDeckIds : [];
    profile.collection = profile.collection && typeof profile.collection === 'object' ? profile.collection : {};
    profile.mapWorld = profile.mapWorld && typeof profile.mapWorld === 'object' ? profile.mapWorld : {};
    profile.mapWorld.campaign = profile.mapWorld.campaign && typeof profile.mapWorld.campaign === 'object' ? profile.mapWorld.campaign : {};
    profile.mapWorld.campaign.ownedWorldIds = Array.isArray(profile.mapWorld.campaign.ownedWorldIds) ? profile.mapWorld.campaign.ownedWorldIds : [];
    profile.mapWorld.campaign.lostWorldIds = Array.isArray(profile.mapWorld.campaign.lostWorldIds) ? profile.mapWorld.campaign.lostWorldIds : [];
    profile.mapWorld.campaign.speciesAccess = profile.mapWorld.campaign.speciesAccess && typeof profile.mapWorld.campaign.speciesAccess === 'object'
      ? profile.mapWorld.campaign.speciesAccess
      : {};
    profile.mapWorld.campaign.worldStates = profile.mapWorld.campaign.worldStates && typeof profile.mapWorld.campaign.worldStates === 'object'
      ? profile.mapWorld.campaign.worldStates
      : {};
  }

  function cardAvailabilityForCampaign(card) {
    const campaign = STATE.profile?.mapWorld?.campaign || {};
    const ownedWorlds = new Set(campaign.ownedWorldIds || []);
    const lostWorlds = new Set(campaign.lostWorldIds || []);
    const speciesAccess = campaign.speciesAccess || {};
    if (card.battleCompatibility === 'duel_only') return { available: false, reason: 'Duel-only card (not legal in defense/conquest deck).' };
    if (card.unlockByWorld && !ownedWorlds.has(card.unlockByWorld)) {
      return { available: false, reason: `Requires world ownership: ${card.unlockByWorld}.` };
    }
    if (card.loseWithWorld && card.unlockByWorld && lostWorlds.has(card.unlockByWorld)) {
      return { available: false, reason: `World lost: ${card.unlockByWorld}.` };
    }
    if (card.worldOrigin && lostWorlds.has(card.worldOrigin)) {
      return { available: false, reason: `Origin world lost: ${card.worldOrigin}.` };
    }
    if (card.speciesOrigin && speciesAccess[card.speciesOrigin] === false) {
      return { available: false, reason: `Species unavailable: ${card.speciesOrigin}.` };
    }
    if (card.techRequirement > 0 && card.worldOrigin) {
      const world = campaign.worldStates?.[card.worldOrigin];
      const tech = toNum(world?.techLevel, 0);
      if (tech < card.techRequirement) return { available: false, reason: `Needs tech ${card.techRequirement} (${tech} current).` };
    }
    if (card.favorRequirement > 0 && card.worldOrigin) {
      const world = campaign.worldStates?.[card.worldOrigin];
      const favor = toNum(world?.favor, 0);
      if (favor < card.favorRequirement) return { available: false, reason: `Needs favor ${card.favorRequirement} (${Math.round(favor)} current).` };
    }
    return { available: true, reason: '' };
  }

  async function loadCardCatalog(ctx) {
    const cards = [];
    try {
      const payload = await ctx.loadJson('./cardex.json', ctx.localCardexFallback || { cards: [] });
      (payload.cards || []).forEach((card) => cards.push(normalizeCard(card, { sourceType: 'starter-card', sourceLabel: 'Starter Card' })));
    } catch {
      (ctx.localCardexFallback?.cards || []).forEach((card) => cards.push(normalizeCard(card, { sourceType: 'starter-card', sourceLabel: 'Starter Card' })));
    }

    try {
      const packIndex = await ctx.loadJson('./packs/index.json', { entries: [] });
      for (const entry of packIndex.entries || []) {
        try {
          const pack = await ctx.loadJson(`./packs/${entry}`, null);
          if (!Array.isArray(pack?.cards)) continue;
          pack.cards.forEach((card) => cards.push(normalizeCard(card, { sourceType: 'pack-card', sourceLabel: 'Pack Card', sourcePack: pack.id || String(entry).replace('.json', '') })));
        } catch {
          // ignore bad pack file
        }
      }
    } catch {
      // optional when packs unavailable
    }

    const customCards = readStorage(CUSTOM_CARD_LIBRARY_KEY, {});
    Object.values(customCards).forEach((card) => cards.push(normalizeCard(card, { sourceType: 'custom-made', sourceLabel: 'Custom Made', sourcePack: 'custom', customMade: true })));
    externalUserPackCards().forEach((card) => cards.push(normalizeCard(card, {
      sourceType: 'pack-card',
      sourceLabel: 'User Pack',
      sourcePack: card.userPackId || card.packSource || 'user-pack',
    })));

    const priority = { 'custom-made': 3, 'pack-card': 2, 'starter-card': 1 };
    const merged = Object.create(null);
    cards.forEach((card) => {
      if (!card.id) return;
      if (!merged[card.id] || priority[card.sourceType] >= priority[merged[card.id].sourceType]) merged[card.id] = card;
    });

    const out = Object.values(merged).sort((a, b) => a.name.localeCompare(b.name));
    const byId = Object.create(null);
    out.forEach((card) => { byId[card.id] = card; });
    return { cards: out, byId };
  }

  function refreshDecks() {
    const builtIn = (STATE.ctx.getCachedDecks?.() || []).map((deck) => normalizeDeck(deck, true));
    const custom = (STATE.profile.customDecks || []).map((deck) => normalizeDeck(deck, false));
    const seen = new Set();
    const merged = [];
    [...builtIn, ...custom].forEach((deck) => {
      if (seen.has(deck.id)) return;
      seen.add(deck.id);
      merged.push(deck);
    });
    STATE.decks = merged;
  }

  function getCustomDecks() {
    return (STATE.profile.customDecks || []).map((deck) => normalizeDeck(deck, false));
  }

  function makeDraft(deck, sourceType) {
    const normalized = normalizeDeck(deck, sourceType === 'built-in');
    return {
      id: normalized.id,
      sourceDeckId: normalized.id,
      sourceType,
      originalDeck: clone(normalized),
      name: normalized.name,
      subtitle: normalized.subtitle,
      notes: normalized.notes,
      icon: normalized.icon,
      themeColor: normalized.themeColor,
      folder: normalized.folder,
      archetype: normalized.archetype,
      universe: normalized.universe,
      faction: normalized.faction,
      sourceSet: normalized.sourceSet,
      associatedPacks: [...normalized.associatedPacks],
      signatureCards: [...normalized.signatureCards],
      rules: normalizeRules(normalized.rules),
      slots: entriesToSlots(normalized.entries, normalized.rules.targetSize),
      refundPreview: countMapFromEntries(normalized.entries),
      dirty: false,
    };
  }

  function makeEmptyDraft() {
    const rules = normalizeRules(DEFAULT_RULESET);
    return {
      id: `custom-${Date.now()}`,
      sourceDeckId: null,
      sourceType: 'new',
      originalDeck: null,
      name: 'New Deck', subtitle: '', notes: '', icon: '◆', themeColor: '#6fa8ff', folder: 'Experiments',
      archetype: '', universe: '', faction: '', sourceSet: '', associatedPacks: [], signatureCards: [],
      rules,
      slots: new Array(rules.targetSize).fill(null),
      refundPreview: {},
      dirty: true,
    };
  }

  function ownershipSnapshot() {
    const customDecks = getCustomDecks();
    const excludeDeckId = STATE.draft?.sourceType === 'custom' ? STATE.draft.sourceDeckId : null;
    const committed = Object.create(null);
    customDecks.forEach((deck) => {
      if (deck.id === excludeDeckId) return;
      deck.entries.forEach((entry) => { committed[entry.cardId] = toNum(committed[entry.cardId], 0) + toNum(entry.count, 0); });
    });
    const usedInDraft = countMapFromSlots(STATE.draft?.slots || []);
    const usedInDecks = Object.create(null);
    customDecks.forEach((deck) => {
      uniq(deck.entries.map((entry) => entry.cardId)).forEach((cardId) => { usedInDecks[cardId] = toNum(usedInDecks[cardId], 0) + 1; });
    });
    const favoriteSet = new Set(STATE.profile.favoriteCards || []);
    STATE.cards.forEach((card) => {
      const owned = Math.max(0, toNum(STATE.profile.collection?.[card.id], 0));
      const committedCount = Math.max(0, toNum(committed[card.id], 0));
      const used = Math.max(0, toNum(usedInDraft[card.id], 0));
      const availability = cardAvailabilityForCampaign(card);
      const freeBefore = availability.available ? Math.max(0, owned - committedCount) : 0;
      card.owned = owned;
      card.committed = committedCount;
      card.usedInCurrentDeck = used;
      card.freeBeforeDraft = freeBefore;
      card.free = Math.max(0, freeBefore - used);
      card.available = availability.available;
      card.unavailableReason = availability.reason;
      card.unlocked = owned > 0;
      card.locked = owned <= 0;
      card.usedInDecks = toNum(usedInDecks[card.id], 0);
      card.favorite = favoriteSet.has(card.id);
      card.lastUsedAt = toNum(STATE.profile.cardLastUsed?.[card.id], 0);
    });
  }

  function draftStats() {
    const entries = slotsToEntries(STATE.draft?.slots || []);
    const rules = normalizeRules(STATE.draft?.rules || DEFAULT_RULESET);
    const size = (STATE.draft?.slots || []).filter(Boolean).length;
    const warnings = [];
    const violations = Object.create(null);
    const manaCurve = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, '6+': 0 };
    const typeBreakdown = Object.create(null);
    const rarityBreakdown = Object.create(null);
    let totalCost = 0;
    let early = 0;
    let threats = 0;
    let removal = 0;
    let sustain = 0;

    entries.forEach((entry) => {
      const card = STATE.cardById[entry.cardId];
      if (!card) return;
      const count = toNum(entry.count, 0);
      const bucket = card.cost >= 6 ? '6+' : String(card.cost);
      manaCurve[bucket] = toNum(manaCurve[bucket], 0) + count;
      typeBreakdown[card.type] = toNum(typeBreakdown[card.type], 0) + count;
      rarityBreakdown[card.rarity] = toNum(rarityBreakdown[card.rarity], 0) + count;
      totalCost += card.cost * count;
      if (card.cost <= 2) early += count;
      if (card.attack >= 5 || card.tags.includes('threat')) threats += count;
      if (card.tags.includes('removal') || card.rulesText.toLowerCase().includes('deal')) removal += count;
      if (card.tags.includes('heal') || card.rulesText.toLowerCase().includes('heal') || card.tags.includes('lifesteal')) sustain += count;
      if (count > rules.maxCopies) {
        violations[card.id] = violations[card.id] || [];
        violations[card.id].push(`Over copy cap ${rules.maxCopies}`);
      }
      if (!card.available) {
        violations[card.id] = violations[card.id] || [];
        violations[card.id].push(card.unavailableReason || 'Unavailable in current campaign ownership state.');
      }
      if (count > card.freeBeforeDraft) {
        violations[card.id] = violations[card.id] || [];
        violations[card.id].push(`Need ${count}, own ${card.freeBeforeDraft}`);
      }
    });

    if (size < rules.minSize) warnings.push(`Under minimum size (${size}/${rules.minSize}).`);
    if (size > rules.maxSize) warnings.push(`Over maximum size (${size}/${rules.maxSize}).`);
    if (size !== rules.targetSize) warnings.push(`Target size ${rules.targetSize}, current ${size}.`);
    if (Object.keys(violations).length) warnings.push(`Copy/ownership violations on ${Object.keys(violations).length} card(s).`);
    if (early < Math.max(4, Math.floor(rules.targetSize * 0.2))) warnings.push('Weak early game (few 0-2 cost cards).');
    if (threats < Math.max(3, Math.floor(rules.targetSize * 0.14))) warnings.push('Few threat cards.');
    if (removal < Math.max(2, Math.floor(rules.targetSize * 0.1))) warnings.push('Low removal coverage.');
    if (sustain < 2) warnings.push('Low sustain/healing.');
    if (toNum(manaCurve['6+'], 0) > Math.ceil(rules.targetSize * 0.42)) warnings.push('Too many expensive cards (6+).');

    return { entries, size, rules, warnings, violations, manaCurve, typeBreakdown, rarityBreakdown, avgCost: size > 0 ? Number((totalCost / size).toFixed(2)) : 0 };
  }

  function limitBadge(card, stats) {
    const used = card.usedInCurrentDeck;
    const cap = stats.rules.maxCopies;
    if (!card.available) return { state: 'unavailable', text: 'Campaign-Locked' };
    if (card.freeBeforeDraft <= 0) return { state: 'unavailable', text: 'Unavailable' };
    if (used > cap) return { state: 'over', text: `Over ${cap}` };
    if (used === cap) return { state: 'at', text: `At ${cap}` };
    return { state: 'under', text: `${used}/${cap}` };
  }

  function draftEvaluationPayload() {
    return {
      id: STATE.draft?.sourceDeckId || STATE.draft?.id || `draft-${Date.now()}`,
      name: STATE.draft?.name || 'Current Draft',
      icon: STATE.draft?.icon || '◆',
      themeColor: STATE.draft?.themeColor || '#6fa8ff',
      archetype: STATE.draft?.archetype || '',
      rules: normalizeRules(STATE.draft?.rules || DEFAULT_RULESET),
      entries: slotsToEntries(STATE.draft?.slots || []),
    };
  }

  async function openDeckEvaluatorFromDraft() {
    const rater = window.CardForgeDeckRater;
    if (!rater?.open) {
      STATE.message = 'Deck evaluator runtime unavailable.';
      return;
    }
    const payload = draftEvaluationPayload();
    if (!rater.checkDeckLegality) {
      await rater.open({ entry: 'deckbuilder', mode: 'deck', suppliedDeck: payload });
      STATE.message = 'Opened deck evaluator for the current draft.';
      return;
    }
    const legality = await rater.checkDeckLegality(payload);
    if (legality.ok) {
      await rater.open({ entry: 'deckbuilder', mode: 'deck', suppliedDeck: payload });
      STATE.message = 'Opened deck evaluator for the current draft.';
      return;
    }
    await rater.open({
      entry: 'deckbuilder',
      mode: 'deck',
      speech: `Current draft is not eligible for the normal-mode evaluator. ${legality.reason} Choose a legal duel or Local Player deck to continue.`,
    });
    STATE.message = `Current draft cannot be evaluated directly. ${legality.reason}`;
  }

  function deckRaterStamp(deck) {
    if (!window.CardForgeDeckRater?.getDeckStamp) return '';
    const stamp = window.CardForgeDeckRater.getDeckStamp(deck);
    if (!stamp) return '';
    return `<span class="rater-deck-stamp" title="${escapeHtml(`${stamp.evaluator} • ${stamp.reliability} • ${stamp.evaluatedAt}`)}">${escapeHtml(stamp.label)}</span>`;
  }

  function sortCards(cards, key) {
    const sorter = {
      newest: (a, b) => (b.updatedAt - a.updatedAt) || a.name.localeCompare(b.name),
      alphabetical: (a, b) => a.name.localeCompare(b.name),
      mana: (a, b) => (a.cost - b.cost) || a.name.localeCompare(b.name),
      rarity: (a, b) => rarityRank(a.rarity) - rarityRank(b.rarity) || a.name.localeCompare(b.name),
      owned: (a, b) => (b.owned - a.owned) || a.name.localeCompare(b.name),
      gen: (a, b) => (b.genVersion - a.genVersion) || a.name.localeCompare(b.name),
      custom: (a, b) => Number(b.customMade) - Number(a.customMade) || a.name.localeCompare(b.name),
      unlocked: (a, b) => Number(b.unlocked) - Number(a.unlocked) || a.name.localeCompare(b.name),
      recently_edited: (a, b) => (b.updatedAt - a.updatedAt) || a.name.localeCompare(b.name),
      recently_used: (a, b) => (b.lastUsedAt - a.lastUsedAt) || a.name.localeCompare(b.name),
    }[key] || ((a, b) => a.name.localeCompare(b.name));
    return [...cards].sort(sorter);
  }

  function passesFilters(card, filters, query) {
    const q = String(query || '').trim().toLowerCase();
    if (q) {
      const hay = `${card.id} ${card.name} ${card.rulesText} ${card.tags.join(' ')} ${card.genVersion} ${card.sourcePack} ${card.bibliography}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (filters.type !== 'all' && card.type !== filters.type) return false;
    if (filters.rarity !== 'all' && card.rarity !== filters.rarity) return false;
    if (filters.custom === 'custom' && !card.customMade) return false;
    if (filters.custom === 'builtin' && card.customMade) return false;
    if (filters.gen !== 'all' && String(card.genVersion) !== String(filters.gen)) return false;
    if (filters.faction !== 'all' && !String(card.race || '').toLowerCase().includes(String(filters.faction).toLowerCase())) return false;
    if (filters.abilityTag !== 'all' && !card.tags.includes(String(filters.abilityTag).toLowerCase())) return false;
    if (filters.owned === 'owned' && card.owned <= 0) return false;
    if (filters.owned === 'free' && card.free <= 0) return false;
    if (filters.deckUse === 'used' && card.usedInDecks <= 0) return false;
    if (filters.deckUse === 'unused' && card.usedInDecks > 0) return false;
    if (filters.lock === 'locked' && card.unlocked) return false;
    if (filters.lock === 'unlocked' && !card.unlocked) return false;
    return true;
  }

  const filterCards = (filters, query, sort) => sortCards(STATE.cards.filter((card) => passesFilters(card, filters, query)), sort);

  function optionsFromCards(cards) {
    return {
      types: uniq(cards.map((card) => card.type)).sort(),
      rarities: uniq(cards.map((card) => card.rarity)).sort((a, b) => rarityRank(a) - rarityRank(b)),
      gens: uniq(cards.map((card) => String(card.genVersion))).sort((a, b) => Number(a) - Number(b)),
      factions: uniq(cards.map((card) => card.race).filter(Boolean)).sort(),
      abilityTags: uniq(cards.flatMap((card) => card.tags)).sort(),
    };
  }

  function renderFilterControls(scope, filters, options) {
    const attr = scope === 'panel' ? 'data-panel-filter' : 'data-collection-filter';
    const select = (field, rows) => `<label>${field}<select ${attr}="${field}">${rows.map(([value, label]) => `<option value="${escapeHtml(value)}" ${String(filters[field]) === String(value) ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select></label>`;
    return [
      select('type', [['all', 'Type'], ...options.types.map((value) => [value, value])]),
      select('rarity', [['all', 'Rarity'], ...options.rarities.map((value) => [value, value])]),
      select('custom', [['all', 'Origin'], ['custom', 'Custom'], ['builtin', 'Built-In']]),
      select('gen', [['all', 'Gen'], ...options.gens.map((value) => [value, `GEN ${value}`])]),
      select('faction', [['all', 'Faction'], ...options.factions.map((value) => [value, value])]),
      select('abilityTag', [['all', 'Ability Tag'], ...options.abilityTags.slice(0, 120).map((value) => [value, value])]),
      select('owned', [['all', 'Ownership'], ['owned', 'Owned >0'], ['free', 'Free >0']]),
      select('deckUse', [['all', 'Deck Use'], ['used', 'Used in decks'], ['unused', 'Unused']]),
      select('lock', [['all', 'Lock'], ['locked', 'Locked'], ['unlocked', 'Unlocked']]),
    ].join('');
  }

  function renderInventory(cards, stats, mode = 'compact') {
    if (!cards.length) return '<div class="db-empty">No cards match the active filters/search.</div>';
    const row = (card, compact = false) => {
      const badge = limitBadge(card, stats);
      const availability = card.available
        ? '<div class="db-counts">Availability: Available</div>'
        : `<div class="db-counts availability-warning">Availability: ${escapeHtml(card.unavailableReason || 'Campaign locked')}</div>`;
      return `<article class="db-card-row rarity-${card.rarity}" data-card-id="${card.id}" data-drag-type="inventory-card" draggable="true"><div class="db-row-main"><strong>${escapeHtml(card.name)}</strong><div>${card.type.toUpperCase()} • ${card.cost} mana • ${card.attack}/${card.health} • DEF ${card.def}</div>${compact ? '' : `<div class="db-row-text">${escapeHtml(card.rulesLines[0] || 'No battle text available.')}</div>`}<div class="db-tags">${card.tags.slice(0, compact ? 3 : 6).map((tag) => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div></div><div class="db-row-side"><div class="db-counts">Owned ${card.owned} • Used ${card.usedInCurrentDeck} • Free ${card.free}</div><div class="db-counts">Gen ${card.genVersion} • ${escapeHtml(card.customMade ? 'Custom' : card.sourceLabel)}</div><div class="db-counts">Used in ${card.usedInDecks} deck(s)</div>${availability}<div class="db-limit-badge ${badge.state}">${badge.text}</div><div class="db-row-actions"><button data-action="add-card" data-card-id="${card.id}">+1</button><button data-action="remove-card" data-card-id="${card.id}">-1</button><button data-action="fill-card" data-card-id="${card.id}">Fill</button><button data-action="remove-all-card" data-card-id="${card.id}">Clear</button><button data-action="inspect-card" data-card-id="${card.id}">Inspect</button><button data-action="toggle-favorite" data-card-id="${card.id}">${card.favorite ? '★' : '☆'}</button></div></div></article>`;
    };
    const tile = (card) => {
      const badge = limitBadge(card, stats);
      const availability = card.available ? 'Available' : (card.unavailableReason || 'Campaign locked');
      return `<article class="db-card-tile rarity-${card.rarity}" data-card-id="${card.id}" data-drag-type="inventory-card" draggable="true"><div class="db-card-head"><strong>${escapeHtml(card.name)}</strong><button data-action="toggle-favorite" data-card-id="${card.id}">${card.favorite ? '★' : '☆'}</button></div><div class="db-card-stats">${card.cost} mana • ${card.attack}/${card.health} • DEF ${card.def}</div><div class="db-card-line">${escapeHtml(card.rulesLines[0] || 'No battle text available.')}</div><div class="db-card-badges"><span class="tag-chip">${card.type}</span><span class="tag-chip">${card.rarity}</span><span class="tag-chip">GEN ${card.genVersion}</span><span class="tag-chip">${card.customMade ? 'custom-made' : 'starter/pack'}</span></div><div class="db-card-counts">Owned ${card.owned} • Used ${card.usedInCurrentDeck} • Free ${card.free}</div><div class="db-card-counts ${card.available ? '' : 'availability-warning'}">${escapeHtml(availability)}</div><div class="db-limit-badge ${badge.state}">${badge.text}</div><div class="db-tile-actions"><button data-action="add-card" data-card-id="${card.id}">Add</button><button data-action="inspect-card" data-card-id="${card.id}">Inspect</button></div></article>`;
    };
    if (mode === 'grid') return `<div class="db-card-grid">${cards.map((card) => tile(card)).join('')}</div>`;
    if (mode === 'list') return cards.map((card) => row(card, false)).join('');
    return cards.map((card) => row(card, true)).join('');
  }

  function render() {
    ownershipSnapshot();
    const stats = draftStats();
    const options = optionsFromCards(STATE.cards);
    const panelCards = filterCards(STATE.panelFilters, STATE.panelSearch, STATE.panelSort);
    const collectionCards = filterCards(STATE.collectionFilters, STATE.collectionSearch, STATE.collectionSort);
    const renderDeckList = () => STATE.decks.length ? STATE.decks.map((deck) => `<button class="db-deck-row ${STATE.selectedDeckId === deck.id ? 'selected' : ''}" data-action="select-deck" data-deck-id="${deck.id}">${escapeHtml(deck.name)} (${deck.entries.reduce((sum, entry) => sum + entry.count, 0)})${deck.isBuiltIn ? ' • template' : ''}${deckRaterStamp(deck)}</button>`).join('') : '<div class="db-empty">No decks found.</div>';
    const renderCurve = () => { const labels = ['0', '1', '2', '3', '4', '5', '6+']; const max = Math.max(1, ...labels.map((l) => toNum(stats.manaCurve[l], 0))); return labels.map((l) => `<div class="db-curve-bar"><span>${l}</span><div class="db-curve-track"><i style="width:${Math.round((toNum(stats.manaCurve[l], 0) / max) * 100)}%"></i></div><strong>${toNum(stats.manaCurve[l], 0)}</strong></div>`).join(''); };
    const renderWarnings = () => stats.warnings.length ? `<ul class="db-warning-list">${stats.warnings.map((w) => `<li>${escapeHtml(w)}</li>`).join('')}</ul>` : '<div class="db-ok">Deck validation passed.</div>';
    const renderSlots = () => { const slots = STATE.draft?.slots || []; const cols = slots.length >= 60 ? 10 : slots.length >= 50 ? 9 : slots.length >= 40 ? 8 : 6; return `<div class="db-slot-grid" style="--db-slot-cols:${cols}">${slots.map((cardId, index) => { if (!cardId) return `<div class="db-slot empty" data-slot-index="${index}"><div class="db-slot-index">${index + 1}</div><div class="db-slot-empty">Drop card</div></div>`; const card = STATE.cardById[cardId]; const badge = limitBadge(card, stats); const bad = (stats.violations[cardId] || []).length ? 'invalid' : ''; return `<div class="db-slot ${bad}" data-slot-index="${index}"><div class="db-slot-index">${index + 1}</div><div class="db-slot-card" data-card-id="${cardId}" data-slot-index="${index}" data-drag-type="slot-card" draggable="true"><strong>${escapeHtml(card?.name || cardId)}</strong><div>${card?.cost ?? 0} mana • ${escapeHtml(card?.type || 'card')}</div><div>${card?.attack ?? 0}/${card?.health ?? 0} • DEF ${card?.def ?? 0}</div><div class="db-limit-badge ${badge.state}">${badge.text}</div></div><div class="db-slot-actions"><button data-action="remove-slot" data-slot-index="${index}">Remove</button><button data-action="inspect-card" data-card-id="${cardId}">Inspect</button></div></div>`; }).join('')}</div>`; };
    const inspect = () => {
      if (!STATE.inspectCardId) return '<div class="db-inspect hidden"></div>';
      const p = STATE.cardById[STATE.inspectCardId];
      if (!p) return '<div class="db-inspect hidden"></div>';
      const c = STATE.compareCardId && STATE.compareCardId !== p.id ? STATE.cardById[STATE.compareCardId] : null;
      const compatLabel = (card) => (card.battleCompatibility === 'duel_only'
        ? 'Duel Only'
        : (card.battleCompatibility === 'defense_only' ? 'Defense/Conquest Only' : 'Both'));
      const availabilityLabel = (card) => card.available ? 'Available' : (card.unavailableReason || 'Campaign locked');
      const block = (card, label) => `<section class="db-inspect-block rarity-${card.rarity}">
        <h4>${label}: ${escapeHtml(card.name)}</h4>
        <div>${card.type.toUpperCase()} • ${card.cost} mana</div>
        <div>${card.attack}/${card.health} • DEF ${card.def}</div>
        <div>Rarity ${card.rarity} • GEN ${card.genVersion}</div>
        <div>Source ${escapeHtml(card.customMade ? 'custom-made' : card.sourceLabel)}${card.sourcePack ? ` (${escapeHtml(card.sourcePack)})` : ''}</div>
        <div>Owned ${card.owned} • Used ${card.usedInCurrentDeck} • Free ${card.free}</div>
        <div>Battle Compatibility: ${escapeHtml(compatLabel(card))}</div>
        <div>Species/World: ${escapeHtml(card.speciesOrigin || 'n/a')} • ${escapeHtml(card.worldOrigin || 'n/a')}</div>
        <div>Production: ${card.producible ? `Yes (${escapeHtml(card.productionBuildingType || 'any')})` : 'No'} • Tier ${card.reinforcementTier}</div>
        <div>Requirements: Tech ${card.techRequirement} • Favor ${card.favorRequirement}</div>
        <div>Unlock/Loss: ${escapeHtml(card.unlockByWorld || 'none')} • ${card.loseWithWorld ? 'Lost with origin world' : 'Persistent'}</div>
        <div class="db-counts ${card.available ? '' : 'availability-warning'}">Availability: ${escapeHtml(availabilityLabel(card))}</div>
        <div class="db-inspect-lines">${card.rulesLines.map((line) => `<p>${escapeHtml(line)}</p>`).join('')}</div>
        <div class="db-tags">${card.tags.map((tag) => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('')}</div>
      </section>`;
      return `<div class="db-inspect"><div class="db-inspect-head"><h3>Card Inspect</h3><div class="db-row-actions"><button data-action="add-card" data-card-id="${p.id}">Add to Deck</button><button data-action="set-compare" data-card-id="${p.id}">Set Compare</button><button data-action="close-inspect">Close</button></div></div><div class="db-inspect-grid ${c ? 'compare' : ''}">${block(p, 'Primary')}${c ? block(c, 'Compare') : ''}</div></div>`;
    };

    const top = `<div class="db-topbar"><div class="db-title-wrap"><h3>Collection + Deckbuilder</h3><div class="db-subline">Ownership-safe deck editing with drag/drop, snapshots, rulesets, searchable ability metadata, and premium deck evaluation.</div></div><div class="db-top-actions"><button data-action="switch-view" data-view="deckbuilder" class="${STATE.view === 'deckbuilder' ? 'active' : ''}">Deck Builder</button><button data-action="switch-view" data-view="collection" class="${STATE.view === 'collection' ? 'active' : ''}">Collection</button><button data-action="new-deck">New</button><button data-action="save-deck">Save</button><button data-action="save-as-deck">Save As</button><button data-action="evaluate-deck">Evaluate</button><button data-action="revert-deck">Revert</button></div><div class="db-status-line"><span class="${STATE.draft?.dirty ? 'db-dirty' : 'db-clean'}">${STATE.draft?.dirty ? 'Unsaved changes' : 'Saved'}</span><span>${stats.size}/${stats.rules.targetSize}</span><span>Copy cap ${stats.rules.maxCopies}</span><span>${escapeHtml(STATE.message)}</span></div></div>`;

    const deckView = `<div class="db-layout"><aside class="db-left"><section class="db-panel"><div class="db-panel-head"><h3>Saved Decks</h3><button data-action="new-deck">New</button></div><div class="db-list">${renderDeckList()}</div><div class="db-panel-actions"><button data-action="use-template">Use Template</button><button data-action="duplicate-deck">Duplicate</button><button data-action="delete-deck">Archive</button></div></section><section class="db-panel"><h3>Deck Identity</h3><label>Name <input data-field="name" value="${escapeHtml(STATE.draft.name)}" /></label><label>Subtitle <input data-field="subtitle" value="${escapeHtml(STATE.draft.subtitle)}" /></label><label>Folder <input data-field="folder" value="${escapeHtml(STATE.draft.folder)}" /></label><label>Theme Color <input data-field="themeColor" type="color" value="${escapeHtml(STATE.draft.themeColor)}" /></label><label>Icon <input data-field="icon" value="${escapeHtml(STATE.draft.icon)}" /></label><label>Archetype <input data-field="archetype" value="${escapeHtml(STATE.draft.archetype)}" /></label><label>Universe <input data-field="universe" value="${escapeHtml(STATE.draft.universe)}" /></label><label>Faction <input data-field="faction" value="${escapeHtml(STATE.draft.faction)}" /></label><label>Source Set <input data-field="sourceSet" value="${escapeHtml(STATE.draft.sourceSet)}" /></label><label>Associated Packs (csv) <input data-field="associatedPacks" value="${escapeHtml((Array.isArray(STATE.draft.associatedPacks) ? STATE.draft.associatedPacks.join(', ') : STATE.draft.associatedPacks || ''))}" /></label><label>Signature Cards (csv) <input data-field="signatureCards" value="${escapeHtml((Array.isArray(STATE.draft.signatureCards) ? STATE.draft.signatureCards.join(', ') : STATE.draft.signatureCards || ''))}" /></label><label>Notes <textarea data-field="notes" rows="3">${escapeHtml(STATE.draft.notes)}</textarea></label></section><section class="db-panel"><h3>Rules</h3><label>Preset <select data-field="rulesPreset"><option value="">Custom</option>${RULESET_PRESETS.map((preset) => `<option value="${preset.id}">${escapeHtml(preset.name)}</option>`).join('')}</select></label><label>Ruleset Name <input data-rule-field="name" value="${escapeHtml(STATE.draft.rules.name)}" /></label><div class="db-rule-row"><label>Min <input data-rule-field="minSize" type="number" min="1" max="200" value="${STATE.draft.rules.minSize}" /></label><label>Target <input data-rule-field="targetSize" type="number" min="1" max="200" value="${STATE.draft.rules.targetSize}" /></label><label>Max <input data-rule-field="maxSize" type="number" min="1" max="200" value="${STATE.draft.rules.maxSize}" /></label></div><label>Max Copies <input data-rule-field="maxCopies" type="number" min="1" max="99" value="${STATE.draft.rules.maxCopies}" /></label><label>Faction Restriction <input data-rule-field="factionRestriction" value="${escapeHtml(STATE.draft.rules.factionRestriction)}" /></label><label>Universe Restriction <input data-rule-field="universeRestriction" value="${escapeHtml(STATE.draft.rules.universeRestriction)}" /></label><label>Rarity Restriction <input data-rule-field="rarityRestriction" value="${escapeHtml(STATE.draft.rules.rarityRestriction)}" /></label></section><section class="db-panel"><h3>Deck Stats</h3><div class="db-stat-grid"><div><span>Size</span><strong>${stats.size}/${stats.rules.targetSize}</strong></div><div><span>Avg Mana</span><strong>${stats.avgCost}</strong></div><div><span>Types</span><strong>${Object.entries(stats.typeBreakdown).map(([k, v]) => `${k}:${v}`).join(' ') || 'n/a'}</strong></div><div><span>Rarity</span><strong>${Object.entries(stats.rarityBreakdown).map(([k, v]) => `${k}:${v}`).join(' ') || 'n/a'}</strong></div></div><div class="db-curve">${renderCurve()}</div>${renderWarnings()}</section><section class="db-panel"><h3>Snapshots</h3><div class="db-row-actions"><button data-action="save-snapshot">Save Snapshot</button></div><div class="db-list">${(STATE.profile.deckSnapshots?.[STATE.draft.sourceDeckId] || []).length ? (STATE.profile.deckSnapshots[STATE.draft.sourceDeckId].slice(-8).reverse().map((snap) => `<button class="db-snapshot-row" data-action="restore-snapshot" data-snapshot-id="${snap.id}">${escapeHtml(snap.label)}</button>`).join('')) : '<div class="db-empty">No snapshots yet.</div>'}</div></section></aside><section class="db-center"><section class="db-panel"><div class="db-panel-head"><h3>Deck Slots</h3><div class="db-row-actions"><button data-action="clear-deck">Clear</button><button data-action="test-deck">Test Deck</button></div></div><div class="db-refund-preview"><strong>Return-to-Inventory Preview:</strong> ${Object.keys(STATE.draft.refundPreview).length ? Object.entries(STATE.draft.refundPreview).map(([cardId, count]) => `<span class="tag-chip">${escapeHtml(STATE.cardById[cardId]?.name || cardId)} x${count}</span>`).join('') : 'No refunded cards in this draft.'}</div>${renderSlots()}</section><section class="db-panel"><h3>Import / Export / Saved Searches</h3><textarea id="db-import-export" rows="6" placeholder="Deck JSON import/export">${escapeHtml(STATE.importText)}</textarea><div class="db-row-actions"><button data-action="export-deck">Export</button><button data-action="import-deck">Import</button><button data-action="save-search">Save Search</button></div><div class="db-row-actions"><select id="db-saved-searches"><option value="">Saved searches</option>${(STATE.profile.deckSearchPresets || []).map((entry) => `<option value="${entry.id}" ${entry.id === STATE.savedSearchId ? 'selected' : ''}>${escapeHtml(entry.name)}</option>`).join('')}</select><button data-action="apply-search">Apply</button><button data-action="delete-search">Delete</button></div></section></section><aside class="db-right" data-drop-zone="inventory-return"><section class="db-panel"><div class="db-panel-head"><h3>Inventory Browser</h3><button data-action="switch-view" data-view="collection">Full Collection</button></div><div class="db-controls"><input id="db-panel-search" placeholder="Search cards, abilities, gen..." value="${escapeHtml(STATE.panelSearch)}" /><select id="db-panel-sort">${Object.entries(SORT_OPTIONS).map(([value, label]) => `<option value="${value}" ${STATE.panelSort === value ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select></div><div class="db-filter-grid">${renderFilterControls('panel', STATE.panelFilters, options)}</div><div class="db-list db-inventory-list">${renderInventory(panelCards, stats, 'compact')}</div></section></aside></div>`;

    const collectionView = `<div class="db-collection-layout"><section class="db-panel"><div class="db-panel-head"><h3>Collection</h3><div class="db-row-actions"><button data-action="switch-view" data-view="deckbuilder">Back to Deckbuilder</button><button data-action="save-search">Save Search</button></div></div><div class="db-summary-grid"><div><span>Total Owned</span><strong>${collectionCards.reduce((sum, c) => sum + c.owned, 0)}</strong></div><div><span>Unique Owned</span><strong>${collectionCards.filter((c) => c.owned > 0).length}</strong></div><div><span>Custom Cards</span><strong>${collectionCards.filter((c) => c.customMade).length}</strong></div><div><span>Locked Cards</span><strong>${collectionCards.filter((c) => c.locked).length}</strong></div><div><span>Free Copies</span><strong>${collectionCards.reduce((sum, c) => sum + c.free, 0)}</strong></div><div><span>Committed</span><strong>${collectionCards.reduce((sum, c) => sum + c.committed, 0)}</strong></div></div><div class="db-controls"><input id="db-collection-search" placeholder="Search by name, text, keyword, GEN..." value="${escapeHtml(STATE.collectionSearch)}" /><select id="db-collection-sort">${Object.entries(SORT_OPTIONS).map(([value, label]) => `<option value="${value}" ${STATE.collectionSort === value ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select><div class="db-segmented"><button data-action="collection-view" data-mode="grid" class="${STATE.collectionView === 'grid' ? 'active' : ''}">Grid</button><button data-action="collection-view" data-mode="list" class="${STATE.collectionView === 'list' ? 'active' : ''}">List</button><button data-action="collection-view" data-mode="compact" class="${STATE.collectionView === 'compact' ? 'active' : ''}">Compact</button></div></div><div class="db-filter-grid">${renderFilterControls('collection', STATE.collectionFilters, options)}</div><div class="db-row-actions"><select id="db-saved-searches"><option value="">Saved searches</option>${(STATE.profile.deckSearchPresets || []).map((entry) => `<option value="${entry.id}" ${entry.id === STATE.savedSearchId ? 'selected' : ''}>${escapeHtml(entry.name)}</option>`).join('')}</select><button data-action="apply-search">Apply</button><button data-action="delete-search">Delete</button></div><div class="db-panel-sub"><h4>Recently Created / Edited</h4><div class="db-tags">${[...collectionCards].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 8).map((card) => `<button class="tag-chip" data-action="inspect-card" data-card-id="${card.id}">${escapeHtml(card.name)} (GEN ${card.genVersion})</button>`).join('') || 'No recent cards yet.'}</div></div><div class="db-collection-results">${renderInventory(collectionCards, stats, STATE.collectionView)}</div></section></div>`;

    STATE.host.innerHTML = `<div class="db-root">${top}${STATE.view === 'collection' ? collectionView : deckView}${inspect()}</div>`;
    bindEvents();
  }

  function scheduleInputRender() {
    if (STATE.inputRenderHandle) cancelAnimationFrame(STATE.inputRenderHandle);
    STATE.inputRenderHandle = requestAnimationFrame(() => {
      STATE.inputRenderHandle = null;
      if (!STATE.host?.isConnected) return;
      scheduleInputRender();
    });
  }

  function selectDeck(deckId) {
    const deck = STATE.decks.find((entry) => entry.id === deckId);
    if (!deck) return;
    if (STATE.draft?.dirty) {
      const proceed = window.confirm('Discard unsaved changes and switch decks?');
      if (!proceed) return;
    }
    STATE.selectedDeckId = deck.id;
    STATE.draft = makeDraft(deck, deck.isBuiltIn ? 'built-in' : 'custom');
    STATE.message = `Loaded ${deck.name}.`;
  }

  function newDeck() {
    if (STATE.draft?.dirty) {
      const proceed = window.confirm('Discard unsaved draft and create a new deck?');
      if (!proceed) return;
    }
    STATE.selectedDeckId = null;
    STATE.draft = makeEmptyDraft();
    STATE.message = 'Started new empty deck.';
  }

  function useTemplate() {
    const template = STATE.decks.find((deck) => deck.id === STATE.selectedDeckId) || STATE.decks[0];
    if (!template) {
      STATE.draft = makeEmptyDraft();
      STATE.message = 'No template found. Started empty deck.';
      return;
    }
    const draft = makeDraft(template, template.isBuiltIn ? 'built-in' : 'custom');
    draft.id = `custom-${Date.now()}`;
    draft.sourceDeckId = null;
    draft.sourceType = 'new';
    draft.originalDeck = null;
    draft.name = `${template.name} Copy`;
    draft.dirty = true;
    STATE.draft = draft;
    STATE.message = `Template loaded from ${template.name}.`;
  }

  function resizeSlots(targetSize) {
    const nextSize = clamp(Math.floor(toNum(targetSize, STATE.draft.rules.targetSize)), 1, 200);
    const slots = [...STATE.draft.slots];
    if (slots.length > nextSize) slots.length = nextSize;
    while (slots.length < nextSize) slots.push(null);
    STATE.draft.slots = slots;
    STATE.draft.rules.targetSize = nextSize;
    STATE.draft.rules.minSize = Math.min(STATE.draft.rules.minSize, nextSize);
    STATE.draft.rules.maxSize = Math.max(STATE.draft.rules.maxSize, nextSize);
    STATE.draft.dirty = true;
  }

  function addCard(cardId, preferredSlot = null) {
    const card = STATE.cardById[cardId];
    if (!card) return { ok: false, message: 'Card not found.' };
    const stats = draftStats();
    const used = toNum(countMapFromSlots(STATE.draft.slots)[cardId], 0);
    const owned = Math.max(0, toNum(STATE.profile.collection?.[cardId], 0));
    const excludeDeckId = STATE.draft?.sourceType === 'custom' ? STATE.draft.sourceDeckId : null;
    let committed = 0;
    getCustomDecks().forEach((deck) => {
      if (deck.id === excludeDeckId) return;
      deck.entries.forEach((entry) => {
        if (entry.cardId === cardId) committed += toNum(entry.count, 0);
      });
    });
    const freeBeforeDraft = Math.max(0, owned - committed);
    if (used >= stats.rules.maxCopies) return { ok: false, message: `Copy cap reached (${stats.rules.maxCopies}).` };
    if (used >= freeBeforeDraft) return { ok: false, message: 'No free owned copies available.' };
    let slot = preferredSlot != null ? toNum(preferredSlot, -1) : -1;
    if (slot < 0 || slot >= STATE.draft.slots.length || STATE.draft.slots[slot]) slot = STATE.draft.slots.findIndex((entry) => !entry);
    if (slot < 0) return { ok: false, message: 'Deck is full.' };
    STATE.draft.slots[slot] = cardId;
    STATE.draft.dirty = true;
    return { ok: true, message: `Added ${card.name}.` };
  }

  function removeSlot(slotIndex) {
    const idx = toNum(slotIndex, -1);
    if (idx < 0 || idx >= STATE.draft.slots.length || !STATE.draft.slots[idx]) return { ok: false, message: 'Slot is empty.' };
    const cardId = STATE.draft.slots[idx];
    STATE.draft.slots[idx] = null;
    STATE.draft.dirty = true;
    return { ok: true, message: `Removed ${STATE.cardById[cardId]?.name || cardId}.` };
  }

  function fillCard(cardId) {
    while (true) {
      const result = addCard(cardId);
      if (!result.ok) break;
    }
  }

  function removeAllCopies(cardId) {
    STATE.draft.slots = STATE.draft.slots.map((entry) => (entry === cardId ? null : entry));
    STATE.draft.dirty = true;
  }

  function moveSlot(fromIndex, toIndex) {
    const a = toNum(fromIndex, -1);
    const b = toNum(toIndex, -1);
    if (a < 0 || b < 0 || a >= STATE.draft.slots.length || b >= STATE.draft.slots.length || a === b) return;
    const temp = STATE.draft.slots[a];
    STATE.draft.slots[a] = STATE.draft.slots[b];
    STATE.draft.slots[b] = temp;
    STATE.draft.dirty = true;
  }

  function saveDraft(saveAsNew = false) {
    const stats = draftStats();
    if (stats.size < stats.rules.minSize || stats.size > stats.rules.maxSize) {
      STATE.message = 'Deck size violates rules.';
      return;
    }
    if (Object.keys(stats.violations).length) {
      const proceed = window.confirm('Deck has copy/ownership violations. Save anyway?');
      if (!proceed) return;
    }
    const now = Date.now();
    const payload = {
      id: saveAsNew || STATE.draft.sourceType !== 'custom' ? `custom-${slug(STATE.draft.name)}-${now}` : STATE.draft.sourceDeckId || STATE.draft.id || `custom-${now}`,
      name: STATE.draft.name || 'Untitled Deck',
      subtitle: STATE.draft.subtitle || '',
      notes: STATE.draft.notes || '',
      icon: STATE.draft.icon || '◆',
      themeColor: STATE.draft.themeColor || '#6fa8ff',
      folder: STATE.draft.folder || 'Experiments',
      archetype: STATE.draft.archetype || '',
      universe: STATE.draft.universe || '',
      faction: STATE.draft.faction || '',
      sourceSet: STATE.draft.sourceSet || '',
      associatedPacks: uniq(String(STATE.draft.associatedPacks || '').split(',').map((part) => part.trim()).filter(Boolean)),
      signatureCards: uniq(String(STATE.draft.signatureCards || '').split(',').map((part) => part.trim()).filter(Boolean)),
      rules: normalizeRules(STATE.draft.rules),
      entries: slotsToEntries(STATE.draft.slots),
      createdAt: STATE.draft.originalDeck?.createdAt || now,
      updatedAt: now,
    };
    const customDecks = getCustomDecks();
    if (saveAsNew || STATE.draft.sourceType !== 'custom') customDecks.push(payload);
    else {
      const idx = customDecks.findIndex((deck) => deck.id === STATE.draft.sourceDeckId);
      if (idx >= 0) customDecks[idx] = payload;
      else customDecks.push(payload);
    }
    STATE.profile.customDecks = customDecks;
    STATE.profile.starterDeckId = payload.id;
    if (!STATE.profile.deckSnapshots[payload.id]) STATE.profile.deckSnapshots[payload.id] = [];
    STATE.profile.deckSnapshots[payload.id].push({ id: `snap-${Date.now()}`, label: `Auto Save ${new Date().toLocaleString()}`, at: Date.now(), deck: clone(payload) });
    payload.entries.forEach((entry) => { STATE.profile.cardLastUsed[entry.cardId] = Date.now(); });
    STATE.ctx.saveProfile(STATE.profile);
    refreshDecks();
    STATE.selectedDeckId = payload.id;
    STATE.draft = makeDraft(payload, 'custom');
    STATE.message = saveAsNew || STATE.draft.sourceType !== 'custom' ? `Saved new deck ${payload.name}.` : `Saved ${payload.name}.`;
  }

  function deleteDeck() {
    if (STATE.draft.sourceType !== 'custom') {
      STATE.message = 'Only custom decks can be archived.';
      return;
    }
    const ok = window.confirm(`Archive deck \"${STATE.draft.name}\"?`);
    if (!ok) return;
    const deckId = STATE.draft.sourceDeckId;
    STATE.profile.customDecks = getCustomDecks().filter((deck) => deck.id !== deckId);
    STATE.profile.archivedDeckIds = uniq([...(STATE.profile.archivedDeckIds || []), deckId]);
    STATE.ctx.saveProfile(STATE.profile);
    refreshDecks();
    const fallback = STATE.decks[0];
    STATE.selectedDeckId = fallback?.id || null;
    STATE.draft = fallback ? makeDraft(fallback, fallback.isBuiltIn ? 'built-in' : 'custom') : makeEmptyDraft();
    STATE.message = 'Deck archived.';
  }

  function bindEvents() {
    const root = STATE.host.querySelector('.db-root');
    if (!root) return;
    root.addEventListener('click', async (event) => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      const action = button.dataset.action;
      const cardId = button.dataset.cardId;

      if (action === 'switch-view') STATE.view = button.dataset.view || 'deckbuilder';
      else if (action === 'collection-view') STATE.collectionView = button.dataset.mode || 'grid';
      else if (action === 'select-deck') selectDeck(button.dataset.deckId);
      else if (action === 'new-deck') newDeck();
      else if (action === 'use-template' || action === 'duplicate-deck') useTemplate();
      else if (action === 'save-deck') saveDraft(false);
      else if (action === 'save-as-deck') saveDraft(true);
      else if (action === 'evaluate-deck') await openDeckEvaluatorFromDraft();
      else if (action === 'revert-deck') { if (STATE.draft.dirty && window.confirm('Revert unsaved changes?')) { STATE.draft = STATE.draft.originalDeck ? makeDraft(STATE.draft.originalDeck, STATE.draft.sourceType === 'custom' ? 'custom' : 'built-in') : makeEmptyDraft(); STATE.message = 'Draft reverted.'; } }
      else if (action === 'delete-deck') deleteDeck();
      else if (action === 'add-card') STATE.message = addCard(cardId).message;
      else if (action === 'remove-card') { const idx = STATE.draft.slots.findIndex((entry) => entry === cardId); STATE.message = idx >= 0 ? removeSlot(idx).message : 'No copy to remove.'; }
      else if (action === 'fill-card') { fillCard(cardId); STATE.message = `Filled ${STATE.cardById[cardId]?.name || cardId} to limits.`; }
      else if (action === 'remove-all-card') { removeAllCopies(cardId); STATE.message = `Removed all ${STATE.cardById[cardId]?.name || cardId} copies from deck.`; }
      else if (action === 'remove-slot') STATE.message = removeSlot(button.dataset.slotIndex).message;
      else if (action === 'inspect-card') STATE.inspectCardId = cardId;
      else if (action === 'close-inspect') STATE.inspectCardId = null;
      else if (action === 'set-compare') { STATE.compareCardId = cardId; STATE.message = `Compare anchor set to ${STATE.cardById[cardId]?.name || cardId}.`; }
      else if (action === 'toggle-favorite') { const f = new Set(STATE.profile.favoriteCards || []); if (f.has(cardId)) f.delete(cardId); else f.add(cardId); STATE.profile.favoriteCards = [...f]; STATE.ctx.saveProfile(STATE.profile); }
      else if (action === 'clear-deck') { STATE.draft.slots = STATE.draft.slots.map(() => null); STATE.draft.dirty = true; STATE.message = 'Deck cleared.'; }
      else if (action === 'save-snapshot') { const id = STATE.draft.sourceType === 'custom' ? STATE.draft.sourceDeckId : STATE.draft.id; if (id) { if (!STATE.profile.deckSnapshots[id]) STATE.profile.deckSnapshots[id] = []; const label = window.prompt('Snapshot label:', `Snapshot ${new Date().toLocaleString()}`) || `Snapshot ${new Date().toLocaleString()}`; STATE.profile.deckSnapshots[id].push({ id: `snap-${Date.now()}`, label, at: Date.now(), deck: { ...clone(STATE.draft), entries: slotsToEntries(STATE.draft.slots) } }); STATE.ctx.saveProfile(STATE.profile); STATE.message = 'Snapshot saved.'; } }
      else if (action === 'restore-snapshot') { const id = STATE.draft.sourceType === 'custom' ? STATE.draft.sourceDeckId : STATE.draft.id; const snap = (STATE.profile.deckSnapshots?.[id] || []).find((x) => x.id === button.dataset.snapshotId); if (snap) { const deck = snap.deck || {}; const rules = normalizeRules(deck.rules || STATE.draft.rules); STATE.draft = { ...STATE.draft, ...deck, rules, slots: entriesToSlots(deck.entries || slotsToEntries(deck.slots || []), rules.targetSize), dirty: true }; STATE.message = `Restored snapshot \"${snap.label}\".`; } }
      else if (action === 'export-deck') { const textarea = root.querySelector('#db-import-export'); if (textarea) { textarea.value = JSON.stringify({ ...STATE.draft, entries: slotsToEntries(STATE.draft.slots), exportedAt: new Date().toISOString() }, null, 2); STATE.importText = textarea.value; } STATE.message = 'Deck exported.'; }
      else if (action === 'import-deck') { const textarea = root.querySelector('#db-import-export'); const parsed = safeParse(textarea?.value || '', null); if (!parsed) STATE.message = 'Invalid deck JSON.'; else { const rules = normalizeRules(parsed.rules || parsed.ruleset || DEFAULT_RULESET); const entries = Array.isArray(parsed.entries) ? parsed.entries : slotsToEntries(Array.isArray(parsed.slots) ? parsed.slots : []); STATE.draft = { ...makeEmptyDraft(), ...parsed, name: String(parsed.name || 'Imported Deck'), rules, slots: entriesToSlots(entries, rules.targetSize), sourceType: 'new', sourceDeckId: null, originalDeck: null, dirty: true }; STATE.message = `Imported deck \"${STATE.draft.name}\".`; } }
      else if (action === 'save-search') { const name = window.prompt('Saved search name?'); if (name?.trim()) { const fromPanel = STATE.view !== 'collection'; const preset = { id: `search-${slug(name)}-${Date.now()}`, name: name.trim(), fromPanel, query: fromPanel ? STATE.panelSearch : STATE.collectionSearch, filters: clone(fromPanel ? STATE.panelFilters : STATE.collectionFilters), sort: fromPanel ? STATE.panelSort : STATE.collectionSort, view: STATE.collectionView }; STATE.profile.deckSearchPresets.push(preset); STATE.ctx.saveProfile(STATE.profile); STATE.message = `Saved search \"${preset.name}\".`; } }
      else if (action === 'apply-search') { const select = root.querySelector('#db-saved-searches'); const preset = (STATE.profile.deckSearchPresets || []).find((x) => x.id === select?.value); if (preset) { if (preset.fromPanel) { STATE.view = 'deckbuilder'; STATE.panelSearch = preset.query || ''; STATE.panelFilters = { ...STATE.panelFilters, ...(preset.filters || {}) }; STATE.panelSort = preset.sort || 'alphabetical'; } else { STATE.view = 'collection'; STATE.collectionSearch = preset.query || ''; STATE.collectionFilters = { ...STATE.collectionFilters, ...(preset.filters || {}) }; STATE.collectionSort = preset.sort || 'alphabetical'; STATE.collectionView = preset.view || 'grid'; } STATE.savedSearchId = preset.id; } }
      else if (action === 'delete-search') { const select = root.querySelector('#db-saved-searches'); if (select?.value) { STATE.profile.deckSearchPresets = (STATE.profile.deckSearchPresets || []).filter((x) => x.id !== select.value); if (STATE.savedSearchId === select.value) STATE.savedSearchId = ''; STATE.ctx.saveProfile(STATE.profile); STATE.message = 'Saved search removed.'; } }
      else if (action === 'test-deck') { if (STATE.draft.dirty && window.confirm('Draft has unsaved changes. Save before test?')) saveDraft(STATE.draft.sourceType !== 'custom'); if (STATE.draft.sourceType === 'custom') { STATE.profile.starterDeckId = STATE.draft.sourceDeckId; STATE.ctx.saveProfile(STATE.profile); } window.location.assign('./game/index.html'); return; }
      render();
    });

    root.addEventListener('change', (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches('#db-panel-sort')) STATE.panelSort = target.value;
      else if (target.matches('#db-collection-sort')) STATE.collectionSort = target.value;
      else if (target.matches('[data-panel-filter]')) STATE.panelFilters[target.dataset.panelFilter] = target.value;
      else if (target.matches('[data-collection-filter]')) STATE.collectionFilters[target.dataset.collectionFilter] = target.value;
      else if (target.matches('[data-field]')) { const field = target.dataset.field; if (field === 'rulesPreset') { const preset = RULESET_PRESETS.find((x) => x.id === target.value); if (preset) { STATE.draft.rules = normalizeRules({ ...STATE.draft.rules, ...preset, name: preset.name }); resizeSlots(STATE.draft.rules.targetSize); } } else { STATE.draft[field] = target.value; STATE.draft.dirty = true; } }
      else if (target.matches('[data-rule-field]')) { const field = target.dataset.ruleField; if (['minSize', 'targetSize', 'maxSize', 'maxCopies'].includes(field)) STATE.draft.rules[field] = Math.floor(toNum(target.value, STATE.draft.rules[field])); else STATE.draft.rules[field] = target.value; STATE.draft.rules = normalizeRules(STATE.draft.rules); if (field === 'targetSize') resizeSlots(STATE.draft.rules.targetSize); else STATE.draft.dirty = true; }
      scheduleInputRender();
    });

    root.addEventListener('input', (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches('#db-panel-search')) STATE.panelSearch = target.value;
      else if (target.matches('#db-collection-search')) STATE.collectionSearch = target.value;
      else if (target.matches('#db-import-export')) STATE.importText = target.value;
      else return;
      scheduleInputRender();
    });

    root.addEventListener('contextmenu', (event) => {
      const node = event.target.closest('[data-card-id], .db-slot-card');
      if (!node) return;
      const cardId = node.dataset.cardId;
      if (!cardId) return;
      event.preventDefault();
      STATE.inspectCardId = cardId;
      render();
    });

    root.addEventListener('pointerdown', (event) => {
      if (event.button !== 0) return;
      setGlobalLeftHold(true);
    });
    const releasePointerHold = () => {
      setGlobalLeftHold(false);
      setGlobalDragActive(false);
      clearDragTargets();
    };
    root.addEventListener('pointerup', releasePointerHold);
    root.addEventListener('pointercancel', releasePointerHold);
    root.addEventListener('mouseleave', (event) => {
      if ((event.buttons & 1) === 0) releasePointerHold();
    });

    root.addEventListener('dragstart', (event) => {
      const node = event.target.closest('[data-drag-type]');
      if (!node) return;
      const dragType = node.dataset.dragType;
      STATE.dragPayload = dragType === 'inventory-card'
        ? { type: 'inventory-card', cardId: node.dataset.cardId }
        : { type: 'slot-card', cardId: node.dataset.cardId, slotIndex: node.dataset.slotIndex };
      event.dataTransfer.effectAllowed = 'copyMove';
      event.dataTransfer.setData('text/plain', JSON.stringify(STATE.dragPayload));
      setGlobalLeftHold(true);
      setGlobalDragActive(true);
    });

    root.addEventListener('dragover', (event) => {
      const slot = event.target.closest('[data-slot-index]');
      const inventoryReturn = event.target.closest('[data-drop-zone="inventory-return"]');
      if (!slot && !inventoryReturn) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'copy';
      clearDragTargets();
      (slot || inventoryReturn)?.classList.add('drag-target');
    });

    root.addEventListener('drop', (event) => {
      const slot = event.target.closest('[data-slot-index]');
      const inventoryReturn = event.target.closest('[data-drop-zone="inventory-return"]');
      if (!slot && !inventoryReturn) return;
      event.preventDefault();
      let payload = STATE.dragPayload;
      if (!payload) payload = safeParse(event.dataTransfer.getData('text/plain'), null);
      if (!payload) return;
      if (slot) {
        const index = Number(slot.dataset.slotIndex);
        if (payload.type === 'inventory-card') STATE.message = addCard(payload.cardId, index).message;
        else if (payload.type === 'slot-card') { moveSlot(payload.slotIndex, index); STATE.message = 'Card reordered.'; }
      } else if (inventoryReturn && payload.type === 'slot-card') {
        STATE.message = removeSlot(payload.slotIndex).message;
      }
      STATE.dragPayload = null;
      clearDragTargets();
      setGlobalDragActive(false);
      render();
    });

    root.addEventListener('dragend', () => {
      STATE.dragPayload = null;
      clearDragTargets();
      setGlobalLeftHold(false);
      setGlobalDragActive(false);
    });

    root.querySelectorAll('.db-card-row,.db-card-tile').forEach((node) => {
      node.addEventListener('dblclick', () => {
        const cardId = node.dataset.cardId;
        STATE.message = addCard(cardId).message;
        render();
      });
    });
  }

  async function initialize(ctx) {
    STATE.ctx = ctx;
    STATE.host = ctx.host;
    STATE.profile = ctx.loadProfile();
    ensureProfileFields(STATE.profile);
    const catalog = await loadCardCatalog(ctx);
    STATE.cards = catalog.cards;
    STATE.cardById = catalog.byId;
    refreshDecks();
    if (!STATE.draft) {
      const selected = STATE.decks.find((deck) => deck.id === STATE.selectedDeckId) || STATE.decks[0];
      STATE.selectedDeckId = selected?.id || null;
      STATE.draft = selected ? makeDraft(selected, selected.isBuiltIn ? 'built-in' : 'custom') : makeEmptyDraft();
    }
  }

  window.renderDeckTabOverhaul = async function renderDeckTabOverhaul(ctx) {
    await initialize(ctx);
    STATE.profile = ctx.loadProfile();
    ensureProfileFields(STATE.profile);
    refreshDecks();
    const customCount = Object.keys(readStorage(CUSTOM_CARD_LIBRARY_KEY, {})).length;
    const loadedCustomCount = STATE.cards.filter((card) => card.customMade).length;
    if (customCount !== loadedCustomCount) {
      const catalog = await loadCardCatalog(ctx);
      STATE.cards = catalog.cards;
      STATE.cardById = catalog.byId;
    }
    render();
  };

  window.addEventListener('cardforge:deck-rater-updated', () => {
    if (!STATE.host?.isConnected) return;
    render();
  });
})();
