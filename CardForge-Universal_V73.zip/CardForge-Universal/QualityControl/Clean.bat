@echo off
setlocal EnableExtensions DisableDelayedExpansion

if defined QC_PROJECT_ROOT (
  set "PROJECT_ROOT=%QC_PROJECT_ROOT%"
) else (
  for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"
)
for %%I in ("%PROJECT_ROOT%") do set "PROJECT_NAME=%%~nxI"
if defined QC_STASH_ROOT (
  set "STASH_ROOT=%QC_STASH_ROOT%"
) else (
  set "STASH_ROOT=%USERPROFILE%\Downloads\CardForge_QC_Stash\%PROJECT_NAME%"
)
set "MANIFEST=%~dp0clean_manifest.txt"

if exist "%MANIFEST%" del /q "%MANIFEST%"
if not exist "%STASH_ROOT%" mkdir "%STASH_ROOT%"

call :move_relative "node_modules"
call :move_relative "output"
call :move_relative "playwright-report"
call :move_relative "test-results"
call :move_relative ".playwright"
call :move_relative ".playwright-artifacts"

for /d /r "%PROJECT_ROOT%" %%D in (__pycache__) do call :move_absolute "%%~fD"
for /d /r "%PROJECT_ROOT%" %%D in (.pytest_cache) do call :move_absolute "%%~fD"

if exist "%MANIFEST%" (
  echo [clean] Moved cleanup targets to "%STASH_ROOT%".
  echo [clean] Run QualityControl\Restore.bat to bring them back.
) else (
  echo [clean] Nothing matched the cleanup list.
)
exit /b 0

:move_relative
if exist "%PROJECT_ROOT%\%~1" call :move_absolute "%PROJECT_ROOT%\%~1"
exit /b 0

:move_absolute
set "SOURCE=%~f1"
call set "REL=%%SOURCE:%PROJECT_ROOT%\=%%"
if "%REL%"=="%SOURCE%" exit /b 0
set "DEST=%STASH_ROOT%\%REL%"
for %%I in ("%DEST%") do if not exist "%%~dpI" mkdir "%%~dpI"
echo [clean] moving "%REL%"
move "%SOURCE%" "%DEST%" >nul
if not errorlevel 1 >> "%MANIFEST%" echo %REL%
exit /b 0
