@echo off
setlocal EnableExtensions EnableDelayedExpansion

if defined QC_PROJECT_ROOT (
  set "PROJECT_ROOT=%QC_PROJECT_ROOT%"
) else (
  for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"
)
set "ZIP_NAME="
set /p "ZIP_NAME=Release zip name: "
if not defined ZIP_NAME set "ZIP_NAME=CardForge-Release"

for %%C in (\ / : * ? ^" ^< ^> ^|) do set "ZIP_NAME=!ZIP_NAME:%%~C=_!"
if defined QC_ZIP_OUTPUT_DIR (
  set "ZIP_PATH=%QC_ZIP_OUTPUT_DIR%\%ZIP_NAME%.zip"
) else (
  set "ZIP_PATH=%USERPROFILE%\Downloads\%ZIP_NAME%.zip"
)

if exist "%ZIP_PATH%" del /q "%ZIP_PATH%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$dest=$env:ZIP_PATH; $src=$env:PROJECT_ROOT; Compress-Archive -Path (Join-Path $src '*') -DestinationPath $dest -Force"

if exist "%ZIP_PATH%" (
  echo [version] Created "%ZIP_PATH%"
) else (
  echo [version] Failed to create release zip.
  exit /b 1
)
exit /b 0
