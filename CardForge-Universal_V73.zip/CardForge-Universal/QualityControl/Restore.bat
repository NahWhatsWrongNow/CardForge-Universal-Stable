@echo off
setlocal EnableExtensions DisableDelayedExpansion

if defined QC_PROJECT_ROOT (
  set "PROJECT_ROOT=%QC_PROJECT_ROOT%"
) else (
  for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"
)
for %%I in ("%PROJECT_ROOT%") do set "PROJECT_NAME=%%~nxI"
if defined QC_STASH_ROOT (
  set "STASH_ROOT=%QC_STASH_ROOT%"
) else (
  set "STASH_ROOT=%USERPROFILE%\Downloads\CardForge_QC_Stash\%PROJECT_NAME%"
)
set "MANIFEST=%~dp0clean_manifest.txt"

if not exist "%MANIFEST%" (
  echo [restore] No cleanup manifest found at "%MANIFEST%".
  exit /b 0
)

for /f "usebackq delims=" %%R in ("%MANIFEST%") do call :restore_relative "%%R"
del /q "%MANIFEST%" >nul 2>nul
echo [restore] Restore pass completed.
exit /b 0

:restore_relative
set "REL=%~1"
set "SOURCE=%STASH_ROOT%\%REL%"
set "DEST=%PROJECT_ROOT%\%REL%"
if not exist "%SOURCE%" (
  echo [restore] missing "%REL%" in stash, skipping.
  exit /b 0
)
if exist "%DEST%" (
  echo [restore] destination already exists for "%REL%", skipping.
  exit /b 0
)
for %%I in ("%DEST%") do if not exist "%%~dpI" mkdir "%%~dpI"
echo [restore] restoring "%REL%"
move "%SOURCE%" "%DEST%" >nul
exit /b 0
