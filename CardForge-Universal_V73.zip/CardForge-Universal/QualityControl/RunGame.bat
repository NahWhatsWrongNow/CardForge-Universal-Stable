@echo off
setlocal EnableExtensions EnableDelayedExpansion

if defined QC_PROJECT_ROOT (
  set "PROJECT_ROOT=%QC_PROJECT_ROOT%"
) else (
  for %%I in ("%~dp0..") do set "PROJECT_ROOT=%%~fI"
)
set "CF_URL=http://localhost:8080/"
if /I "%~1"=="game" set "CF_URL=http://localhost:8080/game/"
if /I "%~1"=="launcher" set "CF_URL=http://localhost:8080/"

call :resolve_python
if not defined CF_PYTHON (
  echo [startup] Unable to locate a working Python interpreter.
  echo [startup] Tried PATH, user-scope install, and common Anaconda/Miniconda locations.
  pause
  exit /b 1
)

cd /d "%PROJECT_ROOT%"
echo [python] using "%CF_PYTHON%"
echo [update_cardex] rebuilding card index...
"%CF_PYTHON%" tools\update_cardex.py
if errorlevel 1 (
  echo [update_cardex] warning: rebuild failed, continuing with existing cardex.
)

echo Starting CardForge on %CF_URL%
if /I not "%QC_SKIP_BROWSER%"=="1" start "" "%CF_PYTHON%" -c "import time,webbrowser; time.sleep(1.0); webbrowser.open(r'%CF_URL%')"
"%CF_PYTHON%" -u -m http.server 8080
exit /b %ERRORLEVEL%

:resolve_python
call :try_path_python
if defined CF_PYTHON exit /b 0

echo [startup] Python was not found on PATH. Trying user-scope install...
call :install_python_user
call :try_path_python
if defined CF_PYTHON exit /b 0
call :try_common_python_installs
if defined CF_PYTHON exit /b 0

echo [startup] User install did not succeed. Checking common Anaconda paths...
call :try_anaconda_python
exit /b 0

:try_path_python
for /f "delims=" %%P in ('where python.exe 2^>nul') do (
  call :verify_python "%%~fP"
  if defined CF_PYTHON exit /b 0
)
exit /b 0

:try_common_python_installs
for %%P in (
  "%LocalAppData%\Programs\Python\Python314\python.exe"
  "%LocalAppData%\Programs\Python\Python313\python.exe"
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%LocalAppData%\Programs\Python\Python311\python.exe"
) do (
  call :verify_python "%%~fP"
  if defined CF_PYTHON exit /b 0
)
exit /b 0

:try_anaconda_python
for %%P in (
  "%UserProfile%\anaconda3\python.exe"
  "%UserProfile%\miniconda3\python.exe"
  "%LocalAppData%\anaconda3\python.exe"
  "%LocalAppData%\miniconda3\python.exe"
  "%ProgramData%\Anaconda3\python.exe"
  "%ProgramData%\Miniconda3\python.exe"
  "C:\Anaconda3\python.exe"
  "C:\Miniconda3\python.exe"
) do (
  call :verify_python "%%~fP"
  if defined CF_PYTHON exit /b 0
)
exit /b 0

:verify_python
set "CANDIDATE=%~f1"
if not exist "%CANDIDATE%" exit /b 0
"%CANDIDATE%" -c "import sys" >nul 2>nul
if errorlevel 1 exit /b 0
set "CF_PYTHON=%CANDIDATE%"
exit /b 0

:install_python_user
set "PYTHON_BOOTSTRAP=%TEMP%\cardforge-python-user-installer.exe"
where winget.exe >nul 2>nul
if not errorlevel 1 (
  winget install --id Python.Python.3.12 --scope user --silent --disable-interactivity --accept-package-agreements --accept-source-agreements >nul 2>nul
)
call :try_common_python_installs
if defined CF_PYTHON exit /b 0

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe' -OutFile '%PYTHON_BOOTSTRAP%' } catch { exit 1 }" >nul 2>nul
if exist "%PYTHON_BOOTSTRAP%" (
  "%PYTHON_BOOTSTRAP%" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=0 Shortcuts=0 >nul 2>nul
)
call :try_common_python_installs
exit /b 0
