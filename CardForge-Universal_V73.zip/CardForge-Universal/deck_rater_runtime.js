(function () {
  const PROFILE_KEY = 'cardforge.profile.v1';
  const STORE_KEY = 'cardforge.deckrater.v1';
  const CUSTOM_CARD_LIBRARY_KEY = 'cardforge.creator.customCards.v1';
  const ENGINE_VERSION = 'oracle-rater-2026.03.v1';
  const DECK_EVALUATION_COST = 30;
  const CARD_EVALUATION_COST = 10;
  const DEFAULT_MIN_MS = 75000;
  const DEFAULT_CARD_MIN_MS = 14000;
  const FAST_MIN_MS = 4000;
  const FAST_CARD_MIN_MS = 1800;
  const DEFAULT_SAMPLES = {
    opening: 2200,
    flood: 600,
    gauntlet: 18,
    refinement: 8,
  };
  const FAST_SAMPLES = {
    opening: 220,
    flood: 80,
    gauntlet: 5,
    refinement: 2,
  };

  const PERSONAS = [
    {
      id: 'arbiter',
      name: 'The Arbiter',
      icon: '⚖️',
      tone: 'formal',
      theme: 'linear-gradient(145deg, rgba(204, 224, 255, 0.28), rgba(18, 32, 58, 0.9))',
      chips: ['Neutral', 'Clinical', 'Balanced'],
      preview: 'I will separate structural strength from wishful thinking.',
      lines: {
        intro: ['Present the list. I will judge it on discipline, not reputation.'],
        intake: ['Cataloguing curve, role spread, and legal scope.', 'I am verifying that the deck identity is real, not merely claimed.'],
        curve: ['The mana profile is revealing its first fault lines.', 'Curve health is acceptable only when it survives bad draws as well.'],
        draw: ['Consistency is never cosmetic. I am measuring how often the plan actually appears.'],
        cohesion: ['Packages are separating into coherent engines and stranded cargo.'],
        matchup: ['Benchmark gauntlet underway. I care about stability, not isolated spikes.'],
        multiplayer: ['Now testing whether the list survives shared-board pressure instead of folding to attention.'],
        validate: ['Anti-cheese moderation active. Inflated stats will not rescue weak infrastructure.'],
        high: ['This list is structured with unusual restraint.'],
        low: ['The surface is stronger than the foundation.'],
        finish: ['Judgement complete. The numbers are earned.'],
        changed: ['The deck has changed. Prior certification is void.'],
      },
    },
    {
      id: 'scholar',
      name: 'The Scholar',
      icon: '📘',
      tone: 'analytical',
      theme: 'linear-gradient(145deg, rgba(145, 196, 255, 0.28), rgba(18, 38, 74, 0.9))',
      chips: ['Analytical', 'Educational', 'Measured'],
      preview: 'I will explain the structure while I grade it.',
      lines: {
        intro: ['Let us inspect the list carefully. Strong decks usually announce their logic early.'],
        intake: ['Recording role tags, card families, and structural intent.'],
        curve: ['A curve is less about average cost than about which turns remain alive.'],
        draw: ['Sampling openers and mulligans now. The first four turns decide more than players admit.'],
        cohesion: ['I am mapping functional packages and isolating unsupported cards.'],
        matchup: ['Running comparative trials into standard pressure shells.'],
        multiplayer: ['Shared-device formats punish selfish sequencing. I am weighting that now.'],
        validate: ['Verifying that theoretical combos are also probabilistic realities.'],
        high: ['There is genuine internal harmony here.'],
        low: ['Several cards read well alone but not together.'],
        finish: ['Review complete. I have annotated the list rather than merely scoring it.'],
        changed: ['Structural changes detected. Re-analysis required.'],
      },
    },
    {
      id: 'warlord',
      name: 'The Warlord',
      icon: '🛡️',
      tone: 'tactical',
      theme: 'linear-gradient(145deg, rgba(250, 193, 139, 0.24), rgba(63, 27, 15, 0.92))',
      chips: ['Pressure', 'Discipline', 'Battlefield'],
      preview: 'I rate lists by battlefield pressure and failure under fire.',
      lines: {
        intro: ['Bring it forward. I want to see whether it marches or just poses.'],
        intake: ['Checking curve discipline, pressure cadence, and recovery stores.'],
        curve: ['Early deployment windows are decisive. Miss too many and you lose initiative.'],
        draw: ['Testing whether the hand feeds the next order on time.'],
        cohesion: ['Your support chain is either a supply line or dead weight.'],
        matchup: ['Gauntlet running. I am measuring battlefield conversion, not theory.'],
        multiplayer: ['Team and free-for-all pressure demand different restraint.'],
        validate: ['Punishing over-specialized lines now. A deck must survive resistance.'],
        high: ['This list understands tempo and respects ammunition.'],
        low: ['It overpromises before it secures the board.'],
        finish: ['Campaign review complete.'],
        changed: ['Orders changed. Previous rating is no longer current.'],
      },
    },
    {
      id: 'oracle',
      name: 'The Oracle',
      icon: '🔮',
      tone: 'predictive',
      theme: 'linear-gradient(145deg, rgba(180, 161, 255, 0.28), rgba(29, 17, 59, 0.92))',
      chips: ['Predictive', 'Calm', 'Future Lines'],
      preview: 'I care about the turns you cannot yet see.',
      lines: {
        intro: ['Let the pattern settle. I will look beyond the first answer.'],
        intake: ['Reading intent, inevitability, and concealed risk.'],
        curve: ['Heavy openings leave shadows later. I am measuring those shadows.'],
        draw: ['Sampling when your key sequences appear, and when they do not.'],
        cohesion: ['Future turn trees depend on whether these clusters actually connect.'],
        matchup: ['Testing into adaptive opposition. Prediction without resistance is vanity.'],
        multiplayer: ['Free-for-all punishes obvious power. I am pricing perception as well as force.'],
        validate: ['Filtering out lucky lines and preserving the reliable futures only.'],
        high: ['The deck sees several turns ahead without collapsing in the present.'],
        low: ['Its strongest future is too conditional.'],
        finish: ['The likely futures are now charted.'],
        changed: ['The pattern shifted. A fresh reading is required.'],
      },
    },
    {
      id: 'alchemist',
      name: 'The Alchemist',
      icon: '⚗️',
      tone: 'technical',
      theme: 'linear-gradient(145deg, rgba(141, 255, 220, 0.24), rgba(13, 52, 45, 0.92))',
      chips: ['Synergy', 'Experimental', 'Combo'],
      preview: 'I look for reactions, catalysts, and wasted reagents.',
      lines: {
        intro: ['Set the formula on the table. We will see which reactions are stable.'],
        intake: ['Identifying catalysts, payloads, and dead intermediates.'],
        curve: ['Even combo decks need respectable ignition points.'],
        draw: ['Checking assembly probability and reagent density.'],
        cohesion: ['Cohesion graphing underway. Unsupported packages will precipitate out.'],
        matchup: ['Now testing whether the engine survives disturbance.'],
        multiplayer: ['Some reactions scale upward in multiplayer. Others simply implode faster.'],
        validate: ['Latent synergy verification underway. Theory alone does not earn points.'],
        high: ['The engine is cleaner than I expected.'],
        low: ['Too many components, not enough conversion.'],
        finish: ['Reaction profile complete.'],
        changed: ['The mixture has changed. Prior notes are contaminated.'],
      },
    },
    {
      id: 'executioner',
      name: 'The Executioner',
      icon: '🗡️',
      tone: 'sharp',
      theme: 'linear-gradient(145deg, rgba(255, 160, 160, 0.24), rgba(65, 18, 24, 0.94))',
      chips: ['Punish', 'Removal', 'Kill Speed'],
      preview: 'I rate whether the deck can punish mistakes and close games cleanly.',
      lines: {
        intro: ['Show me how it kills, and how it survives being denied that kill.'],
        intake: ['Checking punish windows, kill speed, and answer density.'],
        curve: ['Slow starts invite execution.'],
        draw: ['Testing how often the deck actually finds its blade.'],
        cohesion: ['Identifying whether your pressure cards are backed by real support.'],
        matchup: ['Benchmark kills and stabilization races are underway.'],
        multiplayer: ['Shared tables reward precision only if the deck survives retaliation.'],
        validate: ['Highroll inflation is being removed from the sentence.'],
        high: ['Efficient. Ruthless. Difficult to trap.'],
        low: ['It threatens more than it converts.'],
        finish: ['Sentence delivered.'],
        changed: ['The weapon changed. Reassessing edge and reach.'],
      },
    },
    {
      id: 'curator',
      name: 'The Curator',
      icon: '🗃️',
      tone: 'archival',
      theme: 'linear-gradient(145deg, rgba(221, 208, 173, 0.24), rgba(54, 40, 26, 0.94))',
      chips: ['Identity', 'Structure', 'Measured'],
      preview: 'I value deck identity, role coverage, and durable structure.',
      lines: {
        intro: ['Archive opened. I am looking for a list that knows what it is.'],
        intake: ['Cataloguing curve, rarity spread, support packages, and redundancies.'],
        curve: ['Structure is strongest when its lower shelves are not empty.'],
        draw: ['Consistency review underway.'],
        cohesion: ['I am separating the curated package from the clutter.'],
        matchup: ['Context matters. A list belongs to an environment, not a vacuum.'],
        multiplayer: ['Format suitability is now being indexed.'],
        validate: ['Overfit and novelty inflation are being filtered out.'],
        high: ['The deck has a coherent archive signature.'],
        low: ['Its identity frays under scrutiny.'],
        finish: ['Catalog entry complete.'],
        changed: ['Archive delta detected. Prior stamp retired.'],
      },
    },
    {
      id: 'starcaller',
      name: 'The Starcaller',
      icon: '✨',
      tone: 'serene',
      theme: 'linear-gradient(145deg, rgba(205, 214, 255, 0.26), rgba(27, 34, 79, 0.94))',
      chips: ['Flow', 'Harmony', 'Timing'],
      preview: 'I care about flow, timing, and the deck’s skill ceiling.',
      lines: {
        intro: ['Let the list breathe. I am listening for rhythm.'],
        intake: ['Assessing flow, cadence, and timing windows.'],
        curve: ['The curve should feel like motion, not friction.'],
        draw: ['Tracing how often the deck finds graceful sequences.'],
        cohesion: ['Some decks are piles of power. Better decks move like constellations.'],
        matchup: ['Testing whether the flow survives interference.'],
        multiplayer: ['Multiplayer requires a slower, steadier pulse.'],
        validate: ['Removing the lines that only look elegant when uncontested.'],
        high: ['The list has unusual poise.'],
        low: ['Its rhythm breaks too easily.'],
        finish: ['The constellation is charted.'],
        changed: ['The pattern drifted. I must read it again.'],
      },
    },
    {
      id: 'quartermaster',
      name: 'The Quartermaster',
      icon: '📊',
      tone: 'logistical',
      theme: 'linear-gradient(145deg, rgba(170, 227, 255, 0.24), rgba(13, 46, 63, 0.94))',
      chips: ['Numbers', 'Consistency', 'Efficiency'],
      preview: 'I trust reproducibility, not sentiment.',
      lines: {
        intro: ['Inventory received. I will audit efficiency, redundancy, and wastage.'],
        intake: ['Logging counts, distributions, and effective coverage.'],
        curve: ['The curve is a supply chain. Break the early nodes and the whole list stalls.'],
        draw: ['Sampling opening inventories and replacement quality.'],
        cohesion: ['Cluster weights are forming. Unsupported cargo will be flagged.'],
        matchup: ['Gauntlet throughput review in progress.'],
        multiplayer: ['Now auditing ally utility and sustained board demands.'],
        validate: ['Volatility and sample confidence are being normalized.'],
        high: ['Operational efficiency is excellent.'],
        low: ['Too much cargo, not enough delivery.'],
        finish: ['Audit complete.'],
        changed: ['Loadout changed. All prior logistics marks are stale.'],
      },
    },
    {
      id: 'mirror',
      name: 'The Mirror',
      icon: '🪞',
      tone: 'reflective',
      theme: 'linear-gradient(145deg, rgba(231, 216, 255, 0.24), rgba(34, 25, 58, 0.94))',
      chips: ['Psychology', 'Exposure', 'Counterplay'],
      preview: 'I rate how opponents will read you, fear you, and exploit you.',
      lines: {
        intro: ['I am less interested in what you believe the deck does than in what it reveals.'],
        intake: ['Reading pressure signals, visible tells, and exploitable seams.'],
        curve: ['Early stumbles tell opponents how greedy you are.'],
        draw: ['Testing how often your hand exposes your plan too early.'],
        cohesion: ['Strong clusters are useful; obvious ones are punishable.'],
        matchup: ['Counterplay pressure applied. Let us see what survives being understood.'],
        multiplayer: ['Threat perception is part of the format. This deck announces itself loudly.'],
        validate: ['Now separating earned power from exploitable posture.'],
        high: ['Difficult to read cleanly. That matters.'],
        low: ['A competent opponent will smell the seams quickly.'],
        finish: ['Reflection complete.'],
        changed: ['The reflection shifted. Reassessing tells and punish points.'],
      },
    },
  ];

  const PERSONA_BY_ID = Object.fromEntries(PERSONAS.map((entry) => [entry.id, entry]));
  const BENCHMARKS = [
    { id: 'aggro', name: 'Aggro Baseline', traits: { tempo: 82, burst: 74, consistency: 68, sustain: 22, control: 20, inevitability: 18, swarm: 45, multiplayer: 35 } },
    { id: 'midrange', name: 'Midrange Baseline', traits: { tempo: 58, burst: 44, consistency: 62, sustain: 42, control: 48, inevitability: 46, swarm: 22, multiplayer: 44 } },
    { id: 'control', name: 'Control Baseline', traits: { tempo: 24, burst: 28, consistency: 60, sustain: 64, control: 82, inevitability: 78, swarm: 10, multiplayer: 58 } },
    { id: 'combo', name: 'Combo Baseline', traits: { tempo: 30, burst: 86, consistency: 46, sustain: 22, control: 26, inevitability: 68, swarm: 8, multiplayer: 30 } },
    { id: 'relic', name: 'Relic/Engine Baseline', traits: { tempo: 28, burst: 34, consistency: 58, sustain: 48, control: 46, inevitability: 72, swarm: 10, multiplayer: 54 } },
    { id: 'tribal', name: 'Tribal Baseline', traits: { tempo: 52, burst: 42, consistency: 54, sustain: 32, control: 28, inevitability: 42, swarm: 54, multiplayer: 42 } },
    { id: 'antiswarm', name: 'Anti-Swarm Baseline', traits: { tempo: 36, burst: 30, consistency: 62, sustain: 44, control: 78, inevitability: 48, swarm: 6, multiplayer: 52 } },
    { id: 'topend', name: 'Heavy Top-End Baseline', traits: { tempo: 18, burst: 54, consistency: 36, sustain: 52, control: 34, inevitability: 88, swarm: 8, multiplayer: 56 } },
    { id: 'politics', name: 'Multiplayer Politics Baseline', traits: { tempo: 36, burst: 30, consistency: 56, sustain: 58, control: 46, inevitability: 64, swarm: 18, multiplayer: 82 } },
    { id: 'teamplay', name: 'Team Synergy Baseline', traits: { tempo: 42, burst: 34, consistency: 60, sustain: 54, control: 52, inevitability: 56, swarm: 20, multiplayer: 72 } },
  ];
  const BENCHMARK_TIERS = [
    { id: 'basic', label: 'Basic', bonus: -8 },
    { id: 'refined', label: 'Refined', bonus: 0 },
    { id: 'optimized', label: 'Optimized', bonus: 8 },
    { id: 'hostile', label: 'Hostile', bonus: 15 },
  ];
  const TYPE_ALIASES = {
    sorcery: 'spell',
    spell: 'spell',
    aura: 'field',
    relic: 'relic',
    field: 'field',
    minion: 'minion',
    creature: 'minion',
    structure: 'relic',
    minioncard: 'minion',
  };
  const RARITY_RANK = { common: 1, rare: 2, epic: 3, legendary: 4 };
  const GLOBAL = {
    catalogPromise: null,
    catalog: null,
    deckCatalogPromise: null,
    deckCatalog: null,
    ui: null,
  };

  function rootPrefix() {
    const path = String(window.location?.pathname || '').replace(/\\/g, '/').toLowerCase();
    if (path.includes('/creator/') || path.includes('/game/')) return '..';
    return '.';
  }

  function resolvePath(path) {
    return `${rootPrefix()}/${String(path).replace(/^\.\//, '')}`;
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>\"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;' }[char]));
  }

  function sleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function toNumber(value, fallback = 0) {
    const num = Number(value);
    return Number.isFinite(num) ? num : fallback;
  }

  function uniq(list) {
    return [...new Set((Array.isArray(list) ? list : []).filter(Boolean))];
  }

  function slug(value) {
    return String(value ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'item';
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function hashString(input) {
    let hash = 2166136261;
    const text = String(input ?? '');
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return `dr-${(hash >>> 0).toString(16).padStart(8, '0')}`;
  }

  function seededRng(seedInput) {
    let seed = 0;
    String(seedInput ?? 'seed').split('').forEach((char) => { seed = (seed * 31 + char.charCodeAt(0)) >>> 0; });
    return function rng() {
      seed |= 0;
      seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function choose(rng, list) {
    if (!list.length) return null;
    return list[Math.floor(rng() * list.length)] ?? list[0];
  }

  function shuffle(rng, list) {
    const out = [...list];
    for (let i = out.length - 1; i > 0; i -= 1) {
      const j = Math.floor(rng() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  }

  function normalizeList(value) {
    return String(value ?? '')
      .split(/[|,]/)
      .map((entry) => String(entry ?? '').trim().toLowerCase())
      .filter(Boolean);
  }

  function lowerTags(card) {
    return Array.isArray(card?.tags) ? card.tags.map((tag) => String(tag ?? '').trim().toLowerCase()).filter(Boolean) : [];
  }

  function lowerCompat(card) {
    return String(card?.battleCompatibility ?? card?.campaignMeta?.battleCompatibility ?? card?.mtgMeta?.battleCompatibility ?? '').trim().toLowerCase();
  }

  function requiredModesForCard(card) {
    return normalizeList(card?.requiredModes ?? card?.campaignMeta?.requiredModes ?? card?.mtgMeta?.requiredModes ?? '');
  }

  function isLocalExclusiveCard(card) {
    if (!!card?.localExclusive) return true;
    const tags = lowerTags(card);
    if (tags.includes('local-exclusive') || tags.includes('local-player-exclusive')) return true;
    return requiredModesForCard(card).some((entry) => entry === 'local-player' || entry === 'local_player' || entry === 'local multiplayer');
  }

  function isConquestOnlyCard(card) {
    const tags = lowerTags(card);
    const type = String(card?.type ?? '').trim().toLowerCase();
    const compat = lowerCompat(card);
    const mode = String(card?.mode ?? '').trim().toLowerCase();
    const requiredModes = requiredModesForCard(card);
    const conquestOnlyTypes = new Set(['unit', 'building', 'facility', 'turret', 'barricade', 'equipment', 'upgrade', 'tactic', 'support']);
    return mode === 'conquest'
      || compat === 'defense_only'
      || conquestOnlyTypes.has(type)
      || tags.includes('conquest')
      || tags.includes('conquest-only')
      || requiredModes.some((entry) => entry.includes('conquest') || entry.includes('defense'));
  }

  function normalizeCardType(card) {
    return TYPE_ALIASES[String(card?.type ?? '').trim().toLowerCase()] || String(card?.type ?? 'minion').trim().toLowerCase() || 'minion';
  }

  function normalizeRace(card) {
    return String(card?.primaryRace ?? card?.race ?? card?.species ?? '').trim();
  }

  function normalizeRarity(card) {
    return String(card?.rarity ?? 'common').trim().toLowerCase() || 'common';
  }

  function textOf(card) {
    return String(card?.text ?? card?.rulesText ?? '').trim();
  }

  function readJsonStorage(key, fallback) {
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? JSON.parse(raw) : clone(fallback);
    } catch {
      return clone(fallback);
    }
  }

  function writeJsonStorage(key, value) {
    window.localStorage.setItem(key, JSON.stringify(value));
  }

  function loadProfile() {
    const profile = readJsonStorage(PROFILE_KEY, {});
    profile.economy = profile.economy && typeof profile.economy === 'object' ? profile.economy : {};
    profile.economy.gold = Math.max(0, toNumber(profile.economy.gold, 0));
    profile.customDecks = Array.isArray(profile.customDecks) ? profile.customDecks : [];
    return profile;
  }

  function saveProfile(profile) {
    writeJsonStorage(PROFILE_KEY, profile);
  }

  function defaultStore() {
    return {
      version: 1,
      engineVersion: ENGINE_VERSION,
      deckCache: {},
      cardCache: {},
      deckLinks: {},
      deckHistory: {},
      recentRuns: [],
      debug: {
        enabled: false,
        showEval: false,
        showGauntlet: false,
        showCohesion: false,
        showDrawMath: false,
        fastMode: false,
      },
    };
  }

  function loadStore() {
    const store = readJsonStorage(STORE_KEY, defaultStore());
    store.deckCache = store.deckCache && typeof store.deckCache === 'object' ? store.deckCache : {};
    store.cardCache = store.cardCache && typeof store.cardCache === 'object' ? store.cardCache : {};
    store.deckLinks = store.deckLinks && typeof store.deckLinks === 'object' ? store.deckLinks : {};
    store.deckHistory = store.deckHistory && typeof store.deckHistory === 'object' ? store.deckHistory : {};
    store.recentRuns = Array.isArray(store.recentRuns) ? store.recentRuns : [];
    store.debug = { ...defaultStore().debug, ...(store.debug || {}) };
    store.engineVersion = ENGINE_VERSION;
    return store;
  }

  function saveStore(store) {
    writeJsonStorage(STORE_KEY, store);
  }

  async function loadJson(path, fallback = null) {
    try {
      const response = await fetch(resolvePath(path), { cache: 'no-store' });
      if (!response.ok) throw new Error(`Failed ${path}`);
      return await response.json();
    } catch {
      return fallback;
    }
  }

  function mergeCards(primaryCards) {
    const merged = Object.create(null);
    const priority = { custom: 3, pack: 2, base: 1 };
    primaryCards.forEach((card) => {
      if (!card?.id) return;
      const source = card.__sourcePriority || 'base';
      if (!merged[card.id] || priority[source] >= priority[merged[card.id].__sourcePriority || 'base']) merged[card.id] = card;
    });
    return Object.values(merged);
  }

  async function loadCatalog() {
    if (GLOBAL.catalogPromise) return GLOBAL.catalogPromise;
    GLOBAL.catalogPromise = (async () => {
      const base = await loadJson('cardex.json', { cards: [] });
      const packIndex = await loadJson('packs/index.json', { entries: [] });
      const cards = [];
      (base?.cards || []).forEach((card) => cards.push({ ...card, __sourcePriority: 'base' }));
      for (const entry of packIndex?.entries || []) {
        const pack = await loadJson(`packs/${entry}`, null);
        if (!Array.isArray(pack?.cards)) continue;
        pack.cards.forEach((card) => cards.push({ ...card, packId: card.packId || pack.id, packName: card.packName || pack.name, __sourcePriority: 'pack' }));
      }
      const custom = readJsonStorage(CUSTOM_CARD_LIBRARY_KEY, {});
      Object.values(custom).forEach((card) => cards.push({ ...card, customMade: true, __sourcePriority: 'custom' }));
      const merged = mergeCards(cards).map((card) => ({
        ...card,
        id: String(card.id || '').trim(),
        name: String(card.name || card.id || 'Unnamed Card').trim(),
        type: normalizeCardType(card),
        cost: Math.max(0, Math.floor(toNumber(card.cost ?? card.mana ?? 0, 0))),
        attack: Math.max(0, toNumber(card.attack, 0)),
        health: Math.max(0, toNumber(card.health, 0)),
        def: Math.max(0, toNumber(card.def ?? card.defense ?? card.armor ?? card.shield ?? 0, 0)),
        rarity: normalizeRarity(card),
        race: normalizeRace(card),
        text: textOf(card),
        tags: Array.isArray(card.tags) ? card.tags.map((tag) => String(tag)) : [],
      })).filter((card) => card.id);
      const byId = Object.fromEntries(merged.map((card) => [card.id, card]));
      GLOBAL.catalog = { cards: merged, byId };
      return GLOBAL.catalog;
    })();
    return GLOBAL.catalogPromise;
  }

  function normalizeDeck(deck, isBuiltIn) {
    const entries = Array.isArray(deck?.entries)
      ? deck.entries.map((entry) => ({ cardId: String(entry.cardId || '').trim(), count: Math.max(0, Math.floor(toNumber(entry.count, 0))) })).filter((entry) => entry.cardId && entry.count > 0)
      : [];
    return {
      id: String(deck?.id || `deck-${Date.now()}`),
      name: String(deck?.name || 'Untitled Deck'),
      icon: String(deck?.icon || '◆'),
      themeColor: String(deck?.themeColor || '#6fa8ff'),
      archetype: String(deck?.archetype || ''),
      entries,
      rules: { ...(deck?.rules || {}), targetSize: Math.max(1, Math.floor(toNumber(deck?.rules?.targetSize ?? entries.reduce((sum, entry) => sum + entry.count, 0), 30))) },
      isBuiltIn: !!isBuiltIn,
      localExclusive: !!deck?.localExclusive,
    };
  }

  async function loadDeckCatalog() {
    if (GLOBAL.deckCatalogPromise) return GLOBAL.deckCatalogPromise;
    GLOBAL.deckCatalogPromise = (async () => {
      const catalog = await loadCatalog();
      const deckIndex = await loadJson('game/deck_packs/index.json', { entries: [] });
      const builtIn = [];
      for (const entry of deckIndex?.entries || []) {
        const pack = await loadJson(`game/deck_packs/${entry}`, null);
        if (!Array.isArray(pack?.decks)) continue;
        pack.decks.forEach((deck) => {
          const normalized = normalizeDeck(deck, true);
          const legal = normalized.entries.every((item) => {
            const card = catalog.byId[item.cardId];
            return !!card && !isConquestOnlyCard(card);
          });
          if (legal && normalized.entries.length) builtIn.push(normalized);
        });
      }
      GLOBAL.deckCatalog = builtIn;
      return builtIn;
    })();
    return GLOBAL.deckCatalogPromise;
  }

  function combinedDecks(profile, builtInDecks) {
    const customDecks = (profile.customDecks || []).map((deck) => normalizeDeck(deck, false));
    const seen = new Set();
    return [...customDecks, ...builtInDecks].filter((deck) => {
      if (seen.has(deck.id)) return false;
      seen.add(deck.id);
      return true;
    });
  }

  function entriesToCards(entries, byId) {
    const out = [];
    (entries || []).forEach((entry) => {
      const card = byId[entry.cardId];
      if (!card) return;
      for (let i = 0; i < entry.count; i += 1) out.push(card);
    });
    return out;
  }

  function contentHashForDeck(deck) {
    const normalized = normalizeDeck(deck, !!deck?.isBuiltIn);
    const payload = {
      name: normalized.name,
      entries: [...normalized.entries].sort((a, b) => a.cardId.localeCompare(b.cardId)).map((entry) => `${entry.cardId}:${entry.count}`),
      localExclusive: !!normalized.localExclusive,
      rules: normalized.rules?.targetSize || 0,
    };
    return hashString(JSON.stringify(payload));
  }

  function contentHashForCard(card) {
    const payload = {
      id: card?.id || '',
      name: card?.name || '',
      cost: toNumber(card?.cost, 0),
      type: normalizeCardType(card),
      rarity: normalizeRarity(card),
      race: normalizeRace(card),
      attack: toNumber(card?.attack, 0),
      health: toNumber(card?.health, 0),
      def: toNumber(card?.def ?? card?.defense ?? 0, 0),
      text: textOf(card),
      tags: Array.isArray(card?.tags) ? [...card.tags].sort() : [],
      localExclusive: !!card?.localExclusive,
    };
    return hashString(JSON.stringify(payload));
  }

  function countPattern(text, pattern) {
    const matches = text.match(pattern);
    return matches ? matches.length : 0;
  }

  function analyzeCard(card) {
    const type = normalizeCardType(card);
    const race = normalizeRace(card);
    const text = textOf(card).toLowerCase();
    const tags = lowerTags(card);
    const cost = Math.max(0, toNumber(card.cost, 0));
    const attack = Math.max(0, toNumber(card.attack, 0));
    const health = Math.max(0, toNumber(card.health, 0));
    const def = Math.max(0, toNumber(card.def ?? card.defense ?? 0, 0));
    const drawCount = countPattern(text, /draw\s+(?:a|an|\d+)/g) + countPattern(text, /discover|look at the top card|search your deck|tutor/g);
    const summonCount = countPattern(text, /summon/g);
    const healPoints = countPattern(text, /restore|heal/g);
    const removalHits = countPattern(text, /destroy|exile|silence|freeze|deal\s+[4-9]|return .*hand|poisonous|cursed/g);
    const aoeHits = countPattern(text, /all enemy|all enemies|all minions|split among|each enemy|all other minions/g);
    const costReductionHits = countPattern(text, /costs?\s+\d+\s+less|reduce the cost|cost\s+\(\d+\)\s+less/g);
    const auraHits = countPattern(text, /other friendly|your .* have|while you control|aura/g);
    const repeatHits = countPattern(text, /whenever|after |at the start|at the end|once per turn|first time each turn/g);
    const damageHits = countPattern(text, /deal\s+\d+|damage/g);
    const randomHits = countPattern(text, /random|discover|split randomly/g);
    const returnHits = countPattern(text, /return .* hand|bounce/g);
    const reviveHits = countPattern(text, /revive|resummon|return this to your hand|death:/g);
    const buffHits = countPattern(text, /\+\d+\/\+\d+|\+\d+ attack|\+\d+ health|divine shield|stealth|taunt|rush|flying|lifesteal/g);
    const keywordSet = new Set(tags);
    const lowCurve = cost <= 2 ? 1 : 0;
    const highTopEnd = cost >= 6 ? 1 : 0;
    const reactive = removalHits + aoeHits + countPattern(text, /counter|cancel|prevent/g);
    const proactive = Math.max(0, attack + summonCount + buffHits + (type === 'minion' ? 1 : 0));
    const support = drawCount + healPoints + auraHits + costReductionHits + countPattern(text, /friendly/g);
    const engine = repeatHits + auraHits + costReductionHits + (type === 'field' || type === 'relic' ? 2 : 0);
    const threat = attack * 1.7 + health * 1.1 + def * 0.8 + (type === 'minion' ? 2 : 0) + highTopEnd * 2.5 + buffHits * 0.7;
    const tempo = Math.max(0, (lowCurve * 7) + proactive * 1.15 + countPattern(text, /rush|charge|can attack the turn/g) * 4 - highTopEnd * 2.2);
    const control = reactive * 4.2 + aoeHits * 5.5 + healPoints * 1.1 + countPattern(text, /taunt|guard|freeze|silence|can't be targeted/g) * 2.8;
    const cardDraw = drawCount * 8 + countPattern(text, /search|discover|look at the top/g) * 4.5;
    const sustain = healPoints * 3 + countPattern(text, /lifesteal|restore|divine shield|taunt/g) * 2.6;
    const burst = damageHits * 3.4 + countPattern(text, /overkill|double attack|deal .* to all enemies/g) * 3.8 + attack * (cost <= 3 ? 1.1 : 0.45);
    const synergy = support * 2.2 + engine * 2.6 + costReductionHits * 3.2 + (race ? 2 : 0) + countPattern(text, /another friendly|friendly [a-z]+s|race|dragon|beast|human|undead|spirit/g) * 1.6;
    const resilience = health * 1.2 + def * 1.7 + countPattern(text, /death:|return this to your hand|resummon|divine shield|taunt/g) * 2.8;
    const flexibility = Math.min(16, proactive + reactive + support + (type === 'spell' ? 2 : 0));
    const topdeck = Math.max(0, cardDraw * 3.5 + burst * 0.35 + threat * 0.45 + (text.includes('battlecry') ? 2.2 : 0) - cost * 0.8);
    const multiplayer = aoeHits * 6 + sustain * 0.6 + engine * 1.2 + countPattern(text, /all friendly|all enemy|all enemies|each friendly/g) * 2.2;
    const teamUtility = healPoints * 2.2 + countPattern(text, /friendly|all friendly|another friendly/g) * 1.7 + countPattern(text, /draw a card|divine shield|can't be targeted/g) * 1.5;
    const political = clamp((control * 0.5 + engine * 0.35 + sustain * 0.45) - (tempo * 0.28 + burst * 0.26), 0, 100);
    const volatility = randomHits * 5 + countPattern(text, /discard|self damage|deal \d damage to a friendly/g) * 3 + (cost >= 7 ? 1.5 : 0);
    const comboReliance = clamp(costReductionHits * 2 + countPattern(text, /if you|if another|if you control|if this survives/g) * 1.5 + synergy * 0.12, 0, 100);
    const deadRisk = clamp((cost >= 7 ? 12 : 0) + (reactive > proactive ? 6 : 0) + (support > proactive && type === 'minion' ? 4 : 0) + (type === 'field' || type === 'relic' ? 3 : 0), 0, 30);
    const finish = burst * 0.65 + threat * 0.45 + countPattern(text, /can't be targeted|flying|charge|deal .* to any enemy/g) * 2.4;
    return {
      id: card.id,
      name: card.name,
      type,
      race,
      cost,
      rarity: normalizeRarity(card),
      attack,
      health,
      def,
      localExclusive: isLocalExclusiveCard(card),
      roles: {
        tempo,
        control,
        draw: cardDraw,
        sustain,
        burst,
        synergy,
        resilience,
        flexibility,
        topdeck,
        multiplayer,
        teamUtility,
        political,
        volatility,
        comboReliance,
        deadRisk,
        threat,
        engine,
        proactive,
        reactive,
        finish,
      },
      flags: {
        drawCount,
        summonCount,
        healPoints,
        removalHits,
        aoeHits,
        costReductionHits,
        auraHits,
        repeatHits,
        damageHits,
        returnHits,
        reviveHits,
        buffHits,
        lowCurve,
        highTopEnd,
      },
      keywords: {
        taunt: keywordSet.has('taunt') || text.includes('taunt') || text.includes('guard'),
        stealth: keywordSet.has('stealth') || text.includes('stealth'),
        rush: keywordSet.has('rush') || text.includes('rush'),
        flying: keywordSet.has('flying') || text.includes('flying'),
        lifesteal: keywordSet.has('lifesteal') || text.includes('lifesteal'),
        divineShield: keywordSet.has('divine shield') || text.includes('divine shield'),
      },
      text,
      tags,
    };
  }

  function inferDeckArchetype(totals) {
    const contenders = {
      aggro: totals.tempo * 1.2 + totals.burst + totals.lowCurve * 14 - totals.topHeavy * 8,
      midrange: totals.threat + totals.consistency * 0.5 + totals.flexibility * 0.7 + totals.midCurve * 8,
      control: totals.control * 1.2 + totals.sustain + totals.inevitability - totals.lowCurve * 2,
      combo: totals.synergy * 1.25 + totals.draw + totals.engine * 1.1 + totals.comboReliance * 0.9,
      swarm: totals.summon * 1.2 + totals.buffWide * 1.1 + totals.lowCurve * 12 + totals.multiplayerPressure * 0.4,
      tribal: totals.tribalDensity * 1.3 + totals.synergy + totals.draw * 0.35,
      engine: totals.engine * 1.35 + totals.relicField * 1.2 + totals.inevitability * 0.8,
      ramp: totals.topHeavy * 1.1 + totals.draw * 0.6 + totals.inevitability * 1.2,
      value: totals.draw * 0.8 + totals.flexibility * 0.9 + totals.sustain * 0.5 + totals.topdeck * 0.9,
    };
    const ranked = Object.entries(contenders).sort((a, b) => b[1] - a[1]);
    const primary = ranked[0]?.[0] || 'midrange';
    const secondary = ranked[1]?.[0] || primary;
    return {
      primary,
      secondary,
      ranked,
      label: `${primary[0].toUpperCase()}${primary.slice(1)}${secondary !== primary ? ` / ${secondary[0].toUpperCase()}${secondary.slice(1)}` : ''}`,
    };
  }

  function deckSummary(deck, catalog) {
    const normalized = normalizeDeck(deck, !!deck?.isBuiltIn);
    const cards = entriesToCards(normalized.entries, catalog.byId);
    const analyses = cards.map((card) => analyzeCard(card));
    const countsById = Object.create(null);
    const curve = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, '6+': 0 };
    const typeCounts = Object.create(null);
    const raceCounts = Object.create(null);
    const rarityCounts = Object.create(null);
    const totals = {
      cardCount: cards.length,
      manaTotal: 0,
      lowCurve: 0,
      midCurve: 0,
      topHeavy: 0,
      tempo: 0,
      control: 0,
      draw: 0,
      sustain: 0,
      burst: 0,
      synergy: 0,
      resilience: 0,
      flexibility: 0,
      topdeck: 0,
      multiplayerPressure: 0,
      teamUtility: 0,
      political: 0,
      volatility: 0,
      comboReliance: 0,
      threat: 0,
      engine: 0,
      summon: 0,
      removal: 0,
      aoe: 0,
      tribalDensity: 0,
      relicField: 0,
      inevitability: 0,
      buffWide: 0,
      deadRisk: 0,
      finish: 0,
      drawCount: 0,
      consistency: 0,
      legendaryCount: 0,
      localExclusiveCount: 0,
    };
    analyses.forEach((analysis) => {
      countsById[analysis.id] = (countsById[analysis.id] || 0) + 1;
      totals.manaTotal += analysis.cost;
      totals.tempo += analysis.roles.tempo;
      totals.control += analysis.roles.control;
      totals.draw += analysis.roles.draw;
      totals.sustain += analysis.roles.sustain;
      totals.burst += analysis.roles.burst;
      totals.synergy += analysis.roles.synergy;
      totals.resilience += analysis.roles.resilience;
      totals.flexibility += analysis.roles.flexibility;
      totals.topdeck += analysis.roles.topdeck;
      totals.multiplayerPressure += analysis.roles.multiplayer;
      totals.teamUtility += analysis.roles.teamUtility;
      totals.political += analysis.roles.political;
      totals.volatility += analysis.roles.volatility;
      totals.comboReliance += analysis.roles.comboReliance;
      totals.threat += analysis.roles.threat;
      totals.engine += analysis.roles.engine;
      totals.summon += analysis.flags.summonCount;
      totals.removal += analysis.flags.removalHits;
      totals.aoe += analysis.flags.aoeHits;
      totals.buffWide += analysis.flags.buffHits + analysis.flags.auraHits;
      totals.deadRisk += analysis.roles.deadRisk;
      totals.finish += analysis.roles.finish;
      totals.drawCount += analysis.flags.drawCount;
      totals.inevitability += analysis.roles.engine * 0.45 + analysis.roles.topdeck * 0.35 + analysis.roles.resilience * 0.3 + analysis.roles.finish * 0.25;
      if (analysis.cost <= 2) totals.lowCurve += 1;
      else if (analysis.cost <= 5) totals.midCurve += 1;
      else totals.topHeavy += 1;
      if (analysis.race) raceCounts[analysis.race] = (raceCounts[analysis.race] || 0) + 1;
      if (analysis.rarity === 'legendary') totals.legendaryCount += 1;
      if (analysis.localExclusive) totals.localExclusiveCount += 1;
      const bucket = analysis.cost >= 6 ? '6+' : String(analysis.cost);
      curve[bucket] = (curve[bucket] || 0) + 1;
      typeCounts[analysis.type] = (typeCounts[analysis.type] || 0) + 1;
      rarityCounts[analysis.rarity] = (rarityCounts[analysis.rarity] || 0) + 1;
      if (analysis.type === 'relic' || analysis.type === 'field') totals.relicField += 1;
    });
    const dominantRaceEntry = Object.entries(raceCounts).sort((a, b) => b[1] - a[1])[0] || null;
    totals.tribalDensity = dominantRaceEntry ? (dominantRaceEntry[1] / Math.max(1, cards.length)) * 100 : 0;
    const archetype = inferDeckArchetype(totals);
    const avgCost = cards.length ? totals.manaTotal / cards.length : 0;
    return {
      deck: normalized,
      cards,
      analyses,
      countsById,
      curve,
      typeCounts,
      raceCounts,
      rarityCounts,
      avgCost,
      totals,
      archetype,
      dominantRace: dominantRaceEntry ? dominantRaceEntry[0] : '',
      deckHash: contentHashForDeck(normalized),
    };
  }

  function subsetPlayValue(analysis, turn, archetype) {
    const costPenalty = analysis.cost > turn ? 9 : 0;
    const roleBias = {
      aggro: analysis.roles.tempo * 1.3 + analysis.roles.burst * 0.8 + analysis.roles.threat * 0.6,
      control: analysis.roles.control * 1.25 + analysis.roles.sustain * 0.8 + analysis.roles.draw * 0.55,
      combo: analysis.roles.synergy * 1.2 + analysis.roles.draw * 0.85 + analysis.roles.engine * 0.65,
      tribal: analysis.roles.synergy * 1.15 + analysis.roles.threat * 0.6 + (analysis.race ? 4 : 0),
      swarm: analysis.flags.summonCount * 4 + analysis.roles.tempo * 0.9 + analysis.roles.multiplayer * 0.45,
      engine: analysis.roles.engine * 1.2 + analysis.roles.draw * 0.6 + analysis.roles.control * 0.45,
      ramp: analysis.roles.finish * 0.9 + analysis.roles.draw * 0.55 + analysis.roles.topdeck * 0.4,
      value: analysis.roles.flexibility * 1.1 + analysis.roles.topdeck * 0.8 + analysis.roles.draw * 0.7,
      midrange: analysis.roles.threat + analysis.roles.flexibility * 0.8 + analysis.roles.tempo * 0.55,
    }[archetype] || (analysis.roles.tempo + analysis.roles.flexibility);
    return roleBias - costPenalty;
  }

  function simulateOpenings(summary, sampleCount, seed, options = {}) {
    const rng = seededRng(`${seed}:openings:${sampleCount}:${options.mode || 'normal'}`);
    const pool = summary.analyses.map((analysis) => analysis.id);
    const analysisById = Object.fromEntries(summary.analyses.map((analysis, index) => [`${analysis.id}:${index}`, analysis]));
    const indexedDeck = summary.analyses.map((analysis, index) => ({ key: `${analysis.id}:${index}`, analysis }));
    const result = {
      openingQuality: 0,
      deadHands: 0,
      recoverableBadHands: 0,
      curveHits: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
      drawHeatmap: [0, 0, 0, 0, 0, 0, 0, 0],
      topdeckLive: 0,
      topdeckSamples: 0,
      deadCardSamples: 0,
      reactiveOverload: 0,
      finisherAccess: 0,
      keepRate: 0,
      mulliganHelp: 0,
      cardStats: {},
      playedByTurn: [0, 0, 0, 0, 0, 0, 0, 0],
      floodSamples: 0,
      screwSamples: 0,
      sampleCount,
    };
    const archetype = summary.archetype.primary;
    const ensureCardStat = (id) => {
      result.cardStats[id] = result.cardStats[id] || { draws: 0, plays: 0, keeps: 0, dead: 0, supportScore: 0 };
      return result.cardStats[id];
    };

    for (let sample = 0; sample < sampleCount; sample += 1) {
      const deck = shuffle(rng, indexedDeck);
      let hand = deck.slice(0, 5);
      let drawIndex = 5;
      const mulliganable = hand.filter(({ analysis }) => analysis.cost >= 5 || analysis.roles.deadRisk >= 14 || (analysis.roles.reactive > analysis.roles.proactive && analysis.cost >= 3));
      const mulliganCount = Math.min(3, mulliganable.length);
      const keepCount = hand.length - mulliganCount;
      const keepKeys = new Set(hand.slice(0, keepCount).map((entry) => entry.key));
      hand.forEach(({ analysis }) => {
        const stat = ensureCardStat(analysis.id);
        stat.draws += 1;
      });
      if (mulliganCount) {
        result.mulliganHelp += 1;
        const kept = hand.filter((entry) => keepKeys.has(entry.key));
        const redraw = deck.slice(drawIndex, drawIndex + mulliganCount);
        drawIndex += mulliganCount;
        hand = [...kept, ...redraw];
      }
      hand.forEach(({ analysis }) => {
        const stat = ensureCardStat(analysis.id);
        stat.keeps += 1;
      });
      const openerScore = hand.reduce((sum, { analysis }) => sum + subsetPlayValue(analysis, 2, archetype), 0) / Math.max(1, hand.length);
      result.openingQuality += openerScore;
      const earlyLive = hand.filter(({ analysis }) => analysis.cost <= 2 || analysis.roles.draw >= 7 || analysis.roles.tempo >= 7).length;
      if (earlyLive <= 1) result.deadHands += 1;
      if (earlyLive <= 1 && mulliganCount >= 1) result.recoverableBadHands += 1;
      if (hand.filter(({ analysis }) => analysis.roles.reactive > analysis.roles.proactive).length >= 4) result.reactiveOverload += 1;
      if (hand.filter(({ analysis }) => analysis.cost >= 5).length >= 3) result.floodSamples += 1;
      if (hand.filter(({ analysis }) => analysis.cost <= 2).length === 0) result.screwSamples += 1;

      let deadCardsThisSample = 0;
      for (let turn = 1; turn <= 8; turn += 1) {
        if (drawIndex < deck.length) {
          const drawn = deck[drawIndex];
          drawIndex += 1;
          hand.push(drawn);
          ensureCardStat(drawn.analysis.id).draws += 1;
        }
        let mana = turn;
        const played = [];
        const sortedPlayable = [...hand].sort((a, b) => subsetPlayValue(b.analysis, turn, archetype) - subsetPlayValue(a.analysis, turn, archetype));
        for (const entry of sortedPlayable) {
          if (entry.analysis.cost <= mana && subsetPlayValue(entry.analysis, turn, archetype) > 0) {
            mana -= entry.analysis.cost;
            played.push(entry);
          }
        }
        const playedKeys = new Set(played.map((entry) => entry.key));
        hand = hand.filter((entry) => !playedKeys.has(entry.key));
        result.playedByTurn[turn - 1] += played.length;
        if (played.some((entry) => entry.analysis.cost === turn || entry.analysis.cost === turn - 1 || entry.analysis.cost === turn + 1)) {
          result.curveHits[Math.min(5, turn)] += 1;
        }
        played.forEach(({ analysis }) => {
          const stat = ensureCardStat(analysis.id);
          stat.plays += 1;
          stat.supportScore += analysis.roles.synergy + analysis.roles.flexibility;
        });
        if (drawIndex < deck.length) {
          const topdeck = deck[drawIndex].analysis;
          result.topdeckSamples += 1;
          if (subsetPlayValue(topdeck, turn + 1, archetype) > 8 || topdeck.roles.topdeck >= 8) result.topdeckLive += 1;
          result.drawHeatmap[turn - 1] += Math.max(0, Math.min(100, subsetPlayValue(topdeck, turn + 1, archetype) * 2));
        }
      }
      hand.forEach(({ analysis }) => {
        if (analysis.cost >= 5 || analysis.roles.deadRisk >= 12) {
          deadCardsThisSample += 1;
          ensureCardStat(analysis.id).dead += 1;
        }
      });
      result.deadCardSamples += deadCardsThisSample;
      if (Object.values(result.cardStats).length) {
        result.keepRate += keepCount / 5;
      }
      if (summary.analyses.some((analysis) => analysis.roles.finish >= 18)) result.finisherAccess += 1;
    }
    return result;
  }

  function buildSynergyGraph(summary) {
    const nodes = summary.analyses.map((analysis) => ({
      id: analysis.id,
      name: analysis.name,
      race: analysis.race,
      type: analysis.type,
      weight: 0,
    }));
    const edges = [];
    for (let i = 0; i < summary.analyses.length; i += 1) {
      for (let j = i + 1; j < summary.analyses.length; j += 1) {
        const a = summary.analyses[i];
        const b = summary.analyses[j];
        let weight = 0;
        if (a.race && b.race && a.race === b.race) weight += 2.5;
        if (a.type === b.type) weight += 0.35;
        if ((a.roles.synergy >= 10 && b.roles.threat >= 10) || (b.roles.synergy >= 10 && a.roles.threat >= 10)) weight += 1.9;
        if ((a.roles.draw >= 10 && b.roles.comboReliance >= 10) || (b.roles.draw >= 10 && a.roles.comboReliance >= 10)) weight += 1.2;
        if ((a.type === 'relic' || a.type === 'field') && b.roles.engine >= 8) weight += 1.5;
        if ((b.type === 'relic' || b.type === 'field') && a.roles.engine >= 8) weight += 1.5;
        if (a.text.includes('friendly') && b.type === 'minion') weight += 0.4;
        if (b.text.includes('friendly') && a.type === 'minion') weight += 0.4;
        if (weight >= 2.1) {
          edges.push({ a: i, b: j, weight: Number(weight.toFixed(2)) });
          nodes[i].weight += weight;
          nodes[j].weight += weight;
        }
      }
    }
    const clusters = [];
    const seen = new Set();
    nodes.forEach((node, index) => {
      if (seen.has(index)) return;
      const cluster = [index];
      seen.add(index);
      for (const edge of edges) {
        if (edge.weight < 3) continue;
        if (edge.a === index && !seen.has(edge.b)) {
          cluster.push(edge.b);
          seen.add(edge.b);
        }
        if (edge.b === index && !seen.has(edge.a)) {
          cluster.push(edge.a);
          seen.add(edge.a);
        }
      }
      clusters.push(cluster);
    });
    const mappedClusters = clusters
      .map((cluster) => {
        const names = cluster.map((idx) => nodes[idx].name);
        const totalWeight = cluster.reduce((sum, idx) => sum + nodes[idx].weight, 0);
        return { names, score: Number((totalWeight / Math.max(1, cluster.length)).toFixed(1)) };
      })
      .sort((a, b) => b.score - a.score);
    const averageWeight = nodes.reduce((sum, node) => sum + node.weight, 0) / Math.max(1, nodes.length);
    const outliers = nodes.filter((node) => node.weight < averageWeight * 0.45).sort((a, b) => a.weight - b.weight).slice(0, 6);
    const keyCard = [...nodes].sort((a, b) => b.weight - a.weight)[0] || null;
    return {
      nodes,
      edges,
      clusters: mappedClusters,
      outliers,
      keyCardReliance: keyCard ? clamp((keyCard.weight / Math.max(1, averageWeight || 1)) * 18, 0, 100) : 0,
      redundancy: clamp(mappedClusters.slice(0, 3).reduce((sum, cluster) => sum + cluster.names.length, 0) / Math.max(1, nodes.length) * 100, 0, 100),
    };
  }

  function benchmarkMatchScore(metrics, benchmark, tier, format) {
    const traits = benchmark.traits;
    const score = {
      aggro: metrics.control * 0.58 + metrics.sustain * 0.52 + metrics.consistency * 0.45 + metrics.tempo * 0.22 - traits.tempo * 0.44,
      midrange: metrics.boardControl * 0.5 + metrics.tempo * 0.32 + metrics.flexibility * 0.44 + metrics.topdeck * 0.18,
      control: metrics.burst * 0.38 + metrics.synergy * 0.35 + metrics.inevitability * 0.44 + metrics.topdeck * 0.34 - metrics.keyCardReliance * 0.18,
      combo: metrics.tempo * 0.34 + metrics.boardControl * 0.18 + metrics.synergy * 0.24 + metrics.metaResilience * 0.4,
      relic: metrics.boardControl * 0.25 + metrics.synergy * 0.42 + metrics.draw * 0.24 + metrics.redundancy * 0.18,
      tribal: metrics.boardControl * 0.2 + metrics.synergy * 0.28 + metrics.tempo * 0.24 + metrics.recovery * 0.18,
      antiswarm: metrics.burst * 0.18 + metrics.resilience * 0.44 + metrics.topdeck * 0.16 + metrics.synergy * 0.24,
      topend: metrics.tempo * 0.42 + metrics.boardControl * 0.36 + metrics.finish * 0.24 + metrics.draw * 0.14,
      politics: metrics.multiplayerPressure * 0.48 + metrics.sustain * 0.28 + metrics.flexibility * 0.22 + metrics.politicalSurvivability * 0.42 - metrics.threatPerception * 0.28,
      teamplay: metrics.teamUtility * 0.58 + metrics.consistency * 0.24 + metrics.boardControl * 0.2 + metrics.sustain * 0.26,
    }[benchmark.id] || metrics.consistency;
    let modifier = tier.bonus;
    if (format === '2v2') modifier += metrics.teamUtility * 0.09 + metrics.recovery * 0.05;
    if (format === 'ffa') modifier += metrics.multiplayerPressure * 0.08 + metrics.politicalSurvivability * 0.12 - metrics.threatPerception * 0.1;
    return score + modifier;
  }

  function logistic(value) {
    return 1 / (1 + Math.exp(-value / 18));
  }

  function runGauntlet(summary, metrics, samples, seed) {
    const formats = ['1v1', '2v2', 'ffa'];
    const result = { formats: { '1v1': [], '2v2': [], ffa: [] }, benchmarkSpread: {}, winRates: {} };
    formats.forEach((format) => {
      BENCHMARKS.forEach((benchmark) => {
        BENCHMARK_TIERS.forEach((tier) => {
          let wins = 0;
          const margins = [];
          const rng = seededRng(`${seed}:${format}:${benchmark.id}:${tier.id}`);
          for (let sample = 0; sample < samples; sample += 1) {
            const noise = (rng() - 0.5) * (metrics.volatility * 0.15 + 8);
            const matchup = benchmarkMatchScore(metrics, benchmark, tier, format) + noise;
            const probability = logistic(matchup - 52 + (metrics.consistency * 0.08));
            if (rng() < probability) wins += 1;
            margins.push((probability - 0.5) * 100);
          }
          const winRate = wins / Math.max(1, samples);
          const id = `${benchmark.id}:${tier.id}`;
          result.formats[format].push({
            benchmarkId: benchmark.id,
            benchmark: benchmark.name,
            tier: tier.label,
            winRate,
            meanMargin: margins.reduce((sum, value) => sum + value, 0) / Math.max(1, margins.length),
          });
          result.benchmarkSpread[id] = result.benchmarkSpread[id] || [];
          result.benchmarkSpread[id].push(winRate);
        });
      });
      result.winRates[format] = result.formats[format].reduce((sum, entry) => sum + entry.winRate, 0) / Math.max(1, result.formats[format].length);
    });
    return result;
  }

  function summarizeDraws(opening, summary) {
    const sampleCount = Math.max(1, opening.sampleCount);
    const deadHandRate = opening.deadHands / sampleCount;
    const mulliganRecovery = opening.recoverableBadHands / Math.max(1, opening.deadHands || 1);
    const openingQuality = clamp(50 + opening.openingQuality / sampleCount * 3.6, 0, 100);
    const consistency = clamp(
      openingQuality * 0.28
        + (opening.curveHits[1] + opening.curveHits[2] + opening.curveHits[3]) / sampleCount * 18
        + (1 - deadHandRate) * 28
        + (opening.keepRate / sampleCount) * 12
        - (opening.deadCardSamples / sampleCount) * 1.6,
      0,
      100,
    );
    const topdeck = clamp((opening.topdeckLive / Math.max(1, opening.topdeckSamples)) * 100, 0, 100);
    return {
      openingQuality,
      deadHandRate,
      mulliganRecovery,
      consistency,
      topdeck,
      deadCardFrequency: opening.deadCardSamples / sampleCount,
      reactiveOverload: opening.reactiveOverload / sampleCount,
      curveHealth: clamp((opening.curveHits[1] + opening.curveHits[2] + opening.curveHits[3] + opening.curveHits[4]) / sampleCount * 20, 0, 100),
    };
  }

  function deriveDeckMetrics(summary, opening, graph, gauntlet) {
    const draw = summarizeDraws(opening, summary);
    const count = Math.max(1, summary.cards.length);
    const totals = summary.totals;
    const metrics = {
      tempo: clamp(totals.tempo / count * 2.4, 0, 100),
      consistency: draw.consistency,
      draw: clamp((totals.draw / count) * 2.5 + draw.openingQuality * 0.22, 0, 100),
      boardControl: clamp((totals.control / count) * 2.6 + totals.aoe * 2.4, 0, 100),
      burst: clamp((totals.burst / count) * 2.2 + totals.finish * 0.15, 0, 100),
      sustain: clamp((totals.sustain / count) * 2.4 + totals.resilience / count * 1.1, 0, 100),
      synergy: clamp((totals.synergy / count) * 1.9 + graph.redundancy * 0.25, 0, 100),
      resilience: clamp((totals.resilience / count) * 2.2 + (1 - draw.deadHandRate) * 24, 0, 100),
      flexibility: clamp((totals.flexibility / count) * 3.6, 0, 100),
      multiplayerPressure: clamp((totals.multiplayerPressure / count) * 2.5 + totals.teamUtility / count * 0.7, 0, 100),
      recovery: clamp((totals.sustain / count) * 2 + totals.draw / count * 1.1 + (1 - draw.deadHandRate) * 18, 0, 100),
      removal: clamp((totals.removal / count) * 16 + totals.aoe * 4, 0, 100),
      scaling: clamp((totals.inevitability / count) * 1.5 + totals.topHeavy * 1.8, 0, 100),
      threatDensity: clamp((totals.threat / count) * 1.9, 0, 100),
      comboFragility: clamp(totals.comboReliance / count * 2.8 + graph.keyCardReliance * 0.4, 0, 100),
      teamUtility: clamp((totals.teamUtility / count) * 2.8 + totals.sustain / count * 0.8, 0, 100),
      politicalSurvivability: clamp((totals.political / count) * 2 + totals.multiplayerPressure / count * 0.5 + draw.consistency * 0.14, 0, 100),
      threatPerception: clamp((totals.finish / count) * 1.5 + totals.topHeavy * 3.2 + totals.legendaryCount * 4.8, 0, 100),
      metaResilience: 0,
      redundancy: clamp(graph.redundancy, 0, 100),
      keyCardReliance: clamp(graph.keyCardReliance, 0, 100),
      topdeckQuality: draw.topdeck,
      openingHandQuality: draw.openingQuality,
      mulliganStability: clamp(draw.mulliganRecovery * 100 + draw.openingQuality * 0.2, 0, 100),
      deadCardRate: clamp(draw.deadCardFrequency * 8, 0, 100),
      reactiveOverload: clamp(draw.reactiveOverload * 100, 0, 100),
      curveHealth: draw.curveHealth,
      inevitability: clamp((totals.inevitability / count) * 1.8, 0, 100),
      finish: clamp((totals.finish / count) * 2.2, 0, 100),
      volatility: clamp((totals.volatility / count) * 5 + draw.deadHandRate * 30 + (1 - (gauntlet.winRates['1v1'] || 0)) * 8, 0, 100),
    };
    metrics.metaResilience = clamp((gauntlet.formats['1v1'].reduce((sum, entry) => sum + entry.winRate, 0) / Math.max(1, gauntlet.formats['1v1'].length)) * 100, 0, 100);
    return metrics;
  }

  function rateDeck(summary, metrics, gauntlet) {
    const weaknesses = [];
    const strengths = [];
    const warnings = [];
    const opportunities = [];
    const penalties = {
      antiStatInflation: clamp((metrics.threatDensity - (metrics.synergy * 0.42 + metrics.consistency * 0.3 + metrics.boardControl * 0.22)), 0, 45),
      deadCardPenalty: clamp(metrics.deadCardRate * 0.45, 0, 32),
      overfitPenalty: clamp(Math.max(0, 22 - metrics.metaResilience * 0.25), 0, 24),
      volatilityPenalty: clamp(metrics.volatility * 0.28, 0, 22),
      fragilityPenalty: clamp(metrics.keyCardReliance * 0.22 + metrics.comboFragility * 0.12, 0, 24),
      roleCoveragePenalty: clamp(Math.max(0, 26 - (metrics.boardControl * 0.22 + metrics.draw * 0.22 + metrics.threatDensity * 0.18 + metrics.recovery * 0.18)), 0, 24),
    };
    const penaltyTotal = Object.values(penalties).reduce((sum, value) => sum + value, 0);
    const base1v1 = metrics.tempo * 0.12 + metrics.consistency * 0.15 + metrics.draw * 0.08 + metrics.boardControl * 0.12 + metrics.burst * 0.08 + metrics.sustain * 0.08 + metrics.synergy * 0.1 + metrics.resilience * 0.08 + metrics.flexibility * 0.08 + metrics.openingHandQuality * 0.05 + metrics.topdeckQuality * 0.06;
    const base2v2 = base1v1 * 0.78 + metrics.teamUtility * 0.16 + metrics.recovery * 0.08 + metrics.multiplayerPressure * 0.07;
    const baseFFA = base1v1 * 0.7 + metrics.multiplayerPressure * 0.18 + metrics.politicalSurvivability * 0.13 + metrics.sustain * 0.08 - metrics.threatPerception * 0.04;
    const gauntlet1 = (gauntlet.winRates['1v1'] || 0) * 140;
    const gauntlet2 = (gauntlet.winRates['2v2'] || 0) * 140;
    const gauntletF = (gauntlet.winRates.ffa || 0) * 140;
    const publicScores = {
      '1v1': Math.round(clamp(140 + base1v1 * 6.2 + gauntlet1 - penaltyTotal, 120, 980)),
      '2v2': Math.round(clamp(140 + base2v2 * 6.4 + gauntlet2 - penaltyTotal * 0.82, 120, 980)),
      '1v1v1v1': Math.round(clamp(140 + baseFFA * 6.6 + gauntletF - penaltyTotal * 0.88, 120, 980)),
    };
    const confidenceValue = clamp(100 - (metrics.volatility * 0.45 + penalties.overfitPenalty * 1.1 + penalties.fragilityPenalty * 0.7), 20, 98);
    const reliabilityBand = confidenceValue >= 82 ? 'High' : confidenceValue >= 64 ? 'Moderate' : 'Low';
    const bestFormat = Object.entries(publicScores).sort((a, b) => b[1] - a[1])[0]?.[0] || '1v1';
    const worstFormat = Object.entries(publicScores).sort((a, b) => a[1] - b[1])[0]?.[0] || '1v1v1v1';

    if (metrics.consistency >= 72) strengths.push('Opens with strong consistency and low mulligan friction.');
    if (metrics.synergy >= 70) strengths.push('Core packages connect cleanly and reward disciplined sequencing.');
    if (metrics.boardControl >= 68) strengths.push('Carries real board-control tools instead of relying on stat races.');
    if (metrics.teamUtility >= 64) strengths.push('Transfers value well in 2v2 through support and stabilization effects.');
    if (metrics.multiplayerPressure >= 62) strengths.push('Maintains enough board presence to matter in multiplayer without folding immediately.');
    if (metrics.topdeckQuality >= 68) strengths.push('Topdecks remain live late, which raises recovery and inevitability.');

    if (metrics.deadCardRate >= 28) weaknesses.push('Dead-card frequency is too high; expensive or situational pieces are clogging too many samples.');
    if (metrics.keyCardReliance >= 58) weaknesses.push('The deck leans too hard on one package or anchor card to function cleanly.');
    if (penalties.roleCoveragePenalty >= 16) weaknesses.push('Role coverage is uneven; the list is missing one or more basic functional lanes.');
    if (metrics.finish < 42) weaknesses.push('Closing speed is low. The deck stabilizes more often than it actually converts.');
    if (metrics.politicalSurvivability < 45) weaknesses.push('Free-for-all pressure exposes the list too quickly once it becomes the table’s focus.');

    if (penalties.antiStatInflation >= 12) warnings.push('Anti-inflation check triggered: raw body density is outpacing support quality.');
    if (metrics.reactiveOverload >= 38) warnings.push('Too many reactive cards appear in openers without enough proactive anchors.');
    if (metrics.comboFragility >= 62) warnings.push('Combo package is fragile relative to its actual assembly odds.');
    if (metrics.threatPerception >= 68 && publicScores['1v1v1v1'] < publicScores['1v1']) warnings.push('Threat perception is costing real FFA value.');

    if (metrics.deadCardRate >= 24) opportunities.push('Cut one or two expensive situational cards for lower-curve live draws.');
    if (metrics.draw < 48) opportunities.push('Add one more draw/discovery effect to increase opening rescue rate.');
    if (metrics.boardControl < 46) opportunities.push('Add a cleaner interaction slot so aggressive benchmarks stop dictating trades.');
    if (metrics.teamUtility < 40) opportunities.push('If 2v2 matters, add at least one ally-positive support or stabilization card.');

    return {
      publicScores,
      confidenceValue,
      reliabilityBand,
      bestFormat,
      worstFormat,
      strengths,
      weaknesses,
      warnings,
      opportunities,
      penalties,
      powerCeiling: Math.round(clamp((metrics.synergy * 0.32 + metrics.finish * 0.24 + metrics.scaling * 0.22 + metrics.topdeckQuality * 0.22), 1, 100)),
      floorScore: Math.round(clamp((metrics.consistency * 0.38 + metrics.openingHandQuality * 0.22 + (100 - metrics.deadCardRate) * 0.18 + metrics.recovery * 0.22), 1, 100)),
    };
  }

  function weakestCards(summary, opening, graph) {
    const centrality = Object.fromEntries(graph.nodes.map((node) => [node.id, node.weight]));
    return Object.entries(opening.cardStats)
      .map(([id, stat]) => ({
        id,
        name: summary.cards.find((card) => card.id === id)?.name || id,
        score: (stat.plays / Math.max(1, stat.draws)) * 55 + (centrality[id] || 0) * 0.8 - stat.dead * 8,
        dead: stat.dead,
        draws: stat.draws,
        plays: stat.plays,
      }))
      .sort((a, b) => a.score - b.score)
      .slice(0, 5);
  }

  function strongestPackages(graph) {
    return graph.clusters.slice(0, 4);
  }

  function average(list) {
    return list.length ? list.reduce((sum, value) => sum + value, 0) / list.length : 0;
  }

  function benchmarkPanels(gauntlet, formatKey) {
    return [...gauntlet.formats[formatKey]]
      .sort((a, b) => b.winRate - a.winRate);
  }

  function formatMetricValue(value) {
    return Number(value || 0).toFixed(value >= 10 ? 0 : 1);
  }

  function confidenceLabel(value) {
    if (value >= 82) return 'High';
    if (value >= 64) return 'Moderate';
    return 'Low';
  }

  function bestAndWorstMatchups(gauntlet) {
    const merged = Object.values(gauntlet.formats).flat().reduce((map, entry) => {
      map[entry.benchmark] = map[entry.benchmark] || [];
      map[entry.benchmark].push(entry.winRate);
      return map;
    }, {});
    const averaged = Object.entries(merged).map(([benchmark, wins]) => ({ benchmark, value: average(wins) }));
    return {
      best: averaged.sort((a, b) => b.value - a.value)[0] || null,
      worst: averaged.sort((a, b) => a.value - b.value)[0] || null,
    };
  }

  function composePhaseLine(persona, phase, context = {}) {
    const pool = persona.lines[phase] || persona.lines.intake || ['Analyzing.'];
    let line = pool[Math.floor(context.seedValue ?? 0) % pool.length];
    if (phase === 'curve' && Number.isFinite(context.avgCost)) {
      if (context.avgCost >= 4.2) line += ' The curve is leaning heavy.';
      else if (context.avgCost <= 2.6) line += ' The curve is disciplined and light.';
    }
    if (phase === 'draw' && Number.isFinite(context.deadHandRate)) {
      if (context.deadHandRate >= 0.22) line += ' I am seeing too many slow or dead openers.';
      else if (context.deadHandRate <= 0.1) line += ' The opener profile is resilient.';
    }
    if (phase === 'cohesion' && Number.isFinite(context.keyCardReliance)) {
      if (context.keyCardReliance >= 58) line += ' One cluster is carrying too much weight.';
      else if (context.keyCardReliance <= 34) line += ' The load is distributed well across the shell.';
    }
    if (phase === 'matchup' && context.best && context.worst) {
      line += ` Strongest into ${context.best.benchmark}; weakest into ${context.worst.benchmark}.`;
    }
    if (phase === 'multiplayer' && context.ffa && context.twoVTwo) {
      line += context.ffa >= context.twoVTwo
        ? ' The list scales into free-for-all pressure better than most duel shells.'
        : ' Team play is cleaner than its free-for-all posture.';
    }
    if (phase === 'validate' && Number.isFinite(context.confidence)) {
      line += ` Confidence is ${confidenceLabel(context.confidence).toLowerCase()}.`;
    }
    return line;
  }

  function formatDeckStamp(report) {
    if (!report?.scores) return '';
    return `${report.scores['1v1']} / ${report.scores['2v2']} / ${report.scores['1v1v1v1']}`;
  }

  function getCachedDeckResult(deck) {
    const store = loadStore();
    const hash = contentHashForDeck(deck);
    const cached = store.deckCache[hash];
    if (!cached || cached.engineVersion !== ENGINE_VERSION) return null;
    return cached;
  }

  function getDeckEvaluationState(deck) {
    if (!deck) return { current: null, stale: null, latest: null, isStale: false };
    const store = loadStore();
    const current = getCachedDeckResult(deck);
    const history = deck?.id ? (store.deckHistory[deck.id] || []) : [];
    const latest = history.find((entry) => entry?.engineVersion === ENGINE_VERSION) || null;
    const stale = current ? null : latest;
    return {
      current,
      stale,
      latest: current || latest,
      isStale: !!stale,
    };
  }

  function getCachedCardResult(card) {
    const store = loadStore();
    const hash = contentHashForCard(card);
    const cached = store.cardCache[hash];
    if (!cached || cached.engineVersion !== ENGINE_VERSION) return null;
    return cached;
  }

  async function evaluateDeck(target, personaId, uiState, reportProgress) {
    const catalog = await loadCatalog();
    const summary = deckSummary(target, catalog);
    const store = loadStore();
    const samples = store.debug.fastMode ? FAST_SAMPLES : DEFAULT_SAMPLES;
    const minDuration = store.debug.fastMode ? FAST_MIN_MS : DEFAULT_MIN_MS;
    const persona = PERSONA_BY_ID[personaId] || PERSONAS[0];
    const seed = summary.deckHash;
    const startedAt = performance.now();

    reportProgress('intake', 0.08, composePhaseLine(persona, 'intake', { seedValue: seed.length }), {
      cardCount: summary.cards.length,
      avgCost: summary.avgCost,
      archetype: summary.archetype.label,
    });
    await sleep(120);

    reportProgress('curve', 0.18, composePhaseLine(persona, 'curve', { avgCost: summary.avgCost, seedValue: seed.length + 1 }), {
      avgCost: summary.avgCost,
      curve: summary.curve,
    });
    await sleep(100);

    const opening = simulateOpenings(summary, samples.opening, seed);
    reportProgress('draw', 0.38, composePhaseLine(persona, 'draw', { deadHandRate: opening.deadHands / Math.max(1, opening.sampleCount), seedValue: seed.length + 2 }), {
      opening,
    });
    await sleep(80);

    const graph = buildSynergyGraph(summary);
    reportProgress('cohesion', 0.52, composePhaseLine(persona, 'cohesion', { keyCardReliance: graph.keyCardReliance, seedValue: seed.length + 3 }), {
      graph,
    });
    await sleep(80);

    let gauntlet = runGauntlet(summary, { tempo: 50 }, samples.gauntlet, seed);
    let metrics = deriveDeckMetrics(summary, opening, graph, gauntlet);
    gauntlet = runGauntlet(summary, metrics, samples.gauntlet, seed);
    const matchupSummary = bestAndWorstMatchups(gauntlet);
    reportProgress('matchup', 0.74, composePhaseLine(persona, 'matchup', { ...matchupSummary, seedValue: seed.length + 4 }), {
      gauntlet,
    });
    await sleep(80);

    metrics = deriveDeckMetrics(summary, opening, graph, gauntlet);
    reportProgress('multiplayer', 0.86, composePhaseLine(persona, 'multiplayer', { ffa: metrics.multiplayerPressure, twoVTwo: metrics.teamUtility, seedValue: seed.length + 5 }), {
      metrics,
    });

    const elapsed = performance.now() - startedAt;
    const refinementLoops = Math.max(0, Math.floor((minDuration - elapsed) / 350));
    for (let i = 0; i < refinementLoops; i += 1) {
      await sleep(280);
      const refinement = runGauntlet(summary, metrics, samples.refinement, `${seed}:refine:${i}`);
      gauntlet.formats['1v1'].push(...refinement.formats['1v1']);
      gauntlet.formats['2v2'].push(...refinement.formats['2v2']);
      gauntlet.formats.ffa.push(...refinement.formats.ffa);
      gauntlet.winRates['1v1'] = average(gauntlet.formats['1v1'].map((entry) => entry.winRate));
      gauntlet.winRates['2v2'] = average(gauntlet.formats['2v2'].map((entry) => entry.winRate));
      gauntlet.winRates.ffa = average(gauntlet.formats.ffa.map((entry) => entry.winRate));
      metrics = deriveDeckMetrics(summary, opening, graph, gauntlet);
      reportProgress('validate', 0.86 + ((i + 1) / Math.max(1, refinementLoops)) * 0.12, composePhaseLine(persona, 'validate', { confidence: 100 - metrics.volatility, seedValue: seed.length + 6 + i }), {
        metrics,
        refinement: i + 1,
      });
    }

    metrics = deriveDeckMetrics(summary, opening, graph, gauntlet);
    const rating = rateDeck(summary, metrics, gauntlet);
    const weakCards = weakestCards(summary, opening, graph);
    const report = {
      kind: 'deck',
      engineVersion: ENGINE_VERSION,
      evaluatedAt: new Date().toISOString(),
      deckId: summary.deck.id,
      deckName: summary.deck.name,
      deckHash: summary.deckHash,
      personaId: persona.id,
      personaName: persona.name,
      archetype: summary.archetype.label,
      dominantRace: summary.dominantRace,
      scores: rating.publicScores,
      confidence: Math.round(rating.confidenceValue),
      reliability: rating.reliabilityBand,
      bestFormat: rating.bestFormat,
      worstFormat: rating.worstFormat,
      powerCeiling: rating.powerCeiling,
      floor: rating.floorScore,
      radar: {
        Tempo: Math.round(metrics.tempo),
        Consistency: Math.round(metrics.consistency),
        'Card Draw': Math.round(metrics.draw),
        'Board Control': Math.round(metrics.boardControl),
        Burst: Math.round(metrics.burst),
        Sustain: Math.round(metrics.sustain),
        Synergy: Math.round(metrics.synergy),
        Resilience: Math.round(metrics.resilience),
        Flexibility: Math.round(metrics.flexibility),
        'Multiplayer Pressure': Math.round(metrics.multiplayerPressure),
      },
      strengths: rating.strengths,
      weaknesses: rating.weaknesses,
      warnings: rating.warnings,
      opportunities: rating.opportunities,
      matchups: {
        best: matchupSummary.best,
        worst: matchupSummary.worst,
        byFormat: {
          '1v1': benchmarkPanels(gauntlet, '1v1'),
          '2v2': benchmarkPanels(gauntlet, '2v2'),
          '1v1v1v1': benchmarkPanels(gauntlet, 'ffa'),
        },
      },
      metrics: {
        ...metrics,
        openingHandQualityIndex: Math.round(metrics.openingHandQuality),
        mulliganStabilityReport: Math.round(metrics.mulliganStability),
        deadCardFrequency: Math.round(metrics.deadCardRate),
        redundancyMeter: Math.round(metrics.redundancy),
        comboFragilityMeter: Math.round(metrics.comboFragility),
        teamUtilityScore: Math.round(metrics.teamUtility),
        threatProfileFFA: Math.round(metrics.threatPerception),
        metaResilienceScore: Math.round(metrics.metaResilience),
        keyCardReliance: Math.round(metrics.keyCardReliance),
        topdeckQualityScore: Math.round(metrics.topdeckQuality),
        recoveryFromBehindScore: Math.round(metrics.recovery),
      },
      graph,
      curve: summary.curve,
      drawHeatmap: opening.drawHeatmap.map((value) => Math.round(value / Math.max(1, opening.sampleCount))),
      cardOutliers: weakCards,
      packages: strongestPackages(graph),
      historyNote: `Stored by deck hash ${summary.deckHash}. Re-evaluation required after any content change.`,
      localExclusiveCount: summary.totals.localExclusiveCount,
    };
    saveEvaluationReport(report, summary.deck);
    reportProgress('finish', 1, composePhaseLine(persona, 'finish', { seedValue: seed.length + 9 }), { report });
    return report;
  }

  async function evaluateCard(target, personaId, reportProgress) {
    const persona = PERSONA_BY_ID[personaId] || PERSONAS[0];
    const card = { ...target, type: normalizeCardType(target), race: normalizeRace(target), text: textOf(target), rarity: normalizeRarity(target) };
    const summary = analyzeCard(card);
    reportProgress('intake', 0.22, composePhaseLine(persona, 'intake', { seedValue: card.name.length }), { card: summary });
    await sleep(120);
    reportProgress('curve', 0.42, composePhaseLine(persona, 'curve', { avgCost: summary.cost, seedValue: card.name.length + 1 }), { card: summary });
    await sleep(110);
    reportProgress('cohesion', 0.66, composePhaseLine(persona, 'cohesion', { keyCardReliance: summary.roles.comboReliance, seedValue: card.name.length + 2 }), { card: summary });
    await sleep(120);
    const duel = Math.round(clamp(180 + summary.roles.tempo * 5 + summary.roles.flexibility * 4 + summary.roles.threat * 2.8 + summary.roles.synergy * 2.2 - summary.roles.deadRisk * 2, 120, 920));
    const team = Math.round(clamp(180 + summary.roles.teamUtility * 4.8 + summary.roles.sustain * 4 + summary.roles.multiplayer * 2.6 + summary.roles.flexibility * 3.2 - summary.roles.deadRisk * 1.5, 120, 920));
    const ffa = Math.round(clamp(180 + summary.roles.multiplayer * 5 + summary.roles.political * 3.8 + summary.roles.topdeck * 2.8 + summary.roles.resilience * 2.2 - summary.roles.volatility * 2, 120, 920));
    const report = {
      kind: 'card',
      engineVersion: ENGINE_VERSION,
      evaluatedAt: new Date().toISOString(),
      personaId,
      personaName: persona.name,
      cardId: card.id,
      cardName: card.name,
      cardHash: contentHashForCard(card),
      scores: { '1v1': duel, '2v2': team, '1v1v1v1': ffa },
      confidence: Math.round(clamp(86 - summary.roles.volatility * 1.1, 35, 96)),
      reliability: confidenceLabel(clamp(86 - summary.roles.volatility * 1.1, 35, 96)),
      archetype: summary.race ? `${summary.race} ${summary.type}` : `${summary.type}`,
      radar: {
        Tempo: Math.round(clamp(summary.roles.tempo * 3, 0, 100)),
        Consistency: Math.round(clamp(70 - summary.roles.deadRisk * 2 + summary.roles.flexibility, 0, 100)),
        'Card Draw': Math.round(clamp(summary.roles.draw * 3.4, 0, 100)),
        'Board Control': Math.round(clamp(summary.roles.control * 3.2, 0, 100)),
        Burst: Math.round(clamp(summary.roles.burst * 3.1, 0, 100)),
        Sustain: Math.round(clamp(summary.roles.sustain * 3.2, 0, 100)),
        Synergy: Math.round(clamp(summary.roles.synergy * 2.8, 0, 100)),
        Resilience: Math.round(clamp(summary.roles.resilience * 2.8, 0, 100)),
        Flexibility: Math.round(clamp(summary.roles.flexibility * 6.2, 0, 100)),
        'Multiplayer Pressure': Math.round(clamp(summary.roles.multiplayer * 3.2, 0, 100)),
      },
      strengths: [
        summary.roles.flexibility >= 8 ? 'Flexible in multiple board states.' : 'Specialized but clearly role-defined.',
        summary.roles.synergy >= 12 ? 'Provides above-average synergy support.' : 'Does not demand excessive setup.',
      ],
      weaknesses: [
        summary.roles.deadRisk >= 12 ? 'Dead in too many low-resource states.' : 'Reasonably live across normal turns.',
        summary.roles.comboReliance >= 14 ? 'Power ceiling depends on support density.' : 'Operates fine as a standalone inclusion.',
      ],
      warnings: [
        summary.roles.volatility >= 10 ? 'Randomness or variance lowers reliability.' : 'Low variance profile.',
      ],
      opportunities: [
        summary.race ? `Best inside ${summary.race} shells or lists that can increase its support density.` : 'Best in shells that exploit its role rather than raw stats.',
      ],
      metrics: {
        roleIdentity: summary.type,
        powerBand: summary.roles.finish >= 18 ? 'High-impact' : summary.roles.flexibility >= 10 ? 'Reliable role-player' : 'Support / narrow',
        curvePlacement: summary.cost <= 2 ? 'Early' : summary.cost <= 5 ? 'Midgame' : 'Top-end',
        flexibility: Math.round(clamp(summary.roles.flexibility * 6.2, 0, 100)),
        risk: Math.round(clamp(summary.roles.deadRisk * 3.1 + summary.roles.volatility * 2.6, 0, 100)),
        synergyTags: uniq([summary.race, summary.type, ...summary.tags]).filter(Boolean).slice(0, 8),
      },
    };
    saveCardEvaluation(report, card);
    reportProgress('finish', 1, composePhaseLine(persona, 'finish', { seedValue: card.name.length + 4 }), { report });
    return report;
  }

  function saveEvaluationReport(report, deck) {
    const store = loadStore();
    store.deckCache[report.deckHash] = report;
    if (deck?.id) {
      store.deckLinks[deck.id] = {
        hash: report.deckHash,
        at: report.evaluatedAt,
        evaluatorId: report.personaId,
        engineVersion: report.engineVersion,
        deckName: deck.name,
      };
      store.deckHistory[deck.id] = [report, ...(store.deckHistory[deck.id] || []).filter((entry) => entry.deckHash !== report.deckHash)].slice(0, 16);
    }
    store.recentRuns = [{ kind: 'deck', hash: report.deckHash, name: report.deckName, at: report.evaluatedAt, scores: report.scores }, ...store.recentRuns.filter((entry) => entry.hash !== report.deckHash)].slice(0, 30);
    saveStore(store);
    window.dispatchEvent(new CustomEvent('cardforge:deck-rater-updated', { detail: { kind: 'deck', report, deckId: deck?.id || null } }));
  }

  function saveCardEvaluation(report, card) {
    const store = loadStore();
    store.cardCache[report.cardHash] = report;
    store.recentRuns = [{ kind: 'card', hash: report.cardHash, name: report.cardName, at: report.evaluatedAt, scores: report.scores }, ...store.recentRuns.filter((entry) => entry.hash !== report.cardHash)].slice(0, 30);
    saveStore(store);
    window.dispatchEvent(new CustomEvent('cardforge:deck-rater-updated', { detail: { kind: 'card', report, cardId: card?.id || null } }));
  }

  function getDeckStamp(deck) {
    const report = getDeckEvaluationState(deck).current;
    if (!report) return null;
    return {
      label: formatDeckStamp(report),
      scores: report.scores,
      confidence: report.confidence,
      reliability: report.reliability,
      evaluator: report.personaName,
      evaluatedAt: report.evaluatedAt,
      engineVersion: report.engineVersion,
    };
  }

  function getQuickSummary() {
    const store = loadStore();
    return {
      engineVersion: ENGINE_VERSION,
      deckEvaluations: Object.keys(store.deckCache).length,
      cardEvaluations: Object.keys(store.cardCache).length,
      recentRuns: store.recentRuns.slice(0, 4),
      debug: { ...store.debug },
    };
  }

  function normalizeSelectionCards(catalog, query) {
    const needle = String(query || '').trim().toLowerCase();
    return catalog.cards
      .filter((card) => !isConquestOnlyCard(card))
      .filter((card) => {
        if (!needle) return true;
        const hay = `${card.name} ${card.id} ${card.text} ${normalizeRace(card)} ${card.tags.join(' ')}`.toLowerCase();
        return hay.includes(needle);
      })
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, 120);
  }

  function isLegalDeckForEvaluator(deck, catalog) {
    const normalized = normalizeDeck(deck, !!deck?.isBuiltIn);
    if (!normalized.entries.length) return { ok: false, reason: 'Deck is empty.' };
    const illegal = normalized.entries.find((entry) => {
      const card = catalog.byId[entry.cardId];
      return !card || isConquestOnlyCard(card);
    });
    if (illegal) {
      const card = catalog.byId[illegal.cardId];
      return { ok: false, reason: card ? `${card.name} is conquest-only or invalid for this evaluator.` : `Unknown card ${illegal.cardId}.` };
    }
    return { ok: true, reason: '' };
  }

  function isLegalCardForEvaluator(card) {
    if (!card) return { ok: false, reason: 'No card selected.' };
    if (isConquestOnlyCard(card)) return { ok: false, reason: 'Conquest-only cards are excluded from this evaluator.' };
    return { ok: true, reason: '' };
  }

  async function checkDeckLegality(deck) {
    const catalog = await loadCatalog();
    return isLegalDeckForEvaluator(deck, catalog);
  }

  async function checkCardLegality(card) {
    const catalog = await loadCatalog();
    if (!card?.id && card?.cardId && catalog.byId[card.cardId]) return isLegalCardForEvaluator(catalog.byId[card.cardId]);
    if (card?.id && catalog.byId[card.id]) return isLegalCardForEvaluator(catalog.byId[card.id]);
    return isLegalCardForEvaluator(card);
  }

  function buildSummaryExport(report) {
    if (!report) return '';
    if (report.kind === 'card') {
      return [
        `${report.cardName} — ${report.personaName}`,
        `1v1 ${report.scores['1v1']} | 2v2 ${report.scores['2v2']} | FFA ${report.scores['1v1v1v1']}`,
        `Confidence ${report.confidence} (${report.reliability})`,
        `Role ${report.metrics.roleIdentity} | Curve ${report.metrics.curvePlacement} | Band ${report.metrics.powerBand}`,
        `Strengths: ${report.strengths.join(' ')}`,
        `Weaknesses: ${report.weaknesses.join(' ')}`,
      ].join('\n');
    }
    return [
      `${report.deckName} — ${report.personaName}`,
      `Archetype ${report.archetype}`,
      `1v1 ${report.scores['1v1']} | 2v2 ${report.scores['2v2']} | FFA ${report.scores['1v1v1v1']}`,
      `Confidence ${report.confidence} (${report.reliability}) | Best ${report.bestFormat}`,
      `Strengths: ${report.strengths.join(' ')}`,
      `Weaknesses: ${report.weaknesses.join(' ')}`,
      `Warnings: ${report.warnings.join(' ') || 'None.'}`,
      `Opportunities: ${report.opportunities.join(' ') || 'None.'}`,
    ].join('\n');
  }

  function renderRadarSvg(radar = {}) {
    const keys = Object.keys(radar);
    const cx = 180;
    const cy = 180;
    const radius = 128;
    const points = keys.map((key, index) => {
      const angle = (-Math.PI / 2) + (Math.PI * 2 * index / keys.length);
      const value = clamp(Number(radar[key] || 0), 0, 100);
      return {
        key,
        x: cx + Math.cos(angle) * radius * (value / 100),
        y: cy + Math.sin(angle) * radius * (value / 100),
        lx: cx + Math.cos(angle) * (radius + 30),
        ly: cy + Math.sin(angle) * (radius + 30),
        ox: cx + Math.cos(angle) * radius,
        oy: cy + Math.sin(angle) * radius,
      };
    });
    const polygon = points.map((point) => `${point.x},${point.y}`).join(' ');
    const baseline = points.map((point) => `${cx + (point.ox - cx) * 0.55},${cy + (point.oy - cy) * 0.55}`).join(' ');
    return `<svg viewBox=\"0 0 360 360\" class=\"rater-radar\">
      <polygon points=\"${baseline}\" class=\"rater-radar-baseline\"></polygon>
      ${[0.25, 0.5, 0.75, 1].map((ring) => `<polygon points=\"${points.map((point) => `${cx + (point.ox - cx) * ring},${cy + (point.oy - cy) * ring}`).join(' ')}\" class=\"rater-radar-ring\"></polygon>`).join('')}
      ${points.map((point) => `<line x1=\"${cx}\" y1=\"${cy}\" x2=\"${point.ox}\" y2=\"${point.oy}\" class=\"rater-radar-axis\"></line>`).join('')}
      <polygon points=\"${polygon}\" class=\"rater-radar-shape\"></polygon>
      ${points.map((point) => `<circle cx=\"${point.x}\" cy=\"${point.y}\" r=\"3.5\" class=\"rater-radar-point\"></circle>`).join('')}
      ${points.map((point) => `<text x=\"${point.lx}\" y=\"${point.ly}\" class=\"rater-radar-label\">${escapeHtml(point.key)}</text>`).join('')}
    </svg>`;
  }

  function renderCurveSvg(curve) {
    const labels = ['0', '1', '2', '3', '4', '5', '6+'];
    const max = Math.max(1, ...labels.map((label) => Number(curve[label] || 0)));
    return `<div class=\"rater-curve-bars\">${labels.map((label) => `<div class=\"rater-curve-col\"><div class=\"rater-curve-fill\" style=\"height:${Math.round((Number(curve[label] || 0) / max) * 100)}%\"></div><strong>${label}</strong><span>${Number(curve[label] || 0)}</span></div>`).join('')}</div>`;
  }

  function renderHeatmap(values = []) {
    return `<div class=\"rater-heatmap\">${values.map((value, index) => `<div class=\"rater-heat-cell\" style=\"--heat:${clamp(Number(value || 0), 0, 100)}\"><span>T${index + 1}</span><strong>${Math.round(value || 0)}</strong></div>`).join('')}</div>`;
  }

  function renderMatchupBars(entries = []) {
    return `<div class=\"rater-matchups\">${entries.map((entry) => `<div class=\"rater-matchup-row\"><div><strong>${escapeHtml(entry.benchmark)}</strong><div class=\"rater-meta\">${escapeHtml(entry.tier)}</div></div><div class=\"rater-match-bar\"><i style=\"width:${Math.round(entry.winRate * 100)}%\"></i></div><strong>${Math.round(entry.winRate * 100)}%</strong></div>`).join('')}</div>`;
  }

  function injectStyles() {
    if (document.getElementById('deck-rater-styles')) return;
    const style = document.createElement('style');
    style.id = 'deck-rater-styles';
    style.textContent = `
      .deck-rater-overlay{position:fixed;inset:0;z-index:9999;background:rgba(5,8,18,.82);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:center;padding:2vh 2vw}
      .deck-rater-overlay.hidden{display:none}
      .deck-rater-shell{width:min(1440px,96vw);height:min(92vh,980px);display:grid;grid-template-rows:auto 1fr;gap:12px;background:linear-gradient(180deg,rgba(10,15,28,.96),rgba(7,10,18,.98));border:1px solid rgba(156,197,255,.18);border-radius:26px;box-shadow:0 30px 80px rgba(0,0,0,.45);overflow:hidden;color:#eef4ff;font-family:Segoe UI,system-ui,sans-serif}
      .deck-rater-head{display:flex;justify-content:space-between;align-items:center;padding:18px 24px;border-bottom:1px solid rgba(164,191,255,.12);background:linear-gradient(90deg,rgba(98,142,255,.08),rgba(255,216,140,.05))}
      .deck-rater-head h2{margin:0;font-size:1.25rem}
      .deck-rater-head .meta{opacity:.8;font-size:.92rem}
      .deck-rater-body{display:grid;grid-template-columns:320px 1fr 360px;min-height:0}
      .rater-pane{padding:18px 20px;overflow:auto}
      .rater-pane.left{border-right:1px solid rgba(164,191,255,.1)}
      .rater-pane.right{border-left:1px solid rgba(164,191,255,.1);background:linear-gradient(180deg,rgba(17,25,44,.65),rgba(8,12,22,.88))}
      .rater-section{background:rgba(255,255,255,.03);border:1px solid rgba(164,191,255,.1);border-radius:18px;padding:14px;margin-bottom:14px}
      .rater-section h3,.rater-section h4{margin:0 0 10px}
      .rater-grid{display:grid;gap:12px}
      .rater-grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}
      .rater-grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}
      .rater-button,.rater-select,.rater-input{border-radius:12px;border:1px solid rgba(164,191,255,.18);background:rgba(15,20,36,.9);color:#eef4ff;padding:10px 12px}
      .rater-button{cursor:pointer;transition:.18s transform,.18s background,.18s border-color}
      .rater-button:hover{transform:translateY(-1px);background:rgba(44,60,103,.92)}
      .rater-button.primary{background:linear-gradient(135deg,#4f7dff,#7ba6ff);color:#08101d;border-color:rgba(255,255,255,.2);font-weight:700}
      .rater-button.subtle{background:rgba(255,255,255,.04)}
      .rater-button:disabled{opacity:.45;cursor:not-allowed;transform:none}
      .rater-chip-row,.rater-traits,.rater-tabs{display:flex;flex-wrap:wrap;gap:8px}
      .rater-chip,.rater-tab{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:7px 10px;border:1px solid rgba(164,191,255,.16);background:rgba(255,255,255,.04);font-size:.84rem}
      .rater-tab.active,.rater-chip.active{background:rgba(114,154,255,.18);border-color:rgba(137,174,255,.38)}
      .rater-persona-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
      .rater-persona-card{position:relative;min-height:126px;border-radius:18px;padding:14px;border:1px solid rgba(196,215,255,.16);cursor:pointer;overflow:hidden;transition:.18s transform,.18s box-shadow,.18s border-color}
      .rater-persona-card:hover{transform:translateY(-2px);box-shadow:0 16px 28px rgba(0,0,0,.25)}
      .rater-persona-card.active{border-color:rgba(255,225,164,.52);box-shadow:0 0 0 1px rgba(255,225,164,.2),0 20px 36px rgba(0,0,0,.28)}
      .rater-persona-card .icon{font-size:2rem;display:block;margin-bottom:8px}
      .rater-persona-card .name{font-weight:700;margin-bottom:8px}
      .rater-list{display:grid;gap:8px;max-height:340px;overflow:auto}
      .rater-list-item{padding:10px 12px;border-radius:14px;border:1px solid rgba(164,191,255,.12);background:rgba(255,255,255,.03);cursor:pointer}
      .rater-list-item.active{background:rgba(99,134,214,.16);border-color:rgba(146,185,255,.38)}
      .rater-list-item .meta{opacity:.8;font-size:.84rem}
      .rater-stamp{display:inline-flex;gap:8px;align-items:center;border-radius:999px;padding:6px 10px;background:rgba(255,215,128,.1);border:1px solid rgba(255,215,128,.28);font-size:.82rem}
      .rater-score-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
      .rater-score-card{border-radius:18px;border:1px solid rgba(164,191,255,.14);background:linear-gradient(180deg,rgba(22,31,56,.88),rgba(10,15,27,.96));padding:14px}
      .rater-score-card strong{display:block;font-size:2rem}
      .rater-progress{height:12px;border-radius:999px;background:rgba(255,255,255,.05);overflow:hidden}
      .rater-progress i{display:block;height:100%;background:linear-gradient(90deg,#84a9ff,#ffda86);transition:width .22s ease}
      .rater-speech{border-radius:18px;padding:14px;background:rgba(31,44,77,.72);border:1px solid rgba(164,191,255,.12);font-size:1rem;line-height:1.45}
      .rater-metrics-stream{display:grid;gap:8px}
      .rater-metrics-stream .row{display:flex;justify-content:space-between;gap:10px;font-size:.88rem}
      .rater-radar{width:100%;max-width:380px}
      .rater-radar-axis,.rater-radar-ring{stroke:rgba(168,194,255,.16);stroke-width:1;fill:none}
      .rater-radar-baseline{fill:rgba(138,165,255,.08);stroke:rgba(138,165,255,.14)}
      .rater-radar-shape{fill:rgba(255,214,128,.18);stroke:rgba(255,214,128,.85);stroke-width:2}
      .rater-radar-point{fill:#ffd98c}
      .rater-radar-label{fill:#dbe8ff;font-size:11px;text-anchor:middle;dominant-baseline:middle}
      .rater-matchup-row{display:grid;grid-template-columns:minmax(0,1fr) 130px 48px;align-items:center;gap:10px;padding:8px 0}
      .rater-match-bar{height:8px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden}
      .rater-match-bar i{display:block;height:100%;background:linear-gradient(90deg,#7ad9ff,#84a9ff)}
      .rater-curve-bars{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));align-items:end;gap:10px;height:132px}
      .rater-curve-col{display:grid;gap:6px;justify-items:center}
      .rater-curve-fill{width:100%;min-height:8px;border-radius:10px 10px 2px 2px;background:linear-gradient(180deg,#86b4ff,#456cf8)}
      .rater-heatmap{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:8px}
      .rater-heat-cell{border-radius:14px;padding:10px;background:linear-gradient(180deg,rgba(25,36,64,.92),rgba(10,15,28,.94));border:1px solid rgba(164,191,255,.12);box-shadow:inset 0 0 0 999px rgba(122,184,255,calc(var(--heat)/180))}
      .rater-insight-list{display:grid;gap:8px}
      .rater-insight{padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.03);border:1px solid rgba(164,191,255,.1)}
      .rater-badge-row{display:flex;flex-wrap:wrap;gap:8px}
      .rater-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.05);border:1px solid rgba(164,191,255,.12);font-size:.82rem}
      .rater-debug-block{white-space:pre-wrap;font-family:Consolas,monospace;font-size:.8rem;background:rgba(0,0,0,.26);border-radius:14px;padding:10px;border:1px solid rgba(164,191,255,.08)}
      .rater-deck-stamp{display:inline-flex;gap:6px;margin-left:8px;padding:3px 8px;border-radius:999px;background:rgba(122,180,255,.12);border:1px solid rgba(122,180,255,.22);font-size:.75rem;vertical-align:middle}
      @media (max-width: 1180px){.deck-rater-body{grid-template-columns:1fr}.rater-pane.left,.rater-pane.right{border:none}.rater-persona-grid,.rater-score-cards,.rater-grid.three,.rater-grid.two{grid-template-columns:1fr}}
    `;
    document.head.appendChild(style);
  }

  function ensureUi() {
    if (GLOBAL.ui) return GLOBAL.ui;
    injectStyles();
    const overlay = document.createElement('div');
    overlay.className = 'deck-rater-overlay hidden';
    overlay.innerHTML = `
      <div class="deck-rater-shell">
        <div class="deck-rater-head">
          <div>
            <h2>Archive of Judgement</h2>
            <div class="meta" id="rater-head-meta">Normal mode and Local Player analysis only. Conquest is excluded.</div>
          </div>
          <div class="rater-chip-row">
            <span class="rater-chip" id="rater-gold-chip">Gold 0</span>
            <button class="rater-button subtle" data-rater-action="close">Close</button>
          </div>
        </div>
        <div class="deck-rater-body">
          <aside class="rater-pane left" id="rater-left"></aside>
          <main class="rater-pane center" id="rater-center"></main>
          <aside class="rater-pane right" id="rater-right"></aside>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const ui = {
      overlay,
      left: overlay.querySelector('#rater-left'),
      center: overlay.querySelector('#rater-center'),
      right: overlay.querySelector('#rater-right'),
      headMeta: overlay.querySelector('#rater-head-meta'),
      goldChip: overlay.querySelector('#rater-gold-chip'),
      state: {
        open: false,
        entry: 'launcher',
        mode: 'deck',
        personaId: 'arbiter',
        selectedDeckId: '',
        selectedCardId: '',
        suppliedDeck: null,
        suppliedCard: null,
        cardQuery: '',
        decks: [],
        cards: [],
        report: null,
        running: false,
        progress: 0,
        phase: 'intake',
        speech: '',
        live: {},
        formatTab: '1v1',
        runToken: null,
      },
    };
    GLOBAL.ui = ui;
    return ui;
  }

  async function refreshUiData() {
    const ui = ensureUi();
    const profile = loadProfile();
    const [catalog, builtInDecks] = await Promise.all([loadCatalog(), loadDeckCatalog()]);
    ui.state.decks = combinedDecks(profile, builtInDecks).filter((deck) => isLegalDeckForEvaluator(deck, catalog).ok);
    ui.state.cards = normalizeSelectionCards(catalog, ui.state.cardQuery);
    if (ui.state.suppliedDeck && !ui.state.selectedDeckId) ui.state.selectedDeckId = '__supplied_deck__';
    if (ui.state.suppliedCard && !ui.state.selectedCardId) ui.state.selectedCardId = '__supplied_card__';
    if (!ui.state.selectedDeckId && ui.state.decks[0]) ui.state.selectedDeckId = ui.state.decks[0].id;
    if (!ui.state.selectedCardId && ui.state.cards[0]) ui.state.selectedCardId = ui.state.cards[0].id;
    ui.goldChip.textContent = `Gold ${profile.economy.gold}`;
  }

  function selectedDeck(ui) {
    if (ui.state.selectedDeckId === '__supplied_deck__') return ui.state.suppliedDeck;
    return ui.state.decks.find((deck) => deck.id === ui.state.selectedDeckId) || null;
  }

  function selectedCard(ui) {
    if (ui.state.selectedCardId === '__supplied_card__') return ui.state.suppliedCard;
    return ui.state.cards.find((card) => card.id === ui.state.selectedCardId) || null;
  }

  function showCached() {
    const ui = ensureUi();
    if (ui.state.mode === 'deck') {
      const state = getDeckEvaluationState(selectedDeck(ui));
      ui.state.report = state.current || (state.stale ? { ...state.stale, _stale: true } : null);
    } else {
      ui.state.report = getCachedCardResult(selectedCard(ui));
    }
    renderUi();
  }

  function refundGold(kind) {
    const cost = kind === 'deck' ? DECK_EVALUATION_COST : CARD_EVALUATION_COST;
    const profile = loadProfile();
    profile.economy.gold += cost;
    saveProfile(profile);
    return profile.economy.gold;
  }

  function chargeGold(kind) {
    const profile = loadProfile();
    const cost = kind === 'deck' ? DECK_EVALUATION_COST : CARD_EVALUATION_COST;
    if (profile.economy.gold < cost) return { ok: false, reason: `Need ${cost} gold.` };
    profile.economy.gold -= cost;
    saveProfile(profile);
    return { ok: true, cost, gold: profile.economy.gold };
  }

  function wireUiEvents() {
    const ui = ensureUi();
    if (ui.overlay.dataset.bound === 'yes') return;
    ui.overlay.dataset.bound = 'yes';
    ui.overlay.addEventListener('click', async (event) => {
      const target = event.target.closest('[data-rater-action]');
      if (!target) return;
      const action = target.dataset.raterAction;
      if (action === 'close') close();
      else if (action === 'set-persona') { ui.state.personaId = target.dataset.personaId; renderUi(); }
      else if (action === 'set-mode') { ui.state.mode = target.dataset.mode; ui.state.report = null; renderUi(); }
      else if (action === 'choose-deck') { ui.state.selectedDeckId = target.dataset.deckId; ui.state.report = null; renderUi(); }
      else if (action === 'choose-card') { ui.state.selectedCardId = target.dataset.cardId; ui.state.report = null; renderUi(); }
      else if (action === 'start') await startEvaluation();
      else if (action === 'show-cached') showCached();
      else if (action === 'tab') { ui.state.formatTab = target.dataset.tab; renderUi(); }
      else if (action === 'back') { ui.state.report = null; ui.state.running = false; renderUi(); }
      else if (action === 'copy') {
        const text = buildSummaryExport(ui.state.report);
        try {
          if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
          else {
            const area = document.createElement('textarea');
            area.value = text;
            document.body.appendChild(area);
            area.select();
            document.execCommand('copy');
            area.remove();
          }
        } catch {}
      }
    });
    ui.overlay.addEventListener('input', async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLInputElement)) return;
      if (target.dataset.raterField === 'card-query') {
        ui.state.cardQuery = target.value || '';
        await refreshUiData();
        renderUi();
      }
    });
  }

  async function startEvaluation() {
    const ui = ensureUi();
    const catalog = await loadCatalog();
    const target = ui.state.mode === 'deck' ? selectedDeck(ui) : selectedCard(ui);
    const legality = ui.state.mode === 'deck' ? isLegalDeckForEvaluator(target, catalog) : isLegalCardForEvaluator(target);
    if (!legality.ok) {
      ui.state.speech = legality.reason;
      renderUi();
      return;
    }
    const payment = chargeGold(ui.state.mode);
    if (!payment.ok) {
      ui.state.speech = payment.reason;
      renderUi();
      return;
    }
    ui.goldChip.textContent = `Gold ${payment.gold}`;
    ui.state.running = true;
    ui.state.report = null;
    ui.state.progress = 0;
    ui.state.phase = 'intake';
    const token = Symbol('deck-rater');
    ui.state.runToken = token;
    const progress = (phase, pct, speech, live) => {
      if (ui.state.runToken !== token) throw new Error('cancelled');
      ui.state.phase = phase;
      ui.state.progress = pct;
      ui.state.speech = speech;
      ui.state.live = live || {};
      renderUi();
    };
    try {
      const report = ui.state.mode === 'deck'
        ? await evaluateDeck(target, ui.state.personaId, ui.state, progress)
        : await evaluateCard(target, ui.state.personaId, progress);
      if (ui.state.runToken !== token) return;
      ui.state.running = false;
      ui.state.report = report;
      ui.state.progress = 1;
      ui.state.speech = report.kind === 'deck'
        ? `${report.personaName}: ${report.deckName} is archived at ${formatDeckStamp(report)}.`
        : `${report.personaName}: ${report.cardName} is now catalogued.`;
      renderUi();
    } catch (error) {
      if (String(error?.message || '') !== 'cancelled') {
        ui.state.running = false;
        ui.state.live = {};
        const gold = refundGold(ui.state.mode);
        ui.goldChip.textContent = `Gold ${gold}`;
        ui.state.speech = `Evaluation failed: ${error?.message || 'unknown error'}`;
        renderUi();
      }
    }
  }

  function renderSelectionPane(ui) {
    const persona = PERSONA_BY_ID[ui.state.personaId] || PERSONAS[0];
    const currentDeck = selectedDeck(ui);
    const currentCard = selectedCard(ui);
    const deckState = ui.state.mode === 'deck' ? getDeckEvaluationState(currentDeck) : null;
    const cached = ui.state.mode === 'deck' ? deckState?.current : getCachedCardResult(currentCard);
    const stale = ui.state.mode === 'deck' ? deckState?.stale : null;
    const cost = ui.state.mode === 'deck' ? DECK_EVALUATION_COST : CARD_EVALUATION_COST;
    const profile = loadProfile();
    ui.left.innerHTML = `
      <section class="rater-section">
        <h3>Evaluator Persona</h3>
        <div class="rater-persona-grid">
          ${PERSONAS.map((entry) => `<button class="rater-persona-card ${entry.id === ui.state.personaId ? 'active' : ''}" data-rater-action="set-persona" data-persona-id="${entry.id}" style="background:${entry.theme};"><span class="icon">${entry.icon}</span><div class="name">${escapeHtml(entry.name)}</div><div class="rater-traits">${entry.chips.map((chip) => `<span class="rater-chip">${escapeHtml(chip)}</span>`).join('')}</div><div class="meta" style="margin-top:10px;">${escapeHtml(entry.preview)}</div></button>`).join('')}
        </div>
      </section>
      <section class="rater-section">
        <h3>Target</h3>
        <div class="rater-tabs">
          <button class="rater-tab ${ui.state.mode === 'deck' ? 'active' : ''}" data-rater-action="set-mode" data-mode="deck">Evaluate Deck</button>
          <button class="rater-tab ${ui.state.mode === 'card' ? 'active' : ''}" data-rater-action="set-mode" data-mode="card">Evaluate Card</button>
        </div>
        ${ui.state.mode === 'deck' ? `
          <div class="rater-list" style="margin-top:12px;">
            ${ui.state.suppliedDeck ? `<button class="rater-list-item ${ui.state.selectedDeckId === '__supplied_deck__' ? 'active' : ''}" data-rater-action="choose-deck" data-deck-id="__supplied_deck__"><strong>${escapeHtml(ui.state.suppliedDeck.name || 'Current Built Deck')}</strong><div class="meta">Current builder draft</div></button>` : ''}
            ${ui.state.decks.map((deck) => {
              const status = getDeckEvaluationState(deck);
              const stamp = status.current ? getDeckStamp(deck) : null;
              const staleLine = status.stale ? ` • stale ${escapeHtml(status.stale.personaName)}` : '';
              return `<button class="rater-list-item ${ui.state.selectedDeckId === deck.id ? 'active' : ''}" data-rater-action="choose-deck" data-deck-id="${escapeHtml(deck.id)}"><strong>${escapeHtml(deck.name)}</strong>${stamp ? `<span class="rater-deck-stamp">${escapeHtml(stamp.label)}</span>` : ''}<div class="meta">${deck.entries.reduce((sum, entry) => sum + entry.count, 0)} cards${deck.isBuiltIn ? ' • built-in' : ' • custom'}${stamp ? ` • ${escapeHtml(stamp.reliability)}` : staleLine}</div></button>`;
            }).join('')}
          </div>` : `
          <input class="rater-input" data-rater-field="card-query" placeholder="Search cards by name, text, race, tags..." value="${escapeHtml(ui.state.cardQuery)}" style="width:100%;margin-top:12px;" />
          <div class="rater-list" style="margin-top:12px;">
            ${ui.state.suppliedCard ? `<button class="rater-list-item ${ui.state.selectedCardId === '__supplied_card__' ? 'active' : ''}" data-rater-action="choose-card" data-card-id="__supplied_card__"><strong>${escapeHtml(ui.state.suppliedCard.name || 'Current Card')}</strong><div class="meta">Creator draft card</div></button>` : ''}
            ${ui.state.cards.map((card) => `<button class="rater-list-item ${ui.state.selectedCardId === card.id ? 'active' : ''}" data-rater-action="choose-card" data-card-id="${escapeHtml(card.id)}"><strong>${escapeHtml(card.name)}</strong><div class="meta">${escapeHtml(card.type)} • ${card.cost} cost • ${escapeHtml(card.rarity)}${normalizeRace(card) ? ` • ${escapeHtml(normalizeRace(card))}` : ''}</div></button>`).join('')}
          </div>`}
      </section>
    `;
    ui.center.innerHTML = `
      <section class="rater-section">
        <h3>${ui.state.mode === 'deck' ? escapeHtml(currentDeck?.name || 'Select a deck') : escapeHtml(currentCard?.name || 'Select a card')}</h3>
        <div class="rater-badge-row">
          <span class="rater-badge">${persona.icon} ${escapeHtml(persona.name)}</span>
          <span class="rater-badge">Cost ${cost} gold</span>
          ${cached ? `<span class="rater-badge">Stored ${escapeHtml(formatDeckStamp(cached))}</span>` : ''}
          ${stale ? `<span class="rater-badge">Stale report on file</span>` : ''}
        </div>
        <div class="meta" style="margin-top:12px;">${escapeHtml(ui.state.mode === 'deck' ? 'Full evaluation uses static role analysis, draw math, cohesion graphing, benchmark gauntlets, multiplayer pressure modeling, and anti-cheese moderation.' : 'Single-card evaluation measures role identity, flexibility, format fit, and support burden without touching conquest mechanics.')}</div>
        <div class="rater-grid two" style="margin-top:14px;">
          <button class="rater-button primary" data-rater-action="start" ${profile.economy.gold < cost ? 'disabled' : ''}>Begin Evaluation</button>
          <button class="rater-button subtle" data-rater-action="show-cached" ${(cached || stale) ? '' : 'disabled'}>${cached ? 'View Stored Report' : 'View Latest Report'}</button>
        </div>
        ${stale ? `<div class="meta" style="margin-top:10px;">This deck changed since its last evaluation. The archived report remains available for comparison, but it no longer matches the current contents.</div>` : ''}
      </section>
    `;
    ui.right.innerHTML = `
      <section class="rater-section">
        <h3>Evaluator Voice</h3>
        <div class="rater-speech">${escapeHtml(ui.state.speech || persona.lines.intro[0])}</div>
      </section>
      <section class="rater-section">
        <h3>Rules</h3>
        <div class="rater-insight-list">
          <div class="rater-insight">Normal mode and Local Player only.</div>
          <div class="rater-insight">Conquest-only cards and decks are blocked.</div>
          <div class="rater-insight">Ratings persist by deck-content hash until the list changes.</div>
        </div>
      </section>
      <section class="rater-section">
        <h3>Recent Activity</h3>
        <div class="rater-list">
          ${getQuickSummary().recentRuns.map((entry) => `<div class="rater-list-item"><strong>${escapeHtml(entry.name)}</strong><div class="meta">${escapeHtml(entry.kind)} • ${escapeHtml(entry.at)}</div></div>`).join('') || '<div class="meta">No evaluations stored yet.</div>'}
        </div>
      </section>
    `;
  }

  function renderRunningPane(ui) {
    const live = ui.state.live || {};
    const debug = loadStore().debug;
    ui.left.innerHTML = `
      <section class="rater-section">
        <h3>Evaluation Phases</h3>
        <div class="rater-insight-list">
          ${['intake', 'curve', 'draw', 'cohesion', 'matchup', 'multiplayer', 'validate', 'finish'].map((phase, index) => `<div class="rater-insight"><strong>${index + 1}. ${phase}</strong><div class="meta">${ui.state.phase === phase ? 'Active' : ui.state.progress > (index / 8) ? 'Complete' : 'Pending'}</div></div>`).join('')}
        </div>
      </section>
    `;
    ui.center.innerHTML = `
      <section class="rater-section">
        <h3>Evaluation In Progress</h3>
        <div class="rater-progress"><i style="width:${Math.round(ui.state.progress * 100)}%"></i></div>
        <div class="meta" style="margin-top:10px;">Phase: ${escapeHtml(ui.state.phase)} • ${Math.round(ui.state.progress * 100)}%</div>
        <div class="rater-speech" style="margin-top:14px;">${escapeHtml(ui.state.speech || 'Analyzing...')}</div>
      </section>
      <section class="rater-section">
        <h3>Live Metric Stream</h3>
        <div class="rater-metrics-stream">
          ${Object.entries(live).slice(0, 10).map(([key, value]) => `<div class="row"><span>${escapeHtml(key)}</span><strong>${escapeHtml(typeof value === 'object' ? JSON.stringify(value).slice(0, 60) : String(value))}</strong></div>`).join('') || '<div class="meta">Metrics will populate as the evaluator moves through each phase.</div>'}
        </div>
      </section>
      ${debug.showDrawMath && live.opening ? `<section class="rater-section"><h3>Draw Math</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(live.opening, null, 2))}</div></section>` : ''}
      ${debug.showCohesion && live.graph ? `<section class="rater-section"><h3>Cohesion Graph</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(live.graph, null, 2))}</div></section>` : ''}
      ${debug.showGauntlet && live.gauntlet ? `<section class="rater-section"><h3>Gauntlet</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(live.gauntlet, null, 2))}</div></section>` : ''}
    `;
    ui.right.innerHTML = `
      <section class="rater-section">
        <h3>${escapeHtml((PERSONA_BY_ID[ui.state.personaId] || PERSONAS[0]).name)}</h3>
        <div class="rater-speech">${escapeHtml(ui.state.speech || 'Working.')}</div>
      </section>
      ${debug.enabled || debug.showEval ? `<section class="rater-section"><h3>Debug</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify({ phase: ui.state.phase, progress: ui.state.progress, live }, null, 2))}</div></section>` : ''}
    `;
  }

  function renderResultPane(ui) {
    const report = ui.state.report;
    const formatKey = ui.state.formatTab || '1v1';
    const panelKey = formatKey === '1v1v1v1' ? '1v1v1v1' : formatKey;
    const isDeck = report.kind === 'deck';
    const formatFitBars = [
      { id: '1v1', name: '1v1', winRate: Math.round(clamp(report.scores['1v1'] / 10, 0, 100)) },
      { id: '2v2', name: '2v2', winRate: Math.round(clamp(report.scores['2v2'] / 10, 0, 100)) },
      { id: '1v1v1v1', name: '1v1v1v1', winRate: Math.round(clamp(report.scores['1v1v1v1'] / 10, 0, 100)) },
    ];
    ui.left.innerHTML = `
      <section class="rater-section">
        <h3>Summary</h3>
        <div class="rater-badge-row">
          <span class="rater-badge">${escapeHtml(report.personaName)}</span>
          <span class="rater-badge">${escapeHtml(report.archetype)}</span>
          <span class="rater-badge">Confidence ${report.confidence}</span>
          <span class="rater-badge">${escapeHtml(report.reliability)}</span>
          ${report._stale ? '<span class="rater-badge">Stale Snapshot</span>' : ''}
        </div>
        <div class="rater-score-cards" style="margin-top:14px;">
          <article class="rater-score-card"><span>1v1</span><strong>${report.scores['1v1']}</strong></article>
          <article class="rater-score-card"><span>2v2</span><strong>${report.scores['2v2']}</strong></article>
          <article class="rater-score-card"><span>1v1v1v1</span><strong>${report.scores['1v1v1v1']}</strong></article>
        </div>
        ${report._stale ? '<div class="meta" style="margin-top:12px;">This report is kept for history. Re-run the evaluator to certify the current list.</div>' : ''}
      </section>
      <section class="rater-section">
        <h3>Strengths</h3>
        <div class="rater-insight-list">${(report.strengths || []).map((entry) => `<div class="rater-insight">${escapeHtml(entry)}</div>`).join('') || '<div class="meta">No major strengths recorded.</div>'}</div>
      </section>
      <section class="rater-section">
        <h3>Weaknesses</h3>
        <div class="rater-insight-list">${(report.weaknesses || []).map((entry) => `<div class="rater-insight">${escapeHtml(entry)}</div>`).join('') || '<div class="meta">No major weaknesses recorded.</div>'}</div>
      </section>
      <section class="rater-section">
        <h3>Opportunities</h3>
        <div class="rater-insight-list">${(report.opportunities || []).map((entry) => `<div class="rater-insight">${escapeHtml(entry)}</div>`).join('') || '<div class="meta">No major changes suggested.</div>'}</div>
      </section>
    `;
    ui.center.innerHTML = `
      <section class="rater-section">
        <div class="rater-tabs">
          <button class="rater-tab ${panelKey === '1v1' ? 'active' : ''}" data-rater-action="tab" data-tab="1v1">1v1</button>
          <button class="rater-tab ${panelKey === '2v2' ? 'active' : ''}" data-rater-action="tab" data-tab="2v2">2v2</button>
          <button class="rater-tab ${panelKey === '1v1v1v1' ? 'active' : ''}" data-rater-action="tab" data-tab="1v1v1v1">1v1v1v1</button>
        </div>
        <div class="rater-grid two" style="margin-top:12px;align-items:start;">
          <div>${renderRadarSvg(report.radar)}</div>
          <div>
            <h4>${isDeck ? 'Matchup Profile' : 'Format Fit'}</h4>
            ${isDeck ? renderMatchupBars(report.matchups?.byFormat?.[panelKey] || []) : renderMatchupBars(formatFitBars)}
          </div>
        </div>
      </section>
      ${isDeck ? `
        <section class="rater-section">
          <h3>Curve Histogram</h3>
          ${renderCurveSvg(report.curve)}
        </section>
        <section class="rater-section">
          <h3>Draw Heatmap by Turn</h3>
          ${renderHeatmap(report.drawHeatmap || [])}
        </section>` : `
        <section class="rater-section">
          <h3>Card Role</h3>
          <div class="rater-grid two">
            <article class="rater-score-card"><span>Role Identity</span><strong style="font-size:1.15rem">${escapeHtml(report.metrics?.roleIdentity || '-')}</strong></article>
            <article class="rater-score-card"><span>Curve Placement</span><strong style="font-size:1.15rem">${escapeHtml(report.metrics?.curvePlacement || '-')}</strong></article>
          </div>
        </section>
        <section class="rater-section">
          <h3>Synergy Tags</h3>
          <div class="rater-badge-row">${(report.metrics?.synergyTags || []).map((entry) => `<span class="rater-badge">${escapeHtml(entry)}</span>`).join('') || '<span class="meta">No standout synergy tags recorded.</span>'}</div>
        </section>`}
      <section class="rater-section">
        <div class="rater-grid three">
          <article class="rater-score-card"><span>Power Ceiling</span><strong>${report.powerCeiling || report.metrics?.powerBand || '-'}</strong></article>
          <article class="rater-score-card"><span>Floor / Consistency</span><strong>${report.floor || report.reliability}</strong></article>
          <article class="rater-score-card"><span>Best Format</span><strong>${escapeHtml(report.bestFormat || panelKey)}</strong></article>
        </div>
      </section>
    `;
    const debug = loadStore().debug;
    ui.right.innerHTML = `
      <section class="rater-section">
        <h3>Final Statement</h3>
        <div class="rater-speech">${escapeHtml(ui.state.speech || '')}</div>
      </section>
      <section class="rater-section">
        <h3>Format Warnings</h3>
        <div class="rater-insight-list">${(report.warnings || []).map((entry) => `<div class="rater-insight">${escapeHtml(entry)}</div>`).join('') || '<div class="meta">No format-specific warnings.</div>'}</div>
      </section>
      ${isDeck ? `
        <section class="rater-section">
          <h3>Packages</h3>
          <div class="rater-insight-list">${(report.packages || []).map((cluster) => `<div class="rater-insight"><strong>${cluster.score}</strong><div class="meta">${escapeHtml(cluster.names.join(', '))}</div></div>`).join('') || '<div class="meta">No strong packages isolated.</div>'}</div>
        </section>
        <section class="rater-section"><h3>Replaceable Weak Cards</h3><div class="rater-insight-list">${(report.cardOutliers || []).map((entry) => `<div class="rater-insight"><strong>${escapeHtml(entry.name)}</strong><div class="meta">Plays ${entry.plays}/${entry.draws} • dead ${entry.dead}</div></div>`).join('') || '<div class="meta">No weak-card data.</div>'}</div></section>
      ` : `
        <section class="rater-section">
          <h3>Card Metrics</h3>
          <div class="rater-insight-list">
            <div class="rater-insight"><strong>Flexibility</strong><div class="meta">${escapeHtml(String(report.metrics?.flexibility ?? '-'))}</div></div>
            <div class="rater-insight"><strong>Risk</strong><div class="meta">${escapeHtml(String(report.metrics?.risk ?? '-'))}</div></div>
          </div>
        </section>
      `}
      <section class="rater-section">
        <div class="rater-grid two">
          <button class="rater-button primary" data-rater-action="copy">Copy Summary</button>
          <button class="rater-button subtle" data-rater-action="back">Back</button>
        </div>
      </section>
      ${(debug.enabled || debug.showEval) ? `<section class="rater-section"><h3>Debug</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(report.metrics || {}, null, 2))}</div></section>` : ''}
      ${debug.showGauntlet ? `<section class="rater-section"><h3>Gauntlet Breakdown</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(isDeck ? (report.matchups || {}) : formatFitBars, null, 2))}</div></section>` : ''}
      ${debug.showCohesion ? `<section class="rater-section"><h3>Cohesion Breakdown</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(isDeck ? (report.graph || {}) : (report.metrics || {}), null, 2))}</div></section>` : ''}
      ${debug.showDrawMath ? `<section class="rater-section"><h3>Draw / Curve Breakdown</h3><div class="rater-debug-block">${escapeHtml(JSON.stringify(isDeck ? { heatmap: report.drawHeatmap, curve: report.curve } : { scores: report.scores, radar: report.radar }, null, 2))}</div></section>` : ''}
    `;
  }

  function renderUi() {
    const ui = ensureUi();
    ui.headMeta.textContent = ui.state.mode === 'deck'
      ? 'Premium deck analysis for duel, 2v2, and free-for-all. Uses the normal card pool plus Local Player exclusives only when present.'
      : 'Single-card appraisal for normal-mode and Local Player legality. Conquest cards remain excluded.';
    if (ui.state.running) renderRunningPane(ui);
    else if (ui.state.report) renderResultPane(ui);
    else renderSelectionPane(ui);
  }

  async function open(options = {}) {
    const ui = ensureUi();
    wireUiEvents();
    ui.state.open = true;
    ui.state.entry = options.entry || 'launcher';
    ui.state.mode = options.mode || (options.suppliedCard ? 'card' : 'deck');
    ui.state.selectedDeckId = '';
    ui.state.selectedCardId = '';
    ui.state.suppliedDeck = options.suppliedDeck ? normalizeDeck(options.suppliedDeck, false) : null;
    ui.state.suppliedCard = options.suppliedCard ? { ...options.suppliedCard } : null;
    ui.state.report = null;
    ui.state.running = false;
    ui.state.progress = 0;
    ui.state.phase = 'intake';
    ui.state.speech = String(options.speech || '').trim() || (PERSONA_BY_ID[ui.state.personaId] || PERSONAS[0]).lines.intro[0];
    ui.state.cardQuery = '';
    ui.state.live = {};
    ui.state.formatTab = '1v1';
    ui.state.runToken = null;
    ui.overlay.classList.remove('hidden');
    await refreshUiData();
    renderUi();
  }

  function close() {
    const ui = ensureUi();
    ui.state.runToken = null;
    ui.state.running = false;
    ui.overlay.classList.add('hidden');
  }

  function command(raw = '') {
    const store = loadStore();
    const normalized = String(raw || '').trim().toLowerCase();
    if (normalized === './dev -deckrater' || normalized === 'dev -deckrater') {
      store.debug.enabled = true;
      saveStore(store);
      return { ok: true, message: 'Deck rater debug enabled.' };
    }
    if (normalized === './hide -deckrater' || normalized === 'hide -deckrater') {
      store.debug.enabled = false;
      saveStore(store);
      return { ok: true, message: 'Deck rater debug hidden.' };
    }
    if (normalized === './raterdebug' || normalized === 'raterdebug') {
      store.debug.enabled = !store.debug.enabled;
      saveStore(store);
      return { ok: true, message: `Deck rater debug ${store.debug.enabled ? 'enabled' : 'disabled'}.` };
    }
    if (normalized === './showeval' || normalized === 'showeval') {
      store.debug.showEval = !store.debug.showEval;
      saveStore(store);
      return { ok: true, message: `Evaluator metric stream ${store.debug.showEval ? 'shown' : 'hidden'}.` };
    }
    if (normalized === './showgauntlet' || normalized === 'showgauntlet') {
      store.debug.showGauntlet = !store.debug.showGauntlet;
      saveStore(store);
      return { ok: true, message: `Gauntlet debug ${store.debug.showGauntlet ? 'shown' : 'hidden'}.` };
    }
    if (normalized === './showcohesion' || normalized === 'showcohesion') {
      store.debug.showCohesion = !store.debug.showCohesion;
      saveStore(store);
      return { ok: true, message: `Cohesion graph debug ${store.debug.showCohesion ? 'shown' : 'hidden'}.` };
    }
    if (normalized === './showdrawmath' || normalized === 'showdrawmath') {
      store.debug.showDrawMath = !store.debug.showDrawMath;
      saveStore(store);
      return { ok: true, message: `Draw-math debug ${store.debug.showDrawMath ? 'shown' : 'hidden'}.` };
    }
    if (normalized === './deckrater-fast' || normalized === 'deckrater-fast') {
      store.debug.fastMode = !store.debug.fastMode;
      saveStore(store);
      return { ok: true, message: `Deck rater fast mode ${store.debug.fastMode ? 'enabled' : 'disabled'}.` };
    }
    if (normalized === './raterdebug -help' || normalized === 'raterdebug -help') {
      return { ok: true, message: './dev -deckRater | ./hide -deckRater | ./raterdebug | ./showeval | ./showgauntlet | ./showcohesion | ./showdrawmath | ./deckrater-fast' };
    }
    return { ok: false, message: 'Unknown deck rater command.' };
  }

  window.CardForgeDeckRater = {
    open,
    close,
    command,
    getDeckStamp,
    getQuickSummary,
    checkDeckLegality,
    checkCardLegality,
    getStore: loadStore,
    hashDeck: contentHashForDeck,
    hashCard: contentHashForCard,
  };
}());
