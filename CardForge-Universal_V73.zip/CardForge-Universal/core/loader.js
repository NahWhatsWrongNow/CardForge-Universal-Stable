import { validateSchema } from './schema.js';

const LOADER_TIMEOUT_MS = 12000;

async function fetchWithTimeout(path, options = {}, timeoutMs = LOADER_TIMEOUT_MS) {
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const timeout = controller
    ? setTimeout(() => controller.abort(new Error(`Timed out loading ${path}`)), timeoutMs)
    : null;
  try {
    const response = await fetch(path, {
      cache: 'no-store',
      ...options,
      ...(controller ? { signal: controller.signal } : {}),
    });
    return response;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error(`Timed out loading ${path}`);
    }
    throw error;
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

async function loadManifest(manifestPath) {
  const response = await fetchWithTimeout(manifestPath);
  if (!response.ok) throw new Error(`Missing manifest ${manifestPath}`);
  return response.json();
}

async function loadJson(path) {
  const response = await fetchWithTimeout(path);
  if (!response.ok) throw new Error(`Missing file ${path}`);
  return response.json();
}

export async function loadPlugins(registry, definitions, report = console.log) {
  const errors = [];

  for (const definition of definitions) {
    try {
      const manifest = await loadManifest(definition.manifest);
      for (const relPath of manifest.entries ?? []) {
        const path = `${definition.base}/${relPath}`;
        try {
          const plugin = await loadJson(path);
          const validation = validateSchema(plugin, definition.type);
          if (!validation.ok) {
            errors.push(`${path}: missing ${validation.missing.join(', ')}`);
            continue;
          }
          registry.register(definition.kind, plugin);
          report(`Loaded ${plugin.id} from ${path}`);
        } catch (error) {
          errors.push(`${path}: ${error.message}`);
        }
      }
    } catch (error) {
      errors.push(`${definition.manifest}: ${error.message}`);
    }
  }

  return errors;
}
