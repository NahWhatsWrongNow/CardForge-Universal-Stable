# Deck Rater System

## Scope

The deck rater is available only for:

- normal mode
- Local Player / local multiplayer

It is not available for conquest mode.

Local Player uses the normal card pool by default. Cards marked `localExclusive` are also legal in Local Player and are included by the rater when present in the tested deck. Conquest-only cards and conquest/defense decks are rejected.

## Access points

The evaluator is exposed from:

- the Shop tab on the launcher map via `Archive of Judgement`
- the creator via card evaluation
- the Local Player setup/runtime UI
- the deckbuilder for the current draft

The deckbuilder route now performs a legality handshake first. If the current draft contains conquest-only or invalid cards, the overlay opens in deck-selection mode with a clear explanation instead of trying to rate the invalid draft.

## Evaluation costs

- full deck evaluation: `30` gold
- single card evaluation: `10` gold

Gold is charged at evaluation start and refunded automatically if the runtime fails before a report is produced.

## Personas

The system ships with 10 presentation personas. They all use the same engine and only change voice, flavor, traits, and presentation:

- The Arbiter
- The Scholar
- The Warlord
- The Oracle
- The Alchemist
- The Executioner
- The Curator
- The Starcaller
- The Quartermaster
- The Mirror

## Engine architecture

The runtime lives in [deck_rater_runtime.js](C:\Users\jadon\Downloads\CardForge-Universal-CarnifexV13.8\CardForge-Universal\deck_rater_runtime.js).

Primary layers:

1. catalog loading and legality filtering
2. static per-card role analysis
3. deck composition analysis
4. cohesion graph clustering
5. draw and opening-hand simulation
6. benchmark gauntlet scoring
7. multiplayer-specific pressure modeling
8. anti-gaming moderation
9. report persistence keyed by content hash

## Evaluation methods

The deck report fuses multiple methods. No single method can dominate the final score.

### Static card analysis

Each card is normalized and analyzed for:

- cost
- type
- rarity
- race
- stats
- text-derived role signals
- tempo, control, draw, sustain, burst, synergy, resilience, flexibility, topdeck, multiplayer, team utility, political pressure, volatility, combo reliance, dead-draw risk, threat, engine value, finish value

### Deck composition analysis

The evaluator measures:

- mana curve
- type distribution
- rarity distribution
- race concentration
- removal density
- summon density
- AoE density
- support/permanent density
- threat density
- inevitability
- tribal density

### Cohesion graph analysis

Cards become graph nodes. Edges are inferred from shared race, type, cost band, proactive/reactive fit, engine support, buff targets, draw engines, summon density, and text hooks. The graph produces:

- synergy clusters
- outlier cards
- redundancy
- key-card reliance

### Probability and draw analysis

Simulated opening hands and draw sequences measure:

- opening hand quality
- dead-hand rate
- mulligan recovery
- draw consistency
- topdeck quality
- reactive overload
- curve health
- dead-card frequency

### Benchmark gauntlet

Decks are tested against standardized benchmark families, each at multiple tiers:

- aggro baseline
- midrange baseline
- control baseline
- combo baseline
- relic / engine baseline
- tribal baseline
- anti-swarm baseline
- heavy top-end baseline
- multiplayer politics baseline
- team synergy baseline

Each benchmark is evaluated at:

- basic
- refined
- optimized
- hostile / meta-aware

### Multiplayer modeling

Separate scoring is produced for:

- `1v1`
- `2v2`
- `1v1v1v1`

Additional multiplayer metrics include:

- team utility
- political survivability
- multiplayer pressure handling
- overextension risk

## Public outputs

Deck reports expose:

- `1v1`, `2v2`, and `1v1v1v1` ratings
- confidence and reliability
- best format
- worst format
- archetype identity
- power ceiling
- floor / consistency
- strengths
- weaknesses
- opportunities
- warnings
- matchup profile
- radar chart
- curve histogram
- draw heatmap
- package / cluster summary
- replaceable weak-card candidates

Card reports expose:

- format-fit ratings
- role identity
- power band
- curve placement
- best format
- synergy tags
- flexibility
- risk profile
- strengths / weaknesses / opportunities

## Anti-gaming rules

The evaluator is built to be difficult to exploit locally. It uses the following protections:

1. ratings are keyed by deck-content hash, not deck name
2. changing card contents invalidates the current stamp
3. multi-method score fusion prevents single-axis exploits
4. stat inflation alone does not score highly
5. unsupported expensive cards are penalized
6. low-support tribal or combo packages are penalized
7. narrow overfit decks lose resilience and reliability
8. volatility reduces confidence
9. reports require non-trivial sample counts
10. opponent diversity is mandatory through the gauntlet
11. anti-cheese sweeps punish decks that only spike into weak benchmark slices
12. bad-draw stress is modeled through dead-hand and mulligan recovery
13. weak role coverage is penalized unless compensated elsewhere
14. theoretical combo payoff is discounted if assembly probability is poor
15. FFA pressure penalizes duel-only glass-cannon shells
16. 2v2 scoring values ally utility, not only selfish output
17. meta-resilience is factored into the final rating
18. floor / ceiling moderation avoids absurd public numbers from one weird interaction

## Persistence rules

Storage keys:

- profile: `cardforge.profile.v1`
- evaluator store: `cardforge.deckrater.v1`

Persistence behavior:

- deck reports are cached by deck-content hash
- deck history is also stored by deck id for stale history access
- a saved deck shows a rating stamp only when the stored hash matches the current contents
- if the deck changes, the prior report becomes stale and remains history-only
- reports include evaluator name, engine version, timestamp, confidence, and reliability

## Local multiplayer support rules

- Local Player uses the same evaluator engine as normal mode
- only normal-mode cards plus `localExclusive` cards are legal
- conquest-only cards are filtered from selection lists
- conquest/defense decks are rejected by legality checks
- rarity visuals and result UI are shared with the normal-mode presentation

## Dev commands

Supported commands:

- `./dev -deckRater`
- `./hide -deckRater`
- `./raterdebug`
- `./raterdebug -help`
- `./showeval`
- `./showgauntlet`
- `./showcohesion`
- `./showdrawmath`
- `./deckrater-fast`

Debug output can surface:

- live metric stream
- gauntlet progress
- cohesion graph data
- draw math
- recent runs

## Adding future personas

Personas are defined inside [deck_rater_runtime.js](C:\Users\jadon\Downloads\CardForge-Universal-CarnifexV13.8\CardForge-Universal\deck_rater_runtime.js).

To add another persona:

1. add a new entry to the persona list with `id`, `name`, `icon`, `theme`, `chips`, and `preview`
2. provide calm lines for:
   - intro
   - intake
   - curve
   - draw
   - cohesion
   - matchup
   - multiplayer
   - validate
   - finish
   - card mode if needed
3. keep the engine untouched unless the new persona truly needs new commentary hooks

Personas should remain presentation-only unless a future design explicitly wants evaluator-specific weighting.
