(function attachCardPresentationShared(global) {
  const deepClone = typeof global.structuredClone === 'function'
    ? global.structuredClone.bind(global)
    : (value) => JSON.parse(JSON.stringify(value));
  if (typeof global.structuredClone !== 'function') {
    global.structuredClone = deepClone;
  }

  const PRESETS = {
    'compact-fan': {
      label: 'Compact Fan',
      description: 'Balanced overlap with a centered lower grip.',
      values: { cardCount: 8, cardScale: 1, overlap: 0.5, fanAngle: 12, curvature: 20, hoverLift: 62, hoverScale: 1.08, animationSpeed: 0.92, springiness: 0.58, damping: 0.76, anchor: 'bottom-center', hoverSpread: 70, orientation: 'inward' },
    },
    'wide-fan': {
      label: 'Wide Fan',
      description: 'Opens the hand for fuller name bars and art reads.',
      values: { cardCount: 8, cardScale: 1.02, overlap: 0.34, fanAngle: 16, curvature: 24, hoverLift: 64, hoverScale: 1.09, animationSpeed: 0.96, springiness: 0.62, damping: 0.72, anchor: 'bottom-center', hoverSpread: 82, orientation: 'inward' },
    },
    'tight-stack': {
      label: 'Tight Stack',
      description: 'Dense overlap to stress hover reveal and z-order.',
      values: { cardCount: 9, cardScale: 0.98, overlap: 0.64, fanAngle: 8, curvature: 14, hoverLift: 56, hoverScale: 1.06, animationSpeed: 0.9, springiness: 0.54, damping: 0.82, anchor: 'bottom-center', hoverSpread: 62, orientation: 'inward' },
    },
    'arc-spread': {
      label: 'Arc Spread',
      description: 'More pronounced curved baseline with clean center focus.',
      values: { cardCount: 7, cardScale: 1.03, overlap: 0.41, fanAngle: 18, curvature: 30, hoverLift: 66, hoverScale: 1.1, animationSpeed: 0.94, springiness: 0.64, damping: 0.7, anchor: 'center-lower', hoverSpread: 88, orientation: 'inward' },
    },
    'deep-overlap': {
      label: 'Deep Overlap',
      description: 'Pushed close together to judge premium compression.',
      values: { cardCount: 10, cardScale: 0.96, overlap: 0.7, fanAngle: 10, curvature: 18, hoverLift: 60, hoverScale: 1.08, animationSpeed: 0.88, springiness: 0.56, damping: 0.8, anchor: 'bottom-center', hoverSpread: 76, orientation: 'inward' },
    },
    'presentation-fan': {
      label: 'Presentation Fan',
      description: 'Showcase spread with richer depth and stronger focus.',
      values: { cardCount: 6, cardScale: 1.08, overlap: 0.28, fanAngle: 14, curvature: 22, hoverLift: 72, hoverScale: 1.12, animationSpeed: 1, springiness: 0.68, damping: 0.66, anchor: 'center-lower', hoverSpread: 92, orientation: 'inward' },
    },
    'competitive-readability': {
      label: 'Competitive Readability',
      description: 'Calmer motion and wider gaps for text inspection.',
      values: { cardCount: 8, cardScale: 1, overlap: 0.25, fanAngle: 8, curvature: 12, hoverLift: 50, hoverScale: 1.05, animationSpeed: 1.06, springiness: 0.45, damping: 0.9, anchor: 'bottom-center', hoverSpread: 56, orientation: 'inward' },
    },
    'showcase-mode': {
      label: 'Showcase Mode',
      description: 'Larger cards, slower motion, more theatrical spread.',
      values: { cardCount: 5, cardScale: 1.16, overlap: 0.22, fanAngle: 11, curvature: 20, hoverLift: 78, hoverScale: 1.14, animationSpeed: 0.82, springiness: 0.74, damping: 0.62, anchor: 'center-lower', hoverSpread: 96, orientation: 'inward' },
    },
  };

  const MOTION_PRESETS = {
    silk: { label: 'Silk', animationSpeed: 0.9, springiness: 0.52, damping: 0.84 },
    spring: { label: 'Spring', animationSpeed: 1, springiness: 0.7, damping: 0.66 },
    snappy: { label: 'Snappy', animationSpeed: 1.18, springiness: 0.46, damping: 0.92 },
  };

  const ANCHORS = {
    'bottom-center': { label: 'Bottom Center', x: '50%', y: '96%' },
    'center-lower': { label: 'Center Lower', x: '50%', y: '88%' },
    left: { label: 'Left Anchor', x: '30%', y: '92%' },
    right: { label: 'Right Anchor', x: '70%', y: '92%' },
  };

  const DEFAULTS = {
    ...deepClone(PRESETS['compact-fan'].values),
    presetId: 'compact-fan',
    comparePresetId: 'presentation-fan',
    compareMode: false,
    qualityPreset: 'silk',
    styleMode: 'premium',
    showGuides: false,
    showShadows: true,
    showRarityEffects: true,
    showZOrder: false,
    pinMode: true,
    ribbonOpacityDuel: 0,
    ribbonOpacityLocal: 0,
    ribbonOpacityConquest: 0,
  };

  const SAMPLE_CARDS = [
    { id: 'shared-ash-1', name: 'Ash Vow', cost: 1, rarity: 'common', frame: 'ember', type: 'Spell', role: 'Burn', chips: ['Ash', 'Tempo'], text: 'Deal 2 damage. If weather is Ash Storm, scorch again for 1.', attack: null, defense: null, health: null },
    { id: 'shared-tide-2', name: 'Tideguard Adept', cost: 3, rarity: 'rare', frame: 'tide', type: 'Unit', role: 'Guardian', chips: ['Water', 'Sentinel'], text: 'On deploy, ward the lane. Allied officers here gain +1 defense.', attack: 2, defense: 2, health: 5 },
    { id: 'shared-royal-3', name: 'Cathedral Archivist of the Last Static Choir', cost: 5, rarity: 'epic', frame: 'royal', type: 'Officer', role: 'Support', chips: ['Royal', 'Storm', 'Officer'], text: 'Attach to a backline unit. When you draw an Order, restore 2 morale to this lane.', attack: 1, defense: 3, health: 4 },
    { id: 'shared-void-4', name: 'Nullwake Diver', cost: 4, rarity: 'rare', frame: 'void', type: 'Unit', role: 'Skirmisher', chips: ['Void', 'Ambush'], text: 'Slip between lanes. Gains +2 attack the first time it becomes fully revealed.', attack: 4, defense: 1, health: 3 },
    { id: 'shared-fungal-5', name: 'Fungal Court Bloom', cost: 2, rarity: 'common', frame: 'fungal', type: 'Relic', role: 'Engine', chips: ['Fungal', 'Healing'], text: 'At turn end, heal the weakest ally for 1.', attack: null, defense: null, health: null },
    { id: 'shared-war-6', name: 'Banner Captain Helion', cost: 4, rarity: 'epic', frame: 'war', type: 'Officer', role: 'Banner', chips: ['War', 'Officer', 'Aura'], text: 'Anchor to a formation. Adjacent allies gain +1 attack.', attack: 2, defense: 2, health: 4 },
  ];

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function toNumber(value, fallback = 0) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : fallback;
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function slugify(value) {
    return String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'neutral';
  }

  function mergeSettings(raw) {
    const next = { ...DEFAULTS, ...(raw && typeof raw === 'object' ? raw : {}) };
    next.presetId = PRESETS[next.presetId] ? next.presetId : DEFAULTS.presetId;
    next.comparePresetId = PRESETS[next.comparePresetId] ? next.comparePresetId : DEFAULTS.comparePresetId;
    next.qualityPreset = MOTION_PRESETS[next.qualityPreset] ? next.qualityPreset : DEFAULTS.qualityPreset;
    next.anchor = ANCHORS[next.anchor] ? next.anchor : DEFAULTS.anchor;
    next.orientation = String(next.orientation ?? 'inward').toLowerCase() === 'outward' ? 'outward' : 'inward';
    next.styleMode = String(next.styleMode ?? 'premium').toLowerCase() === 'legacy' ? 'legacy' : 'premium';
    next.cardCount = clamp(Math.round(toNumber(next.cardCount, DEFAULTS.cardCount)), 3, 16);
    next.cardScale = clamp(toNumber(next.cardScale, DEFAULTS.cardScale), 0.82, 1.28);
    next.overlap = clamp(toNumber(next.overlap, DEFAULTS.overlap), 0.12, 0.78);
    next.fanAngle = clamp(toNumber(next.fanAngle, DEFAULTS.fanAngle), 0, 24);
    next.curvature = clamp(toNumber(next.curvature, DEFAULTS.curvature), 0, 40);
    next.hoverLift = clamp(toNumber(next.hoverLift, DEFAULTS.hoverLift), 20, 110);
    next.hoverScale = clamp(toNumber(next.hoverScale, DEFAULTS.hoverScale), 1, 1.2);
    next.animationSpeed = clamp(toNumber(next.animationSpeed, DEFAULTS.animationSpeed), 0.6, 1.35);
    next.springiness = clamp(toNumber(next.springiness, DEFAULTS.springiness), 0.1, 1);
    next.damping = clamp(toNumber(next.damping, DEFAULTS.damping), 0.3, 1);
    next.hoverSpread = clamp(toNumber(next.hoverSpread, DEFAULTS.hoverSpread), 20, 120);
    next.compareMode = !!next.compareMode;
    next.showGuides = !!next.showGuides;
    next.showShadows = next.showShadows !== false;
    next.showRarityEffects = next.showRarityEffects !== false;
    next.showZOrder = !!next.showZOrder;
    next.pinMode = next.pinMode !== false;
    next.ribbonOpacityDuel = clamp(toNumber(next.ribbonOpacityDuel, DEFAULTS.ribbonOpacityDuel), 0, 0.92);
    next.ribbonOpacityLocal = clamp(toNumber(next.ribbonOpacityLocal, DEFAULTS.ribbonOpacityLocal), 0, 0.92);
    next.ribbonOpacityConquest = clamp(toNumber(next.ribbonOpacityConquest, DEFAULTS.ribbonOpacityConquest), 0, 0.92);
    return next;
  }

  function applyPreset(settings, presetId) {
    const preset = PRESETS[presetId] ?? PRESETS[DEFAULTS.presetId];
    return mergeSettings({
      ...settings,
      ...deepClone(preset.values),
      presetId,
      orientation: settings?.orientation ?? preset.values.orientation ?? DEFAULTS.orientation,
    });
  }

  function applyMotionPreset(settings, qualityId) {
    const preset = MOTION_PRESETS[qualityId] ?? MOTION_PRESETS[DEFAULTS.qualityPreset];
    return mergeSettings({ ...settings, ...preset, qualityPreset: qualityId });
  }

  function presetOptionsMarkup(selectedId) {
    return Object.entries(PRESETS)
      .map(([id, preset]) => `<option value="${escapeHtml(id)}"${id === selectedId ? ' selected' : ''}>${escapeHtml(preset.label)}</option>`)
      .join('');
  }

  function motionButtonsMarkup(selectedId) {
    return Object.entries(MOTION_PRESETS)
      .map(([id, preset]) => `<button type="button" class="cf-card-ui-quality-btn${id === selectedId ? ' active' : ''}" data-card-ui-quality="${escapeHtml(id)}">${escapeHtml(preset.label)}</button>`)
      .join('');
  }

  function rangeControlMarkup(field, label, min, max, step, value, suffix = '') {
    return `<label class="cf-card-ui-control"><span>${escapeHtml(label)} <strong>${escapeHtml(`${value}${suffix}`)}</strong></span><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-card-ui-field="${escapeHtml(field)}" /></label>`;
  }

  function selectControlMarkup(field, label, options, selected) {
    return `<label class="cf-card-ui-control"><span>${escapeHtml(label)}</span><select data-card-ui-field="${escapeHtml(field)}">${options.map((option) => `<option value="${escapeHtml(option.value)}"${option.value === selected ? ' selected' : ''}>${escapeHtml(option.label)}</option>`).join('')}</select></label>`;
  }

  function toggleControlMarkup(field, label, checked) {
    return `<label class="cf-card-ui-toggle-row"><input type="checkbox" data-card-ui-field="${escapeHtml(field)}"${checked ? ' checked' : ''} /><span>${escapeHtml(label)}</span></label>`;
  }

  function settingsControlsMarkup(settings) {
    const safe = mergeSettings(settings);
    const anchorOptions = Object.entries(ANCHORS).map(([value, meta]) => ({ value, label: meta.label }));
    const comparePresetOptions = Object.entries(PRESETS).map(([value, preset]) => ({ value, label: preset.label }));
    const orientationOptions = [
      { value: 'inward', label: 'Arc Inward' },
      { value: 'outward', label: 'Arc Outward' },
    ];
    const styleModeOptions = [
      { value: 'premium', label: 'Premium Style' },
      { value: 'legacy', label: 'Legacy Style' },
    ];
    return `
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>Layout</h4><p>Real hand shape, overlap, arc, and anchor tuning.</p></div>
        ${selectControlMarkup('presetId', 'Preset', comparePresetOptions, safe.presetId)}
        ${selectControlMarkup('styleMode', 'Card Face Style', styleModeOptions, safe.styleMode)}
        ${selectControlMarkup('orientation', 'Arc Orientation', orientationOptions, safe.orientation)}
        ${rangeControlMarkup('cardCount', 'Preview Card Count', 3, 16, 1, Math.round(safe.cardCount))}
        ${rangeControlMarkup('cardScale', 'Card Size', 0.82, 1.28, 0.01, safe.cardScale.toFixed(2), 'x')}
        ${rangeControlMarkup('overlap', 'Overlap', 0.12, 0.78, 0.01, safe.overlap.toFixed(2))}
        ${rangeControlMarkup('fanAngle', 'Fan Angle', 0, 24, 0.5, safe.fanAngle.toFixed(1), '°')}
        ${rangeControlMarkup('curvature', 'Curvature', 0, 40, 0.5, safe.curvature.toFixed(1), 'px')}
        ${rangeControlMarkup('hoverSpread', 'Hover Spread', 20, 120, 1, Math.round(safe.hoverSpread), 'px')}
        ${selectControlMarkup('anchor', 'Anchor Position', anchorOptions, safe.anchor)}
      </section>
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>Motion</h4><p>Lift, scale, easing, and settle behavior.</p></div>
        ${rangeControlMarkup('hoverLift', 'Hover Lift', 20, 110, 1, Math.round(safe.hoverLift), 'px')}
        ${rangeControlMarkup('hoverScale', 'Hover Scale', 1, 1.2, 0.01, safe.hoverScale.toFixed(2), 'x')}
        ${rangeControlMarkup('animationSpeed', 'Animation Speed', 0.6, 1.35, 0.01, safe.animationSpeed.toFixed(2), 'x')}
        ${rangeControlMarkup('springiness', 'Springiness', 0.1, 1, 0.01, safe.springiness.toFixed(2))}
        ${rangeControlMarkup('damping', 'Damping', 0.3, 1, 0.01, safe.damping.toFixed(2))}
        <div class="cf-card-ui-quality-row"><span>Motion Feel</span><div class="cf-card-ui-quality-buttons">${motionButtonsMarkup(safe.qualityPreset)}</div></div>
      </section>
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>States & Preview</h4><p>Debug-oriented dev_WIP settings that stay available for experimentation.</p></div>
        ${toggleControlMarkup('pinMode', 'Enable pinned inspect mode', safe.pinMode)}
        ${toggleControlMarkup('showGuides', 'Show debug guides', safe.showGuides)}
        ${toggleControlMarkup('compareMode', 'Side-by-side compare mode', safe.compareMode)}
        ${toggleControlMarkup('showShadows', 'Use depth shadows', safe.showShadows)}
        ${toggleControlMarkup('showRarityEffects', 'Use rarity effects', safe.showRarityEffects)}
        ${toggleControlMarkup('showZOrder', 'Show z-order labels', safe.showZOrder)}
        ${selectControlMarkup('comparePresetId', 'Compare Preset', comparePresetOptions, safe.comparePresetId)}
      </section>
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>Ribbon Transparency</h4><p>Separate hand-ribbon transparency per live mode. Zero keeps the ribbon fully transparent.</p></div>
        ${rangeControlMarkup('ribbonOpacityDuel', 'Duel / Wielder Ribbon', 0, 0.92, 0.01, safe.ribbonOpacityDuel.toFixed(2))}
        ${rangeControlMarkup('ribbonOpacityLocal', 'Local Multiplayer Ribbon', 0, 0.92, 0.01, safe.ribbonOpacityLocal.toFixed(2))}
        ${rangeControlMarkup('ribbonOpacityConquest', 'Conquest Ribbon', 0, 0.92, 0.01, safe.ribbonOpacityConquest.toFixed(2))}
      </section>`;
  }

  function parseFieldValue(field, target) {
    if (!target) return null;
    const checkboxFields = new Set(['pinMode', 'showGuides', 'compareMode', 'showShadows', 'showRarityEffects', 'showZOrder']);
    const integerFields = new Set(['cardCount', 'hoverSpread', 'hoverLift']);
    const floatFields = new Set(['cardScale', 'overlap', 'fanAngle', 'curvature', 'hoverScale', 'animationSpeed', 'springiness', 'damping', 'ribbonOpacityDuel', 'ribbonOpacityLocal', 'ribbonOpacityConquest']);
    if (checkboxFields.has(field)) return !!target.checked;
    if (integerFields.has(field)) return Math.round(toNumber(target.value, DEFAULTS[field]));
    if (floatFields.has(field)) return toNumber(target.value, DEFAULTS[field]);
    return String(target.value ?? '');
  }

  function ribbonOpacityForMode(settings, mode = 'duel') {
    const safe = mergeSettings(settings);
    const key = String(mode ?? 'duel').toLowerCase();
    if (key === 'local') return safe.ribbonOpacityLocal;
    if (key === 'conquest') return safe.ribbonOpacityConquest;
    return safe.ribbonOpacityDuel;
  }

  function motionDurationMs(settings, distanceFactor = 0) {
    const speed = clamp(toNumber(settings.animationSpeed, 1), 0.6, 1.35);
    const springiness = clamp(toNumber(settings.springiness, 0.58), 0.1, 1);
    const damping = clamp(toNumber(settings.damping, 0.76), 0.3, 1);
    return Math.round((520 - (speed * 180) + ((1 - damping) * 70) + (springiness * 36)) + (distanceFactor * 32));
  }

  function motionEasing(settings) {
    const springiness = clamp(toNumber(settings.springiness, 0.58), 0.1, 1);
    const damping = clamp(toNumber(settings.damping, 0.76), 0.3, 1);
    const p1 = (0.16 + (springiness * 0.08)).toFixed(2);
    const p2 = (0.86 + (springiness * 0.12)).toFixed(2);
    const p3 = (0.16 + (damping * 0.22)).toFixed(2);
    return `cubic-bezier(${p1}, ${p2}, ${p3}, 1.00)`;
  }

  function resolveCardId(card, getId) {
    if (typeof getId === 'function') return String(getId(card));
    return String(card?.runtimeId ?? card?.instanceId ?? card?.id ?? card?.cardId ?? card?.name ?? 'card');
  }

  function syncHandLayout(root, cards, settings, uiState, options = {}) {
    if (!(root instanceof Element)) return;
    const safe = mergeSettings(settings);
    const nodes = Array.from(root.querySelectorAll('.cf-hand-card'));
    const getId = options.getId;
    const focusId = String(uiState?.pinnedCardId ?? uiState?.selectedCardId ?? uiState?.hoveredCardId ?? '');
    const cardItems = Array.isArray(cards) ? cards : [];
    const ids = cardItems.map((card) => resolveCardId(card, getId));
    const focusIndex = focusId ? ids.findIndex((id) => id === focusId) : -1;
    const baseScale = clamp(toNumber(safe.cardScale, 1), 0.82, 1.28);
    const baseCardWidth = (toNumber(options.baseWidth, 210) * baseScale);
    const overlap = clamp(toNumber(safe.overlap, 0.5), 0.12, 0.78);
    const step = baseCardWidth * clamp(1 - overlap, 0.16, 0.88);
    const curvaturePx = clamp(toNumber(safe.curvature, 20), 0, 40) * 2.2;
    const fanAngle = clamp(toNumber(safe.fanAngle, 12), 0, 24);
    const hoverLift = clamp(toNumber(safe.hoverLift, 62), 20, 110);
    const hoverScale = clamp(toNumber(safe.hoverScale, 1.08), 1, 1.2);
    const hoverSpread = clamp(toNumber(safe.hoverSpread, 70), 20, 120);
    const maxOffset = Math.max((cardItems.length - 1) / 2, 1);
    const orientationSign = safe.orientation === 'outward' ? 1 : -1;
    const stageHeight = Math.max(Math.round((toNumber(options.baseHeight, 304) * baseScale) + hoverLift + curvaturePx + 54), 220);
    root.classList.add('cf-hand-presenter');
    root.classList.toggle('show-shadows', !!safe.showShadows);
    root.classList.toggle('show-rarity-effects', !!safe.showRarityEffects);
    root.classList.toggle('show-guides', !!safe.showGuides);
    root.dataset.orientation = safe.orientation;
    root.dataset.styleMode = safe.styleMode;
    root.style.setProperty('--cf-anchor-x', ANCHORS[safe.anchor]?.x ?? '50%');
    root.style.setProperty('--cf-anchor-y', ANCHORS[safe.anchor]?.y ?? '96%');
    root.style.setProperty('--cf-hand-height', `${stageHeight}px`);
    let focusKind = 'idle';
    nodes.forEach((node, index) => {
      const card = cardItems[index];
      if (!card) return;
      const cardId = ids[index];
      const delta = index - ((cardItems.length - 1) / 2);
      const distance = Math.abs(delta) / maxOffset;
      const focusDelta = focusIndex >= 0 ? index - focusIndex : delta;
      const focusDistance = focusIndex >= 0 ? Math.abs(focusDelta) : Math.abs(delta);
      const proximity = focusIndex >= 0 ? Math.max(0, 1 - (focusDistance / 3.6)) : 0;
      const xBase = delta * step;
      const yBase = Math.pow(distance, 1.55) * curvaturePx;
      const rotationBase = orientationSign * ((delta / maxOffset) * fanAngle);
      const depthBase = (1 - distance) * 40;
      const openOffset = focusIndex >= 0 && index !== focusIndex
        ? Math.sign(focusDelta) * hoverSpread * Math.pow(proximity, 1.25)
        : 0;
      const neighborLift = focusIndex >= 0 && index !== focusIndex ? hoverLift * 0.18 * proximity : 0;
      let x = xBase + openOffset;
      let y = yBase - neighborLift;
      let z = depthBase;
      let scale = baseScale * (1 - (distance * 0.02) + ((1 - distance) * 0.028));
      let rotate = rotationBase;
      let opacity = focusIndex >= 0 && String(uiState?.pinnedCardId ?? '') && index !== focusIndex ? 0.78 : 1;
      let stateLabel = '';
      if (cardId === String(uiState?.hoveredCardId ?? '') && !uiState?.selectedCardId && !uiState?.pinnedCardId) {
        y -= hoverLift * 0.82;
        z += 120;
        scale *= hoverScale;
        rotate *= 0.32;
        stateLabel = 'Hover';
        focusKind = 'hover';
      }
      if (cardId === String(uiState?.selectedCardId ?? '')) {
        y -= hoverLift * 0.94;
        z += 160;
        scale *= 1 + ((hoverScale - 1) * 1.2);
        rotate *= 0.18;
        stateLabel = 'Selected';
        focusKind = 'selected';
      }
      if (cardId === String(uiState?.pinnedCardId ?? '')) {
        y -= hoverLift * 1.16;
        z += 220;
        scale *= 1 + ((hoverScale - 1) * 1.45) + 0.02;
        rotate *= 0.08;
        opacity = 1;
        stateLabel = 'Pinned';
        focusKind = 'pinned';
      }
      const tiltX = String(uiState?.pointerTilt?.cardId ?? '') === cardId ? clamp(toNumber(uiState?.pointerTilt?.x, 0), -7, 7) : 0;
      const tiltY = String(uiState?.pointerTilt?.cardId ?? '') === cardId ? clamp(toNumber(uiState?.pointerTilt?.y, 0), -10, 10) : 0;
      const distanceFactor = focusIndex >= 0 ? Math.min(focusDistance, 3) / 3 : distance;
      node.classList.toggle('is-hovered', stateLabel === 'Hover');
      node.classList.toggle('is-selected', stateLabel === 'Selected');
      node.classList.toggle('is-pinned', stateLabel === 'Pinned');
      node.classList.toggle('is-muted', focusIndex >= 0 && cardId !== focusId);
      node.style.opacity = String(opacity);
      node.style.zIndex = String(100 + Math.round(z) + (stateLabel === 'Pinned' ? 100 : stateLabel === 'Selected' ? 70 : stateLabel === 'Hover' ? 40 : 0));
      node.style.setProperty('--cf-card-width', `${Math.round(baseCardWidth)}px`);
      node.style.setProperty('--cf-card-height', `${Math.round((toNumber(options.baseHeight, 304) * baseScale))}px`);
      node.style.setProperty('--cf-card-x', `${x.toFixed(1)}px`);
      node.style.setProperty('--cf-card-y', `${y.toFixed(1)}px`);
      node.style.setProperty('--cf-card-rotate', `${rotate.toFixed(2)}deg`);
      node.style.setProperty('--cf-card-scale', scale.toFixed(3));
      node.style.setProperty('--cf-card-tilt-x', `${tiltX.toFixed(2)}deg`);
      node.style.setProperty('--cf-card-tilt-y', `${tiltY.toFixed(2)}deg`);
      node.style.setProperty('--cf-card-duration', `${motionDurationMs(safe, distanceFactor)}ms`);
      node.style.setProperty('--cf-card-delay', `${Math.round((focusIndex >= 0 ? focusDistance : distance) * 14)}ms`);
      node.style.setProperty('--cf-card-ease', motionEasing(safe));
      node.dataset.cardState = stateLabel || 'Idle';
      const badge = node.querySelector('.cf-hand-card-debug');
      if (badge) badge.textContent = safe.showZOrder ? `${stateLabel || 'Idle'} · z${node.style.zIndex}` : stateLabel;
    });
    root.dataset.focusKind = focusKind;
  }

  function sampleCards(count) {
    const total = clamp(Math.round(toNumber(count, 8)), 3, 16);
    return Array.from({ length: total }, (_, index) => {
      const base = SAMPLE_CARDS[index % SAMPLE_CARDS.length];
      return { ...base, runtimeId: `${base.id}-${index}`, order: index, name: index >= SAMPLE_CARDS.length ? `${base.name} ${index + 1}` : base.name };
    });
  }

  global.CardForgeCardPresentation = {
    PRESETS,
    MOTION_PRESETS,
    ANCHORS,
    DEFAULTS,
    SAMPLE_CARDS,
    mergeSettings,
    applyPreset,
    applyMotionPreset,
    settingsControlsMarkup,
    parseFieldValue,
    ribbonOpacityForMode,
    syncHandLayout,
    sampleCards,
    escapeHtml,
    slugify,
  };
})(window);
