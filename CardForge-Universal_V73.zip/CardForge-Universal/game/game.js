import { Registry } from '../core/registry.js';
import { loadPlugins } from '../core/loader.js';
import { loadProfile, saveProfile, setDevUnlocked, resetProfile } from '../core/storage.js';
import { toast, uid } from '../core/utils.js';
import { emitVfx, onVfx } from './engine/animation_bus.js';
import { explainInvalidAction } from './engine/targeting.js';
import { getRivalryIndicators, resolveCombat, resolveSpellPower } from './engine/rivalry.js';
import { evaluateQuest, getWinReward, openPack } from './engine/economy.js';
import { chooseTurnPlan, createSummon, getThinkDelay, getThinkingLine, getPlannerDebug, primeNeuralPlanner, VALID_AI_ARCHETYPES } from './engine/ai.js';
import { buildDialogueLine, deckAffinityScore, difficultyConfig, enrichAiProfile, mulliganCardScore } from './engine/ai_personalities.js';
import { createVfxRuntime, VFX_DEFAULTS } from './engine/vfx_runtime.js';
import {
  RACE_LIBRARY,
  addFamiliarity,
  boardFamilyRatio,
  collectCardFamilies,
  countCardsByFamily,
  deckContainsOnlyFamily,
  deckContainsOnlyFamilies,
  ensureFamiliarityPool,
  extractCardRaces,
  getFamiliarity,
  hasFamilyTag,
  normalizeFamilyToken,
  raceIconGlyph,
  raceMeta,
  spendFamiliarity,
} from './engine/race_logic.js';
import {
  isConquestOnlyCard,
  isLocalExclusiveCard,
} from './engine/card_pool_rules.js';
import {
  parseAbilityClauses,
  splitActions,
  extractIfCondition,
  numberFromText,
  extractCostNumber,
  looksLikeNoText,
  normalizeAbilityText,
} from './engine/ability_text.js';
import {
  LOCAL_PLAYER_AI_DIFFICULTIES,
  LOCAL_PLAYER_COLORS,
  LOCAL_PLAYER_ELEMENTS,
  LOCAL_PLAYER_FORMATS,
  LOCAL_PLAYER_MODES,
  LOCAL_PLAYER_STORMS,
  LOCAL_PLAYER_WARBANDS,
  createLocalMatch,
  currentLocalParticipant,
  defaultLocalPlayerSetup,
  endLocalTurn,
  hydrateModeChoices,
  localAttack,
  localLegalAttackTargets,
  localMatchToText,
  localSeatSummary,
  normalizeLocalPlayerSetup,
  playLocalCard,
  randomizeSeatOrder,
  runLocalAiTurn,
  acknowledgeHandoff,
} from './engine/local_multiplayer.js';
import { createLocalPlayerController } from './engine/local_multiplayer_ui.js';

const registry = new Registry();
const MATCH_KEY = 'cardforge.match.opponent.v1';
const MATCH_CONTEXT_KEY = 'cardforge.match.context.v1';
const MATCH_RESULT_KEY = 'cardforge.match.result.v1';
const LOCAL_PLAYER_SETUP_KEY = 'cardforge.localplayer.setup.v1';
const LOCAL_PLAYER_PRESET_KEY = 'cardforge.localplayer.presets.v1';
const LOCAL_MODE = window.location.protocol === 'file:';
const RUNTIME_MODE = new URLSearchParams(window.location.search).get('mode');
const BOOT_TIMEOUT_MS = 18000;
const MAX_SLOTS = 8;
const ROW_SIZE = 4;
const PHASE_ORDER = ['start', 'draw', 'main1', 'declare_attackers', 'response', 'declare_blockers', 'combat', 'main2', 'end'];
let bootSequence = 0;
let bootWatchdogHandle = null;
let bootCompleted = false;
const LOCAL_RUNTIME_DATA = {
  aiProfiles: [
    { id: 'local-initiate', name: 'Mira Vale', level: 2, personality: { title: 'Initiate', dimensionTag: 'Aster-2' }, deck: [{ name: 'Ember Acolyte', attack: 2, health: 1, element: 'fire' }, { name: 'Ward Sentry', attack: 1, health: 3, taunt: true, element: 'light' }] },
    { id: 'local-gregory', name: 'Gregory Of Oltine', level: 5, personality: { title: 'Sentinel', dimensionTag: 'Oltine-Prime' }, deck: [{ name: 'Oltine Bulwark', attack: 2, health: 4, taunt: true, element: 'earth' }, { name: 'Rift Lancer', attack: 4, health: 2, element: 'arcane' }] },
  ],
  storeProducts: [{ id: 'local-pack', name: 'Local Starter Pack', price: 60, cardsPerPack: 3, pityAfter: 4 }],
  decks: [{ id: 'local-balanced', name: 'Local Balanced', entries: [{ cardId: 'local-ember-apprentice', count: 10 }, { cardId: 'local-ward-guardian', count: 10 }, { cardId: 'local-rift-scout', count: 10 }] }],
  cards: [
    { id: 'local-ember-apprentice', name: 'Ember Apprentice', type: 'minion', cost: 1, attack: 2, health: 1, race: 'mage', element: 'fire', rarity: 'common', tags: ['starter'] },
    { id: 'local-ward-guardian', name: 'Ward Guardian', type: 'minion', cost: 2, attack: 2, health: 3, race: 'guardian', element: 'light', rarity: 'rare', tags: ['starter'] },
    { id: 'local-rift-scout', name: 'Rift Scout', type: 'minion', cost: 1, attack: 1, health: 2, race: 'scout', element: 'arcane', rarity: 'common', tags: ['starter'] }
  ],
  themes: [{ id: 'local-theme', name: 'Nebula', appBg: 'linear-gradient(120deg,#0e1428,#1e1a44,#1a3e49)', panelBg: '#10152acc', accent: '#8f7bff', hpStart: '#7dffa2', hpEnd: '#3be0c6' }],
  backdrops: [{ id: 'local-backdrop', name: 'Fracture Ring', css: 'radial-gradient(circle at 30% 20%, #2a4b9f 0%, #1c2446 45%, #0f1429 100%)' }],
  loadingTips: [
    { id: 'local-tip-1', title: 'Dimension Primer', subtitle: 'Formation > raw stats', flavor: 'Eight slots disappear fast when spacing is ignored.', gameplayTip: 'Keep one slot open when facing reactive decks.', faction: 'neutral', accent: '#8f7bff' },
  ],
};
const state = {
  profile: loadProfile(),
  playerHealth: 30,
  playerMaxHealth: 30,
  enemyHealth: 30,
  enemyMaxHealth: 30,
  mana: 1,
  enemyMana: 1,
  maxMana: 1,
  playerDeck: [],
  enemyHand: [],
  playerFatigue: 0,
  enemyFatigue: 0,
  playerCoreDef: 0,
  enemyCoreDef: 0,
  playerDeckRefills: 0,
  playerHeroPoison: 0,
  enemyHeroPoison: 0,
  playerTurnTax: 0,
  enemyTurnTax: 0,
  playerSpellCounter: 0,
  enemySpellCounter: 0,
  hand: [],
  loadingTips: [],
  shownLoadingTip: null,
  aiVoiceMemory: {},
  aiDialogueState: {},
  aiThreatMemory: {},
  aiDebugEnabled: false,
  devModeEnabled: false,
  playableDeckEnabled: false,
  playableDeckMinimized: false,
  playableDeckSort: 'original',
  cardVfxOverrides: {},
  deckTracker: {
    player: [],
    enemy: [],
  },
  rivalryPacks: [], quests: [], storeProducts: [], aiProfiles: [], backdrops: [], playlists: [], cardBacks: [], themes: [], decks: [],
  deckMode: 'planning', deckSearch: '', selectedDeckId: null, selectedAiId: null, bossMode: false, aiThinking: false, aiThinkingLine: '', lastAiTrace: 'not-run', selectedPlayerSlot: null, selectedAttackerId: null, logHidden: true, usedAttacks: {}, enemyUsedAttacks: {}, currentTurn: 'player', enemyDeck: [], matchResolved: false,
  selectedCardId: null,
  selectedSpellTargetMode: false,
  handPresentation: {
    hoveredCardId: null,
    pinnedCardId: null,
    pointerTilt: { cardId: null, x: 0, y: 0 },
  },
  leftPointerHeld: false,
  dragInteractionActive: false,
  battleStartPresented: false,
  dmPanelsVisible: false,
  aiLogicEnabled: true,
  aiTurnQueued: false,
  aiPlannerWarm: {
    queued: false,
    ready: false,
    profileId: null,
  },
  devToolkitEnabled: false,
  devPanelVisibility: {},
  devPanelCollapsed: {},
  devMetrics: {
    lastSampleAt: 0,
    aiTimeline: [],
    boardValueTimeline: [],
    deckSizeTimeline: [],
    actionTrace: [],
    lastAiCandidates: [],
    aiPhase: 'idle',
  },
  resetProgressConfirmUntil: 0,
  playerMinions: [],
  enemyMinions: [],
  playerFields: [],
  enemyFields: [],
  playerRelics: [],
  enemyRelics: [],
  playerBarricades: Array(ROW_SIZE).fill(null),
  enemyBarricades: Array(ROW_SIZE).fill(null),
  playerGraveyard: [],
  enemyGraveyard: [],
  playerExile: [],
  enemyExile: [],
  stack: [],
  phase: 'start',
  matchContext: null,
  battleRuleset: {
    modeModel: 'duel',
    battleType: 'wielder_duel',
    deckSize: 30,
    threatDeckSize: 30,
    startingMana: 1,
    startingHand: 5,
  },
  deckValidationIssues: [],
  abilityClauseCache: new Map(),
  topDeckPreview: null,
  familiarity: {
    player: {},
    enemy: {},
  },
  turnFlags: {
    player: {
      healedAmount: 0,
      healedCharacters: 0,
      minionDamaged: false,
      minionDied: false,
      playedSpell: false,
      playedMinion: false,
      cardsPlayed: 0,
      attacked: false,
      firstSpellCard: null,
      spellDamageBonus: 0,
      heroImmune: false,
      castBlessing: false,
      lookedAtDeck: false,
      drewOutsideTurn: 0,
      playedFamilies: {},
      diedFamilies: {},
    },
    enemy: {
      healedAmount: 0,
      healedCharacters: 0,
      minionDamaged: false,
      minionDied: false,
      playedSpell: false,
      playedMinion: false,
      cardsPlayed: 0,
      attacked: false,
      firstSpellCard: null,
      spellDamageBonus: 0,
      heroImmune: false,
      castBlessing: false,
      lookedAtDeck: false,
      drewOutsideTurn: 0,
      playedFamilies: {},
      diedFamilies: {},
    },
  },
  lastTurnFlags: {
    player: {
      healedAmount: 0,
      healedCharacters: 0,
      minionDamaged: false,
      minionDied: false,
      playedSpell: false,
      playedMinion: false,
      cardsPlayed: 0,
      attacked: false,
      firstSpellCard: null,
      spellDamageBonus: 0,
      heroImmune: false,
      castBlessing: false,
      lookedAtDeck: false,
      drewOutsideTurn: 0,
      playedFamilies: {},
      diedFamilies: {},
    },
    enemy: {
      healedAmount: 0,
      healedCharacters: 0,
      minionDamaged: false,
      minionDied: false,
      playedSpell: false,
      playedMinion: false,
      cardsPlayed: 0,
      attacked: false,
      firstSpellCard: null,
      spellDamageBonus: 0,
      heroImmune: false,
      castBlessing: false,
      lookedAtDeck: false,
      drewOutsideTurn: 0,
      playedFamilies: {},
      diedFamilies: {},
    },
  },
  unhandledAbilityActions: {},
  localPlayer: {
    setup: null,
    presets: [],
    match: null,
    activeScreen: 'setup',
    perspectiveSeatId: null,
    selectedHandCardId: null,
    selectedAttackerId: null,
    aiTimer: null,
    boardDrag: null,
    dragState: null,
    dragGhostEl: null,
    hoverPreview: null,
    handPresentation: {
      hoveredCardId: null,
      pinnedCardId: null,
      pointerTilt: { cardId: null, x: 0, y: 0 },
    },
    pendingFx: null,
    suppressClickUntil: 0,
    viewLayouts: {},
    seatPreview: [],
    deckSummaryVisible: true,
    lastCompletedMatch: null,
  },
};
let localPlayerController = null;

const DEV_PANEL_REGISTRY = [
  { id: 'aiPlanner', title: 'AI Planner', mode: 'both' },
  { id: 'aiGraphs', title: 'AI Graphs', mode: 'both' },
  { id: 'deckViewer', title: 'Deck Viewer', mode: 'both' },
  { id: 'deckGraphs', title: 'Deck Graphs', mode: 'both' },
  { id: 'economy', title: 'Economy', mode: 'both' },
  { id: 'threatMap', title: 'Threat Map', mode: 'conquest' },
  { id: 'ranges', title: 'Range Overlay', mode: 'both' },
  { id: 'vfx', title: 'VFX Trace', mode: 'both' },
  { id: 'ownership', title: 'Ownership', mode: 'conquest' },
  { id: 'unitTypes', title: 'Unit Types', mode: 'both' },
  { id: 'warStats', title: 'War Stats', mode: 'both' },
  { id: 'battleStats', title: 'Battle Stats', mode: 'both' },
  { id: 'handStats', title: 'Hand Stats', mode: 'both' },
  { id: 'turnFlow', title: 'Turn Flow', mode: 'both' },
  { id: 'lanePressure', title: 'Lane Pressure', mode: 'conquest' },
  { id: 'structureState', title: 'Structure State', mode: 'conquest' },
  { id: 'homesteadState', title: 'Homestead State', mode: 'conquest' },
  { id: 'debugLog', title: 'Debug Log', mode: 'both' },
  { id: 'targeting', title: 'Targeting', mode: 'both' },
  { id: 'movement', title: 'Movement', mode: 'conquest' },
  { id: 'actionTrace', title: 'Action Trace', mode: 'both' },
  { id: 'conquestDecks', title: 'Conquest Decks', mode: 'conquest' },
];

const DEV_PANEL_ALIAS = Object.fromEntries(DEV_PANEL_REGISTRY.map((panel) => [panel.id.toLowerCase(), panel.id]));
Object.assign(DEV_PANEL_ALIAS, {
  planner: 'aiPlanner',
  aiplanner: 'aiPlanner',
  graphs: 'aiGraphs',
  aigraphs: 'aiGraphs',
  deckviewer: 'deckViewer',
  deckgraph: 'deckGraphs',
  deckgraphs: 'deckGraphs',
  battlestats: 'battleStats',
  handstats: 'handStats',
  actiontrace: 'actionTrace',
  debuglog: 'debugLog',
  turnflow: 'turnFlow',
  showeconomy: 'economy',
  showranges: 'ranges',
  showvfx: 'vfx',
  showtags: 'unitTypes',
  showtypes: 'unitTypes',
  showownership: 'ownership',
  showthreatmap: 'threatMap',
  showmovement: 'movement',
  showcellcontrol: 'ownership',
  showfacilitydecks: 'conquestDecks',
});

const DEV_PANEL_GROUPS = {
  all: DEV_PANEL_REGISTRY.map((panel) => panel.id),
  graphs: ['aiGraphs', 'deckGraphs', 'battleStats', 'economy'],
  planner: ['aiPlanner', 'actionTrace'],
  decks: ['deckViewer', 'deckGraphs'],
  conquest: ['conquestDecks', 'ownership', 'threatMap', 'movement', 'lanePressure', 'structureState', 'homesteadState'],
};

const DEV_DEFAULT_PANELS = ['aiPlanner', 'aiGraphs', 'deckViewer', 'deckGraphs', 'battleStats', 'handStats', 'turnFlow', 'actionTrace', 'debugLog'];

function ensureDevPanelState() {
  DEV_PANEL_REGISTRY.forEach((panel) => {
    if (typeof state.devPanelVisibility[panel.id] !== 'boolean') state.devPanelVisibility[panel.id] = false;
    if (typeof state.devPanelCollapsed[panel.id] !== 'boolean') state.devPanelCollapsed[panel.id] = false;
  });
}

function resolveDevPanelIds(spec = '') {
  const key = String(spec ?? '').trim().replace(/^-+/, '').toLowerCase();
  if (!key) return [];
  if (DEV_PANEL_GROUPS[key]) return DEV_PANEL_GROUPS[key].slice();
  const direct = DEV_PANEL_ALIAS[key];
  return direct ? [direct] : [];
}

function listHidableDevPanels() {
  return DEV_PANEL_REGISTRY.map((panel) => panel.id);
}

function setDevPanelVisible(panelId, visible = true) {
  ensureDevPanelState();
  if (!DEV_PANEL_ALIAS[String(panelId ?? '').toLowerCase()]) return false;
  const normalized = DEV_PANEL_ALIAS[String(panelId ?? '').toLowerCase()];
  state.devPanelVisibility[normalized] = !!visible;
  return true;
}

function setDevPanelsVisible(ids = [], visible = true) {
  let changed = false;
  ids.forEach((id) => {
    changed = setDevPanelVisible(id, visible) || changed;
  });
  return changed;
}

function showAllDevPanels() {
  ensureDevPanelState();
  DEV_PANEL_REGISTRY.forEach((panel) => {
    state.devPanelVisibility[panel.id] = true;
  });
  state.devToolkitEnabled = true;
  state.devModeEnabled = true;
  state.aiDebugEnabled = true;
  state.playableDeckEnabled = true;
  state.dmPanelsVisible = true;
}

function hideAllDevPanels() {
  ensureDevPanelState();
  DEV_PANEL_REGISTRY.forEach((panel) => {
    state.devPanelVisibility[panel.id] = false;
  });
  state.devToolkitEnabled = false;
  state.devModeEnabled = false;
  state.aiDebugEnabled = false;
  state.playableDeckEnabled = false;
  state.dmPanelsVisible = false;
}

function toggleDevPanelCollapse(panelId) {
  ensureDevPanelState();
  const normalized = DEV_PANEL_ALIAS[String(panelId ?? '').toLowerCase()];
  if (!normalized) return;
  state.devPanelCollapsed[normalized] = !state.devPanelCollapsed[normalized];
}

function pushDevActionTrace(text = '', type = 'info') {
  if (!text) return;
  const item = {
    ts: Date.now(),
    type,
    text: String(text),
  };
  state.devMetrics.actionTrace.push(item);
  if (state.devMetrics.actionTrace.length > 120) state.devMetrics.actionTrace.shift();
}

function totalBoardValue(side = 'player') {
  const lane = side === 'player' ? state.playerMinions : state.enemyMinions;
  return lane.reduce((sum, card) => sum + Math.max(0, Number(card.attack ?? 0)) + Math.max(0, Number(card.health ?? 0)) + Math.max(0, Number(card.baseDef ?? 0)), 0);
}

function pushDevMetricSample(reason = 'tick') {
  const now = Date.now();
  if ((now - Number(state.devMetrics.lastSampleAt ?? 0)) < 220) return;
  state.devMetrics.lastSampleAt = now;
  const aiValue = totalBoardValue('enemy');
  const playerValue = totalBoardValue('player');
  state.devMetrics.aiTimeline.push({
    ts: now,
    reason,
    turn: state.currentTurn,
    phase: state.phase,
    aiThinking: state.aiThinking ? 1 : 0,
    boardDelta: aiValue - playerValue,
    manaDelta: Number(state.maxMana ?? 0) - Number(state.mana ?? 0),
  });
  if (state.devMetrics.aiTimeline.length > 90) state.devMetrics.aiTimeline.shift();
  state.devMetrics.boardValueTimeline.push({
    ts: now,
    player: playerValue,
    enemy: aiValue,
  });
  if (state.devMetrics.boardValueTimeline.length > 90) state.devMetrics.boardValueTimeline.shift();
  state.devMetrics.deckSizeTimeline.push({
    ts: now,
    playerDeck: state.playerDeck.length,
    playerHand: state.hand.length,
    enemyBoard: state.enemyMinions.length,
  });
  if (state.devMetrics.deckSizeTimeline.length > 90) state.devMetrics.deckSizeTimeline.shift();
}

function renderDevSparkline(values = [], classFn = null) {
  if (!values.length) return '<div class="dev-note dev-muted">No samples yet.</div>';
  const max = Math.max(1, ...values.map((entry) => Math.abs(Number(entry ?? 0))));
  return `<div class="dev-sparkline">${values.map((raw) => {
    const value = Number(raw ?? 0);
    const ratio = Math.max(4, Math.round((Math.abs(value) / max) * 100));
    const tone = typeof classFn === 'function' ? classFn(value) : '';
    return `<i class="${tone ?? ''}" style="height:${ratio}%"></i>`;
  }).join('')}</div>`;
}

function renderDeckCurveBars(entries = []) {
  const buckets = Array.from({ length: 8 }, (_, idx) => ({ idx, count: 0 }));
  entries.forEach((entry) => {
    const value = Math.max(0, Math.min(7, Math.floor(toNumber(entry.cost, 0))));
    buckets[value].count += 1;
  });
  const max = Math.max(1, ...buckets.map((bucket) => bucket.count));
  return `
    <div class="dev-kv">
      ${buckets.map((bucket) => `<strong>${bucket.idx}+</strong><div>${Math.round((bucket.count / max) * 100)}% (${bucket.count})</div>`).join('')}
    </div>
  `;
}

function renderDevPanelBody(panelId) {
  const active = currentAiProfile();
  if (panelId === 'aiPlanner') {
    const debug = active ? getPlannerDebug(active.id) : null;
    const candidates = (state.devMetrics.lastAiCandidates ?? []).slice(0, 6);
    const candidateHtml = candidates.length
      ? `<ul class="dev-list">${candidates.map((row) => `<li>${row}</li>`).join('')}</ul>`
      : '<div class="dev-note">No AI candidates captured yet.</div>';
    return `
      <div class="dev-kv">
        <strong>Phase</strong><div>${state.devMetrics.aiPhase ?? 'idle'}</div>
        <strong>Thinking</strong><div>${state.aiThinking ? state.aiThinkingLine : state.lastAiTrace}</div>
        <strong>Formation</strong><div>${debug?.currentFormation ?? debug?.formationId ?? 'n/a'}</div>
        <strong>Reason</strong><div>${debug?.formationReason ?? 'n/a'}</div>
      </div>
      ${candidateHtml}
    `;
  }
  if (panelId === 'aiGraphs') {
    const samples = state.devMetrics.aiTimeline.slice(-36);
    const boardDelta = samples.map((entry) => Number(entry.boardDelta ?? 0));
    const manaDelta = samples.map((entry) => Number(entry.manaDelta ?? 0));
    return `
      <div class="dev-note">Board Delta (enemy - player)</div>
      ${renderDevSparkline(boardDelta, (value) => (value > 0 ? 'warn' : value < 0 ? 'bad' : ''))}
      <div class="dev-note">Mana Spend Pulse</div>
      ${renderDevSparkline(manaDelta)}
    `;
  }
  if (panelId === 'deckViewer') {
    const player = getSortedDeckTracker('player');
    const enemy = getSortedDeckTracker('enemy');
    const statusCount = (entries, key) => entries.filter((entry) => String(entry.status) === key).length;
    return `
      <div class="dev-kv">
        <strong>Player Deck</strong><div>in deck ${statusCount(player, 'in_deck')} • hand ${statusCount(player, 'in_hand')} • played ${statusCount(player, 'played')}</div>
        <strong>Enemy Deck</strong><div>in deck ${statusCount(enemy, 'in_deck')} • hand ${statusCount(enemy, 'in_hand')} • played ${statusCount(enemy, 'played')}</div>
      </div>
      <div class="dev-chip-list">
        <span class="dev-chip">Player total: ${player.length}</span>
        <span class="dev-chip">Enemy total: ${enemy.length}</span>
        <span class="dev-chip">Sort: ${state.playableDeckSort}</span>
      </div>
    `;
  }
  if (panelId === 'deckGraphs') {
    const player = getSortedDeckTracker('player');
    return `
      <div class="dev-note">Player Cost Curve</div>
      ${renderDeckCurveBars(player)}
      <div class="dev-note">Draw Risk: ${state.playerDeck.length <= 6 ? 'HIGH' : state.playerDeck.length <= 12 ? 'MEDIUM' : 'LOW'} (${state.playerDeck.length} cards left)</div>
    `;
  }
  if (panelId === 'economy') {
    const samples = state.devMetrics.deckSizeTimeline.slice(-36);
    return `
      <div class="dev-kv">
        <strong>Mana</strong><div>${state.mana}/${state.maxMana}</div>
        <strong>Deck</strong><div>${state.playerDeck.length}</div>
        <strong>Hand</strong><div>${state.hand.length}</div>
      </div>
      <div class="dev-note">Deck/Hand Pulse</div>
      ${renderDevSparkline(samples.map((row) => Number(row.playerDeck ?? 0)), (v) => (v <= 5 ? 'bad' : v <= 10 ? 'warn' : ''))}
    `;
  }
  if (panelId === 'battleStats' || panelId === 'warStats') {
    const samples = state.devMetrics.boardValueTimeline.slice(-1)[0];
    return `
      <div class="dev-kv">
        <strong>Player HP</strong><div>${state.playerHealth}/${state.playerMaxHealth}</div>
        <strong>Enemy HP</strong><div>${state.enemyHealth}/${state.enemyMaxHealth}</div>
        <strong>Board Value</strong><div>P ${samples?.player ?? totalBoardValue('player')} / E ${samples?.enemy ?? totalBoardValue('enemy')}</div>
        <strong>Turn</strong><div>${state.currentTurn} • ${state.phase}</div>
      </div>
    `;
  }
  if (panelId === 'handStats') {
    const costs = state.hand.map((card) => toNumber(card.cost, 0));
    return `
      <div class="dev-kv">
        <strong>Cards</strong><div>${state.hand.length}</div>
        <strong>Avg Cost</strong><div>${costs.length ? (costs.reduce((a, b) => a + b, 0) / costs.length).toFixed(2) : '0.00'}</div>
        <strong>Playable</strong><div>${state.hand.filter((card) => toNumber(card.cost, 0) <= state.mana).length}</div>
      </div>
      ${renderDevSparkline(costs)}
    `;
  }
  if (panelId === 'turnFlow' || panelId === 'actionTrace' || panelId === 'debugLog') {
    const trace = state.devMetrics.actionTrace.slice(-20).reverse();
    if (!trace.length) return '<div class="dev-note">No actions captured yet.</div>';
    return `<ul class="dev-list">${trace.map((entry) => `<li>[${new Date(entry.ts).toLocaleTimeString()}] ${entry.text}</li>`).join('')}</ul>`;
  }
  if (panelId === 'targeting') {
    return `<div class="dev-kv"><strong>Selected Attacker</strong><div>${state.selectedAttackerId ?? 'none'}</div><strong>Spell Targeting</strong><div>${state.selectedSpellTargetMode ? 'armed' : 'idle'}</div></div>`;
  }
  if (panelId === 'vfx') {
    return '<div class="dev-note">VFX bus trace is active in dev mode. Use `./showvfx` + context actions to monitor emitters.</div>';
  }
  if (panelId === 'ranges') {
    return '<div class="dev-note">Range overlays are mode-aware. In duel mode, use target highlighting and inspect to verify legal arcs.</div>';
  }
  if (panelId === 'unitTypes') {
    const entries = [...state.playerMinions, ...state.enemyMinions];
    const types = entries.reduce((acc, item) => {
      const key = String(item.type ?? 'unit');
      acc[key] = Number(acc[key] ?? 0) + 1;
      return acc;
    }, {});
    const typeItems = Object.entries(types);
    if (!typeItems.length) return '<div class="dev-note">No units on board.</div>';
    return `<div class="dev-chip-list">${typeItems.map(([name, count]) => `<span class="dev-chip">${name}: ${count}</span>`).join('')}</div>`;
  }
  if (panelId === 'conquestDecks' || panelId === 'threatMap' || panelId === 'ownership' || panelId === 'lanePressure' || panelId === 'structureState' || panelId === 'movement' || panelId === 'homesteadState') {
    return '<div class="dev-note">This panel is available in Conquest mode via the same `./dev`/`./hide` commands.</div>';
  }
  return '<div class="dev-note">Panel ready.</div>';
}

function renderDevSuite() {
  const host = document.querySelector('#dev-suite');
  if (!host) return;
  ensureDevPanelState();
  pushDevMetricSample('render');
  const visible = DEV_PANEL_REGISTRY.map((panel) => panel.id).filter((id) => !!state.devPanelVisibility[id]);
  const shouldShow = !!state.devToolkitEnabled && visible.length > 0;
  host.classList.toggle('hidden', !shouldShow);
  if (!shouldShow) {
    host.innerHTML = '';
    return;
  }
  host.innerHTML = visible.map((panelId) => {
    const panel = DEV_PANEL_REGISTRY.find((entry) => entry.id === panelId) ?? { id: panelId, title: panelId };
    const collapsed = !!state.devPanelCollapsed[panelId];
    return `
      <article class="dev-panel ${collapsed ? 'collapsed' : ''}" data-dev-panel="${panelId}">
        <header class="dev-panel-head">
          <button class="dev-collapse-btn" data-dev-collapse="${panelId}" aria-label="Toggle ${panel.title}">${collapsed ? '>' : 'v'}</button>
          <h3>${panel.title}</h3>
          <small>${panelId}</small>
        </header>
        <div class="dev-panel-body">${renderDevPanelBody(panelId)}</div>
      </article>
    `;
  }).join('');
  host.querySelectorAll('[data-dev-collapse]').forEach((button) => {
    button.addEventListener('click', () => {
      toggleDevPanelCollapse(button.dataset.devCollapse);
      renderDevSuite();
    });
  });
}

const log = (msg) => {
  const host = document.querySelector('#log');
  host.innerHTML = `<div>${msg}</div>` + host.innerHTML;
};
const showHint = (msg = '') => { document.querySelector('#hint').textContent = msg; };

function setLeftPointerHeld(active) {
  state.leftPointerHeld = !!active;
  document.body.classList.toggle('left-click-hold', state.leftPointerHeld);
}

function setDragInteractionActive(active) {
  state.dragInteractionActive = !!active;
  document.body.classList.toggle('interaction-drag-active', state.dragInteractionActive);
}
function loadCustomCards() {
  try {
    const library = JSON.parse(localStorage.getItem('cardforge.creator.customCards.v1') || '{}');
    if (!library || typeof library !== 'object') return [];
    return Object.values(library).filter((entry) => entry && typeof entry === 'object' && entry.id);
  } catch {
    return [];
  }
}

function loadExternalUserPackCards() {
  try {
    const packs = JSON.parse(localStorage.getItem('cardforge.external_user_packs.v1') || '[]');
    if (!Array.isArray(packs)) return [];
    return packs.flatMap((pack) => Array.isArray(pack?.cards) ? pack.cards : []).filter((entry) => entry && typeof entry === 'object' && entry.id);
  } catch {
    return [];
  }
}

const getAllCards = () => {
  const base = LOCAL_MODE ? LOCAL_RUNTIME_DATA.cards : registry.list('cardPacks').flatMap((pack) => pack.cards);
  const customPackCards = Array.isArray(state.profile?.customPackDefs)
    ? state.profile.customPackDefs.flatMap((pack) => Array.isArray(pack?.cards) ? pack.cards : [])
    : [];
  const externalPackCards = loadExternalUserPackCards();
  const custom = loadCustomCards();
  if (!custom.length && !customPackCards.length && !externalPackCards.length) return base;
  const byId = new Map();
  [...base, ...customPackCards, ...externalPackCards, ...custom].forEach((card) => {
    if (!card?.id) return;
    byId.set(card.id, { ...card });
  });
  return [...byId.values()];
};
const currentAiProfile = () => state.aiProfiles.find((profile) => profile.id === state.selectedAiId) ?? state.aiProfiles[0] ?? null;
const getSelectedDeck = () => state.decks.find((deck) => deck.id === state.selectedDeckId) ?? state.decks[0] ?? null;
const persistProfile = () => saveProfile(state.profile);

function patchAiProfile(profileId, updater) {
  if (!profileId) return null;
  let patched = null;
  state.aiProfiles = (state.aiProfiles ?? []).map((profile) => {
    if (profile.id !== profileId) return profile;
    patched = typeof updater === 'function'
      ? (updater(profile) ?? profile)
      : { ...profile, ...(updater ?? {}) };
    return patched;
  });
  return patched;
}

function syncAiProfileFromDeck(profileId, cards = []) {
  const active = state.aiProfiles.find((profile) => profile.id === profileId);
  if (!active) return null;
  const threatMemory = state.aiThreatMemory[profileId] ?? active.threatMemory ?? { respectList: [], seenCards: {}, events: [] };
  const hydrated = enrichAiProfile({ ...active, threatMemory }, cards);
  patchAiProfile(profileId, () => hydrated);
  return hydrated;
}

function ensureAiThreatMemory(profileId) {
  if (!profileId) return { respectList: [], seenCards: {}, events: [] };
  const memory = state.aiThreatMemory[profileId] ?? { respectList: [], seenCards: {}, events: [] };
  if (!Array.isArray(memory.respectList)) memory.respectList = [];
  if (!memory.seenCards || typeof memory.seenCards !== 'object') memory.seenCards = {};
  if (!Array.isArray(memory.events)) memory.events = [];
  state.aiThreatMemory[profileId] = memory;
  return memory;
}

function toNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function enemySide(side = 'player') {
  return side === 'player' ? 'enemy' : 'player';
}

function unitLaneForSide(side = 'player') {
  return side === 'player' ? state.playerMinions : state.enemyMinions;
}

function heroHealthForSide(side = 'player') {
  return side === 'player' ? state.playerHealth : state.enemyHealth;
}

function heroMaxHealthForSide(side = 'player') {
  return side === 'player' ? state.playerMaxHealth : state.enemyMaxHealth;
}

function setHeroHealthForSide(side = 'player', value = 0) {
  if (side === 'player') state.playerHealth = value;
  else state.enemyHealth = value;
}

function getTurnFlags(side = 'player') {
  return state.turnFlags?.[side] ?? state.turnFlags.player;
}

function familiarityPoolForSide(side = 'player') {
  state.familiarity = state.familiarity && typeof state.familiarity === 'object' ? state.familiarity : { player: {}, enemy: {} };
  state.familiarity[side] = ensureFamiliarityPool(state.familiarity[side]);
  return state.familiarity[side];
}

function resetTurnFlags(side = 'player') {
  state.turnFlags[side] = {
    healedAmount: 0,
    healedCharacters: 0,
    minionDamaged: false,
    minionDied: false,
    enemyMinionDied: false,
    playedSpell: false,
    playedMinion: false,
    cardsPlayed: 0,
    attacked: false,
    firstSpellCard: null,
    spellDamageBonus: 0,
    heroImmune: false,
    castBlessing: false,
    lookedAtDeck: false,
    drewOutsideTurn: 0,
    playedFamilies: {},
    diedFamilies: {},
  };
}

function noteTurnFlag(side = 'player', key = '', amount = 1) {
  const flags = getTurnFlags(side);
  if (typeof flags[key] === 'number') flags[key] += amount;
  else flags[key] = amount > 0;
}

function noteFamilyTurnFlag(side = 'player', bucket = 'playedFamilies', card = null) {
  if (!card) return;
  const flags = getTurnFlags(side);
  flags[bucket] = flags[bucket] && typeof flags[bucket] === 'object' ? flags[bucket] : {};
  collectCardFamilies(card).forEach((family) => {
    flags[bucket][family] = Math.max(0, Number(flags[bucket][family] ?? 0) + 1);
  });
}

function familyTurnCount(side = 'player', bucket = 'playedFamilies', token = '') {
  const needle = normalizeFamilyToken(token);
  if (!needle) return 0;
  return Math.max(0, Number(getTurnFlags(side)?.[bucket]?.[needle] ?? 0));
}

function sideHandFor(side = 'player') {
  if (side === 'player') return state.hand ?? [];
  return state.enemyDeck ?? [];
}

function cardsInZone(side = 'player', zone = 'board') {
  const key = String(zone ?? 'board').toLowerCase();
  if (key === 'board' || key === 'battlefield' || key === 'lane') {
    return unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0);
  }
  if (key === 'hand') return sideHandFor(side);
  if (key === 'deck') return side === 'player' ? (state.playerDeck ?? []) : (state.enemyDeck ?? []);
  if (key === 'grave' || key === 'graveyard' || key === 'discard') return withSideZone(side, 'graveyard');
  if (key === 'field') return withSideZone(side, 'field');
  if (key === 'relic') return withSideZone(side, 'relic');
  return [];
}

function familyCountInZone(side = 'player', family = '', zone = 'board') {
  return countCardsByFamily(cardsInZone(side, zone), family, (card) => {
    if (zone === 'board') return (card?.health ?? 0) > 0;
    return true;
  });
}

function familyThresholdMet(side = 'player', family = '', zone = 'board', threshold = 1) {
  return familyCountInZone(side, family, zone) >= Math.max(0, Number(threshold ?? 0));
}

function renderFamilyBadges(card = {}, className = 'family-badge') {
  const families = extractCardRaces(card);
  if (!families.length) return '<span class="family-badge neutral">NE</span>';
  return families
    .map((family) => {
      const meta = raceMeta(family);
      return `<span class="${className}" data-family="${meta.id}" title="${meta.label}">${raceIconGlyph(meta.id)}</span>`;
    })
    .join('');
}

function familySummary(card = {}) {
  const families = extractCardRaces(card);
  if (!families.length) return 'Neutral';
  return families.map((family) => raceMeta(family).label).join(' / ');
}

function parseFamilyList(fragment = '') {
  return String(fragment ?? '')
    .split(/,|\band\b/gi)
    .map((token) => normalizeFamilyToken(token))
    .filter(Boolean);
}

function familiaritySummary(side = 'player', card = null) {
  const pool = familiarityPoolForSide(side);
  const focus = card ? collectCardFamilies(card) : Object.keys(pool);
  const entries = [...new Set(focus)]
    .map((family) => {
      const amount = getFamiliarity(pool, family);
      if (amount <= 0) return null;
      return `${raceIconGlyph(family)} ${amount}`;
    })
    .filter(Boolean);
  return entries.join(' · ') || 'None';
}

function clearTemporaryTurnBuffs(side = 'player') {
  unitLaneForSide(side).forEach((unit) => {
    const tempAtk = Math.max(0, toNumber(unit?.statuses?.tempAttackBonus ?? 0));
    if (tempAtk > 0) {
      unit.attack = Math.max(0, toNumber(unit.attack, 0) - tempAtk);
      unit.statuses.tempAttackBonus = 0;
    }
    const tempHp = Math.max(0, toNumber(unit?.statuses?.tempHealthBonus ?? 0));
    if (tempHp > 0) {
      unit.maxHealth = Math.max(1, toNumber(unit.maxHealth ?? unit.health, 1) - tempHp);
      unit.health = Math.min(toNumber(unit.health, 1), unit.maxHealth);
      unit.statuses.tempHealthBonus = 0;
    }
    if (unit?.statuses?.tempTaunt) {
      unit.statuses.tempTaunt = 0;
      unit.taunt = !!unit.baseTaunt || !!unit.defense || !!unit.statuses?.auraTaunt;
    }
    if (unit?.statuses?.tempFlying) {
      unit.statuses.tempFlying = 0;
      unit.flying = !!unit.baseFlying || !!unit.statuses?.auraFlying;
    }
    if (unit?.statuses?.tempLifesteal) {
      unit.statuses.tempLifesteal = 0;
      unit.lifesteal = !!unit.baseLifesteal || !!unit.statuses?.auraLifesteal;
    }
    if (unit?.statuses?.tempRush) {
      unit.statuses.tempRush = 0;
      unit.rush = !!unit.baseRush || !!unit.statuses?.auraRush;
    }
    if (unit?.statuses) unit.statuses.stealthAttackPersistUsed = 0;
    if (unit?.statuses) unit.statuses.drawOnceUsed = false;
  });
}

function canRetainStealthAfterAttack(side = 'player', unit = null) {
  if (!unit) return false;
  refreshAuraStateForUnit(side, unit);
  const aura = unitLaneForSide(side).some((entry) => {
    if ((entry?.health ?? 0) <= 0) return false;
    return /stealthed minions keep stealth after attacking once this turn/.test(cardText(entry).toLowerCase());
  }) || !!unit?.statuses?.keepStealthAfterAttackAura;
  if (!aura) return false;
  unit.statuses = unit.statuses ?? {};
  if (unit.statuses.stealthAttackPersistUsed) return false;
  unit.statuses.stealthAttackPersistUsed = 1;
  return true;
}

function consumeStealthOnAttack(side = 'player', unit = null) {
  if (!unit) return;
  const hadStealth = !!(unit.stealth || unit.statuses?.stealth);
  if (!hadStealth) return;
  if (canRetainStealthAfterAttack(side, unit)) return;
  unit.stealth = false;
  unit.statuses = unit.statuses ?? {};
  unit.statuses.stealth = false;
  triggerAbilityEvent(side, 'on_stealth_loss_friendly', { side, self: unit, target: unit });
}

function seedCardFamiliarity(side = 'player', card = null) {
  const fam = card?.familiarity && typeof card.familiarity === 'object' ? card.familiarity : {};
  const family = normalizeFamilyToken(fam.race ?? card?.familiarityRace ?? '');
  const amount = Math.max(0, toNumber(fam.start ?? card?.familiarityStart ?? 0, 0));
  if (!family || amount <= 0) return 0;
  return addFamiliarity(familiarityPoolForSide(side), family, amount);
}

function cardText(card = {}) {
  return normalizeAbilityText(card?.text ?? '');
}

function isBlessingCard(card = {}) {
  const name = String(card?.name ?? '').toLowerCase();
  const text = cardText(card).toLowerCase();
  const tags = Array.isArray(card?.tags) ? card.tags.map((tag) => String(tag).toLowerCase()) : [];
  return name.includes('blessing')
    || text.includes('blessing')
    || tags.some((tag) => tag.includes('blessing') || tag.includes('blessed'));
}

function hasRaceOrTag(unit = {}, token = '') {
  return hasFamilyTag(unit, token);
}

function boardHas(side = 'player', matcher = () => false) {
  return unitLaneForSide(side).some((unit) => (unit?.health ?? 0) > 0 && matcher(unit));
}

function sideOfUnit(unit = null) {
  if (!unit) return null;
  if (state.playerMinions.some((entry) => entry.id === unit.id)) return 'player';
  if (state.enemyMinions.some((entry) => entry.id === unit.id)) return 'enemy';
  return null;
}

function damagedMinions(side = 'player') {
  return unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0 && (unit?.health ?? 0) < (unit?.maxHealth ?? unit?.health ?? 0));
}

function randomFrom(list = []) {
  if (!Array.isArray(list) || !list.length) return null;
  return list[Math.floor(Math.random() * list.length)] ?? null;
}

function getAbilityClauses(card = {}) {
  const text = cardText(card);
  if (looksLikeNoText(text)) return [];
  const key = `${card?.id ?? card?.name ?? 'card'}::${text}`;
  const cached = state.abilityClauseCache.get(key);
  if (cached) return cached;
  const clauses = parseAbilityClauses(text);
  state.abilityClauseCache.set(key, clauses);
  return clauses;
}

function triggerMatchesEvent(trigger = '', eventKey = '') {
  const trig = String(trigger || '').toLowerCase();
  const evt = String(eventKey || '').toLowerCase();
  if (trig === evt) return true;
  if (trig === 'on_survive_damage_any' && evt === 'on_survive_damage_self') return true;
  if (trig === 'on_heal_any' && evt === 'on_heal_self') return true;
  if (trig === 'on_attack_any' && evt === 'on_attack_self') return true;
  if (trig === 'on_kill_any' && evt === 'on_kill_self') return true;
  if (trig === 'on_overkill_any' && evt === 'on_overkill_self') return true;
  if (trig === 'on_any_end_turn' && evt === 'on_end_turn') return true;
  if (trig === 'on_stealth_gain_friendly' && evt === 'on_stealth_gain_self') return true;
  if (trig === 'on_enemy_attack_friendly' && evt === 'on_enemy_attack_targeting_friendly') return true;
  if (trig === 'on_draw' && evt === 'on_drawn_self') return true;
  return false;
}

function evaluateAbilityCondition(condition = '', runtime = {}) {
  const source = normalizeAbilityText(condition).toLowerCase();
  if (!source) return true;
  const side = runtime.side ?? 'player';
  const foe = enemySide(side);
  const self = runtime.self ?? null;
  const flags = getTurnFlags(side);
  const foeFlags = getTurnFlags(foe);
  const lastFlags = state.lastTurnFlags?.[side] ?? {};
  const amountMatch = source.match(/(\d+)\s+or\s+more/);
  const threshold = amountMatch ? Number(amountMatch[1]) : null;
  const knownFamily = (token = '') => RACE_LIBRARY.some((entry) => entry.id === normalizeFamilyToken(token));

  const deckOnlyListMatch = source.match(/your\s+deck\s+contains\s+only\s+([a-z-,\sand]+)$/i);
  if (deckOnlyListMatch) {
    const families = parseFamilyList(deckOnlyListMatch[1]);
    if (families.length === 1) return deckContainsOnlyFamily(cardsInZone(side, 'deck'), families[0]);
    if (families.length > 1) return deckContainsOnlyFamilies(cardsInZone(side, 'deck'), families);
  }

  const halfBoardMatch = source.match(/at\s+least\s+half\s+your\s+board\s+is\s+([a-z-]+)s?/i);
  if (halfBoardMatch) return boardFamilyRatio(cardsInZone(side, 'board'), halfBoardMatch[1]) >= 0.5;

  const controlAtLeastMatch = source.match(/you\s+control\s+(\d+)(?:\s+or\s+more)?\s+([a-z-]+)s?/i);
  if (controlAtLeastMatch && knownFamily(controlAtLeastMatch[2])) {
    return familyThresholdMet(side, controlAtLeastMatch[2], 'board', Number(controlAtLeastMatch[1] ?? 0));
  }

  const inHandAtLeastMatch = source.match(/(?:you\s+have|there\s+are)\s+(\d+)(?:\s+or\s+more)?\s+([a-z-]+)s?\s+in\s+your\s+hand/i);
  if (inHandAtLeastMatch && knownFamily(inHandAtLeastMatch[2])) {
    return familyThresholdMet(side, inHandAtLeastMatch[2], 'hand', Number(inHandAtLeastMatch[1] ?? 0));
  }

  const inDeckAtLeastMatch = source.match(/(?:you\s+have|there\s+are)\s+(\d+)(?:\s+or\s+more)?\s+([a-z-]+)s?\s+in\s+your\s+deck/i);
  if (inDeckAtLeastMatch && knownFamily(inDeckAtLeastMatch[2])) {
    return familyThresholdMet(side, inDeckAtLeastMatch[2], 'deck', Number(inDeckAtLeastMatch[1] ?? 0));
  }

  const inGraveAtLeastMatch = source.match(/(?:you\s+have|there\s+are)\s+(\d+)(?:\s+or\s+more)?\s+([a-z-]+)s?\s+in\s+your\s+(?:grave|graveyard|discard)/i);
  if (inGraveAtLeastMatch && knownFamily(inGraveAtLeastMatch[2])) {
    return familyThresholdMet(side, inGraveAtLeastMatch[2], 'graveyard', Number(inGraveAtLeastMatch[1] ?? 0));
  }

  const playedFamilyMatch = source.match(/([a-z-]+)\s+was\s+played\s+this\s+turn/i)
    || source.match(/you\s+played\s+a[n]?\s+([a-z-]+)\s+this\s+turn/i);
  if (playedFamilyMatch && knownFamily(playedFamilyMatch[1])) {
    return familyTurnCount(side, 'playedFamilies', playedFamilyMatch[1]) > 0;
  }

  const diedFamilyMatch = source.match(/([a-z-]+)\s+died\s+this\s+turn/i);
  if (diedFamilyMatch && knownFamily(diedFamilyMatch[1])) {
    return familyTurnCount(side, 'diedFamilies', diedFamilyMatch[1]) > 0
      || familyTurnCount(foe, 'diedFamilies', diedFamilyMatch[1]) > 0;
  }

  const familiarityAtLeastMatch = source.match(/([a-z-]+)\s+familiarity\s+(\d+)/i);
  if (familiarityAtLeastMatch && knownFamily(familiarityAtLeastMatch[1])) {
    return getFamiliarity(familiarityPoolForSide(side), familiarityAtLeastMatch[1]) >= Number(familiarityAtLeastMatch[2] ?? 0);
  }

  if (source.includes('you played a spell this turn')) return !!flags.playedSpell;
  if (source.includes('you cast a blessing this turn')) return !!flags.castBlessing;
  if (source.includes('you played another card this turn')) return Number(flags.cardsPlayed ?? 0) >= 2;
  if (source.includes('you played exactly two cards')) return Number(flags.cardsPlayed ?? 0) === 2;
  if (source.includes('you played both a minion and a spell this turn')) return !!flags.playedSpell && !!flags.playedMinion;
  if (source.includes("you didn't attack")) return !flags.attacked;
  if (source.includes('you played a spell last turn')) return !!lastFlags.playedSpell;
  if (source.includes('you restored health this turn')) {
    const healed = Number(flags.healedAmount ?? 0);
    return threshold == null ? healed > 0 : healed >= threshold;
  }
  if (source.includes('friendly minion was healed this turn')) return Number(flags.healedCharacters ?? 0) > 0;
  if (source.includes('a minion took damage this turn') || source.includes('a minion was damaged this turn')) {
    return !!flags.minionDamaged || !!foeFlags.minionDamaged;
  }
  if (source.includes('a minion died this turn')) return !!flags.minionDied || !!foeFlags.minionDied;
  if (source.includes('enemy is damaged') || source.includes('an enemy is damaged')) {
    return damagedMinions(foe).length > 0 || heroHealthForSide(foe) < heroMaxHealthForSide(foe);
  }
  if (source.includes('if all your minions are stealthed or hidden')) {
    const lane = unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0);
    return lane.length > 0 && lane.every((unit) => !!unit.stealth || !!unit.statuses?.stealth || !!unit.statuses?.hidden);
  }
  if (source.includes('you control no other minions')) {
    const own = unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0 && (!self || unit.id !== self.id));
    return own.length === 0;
  }
  if (source.includes('you control a relic')) return withSideZone(side, 'relic').length > 0;
  if (source.includes('you control a field')) return withSideZone(side, 'field').length > 0;
  if (source.includes('you control a relic and a field')) return withSideZone(side, 'relic').length > 0 && withSideZone(side, 'field').length > 0;
  if (source.includes('you control a relic or field')) return withSideZone(side, 'relic').length > 0 || withSideZone(side, 'field').length > 0;
  if (source.includes('you control a ship')) return boardHas(side, (unit) => hasRaceOrTag(unit, 'ship'));
  if (source.includes('you control a beast')) return boardHas(side, (unit) => hasRaceOrTag(unit, 'beast'));
  if (source.includes('you control a skeleton')) return boardHas(side, (unit) => hasRaceOrTag(unit, 'skeleton'));
  const genericControlMatch = source.match(/you\s+control\s+a[n]?\s+([a-z-]+)/i);
  if (genericControlMatch && knownFamily(genericControlMatch[1])) return boardHas(side, (unit) => hasRaceOrTag(unit, genericControlMatch[1]));
  if (source.includes('you control a tamer') || source.includes('you control this')) return boardHas(side, (unit) => hasRaceOrTag(unit, 'tamer') || hasRaceOrTag(unit, 'handler'));
  if (source.includes('you control a damaged beast')) {
    return unitLaneForSide(side).some((unit) => hasRaceOrTag(unit, 'beast') && (unit.health ?? 0) > 0 && (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0));
  }
  if (source.includes('a friendly minion is at full health')) {
    return unitLaneForSide(side).some((unit) => (unit.health ?? 0) > 0 && (unit.health ?? 0) >= (unit.maxHealth ?? unit.health ?? 0));
  }
  if (source.includes('you control a stealthed minion')) return boardHas(side, (unit) => !!unit.stealth || !!unit.statuses?.stealth);
  if (source.includes('an enemy is isolated')) {
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (!target) return false;
    const targetLane = slotLane(target.slot ?? -1);
    const sameLane = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && slotLane(unit.slot ?? -1) === targetLane);
    return sameLane.length <= 1;
  }
  if (source.includes('a minion is marked or damaged')) {
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe)) ?? getPriorityEnemyTarget(unitLaneForSide(side));
    if (!target) return false;
    const damaged = (target.health ?? 0) < (target.maxHealth ?? target.health ?? 0);
    return damaged || !!target.statuses?.marked;
  }
  if (source.includes('you summon a beast')) return !!runtime.summoned && hasRaceOrTag(runtime.summoned, 'beast');
  if (source.includes('you summon a skeleton')) return !!runtime.summoned && hasRaceOrTag(runtime.summoned, 'skeleton');
  if (source.includes('you summon a spirit')) return !!runtime.summoned && hasRaceOrTag(runtime.summoned, 'spirit');
  if (source.includes('you play a relic')) return !!runtime.playedCard && (normalizeCardType(runtime.playedCard) === 'relic' || cardMatchesFamily(runtime.playedCard, 'relic'));
  if (source.includes('you play a ship')) return !!runtime.playedCard && cardMatchesFamily(runtime.playedCard, 'ship');
  if (source.includes('you play a stealthed minion')) return !!runtime.playedCard && normalizeCardType(runtime.playedCard) === 'minion' && (!!runtime.playedCard.stealth || /stealth/.test(cardText(runtime.playedCard).toLowerCase()));
  if (source.includes('you play a tamer')) return !!runtime.playedCard && (cardMatchesFamily(runtime.playedCard, 'tamer') || cardMatchesFamily(runtime.playedCard, 'handler'));
  if (source.includes('you play a beast')) return !!runtime.playedCard && cardMatchesFamily(runtime.playedCard, 'beast');
  if (source.includes('you control serathi')) return boardHas(side, (unit) => String(unit.name ?? '').toLowerCase().includes('serathi'));
  if (source.includes('you return a friendly minion to your hand')) return !!runtime.returned;
  if (source.includes('a friendly minion gains stealth') || source.includes('friendly minion becomes stealthed')) {
    return !!runtime.target && !!(runtime.target.stealth || runtime.target.statuses?.stealth);
  }
  if (source.includes('a friendly minion loses stealth')) {
    return !!runtime.target && !(runtime.target.stealth || runtime.target.statuses?.stealth);
  }
  const minHealthAttack = source.match(/a minion with (\d+) or more health attacks/);
  if (minHealthAttack) {
    const thresholdHp = Number(minHealthAttack[1] ?? 0);
    const attacker = runtime.self ?? runtime.attacker ?? null;
    return toNumber(attacker?.health ?? attacker?.maxHealth, 0) >= thresholdHp;
  }
  if (source.includes('one of your stealthed minions attacks')) {
    const attacker = runtime.self ?? runtime.attacker ?? null;
    return !!attacker && !!(attacker.stealth || attacker.statuses?.stealth);
  }
  if (source.includes('an enemy attacks your minion')) return !!runtime.attacker && sideOfUnit(runtime.attacker) === enemySide(side);
  if (source.includes('you look at or manipulate your deck') || source.includes('you manipulate your deck')) return !!runtime.peekedCard || !!runtime.peekedCards || !!flags.lookedAtDeck;
  if (source.includes('a minion is frozen')) return !!runtime.target?.statuses?.freezeTurns;
  const triggerCount = source.match(/this triggers (\d+) times/);
  if (triggerCount) return toNumber(self?.statuses?.abilityTriggerCount, 0) >= Number(triggerCount[1] ?? 0);
  if (source.includes('a ship is destroyed or removed')) return !!runtime.deadUnit && hasRaceOrTag(runtime.deadUnit, 'ship');
  if (source.includes('a skeleton dies')) return !!runtime.deadUnit && hasRaceOrTag(runtime.deadUnit, 'skeleton');
  if (source.includes('a spirit dies')) return !!runtime.deadUnit && hasRaceOrTag(runtime.deadUnit, 'spirit');
  if (source.includes('a damaged enemy dies')) return !!runtime.deadUnit && runtime.deadSide === foe;
  if (source.includes('a minion survives damage')) return !!runtime.self && (runtime.self.health ?? 0) > 0;
  if (source.includes('this took damage this turn')) return !!self?.statuses?.damagedThisTurn;
  if (source.includes('target was already damaged')) return !!runtime.targetWasDamaged;
  if (source.includes('it survives')) return !!runtime.lastTargetSurvived;
  if (source.includes('it dies')) return !!runtime.lastTargetDied;
  if (source.includes('fully healed')) return !!runtime.lastHealTargetFullyHealed;
  if (source.includes('it is a spell')) return normalizeCardType(runtime.peekedTopCard ?? {}) === 'spell';
  if (source.includes("it's a spell")) return normalizeCardType(runtime.peekedTopCard ?? {}) === 'spell';
  if (source.includes('it is a minion')) return normalizeCardType(runtime.peekedTopCard ?? {}) === 'minion';
  if (source.includes('it is stealthed')) return !!(runtime.target?.stealth || runtime.target?.statuses?.stealth || runtime.self?.stealth || runtime.self?.statuses?.stealth);
  if (source.includes('it is a beast')) {
    const target = runtime.target ?? runtime.self ?? null;
    return !!target && hasRaceOrTag(target, 'beast');
  }
  if (source.includes('it is flying')) {
    const target = runtime.target ?? runtime.self ?? null;
    return !!target && (target.flying || hasRaceOrTag(target, 'flying'));
  }
  if (source.includes('it has 5 or more attack')) {
    const target = runtime.target ?? runtime.self ?? null;
    return toNumber(target?.attack, 0) >= 5;
  }
  return true;
}

function addNamedCardToHand(side = 'player', cardName = '', fallback = {}) {
  const wanted = String(cardName || '').trim().toLowerCase();
  if (!wanted) return null;
  const candidates = getAllCards().filter((card) => String(card?.name ?? '').trim().toLowerCase() === wanted);
  const template = randomFrom(candidates) ?? null;
  const card = template
    ? { ...template, instanceId: uid(side === 'player' ? 'card' : 'ec') }
    : {
      id: uid('gen'),
      instanceId: uid(side === 'player' ? 'card' : 'ec'),
      name: cardName,
      type: fallback.type ?? 'spell',
      cost: fallback.cost ?? 1,
      attack: fallback.attack ?? 1,
      health: fallback.health ?? 1,
      rarity: fallback.rarity ?? 'common',
      text: fallback.text ?? '',
      tags: fallback.tags ?? [],
    };
  if (side === 'player') {
    if (state.hand.length >= 10) return null;
    state.hand.push(card);
  } else {
    state.enemyDeck.unshift(card);
  }
  return card;
}

function cardsFromCollectionName(name = '') {
  const wanted = String(name ?? '').trim().toLowerCase();
  if (!wanted) return [];
  const normalizedTag = wanted.replace(/[^a-z0-9]+/g, '-');
  return getAllCards().filter((card) => {
    const collection = String(card?.collectionName ?? '').trim().toLowerCase();
    if (collection && collection === wanted) return true;
    const tags = Array.isArray(card?.tags) ? card.tags.map((tag) => String(tag).toLowerCase()) : [];
    return tags.includes(`collection:${normalizedTag}`) || tags.includes(normalizedTag);
  });
}

function addRandomCardToHandByFilter(side = 'player', filter = () => true) {
  const pool = getAllCards()
    .filter((card) => availabilityForBattleCard(card, side).available)
    .filter((card) => filter(card));
  const pick = randomFrom(pool);
  if (!pick) return null;
  return addNamedCardToHand(side, pick.name, pick);
}

function summonMinionFromTemplate(side = 'player', template = null, origin = null, overrides = {}) {
  if (!template) return null;
  const lane = unitLaneForSide(side);
  const preferredRow = origin?.slot != null ? slotRow(origin.slot) : null;
  const open = firstOpenSlot(lane, preferredRow);
  if (open == null) return null;
  const next = ensureCombatFields({
    ...template,
    ...overrides,
    id: uid(side === 'player' ? 'sm' : 'esm'),
    slot: open,
    row: slotRow(open),
    maxHealth: Math.max(1, toNumber(overrides.maxHealth ?? template.maxHealth ?? template.health, 1)),
    health: Math.max(1, toNumber(overrides.health ?? template.health ?? template.maxHealth, 1)),
    attack: Math.max(0, toNumber(overrides.attack ?? template.attack, 0)),
    summoningSick: !(overrides.charge ?? template.charge ?? false),
    statuses: { ...(template.statuses ?? {}), ...(overrides.statuses ?? {}) },
  });
  lane.push(next);
  seedCardFamiliarity(side, next);
  refreshAllPassiveAuras();
  triggerBattleVfx('summon', { targetId: next.id, vfxSpec: getCardVfxSpec(origin ?? next, 'summon') ?? VFX_DEFAULTS.summon });
  triggerUnitAbilityEvent(next, side, 'on_play', { side, self: next, card: next });
  triggerAbilityEvent(side, 'on_summon_friendly', { side, self: next, summoned: next });
  return next;
}

function applyKeywordGrant(unit = {}, text = '', ownerSide = null) {
  const source = normalizeAbilityText(text).toLowerCase();
  if (!unit) return;
  if (source.includes('taunt')) { unit.taunt = true; unit.baseTaunt = true; }
  if (source.includes('divine shield')) {
    unit.statuses = unit.statuses ?? {};
    unit.statuses.divineShield = true;
    if (source.includes('while at full health')) unit.statuses.divineShieldPersistent = true;
  }
  if (source.includes('stealth')) {
    const wasStealthed = !!(unit.stealth || unit.statuses?.stealth);
    unit.stealth = true;
    unit.statuses = unit.statuses ?? {};
    unit.statuses.stealth = true;
    if (!wasStealthed && ownerSide) {
      triggerUnitAbilityEvent(unit, ownerSide, 'on_stealth_gain_self', { side: ownerSide, self: unit });
      triggerAbilityEvent(ownerSide, 'on_stealth_gain_friendly', { side: ownerSide, self: unit, target: unit });
    }
  }
  if (source.includes('rush')) { unit.charge = true; unit.summoningSick = false; }
  if (source.includes('charge')) { unit.charge = true; unit.summoningSick = false; }
  if (source.includes('lifesteal')) unit.lifesteal = true;
  if (source.includes('flying')) unit.flying = true;
  if (source.includes('poisonous')) unit.poisonousVsDamaged = true;
  if (source.includes('untargetable')) {
    unit.statuses = unit.statuses ?? {};
    unit.statuses.untargetableTurns = Math.max(1, toNumber(unit.statuses.untargetableTurns ?? 0));
  }
  if (source.includes('immune while attacking')) {
    unit.statuses = unit.statuses ?? {};
    unit.statuses.immuneWhileAttacking = true;
  }
}

function summonTokenByText(side = 'player', tokenName = 'Token', atk = 1, hp = 1, count = 1, origin = null, keywordTail = '') {
  const lane = unitLaneForSide(side);
  const template = getAllCards().find((card) => String(card?.name ?? '').toLowerCase() === String(tokenName ?? '').toLowerCase());
  let summoned = 0;
  for (let i = 0; i < count; i += 1) {
    const row = origin?.slot != null ? slotRow(origin.slot) : null;
    const open = firstOpenSlot(lane, row);
    if (open == null) break;
    if (template) {
      const token = summonMinionFromTemplate(side, template, origin, {
        slot: open,
        row: slotRow(open),
        type: template.type ?? 'token',
        attack: Math.max(0, atk ?? toNumber(template.attack, 0)),
        health: Math.max(1, hp ?? toNumber(template.health ?? template.maxHealth, 1)),
        maxHealth: Math.max(1, hp ?? toNumber(template.health ?? template.maxHealth, 1)),
        collectible: false,
        tags: [...new Set([...(Array.isArray(template.tags) ? template.tags : []), 'token'])],
        text: template.text ?? keywordTail,
      });
      if (token) {
        if (keywordTail) applyKeywordGrant(token, keywordTail, side);
        summoned += 1;
      }
      continue;
    }
    const token = ensureCombatFields({
      id: uid(side === 'player' ? 'ptok' : 'etok'),
      name: tokenName,
      type: 'token',
      attack: Math.max(0, atk),
      health: Math.max(1, hp),
      maxHealth: Math.max(1, hp),
      baseDef: 0,
      defense: false,
      defenseDurability: 0,
      taunt: false,
      baseTaunt: false,
      race: 'token',
      element: origin?.element ?? 'arcane',
      statuses: {},
      rarity: 'common',
      summoningSick: true,
      slot: open,
      row: slotRow(open),
      tags: ['token'],
      text: keywordTail,
    });
    if (keywordTail) applyKeywordGrant(token, keywordTail, side);
    lane.push(token);
    triggerBattleVfx('summon', { targetId: token.id, vfxSpec: getCardVfxSpec(origin ?? token, 'summon') ?? VFX_DEFAULTS.summon });
    summoned += 1;
  }
  if (summoned > 0) {
    refreshAllPassiveAuras();
    triggerAbilityEvent(side, 'on_summon_friendly', { amount: summoned, self: origin ?? null });
  }
  return summoned;
}

function allFriendlyEffectSources(side = 'player') {
  return [
    ...unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0),
    ...withSideZone(side, 'field'),
    ...withSideZone(side, 'relic'),
  ];
}

function healingBonusForSide(side = 'player') {
  const flags = getTurnFlags(side);
  const isFirstHeal = Number(flags.healedCharacters ?? 0) === 0;
  let bonus = 0;
  allFriendlyEffectSources(side).forEach((source) => {
    const text = cardText(source).toLowerCase();
    if (!text) return;
    const always = text.match(/your healing effects restore (\d+) extra health/);
    if (always) bonus += Number(always[1] ?? 0);
    const first = text.match(/first healing effect each turn restores (\d+) extra health/);
    if (first && isFirstHeal) bonus += Number(first[1] ?? 0);
  });
  return bonus;
}

function applyHealPassives(side = 'player', target = null, wasFirstHeal = false) {
  if (!target || !wasFirstHeal) return;
  allFriendlyEffectSources(side).forEach((source) => {
    const text = cardText(source).toLowerCase();
    if (!text) return;
    const firstMinionAtk = text.match(/first minion you heal each turn gets \+(\d+) attack/);
    if (firstMinionAtk) {
      target.attack = Math.max(0, toNumber(target.attack, 0) + Number(firstMinionAtk[1] ?? 0));
    }
    const firstHealBuff = text.match(/your first heal each turn also gives \+(\d+)\s*\/\s*\+(\d+)/);
    if (firstHealBuff) {
      const atk = Number(firstHealBuff[1] ?? 0);
      const hp = Number(firstHealBuff[2] ?? 0);
      target.attack = Math.max(0, toNumber(target.attack, 0) + atk);
      target.maxHealth = Math.max(1, toNumber(target.maxHealth ?? target.health, 1) + hp);
      target.health = Math.min(target.maxHealth, toNumber(target.health, 1) + hp);
    } else if (/your first heal each turn also gives \+1\/\+1/.test(text)) {
      target.attack = Math.max(0, toNumber(target.attack, 0) + 1);
      target.maxHealth = Math.max(1, toNumber(target.maxHealth ?? target.health, 1) + 1);
      target.health = Math.min(target.maxHealth, toNumber(target.health, 1) + 1);
    }
  });
}

function healUnitDirect(unit = null, amount = 0, side = 'player', sourceCard = null) {
  if (!unit || amount <= 0) return 0;
  ensureCombatFields(unit);
  const wasFirstHeal = Number(getTurnFlags(side).healedCharacters ?? 0) === 0;
  const bonus = Math.max(0, healingBonusForSide(side));
  const before = unit.health ?? 0;
  const max = unit.maxHealth ?? unit.health ?? 0;
  unit.health = Math.min(max, before + amount + bonus);
  const healed = Math.max(0, unit.health - before);
  if (healed > 0) {
    getTurnFlags(side).healedAmount += healed;
    getTurnFlags(side).healedCharacters += 1;
    applyHealPassives(side, unit, wasFirstHeal);
    triggerBattleVfx('buff', { targetId: unit.id, vfxSpec: { ...VFX_DEFAULTS.buff, color: '#8fffc4', impactType: 'heal-bloom' } });
    triggerUnitAbilityEvent(unit, side, 'on_heal_self', { healed, sourceCard, self: unit });
    triggerAbilityEvent(side, 'on_heal_any', { healed, sourceCard, target: unit, self: unit });
    refreshAllPassiveAuras();
  }
  return healed;
}

function healHeroDirect(side = 'player', amount = 0) {
  const bonus = Math.max(0, healingBonusForSide(side));
  const max = heroMaxHealthForSide(side);
  const before = heroHealthForSide(side);
  const next = Math.min(max, before + Math.max(0, amount + bonus));
  setHeroHealthForSide(side, next);
  const healed = Math.max(0, next - before);
  if (healed > 0) {
    getTurnFlags(side).healedAmount += healed;
    getTurnFlags(side).healedCharacters += 1;
    refreshAllPassiveAuras();
  }
  return healed;
}

function triggerKeyFromAbility(ability = {}) {
  const key = String(ability?.trigger ?? ability?.timing ?? '').toLowerCase();
  const map = {
    onplay: 'on_play',
    onsummon: 'on_play',
    ondeath: 'on_death',
    onattack: 'on_attack_self',
    ondamage: 'on_survive_damage_self',
    startturn: 'on_start_turn',
    endturn: 'on_end_turn',
    onspell: 'on_spell_cast',
    onheal: 'on_heal_any',
    ondraw: 'on_draw',
  };
  return map[key] ?? key;
}

function structuredAbilityEntries(card = {}) {
  const list = [];
  if (Array.isArray(card?.abilities)) {
    card.abilities.forEach((entry) => {
      if (entry && typeof entry === 'object') list.push(entry);
    });
  }
  if (card?.ability && typeof card.ability === 'object' && !Array.isArray(card.ability) && Object.keys(card.ability).length > 0) {
    list.unshift(card.ability);
  }
  if (card?.effect && typeof card.effect === 'object' && !Array.isArray(card.effect) && Object.keys(card.effect).length > 0) {
    list.unshift(card.effect);
  }
  return list;
}

function runtimeEntityForKey(runtime = {}, key = '') {
  const map = {
    playedCard: runtime.playedCard ?? null,
    summoned: runtime.summoned ?? runtime.summonedCard ?? null,
    attacker: runtime.attacker ?? null,
    target: runtime.target ?? null,
    deadUnit: runtime.deadUnit ?? runtime.deadCard ?? null,
    returned: runtime.returned ?? null,
    sourceCard: runtime.sourceCard ?? runtime.card ?? null,
    self: runtime.self ?? runtime.card ?? null,
    healed: runtime.healedTarget ?? runtime.target ?? null,
  };
  if (key && map[key] != null) return map[key];
  return map.playedCard
    ?? map.summoned
    ?? map.attacker
    ?? map.deadUnit
    ?? map.returned
    ?? map.target
    ?? map.sourceCard
    ?? map.self
    ?? null;
}

function structuredAbilityUseBucket(side = 'player') {
  const flags = getTurnFlags(side);
  flags.structuredUses = flags.structuredUses && typeof flags.structuredUses === 'object' ? flags.structuredUses : {};
  return flags.structuredUses;
}

function structuredAbilityKey(ability = {}) {
  return String(ability?.id || ability?.name || ability?.effect?.action || ability?.text || ability?.trigger || 'structured-ability')
    .trim()
    .toLowerCase();
}

function spellMatchesCategory(card = {}, category = '') {
  const source = normalizeAbilityText(cardText(card)).toLowerCase();
  const wanted = String(category ?? '').trim().toLowerCase();
  if (!wanted) return true;
  if (wanted === 'damage') return /deal\s+\d+\s+damage|destroy\s+a?\s*minion|destroy\s+a\s+damaged/.test(source);
  if (wanted === 'heal' || wanted === 'healing') return /restore\s+\d+\s+health|heal\s+\d+|full health/.test(source);
  if (wanted === 'buff') return /\+\d+\/\+\d+|\+\d+\s+attack|\+\d+\s+health/.test(source);
  return source.includes(wanted);
}

function cardIsAtFullHealth(card = null) {
  return !!card && toNumber(card.health, 0) >= toNumber(card.maxHealth ?? card.health, 0);
}

function chooseFriendlyFamilyUnit(side = 'player', family = '', options = {}) {
  const pool = unitLaneForSide(side).filter((unit) => {
    if (!unit || (unit.health ?? 0) <= 0) return false;
    if (options.excludeId && unit.id === options.excludeId) return false;
    if (family && !cardMatchesFamily(unit, family)) return false;
    if (Array.isArray(options.families) && options.families.length && !options.families.some((entry) => cardMatchesFamily(unit, entry))) return false;
    if (options.fullHealthOnly && !cardIsAtFullHealth(unit)) return false;
    if (options.damagedOnly && cardIsAtFullHealth(unit)) return false;
    return true;
  });
  if (!pool.length) return null;
  if (options.lowAttackOnly) {
    const narrowed = pool.filter((unit) => currentAttackValue(unit, side) <= Number(options.lowAttackOnly));
    if (narrowed.length) return randomFrom(narrowed);
  }
  return randomFrom(pool);
}

function chooseEnemyAnyTarget(side = 'player') {
  const foe = enemySide(side);
  return getPriorityEnemyTarget(unitLaneForSide(foe)) ?? { hero: true, side: foe, id: `${foe}-hero` };
}

function chooseLowestHealthEnemy(side = 'player') {
  const foe = enemySide(side);
  return [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0)]
    .sort((a, b) => toNumber(a.health, 0) - toNumber(b.health, 0) || toNumber(a.attack, 0) - toNumber(b.attack, 0))[0] ?? null;
}

function applyStructuredBuff(target = null, side = 'player', effect = {}, options = {}) {
  if (!target) return false;
  const atk = Math.max(0, toNumber(effect.attack ?? effect.atk ?? effect.amountAttack ?? 0, 0));
  const hp = Math.max(0, toNumber(effect.health ?? effect.hp ?? effect.amountHealth ?? 0, 0));
  const tempOnly = !!options.tempOnly || !!effect.tempOnly || !!effect.untilEndOfTurn;
  if (atk > 0) {
    target.attack = Math.max(0, toNumber(target.attack, 0) + atk);
    if (tempOnly) {
      target.statuses = target.statuses ?? {};
      target.statuses.tempAttackBonus = Math.max(0, toNumber(target.statuses.tempAttackBonus ?? 0) + atk);
    }
  }
  if (hp > 0) {
    target.maxHealth = Math.max(1, toNumber(target.maxHealth ?? target.health, 1) + hp);
    target.health = Math.min(target.maxHealth, toNumber(target.health, 1) + hp);
    if (tempOnly) {
      target.statuses = target.statuses ?? {};
      target.statuses.tempHealthBonus = Math.max(0, toNumber(target.statuses.tempHealthBonus ?? 0) + hp);
    }
  }
  const keywords = [
    ...(Array.isArray(effect.keywords) ? effect.keywords : []),
    ...(effect.keyword ? [effect.keyword] : []),
  ];
  keywords.forEach((keyword) => {
    const lowered = String(keyword ?? '').toLowerCase();
    if (tempOnly && lowered === 'taunt') {
      target.statuses = target.statuses ?? {};
      target.statuses.tempTaunt = 1;
      target.taunt = true;
      return;
    }
    if (tempOnly && lowered === 'flying') {
      target.statuses = target.statuses ?? {};
      target.statuses.tempFlying = 1;
      target.flying = true;
      return;
    }
    if (tempOnly && lowered === 'lifesteal') {
      target.statuses = target.statuses ?? {};
      target.statuses.tempLifesteal = 1;
      target.lifesteal = true;
      return;
    }
    if (tempOnly && lowered === 'rush') {
      target.statuses = target.statuses ?? {};
      target.statuses.tempRush = 1;
      target.rush = true;
      target.summoningSick = false;
      return;
    }
    applyKeywordGrant(target, keyword, side);
  });
  if (effect.stealthUntilNextTurn) {
    target.statuses = target.statuses ?? {};
    target.statuses.stealthTurns = Math.max(1, toNumber(target.statuses.stealthTurns ?? 0) + 1);
  }
  if (effect.untargetableUntilNextTurn) {
    target.statuses = target.statuses ?? {};
    target.statuses.untargetableTurns = Math.max(1, toNumber(target.statuses.untargetableTurns ?? 0) + 1);
  }
  if (effect.divineShieldIfFull && cardIsAtFullHealth(target)) applyKeywordGrant(target, 'divine shield', side);
  return true;
}

function chooseFamilyFormOption(side = 'player', effect = {}) {
  const forms = Array.isArray(effect.forms) ? effect.forms : [];
  if (!forms.length) return null;
  if (side === 'player' && state.currentTurn === 'player') {
    const promptLabel = forms.map((form, index) => `${index + 1}. ${form.label ?? `Form ${index + 1}`}`).join('\n');
    const raw = window.prompt(`Choose a form:\n${promptLabel}`, '1');
    const chosenIndex = Math.max(0, Math.min(forms.length - 1, (Number(raw ?? 1) || 1) - 1));
    return forms[chosenIndex] ?? forms[0];
  }
  const friendly = unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0);
  const enemies = unitLaneForSide(enemySide(side)).filter((unit) => (unit?.health ?? 0) > 0);
  const defensive = forms.find((form) => toNumber(form.health ?? 0, 0) > 0 || String(form.keyword ?? '').toLowerCase() === 'taunt' || (Array.isArray(form.keywords) && form.keywords.some((keyword) => String(keyword).toLowerCase() === 'taunt')));
  const aggressive = forms.find((form) => toNumber(form.attack ?? 0, 0) > 0);
  const evasive = forms.find((form) => !!form.stealthUntilNextTurn || String(form.keyword ?? '').toLowerCase() === 'flying' || (Array.isArray(form.keywords) && form.keywords.some((keyword) => String(keyword).toLowerCase() === 'flying')));
  if (heroHealthForSide(side) <= 12 || friendly.length < enemies.length) return defensive ?? aggressive ?? evasive ?? forms[0];
  if ((heroHealthForSide(enemySide(side)) ?? 30) <= 12 || friendly.length >= enemies.length) return aggressive ?? evasive ?? defensive ?? forms[0];
  return evasive ?? aggressive ?? defensive ?? forms[0];
}

function applyFamilyFormChoice(side = 'player', self = null, effect = {}, choice = null) {
  const picked = choice ?? chooseFamilyFormOption(side, effect);
  if (!picked) return false;
  const families = [...new Set([
    ...(Array.isArray(effect.families) ? effect.families : []),
    ...(Array.isArray(picked.families) ? picked.families : []),
    effect.family,
    picked.family,
  ].map((value) => normalizeFamilyToken(value)).filter(Boolean))];
  unitLaneForSide(side).forEach((unit) => {
    if ((unit?.health ?? 0) <= 0) return;
    if (families.length && !families.some((family) => cardMatchesFamily(unit, family))) return;
    applyStructuredBuff(unit, side, {
      attack: toNumber(picked.attack ?? 0, 0),
      health: toNumber(picked.health ?? 0, 0),
      keyword: picked.keyword ?? null,
      keywords: Array.isArray(picked.keywords) ? picked.keywords : [],
      stealthUntilNextTurn: !!picked.stealthUntilNextTurn,
      untilEndOfTurn: true,
    }, { tempOnly: true });
  });
  refreshAllPassiveAuras();
  showHint(`${self?.name ?? 'Form Shift'} chooses ${picked.label ?? 'a form'}.`);
  return true;
}

function structuredAbilityConditionMet(ability = {}, runtime = {}) {
  const side = runtime.side ?? 'player';
  const foe = enemySide(side);
  const self = runtime.self ?? runtime.card ?? null;
  const watch = runtimeEntityForKey(runtime, ability.watch || '');
  const target = runtimeEntityForKey(runtime, ability.targetWatch || 'target') ?? runtime.target ?? null;
  const sourceCard = runtime.sourceCard ?? runtime.playedCard ?? runtime.card ?? null;
  const flags = getTurnFlags(side);
  if (ability.excludeSelf && self && watch?.id === self.id) return false;
  if (ability.sourceFamily && (!watch || !cardMatchesFamily(watch, ability.sourceFamily))) return false;
  if (ability.targetFamily && (!target || !cardMatchesFamily(target, ability.targetFamily))) return false;
  if (ability.controllerFamily && familyCountInZone(side, ability.controllerFamily, ability.controllerZone || 'board') < Math.max(1, toNumber(ability.controllerCount ?? 1, 1))) return false;
  if (ability.deadFamily && countCardsByFamily(cardsInZone(side, 'graveyard'), ability.deadFamily) < Math.max(1, toNumber(ability.deadFamilyCount ?? ability.threshold ?? 1, 1))) return false;
  if (ability.playedCountEq != null && toNumber(flags.cardsPlayed ?? 0, 0) !== toNumber(ability.playedCountEq, 0)) return false;
  if (ability.playedFamilyCountEq != null) {
    const family = ability.sourceFamily || ability.family || '';
    if (!family || familyTurnCount(side, 'playedFamilies', family) !== toNumber(ability.playedFamilyCountEq, 0)) return false;
  }
  if (ability.spellCostMax != null && toNumber(sourceCard?.cost, 99) > toNumber(ability.spellCostMax, 99)) return false;
  if (ability.spellCostMin != null && toNumber(sourceCard?.cost, 0) < toNumber(ability.spellCostMin, 0)) return false;
  if (ability.spellCategory && !spellMatchesCategory(sourceCard, ability.spellCategory)) return false;
  if (ability.fromHand && !(runtime.fromHand || runtime.castMeta?.fromHand || runtime.playedFromHand)) return false;
  if (ability.watchAttackAtMost != null && toNumber(watch?.attack, 999) > toNumber(ability.watchAttackAtMost, 999)) return false;
  if (ability.watchAttackAtLeast != null && toNumber(watch?.attack, 0) < toNumber(ability.watchAttackAtLeast, 0)) return false;
  if (ability.watchCostAtLeast != null && toNumber(watch?.cost, 0) < toNumber(ability.watchCostAtLeast, 0)) return false;
  if (ability.watchStealthed && !(watch?.stealth || watch?.statuses?.stealth)) return false;
  if (ability.watchFullHealth && !cardIsAtFullHealth(watch)) return false;
  if (ability.watchDamaged && cardIsAtFullHealth(watch)) return false;
  if (ability.healedThisTurn && toNumber(flags.healedAmount ?? 0, 0) <= 0) return false;
  if (ability.playedFieldThisTurn && !flags.playedField) return false;
  if (ability.enemyDiedThisTurn && !flags.enemyMinionDied) return false;
  if (ability.targetFullHealth && !cardIsAtFullHealth(target)) return false;
  if (ability.targetDamaged && cardIsAtFullHealth(target)) return false;
  if (ability.friendlyTargetOnly && sideOfUnit(target) !== side) return false;
  if (ability.enemyTargetOnly && sideOfUnit(target) !== foe) return false;
  if (ability.targetStatus && !target?.statuses?.[ability.targetStatus]) return false;
  if (ability.damageSourceSpell && !runtime.deadUnit?.statuses?.lastDamagedBySpell) return false;
  if (ability.damageSourceFamily) {
    const damagedBy = Array.isArray(runtime.deadUnit?.statuses?.lastDamagedByFamilies) ? runtime.deadUnit.statuses.lastDamagedByFamilies : [];
    if (!damagedBy.includes(normalizeFamilyToken(ability.damageSourceFamily))) return false;
  }
  if (ability.condition && !evaluateAbilityCondition(ability.condition, { ...runtime, target, watchedEntity: watch })) return false;
  return true;
}

function executeStructuredAbility(ability = {}, runtime = {}) {
  const side = runtime.side ?? 'player';
  const effect = ability?.effect && typeof ability.effect === 'object' ? ability.effect : ability;
  const scriptedText = normalizeAbilityText(effect.text ?? ability.text ?? '');
  if (!structuredAbilityConditionMet(ability, runtime)) return false;
  if (ability.oncePerTurn) {
    const bucket = structuredAbilityUseBucket(side);
    const key = structuredAbilityKey(ability);
    if (bucket[key]) return true;
    bucket[key] = true;
  }
  const actionId = String(effect.action ?? ability.action ?? '').trim();
  const amount = Math.max(0, toNumber(effect.amount ?? effect.value ?? ability.amount ?? 1, 1));
  const watch = runtimeEntityForKey(runtime, ability.watch || '');
  const target = runtimeEntityForKey(runtime, ability.targetWatch || 'target') ?? runtime.target ?? null;
  const self = runtime.self ?? runtime.card ?? null;
  const sourceCard = runtime.sourceCard ?? runtime.playedCard ?? runtime.card ?? null;
  const customFamilies = Array.isArray(effect.families) ? effect.families.map((entry) => normalizeFamilyToken(entry)).filter(Boolean) : [];
  if (actionId === 'drawCards') {
    if (side === 'player') drawPlayerCards(amount, 'ability');
    else drawEnemyCards(amount, 'ability');
    return true;
  }
  if (actionId === 'summonNamedToken') {
    const tokenName = effect.name ?? 'Token';
    const atk = Math.max(0, toNumber(effect.attack ?? 1, 1));
    const hp = Math.max(1, toNumber(effect.health ?? 1, 1));
    summonTokenByText(side, tokenName, atk, hp, Math.max(1, amount), self ?? runtime.card ?? null, Array.isArray(effect.keywords) ? effect.keywords.join(' ') : String(effect.keywordTail ?? ''));
    return true;
  }
  if (actionId === 'addNamedCardToHand') {
    addNamedCardToHand(side, effect.name ?? 'Generated Card', {
      type: effect.cardType ?? 'spell',
      cost: toNumber(effect.cost ?? 1, 1),
      race: effect.race ?? '',
      races: effect.races ?? (effect.race ? [effect.race] : []),
      text: effect.text ?? '',
      collectible: effect.collectible ?? false,
    });
    return true;
  }
  if (actionId === 'reduceCostInHandByFamily') {
    const family = effect.family ?? ability.family ?? ability.sourceFamily ?? '';
    const hand = side === 'player' ? state.hand : state.enemyDeck;
    const pool = hand.filter((card) => cardMatchesFamily(card, family));
    const chosen = effect.random ? randomFrom(pool) : pool[0];
    if (chosen) chosen.costOffset = Math.max(0, toNumber(chosen.costOffset, 0) + amount);
    return true;
  }
  if (actionId === 'grantReturnedCostReduction') {
    if (runtime.returned) runtime.returned.costOffset = Math.max(0, toNumber(runtime.returned.costOffset, 0) + amount);
    return true;
  }
  if (actionId === 'dealDamageRandomEnemy') return executeAbilityAction(`deal ${amount} damage to a random enemy`, runtime);
  if (actionId === 'dealDamageAnyEnemy') return executeAbilityAction(`deal ${amount} damage.`, runtime);
  if (actionId === 'dealDamageAllOtherMinions') return executeAbilityAction(`damage all other minions for ${amount}`, runtime);
  if (actionId === 'dealDamageFriendlyFamily') {
    const family = effect.family ?? ability.family ?? ability.sourceFamily ?? '';
    const chosen = chooseFriendlyFamilyUnit(side, family, { excludeId: effect.excludeSelf ? self?.id : null });
    if (chosen) applyDamageToUnit(chosen, amount, { attacker: self ?? null, sourceCard, damageType: sourceCard?.element ?? self?.element ?? 'arcane', breakOnHit: true });
    return true;
  }
  if (actionId === 'buffTarget') {
    applyStructuredBuff(target ?? watch ?? self, side, effect, { tempOnly: !!effect.untilEndOfTurn });
    return true;
  }
  if (actionId === 'buffRandomFriendlyFamily') {
    const chosen = chooseFriendlyFamilyUnit(side, effect.family ?? ability.family ?? '', {
      families: customFamilies,
      excludeId: effect.excludeSelf ? self?.id : null,
      fullHealthOnly: !!effect.fullHealthOnly,
      damagedOnly: !!effect.damagedOnly,
      lowAttackOnly: effect.lowAttackAtMost,
    });
    if (chosen) applyStructuredBuff(chosen, side, effect, { tempOnly: !!effect.untilEndOfTurn });
    return true;
  }
  if (actionId === 'buffAllFriendlyFamilyThisTurn') {
    const family = effect.family ?? ability.family ?? '';
    unitLaneForSide(side).forEach((unit) => {
      if ((unit.health ?? 0) <= 0) return;
      if (family && !cardMatchesFamily(unit, family)) return;
      if (customFamilies.length && !customFamilies.some((entry) => cardMatchesFamily(unit, entry))) return;
      applyStructuredBuff(unit, side, effect, { tempOnly: true });
    });
    return true;
  }
  if (actionId === 'chooseFamilyForm') {
    return applyFamilyFormChoice(side, self, effect);
  }
  if (actionId === 'healHero') {
    applyHealToSide(side, amount, runtime);
    return true;
  }
  if (actionId === 'healAllDamagedFriendlyFamily') {
    const family = effect.family ?? ability.family ?? '';
    unitLaneForSide(side).forEach((unit) => {
      if ((unit.health ?? 0) <= 0) return;
      if (family && !cardMatchesFamily(unit, family)) return;
      if ((unit.health ?? 0) >= (unit.maxHealth ?? unit.health ?? 0)) return;
      const beforeFull = cardIsAtFullHealth(unit);
      applyHealingToUnit(unit, amount, { side, sourceCard, self });
      if (!beforeFull && cardIsAtFullHealth(unit) && toNumber(effect.buffAttackOnFullHeal ?? 0, 0) > 0) {
        unit.attack = Math.max(0, toNumber(unit.attack, 0) + toNumber(effect.buffAttackOnFullHeal, 0));
      }
    });
    return true;
  }
  if (actionId === 'freezeLowestHealthEnemyMinion') {
    const victim = chooseLowestHealthEnemy(side);
    if (victim) {
      victim.statuses = victim.statuses ?? {};
      victim.statuses.freezeTurns = Math.max(1, toNumber(victim.statuses.freezeTurns ?? 0) + Math.max(1, amount));
      triggerAbilityEvent(side, 'on_freeze_any', { side, self: victim, target: victim, sourceCard: sourceCard ?? self });
    }
    return true;
  }
  if (actionId === 'copySpellOnRandomFriendlyFamily') {
    if (runtime.castMeta?.copiedByAbility) return true;
    const copied = sourceCard ?? state.lastSpellCastContext?.card ?? null;
    if (!copied || normalizeCardType(copied) !== 'spell') return true;
    const chosen = chooseFriendlyFamilyUnit(side, effect.family ?? ability.family ?? '', { families: customFamilies });
    executeSpellCard({ ...copied }, side, chosen?.id ?? null, { copiedByAbility: true, sourceAbility: self?.name ?? runtime.card?.name ?? 'Ability Copy' });
    return true;
  }
  if (actionId === 'lookAtTopDeck') {
    const preview = openTopDeckPreview(side, {
      count: Math.max(1, toNumber(effect.count ?? 1, 1)),
      allowBottom: !!effect.allowBottom,
      sourceName: self?.name ?? runtime.card?.name ?? 'Deck Sight',
    });
    runtime.peekedTopCard = preview?.cards?.[0] ?? null;
    return true;
  }
  if (actionId === 'returnSelfToHandReduced') {
    if (!self) return true;
    const kept = { ...self, costOffset: Math.max(0, toNumber(self.costOffset, 0) + amount) };
    addNamedCardToHand(side, kept.name, kept);
    return true;
  }
  if (actionId === 'curseTarget') {
    const victim = target ?? watch ?? null;
    if (!victim) return true;
    victim.statuses = victim.statuses ?? {};
    victim.statuses.cursed = true;
    victim.statuses.cursedTurns = Math.max(1, toNumber(victim.statuses.cursedTurns ?? 0) + Math.max(1, toNumber(effect.duration ?? 1, 1)));
    victim.statuses.cursedAttackPenalty = Math.max(0, toNumber(effect.attackPenalty ?? 1, 1));
    return true;
  }
  if (actionId === 'healHeroFromDamage') {
    const dealt = Math.max(0, toNumber(runtime.damageDealt ?? 0, 0));
    const cap = Math.max(0, toNumber(effect.cap ?? amount, amount));
    const healAmount = Math.min(cap, dealt);
    const before = heroHealthForSide(side);
    const max = heroMaxHealthForSide(side);
    applyHealToSide(side, healAmount, runtime);
    if (before + healAmount > max && watch) applyStructuredBuff(watch, side, { attack: toNumber(effect.overhealAttack ?? 1, 1), health: toNumber(effect.overhealHealth ?? 1, 1) });
    return true;
  }
  if (scriptedText) {
    executeAbilityBody(scriptedText, runtime);
    return true;
  }
  const action = normalizeSpellAction(effect.action ?? 'dealDamage');
  if (action === 'dealDamage') return executeAbilityAction(`deal ${amount} damage to an enemy minion`, runtime);
  if (action === 'draw') return executeAbilityAction(`draw ${Math.max(1, amount)} card`, runtime);
  if (action === 'heal') return executeAbilityAction(`restore ${Math.max(1, amount)} health`, runtime);
  if (action === 'buffAttack') return executeAbilityAction(`give this +${Math.max(1, amount)}/+0`, runtime);
  if (action === 'buffHealth') return executeAbilityAction(`give this +0/+${Math.max(1, amount)}`, runtime);
  if (action === 'summon' || action === 'summonToken') {
    const atk = Math.max(1, toNumber(effect.attack ?? 1, 1));
    const hp = Math.max(1, toNumber(effect.health ?? 1, 1));
    return executeAbilityAction(`summon ${Math.max(1, amount)} ${atk}/${hp} ${effect.name ?? 'Token'}`, runtime);
  }
  if (action === 'grantDefense') return executeAbilityAction(`give this +0/+${Math.max(1, toNumber(effect.defAmount ?? amount, amount))} and taunt`, runtime);
  if (action === 'timeLock') return executeAbilityAction('freeze an enemy minion', runtime);
  if (action === 'weakenAllEnemies') return executeAbilityAction(`deal ${Math.max(1, amount)} damage to all enemy minions`, runtime);
  if (action === 'customText' && scriptedText) {
    executeAbilityBody(scriptedText, runtime);
    return true;
  }
  return false;
}

function executeAbilityAction(actionText = '', runtime = {}) {
  const side = runtime.side ?? 'player';
  const foe = enemySide(side);
  const self = runtime.self ?? null;
  const source = normalizeAbilityText(actionText);
  const lower = source.toLowerCase();
  if (!source) return false;

  const stealthStatement = source.match(/^stealth(?:\s+until\s+your\s+next\s+turn)?(?:\s+if\s+(.+))?\.?$/i);
  if (stealthStatement && self) {
    const cond = String(stealthStatement[1] ?? '').trim();
    if (cond && !evaluateAbilityCondition(cond, runtime)) return true;
    applyKeywordGrant(self, 'stealth', side);
    if (/until your next turn/i.test(source)) {
      self.statuses = self.statuses ?? {};
      self.statuses.stealthTurns = Math.max(1, toNumber(self.statuses.stealthTurns ?? 0) + 1);
    }
    return true;
  }

  const summonMatch = source.match(/^summon\s+(an?|one|two|three|four|five|\d+)\s+(\d+)\s*\/\s*(\d+)\s+(.+?)\.?$/i);
  if (summonMatch) {
    const count = numberFromText(summonMatch[1], 1);
    const atk = Number(summonMatch[2]);
    const hp = Number(summonMatch[3]);
    const descriptor = String(summonMatch[4] ?? '').trim();
    const tokenName = descriptor.replace(/\s+with.+$/i, '').trim();
    const keywordTail = descriptor.match(/\s+with\s+(.+)$/i)?.[1] ?? '';
    const summoned = summonTokenByText(side, tokenName, atk, hp, count, self, keywordTail);
    if (summoned > 0) log(`${self?.name ?? runtime.card?.name ?? 'Ability'} summons ${summoned} ${tokenName}.`);
    return true;
  }

  const gainFamiliarityMatch = source.match(/^gain\s+(\d+)\s+([a-z-]+)\s+familiarity/i);
  if (gainFamiliarityMatch) {
    const amount = Number(gainFamiliarityMatch[1] ?? 0);
    addFamiliarity(familiarityPoolForSide(side), gainFamiliarityMatch[2], amount);
    return true;
  }

  const spendFamiliarityMatch = source.match(/^spend\s+(\d+)\s+([a-z-]+)\s+familiarity/i);
  if (spendFamiliarityMatch) {
    const amount = Number(spendFamiliarityMatch[1] ?? 0);
    const family = spendFamiliarityMatch[2];
    if (getFamiliarity(familiarityPoolForSide(side), family) < amount) return true;
    spendFamiliarity(familiarityPoolForSide(side), family, amount);
    return true;
  }

  const perFamilyStats = source.match(/^for\s+every\s+([a-z-]+)\s+(you\s+control|on\s+your\s+board|in\s+your\s+hand|in\s+your\s+deck|in\s+your\s+grave|in\s+your\s+graveyard|in\s+your\s+discard),\s*gain\s+\+(\d+)\s*\/\s*\+(\d+)/i);
  if (perFamilyStats && self) {
    const family = perFamilyStats[1];
    const phrase = String(perFamilyStats[2] ?? '').toLowerCase();
    const zone = phrase.includes('hand')
      ? 'hand'
      : phrase.includes('deck')
        ? 'deck'
        : (phrase.includes('grave') || phrase.includes('discard'))
          ? 'graveyard'
          : 'board';
    const count = familyCountInZone(side, family, zone);
    const atk = Number(perFamilyStats[3] ?? 0) * count;
    const hp = Number(perFamilyStats[4] ?? 0) * count;
    if (atk > 0) self.attack = Math.max(0, toNumber(self.attack, 0) + atk);
    if (hp > 0) {
      self.maxHealth = Math.max(1, toNumber(self.maxHealth ?? self.health, 1) + hp);
      self.health = Math.min(self.maxHealth, toNumber(self.health, 1) + hp);
    }
    return true;
  }

  const perFamilyAttack = source.match(/^for\s+every\s+([a-z-]+)\s+(you\s+control|on\s+your\s+board|in\s+your\s+hand|in\s+your\s+deck|in\s+your\s+grave|in\s+your\s+graveyard|in\s+your\s+discard),\s*gain\s+\+(\d+)\s+attack(?:\s+this\s+turn)?/i);
  if (perFamilyAttack && self) {
    const family = perFamilyAttack[1];
    const phrase = String(perFamilyAttack[2] ?? '').toLowerCase();
    const zone = phrase.includes('hand')
      ? 'hand'
      : phrase.includes('deck')
        ? 'deck'
        : (phrase.includes('grave') || phrase.includes('discard'))
          ? 'graveyard'
          : 'board';
    const count = familyCountInZone(side, family, zone);
    const amount = Number(perFamilyAttack[3] ?? 0) * count;
    if (amount > 0) {
      self.attack = Math.max(0, toNumber(self.attack, 0) + amount);
      if (/this turn/i.test(source)) {
        self.statuses = self.statuses ?? {};
        self.statuses.tempAttackBonus = Math.max(0, toNumber(self.statuses.tempAttackBonus ?? 0) + amount);
      }
    }
    return true;
  }

  const drawFamily = source.match(/^draw\s+a\s+([a-z-]+)\.?$/i);
  if (drawFamily) {
    const family = String(drawFamily[1] ?? '').toLowerCase();
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const idx = deck.findIndex((card) => cardMatchesFamily(card, family) || normalizeCardType(card) === family);
    if (idx >= 0) {
      const [picked] = deck.splice(idx, 1);
      if (side === 'player' && picked && state.hand.length < 10) {
        state.hand.push(picked);
        triggerUnitAbilityEvent(picked, 'player', 'on_drawn_self', { side: 'player', self: picked, drawnCard: picked, source: 'ability' });
        triggerAbilityEvent('player', 'on_draw', { side: 'player', drawnCard: picked, source: 'ability' });
      }
    } else if (side === 'player') {
      drawPlayerCards(1, 'ability');
    }
    return true;
  }

  if (/^draw\s+/i.test(source) || /^draw\s+it$/i.test(source)) {
    if (/once per turn/i.test(lower) && self) {
      self.statuses = self.statuses ?? {};
      if (self.statuses.drawOnceUsed) return true;
      self.statuses.drawOnceUsed = true;
    }
    const count = numberFromText(source, 1);
    if (side === 'player') drawPlayerCards(count, 'spell');
    return true;
  }

  const copyTopIfCosts = source.match(/^copy\s+the\s+top\s+card\s+of\s+your\s+deck\s+if\s+it\s+costs\s+\((\d+)\)/i);
  if (copyTopIfCosts) {
    const cap = Number(copyTopIfCosts[1] ?? 0);
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const top = deck?.[0] ?? null;
    if (top && toNumber(top.cost, 0) <= cap) addNamedCardToHand(side, top.name, { ...top });
    return true;
  }

  if (/^copy\s+the\s+first\s+spell\s+you\s+cast\s+this\s+turn\s+and\s+cast\s+it\s+again\s+on\s+random\s+legal\s+targets/i.test(source)) {
    const firstSpell = getTurnFlags(side).firstSpellCard ?? null;
    if (firstSpell) executeSpellCard({ ...firstSpell }, side, null, { copiedByAbility: true, sourceAbility: self?.name ?? runtime.card?.name ?? 'Ability Copy' });
    return true;
  }

  if (/^cast\s+a\s+copy\s+on\s+a\s+random\s+friendly\s+minion/i.test(source)) {
    if (runtime.castMeta?.copiedByAbility) return true;
    const copied = runtime.sourceCard ?? state.lastSpellCastContext?.card ?? null;
    if (!copied || normalizeCardType(copied) !== 'spell') return true;
    const target = randomFrom(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0));
    executeSpellCard({ ...copied }, side, target?.id ?? null, { copiedByAbility: true, sourceAbility: self?.name ?? runtime.card?.name ?? 'Ability Copy' });
    return true;
  }

  if (/^copy\s+it\s+if\s+it\s+only\s+gives\s+health\s+or\s+armor/i.test(source)) {
    if (runtime.castMeta?.copiedByAbility) return true;
    const copied = runtime.sourceCard ?? state.lastSpellCastContext?.card ?? null;
    if (!copied || normalizeCardType(copied) !== 'spell') return true;
    const text = cardText(copied).toLowerCase();
    const healthOrArmor = /\+0\/\+\d+|\+\d+\s+health|restore\s+\d+\s+health|heal\s+\d+|armor|plate/.test(text);
    const hasDamageOrKill = /deal\s+\d+\s+damage|destroy|discard|return\s+an?\s+enemy|freeze\s+an?\s+enemy/.test(text);
    if (!healthOrArmor || hasDamageOrKill) return true;
    const target = runtime.target && unitLaneForSide(side).some((u) => u.id === runtime.target.id)
      ? runtime.target
      : getPreferredAllyTarget(unitLaneForSide(side), side, true);
    executeSpellCard({ ...copied }, side, target?.id ?? null, { copiedByAbility: true, sourceAbility: self?.name ?? runtime.card?.name ?? 'Ability Copy' });
    return true;
  }

  if (/^give\s+a\s+friendly\s+structure\s+or\s+relic\s+\+(\d+)\s+durability\/health/i.test(source)) {
    const amount = Number(source.match(/\+(\d+)\s+durability\/health/i)?.[1] ?? 0);
    const structures = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && (normalizeCardType(unit) === 'barricade' || cardMatchesFamily(unit, 'structure') || cardMatchesFamily(unit, 'turret') || cardMatchesFamily(unit, 'facility')));
    const relics = withSideZone(side, 'relic').filter((entry) => !!entry);
    const candidates = [...structures, ...relics];
    const target = runtime.target && candidates.some((entry) => entry.id === runtime.target.id)
      ? runtime.target
      : randomFrom(candidates);
    if (target) {
      if (target.durability != null) target.durability = Math.max(0, toNumber(target.durability, 0) + amount);
      if (target.maxHealth != null || target.health != null) {
        target.maxHealth = Math.max(1, toNumber(target.maxHealth ?? target.health, 1) + amount);
        target.health = Math.min(target.maxHealth, toNumber(target.health ?? target.maxHealth, 1) + amount);
      }
    } else if (candidates.length > 0 && side === 'player') {
      drawPlayerCards(1, 'ability');
    }
    return true;
  }

  const damageToAllEnemies = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all\s+enemies/i);
  if (damageToAllEnemies) {
    const amount = Number(damageToAllEnemies[1]);
    unitLaneForSide(foe).forEach((unit) => {
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    const heroHit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
    spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), heroHit.damageTaken, runtime.card?.element ?? 'arcane');
    return true;
  }

  const damageAllEnemyMinions = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all\s+enemy\s+minions/i);
  if (damageAllEnemyMinions) {
    const amount = Number(damageAllEnemyMinions[1]);
    unitLaneForSide(foe).forEach((unit) => {
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  const damageAllMinions = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all(?:\s+other)?\s+minions/i);
  if (damageAllMinions) {
    const amount = Number(damageAllMinions[1]);
    const excludeSelf = /all other minions/i.test(lower) && self;
    [...unitLaneForSide(side), ...unitLaneForSide(foe)].forEach((unit) => {
      if (excludeSelf && self && unit.id === self.id) return;
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  const damageAllOtherMinions = source.match(/^damage\s+all\s+other\s+minions\s+for\s+(\d+)/i);
  if (damageAllOtherMinions) {
    const amount = Number(damageAllOtherMinions[1] ?? 0);
    [...unitLaneForSide(side), ...unitLaneForSide(foe)].forEach((unit) => {
      if (!unit || (unit.health ?? 0) <= 0) return;
      if (self && unit.id === self.id) return;
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  const damageHeroDirect = source.match(/^deal\s+(\d+)\s+damage\s+to\s+the\s+enemy\s+hero(?:\s+if\s+this\s+was\s+damaged)?/i);
  if (damageHeroDirect) {
    const amount = Number(damageHeroDirect[1] ?? 0);
    if (/if\s+this\s+was\s+damaged/i.test(lower)) {
      const selfDamaged = !!self && (self.health ?? 0) < (self.maxHealth ?? self.health ?? 0);
      if (!selfDamaged) return true;
    }
    const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
    spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    return true;
  }

  const damageDamagedEnemy = source.match(/^deal\s+(\d+)\s+damage\s+to\s+a\s+damaged\s+enemy/i);
  if (damageDamagedEnemy) {
    const amount = Number(damageDamagedEnemy[1] ?? 0);
    const target = runtime.target
      ?? getPriorityEnemyTarget(unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0)));
    if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    } else if (heroHealthForSide(foe) < heroMaxHealthForSide(foe)) {
      const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageAdjacentEnemies = source.match(/^deal\s+(\d+)\s+damage\s+to\s+adjacent\s+enemies/i);
  if (damageAdjacentEnemies) {
    const amount = Number(damageAdjacentEnemies[1] ?? 0);
    const primary = runtime.target ?? null;
    if (primary && (primary.slot ?? null) != null) {
      const neighbors = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && Math.abs(toNumber(unit.slot, -99) - toNumber(primary.slot, -99)) === 1);
      neighbors.forEach((unit) => {
        const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
        spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      });
    }
    return true;
  }

  const damageEnemyAshlings = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all\s+enemy\s+ashlings\/tokens/i);
  if (damageEnemyAshlings) {
    const amount = Number(damageEnemyAshlings[1] ?? 0);
    unitLaneForSide(foe).forEach((unit) => {
      if (!unit || (unit.health ?? 0) <= 0) return;
      const isAshling = String(unit.name ?? '').toLowerCase().includes('ashling');
      const isToken = Array.isArray(unit.tags) && unit.tags.map((t) => String(t).toLowerCase()).includes('token');
      if (!isAshling && !isToken) return;
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  const genericDealDamage = source.match(/^deal\s+(\d+)\s+damage\.?$/i);
  if (genericDealDamage) {
    const amount = Number(genericDealDamage[1] ?? 0);
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    } else {
      const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageRandomEnemyMinion = source.match(/^deal\s+(\d+)\s+damage\s+to\s+a\s+random\s+enemy\s+minion/i);
  if (damageRandomEnemyMinion) {
    const amount = Number(damageRandomEnemyMinion[1] ?? 0);
    const target = randomFrom(unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0));
    if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageHighestEnemyMinion = source.match(/^deal\s+(\d+)\s+damage\s+to\s+the\s+highest-health\s+enemy\s+minion/i);
  if (damageHighestEnemyMinion) {
    const amount = Number(damageHighestEnemyMinion[1] ?? 0);
    const target = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0)]
      .sort((a, b) => toNumber(b.health, 0) - toNumber(a.health, 0))[0];
    if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageRandomEnemy = source.match(/^deal\s+(\d+)\s+damage\s+to\s+a\s+random\s+enemy\.?$/i);
  if (damageRandomEnemy) {
    const amount = Number(damageRandomEnemy[1] ?? 0);
    const targets = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0), { hero: true, id: `${foe}-hero` }];
    const target = randomFrom(targets);
    if (target?.hero) {
      const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    } else if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageDamagedOrSweep = source.match(/^deal\s+(\d+)\s+damage\s+to\s+a\s+damaged\s+minion\s+or\s+(\d+)\s+damage\s+to\s+all\s+enemy\s+minions/i);
  if (damageDamagedOrSweep) {
    const big = Number(damageDamagedOrSweep[1] ?? 0);
    const fallback = Number(damageDamagedOrSweep[2] ?? 0);
    const damaged = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0));
    const target = runtime.target && damaged.some((unit) => unit.id === runtime.target.id)
      ? runtime.target
      : getPriorityEnemyTarget(damaged);
    if (target) {
      const hit = applyDamageToUnit(target, big, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    } else {
      unitLaneForSide(foe).forEach((unit) => {
        if ((unit.health ?? 0) <= 0) return;
        const hit = applyDamageToUnit(unit, fallback, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
        spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      });
    }
    return true;
  }

  const damageEnemyMinion = source.match(/^deal\s+(\d+)\s+damage(?:\s+to)?\s+(?:an?\s+)?enemy\s+minion/i)
    || source.match(/^deal\s+(\d+)\s+damage(?:\s+to)?\s+(?:an?\s+)?enemy$/i)
    || source.match(/^deal\s+(\d+)\s+damage$/i);
  if (damageEnemyMinion) {
    const amount = Number(damageEnemyMinion[1]);
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target) {
      const alreadyDamaged = (target.health ?? 0) < (target.maxHealth ?? target.health ?? 0);
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      runtime.lastTargetDied = (target.health ?? 0) <= 0;
      runtime.lastTargetSurvived = (target.health ?? 0) > 0;
      runtime.targetWasDamaged = alreadyDamaged;
    } else {
      const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageEnemyFamily = source.match(/^deal\s+(\d+)\s+damage\s+to\s+an?\s+enemy\s+([a-z-]+)\.?$/i)
    || source.match(/^deal\s+(\d+)\s+damage\s+to\s+an?\s+enemy\s+([a-z-]+)\s+minion\.?$/i);
  if (damageEnemyFamily) {
    const amount = Number(damageEnemyFamily[1] ?? 0);
    const family = String(damageEnemyFamily[2] ?? '').toLowerCase();
    const target = runtime.target && cardMatchesFamily(runtime.target, family)
      ? runtime.target
      : getPriorityEnemyTarget(unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && cardMatchesFamily(unit, family)));
    if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      runtime.lastTargetDied = (target.health ?? 0) <= 0;
      runtime.lastTargetSurvived = (target.health ?? 0) > 0;
    }
    return true;
  }

  const damageInstead = source.match(/^deal\s+(\d+)\s+instead/i);
  if (damageInstead) {
    const amount = Number(damageInstead[1] ?? 0);
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      runtime.lastTargetDied = (target.health ?? 0) <= 0;
      runtime.lastTargetSurvived = (target.health ?? 0) > 0;
    } else {
      const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const damageIt = source.match(/^deal\s+(\d+)\s+damage\s+to\s+it\.?$/i);
  if (damageIt) {
    const amount = Number(damageIt[1] ?? 0);
    const target = runtime.target ?? self ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target?.hero) {
      const hit = applyDamageToCore(target.side ?? foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${(target.side ?? foe) === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    } else if (target) {
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const selfDamageAndGain = source.match(/^deal\s+(\d+)\s+damage\s+to\s+itself\s+and\s+gain\s+\+(\d+)\s+attack/i);
  if (selfDamageAndGain && self) {
    const dmg = Number(selfDamageAndGain[1] ?? 0);
    const atk = Number(selfDamageAndGain[2] ?? 0);
    applyDamageToUnit(self, dmg, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
    self.attack = Math.max(0, toNumber(self.attack, 0) + atk);
    return true;
  }

  const selfDamageAndGainStats = source.match(/^deal\s+(\d+)\s+damage\s+to\s+itself\s+and\s+gain\s+\+(\d+)\s*\/\s*\+(\d+)/i);
  if (selfDamageAndGainStats && self) {
    const dmg = Number(selfDamageAndGainStats[1] ?? 0);
    const atk = Number(selfDamageAndGainStats[2] ?? 0);
    const hp = Number(selfDamageAndGainStats[3] ?? 0);
    applyDamageToUnit(self, dmg, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
    self.attack = Math.max(0, toNumber(self.attack, 0) + atk);
    self.maxHealth = Math.max(1, toNumber(self.maxHealth ?? self.health, 1) + hp);
    self.health = Math.min(self.maxHealth, toNumber(self.health, 1) + hp);
    return true;
  }

  const healFriendlyAll = source.match(/^(?:restore|heal)\s+(\d+)\s+health\s+to\s+all\s+friendly\s+minions/i);
  if (healFriendlyAll) {
    const amount = Number(healFriendlyAll[1]);
    unitLaneForSide(side).forEach((unit) => healUnitDirect(unit, amount, side, runtime.card));
    return true;
  }

  const healHero = source.match(/^(?:restore|heal)\s+(\d+)\s+health\s+to\s+(?:your|friendly)\s+hero/i);
  if (healHero) {
    const amount = Number(healHero[1]);
    healHeroDirect(side, amount);
    return true;
  }

  const healIt = source.match(/^(?:restore|heal)\s+(\d+)\s+health\s+to\s+it/i);
  if (healIt) {
    const amount = Number(healIt[1] ?? 0);
    const target = runtime.target ?? self ?? getPreferredAllyTarget(unitLaneForSide(side), side, true);
    if (target) {
      healUnitDirect(target, amount, side, runtime.card ?? self);
      runtime.lastHealTargetFullyHealed = (target.health ?? 0) >= (target.maxHealth ?? target.health ?? 0);
    }
    return true;
  }

  const healSplitFriendlies = source.match(/^(?:restore|heal)\s+(\d+)\s+health\s+split\s+among\s+friendly\s+characters/i);
  if (healSplitFriendlies) {
    let amount = Number(healSplitFriendlies[1] ?? 0);
    const friendlies = [
      ...unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0),
      { hero: true, side },
    ];
    while (amount > 0 && friendlies.length) {
      const target = randomFrom(friendlies);
      if (!target) break;
      if (target.hero) healHeroDirect(side, 1);
      else healUnitDirect(target, 1, side, runtime.card ?? self);
      amount -= 1;
    }
    return true;
  }

  const healFriendly = source.match(/^(?:restore|heal)\s+(\d+)\s+health/i);
  if (healFriendly) {
    const amount = Number(healFriendly[1]);
    const target = runtime.target && unitLaneForSide(side).some((u) => u.id === runtime.target.id)
      ? runtime.target
      : getPreferredAllyTarget(unitLaneForSide(side), side, true);
    if (target) {
      healUnitDirect(target, amount, side, runtime.card);
      runtime.lastHealTargetFullyHealed = (target.health ?? 0) >= (target.maxHealth ?? target.health ?? 0);
    } else {
      healHeroDirect(side, amount);
      runtime.lastHealTargetFullyHealed = heroHealthForSide(side) >= heroMaxHealthForSide(side);
    }
    return true;
  }

  const healFriendlyFamily = source.match(/^(?:restore|heal)\s+(\d+)\s+health\s+to\s+all\s+friendly\s+([a-z-]+)s?/i);
  if (healFriendlyFamily) {
    const amount = Number(healFriendlyFamily[1] ?? 0);
    const family = String(healFriendlyFamily[2] ?? '').toLowerCase();
    unitLaneForSide(side)
      .filter((unit) => (unit.health ?? 0) > 0 && cardMatchesFamily(unit, family))
      .forEach((unit) => healUnitDirect(unit, amount, side, runtime.card ?? self));
    return true;
  }

  if (/^if it survives,\s*gain stealth\.?$/i.test(source) && self) {
    if (runtime.lastTargetSurvived || ((self.health ?? 0) > 0)) {
      applyKeywordGrant(self, 'stealth', side);
      self.statuses = self.statuses ?? {};
      self.statuses.stealthTurns = Math.max(1, toNumber(self.statuses.stealthTurns ?? 0) + 1);
    }
    return true;
  }

  if (/^if it dies,\s*draw a card\.?$/i.test(source)) {
    if (runtime.lastTargetDied && side === 'player') drawPlayerCards(1, 'ability');
    return true;
  }

  const giveKeyword = source.match(/^give\s+(this|a\s+friendly\s+minion|all\s+friendly\s+minions|a\s+minion)\s+(.+)/i);
  if (giveKeyword) {
    const scope = String(giveKeyword[1] ?? '').toLowerCase();
    const tail = String(giveKeyword[2] ?? '').toLowerCase();
    if (tail.includes('divine shield') || tail.includes('stealth') || tail.includes('rush') || tail.includes('lifesteal') || tail.includes('taunt')) {
      let targets = [];
      if (scope.includes('all')) targets = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0);
      else if (scope.includes('this') && self) targets = [self];
      else {
        const pick = runtime.target && unitLaneForSide(side).some((u) => u.id === runtime.target.id)
          ? runtime.target
          : getPreferredAllyTarget(unitLaneForSide(side), side, false);
        targets = pick ? [pick] : [];
      }
      targets.forEach((unit) => applyKeywordGrant(unit, tail, side));
      return true;
    }
  }

  const giveBuff = source.match(/^give\s+(?:a|an|all|your|friendly|another|this)?\s*(.*?)\s*\+(\d+)\s*\/\s*\+(\d+)(.*)$/i);
  if (giveBuff) {
    const scope = String(giveBuff[1] || '').trim().toLowerCase();
    const atk = Number(giveBuff[2] ?? 0);
    const hp = Number(giveBuff[3] ?? 0);
    const tail = String(giveBuff[4] ?? '');
    let targets = [];
    if (scope.includes('all') || lower.includes('all friendly minions')) targets = unitLaneForSide(side);
    else if (/your\s+([a-z-]+)s?/i.test(scope)) {
      const family = scope.match(/your\s+([a-z-]+)s?/i)?.[1] ?? '';
      targets = unitLaneForSide(side).filter((unit) => hasRaceOrTag(unit, family));
    }
    else if (scope === 'it' && runtime.peekedTopCard) {
      const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
      if (deck.length > 0) {
        deck[0].attack = Math.max(0, toNumber(deck[0].attack, 0) + atk);
        deck[0].health = Math.max(1, toNumber(deck[0].health ?? deck[0].maxHealth, 1) + hp);
        deck[0].maxHealth = Math.max(deck[0].health, toNumber(deck[0].maxHealth ?? deck[0].health, deck[0].health));
      }
      return true;
    }
    else if (scope.includes('this') && self) targets = [self];
    else if (scope.includes('another') && self) {
      targets = unitLaneForSide(side).filter((unit) => unit.id !== self.id);
      const chosen = getPreferredAllyTarget(targets, side, false);
      targets = chosen ? [chosen] : [];
    } else {
      const chosen = getPreferredAllyTarget(unitLaneForSide(side), side, false);
      targets = chosen ? [chosen] : [];
    }
    targets.forEach((unit) => {
      unit.attack = Math.max(0, toNumber(unit.attack, 0) + atk);
      unit.maxHealth = Math.max(1, toNumber(unit.maxHealth ?? unit.health, 1) + hp);
      unit.health = Math.min(unit.maxHealth, toNumber(unit.health, 1) + hp);
      applyKeywordGrant(unit, tail, side);
      triggerBattleVfx('buff', { targetId: unit.id, vfxSpec: { ...VFX_DEFAULTS.buff, color: '#ffd37a', impactType: 'buff-pulse' } });
    });
    return true;
  }

  const reducePeekedCost = source.match(/^reduce\s+its\s+cost\s+by\s+\((\d+)\)/i);
  if (reducePeekedCost) {
    const amount = Number(reducePeekedCost[1] ?? 0);
    const targetCard = runtime.drawnCard
      ?? runtime.peekedTopCard
      ?? runtime.targetCard
      ?? null;
    if (targetCard) {
      targetCard.costOffset = Math.max(0, toNumber(targetCard.costOffset, 0) + amount);
      return true;
    }
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    if (deck.length > 0) {
      deck[0].costOffset = Math.max(0, toNumber(deck[0].costOffset, 0) + amount);
      return true;
    }
    return true;
  }

  const addToHand = source.match(/^add\s+(?:a|an)\s+(.+?)\s+to\s+your\s+hand/i);
  if (addToHand) {
    const named = addToHand[1].replace(/^random\s+/i, '').replace(/\s+cards?$/i, '').trim();
    if (/^random\s+/i.test(addToHand[1])) {
      let pool = getAllCards().filter((card) => availabilityForBattleCard(card, side).available);
      const coll = addToHand[1].match(/random\s+(.+?)\s+card/i);
      if (coll) {
        const wanted = String(coll[1] ?? '').trim().toLowerCase();
        const filtered = pool.filter((card) => String(card.collectionName ?? '').toLowerCase().includes(wanted));
        if (filtered.length) pool = filtered;
      }
      const pick = randomFrom(pool);
      if (pick) addNamedCardToHand(side, pick.name, pick);
    } else {
      addNamedCardToHand(side, named, { type: 'spell', cost: 1 });
    }
    return true;
  }

  const destroyDamaged = source.match(/^destroy\s+a\s+damaged\s+minion/i);
  if (destroyDamaged) {
    const pool = [...damagedMinions(side), ...damagedMinions(foe)];
    const target = runtime.target ?? randomFrom(pool);
    if (target) target.health = 0;
    return true;
  }

  const destroyDamagedFamily = source.match(/^destroy\s+a\s+damaged\s+([a-z-]+)\.?$/i)
    || source.match(/^destroy\s+a\s+damaged\s+([a-z-]+)\s+minion\.?$/i);
  if (destroyDamagedFamily) {
    const family = String(destroyDamagedFamily[1] ?? '').toLowerCase();
    const pool = [...damagedMinions(side), ...damagedMinions(foe)].filter((unit) => cardMatchesFamily(unit, family));
    const target = runtime.target && cardMatchesFamily(runtime.target, family) ? runtime.target : randomFrom(pool);
    if (target) target.health = 0;
    return true;
  }

  const destroyEnemyFamily = source.match(/^destroy\s+an?\s+enemy\s+([a-z-]+)\.?$/i)
    || source.match(/^destroy\s+an?\s+enemy\s+([a-z-]+)\s+minion\.?$/i);
  if (destroyEnemyFamily) {
    const family = String(destroyEnemyFamily[1] ?? '').toLowerCase();
    const pool = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && cardMatchesFamily(unit, family));
    const target = runtime.target && cardMatchesFamily(runtime.target, family) ? runtime.target : getPriorityEnemyTarget(pool);
    if (target) target.health = 0;
    return true;
  }

  const destroyFriendlyDraw = source.match(/^destroy\s+a\s+friendly\s+(.+?)\s+to\s+draw\s+a\s+card/i)
    || source.match(/^destroy\s+a\s+friendly\s+minion\s+to\s+draw\s+a\s+card/i);
  if (destroyFriendlyDraw) {
    let pool = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0);
    const family = String(destroyFriendlyDraw[1] ?? '').trim().toLowerCase();
    if (family && !family.includes('minion')) {
      pool = pool.filter((unit) => hasRaceOrTag(unit, family) || String(unit.name ?? '').toLowerCase().includes(family));
    }
    const target = runtime.target ?? getPreferredAllyTarget(pool, side, false);
    if (target) {
      runtime.lastDestroyedFriendly = target;
      runtime.lastDestroyedFriendlyStats = {
        attack: Math.max(0, toNumber(target.attack, 0)),
        health: Math.max(0, toNumber(target.health ?? target.maxHealth, 0)),
        cost: Math.max(0, toNumber(target.cost, 0)),
        tags: Array.isArray(target.tags) ? [...target.tags] : [],
      };
      target.health = 0;
      if (side === 'player') drawPlayerCards(1, 'ability');
    }
    return true;
  }

  const destroyFriendly = source.match(/^destroy\s+a\s+friendly\s+minion/i);
  if (destroyFriendly) {
    const target = runtime.target ?? getPreferredAllyTarget(unitLaneForSide(side), side, false);
    if (target) {
      runtime.lastDestroyedFriendly = target;
      runtime.lastDestroyedFriendlyStats = {
        attack: Math.max(0, toNumber(target.attack, 0)),
        health: Math.max(0, toNumber(target.health ?? target.maxHealth, 0)),
        cost: Math.max(0, toNumber(target.cost, 0)),
        tags: Array.isArray(target.tags) ? [...target.tags] : [],
      };
      target.health = 0;
    }
    return true;
  }

  if (/^devour\s+a\s+friendly\s+minion\.?$/i.test(source)) {
    const target = runtime.target ?? getPreferredAllyTarget(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && (!self || unit.id !== self.id)), side, false);
    if (target) {
      runtime.lastDestroyedFriendly = target;
      runtime.lastDestroyedFriendlyStats = {
        attack: Math.max(0, toNumber(target.attack, 0)),
        health: Math.max(0, toNumber(target.health ?? target.maxHealth, 0)),
        cost: Math.max(0, toNumber(target.cost, 0)),
        tags: Array.isArray(target.tags) ? [...target.tags] : [],
      };
      target.health = 0;
    }
    return true;
  }

  if (/^destroy\s+it\.?$/i.test(source)) {
    const target = runtime.target ?? self ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target?.hero) {
      const sideTarget = target.side ?? foe;
      setHeroHealthForSide(sideTarget, 0);
    } else if (target) {
      target.health = 0;
    }
    return true;
  }

  const returnFriendly = source.match(/^return\s+a\s+friendly\s+minion\s+to\s+your\s+hand/i);
  if (returnFriendly) {
    const target = runtime.target ?? getPreferredAllyTarget(unitLaneForSide(side), side, false);
    if (target) {
      target.health = 0;
      addNamedCardToHand(side, target.name, target);
    }
    return true;
  }

  const freezeEnemy = source.match(/^freeze\s+(?:an?\s+)?enemy\s+minion/i)
    || source.match(/^freeze\s+two\s+enemy\s+minions/i)
    || source.match(/^freeze\s+a\s+damaged\s+enemy/i);
  if (freezeEnemy) {
    const count = lower.includes('two enemy') ? 2 : 1;
    const damagedOnly = lower.includes('damaged enemy');
    const pool = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && (!damagedOnly || (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0)));
    const targets = pool.slice(0, count);
    targets.forEach((unit) => {
      unit.statuses = unit.statuses ?? {};
      unit.statuses.freezeTurns = Math.max(1, toNumber(unit.statuses.freezeTurns ?? 0) + 1);
      triggerBattleVfx('debuff', { targetId: unit.id, vfxSpec: { ...VFX_DEFAULTS.debuff, color: '#7ec6ff', impactType: 'status-freeze' } });
      triggerAbilityEvent(side, 'on_freeze_any', { side, self: unit, target: unit, sourceCard: runtime.card ?? self });
    });
    return true;
  }

  if (/^freeze\s+the\s+attacker\s+or\s+a\s+random\s+enemy\s+minion\.?$/i.test(source)) {
    let target = runtime.attacker ?? null;
    if (!target || (target.health ?? 0) <= 0) {
      target = randomFrom(unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0));
    }
    if (target) {
      target.statuses = target.statuses ?? {};
      target.statuses.freezeTurns = Math.max(1, toNumber(target.statuses.freezeTurns ?? 0) + 1);
      triggerBattleVfx('debuff', { targetId: target.id, vfxSpec: { ...VFX_DEFAULTS.debuff, color: '#7ec6ff', impactType: 'status-freeze' } });
      triggerAbilityEvent(side, 'on_freeze_any', { side, self: target, target, sourceCard: runtime.card ?? self });
    }
    return true;
  }

  const silenceEnemy = source.match(/^silence\s+all\s+enemy\s+minions/i) || source.match(/^silence\s+a\s+minion/i);
  if (silenceEnemy) {
    const targets = silenceEnemy[0].toLowerCase().includes('all')
      ? unitLaneForSide(foe)
      : [runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe))].filter(Boolean);
    targets.forEach((unit) => {
      unit.statuses = unit.statuses ?? {};
      unit.statuses.silenced = true;
      unit.statuses.weakened = false;
      unit.statuses.weakenedTurns = 0;
      unit.statuses.freezeTurns = 0;
      unit.statuses.sleepTurns = 0;
    });
    return true;
  }

  const markEnemy = source.match(/^mark\s+(?:an?\s+)?enemy(?:\s+minion)?/i) || source.match(/^mark\s+the\s+defender/i);
  if (markEnemy) {
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target) {
      target.statuses = target.statuses ?? {};
      target.statuses.marked = true;
      target.statuses.markedTurns = Math.max(1, toNumber(target.statuses.markedTurns ?? 0) + 2);
    }
    return true;
  }

  const nextAttackMarked = source.match(/^your\s+next\s+attack\s+against\s+it\s+deals\s+\+(\d+)\s+damage/i);
  if (nextAttackMarked) {
    const target = runtime.target ?? getPriorityEnemyTarget(unitLaneForSide(foe));
    if (target) {
      target.statuses = target.statuses ?? {};
      target.statuses.marked = true;
      target.statuses.markedBonusDamage = Math.max(0, toNumber(target.statuses.markedBonusDamage ?? 0) + Number(nextAttackMarked[1] ?? 0));
      target.statuses.markedTurns = Math.max(1, toNumber(target.statuses.markedTurns ?? 0) + 2);
    }
    return true;
  }

  const reduceCost = source.match(/reduce\s+the\s+cost\s+of\s+(?:a\s+)?random\s+(.+?)\s+in\s+your\s+hand\s+by\s+\((\d+)\)/i);
  if (reduceCost) {
    const family = reduceCost[1].trim().toLowerCase();
    const amount = Number(reduceCost[2] ?? 1);
    const hand = side === 'player' ? state.hand : [];
    const filtered = hand.filter((card) => hasRaceOrTag(card, family) || String(card?.type ?? '').toLowerCase().includes(family));
    const chosen = randomFrom(filtered);
    if (chosen) chosen.costOffset = Math.max(0, toNumber(chosen.costOffset, 0) + amount);
    return true;
  }

  const reduceCostDirect = source.match(/reduce\s+the\s+cost\s+of\s+a\s+(.+?)\s+in\s+your\s+hand\s+by\s+\((\d+)\)/i);
  if (reduceCostDirect) {
    const family = reduceCostDirect[1].trim().toLowerCase();
    const amount = Number(reduceCostDirect[2] ?? 1);
    const hand = side === 'player' ? state.hand : [];
    const card = randomFrom(hand.filter((entry) => cardMatchesFamily(entry, family)));
    if (card) card.costOffset = Math.max(0, toNumber(card.costOffset, 0) + amount);
    return true;
  }

  const lookTop = source.match(/look\s+at\s+the\s+top\s+card\s+of\s+your\s+deck/i) || source.match(/reveal\s+the\s+top\s+card\s+of\s+your\s+deck/i);
  if (lookTop) {
    const preview = openTopDeckPreview(side, {
      count: 1,
      allowBottom: /put it on the bottom/i.test(lower),
      sourceName: runtime.card?.name ?? self?.name ?? 'Ability',
    });
    runtime.peekedTopCard = preview?.cards?.[0] ?? null;
    return true;
  }

  const gainHealth = source.match(/^gain\s+\+?(\d+)\s+health/i);
  if (gainHealth && self) {
    const amount = Number(gainHealth[1] ?? 0);
    self.maxHealth = Math.max(1, toNumber(self.maxHealth ?? self.health, 1) + amount);
    self.health = Math.min(self.maxHealth, toNumber(self.health, 1) + amount);
    return true;
  }

  const gainAttack = source.match(/^gain\s+\+?(\d+)\s+attack(?:\s+this\s+turn)?/i)
    || source.match(/^this\s+gains\s+\+?(\d+)\s+attack(?:\s+this\s+turn)?/i);
  if (gainAttack && self) {
    const amount = Number(gainAttack[1] ?? 0);
    self.attack = Math.max(0, toNumber(self.attack, 0) + amount);
    self.statuses = self.statuses ?? {};
    if (/this turn/i.test(source)) {
      self.statuses.tempAttackBonus = Math.max(0, toNumber(self.statuses.tempAttackBonus ?? 0) + amount);
    }
    return true;
  }

  const gainStats = source.match(/^gain\s+\+?(\d+)\s*\/\s*\+?(\d+)/i);
  if (gainStats && self) {
    const atk = Number(gainStats[1] ?? 0);
    const hp = Number(gainStats[2] ?? 0);
    self.attack = Math.max(0, toNumber(self.attack, 0) + atk);
    self.maxHealth = Math.max(1, toNumber(self.maxHealth ?? self.health, 1) + hp);
    self.health = Math.min(self.maxHealth, toNumber(self.health, 1) + hp);
    return true;
  }

  const gainKeywords = source.match(/^gain\s+(.+)/i);
  if (gainKeywords && self) {
    const tail = String(gainKeywords[1] ?? '').toLowerCase();
    if (tail.includes('stealth') || tail.includes('rush') || tail.includes('lifesteal') || tail.includes('taunt') || tail.includes('divine shield')) {
      const cond = tail.match(/if\s+(.+)$/i);
      if (cond && !evaluateAbilityCondition(cond[1], runtime)) return true;
      applyKeywordGrant(self, tail, side);
      if (tail.includes('this turn')) {
        self.statuses = self.statuses ?? {};
        if (tail.includes('stealth')) self.statuses.stealthTurns = Math.max(1, toNumber(self.statuses.stealthTurns ?? 0) + 1);
      }
      return true;
    }
  }

  const gainSpellDamage = source.match(/^gain\s+spell\s+damage\s*\+?(\d+)\s+this\s+turn/i);
  if (gainSpellDamage) {
    const amount = Number(gainSpellDamage[1] ?? 0);
    getTurnFlags(side).spellDamageBonus = Math.max(0, toNumber(getTurnFlags(side).spellDamageBonus ?? 0) + amount);
    return true;
  }

  if (/^your\s+hero\s+gains\s+immune\s+this\s+turn\.?$/i.test(source)) {
    getTurnFlags(side).heroImmune = true;
    return true;
  }

  const gainItsStats = source.match(/^gain\s+its\s+attack\s+and\s+health/i) || source.match(/^gain\s+its\s+stats\s+and\s+keywords/i);
  if (gainItsStats) {
    if (self && runtime.lastDestroyedFriendlyStats) {
      const buff = runtime.lastDestroyedFriendlyStats;
      const atk = Math.max(0, toNumber(buff.attack, 0));
      const hp = Math.max(0, toNumber(buff.health, 0));
      self.attack = Math.max(0, toNumber(self.attack, 0) + atk);
      self.maxHealth = Math.max(1, toNumber(self.maxHealth ?? self.health, 1) + hp);
      self.health = Math.min(self.maxHealth, toNumber(self.health, 1) + hp);
      if (/keywords/i.test(source)) {
        (buff.tags ?? []).forEach((tag) => applyKeywordGrant(self, String(tag), side));
      }
    }
    return true;
  }

  if (/^restore\s+its\s+health\s+to\s+all\s+your\s+beasts/i.test(source) && runtime.lastDestroyedFriendlyStats) {
    const amount = Math.max(0, toNumber(runtime.lastDestroyedFriendlyStats.health, 0));
    unitLaneForSide(side)
      .filter((unit) => (unit.health ?? 0) > 0 && hasRaceOrTag(unit, 'beast'))
      .forEach((unit) => healUnitDirect(unit, amount, side, runtime.card ?? self));
    return true;
  }

  const giveAttackOnly = source.match(/^give\s+(?:a|an|all|your|friendly|another|this|them)?\s*(.*?)\s*\+(\d+)\s+attack(?:\s+this\s+turn)?/i);
  if (giveAttackOnly) {
    const scope = String(giveAttackOnly[1] ?? '').trim().toLowerCase();
    const amount = Number(giveAttackOnly[2] ?? 0);
    const temporary = /this turn/i.test(source);
    let targets = [];
    if ((scope.includes('all') || scope.includes('your minions') || scope.includes('friendly minions')) && runtime.lastSummonedUnits?.length) {
      targets = runtime.lastSummonedUnits;
    } else if (scope.includes('all') || scope.includes('your minions') || scope.includes('friendly minions')) {
      targets = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0);
    } else if (/your\s+([a-z-]+)s?/i.test(scope)) {
      const family = scope.match(/your\s+([a-z-]+)s?/i)?.[1] ?? '';
      targets = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && hasRaceOrTag(unit, family));
    } else if (scope.includes('random')) {
      const pick = randomFrom(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0));
      targets = pick ? [pick] : [];
    } else if (scope.includes('this') && self) {
      targets = [self];
    } else {
      const pick = getPreferredAllyTarget(unitLaneForSide(side), side, false);
      targets = pick ? [pick] : [];
    }
    targets.forEach((unit) => {
      unit.attack = Math.max(0, toNumber(unit.attack, 0) + amount);
      if (temporary) {
        unit.statuses = unit.statuses ?? {};
        unit.statuses.tempAttackBonus = Math.max(0, toNumber(unit.statuses.tempAttackBonus ?? 0) + amount);
      }
    });
    return true;
  }

  const giveHealthOnly = source.match(/^give\s+(?:a|an|all|your|friendly|another|this|them)?\s*(.*?)\s*\+(\d+)\s+health/i);
  if (giveHealthOnly) {
    const scope = String(giveHealthOnly[1] ?? '').trim().toLowerCase();
    const amount = Number(giveHealthOnly[2] ?? 0);
    let targets = [];
    if (scope.includes('all') || scope.includes('friendly minions')) targets = unitLaneForSide(side);
    else if (/your\s+([a-z-]+)s?/i.test(scope)) {
      const family = scope.match(/your\s+([a-z-]+)s?/i)?.[1] ?? '';
      targets = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && hasRaceOrTag(unit, family));
    }
    else if (scope.includes('this') && self) targets = [self];
    else if (scope.includes('random')) {
      const pick = randomFrom(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0));
      targets = pick ? [pick] : [];
    } else {
      const pick = getPreferredAllyTarget(unitLaneForSide(side), side, false);
      targets = pick ? [pick] : [];
    }
    targets.forEach((unit) => {
      unit.maxHealth = Math.max(1, toNumber(unit.maxHealth ?? unit.health, 1) + amount);
      unit.health = Math.min(unit.maxHealth, toNumber(unit.health, 1) + amount);
    });
    return true;
  }

  if (/^give\s+a\s+friendly\s+minion\s+"whenever\s+this\s+survives\s+damage,\s+gain\s+\+?(\d+)\s+health\.?"/i.test(source)) {
    const amount = Number(source.match(/\+?(\d+)\s+health/i)?.[1] ?? 1);
    const target = runtime.target ?? getPreferredAllyTarget(unitLaneForSide(side), side, false);
    if (target) {
      target.statuses = target.statuses ?? {};
      target.statuses.surviveDamageGainHealth = Math.max(0, toNumber(target.statuses.surviveDamageGainHealth ?? 0) + amount);
    }
    return true;
  }

  if (/^give\s+(?:all\s+)?friendly\s+minions\s+stealth\s+until\s+your\s+next\s+turn/i.test(source)) {
    unitLaneForSide(side).forEach((unit) => {
      if ((unit.health ?? 0) <= 0) return;
      applyKeywordGrant(unit, 'stealth', side);
      unit.statuses = unit.statuses ?? {};
      unit.statuses.stealthTurns = Math.max(1, toNumber(unit.statuses.stealthTurns ?? 0) + 1);
    });
    return true;
  }

  if (/^give\s+a\s+random\s+friendly\s+2-attack-or-less\s+minion\s+stealth\.?$/i.test(source)) {
    const pick = randomFrom(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && toNumber(unit.attack, 0) <= 2));
    if (pick) {
      applyKeywordGrant(pick, 'stealth', side);
      pick.statuses = pick.statuses ?? {};
      pick.statuses.stealthTurns = Math.max(1, toNumber(pick.statuses.stealthTurns ?? 0) + 1);
    }
    return true;
  }

  if (/^give\s+another\s+friendly\s+minion\s+stealth\s+until\s+your\s+next\s+turn\.?$/i.test(source)) {
    const pool = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && (!self || unit.id !== self.id));
    const pick = runtime.target && pool.some((unit) => unit.id === runtime.target.id)
      ? runtime.target
      : getPreferredAllyTarget(pool, side, false);
    if (pick) {
      applyKeywordGrant(pick, 'stealth', side);
      pick.statuses = pick.statuses ?? {};
      pick.statuses.stealthTurns = Math.max(1, toNumber(pick.statuses.stealthTurns ?? 0) + 1);
    }
    return true;
  }

  if (/^give\s+a\s+random\s+friendly\s+minion\s+stealth\s+until\s+your\s+next\s+turn/i.test(source)) {
    const pick = randomFrom(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0));
    if (pick) {
      applyKeywordGrant(pick, 'stealth', side);
      pick.statuses = pick.statuses ?? {};
      pick.statuses.stealthTurns = Math.max(1, toNumber(pick.statuses.stealthTurns ?? 0) + 1);
    }
    return true;
  }

  if (/^gain\s+divine shield/i.test(source) && self) {
    applyKeywordGrant(self, 'divine shield', side);
    return true;
  }

  const dealToMinion = source.match(/^deal\s+(\d+)\s+damage\s+to\s+(?:a|an|the)\s+minion/i);
  if (dealToMinion) {
    const amount = Number(dealToMinion[1] ?? 0);
    const target = runtime.target
      ?? getPriorityEnemyTarget(unitLaneForSide(foe))
      ?? getPriorityEnemyTarget(unitLaneForSide(side));
    if (target) {
      const owner = sideOfUnit(target) ?? foe;
      const hit = applyDamageToUnit(target, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      runtime.lastTargetDied = (target.health ?? 0) <= 0;
      runtime.lastTargetSurvived = (target.health ?? 0) > 0;
      runtime.targetWasDamaged = owner ? damagedMinions(owner).some((u) => u.id === target.id) : false;
    }
    return true;
  }

  const dealDamagedEnemies = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all\s+damaged\s+enemy\s+minions/i);
  if (dealDamagedEnemies) {
    const amount = Number(dealDamagedEnemies[1] ?? 0);
    unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0)).forEach((unit) => {
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  const dealAllDamagedEnemies = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all\s+damaged\s+enemies/i);
  if (dealAllDamagedEnemies) {
    const amount = Number(dealAllDamagedEnemies[1] ?? 0);
    unitLaneForSide(foe)
      .filter((unit) => (unit.health ?? 0) > 0 && (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0))
      .forEach((unit) => {
        const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
        spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      });
    if (heroHealthForSide(foe) < heroMaxHealthForSide(foe)) {
      const hit = applyDamageToCore(foe, amount, { damageType: runtime.card?.element ?? 'arcane' });
      spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    }
    return true;
  }

  const dealSplit = source.match(/^deal\s+(\d+)\s+damage\s+split\s+randomly\s+among\s+enemies/i);
  if (dealSplit) {
    let amount = Number(dealSplit[1] ?? 0);
    const enemyTargets = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0), { id: `${foe}-hero`, hero: true }];
    while (amount > 0 && enemyTargets.length) {
      const target = randomFrom(enemyTargets);
      if (!target) break;
      if (target.hero) {
        const hit = applyDamageToCore(foe, 1, { damageType: runtime.card?.element ?? 'arcane' });
        spawnDamageNumber(document.querySelector(`[data-target-id="${foe === 'player' ? 'player-hero' : 'enemy-hero'}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      } else {
        const hit = applyDamageToUnit(target, 1, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
        spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
      }
      amount -= 1;
    }
    return true;
  }

  const dealLowestEachSide = source.match(/^deal\s+(\d+)\s+damage\s+to\s+the\s+lowest-health\s+minion\s+on\s+each\s+side/i);
  if (dealLowestEachSide) {
    const amount = Number(dealLowestEachSide[1] ?? 0);
    const own = [...unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0)].sort((a, b) => toNumber(a.health, 0) - toNumber(b.health, 0))[0];
    const opp = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0)].sort((a, b) => toNumber(a.health, 0) - toNumber(b.health, 0))[0];
    [own, opp].filter(Boolean).forEach((unit) => {
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  const dealHighestEachSide = source.match(/^deal\s+(\d+)\s+damage\s+to\s+the\s+highest-health\s+minion\s+on\s+each\s+side/i);
  if (dealHighestEachSide) {
    const amount = Number(dealHighestEachSide[1] ?? 0);
    const own = [...unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0)].sort((a, b) => toNumber(b.health, 0) - toNumber(a.health, 0))[0];
    const opp = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0)].sort((a, b) => toNumber(b.health, 0) - toNumber(a.health, 0))[0];
    [own, opp].filter(Boolean).forEach((unit) => {
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  if (/^deal\s+damage\s+to\s+enemies\s+equal\s+to\s+the\s+amount\s+you\s+restored\s+this\s+turn,\s*split\s+randomly/i.test(source)) {
    const total = Math.max(0, Number(getTurnFlags(side).healedAmount ?? 0));
    return executeAbilityAction(`deal ${total} damage split randomly among enemies`, runtime);
  }

  const dealNonBeast = source.match(/^deal\s+(\d+)\s+damage\s+to\s+all\s+non-beast\s+minions/i);
  if (dealNonBeast) {
    const amount = Number(dealNonBeast[1] ?? 0);
    [...unitLaneForSide(side), ...unitLaneForSide(foe)].forEach((unit) => {
      if (hasRaceOrTag(unit, 'beast')) return;
      const hit = applyDamageToUnit(unit, amount, { damageType: runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${unit.id}"]`), hit.damageTaken, runtime.card?.element ?? 'arcane');
    });
    return true;
  }

  if (/^return\s+(?:another\s+)?friendly\s+minion\s+to\s+your\s+hand/i.test(source) || /^return\s+a\s+friendly\s+1-cost\s+minion\s+to\s+your\s+hand/i.test(source)) {
    let pool = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0);
    if (/another/i.test(source) && self) pool = pool.filter((unit) => unit.id !== self.id);
    if (/1-cost/i.test(source)) pool = pool.filter((unit) => toNumber(unit.cost, 0) <= 1);
    const target = runtime.target ?? getPreferredAllyTarget(pool, side, false);
    if (target) {
      const kept = { ...target };
      target.health = 0;
      const added = addNamedCardToHand(side, target.name, kept);
      if (/costs\s+\((\d+)\)\s+less/i.test(source) && added) {
        const amount = Number(source.match(/costs\s+\((\d+)\)\s+less/i)?.[1] ?? 0);
        added.costOffset = Math.max(0, toNumber(added.costOffset, 0) + amount);
      }
      if (/with\s*-(\d+)\s*\/\s*-(\d+)/i.test(source) && added) {
        const m = source.match(/with\s*-(\d+)\s*\/\s*-(\d+)/i);
        added.attack = Math.max(0, toNumber(added.attack, 0) - Number(m?.[1] ?? 0));
        added.health = Math.max(1, toNumber(added.health, 1) - Number(m?.[2] ?? 0));
      }
      triggerAbilityEvent(side, 'on_return_friendly', { side, self: target, returned: target, sourceCard: runtime.card ?? self });
    }
    return true;
  }

  const returnThis = source.match(/^return\s+this\s+to\s+your\s+hand(?:\s+with\s*-(\d+)\s*\/\s*-(\d+))?/i);
  if (returnThis && self) {
    const kept = { ...self };
    self.health = 0;
    const added = addNamedCardToHand(side, kept.name, kept);
    if (added && returnThis[1] && returnThis[2]) {
      added.attack = Math.max(0, toNumber(added.attack, 0) - Number(returnThis[1] ?? 0));
      added.health = Math.max(1, toNumber(added.health, 1) - Number(returnThis[2] ?? 0));
    }
    return true;
  }

  if (/^return\s+it\s+to\s+your\s+hand\s+at\s+end\s+of\s+turn\.?$/i.test(source) && self) {
    self.statuses = self.statuses ?? {};
    self.statuses.returnToHandEndTurn = true;
    return true;
  }

  const returnEnemy = source.match(/^return\s+an?\s+enemy(?:\s+(\d+)-cost-or-less)?\s+minion\s+to\s+its\s+owner'?s\s+hand/i);
  if (returnEnemy) {
    const cap = Number(returnEnemy[1] ?? 99);
    let pool = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0);
    if (cap < 99) pool = pool.filter((unit) => toNumber(unit.cost, 0) <= cap);
    const target = runtime.target ?? getPriorityEnemyTarget(pool);
    if (target) {
      const kept = { ...target };
      target.health = 0;
      addNamedCardToHand(foe, target.name, kept);
    }
    return true;
  }

  const lookTopN = source.match(/look\s+at\s+the\s+top\s+(\d+)\s+cards?\s+of\s+your\s+deck/i);
  if (lookTopN) {
    const count = Number(lookTopN[1] ?? 1);
    const preview = openTopDeckPreview(side, {
      count,
      allowBottom: /put (?:it|them) on the bottom/i.test(lower),
      sourceName: runtime.card?.name ?? self?.name ?? 'Deck Preview',
    });
    runtime.peekedTopCard = preview?.cards?.[0] ?? null;
    runtime.peekedTopCards = preview?.cards ?? [];
    return true;
  }

  const shuffleNamed = source.match(/^shuffle\s+(one|two|three|four|five|\d+)\s+(.+?)\s+cards?\s+into\s+your\s+deck/i);
  if (shuffleNamed) {
    const count = numberFromText(shuffleNamed[1], 1);
    const named = String(shuffleNamed[2] ?? '').replace(/\s+cards?$/i, '').trim();
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    for (let i = 0; i < count; i += 1) {
      const added = addNamedCardToHand(side, named, { type: 'spell', cost: 1 });
      if (!added) continue;
      if (side === 'player') {
        const idx = state.hand.findIndex((card) => card.instanceId === added.instanceId);
        if (idx >= 0) state.hand.splice(idx, 1);
      }
      deck.splice(Math.floor(Math.random() * (deck.length + 1)), 0, added);
    }
    return true;
  }

  if (/^discover\s+a\s+spell/i.test(source)) {
    addRandomCardToHandByFilter(side, (card) => normalizeCardType(card) === 'spell');
    return true;
  }
  if (/^discover\s+a\s+1-cost/i.test(source)) {
    addRandomCardToHandByFilter(side, (card) => toNumber(card.cost, 0) <= 1 && (runtime.card?.collectionName ? String(card.collectionName ?? '') === String(runtime.card.collectionName) : true));
    return true;
  }
  if (/^discover\s+a\s+beast/i.test(source)) {
    const cap = extractCostNumber(source, 99);
    addRandomCardToHandByFilter(side, (card) => hasRaceOrTag(card, 'beast') && toNumber(card.cost, 0) <= cap);
    return true;
  }
  if (/^discover\s+a\s+quake,\s*armor,\s*or\s*construct\s+card/i.test(source)) {
    addRandomCardToHandByFilter(side, (card) => {
      const text = normalizeAbilityText(card?.text ?? '').toLowerCase();
      return hasRaceOrTag(card, 'construct') || text.includes('armor') || text.includes('plate') || text.includes('quake') || text.includes('seismic');
    });
    return true;
  }

  const summonRandomFamilyDeck = source.match(/^summon\s+a\s+random\s+([a-z-]+)\s+from\s+your\s+deck\s+that\s+costs\s+\((\d+)\)\s+or\s+less/i)
    || source.match(/^summon\s+a\s+random\s+([a-z-]+)\s+from\s+your\s+deck/i);
  if (summonRandomFamilyDeck) {
    const family = String(summonRandomFamilyDeck[1] ?? 'beast').toLowerCase();
    const cap = Number(summonRandomFamilyDeck[2] ?? 99);
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const candidates = deck.filter((card) => normalizeCardType(card) === 'minion' && hasRaceOrTag(card, family) && toNumber(card.cost, 0) <= cap);
    const pick = randomFrom(candidates);
    if (pick) {
      const idx = deck.findIndex((card) => card.instanceId === pick.instanceId);
      if (idx >= 0) deck.splice(idx, 1);
      const summoned = summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
      if (summoned && /give it stealth until your next turn/i.test(source)) {
        applyKeywordGrant(summoned, 'stealth', side);
        summoned.statuses.stealthTurns = Math.max(1, toNumber(summoned.statuses.stealthTurns ?? 0) + 1);
      }
    }
    return true;
  }

  const summonCostMore = source.match(/^summon\s+one\s+that\s+costs\s+\((\d+)\)\s+more\s+from\s+your\s+deck/i);
  if (summonCostMore) {
    const delta = Number(summonCostMore[1] ?? 1);
    const baseCost = Math.max(0, toNumber(runtime.lastDestroyedFriendlyStats?.cost, 0));
    const wanted = baseCost + delta;
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const candidates = deck.filter((card) => normalizeCardType(card) === 'minion' && toNumber(card.cost, 0) === wanted);
    const pick = randomFrom(candidates);
    if (pick) {
      const idx = deck.findIndex((card) => card.instanceId === pick.instanceId);
      if (idx >= 0) deck.splice(idx, 1);
      summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
    }
    return true;
  }

  const transformToCostMore = source.match(/^transform\s+a\s+friendly\s+([a-z-]+)\s+into\s+one\s+that\s+costs\s+\((\d+)\)\s+more/i);
  if (transformToCostMore) {
    const family = String(transformToCostMore[1] ?? '').toLowerCase();
    const delta = Number(transformToCostMore[2] ?? 0);
    const target = runtime.target ?? randomFrom(unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && cardMatchesFamily(unit, family)));
    if (!target) return true;
    const keptDamage = Math.max(0, toNumber(target.maxHealth ?? target.health, 1) - toNumber(target.health, 1));
    const wanted = Math.max(0, toNumber(target.cost, 0) + delta);
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const candidates = deck.filter((card) => normalizeCardType(card) === 'minion' && toNumber(card.cost, 0) === wanted);
    const pick = randomFrom(candidates);
    target.health = 0;
    if (pick) {
      const idx = deck.findIndex((card) => card.instanceId === pick.instanceId);
      if (idx >= 0) deck.splice(idx, 1);
      const summoned = summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
      if (summoned && /keeps damage taken/i.test(lower)) {
        summoned.health = Math.max(1, toNumber(summoned.health, 1) - keptDamage);
      }
    }
    return true;
  }

  const summonRandomFromHand = source.match(/^summon\s+a\s+random\s+beast\s+from\s+your\s+hand\s+that\s+costs\s+\((\d+)\)\s+or\s+less/i)
    || source.match(/^summon\s+a\s+random\s+([a-z-]+)\s+from\s+your\s+hand\s+that\s+costs\s+\((\d+)\)\s+or\s+less/i);
  if (summonRandomFromHand) {
    const family = summonRandomFromHand.length > 2 && summonRandomFromHand[2] ? summonRandomFromHand[1] : 'beast';
    const cap = Number((summonRandomFromHand.length > 2 && summonRandomFromHand[2]) ? summonRandomFromHand[2] : summonRandomFromHand[1] ?? 99);
    const hand = side === 'player' ? state.hand : [];
    const candidates = hand.filter((card) => normalizeCardType(card) === 'minion' && cardMatchesFamily(card, family) && toNumber(card.cost, 0) <= cap);
    const pick = randomFrom(candidates);
    if (pick) {
      const idx = hand.findIndex((card) => card.instanceId === pick.instanceId);
      if (idx >= 0) hand.splice(idx, 1);
      summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
    }
    return true;
  }

  const handBeastGainsDiscount = source.match(/^a\s+beast\s+in\s+your\s+hand\s+gains\s+"costs\s+\((\d+)\)\s+less\s+if\s+you\s+control\s+this\.?"/i);
  if (handBeastGainsDiscount) {
    const amount = Number(handBeastGainsDiscount[1] ?? 0);
    const hand = side === 'player' ? state.hand : [];
    const beast = randomFrom(hand.filter((card) => cardMatchesFamily(card, 'beast')));
    if (beast) beast.costOffset = Math.max(0, toNumber(beast.costOffset, 0) + amount);
    return true;
  }

  if (/^resummon\s+a\s+random\s+friendly\s+minion\s+that\s+died\s+this\s+game\s+with\s+1\s+health/i.test(source)) {
    const grave = withSideZone(side, 'graveyard').filter((card) => normalizeCardType(card) === 'minion');
    const pick = randomFrom(grave);
    if (pick) summonMinionFromTemplate(side, pick, self ?? runtime.card, { health: 1, maxHealth: Math.max(1, toNumber(pick.maxHealth ?? pick.health, pick.health ?? 1)) });
    return true;
  }

  if (/^restore\s+all\s+damaged\s+friendly\s+minions\s+to\s+full\s+health/i.test(source)) {
    unitLaneForSide(side).forEach((unit) => {
      if ((unit.health ?? 0) <= 0) return;
      const max = Math.max(1, toNumber(unit.maxHealth ?? unit.health, 1));
      const healed = Math.max(0, max - toNumber(unit.health, 0));
      if (healed > 0) healUnitDirect(unit, healed, side, runtime.card ?? self);
    });
    return true;
  }

  if (/^consume\s+all\s+your\s+ashlings/i.test(source)) {
    const lane = unitLaneForSide(side);
    const consumed = lane.filter((unit) => (unit.health ?? 0) > 0 && String(unit.name ?? '').toLowerCase().includes('ashling'));
    consumed.forEach((unit) => { unit.health = 0; });
    runtime.lastConsumedCount = consumed.length;
    return true;
  }

  if (/^fill\s+your\s+board\s+with\s+1\/1\s+skeleton\s+deckhands\s+and\s+1\/1\s+fishlings/i.test(source)) {
    const lane = unitLaneForSide(side);
    const added = [];
    while (lane.length < MAX_SLOTS) {
      const name = (added.length % 2 === 0) ? 'Skeleton Deckhand' : 'Fishling';
      const token = summonTokenByText(side, name, 1, 1, 1, self);
      if (!token) break;
      const latest = unitLaneForSide(side)[unitLaneForSide(side).length - 1];
      if (latest) added.push(latest);
      if (lane.length >= MAX_SLOTS) break;
    }
    runtime.lastSummonedUnits = added;
    return true;
  }

  if (/^give\s+them\s+\+(\d+)\s*\/\s*\+(\d+)/i.test(source)) {
    const m = source.match(/^give\s+them\s+\+(\d+)\s*\/\s*\+(\d+)/i);
    const atk = Number(m?.[1] ?? 0);
    const hp = Number(m?.[2] ?? 0);
    (runtime.lastSummonedUnits ?? []).forEach((unit) => {
      unit.attack = Math.max(0, toNumber(unit.attack, 0) + atk);
      unit.maxHealth = Math.max(1, toNumber(unit.maxHealth ?? unit.health, 1) + hp);
      unit.health = Math.min(unit.maxHealth, toNumber(unit.health, 1) + hp);
    });
    return true;
  }

  if (/^if you control a damaged beast,\s*attack an enemy minion/i.test(source) && self) {
    const hasDamagedBeast = unitLaneForSide(side).some((unit) => hasRaceOrTag(unit, 'beast') && (unit.health ?? 0) > 0 && (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0));
    if (hasDamagedBeast) {
      const target = getPriorityEnemyTarget(unitLaneForSide(foe));
      if (target) {
        const atk = currentAttackValue(self, side, target);
        const hit = applyDamageToUnit(target, atk, { attacker: self, damageType: self.element ?? 'arcane', breakOnHit: true });
        spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, self.element ?? 'arcane');
      }
    }
    return true;
  }

  if (/^attack\s+a\s+random\s+enemy\s+minion\.?$/i.test(source) && self) {
    const target = randomFrom(unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0));
    if (target) {
      const atk = currentAttackValue(self, side, target);
      const hit = applyDamageToUnit(target, atk, { attacker: self, damageType: self.element ?? runtime.card?.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, self.element ?? runtime.card?.element ?? 'arcane');
      triggerAbilityEvent(side, 'on_attack_any', { side, self, attacker: self, target, sourceCard: runtime.card ?? self });
    }
    return true;
  }

  if (/^pull\s+a\s+1-attack\s+enemy\s+minion\s+into\s+combat\s+with\s+this\.?$/i.test(source) && self) {
    const target = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0 && toNumber(unit.attack, 0) <= 1)]
      .sort((a, b) => toNumber(a.health, 0) - toNumber(b.health, 0))[0];
    if (target) {
      const atk = currentAttackValue(self, side, target);
      const ret = currentAttackValue(target, foe, self);
      const hitTarget = applyDamageToUnit(target, atk, { attacker: self, damageType: self.element ?? 'arcane', breakOnHit: true });
      const hitSelf = applyDamageToUnit(self, ret, { attacker: target, damageType: target.element ?? 'shadow', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hitTarget.damageTaken, self.element ?? 'arcane');
      spawnDamageNumber(document.querySelector(`[data-id="${self.id}"]`), hitSelf.damageTaken, target.element ?? 'shadow');
      runtime.lastTargetDied = (target.health ?? 0) <= 0;
      runtime.lastTargetSurvived = (target.health ?? 0) > 0;
    }
    return true;
  }

  if (/^pull the weakest enemy into combat with this/i.test(source) && self) {
    const target = [...unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0)]
      .sort((a, b) => toNumber(a.health, 0) - toNumber(b.health, 0))[0];
    if (target) {
      const atk = currentAttackValue(self, side, target);
      const ret = currentAttackValue(target, foe, self);
      const hitTarget = applyDamageToUnit(target, atk, { attacker: self, damageType: self.element ?? 'arcane', breakOnHit: true });
      const hitSelf = applyDamageToUnit(self, ret, { attacker: target, damageType: target.element ?? 'shadow', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hitTarget.damageTaken, self.element ?? 'arcane');
      spawnDamageNumber(document.querySelector(`[data-id="${self.id}"]`), hitSelf.damageTaken, target.element ?? 'shadow');
    }
    return true;
  }

  if (/^attack again\.?$/i.test(source) && self) {
    const pool = unitLaneForSide(foe).filter((unit) => (unit.health ?? 0) > 0);
    const target = randomFrom(pool);
    if (!target) return true;
    const hit = applyDamageToUnit(target, currentAttackValue(self, side, target), { attacker: self, damageType: self.element ?? runtime.card?.element ?? 'arcane', breakOnHit: true });
    spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, self.element ?? runtime.card?.element ?? 'arcane');
    return true;
  }

  if (/^equip your whole board with \+0\/\+(\d+) and deal (\d+) damage split among enemies/i.test(source)) {
    const m = source.match(/^equip your whole board with \+0\/\+(\d+) and deal (\d+) damage split among enemies/i);
    const hp = Number(m?.[1] ?? 0);
    const dmg = Number(m?.[2] ?? 0);
    unitLaneForSide(side).forEach((unit) => {
      unit.maxHealth = Math.max(1, toNumber(unit.maxHealth ?? unit.health, 1) + hp);
      unit.health = Math.min(unit.maxHealth, toNumber(unit.health, 1) + hp);
    });
    executeAbilityAction(`deal ${dmg} damage split randomly among enemies`, runtime);
    return true;
  }

  if (/^summon\s+a\s+random\s+construct\s+from\s+your\s+hand\s+or\s+deck\s+that\s+costs\s+\((\d+)\)\s+or\s+less\s+and\s+give\s+it\s+\+0\/\+(\d+)/i.test(source)) {
    const m = source.match(/^summon\s+a\s+random\s+construct\s+from\s+your\s+hand\s+or\s+deck\s+that\s+costs\s+\((\d+)\)\s+or\s+less\s+and\s+give\s+it\s+\+0\/\+(\d+)/i);
    const cap = Number(m?.[1] ?? 0);
    const hp = Number(m?.[2] ?? 0);
    const hand = side === 'player' ? state.hand : [];
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const handCandidates = hand.filter((card) => normalizeCardType(card) === 'minion' && hasRaceOrTag(card, 'construct') && toNumber(card.cost, 0) <= cap);
    const deckCandidates = deck.filter((card) => normalizeCardType(card) === 'minion' && hasRaceOrTag(card, 'construct') && toNumber(card.cost, 0) <= cap);
    let sourceZone = null;
    let pick = randomFrom(handCandidates);
    if (pick) sourceZone = 'hand';
    if (!pick) {
      pick = randomFrom(deckCandidates);
      if (pick) sourceZone = 'deck';
    }
    if (pick) {
      if (sourceZone === 'hand') {
        const idx = hand.findIndex((card) => card.instanceId === pick.instanceId);
        if (idx >= 0) hand.splice(idx, 1);
      } else if (sourceZone === 'deck') {
        const idx = deck.findIndex((card) => card.instanceId === pick.instanceId);
        if (idx >= 0) deck.splice(idx, 1);
      }
      const summoned = summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
      if (summoned) {
        summoned.maxHealth = Math.max(1, toNumber(summoned.maxHealth ?? summoned.health, 1) + hp);
        summoned.health = Math.min(summoned.maxHealth, toNumber(summoned.health, 1) + hp);
      }
    }
    return true;
  }

  if (/^all\s+friendly\s+beasts\s+attack\s+random\s+damaged\s+enemies/i.test(source)) {
    const beasts = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && hasRaceOrTag(unit, 'beast'));
    beasts.forEach((unit) => {
      const pool = unitLaneForSide(foe).filter((enemy) => (enemy.health ?? 0) > 0 && (enemy.health ?? 0) < (enemy.maxHealth ?? enemy.health ?? 0));
      const target = randomFrom(pool);
      if (!target) return;
      const hit = applyDamageToUnit(target, currentAttackValue(unit, side, target), { attacker: unit, damageType: unit.element ?? 'arcane', breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, unit.element ?? 'arcane');
    });
    return true;
  }

  if (/^all\s+your\s+minions\s+attack\s+random\s+marked\s+enemies/i.test(source)) {
    const attackers = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0);
    attackers.forEach((unit) => {
      const pool = unitLaneForSide(foe).filter((enemy) => (enemy.health ?? 0) > 0 && !!enemy.statuses?.marked);
      const target = randomFrom(pool);
      if (!target) return;
      const hit = applyDamageToUnit(target, currentAttackValue(unit, side, target), { attacker: unit, damageType: unit.element ?? 'arcane', breakOnHit: true });
      consumeMarkedAttackBonus(target);
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, unit.element ?? 'arcane');
    });
    return true;
  }

  const castRandomCostSpell = source.match(/^cast\s+a\s+random\s+(\d+)-cost\s+spell\s+from\s+this\s+collection/i);
  if (castRandomCostSpell) {
    const cost = Number(castRandomCostSpell[1] ?? 0);
    const collection = String(runtime.card?.collectionName ?? self?.collectionName ?? '').trim();
    let pool = collection ? cardsFromCollectionName(collection) : getAllCards();
    pool = pool.filter((card) => normalizeCardType(card) === 'spell' && toNumber(card.cost, 0) === cost);
    const pick = randomFrom(pool);
    if (pick) {
      if (!getTurnFlags(side).firstSpellCard) getTurnFlags(side).firstSpellCard = { ...pick };
      executeSpellCard({ ...pick }, side, null);
    }
    return true;
  }

  if (/^cast\s+it\s+again\s+on\s+random\s+legal\s+targets/i.test(source)) {
    const firstSpell = getTurnFlags(side).firstSpellCard ?? null;
    if (firstSpell) executeSpellCard({ ...firstSpell }, side, null);
    return true;
  }

  const enemySpellsTax = source.match(/enemy\s+spells\s+cost\s+\((\d+)\)\s+more\s+next\s+turn/i);
  if (enemySpellsTax) {
    const amount = Number(enemySpellsTax[1] ?? 0);
    if (side === 'player') state.enemyTurnTax = Math.max(0, toNumber(state.enemyTurnTax, 0) + amount);
    else state.playerTurnTax = Math.max(0, toNumber(state.playerTurnTax, 0) + amount);
    return true;
  }

  if (/^gain\s+(\d+)\s+armor\.?$/i.test(source)) {
    const amount = Number(source.match(/^gain\s+(\d+)\s+armor\.?$/i)?.[1] ?? 0);
    if (side === 'player') state.playerCoreDef = Math.max(0, toNumber(state.playerCoreDef, 0) + amount);
    else state.enemyCoreDef = Math.max(0, toNumber(state.enemyCoreDef, 0) + amount);
    return true;
  }

  if (/^your\s+lowest-attack\s+beast\s+eats\s+your\s+highest-attack\s+damaged\s+beast\s+and\s+gains\s+its\s+stats\.?$/i.test(source)) {
    const beasts = unitLaneForSide(side).filter((unit) => (unit.health ?? 0) > 0 && hasRaceOrTag(unit, 'beast'));
    const eater = [...beasts].sort((a, b) => toNumber(a.attack, 0) - toNumber(b.attack, 0))[0];
    const prey = [...beasts]
      .filter((unit) => unit.id !== eater?.id && (unit.health ?? 0) < (unit.maxHealth ?? unit.health ?? 0))
      .sort((a, b) => toNumber(b.attack, 0) - toNumber(a.attack, 0))[0];
    if (eater && prey) {
      eater.attack = Math.max(0, toNumber(eater.attack, 0) + Math.max(0, toNumber(prey.attack, 0)));
      eater.maxHealth = Math.max(1, toNumber(eater.maxHealth ?? eater.health, 1) + Math.max(0, toNumber(prey.health ?? prey.maxHealth, 0)));
      eater.health = Math.min(eater.maxHealth, toNumber(eater.health, 1) + Math.max(0, toNumber(prey.health ?? prey.maxHealth, 0)));
      prey.health = 0;
    }
    return true;
  }

  if (/^summon\s+two\s+skeleton\s+deckhands\.?$/i.test(source)) {
    summonTokenByText(side, 'Skeleton Deckhand', 1, 1, 2, self);
    return true;
  }

  if (/^summon\s+a\s+random\s+skeleton\s+and\s+a\s+random\s+beast\s+that\s+costs\s+\((\d+)\)\s+or\s+less\.?$/i.test(source)) {
    const cap = Number(source.match(/\((\d+)\)\s+or\s+less/i)?.[1] ?? 0);
    const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
    const skeletons = deck.filter((card) => normalizeCardType(card) === 'minion' && cardMatchesFamily(card, 'skeleton'));
    const beasts = deck.filter((card) => normalizeCardType(card) === 'minion' && cardMatchesFamily(card, 'beast') && toNumber(card.cost, 0) <= cap);
    const picks = [randomFrom(skeletons), randomFrom(beasts)].filter(Boolean);
    picks.forEach((pick) => {
      const idx = deck.findIndex((card) => card.instanceId === pick.instanceId);
      if (idx >= 0) deck.splice(idx, 1);
      summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
    });
    return true;
  }

  if (/^summon\s+a\s+random\s+2-cost\s+follower\s+and\s+give\s+it\s+divine\s+shield\.?$/i.test(source)) {
    const pool = getAllCards().filter((card) => normalizeCardType(card) === 'minion' && toNumber(card.cost, 0) === 2);
    const pick = randomFrom(pool);
    if (pick) {
      const summoned = summonMinionFromTemplate(side, pick, self ?? runtime.card, {});
      if (summoned) applyKeywordGrant(summoned, 'divine shield', side);
    }
    return true;
  }

  if (/^store\s+it\s+here\.?$/i.test(source) && self) {
    const healed = Math.max(0, toNumber(runtime.healed ?? runtime.amount ?? 0, 0));
    self.statuses = self.statuses ?? {};
    self.statuses.storedHealing = Math.max(0, toNumber(self.statuses.storedHealing ?? 0) + healed);
    if (toNumber(self.statuses.storedHealing, 0) >= 12) {
      summonTokenByText(side, 'Avatar of Embrace', 7, 7, 1, self);
      const latest = unitLaneForSide(side)[unitLaneForSide(side).length - 1];
      if (latest && String(latest.name ?? '').toLowerCase().includes('avatar of embrace')) {
        applyKeywordGrant(latest, 'divine shield', side);
        applyKeywordGrant(latest, 'taunt', side);
      }
      self.statuses.storedHealing = Math.max(0, toNumber(self.statuses.storedHealing, 0) - 12);
    }
    return true;
  }

  if (/counter(?:\s+or\s+cancel)?\s+the\s+next\s+enemy\s+spell/i.test(source)) {
    if (side === 'player') state.enemySpellCounter = Math.max(0, toNumber(state.enemySpellCounter, 0) + 1);
    else state.playerSpellCounter = Math.max(0, toNumber(state.playerSpellCounter, 0) + 1);
    return true;
  }

  state.unhandledAbilityActions[source] = Math.max(0, Number(state.unhandledAbilityActions[source] ?? 0)) + 1;
  if (state.unhandledAbilityActions[source] === 1) {
    pushDevActionTrace(`Unhandled ability action phrase: ${source}`, 'warn');
  }
  return false;
}

function executeAbilityBody(bodyText = '', runtime = {}) {
  if (!bodyText) return;
  const ifCond = extractIfCondition(bodyText);
  let body = bodyText;
  if (ifCond) {
    if (!evaluateAbilityCondition(ifCond.condition, runtime)) return;
    body = ifCond.thenText;
  }
  splitActions(body).forEach((action) => {
    executeAbilityAction(action, runtime);
  });
}

function triggerUnitAbilityEvent(unit = null, side = 'player', eventKey = '', context = {}) {
  if (!unit) return;
  structuredAbilityEntries(unit).forEach((scripted) => {
    const scriptedTrigger = triggerKeyFromAbility(scripted);
    if (triggerMatchesEvent(scriptedTrigger, eventKey) || (!scriptedTrigger && eventKey === 'on_play')) {
      executeStructuredAbility(scripted, {
        ...context,
        side,
        eventKey,
        card: unit,
        self: unit,
      });
    }
  });
  const clauses = getAbilityClauses(unit);
  if (!clauses.length) return;
  clauses.forEach((clause) => {
    if (!triggerMatchesEvent(clause.trigger, eventKey)) return;
    if (unit?.statuses) {
      unit.statuses.abilityTriggerCount = Math.max(0, toNumber(unit.statuses.abilityTriggerCount ?? 0) + 1);
    }
    const runtime = {
      ...context,
      side,
      eventKey,
      card: unit,
      self: unit,
    };
    executeAbilityBody(clause.body, runtime);
  });
}

function triggerAbilityEvent(side = 'player', eventKey = '', context = {}) {
  unitLaneForSide(side).forEach((unit) => triggerUnitAbilityEvent(unit, side, eventKey, context));
  const permanents = [...withSideZone(side, 'field'), ...withSideZone(side, 'relic')];
  permanents.forEach((perm) => {
    structuredAbilityEntries(perm).forEach((scripted) => {
      const scriptedTrigger = triggerKeyFromAbility(scripted);
      if (!triggerMatchesEvent(scriptedTrigger, eventKey) && !(eventKey === 'on_play' && !scriptedTrigger)) return;
      perm.statuses = perm.statuses ?? {};
      perm.statuses.abilityTriggerCount = Math.max(0, toNumber(perm.statuses.abilityTriggerCount ?? 0) + 1);
      executeStructuredAbility(scripted, { ...context, side, eventKey, card: perm, self: perm });
    });
    const clauses = getAbilityClauses(perm);
    clauses.forEach((clause) => {
      if (!triggerMatchesEvent(clause.trigger, eventKey)) return;
      perm.statuses = perm.statuses ?? {};
      perm.statuses.abilityTriggerCount = Math.max(0, toNumber(perm.statuses.abilityTriggerCount ?? 0) + 1);
      executeAbilityBody(clause.body, { ...context, side, eventKey, card: perm, self: perm });
    });
  });
}

function openTopDeckPreview(side = 'player', options = {}) {
  const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
  if (!Array.isArray(deck) || deck.length === 0) return null;
  const count = Math.max(1, Number(options.count ?? 1));
  state.topDeckPreview = {
    side,
    cards: deck.slice(0, count).map((card) => ({ ...card })),
    allowBottom: !!options.allowBottom,
    sourceName: options.sourceName ?? 'Deck Preview',
  };
  noteTurnFlag(side, 'lookedAtDeck', 1);
  triggerAbilityEvent(side, 'on_deck_peek', { side, peekedCards: state.topDeckPreview.cards, peekedCard: state.topDeckPreview.cards[0] ?? null });
  return state.topDeckPreview;
}

function closeTopDeckPreview() {
  state.topDeckPreview = null;
}

function moveTopDeckCardToBottom(side = 'player') {
  const deck = side === 'player' ? state.playerDeck : state.enemyDeck;
  if (!deck.length) return;
  const [top] = deck.splice(0, 1);
  if (top) deck.push(top);
}

function readMatchContext() {
  try {
    const parsed = JSON.parse(localStorage.getItem(MATCH_CONTEXT_KEY) || 'null');
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function clearQueuedMatchKeys() {
  localStorage.removeItem(MATCH_KEY);
  localStorage.removeItem(MATCH_CONTEXT_KEY);
}

function bootPanel() {
  return document.querySelector('#boot-loading');
}

function setBootStatus(message = '') {
  const node = document.querySelector('#boot-status');
  if (node) node.textContent = String(message ?? '');
}

function setBootActionsVisible(visible = false) {
  document.querySelector('#boot-actions')?.classList.toggle('hidden', !visible);
}

function appendBootLogLine(line = '', tone = 'info') {
  const files = document.querySelector('#boot-files');
  if (!files) return;
  const row = document.createElement('div');
  row.textContent = String(line ?? '');
  row.dataset.tone = tone;
  files.prepend(row);
}

function resetBootUi() {
  const panel = bootPanel();
  if (!panel) return;
  panel.classList.remove('boot-failed');
  panel.classList.remove('hidden');
  const files = document.querySelector('#boot-files');
  if (files) files.innerHTML = '';
  setBootStatus('Loading runtime packs and battle data...');
  setBootActionsVisible(false);
  document.querySelector('#app')?.classList.add('hidden');
  document.querySelector('#title-screen')?.classList.add('hidden');
}

function clearBootWatchdog() {
  if (!bootWatchdogHandle) return;
  clearTimeout(bootWatchdogHandle);
  bootWatchdogHandle = null;
}

function showBootFailure(message = 'Runtime boot failed.', error = null) {
  clearBootWatchdog();
  bootCompleted = false;
  bootSequence += 1;
  const panel = bootPanel();
  if (!panel) return;
  panel.classList.remove('hidden');
  panel.classList.add('boot-failed');
  setBootStatus(message);
  setBootActionsVisible(true);
  document.querySelector('#app')?.classList.add('hidden');
  document.querySelector('#title-screen')?.classList.add('hidden');
  if (error) {
    const detail = typeof error === 'string'
      ? error
      : (error?.message || error?.stack || String(error));
    appendBootLogLine(`Boot failure: ${detail}`, 'error');
  }
}

function scheduleBootWatchdog(sequence) {
  clearBootWatchdog();
  bootWatchdogHandle = setTimeout(() => {
    if (sequence !== bootSequence || bootCompleted) return;
    showBootFailure('Runtime boot took too long. Retry boot or clear the queued match and try again.');
  }, BOOT_TIMEOUT_MS);
}

function handleBootRuntimeError(message, error = null) {
  const panel = bootPanel();
  if (!panel || panel.classList.contains('hidden') || bootCompleted) return;
  console.error(message, error);
  showBootFailure(message, error);
}

function normalizeMatchContext(raw = null) {
  const ctx = raw && typeof raw === 'object' ? raw : {};
  return {
    modeModel: String(ctx.modeModel || 'duel').toLowerCase(),
    battleType: String(ctx.battleType || 'wielder_duel').toLowerCase(),
    rulesetId: String(ctx.rulesetId || 'wielder-duel'),
    rulesetName: String(ctx.rulesetName || 'Wielder Duel'),
    deckSize: Math.max(1, Math.floor(toNumber(ctx.deckSize, 30))),
    threatDeckSize: Math.max(1, Math.floor(toNumber(ctx.threatDeckSize, toNumber(ctx.deckSize, 30)))),
    maxCopiesPerCard: Math.max(1, Math.floor(toNumber(ctx.maxCopiesPerCard, 2))),
    startingMana: Math.max(1, Math.floor(toNumber(ctx.startingMana, 1))),
    startingHand: Math.max(1, Math.floor(toNumber(ctx.startingHand, 5))),
    structureSlots: Math.max(0, Math.floor(toNumber(ctx.structureSlots, 0))),
    enableStrategicZones: !!ctx.enableStrategicZones,
    enableResponseWindows: !!ctx.enableResponseWindows,
    worldId: ctx.worldId ? String(ctx.worldId) : '',
    planetId: ctx.planetId ? String(ctx.planetId) : '',
    objectiveId: ctx.objectiveId ? String(ctx.objectiveId) : '',
    threatId: ctx.threatId ? String(ctx.threatId) : '',
    aiSkillStars: Math.max(1, Math.floor(toNumber(ctx.aiSkillStars, 1))),
    techLevel: Math.max(0, Math.floor(toNumber(ctx.techLevel, 1))),
    metadata: ctx.metadata && typeof ctx.metadata === 'object' ? ctx.metadata : {},
  };
}

function usingDefenseModel() {
  const model = String(state.battleRuleset?.modeModel || '').toLowerCase();
  const type = String(state.battleRuleset?.battleType || '').toLowerCase();
  return model === 'defense'
    || type.includes('defense')
    || type.includes('invasion')
    || type.includes('conquest');
}

function cardCampaignMeta(card = {}) {
  const raw = card.mtgMeta ?? card.campaignMeta ?? {};
  const production = card.production ?? {};
  return {
    battleCompatibility: String(card.battleCompatibility ?? raw.battleCompatibility ?? 'both').toLowerCase(),
    speciesOrigin: String(production.speciesOrigin ?? raw.speciesOrigin ?? extractCardRaces(card)[0] ?? card.race ?? '').trim().toLowerCase(),
    worldOrigin: String(production.worldOrigin ?? raw.worldOrigin ?? card.homeDimension ?? '').trim(),
    unlockByWorld: String(production.unlockByWorld ?? raw.unlockByWorld ?? '').trim(),
    loseWithWorld: !!(production.loseWithWorld ?? raw.loseWithWorld ?? false),
    techRequirement: Math.max(0, toNumber(production.techRequirement ?? raw.techRequirement, 0)),
    favorRequirement: Math.max(0, toNumber(production.favorRequirement ?? raw.favorRequirement, 0)),
    requiredModes: String(production.requiredModes ?? raw.requiredModes ?? card.requiredModes ?? '').toLowerCase(),
  };
}

function availabilityForBattleCard(card = {}, side = 'player') {
  const meta = cardCampaignMeta(card);
  const defense = usingDefenseModel();
  if (!defense && isLocalExclusiveCard(card)) {
    return { available: false, reason: 'Local Player exclusive card not legal in standard normal mode.' };
  }
  if (!defense && isConquestOnlyCard(card)) {
    return { available: false, reason: 'Conquest-only card not legal in standard normal mode.' };
  }
  if (defense && meta.battleCompatibility === 'duel_only') {
    return { available: false, reason: 'Duel-only card not legal in defense mode.' };
  }
  if (!defense && meta.battleCompatibility === 'defense_only') {
    return { available: false, reason: 'Defense-only card not legal in duel mode.' };
  }
  const modeReq = meta.requiredModes.split(',').map((entry) => entry.trim()).filter(Boolean);
  if (modeReq.length && !modeReq.includes(state.battleRuleset.battleType)) {
    return { available: false, reason: `Requires mode: ${modeReq.join(', ')}` };
  }
  if (side !== 'player') return { available: true, reason: '' };

  const campaign = state.profile?.mapWorld?.campaign ?? {};
  const worldStates = campaign.worldStates ?? {};
  const speciesAccess = campaign.speciesAccess ?? {};
  const ownedWorlds = new Set(campaign.ownedWorldIds ?? []);
  const lostWorlds = new Set(campaign.lostWorldIds ?? []);
  const activeWorldId = state.battleRuleset.worldId || '';
  const activeWorld = activeWorldId ? worldStates[activeWorldId] : null;
  if (meta.unlockByWorld && !ownedWorlds.has(meta.unlockByWorld)) {
    return { available: false, reason: `Requires owning world ${meta.unlockByWorld}.` };
  }
  if (meta.worldOrigin && lostWorlds.has(meta.worldOrigin)) {
    return { available: false, reason: `Origin world lost: ${meta.worldOrigin}.` };
  }
  if (meta.loseWithWorld && meta.unlockByWorld && lostWorlds.has(meta.unlockByWorld)) {
    return { available: false, reason: `Unavailable while ${meta.unlockByWorld} is lost.` };
  }
  if (meta.speciesOrigin && speciesAccess[meta.speciesOrigin] === false) {
    return { available: false, reason: `Species unavailable: ${meta.speciesOrigin}.` };
  }
  const targetWorld = meta.worldOrigin ? worldStates[meta.worldOrigin] : activeWorld;
  if (meta.techRequirement > 0 && targetWorld) {
    const tech = toNumber(targetWorld.techLevel, 0);
    if (tech < meta.techRequirement) return { available: false, reason: `Needs tech ${meta.techRequirement} (${tech} current).` };
  }
  if (meta.favorRequirement > 0 && targetWorld) {
    const favor = toNumber(targetWorld.favor, 0);
    if (favor < meta.favorRequirement) return { available: false, reason: `Needs favor ${meta.favorRequirement} (${Math.round(favor)} current).` };
  }
  return { available: true, reason: '' };
}

let vfxRuntime = null;

function getDeckTrackerEntry(side, instanceId) {
  return state.deckTracker[side].find((entry) => entry.instanceId === instanceId) ?? null;
}

function upsertDeckTrackerEntry(side, entry) {
  const list = state.deckTracker[side];
  const idx = list.findIndex((item) => item.instanceId === entry.instanceId);
  if (idx >= 0) list[idx] = { ...list[idx], ...entry };
  else list.push({ originalOrder: list.length, ...entry });
}

function initializeDeckTracker(side, cards, source = 'deck_entry') {
  state.deckTracker[side] = [];
  cards.forEach((card, i) => {
    upsertDeckTrackerEntry(side, {
      instanceId: card.instanceId,
      cardId: card.id ?? card.instanceId,
      name: card.name ?? 'Unknown',
      cost: toNumber(card.cost, 0),
      type: card.type ?? 'minion',
      status: 'in_deck',
      source,
      rarity: card.rarity ?? 'common',
      originalOrder: i,
      transformedFrom: null,
    });
  });
}

function setDeckTrackerStatus(side, instanceId, status, extra = {}) {
  if (!instanceId) return;
  const existing = getDeckTrackerEntry(side, instanceId);
  if (!existing) {
    upsertDeckTrackerEntry(side, {
      instanceId,
      cardId: extra.cardId ?? instanceId,
      name: extra.name ?? 'Generated',
      cost: toNumber(extra.cost, 0),
      type: extra.type ?? 'minion',
      rarity: extra.rarity ?? 'common',
      source: extra.source ?? 'generated_effect',
      status,
      transformedFrom: extra.transformedFrom ?? null,
    });
    return;
  }
  upsertDeckTrackerEntry(side, { ...existing, ...extra, status });
}

function registerGeneratedDeckCard(side, card, status = 'generated') {
  const instanceId = card.instanceId ?? uid(side === 'enemy' ? 'eg' : 'pg');
  card.instanceId = instanceId;
  setDeckTrackerStatus(side, instanceId, status, {
    cardId: card.id ?? instanceId,
    name: card.name ?? 'Generated',
    cost: toNumber(card.cost, 0),
    type: card.type ?? 'minion',
    rarity: card.rarity ?? 'common',
    source: 'generated_effect',
  });
  return instanceId;
}

function getSortedDeckTracker(side) {
  const list = [...state.deckTracker[side]];
  const statusRank = { in_deck: 0, in_hand: 1, generated: 2, transformed: 3, played: 4 };
  if (state.playableDeckSort === 'mana') return list.sort((a, b) => (a.cost - b.cost) || (a.name || '').localeCompare(b.name || ''));
  if (state.playableDeckSort === 'type') return list.sort((a, b) => `${a.type}`.localeCompare(`${b.type}`) || (a.cost - b.cost));
  if (state.playableDeckSort === 'played') return list.sort((a, b) => (statusRank[a.status] ?? 9) - (statusRank[b.status] ?? 9));
  return list.sort((a, b) => (a.originalOrder ?? 0) - (b.originalOrder ?? 0));
}

function renderPlayableDeckOverlay() {
  const overlay = document.querySelector('#playable-deck-overlay');
  if (!overlay) return;
  overlay.classList.toggle('hidden', !state.playableDeckEnabled);
  overlay.classList.toggle('minimized', state.playableDeckMinimized);
  if (!state.playableDeckEnabled) return;
  const playerHost = document.querySelector('#playable-deck-player');
  const enemyHost = document.querySelector('#playable-deck-enemy');
  const renderHost = (host, side) => {
    if (!host) return;
    const entries = getSortedDeckTracker(side);
    host.innerHTML = '';
    entries.forEach((entry) => {
      const card = document.createElement('div');
      card.className = `deck-track-card state-${entry.status}`;
      card.dataset.inspectType = 'deck-track';
      card.dataset.inspectId = entry.instanceId;
      const badge = entry.status.replace('_', ' ');
      const sourceBadge = entry.source === 'generated_effect' ? 'generated' : entry.source === 'starter' ? 'starter' : 'deck';
      card.innerHTML = `<strong>${entry.name}</strong><div>${entry.cost} mana • ${entry.type}</div><div class="badge">${badge}</div><div class="badge">${sourceBadge}</div>`;
      card.oncontextmenu = (event) => {
        event.preventDefault();
        const sourceCard = allKnownCardsById()[entry.cardId] ?? {
          id: entry.cardId,
          name: entry.name,
          type: entry.type,
          cost: entry.cost,
          rarity: entry.rarity,
        };
        openInspectPanel({ type: 'deck-card', card: sourceCard, side });
      };
      host.appendChild(card);
    });
  };
  renderHost(playerHost, 'player');
  renderHost(enemyHost, 'enemy');
}

function isNeuralAiProfile(profile) {
  return !!profile;
}

function getCardVfxSpec(card, eventKey = 'attack') {
  if (!card) return null;
  const override = state.cardVfxOverrides?.[card.id]?.[eventKey];
  return override ?? card.vfx?.[eventKey] ?? null;
}

function allKnownCardsById() {
  return Object.fromEntries(getAllCards().map((card) => [card.id, card]));
}

function getCardEffect(card = {}) {
  const fromEffect = card.effect;
  if (fromEffect && typeof fromEffect === 'object' && Object.keys(fromEffect).length > 0) return fromEffect;
  const fromAbility = card.ability;
  if (fromAbility && typeof fromAbility === 'object' && Object.keys(fromAbility).length > 0) return fromAbility;
  return {};
}

function normalizeSpellAction(action = 'dealDamage') {
  const normalized = String(action ?? 'dealDamage').trim().toLowerCase();
  const aliases = {
    damage: 'dealDamage',
    directdamage: 'dealDamage',
    dealdamage: 'dealDamage',
    buffatk: 'buffAttack',
    buffattack: 'buffAttack',
    buffhp: 'buffHealth',
    buffhealth: 'buffHealth',
    grantarmor: 'grantArmor',
    grantdefense: 'grantDefense',
    drawcard: 'draw',
    draww: 'draw',
    poisonhero: 'poisonHero',
    poison: 'poisonHero',
    shatterfront: 'shatterFront',
    weakenallenemies: 'weakenAllEnemies',
    timelock: 'timeLock',
  };
  return aliases[normalized] ?? (normalized || 'dealDamage');
}

function fallbackAmountForSpellAction(action, card = {}) {
  const cost = Math.max(0, toNumber(card.cost ?? 0));
  const damage = Math.max(0, toNumber(card.damage ?? 0));
  if (action === 'dealDamage') return Math.max(1, damage || Math.ceil(cost * 0.8) || 1);
  if (action === 'draw') return Math.max(1, Math.min(3, Math.ceil(cost / 3) || 1));
  if (action === 'heal' || action === 'buffHealth') return Math.max(1, Math.ceil(cost / 2) || 1);
  if (action === 'grantArmor' || action === 'grantDefense') return Math.max(1, Math.ceil(cost / 2) || 1);
  if (action === 'buffAttack') return Math.max(1, Math.ceil(cost / 3) || 1);
  if (action === 'weakenAllEnemies') return Math.max(1, Math.ceil(cost / 3) || 1);
  if (action === 'summon') return Math.max(1, Math.min(3, Math.ceil(cost / 4) || 1));
  return 1;
}

function normalizeSpellEffect(card = {}) {
  const raw = getCardEffect(card);
  const action = normalizeSpellAction(raw.action ?? card.action ?? 'dealDamage');
  const parsedAmount = toNumber(raw.amount ?? card.damage ?? card.effectAmount ?? NaN, NaN);
  const amount = Number.isFinite(parsedAmount) && parsedAmount > 0
    ? parsedAmount
    : fallbackAmountForSpellAction(action, card);
  const duration = Math.max(1, toNumber(raw.duration ?? raw.turns ?? 1, 1));
  const defAmount = Math.max(1, toNumber(raw.defAmount ?? raw.armor ?? amount, amount));
  const pierce = Math.max(0, toNumber(raw.pierce ?? card.pierce ?? 0));
  const damageType = String(raw.damageType ?? (card.trueDamage ? 'true' : card.element ?? 'arcane')).toLowerCase();
  const trueDamage = damageType === 'true' || !!raw.trueDamage || !!card.trueDamage;
  return {
    action,
    amount,
    duration,
    defAmount,
    pierce,
    damageType,
    trueDamage,
    summonCount: Math.max(1, toNumber(raw.count ?? raw.amount ?? 1, 1)),
    raw,
  };
}

function describeSpellAction(effectData = {}) {
  const action = normalizeSpellAction(effectData.action ?? 'dealDamage');
  const amount = Math.max(0, toNumber(effectData.amount ?? 0));
  const duration = Math.max(1, toNumber(effectData.duration ?? 1));
  const defAmount = Math.max(1, toNumber(effectData.defAmount ?? amount ?? 1));
  const damageLabel = effectData.trueDamage ? 'true damage' : 'damage';
  if (action === 'dealDamage') return `Deal ${amount} ${damageLabel} to a priority enemy minion (Guard first, then highest DEF). If no enemy minion exists, hit enemy hero.`;
  if (action === 'poisonHero') return `Apply Poison to enemy hero: ${amount} damage at the end of each of your turns.`;
  if (action === 'shatterFront') return `Shatter a priority enemy minion (Guard first): set DEF to 0 and remove Defense Stance for ${duration} turn(s).`;
  if (action === 'grantDefense') return `Give a priority allied minion +${defAmount} DEF, enter Defense Stance, and gain Guard.`;
  if (action === 'weakenAllEnemies') return `Apply Weakened to all enemy minions for ${duration} turn(s) (-1 ATK).`;
  if (action === 'draw') return `Draw ${amount} card(s).`;
  if (action === 'heal') return `Restore ${amount} HP to your most damaged ally (or your hero if no ally is damaged).`;
  if (action === 'buffAttack') return `Give a priority allied minion +${amount} ATK.`;
  if (action === 'buffHealth') return `Give a priority allied minion +${amount} Max HP and heal it for ${amount}.`;
  if (action === 'grantArmor') return `Gain +${amount} Core DEF this match.`;
  if (action === 'timelock' || action === 'timeLock') return `Time-Lock a priority enemy minion for ${duration} turn(s) (cannot attack).`;
  if (action === 'tax') return `Tax opponent's next turn by ${amount} mana.`;
  if (action === 'sentence') return `Apply Sentence to a priority enemy minion for ${duration} turn(s). Sentenced units take 1 true damage each owner turn end.`;
  if (action === 'summon') return `Summon ${Math.max(1, toNumber(effectData.summonCount ?? amount ?? 1))} token minion(s) into free slots.`;
  return `Resolve effect: ${action}${amount ? ` (${amount})` : ''}.`;
}

function cardRulesInBattleTerms(card = {}) {
  const lines = [];
  const type = normalizeCardType(card);
  const hasEffect = Object.keys(getCardEffect(card)).length > 0;
  const spellEffect = normalizeSpellEffect(card);
  if (type === 'minion' || type === 'token') {
    lines.push(`Summon: ${card.attack ?? 0} ATK / ${card.health ?? 0} HP / ${Math.max(0, toNumber(card.def ?? card.baseDef ?? 0))} DEF.`);
    if (hasEffect) lines.push(`On Play: ${describeSpellAction(spellEffect)}`);
    lines.push('Board rule: placed into Front Row or Back Row (4 slots each).');
  } else if (type === 'spell' || type === 'sorcery') {
    lines.push(`Cast: ${describeSpellAction(spellEffect)}`);
    lines.push('Spell speed: Sorcery (main phases only).');
  } else if (type === 'instant') {
    lines.push(`Cast: ${describeSpellAction(spellEffect)}`);
    lines.push('Spell speed: Instant (response windows and main phases).');
  } else if (type === 'field') {
    lines.push('Permanent: enters the Field Tray and stays active until removed.');
    if (hasEffect) lines.push(`Field Effect: ${describeSpellAction(spellEffect)}`);
  } else if (type === 'relic') {
    lines.push('Permanent: enters the Relic Tray and applies persistent effects.');
    if (hasEffect) lines.push(`Relic Effect: ${describeSpellAction(spellEffect)}`);
  } else if (type === 'barricade') {
    lines.push('Structure: deploy to a front-row lane; that lane must break this barricade before attacks pass through.');
    lines.push(`Durability: ${card.health ?? card.durability ?? 6} HP / DEF ${Math.max(0, toNumber(card.def ?? card.baseDef ?? 1))}.`);
    if (hasEffect) lines.push(`On Deploy: ${describeSpellAction(spellEffect)}`);
  } else {
    lines.push(`Type: ${type}.`);
  }
  if (card.cost != null) lines.push(`Cost: ${card.cost} mana.`);
  if (card.taunt || card.guard || card.seamguard) lines.push('Guard: enemy attacks must target this unit while it is active.');
  if (card.charge) lines.push('Charge: can attack on the turn it is summoned.');
  if (card.pierce) lines.push(`Pierce ${card.pierce}: ignores that much DEF on each hit.`);
  if (card.trueDamage) lines.push('True Damage: ignores DEF.');
  if (card.allowMultiAttack) lines.push('Multi-Attack: can attack more than once each turn.');
  if (card.allowFriendlyAttack) lines.push('Friendly Targeting: can target friendly units.');
  if (card.swarm || (Array.isArray(card.tags) && card.tags.some((t) => String(t).toLowerCase() === 'swarm'))) {
    lines.push('Swarm: this unit represents multiple bodies; on death it spawns 1/1 fragments if slots are open.');
  }
  if (card.large || (Array.isArray(card.tags) && card.tags.some((t) => String(t).toLowerCase() === 'large'))) {
    lines.push('Large: requires two adjacent slots in the same row.');
  }
  if (card.flying) lines.push('Flying: can pressure protected back-row targets.');
  if (card.reach) lines.push('Reach: can interact with flying/back-row threats.');
  if (card.siege) lines.push('Siege: can pressure through lane protection and barricade lines.');
  if (spellEffect.pierce > 0) lines.push(`Spell Pierce ${spellEffect.pierce}: ignores that much DEF.`);
  if (spellEffect.trueDamage) lines.push('Spell damage type: True (ignores DEF).');
  if (lines.length === 0) lines.push('No explicit battle effect defined.');
  return [...new Set(lines.filter(Boolean))];
}

function triggerBattleVfx(eventName, payload = {}) {
  emitVfx(eventName, payload);
  if (vfxRuntime) vfxRuntime.trigger(eventName, payload);
}

function ensureCombatFields(minion) {
  if (!minion) return minion;
  minion.statuses = minion.statuses ?? {};
  const loweredText = cardText(minion).toLowerCase();
  minion.races = extractCardRaces(minion);
  minion.race = minion.races[0] ?? normalizeFamilyToken(minion.race ?? minion.type ?? 'neutral') ?? 'neutral';
  minion.tags = Array.isArray(minion.tags) ? [...new Set(minion.tags)] : [];
  minion.baseTaunt = !!(minion.baseTaunt ?? minion.taunt);
  minion.baseFlying = !!(minion.baseFlying ?? minion.flying);
  minion.baseLifesteal = !!(minion.baseLifesteal ?? minion.lifesteal);
  minion.baseRush = !!(minion.baseRush ?? minion.rush);
  minion.baseMaxHealth = Math.max(1, toNumber(minion.baseMaxHealth ?? minion.maxHealth ?? minion.health, 1));
  minion.keywords = Array.isArray(minion.keywords)
    ? minion.keywords
    : (Array.isArray(minion.tags) ? minion.tags : []);
  minion.baseDef = Math.max(0, toNumber(minion.baseDef ?? minion.def ?? minion.defenseValue ?? 0));
  minion.pierce = Math.max(0, toNumber(minion.pierce ?? 0));
  minion.trueDamage = !!minion.trueDamage;
  minion.flying = !!minion.flying || minion.keywords.some((k) => String(k).toLowerCase() === 'flying');
  minion.reach = !!minion.reach || minion.keywords.some((k) => String(k).toLowerCase() === 'reach');
  minion.siege = !!minion.siege || minion.keywords.some((k) => String(k).toLowerCase() === 'siege');
  minion.swarm = !!minion.swarm || minion.keywords.some((k) => String(k).toLowerCase() === 'swarm');
  minion.large = !!minion.large || minion.keywords.some((k) => String(k).toLowerCase() === 'large');
  minion.poisonousVsDamaged = !!minion.poisonousVsDamaged || /poisonous against damaged minions/.test(loweredText);
  minion.defense = !!minion.defense;
  minion.defenseDurability = Math.max(0, toNumber(minion.defenseDurability ?? (minion.defense ? 2 : 0)));
  minion.taunt = !!minion.baseTaunt || minion.defense;
  if (!minion.statuses.passiveKeywordsApplied) {
    if (/\bstealth\b/.test(loweredText)) {
      minion.stealth = true;
      minion.statuses.stealth = true;
      if (/until your next turn/.test(loweredText)) {
        minion.statuses.stealthTurns = Math.max(1, toNumber(minion.statuses.stealthTurns ?? 0) + 1);
      }
    }
    if (/\bdivine shield\b/.test(loweredText)) {
      minion.statuses.divineShield = true;
      if (/while at full health/.test(loweredText)) minion.statuses.divineShieldPersistent = true;
    }
    if (/\btaunt\b/.test(loweredText)) {
      minion.taunt = true;
      minion.baseTaunt = true;
    }
    if (/\bflying\b/.test(loweredText)) minion.flying = true;
    if (/\blifesteal\b/.test(loweredText)) minion.lifesteal = true;
    if (/\bpoisonous\b/.test(loweredText)) minion.poisonousVsDamaged = true;
    minion.statuses.passiveKeywordsApplied = true;
  }
  if (/can'?t attack heroes while enemy minions are alive/.test(loweredText)) minion.cannotHitHero = true;
  if (/rush/.test(loweredText) && !/cannot/.test(loweredText)) minion.charge = !!minion.charge || !!minion.rush;
  if (/divine shield while at full health/.test(loweredText)) {
    if ((minion.health ?? 0) >= (minion.maxHealth ?? minion.health ?? 0)) minion.statuses.divineShield = true;
    else if (!minion.statuses?.divineShieldPersistent) minion.statuses.divineShield = false;
  }
  if (minion.large) {
    const baseSlot = Number.isInteger(minion.slot) ? minion.slot : null;
    const occupied = Array.isArray(minion.occupiedSlots) ? minion.occupiedSlots : (baseSlot == null ? [] : [baseSlot, baseSlot + 1]);
    minion.occupiedSlots = occupied.filter((slot) => Number.isInteger(slot) && slot >= 0 && slot < MAX_SLOTS);
  }
  return minion;
}

function buildPlayerDeck() {
  const allCards = getAllCards();
  if (allCards.length === 0) return [];
  const targetSize = Math.max(1, Math.floor(toNumber(state.battleRuleset?.deckSize, 30)));
  const byId = Object.fromEntries(allCards.map((card) => [card.id, card]));
  const selected = getSelectedDeck();
  state.deckValidationIssues = [];
  const pool = [];
  if (selected?.entries?.length) {
    selected.entries.forEach((entry) => {
      const card = byId[entry.cardId];
      if (!card) {
        state.deckValidationIssues.push(`Missing card id: ${entry.cardId}.`);
        return;
      }
      const availability = availabilityForBattleCard(card, 'player');
      if (!availability.available) {
        state.deckValidationIssues.push(`${card.name}: ${availability.reason}`);
        return;
      }
      for (let i = 0; i < Math.max(0, Number(entry.count) || 0); i += 1) pool.push({ ...card });
    });
  }
  const fallbackPool = allCards.filter((card) => availabilityForBattleCard(card, 'player').available);
  if (pool.length === 0) {
    const source = fallbackPool.length ? fallbackPool : allCards;
    for (let i = 0; i < targetSize; i += 1) pool.push({ ...source[i % source.length] });
  }
  while (pool.length < targetSize) {
    const source = fallbackPool.length ? fallbackPool : allCards;
    pool.push({ ...source[pool.length % source.length] });
  }
  return shuffle(pool).slice(0, targetSize).map((card) => ({ ...card, instanceId: uid('card') }));
}

function isDuelBattleMode() {
  const model = String(state.battleRuleset?.modeModel ?? '').toLowerCase();
  const type = String(state.battleRuleset?.battleType ?? '').toLowerCase();
  return model === 'duel' || type.includes('wielder') || type.includes('duel');
}

function refillPlayerDeckFromBuild() {
  const refill = buildPlayerDeck();
  if (!refill.length) return false;
  state.playerDeck = shuffle([...state.playerDeck, ...refill]);
  refill.forEach((card) => {
    setDeckTrackerStatus('player', card.instanceId, 'in_deck', {
      cardId: card.id ?? card.instanceId,
      name: card.name ?? 'Unknown',
      cost: toNumber(card.cost, 0),
      type: card.type ?? 'minion',
      rarity: card.rarity ?? 'common',
      source: 'deck_refill',
    });
  });
  state.playerDeckRefills = Math.max(0, Number(state.playerDeckRefills ?? 0)) + 1;
  log(`Deck recycled (${refill.length} cards).`);
  toast(`Deck recycled (#${state.playerDeckRefills}).`, 'info');
  return true;
}

function drawPlayerCards(count = 1, source = 'draw') {
  const heroEl = document.querySelector('[data-target-id="player-hero"]');
  for (let i = 0; i < count; i += 1) {
    if (state.hand.length >= 10) break;
    let next = state.playerDeck.shift();
    if (!next && isDuelBattleMode()) {
      const recycled = refillPlayerDeckFromBuild();
      if (recycled) next = state.playerDeck.shift();
    }
    if (!next) {
      state.playerFatigue += 1;
      state.playerHealth -= state.playerFatigue;
      spawnDamageNumber(heroEl, state.playerFatigue, 'shadow');
      log(`Fatigue hits for ${state.playerFatigue}.`);
      cleanupDead();
      continue;
    }
    const drawn = { ...next, instanceId: next.instanceId ?? uid('card') };
    state.hand.push(drawn);
    setDeckTrackerStatus('player', next.instanceId, 'in_hand');
    if (state.currentTurn !== 'player') noteTurnFlag('player', 'drewOutsideTurn', 1);
    triggerUnitAbilityEvent(drawn, 'player', 'on_drawn_self', { side: 'player', self: drawn, drawnCard: drawn, source });
    triggerAbilityEvent('player', 'on_draw', { drawnCard: drawn, source });
    if (/^when drawn/i.test(cardText(drawn).toLowerCase())) {
      state.hand = state.hand.filter((entry) => entry.instanceId !== drawn.instanceId);
      pushToZone('player', 'graveyard', { ...drawn, type: normalizeCardType(drawn) });
    }
  }
  if (source === 'opening') log(`Opening hand drawn (${state.hand.length} cards).`);
}

function drawEnemyCards(count = 1, source = 'draw') {
  const heroEl = document.querySelector('[data-target-id="enemy-hero"]');
  for (let i = 0; i < count; i += 1) {
    if (state.enemyHand.length >= 10) break;
    let next = state.enemyDeck.shift();
    if (!next) {
      state.enemyFatigue += 1;
      state.enemyHealth -= state.enemyFatigue;
      spawnDamageNumber(heroEl, state.enemyFatigue, 'shadow');
      cleanupDead();
      continue;
    }
    const drawn = {
      ...next,
      instanceId: next.instanceId ?? uid('ecard'),
      drawSource: source,
      justDrawn: source === 'turn',
    };
    state.enemyHand.push(drawn);
    setDeckTrackerStatus('enemy', next.instanceId, 'in_hand');
    if (state.currentTurn !== 'enemy') noteTurnFlag('enemy', 'drewOutsideTurn', 1);
    triggerUnitAbilityEvent(drawn, 'enemy', 'on_drawn_self', { side: 'enemy', self: drawn, drawnCard: drawn, source });
    triggerAbilityEvent('enemy', 'on_draw', { side: 'enemy', drawnCard: drawn, source });
  }
}

function runEnemyMulligan(profile = currentAiProfile()) {
  if (!profile || !state.enemyHand.length || !state.enemyDeck.length) return;
  const scored = state.enemyHand.map((card, index) => ({ index, score: mulliganCardScore(card, profile) }));
  const redraw = scored
    .sort((a, b) => a.score - b.score)
    .slice(0, Math.min(3, scored.length))
    .filter((entry) => entry.score < 3.2)
    .map((entry) => entry.index)
    .sort((a, b) => b - a);
  if (!redraw.length) return;

  const returned = [];
  redraw.forEach((index) => {
    const [card] = state.enemyHand.splice(index, 1);
    if (!card) return;
    returned.push({ ...card, justDrawn: false, drawSource: 'deck' });
    setDeckTrackerStatus('enemy', card.instanceId, 'in_deck');
  });
  state.enemyDeck = shuffle([...state.enemyDeck, ...returned]);
  drawEnemyCards(returned.length, 'mulligan');
  log(`${profile.name} mulliganed ${returned.length} card(s).`);
}

function normalizeCardType(card = {}) {
  const t = String(card.type ?? 'minion').toLowerCase();
  if (t === 'minion' || t === 'creature' || t === 'token') return 'minion';
  if (t === 'spell') return 'spell';
  if (t === 'instant') return 'instant';
  if (t === 'sorcery') return 'sorcery';
  if (t === 'field') return 'field';
  if (t === 'relic' || t === 'artifact') return 'relic';
  if (t === 'barricade' || t === 'structure' || t === 'fortress' || t === 'turret' || t === 'reactor') return 'barricade';
  if (t === 'aura' || t === 'enchantment') return 'aura';
  if (t === 'trap') return 'trap';
  return t;
}

function cardMatchesFamily(card = {}, family = '') {
  return hasFamilyTag(card, family);
}

function passiveAuraEntries(card = {}) {
  return structuredAbilityEntries(card).filter((entry) => {
    const trigger = String(entry?.trigger ?? entry?.timing ?? '').trim().toLowerCase();
    return trigger === 'aura' || trigger === 'passive';
  });
}

function passiveAuraEffect(entry = {}) {
  return entry?.effect && typeof entry.effect === 'object' ? entry.effect : entry;
}

function passiveAuraFamilies(entry = {}) {
  const effect = passiveAuraEffect(entry);
  return [...new Set([
    entry.family,
    effect.family,
    ...(Array.isArray(entry.families) ? entry.families : []),
    ...(Array.isArray(effect.families) ? effect.families : []),
  ].map((value) => normalizeFamilyToken(value)).filter(Boolean))];
}

function passiveAuraMatchesUnit(entry = {}, unit = null, source = null, side = 'player') {
  if (!unit || (unit.health ?? 0) <= 0) return false;
  const effect = passiveAuraEffect(entry);
  const families = passiveAuraFamilies(entry);
  if (effect.excludeSelf && source?.id && unit.id === source.id) return false;
  if (families.length && !families.some((family) => cardMatchesFamily(unit, family))) return false;
  if (effect.stealthedOnly && !(unit.stealth || unit.statuses?.stealth)) return false;
  if (effect.fullHealthOnly && !cardIsAtFullHealth(unit)) return false;
  if (effect.damagedOnly && cardIsAtFullHealth(unit)) return false;
  if (effect.attackAtMost != null && toNumber(unit.attack, 0) > toNumber(effect.attackAtMost, 0)) return false;
  if (effect.attackAtLeast != null && toNumber(unit.attack, 0) < toNumber(effect.attackAtLeast, 0)) return false;
  if (effect.costAtLeast != null && toNumber(unit.cost, 0) < toNumber(effect.costAtLeast, 0)) return false;
  if (effect.ownerTurnOnly && state.currentTurn !== side) return false;
  return true;
}

function passiveAuraMatchesCard(entry = {}, card = {}, side = 'player') {
  if (!card) return false;
  const effect = passiveAuraEffect(entry);
  const families = passiveAuraFamilies(entry);
  if (families.length && !families.some((family) => cardMatchesFamily(card, family))) return false;
  if (effect.ifEnemyDiedThisTurn && !getTurnFlags(side).enemyMinionDied) return false;
  if (effect.ifMinionDiedThisTurn && !(getTurnFlags(side).minionDied || getTurnFlags(enemySide(side)).minionDied)) return false;
  return true;
}

function passiveAuraSources(side = 'player') {
  return [
    ...unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0),
    ...withSideZone(side, 'field'),
    ...withSideZone(side, 'relic'),
  ];
}

function passiveAuraBundlesForUnit(side = 'player', unit = null) {
  const bundles = [];
  passiveAuraSources(side).forEach((source) => {
    passiveAuraEntries(source).forEach((entry) => {
      if (!passiveAuraMatchesUnit(entry, unit, source, side)) return;
      bundles.push({ source, entry, effect: passiveAuraEffect(entry) });
    });
  });
  return bundles;
}

function passiveAuraCostReduction(side = 'player', card = {}) {
  let reduction = 0;
  passiveAuraSources(side).forEach((source) => {
    passiveAuraEntries(source).forEach((entry) => {
      const effect = passiveAuraEffect(entry);
      if (!passiveAuraMatchesCard(entry, card, side)) return;
      reduction += Math.max(0, toNumber(effect.costReduction ?? 0, 0));
    });
  });
  return reduction;
}

function refreshAuraStateForUnit(side = 'player', unit = null) {
  if (!unit || (unit.health ?? 0) <= 0) return;
  ensureCombatFields(unit);
  unit.statuses = unit.statuses ?? {};
  const bundles = passiveAuraBundlesForUnit(side, unit);
  const attackBonus = bundles.reduce((sum, bundle) => sum + Math.max(0, toNumber(bundle.effect.attack ?? 0, 0)), 0);
  const healthBonus = bundles.reduce((sum, bundle) => sum + Math.max(0, toNumber(bundle.effect.health ?? 0, 0)), 0);
  const previousHealthBonus = Math.max(0, toNumber(unit.statuses.auraHealthBonusApplied ?? 0, 0));
  const baseMaxHealth = Math.max(1, toNumber(unit.baseMaxHealth ?? unit.maxHealth ?? unit.health, 1));
  if (unit.baseMaxHealth == null) unit.baseMaxHealth = baseMaxHealth;
  const nextMaxHealth = Math.max(1, baseMaxHealth + healthBonus);
  const delta = healthBonus - previousHealthBonus;
  if (delta !== 0) {
    unit.maxHealth = nextMaxHealth;
    unit.health = delta > 0
      ? Math.min(nextMaxHealth, toNumber(unit.health, 1) + delta)
      : Math.min(toNumber(unit.health, 1), nextMaxHealth);
  } else {
    unit.maxHealth = nextMaxHealth;
    unit.health = Math.min(toNumber(unit.health, 1), nextMaxHealth);
  }
  unit.statuses.auraHealthBonusApplied = healthBonus;
  unit.statuses.auraAttackBonus = attackBonus;
  unit.statuses.keepStealthAfterAttackAura = bundles.some((bundle) => !!bundle.effect.keepStealthAfterAttack);
  unit.statuses.immediateAttackAura = bundles.some((bundle) => !!bundle.effect.grantImmediateAttack);
  unit.statuses.auraTaunt = bundles.some((bundle) => {
    const keywords = [...(Array.isArray(bundle.effect.keywords) ? bundle.effect.keywords : []), bundle.effect.keyword].filter(Boolean);
    return keywords.some((keyword) => String(keyword).toLowerCase() === 'taunt');
  });
  unit.statuses.auraLifesteal = bundles.some((bundle) => {
    const keywords = [...(Array.isArray(bundle.effect.keywords) ? bundle.effect.keywords : []), bundle.effect.keyword].filter(Boolean);
    return keywords.some((keyword) => String(keyword).toLowerCase() === 'lifesteal');
  });
  unit.statuses.auraFlying = bundles.some((bundle) => {
    const keywords = [...(Array.isArray(bundle.effect.keywords) ? bundle.effect.keywords : []), bundle.effect.keyword].filter(Boolean);
    return keywords.some((keyword) => String(keyword).toLowerCase() === 'flying');
  });
  unit.statuses.auraRush = bundles.some((bundle) => {
    const keywords = [...(Array.isArray(bundle.effect.keywords) ? bundle.effect.keywords : []), bundle.effect.keyword].filter(Boolean);
    return keywords.some((keyword) => String(keyword).toLowerCase() === 'rush');
  });
  unit.taunt = !!unit.baseTaunt || !!unit.defense || !!unit.statuses.auraTaunt;
  unit.lifesteal = !!unit.baseLifesteal || !!unit.statuses.auraLifesteal || /\blifesteal\b/i.test(cardText(unit));
  unit.flying = !!unit.baseFlying || !!unit.statuses.auraFlying || /\bflying\b/i.test(cardText(unit));
  unit.rush = !!unit.baseRush || !!unit.statuses.auraRush || /\brush\b/i.test(cardText(unit));
  if (unit.statuses.immediateAttackAura && unit.summoningSick) unit.summoningSick = false;
}

function refreshPassiveAuraState(side = 'player') {
  unitLaneForSide(side).forEach((unit) => refreshAuraStateForUnit(side, unit));
}

function refreshAllPassiveAuras() {
  refreshPassiveAuraState('player');
  refreshPassiveAuraState('enemy');
}

function boardCostReductionForCard(side = 'player', card = {}) {
  const lane = unitLaneForSide(side);
  const permanents = [...withSideZone(side, 'field'), ...withSideZone(side, 'relic')];
  let reduction = 0;
  const applyFromText = (text = '') => {
    const source = normalizeAbilityText(text).toLowerCase();
    const direct = source.match(/your\s+([a-z-]+)s?\s+cost\s+\((\d+)\)\s+less/);
    if (direct && cardMatchesFamily(card, direct[1])) reduction += Number(direct[2] ?? 0);
    const familiarityDirect = source.match(/([a-z-]+)\s+familiarity\s+(\d+):\s*your\s+([a-z-]+)s?\s+cost\s+\((\d+)\)\s+less/i);
    if (familiarityDirect && cardMatchesFamily(card, familiarityDirect[3])) {
      const threshold = Number(familiarityDirect[2] ?? 0);
      if (getFamiliarity(familiarityPoolForSide(side), familiarityDirect[1]) >= threshold) {
        reduction += Number(familiarityDirect[4] ?? 0);
      }
    }
    if (/first\s+beast\s+each\s+turn\s+costs\s+\((\d+)\)\s+less/.test(source) && cardMatchesFamily(card, 'beast')) {
      reduction += Number(source.match(/first\s+beast\s+each\s+turn\s+costs\s+\((\d+)\)\s+less/)?.[1] ?? 0);
    }
    if (/first\s+skeleton\s+each\s+turn/.test(source) && cardMatchesFamily(card, 'skeleton')) reduction += 1;
  };
  lane.forEach((unit) => {
    if ((unit?.health ?? 0) <= 0) return;
    applyFromText(unit?.text ?? '');
  });
  permanents.forEach((perm) => applyFromText(perm?.text ?? ''));
  reduction += passiveAuraCostReduction(side, card);
  return reduction;
}

function conditionalCardReduction(card = {}, side = 'player') {
  const text = normalizeAbilityText(card?.text ?? '').toLowerCase();
  let reduction = 0;
  const diedMatch = text.match(/costs\s+\((\d+)\)\s+less\s+if\s+a\s+minion\s+died\s+this\s+turn/);
  if (diedMatch && (getTurnFlags(side).minionDied || getTurnFlags(enemySide(side)).minionDied)) {
    reduction += Number(diedMatch[1] ?? 0);
  }
  const eachMatch = text.match(/costs\s+\((\d+)\)\s+less\s+for\s+each\s+friendly\s+([a-z-]+)/);
  if (eachMatch) {
    const per = Number(eachMatch[1] ?? 0);
    const family = eachMatch[2] ?? '';
    const count = unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0 && cardMatchesFamily(unit, family)).length;
    reduction += per * count;
  }
  const eachZoneMatch = text.match(/costs\s+\((\d+)\)\s+less\s+for\s+each\s+([a-z-]+)\s+in\s+your\s+(hand|deck|grave|graveyard|discard)/i);
  if (eachZoneMatch) {
    const per = Number(eachZoneMatch[1] ?? 0);
    const family = eachZoneMatch[2] ?? '';
    const zone = String(eachZoneMatch[3] ?? 'hand').toLowerCase();
    reduction += per * familyCountInZone(side, family, zone === 'grave' || zone === 'discard' ? 'graveyard' : zone);
  }
  const deckOnlyMatch = text.match(/costs\s+\((\d+)\)\s+less\s+if\s+your\s+deck\s+contains\s+only\s+([a-z-,\sand]+)/i);
  if (deckOnlyMatch) {
    const families = parseFamilyList(deckOnlyMatch[2]);
    const passes = families.length === 1
      ? deckContainsOnlyFamily(cardsInZone(side, 'deck'), families[0])
      : families.length > 1
        ? deckContainsOnlyFamilies(cardsInZone(side, 'deck'), families)
        : false;
    if (passes) reduction += Number(deckOnlyMatch[1] ?? 0);
  }
  if (/costs\s+\((\d+)\)\s+less\s+if\s+you\s+control\s+a\s+stealthed\s+minion/.test(text)) {
    const amount = Number(text.match(/costs\s+\((\d+)\)\s+less\s+if\s+you\s+control\s+a\s+stealthed\s+minion/)?.[1] ?? 0);
    if (boardHas(side, (unit) => !!unit.stealth || !!unit.statuses?.stealth)) reduction += amount;
  }
  return reduction;
}

function effectiveCardCost(card = {}, side = 'player', extraSpellDiscount = 0) {
  const base = Math.max(0, toNumber(card?.cost ?? 0));
  const fromOffset = Math.max(0, toNumber(card?.costOffset ?? 0));
  const fromBoard = Math.max(0, boardCostReductionForCard(side, card));
  const fromText = Math.max(0, conditionalCardReduction(card, side));
  return Math.max(0, base - fromOffset - fromBoard - Math.max(0, toNumber(extraSpellDiscount, 0)) - fromText);
}

function firstSpellDiscount(side = 'player') {
  const fields = withSideZone(side, 'field');
  const relics = withSideZone(side, 'relic');
  let discount = 0;
  [...fields, ...relics].forEach((perm) => {
    discount += Math.max(0, toNumber(perm.effect?.firstSpellDiscount ?? perm.firstSpellDiscount ?? 0));
  });
  return discount;
}

function applyFieldStartEffects(side = 'player') {
  const fields = withSideZone(side, 'field');
  const relics = withSideZone(side, 'relic');
  const heroSide = side === 'player' ? 'player' : 'enemy';
  [...fields, ...relics].forEach((perm) => {
    const effect = perm.effect ?? {};
    const gain = Math.max(0, toNumber(effect.manaGain ?? perm.manaGain ?? 0));
    if (gain > 0) {
      if (heroSide === 'player') state.mana = Math.min(20, state.mana + gain);
      else state.enemyMana = Math.min(20, state.enemyMana + gain);
    }
    const coreDefBonus = Math.max(0, toNumber(effect.coreDefBonus ?? perm.coreDefBonus ?? 0));
    if (coreDefBonus > 0) {
      if (heroSide === 'player') state.playerCoreDef += coreDefBonus;
      else state.enemyCoreDef += coreDefBonus;
    }
  });
}

function beginPhaseFlowFor(side = 'player') {
  clearTemporaryTurnBuffs(side);
  state.lastTurnFlags[side] = { ...getTurnFlags(side) };
  resetTurnFlags(side);
  unitLaneForSide(side).forEach((unit) => { delete unit.cannotHitHeroThisTurn; });
  refreshAllPassiveAuras();
  setPhase('start');
  triggerAbilityEvent(side, 'on_start_turn', { side });
  refreshAllPassiveAuras();
  applyFieldStartEffects(side);
  setPhase('draw');
  if (side === 'player') drawPlayerCards(1, 'turn');
  else drawEnemyCards(1, 'turn');
  setPhase('main1');
}

function getCoreDefense(side = 'player') {
  const base = side === 'player' ? state.playerCoreDef : state.enemyCoreDef;
  return Math.max(0, base);
}

function getEffectiveDefense(target, attackCtx = {}) {
  const pierce = Math.max(0, toNumber(attackCtx.pierce ?? 0));
  const trueDamage = !!attackCtx.trueDamage || String(attackCtx.damageType ?? '').toLowerCase() === 'true';
  const shattered = (target?.statuses?.shatteredTurns ?? 0) > 0;
  const rawDef = trueDamage ? 0 : Math.max(0, (target?.baseDef ?? 0) + ((target?.defense ?? false) ? 2 : 0));
  const currentDef = shattered ? 0 : rawDef;
  return {
    effectiveDef: trueDamage ? 0 : Math.max(0, currentDef - pierce),
    trueDamage,
    shattered,
  };
}

function applyDamageToUnit(target, incomingDamage, attackCtx = {}) {
  ensureCombatFields(target);
  const incoming = Math.max(0, toNumber(incomingDamage));
  const ownerSide = sideOfUnit(target);
  target.statuses = target.statuses ?? {};
  if (incoming > 0 && target.statuses.divineShield) {
    target.statuses.divineShield = false;
    triggerBattleVfx('defense-enter', { targetId: target.id, vfxSpec: { ...VFX_DEFAULTS['defense-enter'], color: '#ffe79a', impactType: 'shield-ring' } });
    return {
      damageTaken: 0,
      blocked: incoming,
      effectiveDef: 999,
      trueDamage: false,
      shattered: false,
      shieldBlocked: true,
    };
  }
  const defenseInfo = getEffectiveDefense(target, attackCtx);
  const taken = Math.max(0, incoming - defenseInfo.effectiveDef);
  if (incoming > 0) {
    target.statuses.damagedThisTurn = true;
    target.statuses.lastDamageAmount = incoming;
    target.statuses.lastDamagedBySpell = !!attackCtx.bySpell || ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(normalizeCardType(attackCtx.sourceCard ?? {}));
    target.statuses.lastDamagedBySide = attackCtx.sourceSide ?? sideOfUnit(attackCtx.attacker) ?? sideOfUnit(attackCtx.sourceCard) ?? null;
    target.statuses.lastDamagedByFamilies = collectCardFamilies(attackCtx.sourceCard ?? attackCtx.attacker ?? {})
      .map((entry) => normalizeFamilyToken(entry))
      .filter(Boolean);
    if (ownerSide) noteTurnFlag(ownerSide, 'minionDamaged', 1);
  }
  target.health -= taken;

  if (!defenseInfo.trueDamage && (attackCtx.breakOnHit ?? true) && target.defense && defenseInfo.effectiveDef > 0) {
    target.defenseDurability = Math.max(0, (target.defenseDurability || 2) - 1);
    if (target.defenseDurability <= 0) {
      target.defense = false;
      target.taunt = !!target.baseTaunt;
      log(`${target.name}'s defense mod broke.`);
    }
  }
  if (ownerSide && taken > 0 && (target.health ?? 0) > 0) {
    triggerUnitAbilityEvent(target, ownerSide, 'on_survive_damage_self', {
      self: target,
      target,
      amount: taken,
      attacker: attackCtx.attacker ?? null,
      sourceCard: attackCtx.sourceCard ?? null,
    });
    triggerAbilityEvent(ownerSide, 'on_survive_damage_any', {
      self: target,
      target,
      amount: taken,
      attacker: attackCtx.attacker ?? null,
      sourceCard: attackCtx.sourceCard ?? null,
    });
    const gainOnSurvive = Math.max(0, toNumber(target.statuses?.surviveDamageGainHealth ?? 0));
    if (gainOnSurvive > 0) {
      target.maxHealth = Math.max(1, toNumber(target.maxHealth ?? target.health, 1) + gainOnSurvive);
      target.health = Math.min(target.maxHealth, toNumber(target.health, 1) + gainOnSurvive);
    }
  }
  refreshAllPassiveAuras();
  return { damageTaken: taken, blocked: Math.max(0, incoming - taken), ...defenseInfo };
}

function applyDamageToCore(side, incomingDamage, attackCtx = {}) {
  const incoming = Math.max(0, toNumber(incomingDamage));
  if (getTurnFlags(side).heroImmune) {
    return {
      damageTaken: 0,
      blocked: incoming,
      effectiveDef: getCoreDefense(side),
      trueDamage: !!attackCtx.trueDamage || String(attackCtx.damageType ?? '').toLowerCase() === 'true',
      immune: true,
    };
  }
  const pierce = Math.max(0, toNumber(attackCtx.pierce ?? 0));
  const trueDamage = !!attackCtx.trueDamage || String(attackCtx.damageType ?? '').toLowerCase() === 'true';
  const rawDef = trueDamage ? 0 : getCoreDefense(side);
  const effectiveDef = trueDamage ? 0 : Math.max(0, rawDef - pierce);
  const damageTaken = Math.max(0, incoming - effectiveDef);
  if (side === 'player') state.playerHealth -= damageTaken;
  else state.enemyHealth -= damageTaken;
  return { damageTaken, blocked: Math.max(0, incoming - damageTaken), effectiveDef, trueDamage };
}

function resolveEndTurnReturns(side = 'player') {
  const lane = unitLaneForSide(side).filter((unit) => (unit?.health ?? 0) > 0 && !!unit?.statuses?.returnToHandEndTurn);
  lane.forEach((unit) => {
    const kept = { ...unit };
    kept.statuses = { ...(kept.statuses ?? {}) };
    delete kept.statuses.returnToHandEndTurn;
    unit.statuses.returnToHandEndTurn = false;
    unit.health = 0;
    addNamedCardToHand(side, kept.name, kept);
    triggerAbilityEvent(side, 'on_return_friendly', { side, returned: unit, self: unit, sourceCard: kept });
  });
}

function tickStatusDurations(minions = [], side = 'player') {
  minions.forEach((minion) => {
    if (!minion?.statuses) return;
    if (toNumber(minion.statuses.sentenceTurns ?? 0) > 0) {
      const hit = applyDamageToUnit(minion, 1, { trueDamage: true, damageType: 'true', breakOnHit: false });
      spawnDamageNumber(document.querySelector(`[data-id="${minion.id}"]`), hit.damageTaken, 'shadow');
    }
    const hadStealth = !!(minion.stealth || minion.statuses?.stealth);
    ['shatteredTurns', 'freezeTurns', 'sleepTurns', 'weakenedTurns', 'timeLockedTurns', 'sentenceTurns', 'stealthTurns', 'untargetableTurns', 'markedTurns'].forEach((key) => {
      if (minion.statuses[key] != null) {
        minion.statuses[key] = Math.max(0, toNumber(minion.statuses[key]) - 1);
        if (minion.statuses[key] <= 0) delete minion.statuses[key];
      }
    });
    delete minion.statuses.damagedThisTurn;
    if (!minion.statuses.weakenedTurns) delete minion.statuses.weakened;
    if (!minion.statuses.timeLockedTurns) delete minion.statuses.timelocked;
    if (!minion.statuses.markedTurns) delete minion.statuses.marked;
    if (!minion.statuses.stealthTurns && minion.statuses?.stealth) {
      minion.statuses.stealth = false;
      minion.stealth = false;
    }
    const hasStealth = !!(minion.stealth || minion.statuses?.stealth);
    if (hadStealth && !hasStealth) {
      triggerAbilityEvent(side, 'on_stealth_loss_friendly', { side, self: minion, target: minion });
    }
  });
}

function shuffle(list = []) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const RUNTIME_DEFAULT_STATS = {
  wins: 0,
  losses: 0,
  packsOpened: 0,
  streak: 0,
  bestStreak: 0,
  battlesPlayed: 0,
  modes: {
    duel: { wins: 0, losses: 0, battles: 0 },
    defense: { wins: 0, losses: 0, battles: 0 },
  },
  threats: {
    pirate: { wins: 0, losses: 0, battles: 0 },
    alien: { wins: 0, losses: 0, battles: 0 },
    boss: { wins: 0, losses: 0, battles: 0 },
    wielder: { wins: 0, losses: 0, battles: 0 },
  },
  factionsFought: {},
  bossesDefeated: 0,
  namedWieldersDefeated: 0,
  worlds: { conquered: 0, lost: 0 },
  planets: { conquered: 0, lost: 0 },
  invasions: { intercepted: 0, piratesEscaped: 0 },
  packs: {
    openedTotal: 0,
    byPack: {},
    cardsByPack: {},
    uniqueByPack: {},
    rarityPulls: { common: 0, rare: 0, epic: 0, legendary: 0 },
    legendaryPulls: 0,
  },
  collectionProgress: { totalCopiesOwned: 0, uniqueOwned: 0 },
  decks: { created: 0, edited: 0 },
  battleHistory: [],
};

function mergeRuntimeStats(raw = {}) {
  return {
    ...RUNTIME_DEFAULT_STATS,
    ...(raw ?? {}),
    modes: {
      duel: { ...RUNTIME_DEFAULT_STATS.modes.duel, ...(raw?.modes?.duel ?? {}) },
      defense: { ...RUNTIME_DEFAULT_STATS.modes.defense, ...(raw?.modes?.defense ?? {}) },
    },
    threats: {
      pirate: { ...RUNTIME_DEFAULT_STATS.threats.pirate, ...(raw?.threats?.pirate ?? {}) },
      alien: { ...RUNTIME_DEFAULT_STATS.threats.alien, ...(raw?.threats?.alien ?? {}) },
      boss: { ...RUNTIME_DEFAULT_STATS.threats.boss, ...(raw?.threats?.boss ?? {}) },
      wielder: { ...RUNTIME_DEFAULT_STATS.threats.wielder, ...(raw?.threats?.wielder ?? {}) },
    },
    factionsFought: { ...(raw?.factionsFought ?? {}) },
    worlds: { ...RUNTIME_DEFAULT_STATS.worlds, ...(raw?.worlds ?? {}) },
    planets: { ...RUNTIME_DEFAULT_STATS.planets, ...(raw?.planets ?? {}) },
    invasions: { ...RUNTIME_DEFAULT_STATS.invasions, ...(raw?.invasions ?? {}) },
    packs: {
      ...RUNTIME_DEFAULT_STATS.packs,
      ...(raw?.packs ?? {}),
      byPack: { ...(raw?.packs?.byPack ?? {}) },
      cardsByPack: { ...(raw?.packs?.cardsByPack ?? {}) },
      uniqueByPack: { ...(raw?.packs?.uniqueByPack ?? {}) },
      rarityPulls: { ...RUNTIME_DEFAULT_STATS.packs.rarityPulls, ...(raw?.packs?.rarityPulls ?? {}) },
    },
    collectionProgress: { ...RUNTIME_DEFAULT_STATS.collectionProgress, ...(raw?.collectionProgress ?? {}) },
    decks: { ...RUNTIME_DEFAULT_STATS.decks, ...(raw?.decks ?? {}) },
    battleHistory: Array.isArray(raw?.battleHistory) ? raw.battleHistory.slice(-80) : [],
  };
}

function updateCollectionProgressStats(profile) {
  const entries = Object.entries(profile.collection ?? {});
  const uniqueOwned = entries.filter(([, count]) => Number(count ?? 0) > 0).length;
  const totalCopiesOwned = entries.reduce((sum, [, count]) => sum + Math.max(0, Number(count ?? 0)), 0);
  profile.stats.collectionProgress.uniqueOwned = uniqueOwned;
  profile.stats.collectionProgress.totalCopiesOwned = totalCopiesOwned;
}

function modeStatsKey() {
  return usingDefenseModel() ? 'defense' : 'duel';
}

function detectThreatType(opponent = null) {
  const fromMeta = String(state.matchContext?.metadata?.threatType ?? '').toLowerCase();
  if (fromMeta === 'pirate' || fromMeta === 'alien') return fromMeta;
  const opId = String(opponent?.id ?? '').toLowerCase();
  if (opId.startsWith('pirate-ai-')) return 'pirate';
  if (opId.startsWith('alien-ai-')) return 'alien';
  return 'wielder';
}

function recordBattleOutcome(result = 'loss', opponent = null) {
  const isWin = result === 'win';
  state.profile.stats = mergeRuntimeStats(state.profile.stats ?? {});
  const stats = state.profile.stats;
  const modeKey = modeStatsKey();
  const threatType = detectThreatType(opponent);
  const isBoss = String(state.matchContext?.metadata?.commanderRank ?? '').toLowerCase() === 'boss'
    || Number(opponent?.level ?? 0) >= 20;
  const rawFactionId = state.matchContext?.metadata?.factionId
    ?? opponent?.faction
    ?? opponent?.personality?.faction
    ?? 'unknown';
  const factionId = String(rawFactionId || 'unknown').trim().toLowerCase().replace(/[^a-z0-9:_-]+/g, '_') || 'unknown';

  stats.battlesPlayed = Math.max(0, Number(stats.battlesPlayed ?? 0)) + 1;
  stats[isWin ? 'wins' : 'losses'] = Math.max(0, Number(stats[isWin ? 'wins' : 'losses'] ?? 0)) + 1;

  stats.modes[modeKey].battles = Math.max(0, Number(stats.modes[modeKey].battles ?? 0)) + 1;
  stats.modes[modeKey][isWin ? 'wins' : 'losses'] = Math.max(0, Number(stats.modes[modeKey][isWin ? 'wins' : 'losses'] ?? 0)) + 1;

  if (stats.threats[threatType]) {
    stats.threats[threatType].battles = Math.max(0, Number(stats.threats[threatType].battles ?? 0)) + 1;
    stats.threats[threatType][isWin ? 'wins' : 'losses'] = Math.max(0, Number(stats.threats[threatType][isWin ? 'wins' : 'losses'] ?? 0)) + 1;
  }

  if (isBoss) {
    stats.threats.boss.battles = Math.max(0, Number(stats.threats.boss.battles ?? 0)) + 1;
    stats.threats.boss[isWin ? 'wins' : 'losses'] = Math.max(0, Number(stats.threats.boss[isWin ? 'wins' : 'losses'] ?? 0)) + 1;
  }

  stats.factionsFought[factionId] = stats.factionsFought[factionId] ?? { wins: 0, losses: 0, battles: 0 };
  stats.factionsFought[factionId].battles = Math.max(0, Number(stats.factionsFought[factionId].battles ?? 0)) + 1;
  stats.factionsFought[factionId][isWin ? 'wins' : 'losses'] = Math.max(
    0,
    Number(stats.factionsFought[factionId][isWin ? 'wins' : 'losses'] ?? 0),
  ) + 1;

  if (isWin && isBoss) {
    stats.bossesDefeated = Math.max(0, Number(stats.bossesDefeated ?? 0)) + 1;
  }
  if (isWin && threatType === 'wielder') {
    stats.namedWieldersDefeated = Math.max(0, Number(stats.namedWieldersDefeated ?? 0)) + 1;
  }

  if (isWin) {
    stats.streak = Math.max(0, Number(stats.streak ?? 0)) + 1;
    stats.bestStreak = Math.max(Number(stats.bestStreak ?? 0), Number(stats.streak ?? 0));
  } else {
    stats.streak = 0;
  }

  const historyEntry = {
    ts: Date.now(),
    result,
    mode: modeKey,
    battleType: state.battleRuleset?.battleType ?? 'unknown',
    threatType,
    opponentId: opponent?.id ?? null,
    opponentName: opponent?.name ?? 'Unknown',
    factionId: state.matchContext?.metadata?.factionId ?? opponent?.faction ?? null,
    worldId: state.battleRuleset?.worldId ?? state.matchContext?.worldId ?? null,
    planetId: state.battleRuleset?.planetId ?? state.matchContext?.planetId ?? null,
  };
  stats.battleHistory = [...(stats.battleHistory ?? []), historyEntry].slice(-80);
}

function ensureProgressFields(profile) {
  profile.stats = mergeRuntimeStats(profile.stats ?? {});
  profile.defeatedAiIds = [...new Set(profile.defeatedAiIds ?? [])];
  profile.lobbyResidents = [...new Set(profile.lobbyResidents ?? [])];
  profile.carnexCodes = profile.carnexCodes ?? {};
  profile.discoveredDimensions = [...new Set(profile.discoveredDimensions ?? [])];
  profile.capturedCards = profile.capturedCards ?? {};
  profile.paywallMode = !!profile.paywallMode;
  profile.economy = profile.economy ?? { gold: 0, lifeforce: 0 };
  profile.economy.lifeforce = profile.economy.lifeforce ?? 0;
  profile.mapWorld = profile.mapWorld && typeof profile.mapWorld === 'object' ? profile.mapWorld : {};
  profile.mapWorld.campaign = profile.mapWorld.campaign && typeof profile.mapWorld.campaign === 'object' ? profile.mapWorld.campaign : {};
  profile.mapWorld.campaign.ownedWorldIds = Array.isArray(profile.mapWorld.campaign.ownedWorldIds) ? profile.mapWorld.campaign.ownedWorldIds : [];
  profile.mapWorld.campaign.lostWorldIds = Array.isArray(profile.mapWorld.campaign.lostWorldIds) ? profile.mapWorld.campaign.lostWorldIds : [];
  profile.mapWorld.campaign.worldStates = profile.mapWorld.campaign.worldStates && typeof profile.mapWorld.campaign.worldStates === 'object'
    ? profile.mapWorld.campaign.worldStates
    : {};
  profile.mapWorld.campaign.speciesAccess = profile.mapWorld.campaign.speciesAccess && typeof profile.mapWorld.campaign.speciesAccess === 'object'
    ? profile.mapWorld.campaign.speciesAccess
    : {};
  updateCollectionProgressStats(profile);
}

function buildUnlockCarnexCode(aiProfile = {}) {
  const dim = String(aiProfile?.personality?.dimensionTag ?? '#Frontier').trim() || '#Frontier';
  const level = Math.max(1, Math.floor(toNumber(aiProfile?.level, 1)));
  const id = String(aiProfile?.id ?? 'unknown-ai').trim() || 'unknown-ai';
  return `${dim}-${level}-${id}`;
}

function applyUnlockAllProgress(profile = state.profile) {
  const target = profile && typeof profile === 'object' ? profile : state.profile;
  ensureProgressFields(target);
  target.devUnlocked = true;
  target.collection = target.collection ?? {};
  target.economy = target.economy ?? { gold: 0, lifeforce: 0 };
  target.economy.pityByProduct = target.economy.pityByProduct ?? {};
  target.questProgress = target.questProgress ?? {};

  const allCards = getAllCards().filter((card) => !!card?.id);
  let cardsUpdated = 0;
  allCards.forEach((card) => {
    const prev = Math.max(0, Number(target.collection[card.id] ?? 0));
    const next = Math.max(prev, 4);
    if (next > prev) cardsUpdated += 1;
    target.collection[card.id] = next;
  });

  const aiPool = Array.isArray(state.aiProfiles) && state.aiProfiles.length
    ? state.aiProfiles
    : (LOCAL_MODE ? (LOCAL_RUNTIME_DATA.aiProfiles ?? []) : registry.list('ai'));
  const aiIds = [];
  const discoveredDimensions = [];
  target.carnexCodes = target.carnexCodes ?? {};
  aiPool.forEach((ai) => {
    const aiId = String(ai?.id ?? '').trim();
    if (!aiId) return;
    aiIds.push(aiId);
    if (!target.carnexCodes[aiId]) target.carnexCodes[aiId] = buildUnlockCarnexCode(ai);
    const dimName = String(ai?.personality?.dimensionTag ?? '')
      .replace(/^#+\s*/, '')
      .trim();
    if (dimName) discoveredDimensions.push(dimName);
  });
  target.defeatedAiIds = [...new Set([...(target.defeatedAiIds ?? []), ...aiIds])];
  target.lobbyResidents = [...new Set([...(target.lobbyResidents ?? []), ...aiIds])];
  target.discoveredDimensions = [...new Set([...(target.discoveredDimensions ?? []), ...discoveredDimensions])];

  target.economy.gold = Math.max(250000, Math.max(0, Number(target.economy.gold ?? 0)));
  target.economy.lifeforce = Math.max(25000, Math.max(0, Number(target.economy.lifeforce ?? 0)));
  target.questProgress.packsOpened = Math.max(999, Math.max(0, Number(target.questProgress.packsOpened ?? 0)));
  target.stats.packsOpened = Math.max(999, Math.max(0, Number(target.stats.packsOpened ?? 0)));
  target.stats.packs.openedTotal = Math.max(999, Math.max(0, Number(target.stats.packs.openedTotal ?? 0)));

  updateCollectionProgressStats(target);
  ensureProgressFields(target);
  return {
    cardsTotal: allCards.length,
    cardsUpdated,
    aiUnlocked: aiIds.length,
    dimensionsUnlocked: discoveredDimensions.length,
  };
}

function expandDeckEntries(entries = [], byId = {}) {
  const cards = [];
  entries.forEach((entry) => {
    const template = byId[entry.cardId];
    if (!template) return;
    const copies = Math.max(0, Number(entry.count) || 0);
    for (let i = 0; i < copies; i += 1) cards.push({ ...template });
  });
  return cards;
}

function buildUniqueAiDeck(profile) {
  const allCards = getAllCards().filter((card) => String(card?.mode ?? '').toLowerCase() !== 'conquest');
  const byId = Object.fromEntries(allCards.map((card) => [card.id, card]));
  const deckMeta = state.decks.find((deck) => deck.id === profile?.deckId);
  const assignedPackIds = new Set((Array.isArray(profile?.assignedPacks) ? profile.assignedPacks : [])
    .map((entry) => String(entry || '').toLowerCase())
    .filter(Boolean));
  const targetDeckSize = Math.max(10, Math.floor(toNumber(
    state.battleRuleset?.threatDeckSize ?? state.battleRuleset?.deckSize,
    30,
  )));

  const fromAssignedPacks = assignedPackIds.size
    ? allCards
      .filter((card) => {
        const packSource = String(card.packSource ?? card.sourcePack ?? card.pack ?? '').toLowerCase();
        const factionId = String(card.factionId ?? card.invasionFaction ?? '').toLowerCase();
        const tags = Array.isArray(card.tags) ? card.tags.map((tag) => String(tag).toLowerCase()) : [];
        return assignedPackIds.has(packSource)
          || assignedPackIds.has(factionId)
          || tags.some((tag) => assignedPackIds.has(tag) || (tag.startsWith('faction:') && assignedPackIds.has(tag.slice(8))));
      })
      .map((card) => ({ ...card }))
    : [];

  const packed = deckMeta?.entries?.length ? expandDeckEntries(deckMeta.entries, byId) : [];
  const profileDeck = (profile.deck ?? profile.summons ?? []).map((card) => ({ ...card }));
  const enriched = enrichAiProfile(profile, [...packed, ...profileDeck, ...fromAssignedPacks]);
  const base = packed.length > 0
    ? packed.map((card) => ({ ...card, deckId: deckMeta.id, deckOwner: profile.id }))
    : (profileDeck.length ? profileDeck : fromAssignedPacks);

  const affinityPool = [...(base.length ? base : allCards)]
    .map((card) => ({ ...card, __aiScore: deckAffinityScore(card, enriched) }))
    .sort((a, b) => b.__aiScore - a.__aiScore);

  const selected = [];
  const counts = new Map();
  for (const entry of affinityPool) {
    if (selected.length >= targetDeckSize) break;
    const key = String(entry.id ?? entry.name ?? `card-${selected.length}`);
    const rarity = String(entry.rarity ?? '').toLowerCase();
    const limit = rarity === 'legendary' ? 1 : 2;
    const current = counts.get(key) ?? 0;
    if (current >= limit) continue;
    selected.push({ ...entry, dimensionOwner: profile.id });
    counts.set(key, current + 1);
  }

  const source = selected.length ? selected : [{ name: 'Wisp', attack: 1, health: 1, race: 'spirit', element: 'arcane' }];
  if (source.length >= targetDeckSize) return shuffle(source).slice(0, targetDeckSize).map(({ __aiScore, ...card }) => card);
  if (deckMeta && source.length > 0) {
    const repeated = [];
    while (repeated.length < targetDeckSize) repeated.push({ ...source[repeated.length % source.length] });
    return shuffle(repeated).map(({ __aiScore, ...card }) => card);
  }

  const epithets = ['Prime', 'Echo', 'Lancer', 'Vanguard', 'Myriad', 'Sentinel', 'Oracle', 'Nova', 'Anchor', 'Aegis'];
  const generated = [];
  for (let i = 0; i < targetDeckSize; i += 1) {
    const t = source[i % source.length];
    const atkShift = (i % 4) - 1;
    const hpShift = ((i + 1) % 5) - 2;
    generated.push({
      ...t,
      name: `${t.name} ${epithets[i % epithets.length]}-${i + 1}`,
      attack: Math.max(1, (t.attack ?? 2) + atkShift),
      health: Math.max(1, (t.health ?? 2) + hpShift),
      def: Math.max(0, toNumber(t.def ?? t.baseDef ?? 0) + ((i % 5 === 0) ? 1 : 0)),
      pierce: Math.max(0, toNumber(t.pierce ?? 0) + ((i % 6 === 0) ? 1 : 0)),
      trueDamage: !!t.trueDamage || i % 13 === 0,
      taunt: !!t.taunt || i % 9 === 0,
      charge: !!t.charge || i % 11 === 0,
      rarity: t.rarity ?? (i % 7 === 0 ? 'legendary' : i % 4 === 0 ? 'epic' : 'rare'),
      dimensionOwner: profile.id,
    });
  }
  return generated;
}

function weightedPick(entries = [], key = 'global') {
  if (!entries.length) return null;
  const safe = entries.map((entry) => (typeof entry === 'string' ? { text: entry, weight: 1 } : { text: entry.text, weight: Math.max(0.2, Number(entry.weight ?? 1)) }));
  const last = state.aiVoiceMemory[key] ?? null;
  const pool = safe.map((entry) => ({ ...entry, weight: entry.text === last ? entry.weight * 0.35 : entry.weight }));
  const total = pool.reduce((sum, entry) => sum + entry.weight, 0);
  let roll = Math.random() * Math.max(0.01, total);
  for (const entry of pool) {
    roll -= entry.weight;
    if (roll <= 0) {
      state.aiVoiceMemory[key] = entry.text;
      return entry.text;
    }
  }
  const fallback = pool[pool.length - 1].text;
  state.aiVoiceMemory[key] = fallback;
  return fallback;
}

function aiBanterLine(profile, category = 'start_turn') {
  const line = buildDialogueLine(profile, category, { last: state.aiVoiceMemory[`${profile.id}:${category}`] ?? null });
  state.aiVoiceMemory[`${profile.id}:${category}`] = line;
  return line;
}

function initEnemyDeck() {
  const profile = currentAiProfile();
  if (!profile) { state.enemyDeck = []; state.enemyHand = []; return; }
  const deck = buildUniqueAiDeck(profile);
  syncAiProfileFromDeck(profile.id, deck);
  state.enemyDeck = shuffle(deck).map((card) => ({ ...card, instanceId: card.instanceId ?? uid('ec') }));
  state.enemyHand = [];
  initializeDeckTracker('enemy', state.enemyDeck, 'deck_entry');
}

function drawEnemySummon(profile, deckIndex = null) {
  if (!state.enemyDeck.length) initEnemyDeck();
  let next = null;
  if (state.enemyDeck.length > 0) {
    const idx = Number.isInteger(deckIndex)
      ? Math.max(0, Math.min(deckIndex, state.enemyDeck.length - 1))
      : 0;
    [next] = state.enemyDeck.splice(idx, 1);
    if (next?.instanceId) setDeckTrackerStatus('enemy', next.instanceId, 'in_hand');
  }
  if (!next) {
    const generated = ensureCombatFields(createSummon(profile));
    generated.instanceId = registerGeneratedDeckCard('enemy', { ...generated, type: 'minion', cost: 0 }, 'generated');
    return generated;
  }
  const nextText = cardText(next).toLowerCase();
  const permanentHeroLock = /can't attack heroes while enemy minions are alive/.test(nextText);
  return ensureCombatFields({
    id: uid('enemy'),
    name: next.name,
    type: 'minion',
    attack: next.attack ?? 2,
    health: next.health ?? 2,
    taunt: !!next.taunt,
    baseTaunt: !!next.taunt,
    baseDef: Math.max(0, toNumber(next.def ?? next.baseDef ?? 0)),
    defense: false,
    defenseDurability: 0,
    race: next.race ?? 'neutral',
    element: next.element ?? 'none',
    statuses: {},
    rarity: next.rarity ?? 'rare',
    pierce: Math.max(0, toNumber(next.pierce ?? 0)),
    trueDamage: !!next.trueDamage,
    allowMultiAttack: !!next.allowMultiAttack,
    allowFriendlyAttack: !!next.allowFriendlyAttack,
    charge: !!next.charge,
    cannotHitHero: !!next.cannotHitHero || permanentHeroLock,
    effect: getCardEffect(next),
    ability: getCardEffect(next),
    text: next.text ?? '',
    tags: next.tags ?? [],
    instanceId: next.instanceId,
  });
}


function getSlotOccupant(minions, slot) {
  return minions.find((m) => {
    if ((m.slot ?? -1) === slot) return true;
    if (m.large && Array.isArray(m.occupiedSlots)) return m.occupiedSlots.includes(slot);
    return false;
  }) ?? null;
}

function slotRow(slot) {
  return Number(slot) >= ROW_SIZE ? 'front' : 'back';
}

function slotLane(slot) {
  return Number(slot) % ROW_SIZE;
}

function slotsForRow(row = 'front') {
  const start = row === 'front' ? ROW_SIZE : 0;
  return Array.from({ length: ROW_SIZE }, (_, i) => start + i);
}

function firstOpenSlot(minions = [], preferredRow = null) {
  const all = preferredRow ? slotsForRow(preferredRow) : Array.from({ length: MAX_SLOTS }, (_, i) => i);
  return all.find((slot) => !getSlotOccupant(minions, slot));
}

function frontRowUnits(minions = []) {
  return minions.filter((m) => slotRow(m.slot ?? 0) === 'front' && (m.health ?? 0) > 0);
}

function backRowUnits(minions = []) {
  return minions.filter((m) => slotRow(m.slot ?? 0) === 'back' && (m.health ?? 0) > 0);
}

function getBarricade(side = 'player', laneIndex = 0) {
  const tray = side === 'player' ? state.playerBarricades : state.enemyBarricades;
  return tray?.[laneIndex] ?? null;
}

function withSideZone(side = 'player', zone = 'field') {
  const isPlayer = side === 'player';
  if (zone === 'field') return isPlayer ? state.playerFields : state.enemyFields;
  if (zone === 'relic') return isPlayer ? state.playerRelics : state.enemyRelics;
  if (zone === 'graveyard') return isPlayer ? state.playerGraveyard : state.enemyGraveyard;
  if (zone === 'exile') return isPlayer ? state.playerExile : state.enemyExile;
  return [];
}

function pushToZone(side = 'player', zone = 'graveyard', card = null) {
  if (!card) return;
  const tray = withSideZone(side, zone);
  tray.unshift({
    id: card.id ?? card.instanceId ?? uid('zone'),
    name: card.name ?? 'Unknown',
    type: card.type ?? 'minion',
    cost: toNumber(card.cost, 0),
    attack: toNumber(card.attack, 0),
    health: toNumber(card.health ?? card.maxHealth, 0),
    def: Math.max(0, toNumber(card.baseDef ?? card.def, 0)),
    text: card.text ?? '',
    race: extractCardRaces(card)[0] ?? card.race ?? null,
    races: extractCardRaces(card),
    element: card.element ?? null,
    tags: Array.isArray(card.tags) ? [...card.tags] : [],
    keywords: Array.isArray(card.keywords) ? [...card.keywords] : [],
    rarity: card.rarity ?? 'common',
    packSource: card.packSource ?? card.pack ?? null,
    faction: card.faction ?? null,
    at: Date.now(),
  });
}

function setPhase(nextPhase = 'main1') {
  if (!PHASE_ORDER.includes(nextPhase)) return;
  state.phase = nextPhase;
}

function isMainPhase() {
  return state.phase === 'main1' || state.phase === 'main2';
}

function isResponsePhase() {
  return state.phase === 'response' || state.phase === 'declare_blockers' || state.phase === 'combat';
}

function pushStackEntry(entry = {}) {
  state.stack.push({ id: uid('stack'), ts: Date.now(), ...entry });
  render();
}

function resolveStack() {
  while (state.stack.length) {
    const entry = state.stack.pop();
    if (typeof entry.resolve === 'function') {
      try { entry.resolve(); } catch (err) { log(`Stack resolve error: ${err.message}`); }
    }
  }
}

function sideInfo(side = 'player') {
  const isPlayer = side === 'player';
  return {
    side,
    isPlayer,
    lane: isPlayer ? state.playerMinions : state.enemyMinions,
    enemyLane: isPlayer ? state.enemyMinions : state.playerMinions,
    usedAttacks: isPlayer ? state.usedAttacks : state.enemyUsedAttacks,
    heroTargetId: isPlayer ? 'enemy-hero' : 'player-hero',
    ownBarricades: isPlayer ? state.playerBarricades : state.enemyBarricades,
    enemyBarricades: isPlayer ? state.enemyBarricades : state.playerBarricades,
  };
}

function stanceLabel(minion = null, isEnemy = false) {
  if (!minion) return 'Unknown';
  if (minion.statuses?.timelocked || minion.statuses?.timeLockedTurns > 0) return 'Time-Locked';
  if (minion.statuses?.sleepTurns || minion.statuses?.freezeTurns) return 'Stunned';
  if (minion.defense) return `Defense Stance (Guard ${minion.defenseDurability || 0})`;
  if (minion.taunt) return isEnemy ? 'Guarding (Enemy)' : 'Guarding';
  return 'Attack Stance';
}

function explainAttackFailure(code, extra = {}) {
  const map = {
    not_turn: 'Not your turn. End enemy turn first.',
    no_attacker: 'Select a valid attacker first.',
    attacker_dead: 'This unit is no longer on board.',
    in_defense: explainInvalidAction('defense'),
    summoning_sickness: 'Summoning sickness: this unit cannot attack this turn.',
    already_attacked: 'This unit already attacked this turn.',
    no_legal_targets: 'No legal targets available for this unit.',
    invalid_target: 'That target is invalid for this attack.',
    taunt_gate: explainInvalidAction('taunt'),
    target_hidden: 'Target is hidden or untargetable right now.',
    cannot_hit_hero: 'This unit cannot attack heroes.',
    blocked_frontline: 'You must clear enemy board before hitting hero.',
    action_locked: 'Unit is time-locked/stunned and cannot attack.',
    barricade_block: 'A barricade is blocking this lane.',
  };
  if (code === 'target_missing' && extra?.targetId) return `Target not found: ${extra.targetId}.`;
  return map[code] ?? explainInvalidAction('invalid');
}

function validateAttack(side = 'player', attackerId, targetId) {
  const info = sideInfo(side);
  if (state.matchResolved) return { ok: false, code: 'action_locked', message: explainAttackFailure('action_locked') };
  if (state.currentTurn !== side) return { ok: false, code: 'not_turn', message: explainAttackFailure('not_turn') };
  if (!['declare_attackers', 'response', 'declare_blockers', 'combat', 'main2', 'main1'].includes(state.phase)) {
    return { ok: false, code: 'invalid_target', message: 'You can only attack during combat-capable phases.' };
  }

  const attacker = ensureCombatFields(info.lane.find((m) => m.id === attackerId));
  if (!attacker) return { ok: false, code: 'no_attacker', message: explainAttackFailure('no_attacker') };
  if ((attacker.health ?? 0) <= 0) return { ok: false, code: 'attacker_dead', message: explainAttackFailure('attacker_dead') };
  if (attacker.defense) return { ok: false, code: 'in_defense', message: explainAttackFailure('in_defense') };
  if (attacker.statuses?.sleepTurns || attacker.statuses?.freezeTurns || attacker.statuses?.timelocked || attacker.statuses?.timeLockedTurns > 0) {
    return { ok: false, code: 'action_locked', message: explainAttackFailure('action_locked') };
  }
  if (attacker.summoningSick) return { ok: false, code: 'summoning_sickness', message: explainAttackFailure('summoning_sickness') };

  const cap = attacker.allowMultiAttack ? 99 : 1;
  const used = info.usedAttacks[attacker.id] ?? 0;
  if (used >= cap) return { ok: false, code: 'already_attacked', message: explainAttackFailure('already_attacked') };

  const liveEnemy = info.enemyLane.filter((m) => (m.health ?? 0) > 0).map(ensureCombatFields);
  const enemyFront = frontRowUnits(liveEnemy);
  const enemyBack = backRowUnits(liveEnemy);
  const taunts = liveEnemy.filter((m) => !!m.taunt);
  const attackerLane = slotLane(attacker.slot ?? 0);
  const laneBarricade = getBarricade(side === 'player' ? 'enemy' : 'player', attackerLane);
  if (laneBarricade && (laneBarricade.health ?? 0) > 0 && !attacker.siege && !attacker.piercing) {
    if (!targetId || targetId !== laneBarricade.id) {
      return {
        ok: false,
        code: 'invalid_target',
        message: `${laneBarricade.name} blocks lane ${attackerLane + 1}. Break the barricade first or use Siege/Piercing.`,
      };
    }
  }
  if (!targetId) {
    const legalExists = liveEnemy.length > 0 || (taunts.length === 0 && !attacker.cannotHitHero);
    return legalExists
      ? { ok: false, code: 'invalid_target', message: explainAttackFailure('invalid_target') }
      : { ok: false, code: 'no_legal_targets', message: explainAttackFailure('no_legal_targets') };
  }

  if (laneBarricade && targetId === laneBarricade.id) {
    return { ok: true, attacker, target: laneBarricade, targetType: 'barricade' };
  }

  if (targetId === info.heroTargetId) {
    if (attacker.cannotHitHeroThisTurn) return { ok: false, code: 'cannot_hit_hero', message: explainAttackFailure('cannot_hit_hero') };
    if (attacker.cannotHitHero && liveEnemy.length > 0) return { ok: false, code: 'cannot_hit_hero', message: explainAttackFailure('cannot_hit_hero') };
    if (taunts.length > 0) return { ok: false, code: 'taunt_gate', message: explainAttackFailure('taunt_gate') };
    if (enemyFront.length > 0) return { ok: false, code: 'blocked_frontline', message: explainAttackFailure('blocked_frontline') };
    if ((state.phase === 'main1' || state.phase === 'main2') && !attacker.haste) {
      setPhase('declare_attackers');
    }
    return { ok: true, attacker, target: null, targetType: 'hero' };
  }

  let target = liveEnemy.find((m) => m.id === targetId) ?? null;
  if (!target && attacker.allowFriendlyAttack) target = info.lane.find((m) => m.id === targetId) ?? null;
  if (!target) return { ok: false, code: 'target_missing', message: explainAttackFailure('target_missing', { targetId }) };
  if (target.statuses?.hidden || target.statuses?.stealth) return { ok: false, code: 'target_hidden', message: explainAttackFailure('target_hidden') };
  if (taunts.length > 0 && !target.taunt && info.enemyLane.some((m) => m.id === target.id)) return { ok: false, code: 'taunt_gate', message: explainAttackFailure('taunt_gate') };
  if (!attacker.allowFriendlyAttack && info.lane.some((m) => m.id === target.id)) return { ok: false, code: 'invalid_target', message: explainAttackFailure('invalid_target') };
  const targetRow = slotRow(target.slot ?? 0);
  if (targetRow === 'back' && enemyFront.length > 0 && !attacker.flying && !attacker.siege && !attacker.piercing && !attacker.reach) {
    return {
      ok: false,
      code: 'invalid_target',
      message: `Back row is protected while enemy front row holds. Clear front row or use Flying/Siege/Piercing/Reach.`,
    };
  }
  if ((state.phase === 'main1' || state.phase === 'main2') && !attacker.haste) {
    setPhase('declare_attackers');
  }
  return { ok: true, attacker, target, targetType: 'minion' };
}

function legalAttackTargetIds(side = 'player', attackerId = null) {
  const info = sideInfo(side);
  const attacker = info.lane.find((m) => m.id === attackerId);
  if (!attacker) return [];
  const ids = [];
  const laneBarrier = getBarricade(side === 'player' ? 'enemy' : 'player', slotLane(attacker.slot ?? 0));
  if (laneBarrier && (laneBarrier.health ?? 0) > 0) {
    const checkBarrier = validateAttack(side, attackerId, laneBarrier.id);
    if (checkBarrier.ok) return [laneBarrier.id];
  }
  info.enemyLane.forEach((enemy) => {
    const result = validateAttack(side, attackerId, enemy.id);
    if (result.ok) ids.push(enemy.id);
  });
  const heroResult = validateAttack(side, attackerId, info.heroTargetId);
  if (heroResult.ok) ids.push(info.heroTargetId);
  if (attacker.allowFriendlyAttack) {
    info.lane.forEach((ally) => {
      if (ally.id === attackerId) return;
      const result = validateAttack(side, attackerId, ally.id);
      if (result.ok) ids.push(ally.id);
    });
  }
  return ids;
}

function auraAttackBonus(unit = null, side = 'player') {
  if (!unit) return 0;
  const lane = unitLaneForSide(side).filter((entry) => (entry?.health ?? 0) > 0);
  let bonus = 0;
  lane.forEach((source) => {
    const text = normalizeAbilityText(source?.text ?? '').toLowerCase();
    if (!text) return;
    const matchFamily = text.match(/your\s+([a-z-]+)s?\s+have\s+\+(\d+)\s+attack/);
    if (matchFamily && cardMatchesFamily(unit, matchFamily[1])) {
      if (text.includes('other') && source.id === unit.id) return;
      bonus += Number(matchFamily[2] ?? 0);
    }
    const matchOther = text.match(/other\s+friendly\s+minions\s+have\s+\+(\d+)\s+attack/);
    if (matchOther && source.id !== unit.id) bonus += Number(matchOther[1] ?? 0);
    const matchAll = text.match(/friendly\s+minions\s+have\s+\+(\d+)\s+attack/);
    if (matchAll && !text.includes('other')) bonus += Number(matchAll[1] ?? 0);
  });
  return bonus;
}

function conditionalAttackBonus(unit = null, side = 'player', target = null) {
  if (!unit) return 0;
  const text = normalizeAbilityText(unit?.text ?? '').toLowerCase();
  if (!text) return 0;
  let bonus = 0;
  const damagedAttack = text.match(/has\s+\+(\d+)\s+attack\s+while\s+attacking\s+damaged\s+enemies?/);
  if (damagedAttack && target && (target.health ?? 0) < (target.maxHealth ?? target.health ?? 0)) {
    bonus += Number(damagedAttack[1] ?? 0);
  }
  const whileStealthed = text.match(/has\s+\+(\d+)\s+attack\s+while\s+stealthed/);
  if (whileStealthed && (unit.stealth || unit.statuses?.stealth)) bonus += Number(whileStealthed[1] ?? 0);
  const relicOrShip = text.match(/has\s+\+(\d+)\s+attack\s+while\s+you\s+control\s+a\s+relic\s+or\s+ship/);
  if (relicOrShip && (withSideZone(side, 'relic').length > 0 || boardHas(side, (entry) => hasRaceOrTag(entry, 'ship')))) {
    bonus += Number(relicOrShip[1] ?? 0);
  }
  const healedMinion = text.match(/gains?\s+\+(\d+)\s+attack\s+while\s+you\s+control\s+a\s+healed\s+minion/);
  if (healedMinion && damagedMinions(side).length > 0) bonus += Number(healedMinion[1] ?? 0);
  if (target?.statuses?.markedBonusDamage) bonus += Math.max(0, toNumber(target.statuses.markedBonusDamage, 0));
  return bonus;
}

function currentAttackValue(unit = null, side = 'player', target = null) {
  if (!unit) return 0;
  refreshAuraStateForUnit(side, unit);
  const weakened = unit?.statuses?.weakened ? 1 : 0;
  const base = Math.max(0, toNumber(unit.attack, 0) - weakened);
  return Math.max(0, base + Math.max(0, toNumber(unit?.statuses?.auraAttackBonus ?? 0, 0)) + auraAttackBonus(unit, side) + conditionalAttackBonus(unit, side, target));
}

function consumeMarkedAttackBonus(target = null) {
  if (!target?.statuses) return;
  if (target.statuses.markedBonusDamage) delete target.statuses.markedBonusDamage;
}

function emitKillAndOverkillEvents(side = 'player', attacker = null, victim = null, damageDealt = 0, victimHealthBefore = 0) {
  if (!attacker || !victim) return;
  const overkillDamage = Math.max(0, toNumber(damageDealt, 0) - Math.max(0, toNumber(victimHealthBefore, 0)));
  const runtime = {
    side,
    self: attacker,
    attacker,
    target: victim,
    deadUnit: victim,
    sourceCard: attacker,
    damageDealt: Math.max(0, toNumber(damageDealt, 0)),
    overkillDamage,
  };
  triggerUnitAbilityEvent(attacker, side, 'on_kill_self', runtime);
  triggerAbilityEvent(side, 'on_kill_any', runtime);
  if (overkillDamage > 0) {
    triggerUnitAbilityEvent(attacker, side, 'on_overkill_self', runtime);
    triggerAbilityEvent(side, 'on_overkill_any', runtime);
  }
}

function chooseAutoBlocker(attacker, defendingLane = [], requestedTarget = null) {
  const front = frontRowUnits(defendingLane).map(ensureCombatFields);
  if (!front.length) return null;
  const targetRow = requestedTarget ? slotRow(requestedTarget.slot ?? 0) : 'hero';
  if (targetRow === 'front') return null;
  const guards = front.filter((unit) => !!unit.taunt || !!unit.defense || !!unit.guard);
  if (guards.length) {
    return guards.sort((a, b) => ((b.health ?? 0) + (b.baseDef ?? 0)) - ((a.health ?? 0) + (a.baseDef ?? 0)))[0];
  }
  const lane = slotLane(attacker.slot ?? 0);
  const laneBlock = front.find((unit) => slotLane(unit.slot ?? 0) === lane);
  return laneBlock ?? front.sort((a, b) => (b.health ?? 0) - (a.health ?? 0))[0];
}

function cancelSelections() {
  state.selectedAttackerId = null;
  state.selectedCardId = null;
  state.selectedSpellTargetMode = false;
  clearHighlights();
  showHint('');
}

function resetAttackUsageFor(side = 'player') {
  if (side === 'player') state.usedAttacks = {};
  else state.enemyUsedAttacks = {};
}


function setBar(id, value, max) {
  const pct = Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100));
  const bar = document.querySelector(id);
  if (bar) bar.style.width = `${pct}%`;
}

function applyThemeAndSettings(opponentThemeId = null) {
  const board = document.querySelector('#board');
  const backdrop = state.backdrops.find((item) => item.id === state.profile.settings.selectedBackdrop) ?? state.backdrops[0];
  if (backdrop?.css) board.style.background = backdrop.css;
  board.style.backgroundSize = 'cover';
  board.style.backgroundPosition = 'center';
  const theme = state.themes.find((item) => item.id === opponentThemeId)
    ?? state.themes.find((item) => item.id === state.profile.settings.selectedTheme)
    ?? state.themes[0];
  if (theme) {
    document.body.style.background = theme.appBg;
    document.querySelectorAll('.panel').forEach((panel) => { panel.style.background = theme.panelBg; });
    document.documentElement.style.setProperty('--accent', theme.accent);
    if (theme.hpStart) document.documentElement.style.setProperty('--hp-start', theme.hpStart);
    if (theme.hpEnd) document.documentElement.style.setProperty('--hp-end', theme.hpEnd);
    if (theme.cardGlow) document.documentElement.style.setProperty('--card-glow', theme.cardGlow);
    if (theme.heroFrame) document.documentElement.style.setProperty('--hero-frame', theme.heroFrame);
  }
  const app = document.querySelector('#app');
  if (app) {
    app.style.transform = `scale(${state.profile.settings.uiScale})`;
    app.style.transformOrigin = 'top center';
  }
  document.body.classList.toggle('high-contrast', !!state.profile.settings.highContrast);
  document.body.classList.toggle('reduce-motion', !!state.profile.settings.reduceMotion);
}

function cardPresentationApi() {
  return window.CardForgeCardPresentation ?? null;
}

function currentCardPresentationSettings() {
  const api = cardPresentationApi();
  const raw = state.profile?.settings?.cardPresentation ?? {};
  const merged = api?.mergeSettings ? api.mergeSettings(raw) : raw;
  state.profile.settings = state.profile.settings ?? {};
  state.profile.settings.cardPresentation = merged;
  return merged;
}

function resetCardPresentationTransientState() {
  state.handPresentation = {
    hoveredCardId: null,
    pinnedCardId: null,
    pointerTilt: { cardId: null, x: 0, y: 0 },
  };
  if (state.localPlayer?.handPresentation) {
    state.localPlayer.handPresentation = {
      hoveredCardId: null,
      pinnedCardId: null,
      pointerTilt: { cardId: null, x: 0, y: 0 },
    };
  }
}

function saveCardPresentationSettings(nextSettings, options = {}) {
  const api = cardPresentationApi();
  const merged = api?.mergeSettings ? api.mergeSettings(nextSettings) : nextSettings;
  state.profile.settings = state.profile.settings ?? {};
  state.profile.settings.cardPresentation = merged;
  persistProfile();
  if (!options.skipModalRender) renderCardUiSettingsModal();
  if (!options.skipRender) {
    if (state.localPlayer?.match && state.localPlayer.activeScreen === 'battle') renderBattle();
    else render();
  }
}

function cardUiSettingsControlsMarkup() {
  const api = cardPresentationApi();
  return api?.settingsControlsMarkup ? api.settingsControlsMarkup(currentCardPresentationSettings()) : '<div class="meta">Card UI settings unavailable.</div>';
}

function renderCardUiSettingsModal() {
  const controls = document.querySelector('#card-ui-settings-controls');
  if (!controls) return;
  controls.innerHTML = cardUiSettingsControlsMarkup();
}

function openCardUiSettingsModal() {
  renderCardUiSettingsModal();
  document.querySelector('#card-ui-settings-modal')?.classList.remove('hidden');
}

function closeCardUiSettingsModal() {
  document.querySelector('#card-ui-settings-modal')?.classList.add('hidden');
}

function bindCardUiSettingsControls(root = document) {
  const modal = root.querySelector('#card-ui-settings-modal');
  if (!(modal instanceof HTMLElement) || modal.dataset.bound === '1') return;
  modal.dataset.bound = '1';
  modal.addEventListener('input', (event) => {
    const target = event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement ? event.target : null;
    const field = String(target?.dataset?.cardUiField ?? '');
    if (!field) return;
    const api = cardPresentationApi();
    const next = {
      ...currentCardPresentationSettings(),
      [field]: api?.parseFieldValue ? api.parseFieldValue(field, target) : target.value,
    };
    if (field === 'presetId' && api?.applyPreset) {
      saveCardPresentationSettings(api.applyPreset(next, String(next.presetId)), { skipModalRender: false });
      return;
    }
    saveCardPresentationSettings(next, { skipModalRender: false });
  });
  modal.addEventListener('click', (event) => {
    const target = event.target instanceof HTMLElement ? event.target : null;
    if (!target) return;
    if (target.id === 'card-ui-settings-close-btn' || target === modal) {
      closeCardUiSettingsModal();
      return;
    }
    if (target.id === 'card-ui-settings-reset-btn') {
      const api = cardPresentationApi();
      const defaults = api?.DEFAULTS ? api.mergeSettings(api.DEFAULTS) : {};
      saveCardPresentationSettings(defaults, { skipModalRender: false });
      return;
    }
    const qualityId = String(target.dataset.cardUiQuality ?? '');
    if (qualityId) {
      const api = cardPresentationApi();
      const next = api?.applyMotionPreset
        ? api.applyMotionPreset(currentCardPresentationSettings(), qualityId)
        : currentCardPresentationSettings();
      saveCardPresentationSettings(next, { skipModalRender: false });
    }
  });
}

function runtimeCardCanCast(shownCost = 0) {
  return Number(shownCost ?? 0) <= Number(state.mana ?? 0);
}

function runtimeHandMarkup(card = {}, shownCost = 0) {
  const api = cardPresentationApi();
  const escape = api?.escapeHtml ?? ((value) => String(value ?? ''));
  const keywords = [];
  if (card.taunt) keywords.push('Guard');
  if (card.pierce) keywords.push(`Pierce ${card.pierce}`);
  if (card.trueDamage) keywords.push('True');
  const cardRules = cardRulesInBattleTerms(card);
  const battleLine = cardRules.find((line) => line.startsWith('Cast:') || line.startsWith('On Play:')) ?? cardRules[0] ?? 'No battle text.';
  const canCast = runtimeCardCanCast(shownCost);
  const families = `${renderFamilyBadges(card)}<span class="family-label">${familySummary(card)}</span>`;
  const tags = keywords.length
    ? keywords.map((tag) => `<span class="cf-hand-card-chip">${escape(tag)}</span>`).join('')
    : `<span class="cf-hand-card-chip">${escape(card.type ?? 'Card')}</span>`;
  const attack = Number.isFinite(card.attack) ? card.attack : '—';
  const defense = Number.isFinite(card.def ?? card.baseDef) ? (card.def ?? card.baseDef) : '—';
  const health = Number.isFinite(card.health) ? card.health : '—';
  return `
    <div class="cf-hand-card-face">
      <div class="cf-hand-card-header">
        <div class="cf-hand-card-title">
          <div class="cf-hand-card-name">${escape(card.name ?? 'Card')}</div>
          <div class="cf-hand-card-type">${escape(card.type ?? 'Card')} • ${escape(String(card.rarity ?? 'common').toUpperCase())}</div>
        </div>
        <div class="cf-hand-card-cost ${canCast ? 'is-castable' : 'is-expensive'}">${escape(shownCost)}</div>
      </div>
      <div class="cf-hand-card-topline">
        <span class="cf-hand-card-cost-note">${shownCost !== toNumber(card.cost, 0) ? `Base ${toNumber(card.cost, 0)}` : 'Ready Cost'}</span>
      </div>
      <div class="cf-hand-card-art">
        <span class="cf-hand-card-art-label">${escape(familySummary(card))}</span>
        <span class="cf-hand-card-art-role">${escape(String(card.element ?? card.role ?? 'neutral').toUpperCase())}</span>
      </div>
      <div class="cf-hand-card-tags">${tags}${families}</div>
      <div class="cf-hand-card-stats">
        <span><strong>${attack}</strong>ATK</span>
        <span><strong>${defense}</strong>DEF</span>
        <span><strong>${health}</strong>HP</span>
      </div>
      <div class="cf-hand-card-text">${escape(battleLine)}</div>
      <div class="cf-hand-card-footer">
        <span>${escape(familiaritySummary('player', card))}</span>
        <span class="cf-hand-card-debug"></span>
      </div>
    </div>`;
}

function syncRuntimeHandPresentation(handHost, cards = []) {
  const api = cardPresentationApi();
  if (!api?.syncHandLayout || !(handHost instanceof HTMLElement)) return;
  handHost.classList.add('cf-hand-presenter');
  const settings = currentCardPresentationSettings();
  const ribbonOpacity = typeof api.ribbonOpacityForMode === 'function'
    ? api.ribbonOpacityForMode(settings, 'duel')
    : Number(settings.ribbonOpacityDuel ?? 0);
  handHost.style.setProperty('--cf-hand-ribbon-opacity', String(ribbonOpacity));
  api.syncHandLayout(
    handHost,
    cards,
    settings,
    {
      hoveredCardId: state.handPresentation?.hoveredCardId ?? null,
      selectedCardId: state.selectedCardId ?? null,
      pinnedCardId: state.handPresentation?.pinnedCardId ?? null,
      pointerTilt: state.handPresentation?.pointerTilt ?? { cardId: null, x: 0, y: 0 },
    },
    {
      getId: (card) => card.instanceId,
      baseWidth: 214,
      baseHeight: 304,
    },
  );
}

function queueEnemyTurnStart() {
  if (state.aiTurnQueued || state.aiThinking || state.matchResolved) return;
  const profile = currentAiProfile();
  if (!state.aiPlannerWarm.ready || state.aiPlannerWarm.profileId !== (profile?.id ?? null)) {
    scheduleAiWarmup({ immediate: true });
  }
  state.aiTurnQueued = true;
  state.devMetrics.aiPhase = state.aiPlannerWarm.ready ? 'queue enemy turn' : 'warm enemy planner';
  renderPanels();
  requestAnimationFrame(() => {
    setTimeout(() => {
      state.aiTurnQueued = false;
      runEnemyTurn();
    }, state.aiPlannerWarm.ready ? 0 : 48);
  });
}

function scheduleAiWarmup(options = {}) {
  const immediate = !!options.immediate;
  const profile = currentAiProfile();
  if (!profile || state.localPlayer?.match) return;
  if (state.aiPlannerWarm.profileId && state.aiPlannerWarm.profileId !== (profile.id ?? null)) {
    state.aiPlannerWarm.ready = false;
    state.aiPlannerWarm.queued = false;
    state.aiPlannerWarm.profileId = null;
  }
  if (state.aiPlannerWarm.queued || state.aiPlannerWarm.ready) return;
  state.aiPlannerWarm.queued = true;
  const warm = () => {
    try {
      primeNeuralPlanner({
        enemyHealth: state.enemyHealth,
        playerHealth: state.playerHealth,
        enemyMinions: state.enemyMinions,
        playerMinions: state.playerMinions,
        enemyDeck: state.enemyDeck,
        enemyHand: state.enemyHand,
        enemyFields: state.enemyFields,
        enemyRelics: state.enemyRelics,
        enemyBarricades: state.enemyBarricades,
        enemyMana: Math.max(0, toNumber(state.enemyMana ?? state.maxMana ?? 0)),
        enemyUsedAttacks: state.enemyUsedAttacks,
        playerUsedAttacks: state.playerUsedAttacks,
        familiarity: state.familiarity,
        turnFlags: state.turnFlags,
        maxMana: state.maxMana,
        turn: state.turn,
      }, profile);
      state.aiPlannerWarm.ready = true;
      state.aiPlannerWarm.profileId = profile.id ?? null;
      state.devMetrics.aiPhase = 'planner warmed';
    } catch (error) {
      console.warn('[runtime] AI warmup failed.', error);
    } finally {
      state.aiPlannerWarm.queued = false;
    }
  };
  if (immediate) {
    window.setTimeout(warm, 24);
    return;
  }
  if (typeof window.requestIdleCallback === 'function') window.requestIdleCallback(warm, { timeout: 240 });
  else window.setTimeout(warm, 120);
}

function bumpQuestMetric(metric, amount = 1, persist = true) {
  state.profile.questProgress[metric] = (state.profile.questProgress[metric] ?? 0) + amount;
  if (persist) persistProfile();
}

function queueMatchResult(result = 'loss', opponent = null) {
  const payload = {
    ts: Date.now(),
    result,
    opponentId: opponent?.id ?? null,
    opponentName: opponent?.name ?? 'Unknown',
    opponentLevel: Number(opponent?.level ?? 1),
    worldId: state.matchContext?.worldId ?? null,
    planetId: state.matchContext?.planetId ?? null,
    objectiveId: state.matchContext?.objectiveId ?? null,
    threatId: state.matchContext?.threatId ?? null,
    battleType: state.battleRuleset?.battleType ?? null,
    modeModel: state.battleRuleset?.modeModel ?? null,
    metadata: state.matchContext?.metadata ?? {},
  };
  localStorage.setItem(MATCH_RESULT_KEY, JSON.stringify(payload));
}

function battleDifficultyBonus(opponent = null) {
  const level = Math.max(1, Number(opponent?.level ?? 1));
  const stars = Math.max(1, Number(state.matchContext?.aiSkillStars ?? Math.ceil(level / 8)));
  const tech = Math.max(1, Number(state.matchContext?.techLevel ?? 1));
  const deckSize = Math.max(20, Number(state.matchContext?.threatDeckSize ?? state.matchContext?.deckSize ?? state.battleRuleset?.threatDeckSize ?? 30));
  const isDefense = String(state.battleRuleset?.modeModel ?? '').toLowerCase() === 'defense';
  const threatType = String(state.matchContext?.metadata?.threatType ?? '').toLowerCase();
  const base = Math.floor(level * 5.5) + (stars * 8) + Math.floor((tech - 1) * 6) + Math.floor(Math.max(0, deckSize - 30) * 0.9);
  const threatBonus = threatType === 'alien' ? 24 : threatType === 'pirate' ? 18 : 0;
  const modeBonus = isDefense ? 20 : 0;
  return Math.max(20, base + threatBonus + modeBonus);
}

function calculateBattleWinGold(opponent = null) {
  const base = getWinReward(Math.max(0, Number(state.profile.stats?.streak ?? 0)));
  return Math.max(80, base + battleDifficultyBonus(opponent));
}

function bumpBattleOutcomeQuestMetrics(result = 'loss') {
  bumpQuestMetric('battlesPlayed', 1, false);
  if (result === 'win') bumpQuestMetric('wins', 1, false);
  else bumpQuestMetric('losses', 1, false);
}

function compatibilityScore(card, deck) {
  if (!deck) return 0;
  const byId = Object.fromEntries(getAllCards().map((entry) => [entry.id, entry]));
  const deckCards = deck.entries.flatMap((entry) => Array.from({ length: entry.count }, () => byId[entry.cardId])).filter(Boolean);
  const families = new Set(deckCards.flatMap((item) => collectCardFamilies(item)));
  const elements = new Set(deckCards.map((item) => item.element).filter(Boolean));
  let score = 0;
  collectCardFamilies(card).forEach((family) => {
    if (families.has(family)) score += 2;
  });
  if (card.element && elements.has(card.element)) score += 2;
  if (card.synergy?.some((tag) => families.has(normalizeFamilyToken(tag)) || elements.has(tag))) score += 2;
  if (card.type === 'spell' && deckCards.some((item) => item.type === 'minion')) score += 1;
  return score;
}

function claimDailyGift() {
  const today = new Date().toDateString();
  if (state.profile.economy.lastDailyGiftAt === today) return;
  state.profile.economy.lastDailyGiftAt = today;
  state.profile.economy.gold += 75;
  persistProfile();
  toast('Daily gift claimed (+75g).', 'info');
  renderPanels();
  document.querySelector('#boot-loading')?.classList.add('hidden');
  document.querySelector('#app')?.classList.remove('hidden');
}


function claimDemoWin() {
  ensureProgressFields(state.profile);
  const reward = getWinReward(state.profile.stats.streak);
  recordBattleOutcome('win', currentAiProfile());
  state.profile.economy.gold += reward;
  persistProfile();
  toast(`Win reward claimed (+${reward}g).`, 'info');
  renderPanels();
  document.querySelector('#boot-loading')?.classList.add('hidden');
  document.querySelector('#app')?.classList.remove('hidden');
}


function performEnemyAttack(attackerId, targetId) {
  let validation = validateAttack('enemy', attackerId, targetId === 'player-hero' ? 'player-hero' : targetId);
  if (!validation.ok) {
    const attacker = state.enemyMinions.find((m) => m.id === attackerId);
    const lane = slotLane(attacker?.slot ?? -1);
    const barrier = lane >= 0 ? state.playerBarricades[lane] : null;
    if (barrier && (barrier.health ?? 0) > 0) {
      const fallback = validateAttack('enemy', attackerId, barrier.id);
      if (fallback.ok) validation = fallback;
    }
  }
  if (!validation.ok) {
    if (state.devModeEnabled) log(`Enemy attack skipped: ${validation.message}`);
    return false;
  }
  const attacker = validation.attacker;
  noteTurnFlag('enemy', 'attacked', 1);
  triggerUnitAbilityEvent(attacker, 'enemy', 'on_attack_self', { side: 'enemy', self: attacker, target: validation.target ?? null });
  triggerAbilityEvent('enemy', 'on_attack_any', { side: 'enemy', self: attacker, target: validation.target ?? null });
  consumeStealthOnAttack('enemy', attacker);
  const attackerEl = document.querySelector(`[data-id="${attacker.id}"]`);
  const used = state.enemyUsedAttacks[attacker.id] ?? 0;
  let scoredKill = false;
  let directKillVictim = null;
  let directKillDamage = 0;
  let directKillHealthBefore = 0;
  if (validation.targetType === 'barricade') {
    const barricade = validation.target;
    const lane = slotLane(attacker.slot ?? 0);
    if (barricade) {
      const barricadeHealthBefore = Math.max(0, toNumber(barricade.health, 0));
      const atkValue = currentAttackValue(attacker, 'enemy', barricade);
      const taken = Math.max(0, atkValue - Math.max(0, barricade.def ?? 0));
      barricade.health -= taken;
      state.enemyUsedAttacks[attacker.id] = used + 1;
      triggerBattleVfx('attack', { attackerId: attacker.id, targetId: barricade.id, fromEl: attackerEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
      if (barricade.health <= 0) {
        state.playerBarricades[lane] = null;
        pushToZone('player', 'graveyard', barricade);
        scoredKill = true;
      }
      if (scoredKill) emitKillAndOverkillEvents('enemy', attacker, barricade, taken, barricadeHealthBefore);
      return true;
    }
  }

  const requestedTarget = validation.targetType === 'minion' ? validation.target : null;
  const canAutoBlock = validation.targetType === 'hero' || (requestedTarget && slotRow(requestedTarget.slot ?? 0) === 'back');
  let blocker = canAutoBlock ? chooseAutoBlocker(attacker, state.playerMinions, requestedTarget) : null;
  if (blocker && (blocker.health ?? 0) <= 0) blocker = null;
  if (blocker) {
    const defender = ensureCombatFields(blocker);
    const defenderHealthBefore = Math.max(0, toNumber(defender.health, 0));
    const defenderEl = document.querySelector(`[data-id="${defender.id}"]`);
    triggerAbilityEvent('player', 'on_enemy_attack_targeting_friendly', {
      side: 'player',
      self: defender,
      target: defender,
      attacker,
    });
    const defenderWasDamagedBefore = (defender.health ?? 0) < (defender.maxHealth ?? defender.health ?? 0);
    const attackerWasDamagedBefore = (attacker.health ?? 0) < (attacker.maxHealth ?? attacker.health ?? 0);
    const combatAttacker = { ...attacker, attack: currentAttackValue(attacker, 'enemy', defender) };
    const combatDefender = { ...defender, attack: currentAttackValue(defender, 'player', attacker) };
    const result = resolveCombat(combatAttacker, combatDefender, state, 'enemy');
    const defenderHit = applyDamageToUnit(defender, result.damageToDefender, { pierce: attacker.pierce, trueDamage: attacker.trueDamage, damageType: attacker.damageType ?? attacker.element, breakOnHit: true });
    consumeMarkedAttackBonus(defender);
    const attackerHit = applyDamageToUnit(attacker, result.damageToAttacker, { pierce: defender.pierce, trueDamage: defender.trueDamage, damageType: defender.damageType ?? defender.element, breakOnHit: true });
    if (attacker.poisonousVsDamaged && defenderWasDamagedBefore && defenderHit.damageTaken > 0) defender.health = 0;
    if (defender.poisonousVsDamaged && attackerWasDamagedBefore && attackerHit.damageTaken > 0) attacker.health = 0;
    spawnDamageNumber(defenderEl, defenderHit.damageTaken, attacker.element ?? 'arcane');
    state.enemyUsedAttacks[attacker.id] = used + 1;
    spawnDamageNumber(attackerEl, attackerHit.damageTaken, defender.element ?? 'shadow');
    drawAttackLine(attackerEl, defenderEl);
    triggerBattleVfx('attack', { attackerId: attacker.id, targetId: defender.id, fromEl: attackerEl, toEl: defenderEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
    scoredKill = (defender.health ?? 0) <= 0;
    if (scoredKill) emitKillAndOverkillEvents('enemy', attacker, defender, defenderHit.damageTaken, defenderHealthBefore);
    return true;
  }

  if (validation.targetType === 'hero') {
    const atkValue = currentAttackValue(attacker, 'enemy', null);
    const hit = applyDamageToCore('player', atkValue, { pierce: attacker.pierce, trueDamage: attacker.trueDamage, breakOnHit: true });
    const heroEl = document.querySelector('[data-target-id="player-hero"]');
    state.enemyUsedAttacks[attacker.id] = used + 1;
    spawnDamageNumber(heroEl, hit.damageTaken, attacker.element ?? (hit.trueDamage ? 'shadow' : 'arcane'));
    drawAttackLine(attackerEl, heroEl);
    triggerBattleVfx('attack', { attackerId: attacker.id, targetId: 'player-hero', fromEl: attackerEl, toEl: heroEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
    return true;
  }
  const defender = ensureCombatFields(validation.target);
  if (!defender) return false;
  const defenderHealthBefore = Math.max(0, toNumber(defender.health, 0));
  const defenderEl = document.querySelector(`[data-id="${defender.id}"]`);
  triggerAbilityEvent('player', 'on_enemy_attack_targeting_friendly', {
    side: 'player',
    self: defender,
    target: defender,
    attacker,
  });
  const defenderWasDamagedBefore = (defender.health ?? 0) < (defender.maxHealth ?? defender.health ?? 0);
  const attackerWasDamagedBefore = (attacker.health ?? 0) < (attacker.maxHealth ?? attacker.health ?? 0);
  const combatAttacker = { ...attacker, attack: currentAttackValue(attacker, 'enemy', defender) };
  const combatDefender = { ...defender, attack: currentAttackValue(defender, 'player', attacker) };
  const result = resolveCombat(combatAttacker, combatDefender, state, 'enemy');
  const defenderHit = applyDamageToUnit(defender, result.damageToDefender, { pierce: attacker.pierce, trueDamage: attacker.trueDamage, damageType: attacker.damageType ?? attacker.element, breakOnHit: true });
  consumeMarkedAttackBonus(defender);
  const attackerHit = applyDamageToUnit(attacker, result.damageToAttacker, { pierce: defender.pierce, trueDamage: defender.trueDamage, damageType: defender.damageType ?? defender.element, breakOnHit: true });
  if (attacker.poisonousVsDamaged && defenderWasDamagedBefore && defenderHit.damageTaken > 0) defender.health = 0;
  if (defender.poisonousVsDamaged && attackerWasDamagedBefore && attackerHit.damageTaken > 0) attacker.health = 0;
  spawnDamageNumber(defenderEl, defenderHit.damageTaken, attacker.element ?? 'arcane');
  state.enemyUsedAttacks[attacker.id] = used + 1;
  spawnDamageNumber(attackerEl, attackerHit.damageTaken, defender.element ?? 'shadow');
  if (attackerEl) attackerEl.classList.add('recoil');
  if (defenderEl) defenderEl.classList.add('recoil');
  setTimeout(() => {
    attackerEl?.classList.remove('recoil');
    defenderEl?.classList.remove('recoil');
  }, 180);
  drawAttackLine(attackerEl, defenderEl);
  triggerBattleVfx('attack', { attackerId: attacker.id, targetId: defender.id, fromEl: attackerEl, toEl: defenderEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
  if (defenderHit.blocked > 0) triggerBattleVfx('defense-enter', { targetId: defender.id, vfxSpec: VFX_DEFAULTS['defense-enter'] });
  if (attacker.pierce > 0 || attacker.trueDamage) triggerBattleVfx('pierce', { targetId: defender.id, vfxSpec: { ...VFX_DEFAULTS.attack, color: '#ffd58a', projectileType: 'lance', impactType: 'shatter' } });
  scoredKill = (defender.health ?? 0) <= 0;
  directKillVictim = defender;
  directKillDamage = defenderHit.damageTaken;
  directKillHealthBefore = defenderHealthBefore;
  if (scoredKill) emitKillAndOverkillEvents('enemy', attacker, directKillVictim, directKillDamage, directKillHealthBefore);
  return true;
}

async function runEnemyTurn() {
  state.aiTurnQueued = false;
  const activeProfile = currentAiProfile();
  const profile = syncAiProfileFromDeck(activeProfile?.id, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? [])])
    ?? enrichAiProfile(activeProfile ?? {}, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? [])]);
  if (!profile || state.aiThinking || state.matchResolved) return;
  if (!state.aiLogicEnabled) {
    state.lastAiTrace = 'AI logic disabled via ./ailogic off.';
    state.currentTurn = 'player';
    pushDevActionTrace('Enemy AI skipped (logic disabled).', 'warn');
    renderPanels();
    return;
  }

  state.aiThinking = true;
  state.currentTurn = 'enemy';
  state.devMetrics.aiPhase = 'evaluate board';
  const enemyTax = Math.max(0, toNumber(state.enemyTurnTax ?? 0));
  state.enemyMana = Math.max(0, state.maxMana - enemyTax);
  beginPhaseFlowFor('enemy');
  state.enemyMinions.forEach((m) => { ensureCombatFields(m); m.summoningSick = false; });
  maybeSpeakAiEvent(profile, 'start_turn', 0.7);
  const biggestEnemy = [...state.playerMinions].sort((a, b) => ((b.attack ?? 0) + (b.health ?? 0)) - ((a.attack ?? 0) + (a.health ?? 0)))[0];
  if (biggestEnemy && ((biggestEnemy.attack ?? 0) >= 6 || (biggestEnemy.health ?? 0) >= 8) && Math.random() < 0.42) {
    maybeSpeakAiEvent(profile, 'respect_enemy', 0.58);
  }
  if (state.enemyHealth <= 8) maybeSpeakAiEvent(profile, 'near_death', 0.72);
  state.aiThinkingLine = getThinkingLine(profile);
  renderPanels();

  const delayMs = getThinkDelay(profile);
  await new Promise((resolve) => setTimeout(resolve, delayMs));
  if (!state.aiPlannerWarm.ready || state.aiPlannerWarm.profileId !== (profile.id ?? null)) {
    state.devMetrics.aiPhase = 'finalize enemy planner';
    renderPanels();
    await new Promise((resolve) => setTimeout(resolve, 24));
  }

  if (enemyTax > 0) log(`Enemy taxed: -${enemyTax} mana this turn.`);
  const planningState = enemyTax > 0
    ? { ...state, enemyMana: Math.max(0, state.maxMana - enemyTax) }
    : state;
  state.enemyTurnTax = 0;

  const plan = chooseTurnPlan(planningState, profile);
  state.devMetrics.aiPhase = 'choose action sequence';
  state.devMetrics.lastAiCandidates = plan.slice(0, 10).map((step, idx) => `${idx + 1}. ${(step?.type ?? 'pass')} • ${step?.trace ?? 'no-trace'}`);
  const traces = [];
  let comboAnnounced = false;
  let sequenceThreatPlays = 0;

  for (let step = 0; step < plan.length; step += 1) {
    const action = plan[step] ?? { type: 'pass', trace: 'enemy:invalid-step' };
    traces.push(action.trace ?? action.type ?? `step-${step + 1}`);
    state.devMetrics.aiPhase = action.type === 'summon'
      ? 'choose deployment'
      : action.type === 'attack-minion' || action.type === 'attack-hero'
        ? 'choose attack'
        : action.type === 'boss-roar'
          ? 'support action'
          : 'end turn';
    pushDevActionTrace(`AI ${action.type ?? 'pass'} • ${action.trace ?? `step ${step + 1}`}`, 'ai');

    if (action.type === 'summon') {
      const summon = drawEnemySummon(profile, action.deckIndex ?? null);
      if (summon) {
        summon.maxHealth = summon.health;
        summon.level = profile.level ?? 1;
        const preferred = Number.isInteger(action.slot) ? action.slot : null;
        const free = preferred != null && !getSlotOccupant(state.enemyMinions, preferred)
          ? preferred
          : Array.from({ length: MAX_SLOTS }, (_, i) => i).find((i) => !getSlotOccupant(state.enemyMinions, i));
        if (free != null) {
          summon.slot = free;
          summon.summoningSick = !summon.charge;
          ensureCombatFields(summon);
          noteTurnFlag('enemy', 'playedMinion', 1);
          noteTurnFlag('enemy', 'cardsPlayed', 1);
          noteFamilyTurnFlag('enemy', 'playedFamilies', summon);
          state.enemyMinions.push(summon);
          seedCardFamiliarity('enemy', summon);
          refreshAllPassiveAuras();
          triggerAbilityEvent('enemy', 'on_summon_friendly', { side: 'enemy', self: summon, summoned: summon });
          triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: summon, target: summon, self: summon });
          if (cardMatchesFamily(summon, 'ship')) triggerAbilityEvent('enemy', 'on_play_ship', { side: 'enemy', playedCard: summon, target: summon, self: summon });
          triggerUnitAbilityEvent(summon, 'enemy', 'on_play', { side: 'enemy', self: summon, card: summon });
          if (summon.instanceId) setDeckTrackerStatus('enemy', summon.instanceId, 'played', { source: summon.source ?? undefined });
          triggerBattleVfx('summon', { side: 'enemy', unit: summon.name, vfxSpec: getCardVfxSpec(summon, 'summon') });
          if ((summon.attack ?? 0) >= 5 || summon.taunt || summon.trueDamage) sequenceThreatPlays += 1;
          maybeSpeakAiEvent(profile, (summon.rarity === 'legendary' || (summon.attack ?? 0) >= 6) ? 'signature_play' : 'early_pressure', 0.45);
        }
      }
    } else if (action.type === 'play-card') {
      const played = playEnemyCardFromHand(action, profile);
      if (played.ok) {
        sequenceThreatPlays += 1;
        (played.categories ?? ['early_pressure']).forEach((category, categoryIndex) => {
          maybeSpeakAiEvent(profile, category, categoryIndex === 0 ? 0.52 : 0.34);
        });
      } else {
        pushDevActionTrace(`Enemy failed to play card: ${played.message ?? 'unknown'}`, 'warn');
        maybeSpeakAiEvent(profile, 'whiff', 0.24);
      }
    } else if (action.type === 'attack-minion') {
      if (performEnemyAttack(action.attackerId, action.targetId)) sequenceThreatPlays += 1;
    } else if (action.type === 'attack-hero') {
      if (performEnemyAttack(action.attackerId, 'player-hero')) {
        sequenceThreatPlays += 1;
        if (state.playerHealth <= 10) maybeSpeakAiEvent(profile, 'lethal_found', 0.74);
      }
    } else if (action.type === 'boss-roar') {
      if (toNumber(state.enemySpellCounter, 0) > 0) {
        state.enemySpellCounter = Math.max(0, toNumber(state.enemySpellCounter, 0) - 1);
        pushDevActionTrace('Enemy spell action countered.', 'warn');
        continue;
      }
      const roarHit = applyDamageToCore('player', 2, { damageType: 'arcane' });
      state.enemyMinions.forEach((m) => { m.attack += 1; });
      spawnDamageNumber(document.querySelector('[data-target-id="player-hero"]'), roarHit.damageTaken, 'arcane');
      triggerBattleVfx('cast', { skill: 'shadow-roar', vfxSpec: { ...VFX_DEFAULTS.cast, color: '#c7a0ff', impactType: 'arcane-burst', particleDensity: 22 } });
      noteTurnFlag('enemy', 'playedSpell', 1);
      noteTurnFlag('enemy', 'cardsPlayed', 1);
      if (!getTurnFlags('enemy').firstSpellCard) getTurnFlags('enemy').firstSpellCard = { name: 'Shadow Roar', type: 'spell', cost: 0, text: '' };
      triggerAbilityEvent('enemy', 'on_spell_cast', {
        side: 'enemy',
        card: { name: 'Shadow Roar', type: 'spell' },
        sourceCard: { name: 'Shadow Roar', type: 'spell' },
        castMeta: { fromSkill: true },
        source: 'skill',
      });
      triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: { name: 'Shadow Roar', type: 'spell' }, target: null });
    } else if (action.type === 'pass') {
      if (step === 0 && (state.enemyHand?.length ?? 0) > 0) maybeSpeakAiEvent(profile, 'under_pressure', 0.22);
      break;
    }

    cleanupDead();
    render();
    if (!comboAnnounced && sequenceThreatPlays >= 2 && Math.random() < 0.38) {
      comboAnnounced = true;
      maybeSpeakAiEvent(profile, 'combo_assembled', 0.84);
    }

    if (state.playerHealth <= 0 || state.enemyHealth <= 0) break;
    await new Promise((resolve) => setTimeout(resolve, 120));
  }

  state.lastAiTrace = `${profile.name} -> ${traces.join(' | ') || 'pass'} (${delayMs}ms)`;
  state.devMetrics.aiPhase = 'end turn';

  setPhase('end');
  triggerAbilityEvent('enemy', 'on_end_turn', { side: 'enemy' });
  resolveEndTurnReturns('enemy');
  triggerAbilityEvent('enemy', 'on_any_end_turn', { side: 'enemy' });
  triggerAbilityEvent('player', 'on_any_end_turn', { side: 'enemy' });
  state.aiThinking = false;
  state.devMetrics.aiPhase = 'idle';
  state.aiThinkingLine = '';
  state.currentTurn = 'player';
  state.selectedCardId = null;
  state.selectedSpellTargetMode = false;
  state.selectedAttackerId = null;
  if (state.enemyHealth <= 10) maybeSpeakAiEvent(profile, 'stabilizing', 0.52);
  if (state.playerHeroPoison) {
    state.playerHealth -= state.playerHeroPoison;
    spawnDamageNumber(document.querySelector('[data-target-id="player-hero"]'), state.playerHeroPoison, 'poison');
  }
  tickStatusDurations(state.enemyMinions, 'enemy');
  state.maxMana = Math.min(15, state.maxMana + 1);
  const playerTax = Math.max(0, toNumber(state.playerTurnTax ?? 0));
  state.mana = Math.max(0, state.maxMana - playerTax);
  state.enemyMana = 0;
  state.enemyHand.forEach((card) => { card.justDrawn = false; });
  if (playerTax > 0) log(`Player taxed: -${playerTax} mana this turn.`);
  state.playerTurnTax = 0;
  resetAttackUsageFor('player');
  state.playerMinions.forEach((m) => { ensureCombatFields(m); m.summoningSick = false; });
  beginPhaseFlowFor('player');
  cleanupDead();
  render();
  toast('Enemy turn complete.', 'info');
  renderPanels();
  document.querySelector('#boot-loading')?.classList.add('hidden');
  document.querySelector('#app')?.classList.remove('hidden');
}



function endTurn() {
  if (state.matchResolved) return;
  if (state.currentTurn !== 'player') return;
  setPhase('end');
  triggerAbilityEvent('player', 'on_end_turn', { side: 'player' });
  resolveEndTurnReturns('player');
  triggerAbilityEvent('player', 'on_any_end_turn', { side: 'player' });
  triggerAbilityEvent('enemy', 'on_any_end_turn', { side: 'player' });
  if (state.enemyHeroPoison) {
    state.enemyHealth -= state.enemyHeroPoison;
    spawnDamageNumber(document.querySelector('[data-target-id=\"enemy-hero\"]'), state.enemyHeroPoison, 'poison');
  }
  tickStatusDurations(state.playerMinions, 'player');
  state.selectedAttackerId = null;
  state.selectedCardId = null;
  state.selectedSpellTargetMode = false;
  state.handPresentation.hoveredCardId = null;
  state.handPresentation.pointerTilt = { cardId: null, x: 0, y: 0 };
  resetAttackUsageFor('enemy');
  state.enemyMinions = state.enemyMinions.map((m, i) => ensureCombatFields({ ...m, slot: m.slot ?? i }));
  queueEnemyTurnStart();
  render();
}

function renderPanels() {
  document.querySelector('#gold').textContent = state.profile.economy.gold;
  document.querySelector('#streak').textContent = state.profile.stats.streak;
  document.querySelector('#mana').textContent = `${state.mana}/${state.maxMana}`;
  const deckCount = document.querySelector('#deck-count');
  if (deckCount) deckCount.textContent = String(state.playerDeck.length);
  const handCount = document.querySelector('#hand-count');
  if (handCount) handCount.textContent = String(state.hand.length);

  const slotHelp = document.querySelector('#slot-help');
  const mainPanels = document.querySelector('#main-panels');
  if (mainPanels) mainPanels.classList.toggle('hidden', !state.dmPanelsVisible);
  if (slotHelp) {
    slotHelp.innerHTML = '<h3>Tutorial</h3><div>Use click-to-place and click-to-attack for clean control.</div><details><summary>Quick Controls</summary><div>Click a hand card, then click a highlighted slot to summon.</div><div>Click your minion, then click a highlighted target to attack.</div><div>Defense stance grants +2 DEF and Guard/Taunt but can break after blocks.</div><div>Press Escape to cancel selections.</div></details>';
  }

  const aiPanel = document.querySelector('#ai-panel');
  const active = currentAiProfile();
  if (aiPanel && active) {
    aiPanel.classList.toggle('debug-overlay', state.devModeEnabled);
    if (!state.devModeEnabled) {
      aiPanel.innerHTML = '<h3>Neural AI Planner</h3><div>Debug hidden. Use <code>./DevMode</code> to show.</div>';
    } else if (!isNeuralAiProfile(active)) {
      aiPanel.innerHTML = `<h3>Neural AI Planner</h3><div>${active.name} is not using a neural planner profile in this match.</div><div class="hint">Switch opponent or AI pack to neural-enabled profiles for rollout traces.</div>`;
    } else {
      const debug = getPlannerDebug(active.id);
      const formation = debug?.currentFormation ?? debug?.formationId ?? 'n/a';
      const scores = (debug?.formationScores ?? []).slice(0, 4).map((entry) => `${entry.name}: ${entry.score.toFixed(2)}`).join('<br />') || 'No formation data yet.';
      const probs = debug?.probabilities
        ? `Taunt T3 ${(debug.probabilities.tauntBy3 * 100).toFixed(0)}% • Engine T4 ${(debug.probabilities.engineBy4 * 100).toFixed(0)}% • Threat T5 ${(debug.probabilities.threatBy5 * 100).toFixed(0)}%`
        : 'Draw math pending.';
      const roleCounts = debug?.roleCounts
        ? Object.entries(debug.roleCounts).map(([key, value]) => `${key}:${value}`).join(' • ')
        : 'No role counts.';
      const slotReason = (debug?.slotDecisions ?? []).slice(0, 3).map((entry) => `${entry.card} -> slot ${entry.slot} (${entry.reason})`).join('<br />') || 'No slot decisions yet.';
      const candidates = (debug?.candidateSummary ?? []).slice(0, 5).map((entry, idx) => `${idx + 1}. ${entry.actions.join(' -> ')} <strong>${entry.score}</strong><br /><span class="hint">${(entry.rationale ?? []).join(', ') || 'no explicit rationale'} | lethal:${entry.predictedLethal ? 'yes' : 'no'} | threatened:${entry.threatenedLethal ? 'yes' : 'no'} | board:${entry.boardValue ?? 'n/a'}</span>`).join('<br />') || 'No candidate lines.';
      const evalSummary = debug?.evaluation
        ? Object.entries(debug.evaluation).map(([key, value]) => `${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}`).join('<br />')
        : 'No evaluation snapshot.';
      const respectList = (state.aiThreatMemory?.[active.id]?.respectList ?? [])
        .slice(0, 5)
        .map((entry) => `${entry.name} (${entry.score})`)
        .join('<br />') || 'No tracked enemy threats.';
      const lastDialogue = state.aiDialogueState?._last
        ? `${state.aiDialogueState._last.category}: ${state.aiDialogueState._last.line}`
        : 'No dialogue event yet.';
      aiPanel.innerHTML = `
        <h3>Neural AI Planner</h3>
        <div><strong>Opponent:</strong> ${active.name} (Lvl ${active.level ?? 1})</div>
        <div><strong>Archetype:</strong> ${debug?.archetypeName ?? active.aiArchetypeName ?? active.archetype ?? active.strategy ?? 'unknown'} ${(debug?.difficultyBand ?? active.difficultyBand) ? `• ${debug?.difficultyBand ?? active.difficultyBand}` : ''}</div>
        <div><strong>Deck Identity:</strong> ${debug?.deckIdentity?.primary ?? active.deckIdentity?.primary ?? active.deckIdentity ?? 'unknown'}</div>
        <div><strong>Current Formation:</strong> ${formation}</div>
        <div><strong>Formation Reason:</strong> ${debug?.formationReason ?? 'n/a'}</div>
        <div><strong>Think:</strong> ${state.aiThinking ? state.aiThinkingLine : state.lastAiTrace}</div>
        <div><strong>Dialogue:</strong> ${lastDialogue}</div>
        <div><strong>Hold Reason:</strong> ${debug?.holdReason ?? 'none'}</div>
        <div><strong>Chosen Why:</strong> ${debug?.selectedWhy ?? 'n/a'}</div>
        <div><strong>Predicted Lethal:</strong> ${debug?.evaluation?.predictedLethal ? 'yes' : 'no'} | <strong>Threatened:</strong> ${debug?.evaluation?.threatenedLethal ? 'yes' : 'no'}</div>
        <details><summary>Formation Scores</summary><div>${scores}</div></details>
        <details><summary>Role Counts</summary><div>${roleCounts}</div></details>
        <details><summary>Respect List</summary><div>${respectList}</div></details>
        <details><summary>Draw Probabilities</summary><div>${probs}</div></details>
        <details><summary>Slot Decisions</summary><div>${slotReason}</div></details>
        <details><summary>Candidate Lines</summary><div>${candidates}</div></details>
        <details><summary>Evaluation</summary><div>${evalSummary}</div></details>
      `;
    }
  }

  const settingsPanel = document.querySelector('#settings-panel');
  if (settingsPanel) {
    const tip = state.shownLoadingTip;
    const issueBlock = state.deckValidationIssues.length
      ? `<div class="hint" style="margin-top:0.45rem;color:#ffd68b;"><strong>Deck legality adjustments:</strong><br/>${state.deckValidationIssues.slice(0, 3).join('<br/>')}</div>`
      : '';
    settingsPanel.innerHTML = `
      <h3>Loading Flavor</h3>
      ${tip
        ? `<div><strong>${tip.title}</strong></div><div>${tip.flavor}</div><small>${tip.gameplayTip}</small>`
        : '<div>No lore tip loaded.</div>'}
      <div class="hint" style="margin-top:0.55rem;">
        <strong>Ruleset:</strong> ${state.battleRuleset.rulesetName}<br/>
        <strong>Mode:</strong> ${state.battleRuleset.modeModel} (${state.battleRuleset.battleType})<br/>
        <strong>Deck Size:</strong> ${state.battleRuleset.deckSize} • <strong>Threat Deck:</strong> ${state.battleRuleset.threatDeckSize}
      </div>
      ${issueBlock}
    `;
  }
  renderDevSuite();
}

async function buyAndOpen(productId, quantity = 1, discount = 1) {
  const product = state.storeProducts.find((entry) => entry.id === productId);
  if (!product) return;
  ensureProgressFields(state.profile);
  const totalPrice = Math.floor(product.price * quantity * discount);
  if (state.profile.economy.gold < totalPrice) return;
  state.profile.economy.gold -= totalPrice;
  for (let i = 0; i < quantity; i += 1) {
    const pityState = state.profile.economy.pityByProduct[product.id] ?? { missesUntilGuaranteed: 0 };
    const pool = resolveStorePoolForProduct(product);
    const opened = openPack(pool, product, pityState);
    state.profile.economy.pityByProduct[product.id] = opened.pityState;
    state.profile.stats.packsOpened = Math.max(0, Number(state.profile.stats.packsOpened ?? 0)) + 1;
    state.profile.stats.packs.openedTotal = Math.max(0, Number(state.profile.stats.packs.openedTotal ?? 0)) + 1;
    state.profile.stats.packs.byPack[product.id] = Math.max(0, Number(state.profile.stats.packs.byPack[product.id] ?? 0)) + 1;
    state.profile.stats.packs.cardsByPack[product.id] = Math.max(0, Number(state.profile.stats.packs.cardsByPack[product.id] ?? 0)) + opened.pulls.length;
    const revealPayload = opened.pulls.map((card) => ({
      card,
      isNew: (state.profile.collection[card.id] ?? 0) === 0,
    }));
    opened.pulls.forEach((card) => {
      const rarity = String(card.rarity ?? 'common').toLowerCase();
      state.profile.collection[card.id] = (state.profile.collection[card.id] ?? 0) + 1;
      state.profile.stats.packs.rarityPulls[rarity] = Math.max(0, Number(state.profile.stats.packs.rarityPulls[rarity] ?? 0)) + 1;
      if (rarity === 'legendary') {
        state.profile.stats.packs.legendaryPulls = Math.max(0, Number(state.profile.stats.packs.legendaryPulls ?? 0)) + 1;
      }
    });
    const packIds = new Set(pool.map((card) => String(card.packSource ?? card.sourcePack ?? '').toLowerCase()).filter(Boolean));
    if (packIds.size) {
      let uniqueForPack = 0;
      Object.entries(state.profile.collection).forEach(([cardId, owned]) => {
        if (Number(owned ?? 0) <= 0) return;
        const card = getAllCards().find((entry) => entry.id === cardId);
        const source = String(card?.packSource ?? card?.sourcePack ?? '').toLowerCase();
        if (packIds.has(source)) uniqueForPack += 1;
      });
      state.profile.stats.packs.uniqueByPack[product.id] = uniqueForPack;
    }
    bumpQuestMetric('packsOpened', 1);
    await animatePackOpening(revealPayload);
    triggerBattleVfx('cast', { product: product.id, count: opened.pulls.length, vfxSpec: { ...VFX_DEFAULTS.cast, projectileType: 'rain', color: '#ffd57a', numberOfProjectiles: 4, staggerTiming: 50 } });
  }
  updateCollectionProgressStats(state.profile);
  persistProfile();
  toast(`Opened ${quantity} pack(s).`, 'info');
  renderPanels();
  document.querySelector('#boot-loading')?.classList.add('hidden');
  document.querySelector('#app')?.classList.remove('hidden');
}

function resolveStorePoolForProduct(product = {}) {
  const allCards = getAllCards();
  const poolTag = String(product.poolTag ?? '').trim();
  if (!poolTag) return allCards;
  const upper = poolTag.toUpperCase();
  const lower = poolTag.toLowerCase();
  const tagged = allCards.filter((card) => {
    const tags = Array.isArray(card.tags) ? card.tags.map((entry) => String(entry).toLowerCase()) : [];
    const race = String(card.race ?? '').toLowerCase();
    const faction = String(card.factionId ?? card.invasionFaction ?? '').toLowerCase();
    return tags.includes(lower) || tags.includes(upper.toLowerCase()) || race === lower || faction === lower;
  });
  if (tagged.length) return tagged;
  const thematicFallback = {
    ashen_armadas: ['siege', 'fortress', 'iron-carrion-mandate', 'armor', 'structure'],
    broken_stars: ['halo-censors', 'heal', 'radiant', 'silence', 'support'],
    feral_shard: ['chitin-ascendancy', 'swarm', 'adjacency', 'aggressive', 'summon'],
    black_signals: ['glass-null-collective', 'tax', 'control', 'spellcraft', 'value'],
  };
  const fallbackTags = thematicFallback[lower] ?? [];
  if (fallbackTags.length) {
    const fallbackPool = allCards.filter((card) => {
      const tags = Array.isArray(card.tags) ? card.tags.map((entry) => String(entry).toLowerCase()) : [];
      return fallbackTags.some((tag) => tags.includes(tag));
    });
    if (fallbackPool.length) return fallbackPool;
  }
  return allCards;
}


async function animatePackOpening(cards) {
  const panel = document.querySelector('#pack-opening');
  const reveal = document.querySelector('#pack-reveal');
  panel.classList.remove('hidden');
  reveal.innerHTML = '';
  const guide = document.querySelector('#pack-guide');
  if (guide) guide.classList.remove('hidden');
  await new Promise((resolve) => setTimeout(resolve, 350));
  if (guide) guide.classList.add('hidden');
  for (const payload of cards) {
    const card = payload?.card ?? payload;
    const isNew = !!payload?.isNew;
    const node = document.createElement('div');
    node.className = `pack-card ${card.rarity} ${isNew ? 'new-card' : ''}`;
    node.innerHTML = `<strong>${card.name}</strong><div>${card.rarity}${isNew ? ' • NEW' : ''}</div>`;
    reveal.appendChild(node);
    await new Promise((resolve) => setTimeout(resolve, 100));
    node.classList.add('show');
  }
}

async function boot() {
  const sequence = ++bootSequence;
  bootCompleted = false;
  resetBootUi();
  scheduleBootWatchdog(sequence);
  ensureProgressFields(state.profile);
  const bootLog = (line) => appendBootLogLine(line);
  try {
    if (!LOCAL_MODE) {
      setBootStatus('Loading runtime manifests...');
      const errors = await loadPlugins(registry, [
        { manifest: './mode_packs/index.json', base: './mode_packs', type: 'mode-pack', kind: 'modes' },
        { manifest: './ai_packs/index.json', base: './ai_packs', type: 'ai-pack', kind: 'ai' },
        { manifest: './race_packs/index.json', base: './race_packs', type: 'race-pack', kind: 'rivalryPacks' },
        { manifest: './quest_packs/index.json', base: './quest_packs', type: 'quest-pack', kind: 'questPacks' },
        { manifest: './store_packs/index.json', base: './store_packs', type: 'store-pack', kind: 'storePacks' },
        { manifest: './deck_packs/index.json', base: './deck_packs', type: 'deck-pack', kind: 'deckPacks' },
        { manifest: './backdrop_packs/index.json', base: './backdrop_packs', type: 'backdrop-pack', kind: 'backdropPacks' },
        { manifest: './audio_packs/index.json', base: './audio_packs', type: 'audio-pack', kind: 'audioPacks' },
        { manifest: './cosmetic_packs/index.json', base: './cosmetic_packs', type: 'cosmetic-pack', kind: 'cosmeticPacks' },
        { manifest: './theme_packs/index.json', base: './theme_packs', type: 'theme-pack', kind: 'themePacks' },
        { manifest: './loading_packs/index.json', base: './loading_packs', type: 'loading-pack', kind: 'loadingPacks' },
        { manifest: '../packs/index.json', base: '../packs', type: 'card-pack', kind: 'cardPacks' },
      ], bootLog);
      if (sequence !== bootSequence) return;
      errors.forEach((error) => log(`Error: ${error}`));
    } else {
      bootLog('Local mode detected (file://).');
      bootLog('Using embedded starter data.');
    }

    setBootStatus('Preparing battle runtime state...');
    state.rivalryPacks = LOCAL_MODE ? [] : registry.list('rivalryPacks');
    state.quests = LOCAL_MODE ? [{ id: 'local-win', goal: 'Win 1 match', metric: 'wins', target: 1, reward: 120 }] : registry.list('questPacks').flatMap((pack) => pack.quests ?? []);
    state.storeProducts = LOCAL_MODE ? LOCAL_RUNTIME_DATA.storeProducts : registry.list('storePacks').flatMap((pack) => pack.products ?? []);
    state.aiProfiles = LOCAL_MODE ? LOCAL_RUNTIME_DATA.aiProfiles : registry.list('ai');
    const customMapAis = Array.isArray(state.profile?.mapWorld?.customAiProfiles) ? state.profile.mapWorld.customAiProfiles : [];
    customMapAis.forEach((entry) => {
      if (!entry?.id || !entry?.name) return;
      const idx = state.aiProfiles.findIndex((ai) => ai.id === entry.id);
      if (idx >= 0) state.aiProfiles[idx] = { ...state.aiProfiles[idx], ...entry };
      else state.aiProfiles.push(entry);
    });
    state.aiProfiles = state.aiProfiles.map((profile) => enrichAiProfile(profile, [...(profile?.deck ?? []), ...(profile?.summons ?? [])]));
    state.selectedAiId = state.aiProfiles[0]?.id ?? null;
    const queuedOpponent = localStorage.getItem(MATCH_KEY);
    if (queuedOpponent && state.aiProfiles.some((a) => a.id === queuedOpponent)) state.selectedAiId = queuedOpponent;
    const queuedContext = normalizeMatchContext(readMatchContext());
    state.matchContext = queuedContext;
    state.battleRuleset = queuedContext;
    if (queuedContext.aiProfileId && state.aiProfiles.some((a) => a.id === queuedContext.aiProfileId)) {
      state.selectedAiId = queuedContext.aiProfileId;
    }
    state.backdrops = LOCAL_MODE ? LOCAL_RUNTIME_DATA.backdrops : registry.list('backdropPacks').flatMap((pack) => pack.backdrops ?? []);
    state.playlists = registry.list('audioPacks').flatMap((pack) => pack.playlists ?? []);
    state.cardBacks = registry.list('cosmeticPacks').flatMap((pack) => pack.cardBacks ?? []);
    state.themes = LOCAL_MODE ? LOCAL_RUNTIME_DATA.themes : registry.list('themePacks').flatMap((pack) => pack.themes ?? []);
    const builtInDecks = LOCAL_MODE ? LOCAL_RUNTIME_DATA.decks : registry.list('deckPacks').flatMap((pack) => pack.decks ?? []);
    const customDecks = Array.isArray(state.profile.customDecks) ? state.profile.customDecks : [];
    state.decks = [...builtInDecks, ...customDecks].filter((deck, idx, arr) => arr.findIndex((entry) => entry.id === deck.id) === idx);
    state.loadingTips = LOCAL_MODE ? LOCAL_RUNTIME_DATA.loadingTips : registry.list('loadingPacks').flatMap((pack) => pack.entries ?? []);
    ensureLocalPlayerController();
    const defenseMode = String(queuedContext?.modeModel ?? '').toLowerCase() === 'defense'
      || String(queuedContext?.battleType ?? '').toLowerCase().includes('defense')
      || String(queuedContext?.battleType ?? '').toLowerCase().includes('invasion')
      || String(queuedContext?.battleType ?? '').toLowerCase().includes('conquest');
    const preferredStarterDeckId = defenseMode
      ? (state.profile.starterDefenseDeckId ?? state.profile.starterDeckId)
      : (state.profile.starterDeckId ?? state.profile.starterDefenseDeckId);
    const compatibleFallbackDeck = state.decks.find((deck) => {
      const compat = String(deck?.battleCompatibility ?? 'both').toLowerCase();
      if (compat === 'both') return true;
      if (defenseMode) return compat.includes('defense');
      return compat.includes('duel');
    });
    state.selectedDeckId = state.decks.find((deck) => deck.id === preferredStarterDeckId)?.id
      ?? compatibleFallbackDeck?.id
      ?? state.decks[0]?.id
      ?? null;
    ensureDevPanelState();
    state.shownLoadingTip = (state.loadingTips.length ? state.loadingTips[Math.floor(Math.random() * state.loadingTips.length)] : null);
    const sortSelect = document.querySelector('#deck-overlay-sort');
    if (sortSelect) sortSelect.value = state.playableDeckSort;
    try {
      state.cardVfxOverrides = JSON.parse(localStorage.getItem('cardforge.creator.cardVfx.v1') || '{}') || {};
    } catch {
      state.cardVfxOverrides = {};
    }
    if (state.shownLoadingTip) bootLog(`Tip: ${state.shownLoadingTip.title} — ${state.shownLoadingTip.gameplayTip}`);

    setBootStatus('Creating VFX and decks...');
    vfxRuntime = createVfxRuntime({
      canvas: document.querySelector('#vfx-canvas'),
      boardElement: document.querySelector('#board'),
      prefersReducedMotion: () => !!state.profile.settings.reduceMotion,
    });
    window.__cardforgeVfxPreview = (eventName = 'cast', spec = {}) => {
      vfxRuntime?.trigger(eventName, { vfxSpec: spec });
    };

    onVfx('play-card', ({ payload }) => { if (state.devModeEnabled) log(`VFX play-card: ${payload.cardId}`); });
    onVfx('attack', ({ payload }) => { if (state.devModeEnabled) log(`VFX attack: ${payload.attackerId} -> ${payload.targetId}`); });
    onVfx('stance-toggle', ({ payload }) => { if (state.devModeEnabled) log(`VFX stance-toggle: ${payload.id}=${payload.defense}`); });
    onVfx('summon', ({ payload }) => { if (state.devModeEnabled) log(`VFX summon: ${payload.unit}`); });
    onVfx('pack-open', ({ payload }) => { if (state.devModeEnabled) log(`VFX pack-open: ${payload.product} x${payload.count}`); });

    state.enemyMinions = state.enemyMinions.map((m, i) => ensureCombatFields({ ...m, slot: m.slot ?? i }));
    state.maxMana = Math.max(1, Math.floor(toNumber(state.battleRuleset.startingMana, 1)));
    state.mana = state.maxMana;
    state.enemyMana = state.maxMana;
    state.playerFatigue = 0;
    state.enemyFatigue = 0;
    state.playerDeckRefills = 0;
    state.playerCoreDef = 0;
    state.enemyCoreDef = 0;
    state.playerHeroPoison = 0;
    state.enemyHeroPoison = 0;
    state.playerTurnTax = 0;
    state.enemyTurnTax = 0;
    state.playerSpellCounter = 0;
    state.enemySpellCounter = 0;
    state.aiDialogueState = {};
    state.aiThreatMemory = {};
    state.aiTurnQueued = false;
    state.aiPlannerWarm = { queued: false, ready: false, profileId: null };
    resetCardPresentationTransientState();
    state.playerDeck = buildPlayerDeck();
    initializeDeckTracker('player', state.playerDeck, 'deck_entry');
    initEnemyDeck();
    state.hand = [];
    state.enemyHand = [];
    drawPlayerCards(Math.max(1, Math.floor(toNumber(state.battleRuleset.startingHand, 5))), 'opening');
    drawEnemyCards(Math.max(1, Math.floor(toNumber(state.battleRuleset.startingHand, 5))), 'opening');
    runEnemyMulligan(currentAiProfile());
    setPhase('main1');
    applyThemeAndSettings(currentAiProfile()?.themeId ?? null);
    render();
    const introAi = currentAiProfile();
    if (introAi) {
      speakAiLine(introAi, aiBanterLine(introAi, 'pre_match'));
      if (Math.random() < 0.7) speakAiLine(introAi, aiBanterLine(introAi, 'mulligan'));
    }
    if (state.deckValidationIssues.length) {
      log(`Deck legality adjustments: ${state.deckValidationIssues.slice(0, 4).join(' | ')}`);
      toast(`Deck adjusted for ${state.battleRuleset.rulesetName} legality.`, 'error');
    }
    log(`Battle ruleset: ${state.battleRuleset.rulesetName} (${state.battleRuleset.battleType}) • model ${state.battleRuleset.modeModel} • deck ${state.battleRuleset.deckSize}.`);
    toast('Runtime ready.', 'info');
    scheduleAiWarmup({ immediate: true });
    renderPanels();
    document.querySelector('#log').classList.toggle('hidden', state.logHidden);
    document.querySelector('#toggle-log').textContent = state.logHidden ? 'Show Log' : 'Hide Log';
    if (sequence !== bootSequence) return;
    bootCompleted = true;
    clearBootWatchdog();
    document.querySelector('#boot-loading')?.classList.add('hidden');
    document.querySelector('#app')?.classList.add('hidden');
    document.querySelector('#title-screen')?.classList.remove('hidden');
    const hasQueuedBattle = !!localStorage.getItem(MATCH_KEY) || !!localStorage.getItem(MATCH_CONTEXT_KEY);
    const autoStart = new URLSearchParams(window.location.search).get('autostart') === '1';
    if (hasQueuedBattle) {
      requestAnimationFrame(() => enterBattleRuntime());
    } else if (autoStart) {
      requestAnimationFrame(() => enterBattleRuntime());
    } else if (RUNTIME_MODE === 'local-player') {
      requestAnimationFrame(() => ensureLocalPlayerController().openSetup());
    }
  } catch (error) {
    if (sequence !== bootSequence) return;
    handleBootRuntimeError('Runtime boot failed before the battle client could open.', error);
  }
}

function enterBattleRuntime() {
  if (document.querySelector('#boot-loading') && !document.querySelector('#boot-loading').classList.contains('hidden')) return;
  document.querySelector('#title-screen')?.classList.add('hidden');
  document.querySelector('#app')?.classList.remove('hidden');
  if (!state.battleStartPresented) {
    const selectedDeck = getSelectedDeck();
    const deckName = selectedDeck?.name ?? 'Current Deck';
    showHint(`${state.battleRuleset.rulesetName}: ${deckName}. Right-click cards or units for full battle-term inspect.`);
    toast(`Battle Start • ${state.battleRuleset.rulesetName}`, 'info');
    state.battleStartPresented = true;
  }
  render();
  renderPanels();
}

function renderTopDeckPreview() {
  const panel = document.querySelector('#topdeck-panel');
  const title = document.querySelector('#topdeck-title');
  const body = document.querySelector('#topdeck-body');
  const closeBtn = document.querySelector('#topdeck-close-btn');
  const bottomBtn = document.querySelector('#topdeck-bottom-btn');
  if (!panel || !title || !body || !closeBtn || !bottomBtn) return;
  const preview = state.topDeckPreview;
  panel.classList.toggle('hidden', !preview);
  if (!preview) return;
  title.textContent = `${preview.sourceName ?? 'Deck Preview'} • ${preview.side === 'player' ? 'Your Deck' : 'Enemy Deck'}`;
  const cards = Array.isArray(preview.cards) ? preview.cards : [];
  body.innerHTML = cards.map((card, index) => `
    <article class="topdeck-card">
      <strong>${index + 1}. ${card.name ?? 'Unknown Card'}</strong>
      <div>${card.type ?? 'unknown'} • ${toNumber(card.cost, 0)} mana</div>
      <div>${toNumber(card.attack, 0)}/${toNumber(card.health, 0)} · DEF ${Math.max(0, toNumber(card.def ?? card.baseDef, 0))}</div>
      <div class="meta">${card.text ?? 'No text.'}</div>
    </article>
  `).join('');
  closeBtn.onclick = () => {
    closeTopDeckPreview();
    render();
  };
  bottomBtn.classList.toggle('hidden', !preview.allowBottom);
  bottomBtn.onclick = () => {
    moveTopDeckCardToBottom(preview.side);
    closeTopDeckPreview();
    showHint('Moved top deck card to bottom.');
    render();
  };
}


function render() {
  document.querySelector('#mana').textContent = `${state.mana}/${state.maxMana}`;
  document.querySelector('#player-health').textContent = state.playerHealth;
  document.querySelector('#enemy-health').textContent = state.enemyHealth;
  const playerCoreDef = document.querySelector('#player-core-def');
  if (playerCoreDef) playerCoreDef.textContent = String(getCoreDefense('player'));
  const enemyCoreDef = document.querySelector('#enemy-core-def');
  if (enemyCoreDef) enemyCoreDef.textContent = String(getCoreDefense('enemy'));
  const aiName = currentAiProfile()?.name ?? 'Unknown';
  const enemyNameEl = document.querySelector('#enemy-name');
  if (enemyNameEl) enemyNameEl.textContent = `${aiName} (Lvl ${currentAiProfile()?.level ?? 1})`; 
  setBar('#player-hero-bar', state.playerHealth, state.playerMaxHealth);
  setBar('#enemy-hero-bar', state.enemyHealth, state.enemyMaxHealth);

  const handHost = document.querySelector('#hand');
  handHost.innerHTML = '';
  handHost.classList.add('cf-hand-presenter');
  const handSettings = currentCardPresentationSettings();
  state.hand.forEach((card) => {
    ensureCombatFields(card);
    const node = document.createElement('button');
    const discount = ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(normalizeCardType(card)) ? firstSpellDiscount('player') : 0;
    const shownCost = effectiveCardCost(card, 'player', discount);
    const canCast = runtimeCardCanCast(shownCost);
    node.type = 'button';
    node.className = `cf-hand-card runtime-hand-card rarity-${card.rarity ?? 'common'} ${canCast ? 'can-cast' : 'cannot-cast'}`;
    node.dataset.id = card.instanceId;
    node.dataset.cardId = card.instanceId;
    node.dataset.inspectType = 'hand-card';
    node.dataset.inspectId = card.instanceId;
    node.innerHTML = runtimeHandMarkup(card, shownCost);
    node.classList.toggle('selected-play', state.selectedCardId === card.instanceId);
    node.onmouseenter = () => {
      state.handPresentation.hoveredCardId = card.instanceId;
      syncRuntimeHandPresentation(handHost, state.hand);
    };
    node.onmouseleave = () => {
      if (state.handPresentation.hoveredCardId !== card.instanceId) return;
      state.handPresentation.hoveredCardId = null;
      state.handPresentation.pointerTilt = { cardId: null, x: 0, y: 0 };
      syncRuntimeHandPresentation(handHost, state.hand);
    };
    node.onmousemove = (event) => {
      const rect = node.getBoundingClientRect();
      const px = ((event.clientX - rect.left) / Math.max(rect.width, 1)) - 0.5;
      const py = ((event.clientY - rect.top) / Math.max(rect.height, 1)) - 0.5;
      state.handPresentation.pointerTilt = { cardId: card.instanceId, x: px * 8, y: py * -10 };
      syncRuntimeHandPresentation(handHost, state.hand);
    };
    node.onclick = (event) => {
      event.stopPropagation();
      if (state.currentTurn !== 'player') {
        showHint('Wait for your turn.');
        return;
      }
      const cardType = normalizeCardType(card);
      if (['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(cardType)) {
        if (state.selectedCardId === card.instanceId && state.selectedSpellTargetMode) {
          const cast = playCard(card.instanceId, null, null);
          if (cast) {
            state.selectedCardId = null;
            state.selectedSpellTargetMode = false;
            clearHighlights();
            render();
          }
          return;
        }
        state.selectedCardId = card.instanceId;
        state.selectedAttackerId = null;
        state.selectedSpellTargetMode = true;
        highlightSpellTargets(card);
        render();
        return;
      }
      state.selectedCardId = state.selectedCardId === card.instanceId ? null : card.instanceId;
      state.selectedSpellTargetMode = false;
      state.selectedAttackerId = null;
      state.handPresentation.pinnedCardId = state.selectedCardId ? state.handPresentation.pinnedCardId : null;
      if (state.selectedCardId) highlightCardPlayTargets();
      else clearHighlights();
      render();
    };
    node.oncontextmenu = (event) => {
      event.preventDefault();
      if (handSettings.pinMode) state.handPresentation.pinnedCardId = card.instanceId;
      openInspectPanel({ type: 'hand-card', card, side: 'player' });
      syncRuntimeHandPresentation(handHost, state.hand);
    };
    enableCardDrag(node, card.instanceId);
    handHost.appendChild(node);
  });
  syncRuntimeHandPresentation(handHost, state.hand);

  renderLane('#enemy-back-row', state.enemyMinions, false, 'back');
  renderLane('#enemy-front-row', state.enemyMinions, false, 'front');
  renderLane('#player-front-row', state.playerMinions, true, 'front');
  renderLane('#player-back-row', state.playerMinions, true, 'back');
  wireHeroTargets();
  renderHybridZones();
  const deckCount = document.querySelector('#deck-count');
  if (deckCount) deckCount.textContent = String(state.playerDeck.length);
  const handCount = document.querySelector('#hand-count');
  if (handCount) handCount.textContent = String(state.hand.length);
  renderPlayableDeckOverlay();
  if (state.selectedCardId && state.selectedSpellTargetMode) {
    const selected = state.hand.find((card) => card.instanceId === state.selectedCardId);
    highlightSpellTargets(selected);
  } else if (state.selectedCardId) highlightCardPlayTargets();
  else if (state.selectedAttackerId) highlightAttackTargets(state.selectedAttackerId);
  else clearHighlights();
  renderTopDeckPreview();
}

function renderLane(selector, minions, playerOwned, row = 'front') {
  const lane = document.querySelector(selector);
  const opponents = playerOwned ? state.enemyMinions : state.playerMinions;
  if (!lane) return;
  lane.innerHTML = '';
  const rowSlots = slotsForRow(row);
  for (let idx = 0; idx < rowSlots.length; idx += 1) {
    const i = rowSlots[idx];
    const slot = document.createElement('div');
    slot.className = 'board-slot';
    slot.dataset.slotIndex = String(i);
    slot.dataset.row = row;
    const minion = getSlotOccupant(minions, i);

    if (!minion) {
      const laneBarricade = row === 'front'
        ? (playerOwned ? state.playerBarricades[slotLane(i)] : state.enemyBarricades[slotLane(i)])
        : null;
      if (laneBarricade && (laneBarricade.health ?? 0) > 0) {
        const bNode = document.createElement('div');
        bNode.className = 'minion target status-shattered';
        bNode.dataset.id = laneBarricade.id;
        bNode.dataset.targetId = laneBarricade.id;
        bNode.dataset.inspectType = 'barricade';
        bNode.innerHTML = `<strong>🧱 ${laneBarricade.name}</strong><div>${laneBarricade.health}/${laneBarricade.maxHealth} · DEF ${laneBarricade.def ?? 0}</div><div class="meta">Barricade · Lane ${slotLane(i) + 1}</div><div class="meta">${laneBarricade.text || 'Blocks lane attacks.'}</div>`;
        bNode.oncontextmenu = (event) => {
          event.preventDefault();
          openInspectPanel({ type: 'board-minion', minion: { ...laneBarricade, type: 'barricade', slot: i, maxHealth: laneBarricade.maxHealth, baseDef: laneBarricade.def, tags: ['barricade'] }, side: playerOwned ? 'player' : 'enemy' });
        };
        if (!playerOwned) {
          bNode.onclick = (event) => {
            event.stopPropagation();
            if (!state.selectedAttackerId) return;
            attackWith(state.selectedAttackerId, laneBarricade.id);
          };
        }
        slot.appendChild(bNode);
        lane.appendChild(slot);
        continue;
      }
      slot.innerHTML = `<span class="slot-holo">${playerOwned ? '⌬' : '◌'}</span>`;
      if (playerOwned) {
        const empty = !getSlotOccupant(state.playerMinions, i);
        if (state.selectedCardId && empty) slot.classList.add('slot-valid');
        slot.onclick = (event) => {
          event.stopPropagation();
          if (state.selectedCardId) {
            const played = playCard(state.selectedCardId, i);
            if (played) {
              state.selectedCardId = null;
              state.selectedPlayerSlot = null;
              clearHighlights();
              render();
            }
            return;
          }
          state.selectedPlayerSlot = i;
          render();
        };
        if (state.selectedPlayerSlot === i) slot.classList.add('selected');
      }
      lane.appendChild(slot);
      continue;
    }

    if (minion.large && Array.isArray(minion.occupiedSlots) && minion.occupiedSlots[0] !== i) {
      slot.classList.add('large-occupied');
      slot.innerHTML = '<span class="slot-holo">LARGE</span>';
      lane.appendChild(slot);
      continue;
    }

    const node = document.createElement('div');
    ensureCombatFields(minion);
    const indicators = getRivalryIndicators(minion, opponents, state, playerOwned ? 'player' : 'enemy');
    node.className = `minion target rarity-${minion.rarity ?? 'common'} ${minion.taunt ? 'taunt' : ''} ${minion.defense ? 'defending' : ''} ${minion.statuses?.shatteredTurns ? 'status-shattered' : ''} ${minion.statuses?.sleepTurns || minion.statuses?.freezeTurns ? 'status-stunned' : ''} ${minion.statuses?.silenced ? 'status-silenced' : ''} ${indicators.hasAdvantage ? 'rivalry-advantage' : ''} ${indicators.hasDisadvantage ? 'rivalry-danger' : ''} ${state.selectedAttackerId === minion.id ? 'selected-attacker' : ''}`;
    node.dataset.id = minion.id;
    node.dataset.targetId = minion.id;
    node.dataset.defense = String(minion.defense);
    node.dataset.inspectType = 'board-minion';
    node.dataset.inspectId = minion.id;
    node.dataset.inspectSide = playerOwned ? 'player' : 'enemy';
    const currentAttack = currentAttackValue(minion, playerOwned ? 'player' : 'enemy', null);
    const hpPct = Math.max(0, Math.min(100, (minion.health / Math.max(1, minion.maxHealth ?? minion.health)) * 100));
    const displayDef = getEffectiveDefense(minion, {}).effectiveDef;
    const minionRules = cardRulesInBattleTerms(minion);
    const battleLine = minionRules.find((line) => line.startsWith('On Play:') || line.startsWith('Cast:')) ?? minionRules[0] ?? 'No battle text.';
    const familyMeta = `${renderFamilyBadges(minion)}<span class="family-label">${familySummary(minion)}</span>`;
    const famState = familiaritySummary(playerOwned ? 'player' : 'enemy', minion);
    node.innerHTML = `<strong>${minion.defense ? '🛡️ ' : ''}${minion.name}</strong><div>${currentAttack}/${minion.health} · DEF ${displayDef}</div><div class="health-bar"><div class="health-fill" style="width:${hpPct}%"></div></div><div class="family-strip">${familyMeta}</div><div class="meta">${minion.element ?? 'none'} · L${minion.level ?? 1} · Fam ${famState}</div><div class="meta">${stanceLabel(minion, !playerOwned)}</div><div class="meta">${battleLine}</div><div class="status-row">${minion.summoningSick ? '<span class="status">Summoning Sickness</span>' : ''}${minion.statuses?.weakened ? '<span class="status">Weakened</span>' : ''}${minion.statuses?.shatteredTurns ? '<span class="status">Shattered</span>' : ''}${minion.defense ? `<span class="status">Guard ${minion.defenseDurability || 0}</span>` : ''}</div><button type="button" data-no-drag="true">${minion.defense ? `Defense ON (${minion.defenseDurability || 0})` : 'Defense OFF'}</button>`;
    const defenseButton = node.querySelector('button');
    if (playerOwned) {
      defenseButton.onpointerdown = (event) => event.stopPropagation();
      defenseButton.onclick = (event) => {
        event.stopPropagation();
        if (state.currentTurn !== 'player') {
          showHint('You can only change stance on your turn.');
          return;
        }
        minion.defense = !minion.defense;
        if (minion.defense) minion.defenseDurability = Math.max(2, minion.defenseDurability || 0);
        else minion.defenseDurability = 0;
        minion.taunt = !!minion.baseTaunt || minion.defense;
        triggerBattleVfx('defense-enter', { id: minion.id, defense: minion.defense, targetId: minion.id, vfxSpec: getCardVfxSpec(minion, 'defenseEnter') ?? VFX_DEFAULTS['defense-enter'] });
        showHint(`${minion.name}: ${stanceLabel(minion, false)}.`);
        render();
      };
    } else {
      defenseButton.disabled = true;
      defenseButton.textContent = stanceLabel(minion, true);
    }

    if (playerOwned) {
      node.onclick = (event) => {
        event.stopPropagation();
        if (state.selectedCardId && !state.selectedSpellTargetMode) {
          showHint('Cannot summon into occupied slot.');
          return;
        }
        if (state.selectedCardId && state.selectedSpellTargetMode) {
          const ok = playCard(state.selectedCardId, null, minion.id);
          if (ok) {
            state.selectedCardId = null;
            state.selectedSpellTargetMode = false;
          }
          render();
          return;
        }
        if (state.selectedAttackerId && state.selectedAttackerId !== minion.id) {
          attackWith(state.selectedAttackerId, minion.id);
          return;
        }
        state.selectedAttackerId = state.selectedAttackerId === minion.id ? null : minion.id;
        state.selectedCardId = null;
        if (state.selectedAttackerId) highlightAttackTargets(minion.id);
        else clearHighlights();
        render();
      };
      enableAttackDrag(node, minion.id);
    } else {
      node.onclick = (event) => {
        event.stopPropagation();
        if (state.selectedCardId && state.selectedSpellTargetMode) {
          const ok = playCard(state.selectedCardId, null, minion.id);
          if (ok) {
            state.selectedCardId = null;
            state.selectedSpellTargetMode = false;
          }
          render();
          return;
        }
        if (!state.selectedAttackerId) return;
        attackWith(state.selectedAttackerId, minion.id);
      };
    }
    node.oncontextmenu = (event) => {
      event.preventDefault();
      openInspectPanel({ type: 'board-minion', minion, side: playerOwned ? 'player' : 'enemy' });
    };

    slot.appendChild(node);
    lane.appendChild(slot);
  }
}

function wireHeroTargets() {
  const enemyHero = document.querySelector('[data-target-id="enemy-hero"]');
  const playerHero = document.querySelector('[data-target-id="player-hero"]');
  if (enemyHero) {
    enemyHero.onclick = (event) => {
      event.stopPropagation();
      if (state.selectedCardId && state.selectedSpellTargetMode) {
        const ok = playCard(state.selectedCardId, null, 'enemy-hero');
        if (ok) {
          state.selectedCardId = null;
          state.selectedSpellTargetMode = false;
        }
        render();
        return;
      }
      if (!state.selectedAttackerId) return;
      attackWith(state.selectedAttackerId, 'enemy-hero');
    };
    enemyHero.oncontextmenu = (event) => {
      event.preventDefault();
      openInspectPanel({
        type: 'hero',
        side: 'enemy',
        name: currentAiProfile()?.name ?? 'Enemy Hero',
        health: state.enemyHealth,
        maxHealth: state.enemyMaxHealth,
        defense: getCoreDefense('enemy'),
      });
    };
  }
  if (playerHero) {
    playerHero.onclick = (event) => {
      event.stopPropagation();
      if (!state.selectedCardId || !state.selectedSpellTargetMode) return;
      const ok = playCard(state.selectedCardId, null, 'player-hero');
      if (ok) {
        state.selectedCardId = null;
        state.selectedSpellTargetMode = false;
      }
      render();
    };
    playerHero.oncontextmenu = (event) => {
      event.preventDefault();
      openInspectPanel({
        type: 'hero',
        side: 'player',
        name: 'Player Hero',
        health: state.playerHealth,
        maxHealth: state.playerMaxHealth,
        defense: getCoreDefense('player'),
      });
    };
  }
}

function renderHybridZones() {
  const phaseHost = document.querySelector('#phase-tracker');
  if (phaseHost) {
    phaseHost.innerHTML = '';
    PHASE_ORDER.forEach((phaseId) => {
      const chip = document.createElement('span');
      chip.className = `phase-chip ${state.phase === phaseId ? 'active' : ''}`;
      chip.textContent = phaseId.replace('_', ' ');
      phaseHost.appendChild(chip);
    });
  }
  const stackHost = document.querySelector('#stack-panel');
  if (stackHost) {
    stackHost.innerHTML = '';
    if (!state.stack.length) stackHost.innerHTML = '<div class="stack-entry">Stack empty.</div>';
    else {
      [...state.stack].slice().reverse().forEach((entry, idx) => {
        const node = document.createElement('div');
        node.className = 'stack-entry';
        node.textContent = `${idx + 1}. ${entry.label ?? 'Effect'}`;
        stackHost.appendChild(node);
      });
    }
  }
  const fillTray = (selector, entries, className = '') => {
    const host = document.querySelector(selector);
    if (!host) return;
    host.innerHTML = '';
    if (!entries.length) {
      const empty = document.createElement('span');
      empty.className = `tray-chip ${className}`.trim();
      empty.textContent = 'none';
      host.appendChild(empty);
      return;
    }
    entries.slice(0, 8).forEach((entry) => {
      const chip = document.createElement('span');
      chip.className = `tray-chip ${className}`.trim();
      chip.textContent = entry.name ?? entry.id ?? 'item';
      host.appendChild(chip);
    });
  };
  const playerFieldEntries = [
    ...state.playerFields,
    ...state.playerBarricades.filter(Boolean).map((b, idx) => ({ name: `${b.name} (Lane ${idx + 1})` })),
  ];
  const enemyFieldEntries = [
    ...state.enemyFields,
    ...state.enemyBarricades.filter(Boolean).map((b, idx) => ({ name: `${b.name} (Lane ${idx + 1})` })),
  ];
  fillTray('#player-field-tray', playerFieldEntries, 'field');
  fillTray('#enemy-field-tray', enemyFieldEntries, 'field');
  fillTray('#player-relic-tray', state.playerRelics, 'relic');
  fillTray('#enemy-relic-tray', state.enemyRelics, 'relic');
  fillTray('#player-graveyard-tray', state.playerGraveyard, 'grave');
  fillTray('#enemy-graveyard-tray', state.enemyGraveyard, 'grave');
  fillTray('#player-exile-tray', state.playerExile, 'exile');
  fillTray('#enemy-exile-tray', state.enemyExile, 'exile');
}

function getPreferredAllyTarget(allyLane = [], side = 'player', preferDamaged = false) {
  const live = allyLane.filter((m) => (m.health ?? 0) > 0).map(ensureCombatFields);
  if (!live.length) return null;
  if (side === 'player') {
    if (state.selectedAttackerId) {
      const selected = live.find((m) => m.id === state.selectedAttackerId);
      if (selected) return selected;
    }
    if (state.selectedPlayerSlot != null) {
      const slotTarget = live.find((m) => (m.slot ?? -1) === state.selectedPlayerSlot);
      if (slotTarget) return slotTarget;
    }
  }
  if (preferDamaged) {
    const damaged = [...live].sort((a, b) => ((b.maxHealth ?? b.health ?? 0) - (b.health ?? 0)) - ((a.maxHealth ?? a.health ?? 0) - (a.health ?? 0)));
    if (damaged[0] && (damaged[0].health ?? 0) < (damaged[0].maxHealth ?? damaged[0].health ?? 0)) return damaged[0];
  }
  return live.find((m) => !m.defense) ?? live[0] ?? null;
}

function getPriorityEnemyTarget(enemyLane = []) {
  const live = enemyLane.filter((m) => (m.health ?? 0) > 0).map(ensureCombatFields);
  if (!live.length) return null;
  return live.find((m) => !!m.taunt) ?? [...live].sort((a, b) => ((b.baseDef ?? 0) - (a.baseDef ?? 0)) || ((b.health ?? 0) - (a.health ?? 0)))[0];
}

function executeSpellCard(card, side = 'player', explicitTargetId = null, castMeta = {}) {
  const safeCastMeta = castMeta && typeof castMeta === 'object' ? castMeta : {};
  const isPlayer = side === 'player';
  if (isPlayer && toNumber(state.playerSpellCounter, 0) > 0) {
    state.playerSpellCounter = Math.max(0, toNumber(state.playerSpellCounter, 0) - 1);
    return { ok: true, message: `${card.name} was countered.` };
  }
  if (!isPlayer && toNumber(state.enemySpellCounter, 0) > 0) {
    state.enemySpellCounter = Math.max(0, toNumber(state.enemySpellCounter, 0) - 1);
    return { ok: true, message: `${card.name} was countered.` };
  }
  const allyLane = isPlayer ? state.playerMinions : state.enemyMinions;
  const enemyLane = isPlayer ? state.enemyMinions : state.playerMinions;
  const allyHeroEl = document.querySelector(`[data-target-id="${isPlayer ? 'player-hero' : 'enemy-hero'}"]`);
  const enemyHeroEl = document.querySelector(`[data-target-id="${isPlayer ? 'enemy-hero' : 'player-hero'}"]`);
  const spellEffect = normalizeSpellEffect(card);
  const { action, amount, duration, defAmount, pierce, trueDamage, damageType } = spellEffect;
  const spellDamageBonus = Math.max(0, toNumber(getTurnFlags(side).spellDamageBonus ?? 0));
  const scaledDamage = Math.max(0, amount + spellDamageBonus);
  const spellVfx = getCardVfxSpec(card, 'cast') ?? VFX_DEFAULTS.cast;
  let hint = '';
  const explicitEnemyMinion = explicitTargetId ? enemyLane.find((m) => m.id === explicitTargetId) : null;
  const explicitAllyMinion = explicitTargetId ? allyLane.find((m) => m.id === explicitTargetId) : null;
  const explicitEnemyHero = explicitTargetId === (isPlayer ? 'enemy-hero' : 'player-hero');
  const explicitAllyHero = explicitTargetId === (isPlayer ? 'player-hero' : 'enemy-hero');
  if (explicitEnemyMinion) triggerUnitAbilityEvent(explicitEnemyMinion, enemySide(side), 'on_targeted_by_spell', { side: enemySide(side), target: explicitEnemyMinion, sourceCard: card });
  if (explicitAllyMinion) triggerUnitAbilityEvent(explicitAllyMinion, side, 'on_targeted_by_spell', { side, target: explicitAllyMinion, sourceCard: card });

  const textRules = cardText(card);
  state.lastSpellCastContext = {
    side,
    card: { ...card },
    explicitTargetId,
    castMeta: { ...safeCastMeta },
    textRules,
  };
  if (!looksLikeNoText(textRules) && Object.keys(getCardEffect(card)).length === 0) {
    const clauses = parseAbilityClauses(textRules);
    const runtime = {
      side,
      card,
      self: card,
      sourceCard: card,
      castMeta: safeCastMeta,
      target: explicitEnemyMinion ?? explicitAllyMinion ?? null,
      targetWasDamaged: !!(explicitEnemyMinion && (explicitEnemyMinion.health ?? 0) < (explicitEnemyMinion.maxHealth ?? explicitEnemyMinion.health ?? 0)),
      explicitEnemyHero,
      explicitAllyHero,
      enemyHeroEl,
      allyHeroEl,
    };
    let resolved = false;
    clauses.forEach((clause) => {
      if (!['on_play', 'on_cast', 'passive'].includes(clause.trigger)) return;
      executeAbilityBody(clause.body, runtime);
      resolved = true;
    });
    if (resolved) {
      cleanupDead();
      return { ok: true, message: `${card.name}: resolved text effects.` };
    }
  }

  if (action === 'dealDamage') {
    const target = explicitEnemyMinion ?? getPriorityEnemyTarget(enemyLane);
    if (explicitEnemyHero) {
      const hit = applyDamageToCore(isPlayer ? 'enemy' : 'player', scaledDamage, { pierce, trueDamage, damageType });
      spawnDamageNumber(enemyHeroEl, hit.damageTaken, card.element ?? 'arcane');
      triggerBattleVfx('cast', { targetId: isPlayer ? 'enemy-hero' : 'player-hero', toEl: enemyHeroEl, vfxSpec: spellVfx });
      hint = `${card.name}: dealt ${hit.damageTaken} to enemy hero.`;
    } else if (target) {
      const source = allyLane[0] ?? { race: 'none', element: 'none' };
      const spell = resolveSpellPower(source, target, scaledDamage, state, side);
      const hit = applyDamageToUnit(target, spell.power, { pierce, trueDamage, damageType, breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, card.element ?? target.element ?? 'arcane');
      triggerBattleVfx('cast', { targetId: target.id, vfxSpec: spellVfx });
      hint = `${card.name}: dealt ${hit.damageTaken} to ${target.name}.`;
    } else {
      const hit = applyDamageToCore(isPlayer ? 'enemy' : 'player', scaledDamage, { pierce, trueDamage, damageType });
      spawnDamageNumber(enemyHeroEl, hit.damageTaken, card.element ?? 'arcane');
      triggerBattleVfx('cast', { targetId: isPlayer ? 'enemy-hero' : 'player-hero', toEl: enemyHeroEl, vfxSpec: spellVfx });
      hint = `${card.name}: dealt ${hit.damageTaken} to enemy hero.`;
    }
  } else if (action === 'poisonHero') {
    if (isPlayer) state.enemyHeroPoison = (state.enemyHeroPoison ?? 0) + amount;
    else state.playerHeroPoison = (state.playerHeroPoison ?? 0) + amount;
    spawnDamageNumber(enemyHeroEl, amount, 'poison');
    triggerBattleVfx('debuff', { targetId: isPlayer ? 'enemy-hero' : 'player-hero', toEl: enemyHeroEl, vfxSpec: { ...spellVfx, color: '#9cf169', impactType: 'status-poison' } });
    hint = `${card.name}: enemy hero poisoned (+${amount} per turn).`;
  } else if (action === 'shatterFront') {
    const target = explicitEnemyMinion ?? getPriorityEnemyTarget(enemyLane);
    if (!target) return { ok: false, message: `${card.name} needs an enemy minion target.` };
    target.statuses.shatteredTurns = Math.max(duration, toNumber(target.statuses.shatteredTurns ?? 0));
    target.defense = false;
    target.defenseDurability = 0;
    target.taunt = !!target.baseTaunt;
    triggerBattleVfx('pierce', { targetId: target.id, vfxSpec: { ...spellVfx, color: '#ffd490', projectileType: 'shard', impactType: 'shatter' } });
    hint = `${card.name}: shattered ${target.name} for ${duration} turn(s).`;
  } else if (action === 'grantDefense') {
    const ally = explicitAllyMinion ?? getPreferredAllyTarget(allyLane, side, false);
    if (!ally) return { ok: false, message: `${card.name} needs an allied minion target.` };
    ally.baseDef += defAmount;
    ally.defense = true;
    ally.defenseDurability = Math.max(ally.defenseDurability || 0, 2);
    ally.taunt = true;
    triggerBattleVfx('defense-enter', { targetId: ally.id, vfxSpec: { ...spellVfx, color: '#79ddff', impactType: 'shield-ring' } });
    hint = `${card.name}: ${ally.name} gains +${defAmount} DEF and Guard.`;
  } else if (action === 'weakenAllEnemies') {
    enemyLane.forEach((minion) => {
      ensureCombatFields(minion);
      minion.statuses.weakened = true;
      minion.statuses.weakenedTurns = Math.max(duration, toNumber(minion.statuses.weakenedTurns ?? 0));
    });
    triggerBattleVfx('debuff', { targetId: isPlayer ? 'enemy-hero' : 'player-hero', vfxSpec: { ...spellVfx, projectileType: 'wave', color: '#d1a7ff', numberOfProjectiles: 2, staggerTiming: 80 } });
    hint = `${card.name}: all enemy minions weakened for ${duration} turn(s).`;
  } else if (action === 'draw') {
    if (isPlayer) drawPlayerCards(amount, 'spell');
    hint = `${card.name}: drew ${amount} card(s).`;
  } else if (action === 'heal') {
    const ally = explicitAllyMinion ?? getPreferredAllyTarget(allyLane, side, true);
    if (ally) {
      const healed = healUnitDirect(ally, amount, side, card);
      triggerBattleVfx('buff', { targetId: ally.id, vfxSpec: { ...spellVfx, color: '#8fffc4', impactType: 'heal-bloom' } });
      hint = `${card.name}: healed ${ally.name} for ${Math.max(0, healed)}.`;
    } else if (isPlayer || explicitAllyHero) {
      const healed = healHeroDirect('player', amount);
      triggerBattleVfx('buff', { targetId: 'player-hero', toEl: allyHeroEl, vfxSpec: { ...spellVfx, color: '#8fffc4', impactType: 'heal-bloom' } });
      hint = `${card.name}: healed your hero for ${Math.max(0, healed)}.`;
    } else {
      const healed = healHeroDirect('enemy', amount);
      hint = `${card.name}: healed enemy hero for ${Math.max(0, healed)}.`;
    }
  } else if (action === 'buffAttack') {
    const ally = explicitAllyMinion ?? getPreferredAllyTarget(allyLane, side, false);
    if (!ally) return { ok: false, message: `${card.name} needs an allied minion target.` };
    ally.attack += amount;
    triggerBattleVfx('buff', { targetId: ally.id, vfxSpec: { ...spellVfx, color: '#ffcf7a', impactType: 'buff-pulse' } });
    hint = `${card.name}: ${ally.name} gains +${amount} ATK.`;
  } else if (action === 'buffHealth') {
    const ally = explicitAllyMinion ?? getPreferredAllyTarget(allyLane, side, false);
    if (!ally) return { ok: false, message: `${card.name} needs an allied minion target.` };
    ally.maxHealth = (ally.maxHealth ?? ally.health ?? 0) + amount;
    ally.health += amount;
    triggerBattleVfx('buff', { targetId: ally.id, vfxSpec: { ...spellVfx, color: '#8ec9ff', impactType: 'buff-pulse' } });
    hint = `${card.name}: ${ally.name} gains +${amount} Max HP.`;
  } else if (action === 'grantArmor') {
    if (isPlayer) state.playerCoreDef += amount;
    else state.enemyCoreDef += amount;
    triggerBattleVfx('defense-enter', { targetId: isPlayer ? 'player-hero' : 'enemy-hero', toEl: allyHeroEl, vfxSpec: { ...spellVfx, color: '#79ddff', impactType: 'shield-ring' } });
    hint = `${card.name}: +${amount} Core DEF.`;
  } else if (action === 'timeLock') {
    const target = explicitEnemyMinion ?? getPriorityEnemyTarget(enemyLane);
    if (!target) return { ok: false, message: `${card.name} needs an enemy minion target.` };
    target.statuses.timeLockedTurns = Math.max(duration, toNumber(target.statuses.timeLockedTurns ?? 0));
    target.statuses.timelocked = true;
    triggerBattleVfx('debuff', { targetId: target.id, vfxSpec: { ...spellVfx, color: '#a4c3ff', impactType: 'status-freeze' } });
    hint = `${card.name}: ${target.name} is Time-Locked for ${duration} turn(s).`;
  } else if (action === 'tax') {
    if (isPlayer) state.enemyTurnTax = (state.enemyTurnTax ?? 0) + amount;
    else state.playerTurnTax = (state.playerTurnTax ?? 0) + amount;
    triggerBattleVfx('debuff', { targetId: isPlayer ? 'enemy-hero' : 'player-hero', toEl: enemyHeroEl, vfxSpec: { ...spellVfx, color: '#ffe59a', impactType: 'status-shock' } });
    hint = `${card.name}: taxed next enemy turn by ${amount} mana.`;
  } else if (action === 'sentence') {
    const target = explicitEnemyMinion ?? getPriorityEnemyTarget(enemyLane);
    if (!target) return { ok: false, message: `${card.name} needs an enemy minion target.` };
    target.statuses.sentenceTurns = Math.max(duration, toNumber(target.statuses.sentenceTurns ?? 0));
    triggerBattleVfx('debuff', { targetId: target.id, vfxSpec: { ...spellVfx, color: '#ffb99a', impactType: 'status-burn' } });
    hint = `${card.name}: ${target.name} is Sentenced for ${duration} turn(s).`;
  } else if (action === 'summon') {
    const openSlots = Array.from({ length: MAX_SLOTS }, (_, idx) => idx).filter((idx) => !getSlotOccupant(allyLane, idx));
    const count = Math.min(openSlots.length, Math.max(1, spellEffect.summonCount));
    if (count <= 0) return { ok: false, message: `${card.name} has no free board slots to summon into.` };
    for (let i = 0; i < count; i += 1) {
      const token = ensureCombatFields({
        id: uid(isPlayer ? 'ptok' : 'etok'),
        name: `${card.name} Token`,
        type: 'minion',
        attack: Math.max(1, Math.floor(amount / 2) || 1),
        health: Math.max(1, Math.ceil(amount / 2) || 1),
        maxHealth: Math.max(1, Math.ceil(amount / 2) || 1),
        baseDef: 0,
        defense: false,
        defenseDurability: 0,
        taunt: false,
        baseTaunt: false,
        race: 'token',
        element: card.element ?? 'arcane',
        statuses: {},
        rarity: 'common',
        charge: false,
        summoningSick: true,
        slot: openSlots[i],
      });
      allyLane.push(token);
      triggerBattleVfx('summon', { targetId: token.id, vfxSpec: getCardVfxSpec(card, 'summon') ?? VFX_DEFAULTS.summon });
    }
    hint = `${card.name}: summoned ${count} token(s).`;
  } else {
    const target = getPriorityEnemyTarget(enemyLane);
    if (target) {
      const hit = applyDamageToUnit(target, scaledDamage, { pierce, trueDamage, damageType, breakOnHit: true });
      spawnDamageNumber(document.querySelector(`[data-id="${target.id}"]`), hit.damageTaken, card.element ?? target.element ?? 'arcane');
      triggerBattleVfx('cast', { targetId: target.id, vfxSpec: spellVfx });
      hint = `${card.name}: dealt ${hit.damageTaken} to ${target.name}.`;
    } else {
      const hit = applyDamageToCore(isPlayer ? 'enemy' : 'player', scaledDamage, { pierce, trueDamage, damageType });
      spawnDamageNumber(enemyHeroEl, hit.damageTaken, card.element ?? 'arcane');
      triggerBattleVfx('cast', { targetId: isPlayer ? 'enemy-hero' : 'player-hero', toEl: enemyHeroEl, vfxSpec: spellVfx });
      hint = `${card.name}: dealt ${hit.damageTaken} to enemy hero.`;
    }
  }

  return { ok: true, message: hint };
}

function playCard(cardId, slotOverride = null, targetOverride = null) {
  const index = state.hand.findIndex((c) => c.instanceId === cardId);
  if (index === -1) return false;
  const card = state.hand[index];
  const cardType = normalizeCardType(card);
  const spellLike = ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(cardType);
  const discount = spellLike ? firstSpellDiscount('player') : 0;
  const effectiveCost = effectiveCardCost(card, 'player', discount);
  if (state.currentTurn !== 'player') { showHint('Wait for your turn.'); return false; }
  if (effectiveCost > state.mana) { showHint(explainInvalidAction('mana')); return false; }
  if ((cardType === 'spell' || cardType === 'sorcery') && !isMainPhase()) {
    showHint('Sorcery-speed cards can only be played in Main Phase 1 or Main Phase 2.');
    return false;
  }
  if ((cardType === 'instant' || cardType === 'trap') && !isMainPhase() && !isResponsePhase()) {
    showHint('Instants/Traps require an open response window or main phase.');
    return false;
  }

  if (cardType === 'minion') {
    if (state.playerMinions.length >= MAX_SLOTS) { showHint(`Board is full (${MAX_SLOTS}/${MAX_SLOTS}).`); return false; }
    const slot = slotOverride ?? state.selectedPlayerSlot;
    if (slot == null || slot < 0 || slot >= MAX_SLOTS) { showHint('Select a board slot first.'); return false; }
    if (getSlotOccupant(state.playerMinions, slot)) { showHint('That slot is occupied. Choose another slot.'); return false; }
    const row = slotRow(slot);
    let occupiedSlots = [slot];
    const loweredText = cardText(card).toLowerCase();
    const hasLarge = !!card.large || (Array.isArray(card.keywords) && card.keywords.some((k) => String(k).toLowerCase() === 'large'));
    if (hasLarge) {
      const mate = slot + 1;
      if (slotLane(slot) === ROW_SIZE - 1 || slotRow(mate) !== row || getSlotOccupant(state.playerMinions, mate)) {
        showHint('Large creature needs two adjacent free slots in the same row.');
        return false;
      }
      occupiedSlots = [slot, mate];
    }
    const conditionalImmediate = /can attack immediately if an enemy is damaged/.test(loweredText)
      && (damagedMinions('enemy').length > 0 || state.enemyHealth < state.enemyMaxHealth);
    const temporaryHeroLock = /can't attack heroes this turn when summoned/.test(loweredText);
    const permanentHeroLock = /can't attack heroes while enemy minions are alive/.test(loweredText);
    const summon = ensureCombatFields({
      id: uid('m'),
      name: card.name,
      type: 'minion',
      attack: card.attack,
      health: card.health,
      maxHealth: card.health,
      taunt: !!card.taunt,
      baseTaunt: !!card.taunt,
      baseDef: Math.max(0, toNumber(card.def ?? card.baseDef ?? 0)),
      defense: false,
      defenseDurability: 0,
      race: extractCardRaces(card)[0] ?? card.race ?? 'neutral',
      races: extractCardRaces(card),
      element: card.element ?? 'none',
      statuses: {},
      rarity: card.rarity ?? 'common',
      level: card.level ?? 1,
      pierce: Math.max(0, toNumber(card.pierce ?? 0)),
      trueDamage: !!card.trueDamage,
      allowFriendlyAttack: !!card.allowFriendlyAttack,
      allowMultiAttack: !!card.allowMultiAttack,
      charge: !!card.charge || conditionalImmediate,
      cannotHitHero: !!card.cannotHitHero || permanentHeroLock,
      cannotHitHeroThisTurn: temporaryHeroLock,
      effect: getCardEffect(card),
      ability: getCardEffect(card),
      text: card.text ?? '',
      tags: card.tags ?? [],
      keywords: card.keywords ?? card.tags ?? [],
      summoningSick: !(!!card.charge || conditionalImmediate),
      slot,
      occupiedSlots,
      row,
      large: hasLarge,
    });
    state.hand.splice(index, 1);
    state.mana -= effectiveCost;
    noteTurnFlag('player', 'playedMinion', 1);
    noteTurnFlag('player', 'cardsPlayed', 1);
    noteFamilyTurnFlag('player', 'playedFamilies', summon);
    state.playerMinions.push(summon);
    seedCardFamiliarity('player', summon);
    refreshAllPassiveAuras();
    triggerAbilityEvent('player', 'on_summon_friendly', { side: 'player', self: summon, summoned: summon });
    triggerAbilityEvent('player', 'on_play_card', { side: 'player', playedCard: summon, target: summon, self: summon });
    if (cardMatchesFamily(summon, 'ship')) triggerAbilityEvent('player', 'on_play_ship', { side: 'player', playedCard: summon, target: summon, self: summon });
    triggerUnitAbilityEvent(summon, 'player', 'on_play', { side: 'player', self: summon, card });
    pushDevActionTrace(`Player summon: ${card.name} -> slot ${slot + 1}`, 'player');
    state.selectedCardId = null;
    setDeckTrackerStatus('player', card.instanceId, 'played');
    triggerBattleVfx('cast', { cardId: card.id, vfxSpec: getCardVfxSpec(card, 'cast') ?? VFX_DEFAULTS.cast });
    bumpQuestMetric('cardsPlayed', 1);
    observePlayerActionForAi(card, { reason: 'player-play-minion' });
    showHint(`${card.name} placed in slot ${slot + 1}.`);
    setPhase('main2');
    render(); renderPanels();
    return true;
  }

  if (cardType === 'field') {
    const perm = { ...card, type: 'field', effect: getCardEffect(card), instanceId: card.instanceId };
    state.hand.splice(index, 1);
    state.mana -= effectiveCost;
    noteTurnFlag('player', 'cardsPlayed', 1);
    noteFamilyTurnFlag('player', 'playedFamilies', perm);
    state.selectedCardId = null;
    setDeckTrackerStatus('player', card.instanceId, 'played');
    state.playerFields.push(perm);
    noteTurnFlag('player', 'playedField', 1);
    seedCardFamiliarity('player', perm);
    refreshAllPassiveAuras();
    triggerAbilityEvent('player', 'on_play_card', { side: 'player', playedCard: perm, target: perm, self: perm });
    triggerUnitAbilityEvent(perm, 'player', 'on_play', { side: 'player', card: perm, self: perm });
    pushDevActionTrace(`Player field: ${card.name}`, 'player');
    pushStackEntry({
      label: `Field enters: ${card.name}`,
      resolve: () => {
        applyFieldStartEffects('player');
        showHint(`${card.name} enters as an active Mana Field.`);
      },
    });
    resolveStack();
    bumpQuestMetric('cardsPlayed', 1);
    observePlayerActionForAi(card, { reason: 'player-play-field' });
    setPhase('main2');
    render(); renderPanels();
    return true;
  }

  if (cardType === 'relic' || cardType === 'artifact' || cardType === 'aura' || cardType === 'trap') {
    const perm = { ...card, type: cardType === 'artifact' ? 'relic' : cardType, effect: getCardEffect(card), instanceId: card.instanceId };
    state.hand.splice(index, 1);
    state.mana -= effectiveCost;
    noteTurnFlag('player', 'cardsPlayed', 1);
    noteFamilyTurnFlag('player', 'playedFamilies', perm);
    state.selectedCardId = null;
    setDeckTrackerStatus('player', card.instanceId, 'played');
    state.playerRelics.push(perm);
    seedCardFamiliarity('player', perm);
    refreshAllPassiveAuras();
    triggerAbilityEvent('player', 'on_play_card', { side: 'player', playedCard: perm, target: perm, self: perm });
    triggerAbilityEvent('player', 'on_play_relic', { side: 'player', playedCard: perm, target: perm, self: perm });
    triggerUnitAbilityEvent(perm, 'player', 'on_play', { side: 'player', card: perm, self: perm });
    pushDevActionTrace(`Player permanent: ${card.name}`, 'player');
    pushStackEntry({ label: `Permanent enters: ${card.name}`, resolve: () => showHint(`${card.name} is now active.`) });
    resolveStack();
    bumpQuestMetric('cardsPlayed', 1);
    observePlayerActionForAi(card, { reason: 'player-play-permanent' });
    setPhase('main2');
    render(); renderPanels();
    return true;
  }

  if (cardType === 'barricade' || cardType === 'structure') {
    const slot = slotOverride ?? state.selectedPlayerSlot;
    if (slot == null || slot < 0 || slot >= MAX_SLOTS) { showHint('Select a front-row lane for the barricade.'); return false; }
    const lane = slotLane(slot);
    if (state.playerBarricades[lane] && (state.playerBarricades[lane].health ?? 0) > 0) {
      showHint(`Lane ${lane + 1} already has a barricade.`);
      return false;
    }
    const barricade = {
      id: uid('bar'),
      name: card.name,
      type: 'barricade',
      lane,
      health: Math.max(1, toNumber(card.health ?? card.durability ?? 6, 6)),
      maxHealth: Math.max(1, toNumber(card.health ?? card.durability ?? 6, 6)),
      def: Math.max(0, toNumber(card.def ?? card.baseDef ?? 1, 1)),
      text: card.text ?? '',
      tags: card.tags ?? [],
      effect: getCardEffect(card),
    };
    state.hand.splice(index, 1);
    state.mana -= effectiveCost;
    noteTurnFlag('player', 'cardsPlayed', 1);
    noteFamilyTurnFlag('player', 'playedFamilies', barricade);
    state.selectedCardId = null;
    state.playerBarricades[lane] = barricade;
    refreshAllPassiveAuras();
    triggerAbilityEvent('player', 'on_play_card', { side: 'player', playedCard: barricade, target: barricade, self: barricade });
    triggerUnitAbilityEvent(barricade, 'player', 'on_play', { side: 'player', card: barricade, self: barricade });
    pushDevActionTrace(`Player barricade: ${card.name} lane ${lane + 1}`, 'player');
    setDeckTrackerStatus('player', card.instanceId, 'played');
    pushStackEntry({ label: `Barricade deployed: ${card.name}`, resolve: () => showHint(`${card.name} now blocks lane ${lane + 1}.`) });
    resolveStack();
    bumpQuestMetric('cardsPlayed', 1);
    observePlayerActionForAi(card, { reason: 'player-play-barricade' });
    setPhase('main2');
    render(); renderPanels();
    return true;
  }

  if (spellLike) {
    const beforeSnapshot = {
      enemyBoard: state.enemyMinions.length,
      enemyHealth: state.enemyHealth,
    };
    const resultHolder = { ok: true, message: '' };
    pushStackEntry({
      label: `${card.name} (${cardType})`,
      resolve: () => {
        const result = executeSpellCard(card, 'player', targetOverride);
        resultHolder.ok = !!result?.ok;
        resultHolder.message = result?.message ?? '';
      },
    });
    resolveStack();
    if (!resultHolder.ok) {
      state.stack = [];
      showHint(resultHolder.message || `${card.name} has no legal target.`);
      return false;
    }
    state.hand.splice(index, 1);
    state.mana -= effectiveCost;
    noteTurnFlag('player', 'playedSpell', 1);
    noteTurnFlag('player', 'cardsPlayed', 1);
    noteFamilyTurnFlag('player', 'playedFamilies', card);
    seedCardFamiliarity('player', card);
    if (!getTurnFlags('player').firstSpellCard) getTurnFlags('player').firstSpellCard = { ...card };
    if (isBlessingCard(card)) noteTurnFlag('player', 'castBlessing', 1);
    state.selectedSpellTargetMode = false;
    state.selectedCardId = null;
    triggerAbilityEvent('player', 'on_spell_cast', {
      side: 'player',
      card,
      sourceCard: card,
      castMeta: { fromHand: true },
      target: targetOverride ? { id: targetOverride } : null,
      source: 'spell',
    });
    triggerAbilityEvent('player', 'on_play_card', { side: 'player', playedCard: card, target: targetOverride ? { id: targetOverride } : null, self: card });
    pushToZone('player', 'graveyard', { ...card, type: cardType });
    pushDevActionTrace(`Player cast: ${card.name}`, 'player');
    setDeckTrackerStatus('player', card.instanceId, 'played');
    bumpQuestMetric('cardsPlayed', 1);
    cleanupDead();
    observePlayerActionForAi(card, {
      reason: 'player-cast-spell',
      kills: Math.max(0, beforeSnapshot.enemyBoard - state.enemyMinions.length),
      damageToEnemy: Math.max(0, beforeSnapshot.enemyHealth - state.enemyHealth),
      boardClear: Math.max(0, beforeSnapshot.enemyBoard - state.enemyMinions.length) >= 2,
      combo: /draw|discover|copy|reduce .* cost|look at the top|reorder|familiarity/.test(String(card.text ?? '').toLowerCase()),
    });
    if (resultHolder.message) showHint(resultHolder.message);
    setPhase('main2');
    render(); renderPanels();
    return true;
  }
  return false;
}

function classifyEnemyPlayOutcome(card = {}, before = {}, after = {}, cardType = 'minion', effectiveCost = 0) {
  const text = cardText(card).toLowerCase();
  const playerKills = Math.max(0, Number(before.playerBoard ?? 0) - Number(after.playerBoard ?? 0));
  const enemyHeal = Math.max(0, Number(after.enemyHealth ?? 0) - Number(before.enemyHealth ?? 0));
  const playerDamage = Math.max(0, Number(before.playerHealth ?? 0) - Number(after.playerHealth ?? 0));
  const categories = [];

  if (card.justDrawn && (/destroy|deal \d+ damage|restore|heal|freeze|silence/.test(text) || playerKills > 0 || enemyHeal > 0)) {
    categories.push('topdeck_answer');
  }
  if (playerKills >= 2 || /all enemy minions|split among enemies|destroy all|deal .* all/.test(text)) categories.push('board_clear');
  if (!categories.includes('board_clear') && (playerKills >= 1 || /destroy|silence|freeze|return .* hand/.test(text))) categories.push('removal_used');
  if (enemyHeal > 0 && (before.enemyHealth ?? 30) <= 12) categories.push('stabilizing');
  if ((String(card.rarity ?? '').toLowerCase() === 'legendary') || effectiveCost >= 7 || ['field', 'relic', 'artifact', 'aura', 'trap', 'barricade'].includes(cardType)) {
    categories.push('signature_play');
  }
  if (/draw|discover|look at the top|reorder|copy|reduce .* cost|familiarity/.test(text)) categories.push('combo_assembled');
  if (playerDamage >= 4 || (cardType === 'minion' && (card.attack ?? 0) >= 5)) categories.push('early_pressure');
  if (!categories.length) categories.push('early_pressure');
  return [...new Set(categories)];
}

function playEnemyCardFromHand(action = {}, profile = currentAiProfile()) {
  const index = Math.max(0, Math.min(Number(action.handIndex ?? -1), Math.max(0, state.enemyHand.length - 1)));
  const card = state.enemyHand[index];
  if (!card) return { ok: false, message: 'Enemy card not found.' };
  const cardType = normalizeCardType(card);
  const spellLike = ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(cardType);
  const discount = spellLike ? firstSpellDiscount('enemy') : 0;
  const effectiveCost = effectiveCardCost(card, 'enemy', discount);
  if (effectiveCost > state.enemyMana) return { ok: false, message: 'Enemy lacks mana.' };
  const before = {
    playerBoard: state.playerMinions.length,
    enemyBoard: state.enemyMinions.length,
    playerHealth: state.playerHealth,
    enemyHealth: state.enemyHealth,
  };

  if (cardType === 'minion') {
    const slot = action.slot ?? firstOpenSlot(state.enemyMinions);
    if (slot == null || slot < 0 || slot >= MAX_SLOTS || getSlotOccupant(state.enemyMinions, slot)) return { ok: false, message: 'No legal enemy slot.' };
    const loweredText = cardText(card).toLowerCase();
    const conditionalImmediate = /can attack immediately if an enemy is damaged/.test(loweredText) && (damagedMinions('player').length > 0 || state.playerHealth < state.playerMaxHealth);
    const temporaryHeroLock = /can't attack heroes this turn when summoned/.test(loweredText);
    const permanentHeroLock = /can't attack heroes while enemy minions are alive/.test(loweredText);
    const summon = ensureCombatFields({
      id: uid('enemy'),
      name: card.name,
      type: 'minion',
      attack: card.attack,
      health: card.health,
      maxHealth: card.health,
      taunt: !!card.taunt,
      baseTaunt: !!card.taunt,
      baseDef: Math.max(0, toNumber(card.def ?? card.baseDef ?? 0)),
      defense: false,
      defenseDurability: 0,
      race: extractCardRaces(card)[0] ?? card.race ?? 'neutral',
      races: extractCardRaces(card),
      element: card.element ?? 'none',
      statuses: {},
      rarity: card.rarity ?? 'common',
      level: card.level ?? 1,
      pierce: Math.max(0, toNumber(card.pierce ?? 0)),
      trueDamage: !!card.trueDamage,
      allowFriendlyAttack: !!card.allowFriendlyAttack,
      allowMultiAttack: !!card.allowMultiAttack,
      charge: !!card.charge || conditionalImmediate,
      cannotHitHero: !!card.cannotHitHero || permanentHeroLock,
      cannotHitHeroThisTurn: temporaryHeroLock,
      effect: getCardEffect(card),
      ability: getCardEffect(card),
      text: card.text ?? '',
      tags: card.tags ?? [],
      keywords: card.keywords ?? card.tags ?? [],
      summoningSick: !(!!card.charge || conditionalImmediate),
      slot,
    });
    state.enemyHand.splice(index, 1);
    state.enemyMana -= effectiveCost;
    noteTurnFlag('enemy', 'playedMinion', 1);
    noteTurnFlag('enemy', 'cardsPlayed', 1);
    noteFamilyTurnFlag('enemy', 'playedFamilies', summon);
    state.enemyMinions.push(summon);
    seedCardFamiliarity('enemy', summon);
    refreshAllPassiveAuras();
    triggerAbilityEvent('enemy', 'on_summon_friendly', { side: 'enemy', self: summon, summoned: summon });
    triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: summon, target: summon, self: summon });
    if (cardMatchesFamily(summon, 'ship')) triggerAbilityEvent('enemy', 'on_play_ship', { side: 'enemy', playedCard: summon, target: summon, self: summon });
    triggerUnitAbilityEvent(summon, 'enemy', 'on_play', { side: 'enemy', self: summon, card });
    setDeckTrackerStatus('enemy', card.instanceId, 'played');
    card.justDrawn = false;
    return {
      ok: true,
      categories: classifyEnemyPlayOutcome(card, before, {
        playerBoard: state.playerMinions.length,
        enemyBoard: state.enemyMinions.length,
        playerHealth: state.playerHealth,
        enemyHealth: state.enemyHealth,
      }, cardType, effectiveCost),
      card,
    };
  }

  if (cardType === 'field') {
    const perm = { ...card, type: 'field', effect: getCardEffect(card), instanceId: card.instanceId };
    state.enemyHand.splice(index, 1);
    state.enemyMana -= effectiveCost;
    noteTurnFlag('enemy', 'cardsPlayed', 1);
    noteFamilyTurnFlag('enemy', 'playedFamilies', perm);
    state.enemyFields.push(perm);
    noteTurnFlag('enemy', 'playedField', 1);
    seedCardFamiliarity('enemy', perm);
    refreshAllPassiveAuras();
    triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: perm, target: perm, self: perm });
    triggerUnitAbilityEvent(perm, 'enemy', 'on_play', { side: 'enemy', card: perm, self: perm });
    setDeckTrackerStatus('enemy', card.instanceId, 'played');
    card.justDrawn = false;
    return {
      ok: true,
      categories: classifyEnemyPlayOutcome(card, before, {
        playerBoard: state.playerMinions.length,
        enemyBoard: state.enemyMinions.length,
        playerHealth: state.playerHealth,
        enemyHealth: state.enemyHealth,
      }, cardType, effectiveCost),
      card,
    };
  }

  if (cardType === 'relic' || cardType === 'artifact' || cardType === 'aura' || cardType === 'trap') {
    const perm = { ...card, type: cardType === 'artifact' ? 'relic' : cardType, effect: getCardEffect(card), instanceId: card.instanceId };
    state.enemyHand.splice(index, 1);
    state.enemyMana -= effectiveCost;
    noteTurnFlag('enemy', 'cardsPlayed', 1);
    noteFamilyTurnFlag('enemy', 'playedFamilies', perm);
    state.enemyRelics.push(perm);
    seedCardFamiliarity('enemy', perm);
    refreshAllPassiveAuras();
    triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: perm, target: perm, self: perm });
    triggerAbilityEvent('enemy', 'on_play_relic', { side: 'enemy', playedCard: perm, target: perm, self: perm });
    triggerUnitAbilityEvent(perm, 'enemy', 'on_play', { side: 'enemy', card: perm, self: perm });
    setDeckTrackerStatus('enemy', card.instanceId, 'played');
    card.justDrawn = false;
    return {
      ok: true,
      categories: classifyEnemyPlayOutcome(card, before, {
        playerBoard: state.playerMinions.length,
        enemyBoard: state.enemyMinions.length,
        playerHealth: state.playerHealth,
        enemyHealth: state.enemyHealth,
      }, cardType, effectiveCost),
      card,
    };
  }

  if (cardType === 'barricade') {
    const lane = Math.max(0, Math.min(ROW_SIZE - 1, Number(action.lane ?? 0)));
    if (state.enemyBarricades[lane] && (state.enemyBarricades[lane].health ?? 0) > 0) return { ok: false, message: 'Lane already blocked.' };
    const barricade = {
      id: uid('ebar'),
      name: card.name,
      type: 'barricade',
      lane,
      health: Math.max(1, toNumber(card.health ?? card.durability ?? 6, 6)),
      maxHealth: Math.max(1, toNumber(card.health ?? card.durability ?? 6, 6)),
      def: Math.max(0, toNumber(card.def ?? card.baseDef ?? 1, 1)),
      text: card.text ?? '',
      tags: card.tags ?? [],
      effect: getCardEffect(card),
    };
    state.enemyHand.splice(index, 1);
    state.enemyMana -= effectiveCost;
    noteTurnFlag('enemy', 'cardsPlayed', 1);
    noteFamilyTurnFlag('enemy', 'playedFamilies', barricade);
    state.enemyBarricades[lane] = barricade;
    refreshAllPassiveAuras();
    triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: barricade, target: barricade, self: barricade });
    triggerUnitAbilityEvent(barricade, 'enemy', 'on_play', { side: 'enemy', card: barricade, self: barricade });
    setDeckTrackerStatus('enemy', card.instanceId, 'played');
    card.justDrawn = false;
    return {
      ok: true,
      categories: classifyEnemyPlayOutcome(card, before, {
        playerBoard: state.playerMinions.length,
        enemyBoard: state.enemyMinions.length,
        playerHealth: state.playerHealth,
        enemyHealth: state.enemyHealth,
      }, cardType, effectiveCost),
      card,
    };
  }

  if (spellLike) {
    const result = executeSpellCard(card, 'enemy', action.targetId ?? null, { fromHand: true });
    if (!result?.ok) return { ok: false, message: result?.message ?? 'No legal enemy spell target.' };
    state.enemyHand.splice(index, 1);
    state.enemyMana -= effectiveCost;
    noteTurnFlag('enemy', 'playedSpell', 1);
    noteTurnFlag('enemy', 'cardsPlayed', 1);
    noteFamilyTurnFlag('enemy', 'playedFamilies', card);
    seedCardFamiliarity('enemy', card);
    if (!getTurnFlags('enemy').firstSpellCard) getTurnFlags('enemy').firstSpellCard = { ...card };
    triggerAbilityEvent('enemy', 'on_spell_cast', { side: 'enemy', card, sourceCard: card, castMeta: { fromHand: true }, target: action.targetId ? { id: action.targetId } : null, source: 'spell' });
    triggerAbilityEvent('enemy', 'on_play_card', { side: 'enemy', playedCard: card, target: action.targetId ? { id: action.targetId } : null, self: card });
    pushToZone('enemy', 'graveyard', { ...card, type: cardType });
    setDeckTrackerStatus('enemy', card.instanceId, 'played');
    cleanupDead();
    card.justDrawn = false;
    return {
      ok: true,
      categories: classifyEnemyPlayOutcome(card, before, {
        playerBoard: state.playerMinions.length,
        enemyBoard: state.enemyMinions.length,
        playerHealth: state.playerHealth,
        enemyHealth: state.enemyHealth,
      }, cardType, effectiveCost),
      card,
      message: result?.message ?? '',
    };
  }

  return { ok: false, message: 'Unsupported enemy card type.' };
}

function attackWith(attackerId, targetId) {
  const validation = validateAttack('player', attackerId, targetId);
  if (!validation.ok) {
    showHint(validation.message);
    toast(validation.message, 'error');
    return false;
  }
  const attacker = validation.attacker;
  noteTurnFlag('player', 'attacked', 1);
  triggerUnitAbilityEvent(attacker, 'player', 'on_attack_self', { side: 'player', self: attacker, target: validation.target ?? null });
  triggerAbilityEvent('player', 'on_attack_any', { side: 'player', self: attacker, target: validation.target ?? null });
  consumeStealthOnAttack('player', attacker);
  pushDevActionTrace(`Player attack declared: ${attacker?.name ?? attackerId} -> ${targetId}`, 'player');
  const used = state.usedAttacks[attacker.id] ?? 0;
  const attackerEl = document.querySelector(`[data-id="${attacker.id}"]`);
  let targetEl = null;
  let scoredKill = false;
  let directKillVictim = null;
  let directKillDamage = 0;
  let directKillHealthBefore = 0;

  setPhase('declare_attackers');
  setPhase('response');
  resolveStack();
  setPhase('declare_blockers');

  if (validation.targetType === 'barricade') {
    const barricade = validation.target;
    const lane = slotLane(attacker.slot ?? 0);
    const atkValue = currentAttackValue(attacker, 'player', barricade);
    const barricadeHealthBefore = Math.max(0, toNumber(barricade?.health, 0));
    if (!barricade) {
      showHint('Barricade target was not found.');
      return false;
    }
    const taken = Math.max(0, Math.max(0, atkValue) - Math.max(0, toNumber(barricade.def, 0)));
    barricade.health -= taken;
    state.usedAttacks[attacker.id] = used + 1;
    triggerBattleVfx('attack', { attackerId, targetId: barricade.id, fromEl: attackerEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
    showHint(`${attacker.name} hits ${barricade.name} for ${taken}.`);
    if (barricade.health <= 0) {
      pushToZone('enemy', 'graveyard', barricade);
      state.enemyBarricades[lane] = null;
      showHint(`${barricade.name} was destroyed.`);
      scoredKill = true;
    }
    setPhase('combat');
    resolveStack();
    setPhase('main2');
    cleanupDead();
    if (scoredKill) emitKillAndOverkillEvents('player', attacker, barricade, taken, barricadeHealthBefore);
    render();
    return true;
  }

  const requestedTarget = validation.targetType === 'minion' ? validation.target : null;
  const canAutoBlock = validation.targetType === 'hero' || (requestedTarget && slotRow(requestedTarget.slot ?? 0) === 'back');
  let blocker = canAutoBlock ? chooseAutoBlocker(attacker, state.enemyMinions, requestedTarget) : null;
  if (blocker && (blocker.health ?? 0) <= 0) blocker = null;
  if (blocker) {
    const defender = ensureCombatFields(blocker);
    const defenderHealthBefore = Math.max(0, toNumber(defender?.health, 0));
    const defenderEl = document.querySelector(`[data-id="${defender.id}"]`);
    targetEl = defenderEl;
    const defenderWasDamagedBefore = (defender.health ?? 0) < (defender.maxHealth ?? defender.health ?? 0);
    const attackerWasDamagedBefore = (attacker.health ?? 0) < (attacker.maxHealth ?? attacker.health ?? 0);
    const combatAttacker = { ...attacker, attack: currentAttackValue(attacker, 'player', defender) };
    const combatDefender = { ...defender, attack: currentAttackValue(defender, 'enemy', attacker) };
    const result = resolveCombat(combatAttacker, combatDefender, state, 'player');
    const defenderHit = applyDamageToUnit(defender, result.damageToDefender, { pierce: attacker.pierce, trueDamage: attacker.trueDamage, damageType: attacker.damageType ?? attacker.element, breakOnHit: true });
    consumeMarkedAttackBonus(defender);
    const attackerHit = applyDamageToUnit(attacker, result.damageToAttacker, { pierce: defender.pierce, trueDamage: defender.trueDamage, damageType: defender.damageType ?? defender.element, breakOnHit: true });
    if (attacker.poisonousVsDamaged && defenderWasDamagedBefore && defenderHit.damageTaken > 0) defender.health = 0;
    if (defender.poisonousVsDamaged && attackerWasDamagedBefore && attackerHit.damageTaken > 0) attacker.health = 0;
    spawnDamageNumber(defenderEl, defenderHit.damageTaken, attacker.element ?? defender.element);
    spawnDamageNumber(attackerEl, attackerHit.damageTaken, defender.element ?? 'shadow');
    drawAttackLine(attackerEl, defenderEl);
    state.usedAttacks[attacker.id] = used + 1;
    triggerBattleVfx('attack', { attackerId, targetId: defender.id, fromEl: attackerEl, toEl: defenderEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
    showHint(`${defender.name} blocks the attack.`);
    scoredKill = (defender.health ?? 0) <= 0;
    setPhase('combat');
    resolveStack();
    setPhase('main2');
    cleanupDead();
    if (scoredKill) emitKillAndOverkillEvents('player', attacker, defender, defenderHit.damageTaken, defenderHealthBefore);
    render();
    return true;
  }

  if (validation.targetType === 'hero') {
    targetEl = document.querySelector('[data-target-id="enemy-hero"]');
    const atkValue = currentAttackValue(attacker, 'player', null);
    const heroHit = applyDamageToCore('enemy', atkValue, { pierce: attacker.pierce, trueDamage: attacker.trueDamage, damageType: attacker.damageType ?? attacker.element, breakOnHit: true });
    spawnDamageNumber(targetEl, heroHit.damageTaken, attacker.element ?? 'arcane');
    if (attackerEl) {
      attackerEl.classList.add('recoil');
      setTimeout(() => attackerEl.classList.remove('recoil'), 160);
    }
  } else {
    const defender = ensureCombatFields(validation.target);
    if (!defender) {
      showHint(explainAttackFailure('target_missing', { targetId }));
      return false;
    }
    const defenderHealthBefore = Math.max(0, toNumber(defender?.health, 0));
    const defenderEl = document.querySelector(`[data-id="${defender.id}"]`);
    targetEl = defenderEl;
    const defenderWasDamagedBefore = (defender.health ?? 0) < (defender.maxHealth ?? defender.health ?? 0);
    const attackerWasDamagedBefore = (attacker.health ?? 0) < (attacker.maxHealth ?? attacker.health ?? 0);
    const combatAttacker = { ...attacker, attack: currentAttackValue(attacker, 'player', defender) };
    const combatDefender = { ...defender, attack: currentAttackValue(defender, 'enemy', attacker) };
    const result = resolveCombat(combatAttacker, combatDefender, state, 'player');
    const defenderHit = applyDamageToUnit(defender, result.damageToDefender, { pierce: attacker.pierce, trueDamage: attacker.trueDamage, damageType: attacker.damageType ?? attacker.element, breakOnHit: true });
    consumeMarkedAttackBonus(defender);
    const attackerHit = applyDamageToUnit(attacker, result.damageToAttacker, { pierce: defender.pierce, trueDamage: defender.trueDamage, damageType: defender.damageType ?? defender.element, breakOnHit: true });
    if (attacker.poisonousVsDamaged && defenderWasDamagedBefore && defenderHit.damageTaken > 0) defender.health = 0;
    if (defender.poisonousVsDamaged && attackerWasDamagedBefore && attackerHit.damageTaken > 0) attacker.health = 0;
    spawnDamageNumber(defenderEl, defenderHit.damageTaken, attacker.element ?? defender.element);
    spawnDamageNumber(attackerEl, attackerHit.damageTaken, defender.element ?? 'shadow');
    if (attackerEl) attackerEl.classList.add('recoil');
    if (defenderEl) defenderEl.classList.add('recoil');
    setTimeout(() => {
      attackerEl?.classList.remove('recoil');
      defenderEl?.classList.remove('recoil');
    }, 180);
    if (defenderHit.blocked > 0) triggerBattleVfx('defense-enter', { targetId: defender.id, fromEl: attackerEl, toEl: defenderEl, vfxSpec: VFX_DEFAULTS['defense-enter'] });
    if (attacker.pierce > 0 || attacker.trueDamage) triggerBattleVfx('pierce', { targetId: defender.id, fromEl: attackerEl, toEl: defenderEl, vfxSpec: { ...VFX_DEFAULTS.attack, color: '#ffd58a', projectileType: 'lance', impactType: 'shatter', screenShakeAmount: 0.4 } });
    scoredKill = (defender.health ?? 0) <= 0;
    directKillVictim = defender;
    directKillDamage = defenderHit.damageTaken;
    directKillHealthBefore = defenderHealthBefore;
  }
  drawAttackLine(attackerEl, targetEl);
  state.usedAttacks[attacker.id] = used + 1;
  pushDevActionTrace(`Player attack resolved: ${attacker?.name ?? attackerId} -> ${targetId}`, 'player');
  triggerBattleVfx('attack', { attackerId, targetId, fromEl: attackerEl, toEl: targetEl, vfxSpec: getCardVfxSpec(attacker, 'attack') ?? VFX_DEFAULTS.attack });
  state.selectedAttackerId = null;
  clearHighlights();
  showHint('');
  setPhase('combat');
  resolveStack();
  setPhase('main2');
  cleanupDead();
  if (validation.targetType === 'hero' && currentAiProfile()) {
    maybeSpeakAiEvent(currentAiProfile(), state.enemyHealth <= 8 ? 'near_death' : 'under_pressure', state.enemyHealth <= 8 ? 0.72 : 0.34);
  }
  if (scoredKill && validation.targetType === 'minion') emitKillAndOverkillEvents('player', attacker, directKillVictim, directKillDamage, directKillHealthBefore);
  render();
  return true;
}
function cleanupDead() {
  const deadPlayer = state.playerMinions.filter((m) => m.health <= 0);
  const deadEnemy = state.enemyMinions.filter((m) => m.health <= 0);
  const activeAi = currentAiProfile();
  deadPlayer.forEach((unit) => {
    const el = document.querySelector(`[data-id="${unit.id}"]`);
    if (el) el.classList.add('kill-fade');
    noteTurnFlag('player', 'minionDied', 1);
    noteTurnFlag('enemy', 'minionDied', 1);
    noteTurnFlag('enemy', 'enemyMinionDied', 1);
    noteFamilyTurnFlag('player', 'diedFamilies', unit);
    noteFamilyTurnFlag('enemy', 'diedFamilies', unit);
    triggerUnitAbilityEvent(unit, 'player', 'on_death', { side: 'player', self: unit });
    triggerAbilityEvent('player', 'on_minion_death', { side: 'player', self: unit, target: unit, deadUnit: unit, deadSide: 'player' });
    triggerAbilityEvent('enemy', 'on_minion_death', { side: 'enemy', self: unit, target: unit, deadUnit: unit, deadSide: 'player' });
    triggerBattleVfx('kill', { targetId: unit.id, vfxSpec: getCardVfxSpec(unit, 'onDeath') ?? VFX_DEFAULTS.kill });
    pushToZone('player', 'graveyard', unit);
    if (unit.swarm) {
      const count = 2;
      for (let i = 0; i < count; i += 1) {
        const open = firstOpenSlot(state.playerMinions, slotRow(unit.slot ?? 0));
        if (open == null) break;
        state.playerMinions.push(ensureCombatFields({
          id: uid('swp'),
          name: `${unit.name} Fragment`,
          type: 'token',
          attack: 1,
          health: 1,
          maxHealth: 1,
          slot: open,
          row: slotRow(open),
          race: 'swarm',
          element: unit.element ?? 'none',
          tags: ['swarm', 'token'],
          swarm: true,
          summoningSick: true,
        }));
      }
    }
  });
  deadEnemy.forEach((unit) => {
    const el = document.querySelector(`[data-id="${unit.id}"]`);
    if (el) el.classList.add('kill-fade');
    noteTurnFlag('enemy', 'minionDied', 1);
    noteTurnFlag('player', 'minionDied', 1);
    noteTurnFlag('player', 'enemyMinionDied', 1);
    noteFamilyTurnFlag('enemy', 'diedFamilies', unit);
    noteFamilyTurnFlag('player', 'diedFamilies', unit);
    triggerUnitAbilityEvent(unit, 'enemy', 'on_death', { side: 'enemy', self: unit });
    triggerAbilityEvent('enemy', 'on_minion_death', { side: 'enemy', self: unit, target: unit, deadUnit: unit, deadSide: 'enemy' });
    triggerAbilityEvent('player', 'on_minion_death', { side: 'player', self: unit, target: unit, deadUnit: unit, deadSide: 'enemy' });
    triggerBattleVfx('kill', { targetId: unit.id, vfxSpec: getCardVfxSpec(unit, 'onKill') ?? VFX_DEFAULTS.kill });
    pushToZone('enemy', 'graveyard', unit);
    if (unit.swarm) {
      const count = 2;
      for (let i = 0; i < count; i += 1) {
        const open = firstOpenSlot(state.enemyMinions, slotRow(unit.slot ?? 0));
        if (open == null) break;
        state.enemyMinions.push(ensureCombatFields({
          id: uid('swe'),
          name: `${unit.name} Fragment`,
          type: 'token',
          attack: 1,
          health: 1,
          maxHealth: 1,
          slot: open,
          row: slotRow(open),
          race: 'swarm',
          element: unit.element ?? 'none',
          tags: ['swarm', 'token'],
          swarm: true,
          summoningSick: true,
        }));
      }
    }
  });
  if (activeAi && deadEnemy.length > 0) {
    const lostKeyThreat = deadEnemy.some((unit) => String(unit.rarity ?? '').toLowerCase() === 'legendary' || (unit.attack ?? 0) >= 6 || /engine|support|aura|field|relic/i.test(`${unit.text ?? ''} ${(unit.tags ?? []).join(' ')}`));
    if (lostKeyThreat) maybeSpeakAiEvent(activeAi, 'under_pressure', 0.46);
    else maybeSpeakAiEvent(activeAi, 'whiff', 0.22);
  }
  state.playerMinions = state.playerMinions.filter((m) => m.health > 0);
  state.enemyMinions = state.enemyMinions.filter((m) => m.health > 0);
  refreshAllPassiveAuras();
  if (state.matchResolved) return;

  if (state.enemyHealth <= 0) {
    const p = currentAiProfile();
    ensureProgressFields(state.profile);
    state.matchResolved = true;
    recordBattleOutcome('win', p);
    bumpBattleOutcomeQuestMetrics('win');
    const reward = calculateBattleWinGold(p);
    state.profile.economy.gold = Math.max(0, Number(state.profile.economy?.gold ?? 0)) + reward;
    if (p?.id) {
      state.profile.defeatedAiIds.push(p.id);
      state.profile.lobbyResidents.push(p.id);
      state.profile.defeatedAiIds = [...new Set(state.profile.defeatedAiIds)];
      state.profile.lobbyResidents = [...new Set(state.profile.lobbyResidents)];
      if (p.personality?.dimensionTag) {
        const code = `${p.personality.dimensionTag}-${(p.level ?? 1)}-${p.id}`;
        state.profile.carnexCodes[p.id] = code;
        state.profile.discoveredDimensions.push(p.personality.dimensionTag.replace('#', ''));
      }
    }
    state.profile.discoveredDimensions = [...new Set(state.profile.discoveredDimensions)];
    queueMatchResult('win', p);
    localStorage.removeItem(MATCH_KEY);
    localStorage.removeItem(MATCH_CONTEXT_KEY);
    persistProfile();
    const line = aiBanterLine(p ?? { id: 'unknown', name: 'Unknown', personality: {} }, 'defeat') || p?.personality?.victoryLine || `You found ${p?.personality?.dimensionTag ?? '#Unknown'}.`;
    if (p) speakAiLine(p, line);
    else log(line);
    if (p?.personality?.dimensionTag) log(`Dimension unlocked and moved to lobby: ${p.personality.dimensionTag.replace('#', '')}`);
    if (p?.id && state.profile.carnexCodes[p.id]) log(`Carnex code acquired: ${state.profile.carnexCodes[p.id]}`);
    log(`Victory reward: +${reward} gold.`);
    toast(`Victory reward +${reward}g.`, 'info');
    toast('AI defeated. Dimension unlocked.', 'info');
    clearResolvedBattlefield();
  } else if (state.playerHealth <= 0) {
    ensureProgressFields(state.profile);
    state.matchResolved = true;
    const p = currentAiProfile();
    recordBattleOutcome('loss', p);
    bumpBattleOutcomeQuestMetrics('loss');
    queueMatchResult('loss', p);
    localStorage.removeItem(MATCH_KEY);
    localStorage.removeItem(MATCH_CONTEXT_KEY);
    persistProfile();
    if (p) speakAiLine(p, aiBanterLine(p, 'victory'));
    log('Defeat logged. Regroup and retry the dimension.');
    clearResolvedBattlefield();
  }
}

function clearResolvedBattlefield() {
  state.playerMinions = [];
  state.enemyMinions = [];
  state.hand = [];
  state.enemyHand = [];
  state.playerDeck = [];
  state.enemyDeck = [];
  state.playerFields = [];
  state.enemyFields = [];
  state.playerRelics = [];
  state.enemyRelics = [];
  state.playerBarricades = Array(ROW_SIZE).fill(null);
  state.enemyBarricades = Array(ROW_SIZE).fill(null);
  state.playerGraveyard = [];
  state.enemyGraveyard = [];
  state.playerExile = [];
  state.enemyExile = [];
  state.stack = [];
  state.selectedCardId = null;
  state.selectedAttackerId = null;
  state.selectedSpellTargetMode = false;
  const attackLayer = document.querySelector('#attack-layer');
  if (attackLayer) attackLayer.innerHTML = '';
  const floatLayer = document.querySelector('#float-layer');
  if (floatLayer) floatLayer.innerHTML = '';
  clearHighlights();
}

function drawAttackLine(fromEl, toEl) {
  if (!fromEl || !toEl) return;
  const boardRect = document.querySelector('#board').getBoundingClientRect();
  const from = fromEl.getBoundingClientRect();
  const to = toEl.getBoundingClientRect();
  const x1 = from.left + (from.width / 2) - boardRect.left;
  const y1 = from.top + (from.height / 2) - boardRect.top;
  const x2 = to.left + (to.width / 2) - boardRect.left;
  const y2 = to.top + (to.height / 2) - boardRect.top;
  const svg = document.querySelector('#attack-layer');
  svg.innerHTML = `<line class="attack-line" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" />`;
  setTimeout(() => { svg.innerHTML = ''; }, 260);
}

function spawnDamageNumber(targetEl, amount, element = 'arcane') {
  if (!targetEl || amount <= 0) return;
  const boardRect = document.querySelector('#board').getBoundingClientRect();
  const rect = targetEl.getBoundingClientRect();
  const node = document.createElement('div');
  node.className = 'damage-float';
  node.textContent = `-${amount}`;
  const colors = { fire: '#ff8a5b', water: '#67b8ff', shadow: '#b38cff', nature: '#7de092', arcane: '#c0d2ff', holy: '#ffe799', poison: '#9df75f' };
  node.style.color = colors[element] ?? '#ffd0d8';
  node.style.left = `${rect.left + rect.width / 2 - boardRect.left}px`;
  node.style.top = `${rect.top + rect.height / 2 - boardRect.top}px`;
  document.querySelector('#float-layer').appendChild(node);
  setTimeout(() => node.remove(), 900);
}

let aiSpeechTimer = null;
function speakAiLine(profile, line) {
  if (!profile || !line) return;
  log(`[${profile.name}] ${line}`);
  const bubble = document.querySelector('#ai-speech');
  if (!bubble) return;
  bubble.textContent = `${profile.name}: ${line}`;
  bubble.classList.remove('hidden');
  if (aiSpeechTimer) clearTimeout(aiSpeechTimer);
  aiSpeechTimer = setTimeout(() => bubble.classList.add('hidden'), 3200);
}

function playerReadyAttackTotal() {
  return (state.playerMinions ?? [])
    .filter((unit) => (unit.health ?? 0) > 0 && !unit.summoningSick && ((state.usedAttacks?.[unit.id] ?? 0) < (unit.allowMultiAttack ? 99 : 1)))
    .reduce((sum, unit) => sum + Math.max(0, Number(unit.attack ?? 0)), 0);
}

function rememberAiThreat(profile, card, context = {}) {
  if (!profile?.id || !card) return null;
  const memory = ensureAiThreatMemory(profile.id);
  const name = String(card.name ?? card.id ?? 'Unknown');
  const key = name.toLowerCase();
  const text = `${card.text ?? ''} ${(card.tags ?? []).join(' ')} ${(card.keywords ?? []).join(' ')}`.toLowerCase();
  const rarity = String(card.rarity ?? '').toLowerCase();
  const type = String(card.type ?? '').toLowerCase();
  let score = (Math.max(0, Number(card.attack ?? 0)) * 1.15)
    + (Math.max(0, Number(card.health ?? 0)) * 0.72)
    + (Math.max(0, Number(card.cost ?? 0)) * 0.35)
    + (context.kills ?? 0) * 2.1
    + (context.damageToEnemy ?? 0) * 0.55;
  if (/destroy|silence|freeze|copy|draw|discover|reduce .* cost|return .* hand|counter/.test(text)) score += 2.8;
  if (/(all enemy minions|all minions|deal .* all|destroy all|split among enemies)/.test(text)) score += 3.5;
  if (/(field|relic|artifact|aura|trap)/.test(type)) score += 1.6;
  if (rarity === 'legendary') score += 2.4;
  if ((card.attack ?? 0) >= 6 || (card.health ?? 0) >= 8) score += 1.4;
  const seen = memory.seenCards[key] ?? { name, score: 0, count: 0, contexts: [] };
  seen.name = name;
  seen.score = Math.max(seen.score, Number(score.toFixed(2)));
  seen.count = (seen.count ?? 0) + 1;
  if (context.reason) seen.contexts = [...new Set([...(seen.contexts ?? []), context.reason])].slice(-4);
  memory.seenCards[key] = seen;
  memory.respectList = Object.values(memory.seenCards)
    .sort((a, b) => (b.score - a.score) || (b.count - a.count))
    .slice(0, 6);
  memory.events.push({
    at: Date.now(),
    name,
    score: seen.score,
    reason: context.reason ?? 'observed',
  });
  memory.events = memory.events.slice(-20);
  state.aiThreatMemory[profile.id] = memory;
  patchAiProfile(profile.id, (current) => enrichAiProfile({
    ...current,
    threatMemory: memory,
  }, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? []), ...(current?.deck ?? []), ...(current?.summons ?? [])]));
  return seen;
}

function observePlayerActionForAi(card, context = {}) {
  const active = currentAiProfile();
  if (!active || !card || state.matchResolved) return;
  const profile = active.aiArchetype ? active : enrichAiProfile(active, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? []), ...(active.deck ?? []), ...(active.summons ?? [])]);
  const threat = rememberAiThreat(profile, card, context);
  const text = `${card.text ?? ''}`.toLowerCase();
  const effectiveThreat = Number(threat?.score ?? 0);
  if (context.boardClear || (context.kills ?? 0) >= 2 || /(all enemy minions|all minions|destroy all|deal .* all)/.test(text)) {
    maybeSpeakAiEvent(profile, 'board_clear', 0.58);
  } else if (effectiveThreat >= 8.25 || (card.attack ?? 0) >= 7 || String(card.rarity ?? '').toLowerCase() === 'legendary') {
    maybeSpeakAiEvent(profile, 'respect_enemy', 0.52);
  } else if (context.combo || /draw|discover|copy|reduce .* cost|look at the top|reorder|familiarity/.test(text)) {
    maybeSpeakAiEvent(profile, 'respect_enemy', 0.38);
  }
  const lethalThreat = playerReadyAttackTotal() >= Math.max(1, (state.enemyHealth ?? 0) - 1);
  if (lethalThreat) maybeSpeakAiEvent(profile, 'near_death', 0.76);
  else if ((state.enemyHealth ?? 30) <= 10) maybeSpeakAiEvent(profile, 'under_pressure', 0.48);
}

function maybeSpeakAiEvent(profile, category, chance = 0.45) {
  if (!profile || !category) return;
  const enriched = profile.aiArchetype ? profile : enrichAiProfile(profile, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? []), ...(profile.deck ?? []), ...(profile.summons ?? [])]);
  const speechBias = difficultyConfig(enriched.difficultyBand).speechChance ?? 0.45;
  const key = `${profile.id}:${category}`;
  const memory = state.aiDialogueState[key] ?? { at: 0, count: 0 };
  const now = Date.now();
  if ((now - memory.at) < 2200) return;
  if (Math.random() > Math.max(0.08, Math.min(0.92, chance * (speechBias / 0.45)))) return;
  const line = aiBanterLine(enriched, category);
  if (!line) return;
  state.aiDialogueState[key] = { at: now, count: memory.count + 1, line };
  state.aiDialogueState._last = { profileId: profile.id, category, line, at: now };
  speakAiLine(enriched, line);
}

function minionStatuses(minion) {
  const statuses = [];
  if (minion?.summoningSick) statuses.push('Summoning Sickness');
  if (minion?.statuses?.divineShield) statuses.push('Divine Shield');
  if (minion?.statuses?.weakened) statuses.push('Weakened (-1 ATK)');
  if (minion?.statuses?.shatteredTurns) statuses.push(`Shattered (${minion.statuses.shatteredTurns} turn)`);
  if (minion?.statuses?.sleepTurns) statuses.push(`Sleep (${minion.statuses.sleepTurns} turn)`);
  if (minion?.statuses?.freezeTurns) statuses.push(`Freeze (${minion.statuses.freezeTurns} turn)`);
  if (minion?.statuses?.silenced) statuses.push('Silenced');
  if (minion?.statuses?.timelocked || minion?.statuses?.timeLockedTurns > 0) statuses.push('Time-Locked');
  return statuses;
}

function inspectAttackSummary(minion, side = 'player') {
  if (!minion) return { canAttack: false, reason: 'No unit selected.' };
  const targetId = side === 'player' ? 'enemy-hero' : 'player-hero';
  const check = validateAttack(side, minion.id, targetId);
  if (check.ok) return { canAttack: true, reason: 'Can attack now.' };
  if (check.code === 'taunt_gate' || check.code === 'blocked_frontline') return { canAttack: true, reason: check.message };
  return { canAttack: false, reason: check.message };
}

function openInspectPanel(payload = {}) {
  const panel = document.querySelector('#inspect-panel');
  const title = document.querySelector('#inspect-title');
  const body = document.querySelector('#inspect-body');
  if (!panel || !title || !body) return;
  const rows = [];
  const push = (k, v) => rows.push(`<div>${k}</div><div>${v}</div>`);

  if (payload.type === 'hero') {
    title.textContent = `${payload.name ?? 'Hero'} Inspect`;
    push('Health', `${payload.health ?? 0}/${payload.maxHealth ?? payload.health ?? 0}`);
    push('Defense', `${payload.defense ?? 0}`);
    push('Stance', 'Hero Core');
    push('Status', payload.side === 'enemy' ? 'Enemy Core' : 'Player Core');
    push('Familiarity', payload.localFamiliaritySummary ?? familiaritySummary(payload.side ?? 'player'));
    body.innerHTML = `<div class="inspect-kv">${rows.join('')}</div>`;
    panel.classList.remove('hidden');
    return;
  }

  const card = payload.card ?? payload.minion ?? null;
  if (!card) return;
  ensureCombatFields(card);
  const isMinion = payload.type === 'board-minion';
  const sourceCard = (!isMinion && payload.card?.id)
    ? (allKnownCardsById()[payload.card.id] ?? payload.card)
    : card;
  const rules = cardRulesInBattleTerms(sourceCard);
  const statuses = isMinion ? minionStatuses(card) : [];
  const attackSummary = isMinion ? inspectAttackSummary(card, payload.side ?? 'player') : null;
  const canToggleFriendly = (payload.type === 'board-minion' && payload.side === 'player')
    || (payload.type === 'hand-card' && card.type === 'minion' && payload.side === 'player');
  title.textContent = `${card.name ?? 'Card'} Inspect`;
  push('Type', normalizeCardType({ type: card.type ?? (isMinion ? 'minion' : 'unknown') }));
  push('Mana', `${card.cost ?? 0}`);
  push('Stats', `${card.attack ?? 0}/${card.health ?? card.maxHealth ?? 0} · DEF ${Math.max(0, toNumber(card.baseDef ?? card.def ?? 0))}`);
  push('Families', familySummary(card));
  push('Familiarity', payload.localFamiliaritySummary ?? familiaritySummary(payload.side ?? 'player', card));
  push('Stance', isMinion ? stanceLabel(card, payload.side === 'enemy') : 'Hand Card');
  push('Keywords', [
    card.taunt || card.guard ? 'Guard' : null,
    card.charge ? 'Charge' : null,
    card.pierce ? `Pierce ${card.pierce}` : null,
    card.trueDamage ? 'True Damage' : null,
    card.allowMultiAttack ? 'Multi-Attack' : null,
  ].filter(Boolean).join(', ') || 'None');
  push('Friendly Targeting', card.allowFriendlyAttack ? 'ON' : 'OFF');
  push('Status Effects', statuses.join(', ') || 'None');
  push('Pack/Faction', `${card.packSource ?? card.pack ?? 'Unknown'} / ${card.faction ?? familySummary(card) ?? 'Unknown'}`);
  push('Universe', card.universe ?? card.dimensionOwner ?? 'Unknown');
  if (attackSummary) {
    push('Can Attack Now', attackSummary.canAttack ? 'Yes' : 'No');
    push('Attack Reason', attackSummary.reason);
  }
  const controls = canToggleFriendly
    ? `<div class="inspect-actions"><button id="inspect-toggle-friendly-btn" data-no-drag="true">Friendly Targeting: ${card.allowFriendlyAttack ? 'ON' : 'OFF'}</button></div>`
    : '';
  body.innerHTML = `<div class="inspect-family-row">${renderFamilyBadges(card, 'inspect-family-badge')}</div><div class="inspect-kv">${rows.join('')}</div>${rules.map((line) => `<div class="inspect-rule">${line}</div>`).join('')}${controls}`;
  const toggleFriendlyBtn = body.querySelector('#inspect-toggle-friendly-btn');
  if (toggleFriendlyBtn) {
    toggleFriendlyBtn.onpointerdown = (event) => event.stopPropagation();
    toggleFriendlyBtn.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      card.allowFriendlyAttack = !card.allowFriendlyAttack;
      showHint(`${card.name}: Friendly Targeting ${card.allowFriendlyAttack ? 'ON' : 'OFF'}.`);
      render();
      openInspectPanel(isMinion
        ? { ...payload, minion: card }
        : { ...payload, card });
    };
  }
  panel.classList.remove('hidden');
}

function ensureLocalPlayerController() {
  if (localPlayerController) return localPlayerController;
  localPlayerController = createLocalPlayerController({
    state,
    getAllCards,
    toast,
    openInspectPanel,
    collectCardFamilies,
    extractCardRaces,
    getFamiliarity,
    hasFamilyTag,
    normalizeAbilityText,
    normalizeCardType,
    raceIconGlyph,
    raceMeta,
    toNumber,
    uid,
  });
  localPlayerController.ensureReady();
  localPlayerController.attachSetupHandlers?.();
  return localPlayerController;
}

function clearHighlights() {
  document.querySelectorAll('.target-valid,.target-blocked,.target-disabled,.slot-valid').forEach((el) => el.classList.remove('target-valid', 'target-blocked', 'target-disabled', 'slot-valid'));
}

function highlightCardPlayTargets() {
  clearHighlights();
  const selected = state.hand.find((card) => card.instanceId === state.selectedCardId);
  if (!selected) return;
  const selectedType = normalizeCardType(selected);
  const discount = ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(selectedType) ? firstSpellDiscount('player') : 0;
  const effectiveCost = effectiveCardCost(selected, 'player', discount);
  if (effectiveCost > state.mana) {
    showHint(explainInvalidAction('mana'));
    return;
  }
  if (selectedType === 'barricade' || selectedType === 'structure') {
    document.querySelectorAll('#player-front-row .board-slot').forEach((slotNode) => {
      const idx = Number(slotNode.dataset.slotIndex);
      if (!state.playerBarricades[slotLane(idx)]) slotNode.classList.add('slot-valid');
    });
    return;
  }
  if (selectedType === 'minion' || selectedType === 'token' || selectedType === 'creature') {
    if (state.playerMinions.length >= MAX_SLOTS) {
      showHint(`Board is full (${MAX_SLOTS}/${MAX_SLOTS}).`);
      return;
    }
    const requiresLarge = !!selected.large || (Array.isArray(selected.keywords) && selected.keywords.some((k) => String(k).toLowerCase() === 'large'));
    document.querySelectorAll('#player-front-row .board-slot, #player-back-row .board-slot').forEach((slotNode) => {
      const idx = Number(slotNode.dataset.slotIndex);
      if (getSlotOccupant(state.playerMinions, idx)) return;
      if (requiresLarge) {
        const mate = idx + 1;
        if (slotLane(idx) === ROW_SIZE - 1 || slotRow(mate) !== slotRow(idx) || getSlotOccupant(state.playerMinions, mate)) return;
      }
      slotNode.classList.add('slot-valid');
    });
  }
}

function highlightSpellTargets(card) {
  clearHighlights();
  if (!card) return;
  const effect = normalizeSpellEffect(card);
  const action = normalizeSpellAction(effect.action);
  const targetEnemies = new Set(['dealDamage', 'poisonHero', 'shatterFront', 'timeLock', 'sentence', 'weakenAllEnemies', 'tax']);
  const targetAllies = new Set(['grantDefense', 'heal', 'buffAttack', 'buffHealth', 'grantArmor']);

  if (targetEnemies.has(action)) {
    document.querySelectorAll('#enemy-front-row .minion, #enemy-back-row .minion').forEach((node) => node.classList.add('target-valid'));
    document.querySelector('[data-target-id="enemy-hero"]')?.classList.add('target-valid');
  }
  if (targetAllies.has(action)) {
    document.querySelectorAll('#player-front-row .minion, #player-back-row .minion').forEach((node) => node.classList.add('target-valid'));
    document.querySelector('[data-target-id="player-hero"]')?.classList.add('target-valid');
  }
  showHint('Spell targeting active: click a highlighted target, or click the spell again for auto-target.');
}

function highlightAttackTargets(attackerId) {
  clearHighlights();
  const baseline = validateAttack('player', attackerId, null);
  if (!baseline.ok && baseline.code !== 'invalid_target') {
    showHint(baseline.message);
    return;
  }
  const legalTargets = new Set(legalAttackTargetIds('player', attackerId));
  if (legalTargets.size === 0) {
    showHint(explainAttackFailure('no_legal_targets'));
    return;
  }

  document.querySelectorAll('#enemy-front-row .minion, #enemy-back-row .minion').forEach((node) => {
    if (legalTargets.has(node.dataset.id)) node.classList.add('target-valid');
    else node.classList.add('target-blocked');
  });
  const enemyHero = document.querySelector('[data-target-id="enemy-hero"]');
  if (enemyHero) {
    if (legalTargets.has('enemy-hero')) enemyHero.classList.add('target-valid');
    else enemyHero.classList.add('target-disabled');
  }
  if (state.playerMinions.find((m) => m.id === attackerId)?.allowFriendlyAttack) {
    document.querySelectorAll('#player-front-row .minion, #player-back-row .minion').forEach((node) => {
      if (node.dataset.id === attackerId) return;
      if (legalTargets.has(node.dataset.id)) node.classList.add('target-valid');
    });
  }
}

function dragWithGhost(node, onMove, onDrop) {
  node.onpointerdown = (event) => {
    if (event.button !== 0) return;
    setLeftPointerHeld(true);
    const target = event.target;
    if (target instanceof Element && target.closest('button, input, select, textarea, [data-no-drag="true"]')) return;
    const startX = event.clientX;
    const startY = event.clientY;
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;
    let ghost = null;

    const startDrag = (e) => {
      dragging = true;
      document.body.classList.add('dragging');
      setDragInteractionActive(true);
      const sourceRect = node.getBoundingClientRect();
      offsetX = e.clientX - sourceRect.left;
      offsetY = e.clientY - sourceRect.top;
      ghost = node.cloneNode(true);
      ghost.classList.add('ghost');
      ghost.style.width = `${Math.round(sourceRect.width)}px`;
      ghost.style.height = `${Math.round(sourceRect.height)}px`;
      ghost.style.left = '0px';
      ghost.style.top = '0px';
      document.documentElement.appendChild(ghost);
      if (node.setPointerCapture) {
        try { node.setPointerCapture(event.pointerId); } catch {}
      }
    };

    const move = (e) => {
      if (!dragging) {
        const moved = Math.hypot(e.clientX - startX, e.clientY - startY);
        if (moved < 6) return;
        e.preventDefault();
        startDrag(e);
      }
      if (!ghost) return;
      const x = e.clientX - offsetX;
      const y = e.clientY - offsetY;
      ghost.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      onMove(e);
    };
    const up = (e) => {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      document.removeEventListener('pointercancel', up);
      if (dragging) {
        onDrop(e);
        ghost?.remove();
        clearHighlights();
        showHint('');
        document.body.classList.remove('dragging');
        setDragInteractionActive(false);
        if (node.releasePointerCapture) {
          try { node.releasePointerCapture(e.pointerId); } catch {}
        }
      } else {
        setDragInteractionActive(false);
      }
    };    
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up, { once: true });
    document.addEventListener('pointercancel', up, { once: true });
  };
}

function enableCardDrag(node, cardId) {
  dragWithGhost(node, () => {
    state.selectedCardId = cardId;
    state.selectedAttackerId = null;
    const card = state.hand.find((entry) => entry.instanceId === cardId);
    if (card && ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(normalizeCardType(card))) {
      state.selectedSpellTargetMode = true;
      highlightSpellTargets(card);
    } else {
      state.selectedSpellTargetMode = false;
      highlightCardPlayTargets();
    }
  }, (e) => {
    const target = document.elementFromPoint(e.clientX, e.clientY);
    const slotNode = target?.closest('#player-front-row .board-slot, #player-back-row .board-slot');
    const drop = target?.closest('#drop-zone');
    const targetNode = target?.closest('[data-target-id]');
    const card = state.hand.find((entry) => entry.instanceId === cardId);
    const spellLike = card && ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(normalizeCardType(card));
    if (spellLike && targetNode) {
      const ok = playCard(cardId, null, targetNode.dataset.targetId);
      if (ok) state.selectedCardId = null;
      state.selectedSpellTargetMode = false;
      render();
      return;
    }
    if (slotNode) {
      const ok = playCard(cardId, Number(slotNode.dataset.slotIndex));
      if (ok) state.selectedCardId = null;
    } else if (drop) {
      const ok = playCard(cardId);
      if (ok) state.selectedCardId = null;
    } else {
      showHint('Drop on a highlighted slot to summon this card.');
    }
    state.selectedSpellTargetMode = false;
    render();
  });
}

function enableAttackDrag(node, attackerId) {
  dragWithGhost(node, () => {
    state.selectedAttackerId = attackerId;
    state.selectedCardId = null;
    highlightAttackTargets(attackerId);
  }, (e) => {
    const target = document.elementFromPoint(e.clientX, e.clientY)?.closest('[data-target-id]');
    if (target) attackWith(attackerId, target.dataset.targetId);
    else showHint('Drop on a highlighted target to attack.');
    render();
  });
}

function enableSpecificDevPanels(args = []) {
  ensureDevPanelState();
  const specs = args.filter((arg) => /^-/.test(String(arg ?? '')));
  if (!specs.length) {
    showAllDevPanels();
    return { ok: true, message: 'All dev utilities enabled.' };
  }
  if (specs.some((arg) => /^-help$/i.test(String(arg)))) {
    return { ok: true, message: `Hidable panels: ${listHidableDevPanels().join(', ')}` };
  }
  const selected = specs.flatMap((arg) => resolveDevPanelIds(arg));
  if (!selected.length) return { ok: false, message: `Unknown panel specifier(s): ${specs.join(', ')}` };
  setDevPanelsVisible(selected, true);
  state.devToolkitEnabled = true;
  state.devModeEnabled = true;
  state.aiDebugEnabled = true;
  if (selected.includes('deckViewer')) state.playableDeckEnabled = true;
  return { ok: true, message: `Enabled panels: ${selected.join(', ')}` };
}

function hideSpecificDevPanels(args = []) {
  ensureDevPanelState();
  const specs = args.filter((arg) => /^-/.test(String(arg ?? '')));
  if (!specs.length) {
    hideAllDevPanels();
    return { ok: true, message: 'All dev utilities hidden.' };
  }
  if (specs.some((arg) => /^-help$/i.test(String(arg)))) {
    return { ok: true, message: `Hidable panels: ${listHidableDevPanels().join(', ')}` };
  }
  const selected = specs.flatMap((arg) => resolveDevPanelIds(arg));
  if (!selected.length) return { ok: false, message: `Unknown panel specifier(s): ${specs.join(', ')}` };
  setDevPanelsVisible(selected, false);
  if (selected.includes('deckViewer')) state.playableDeckEnabled = false;
  const anyVisible = listHidableDevPanels().some((id) => state.devPanelVisibility[id]);
  if (!anyVisible) {
    state.devToolkitEnabled = false;
    state.devModeEnabled = false;
    state.aiDebugEnabled = false;
  }
  return { ok: true, message: `Hidden panels: ${selected.join(', ')}` };
}

function toggleNamedDevPanel(panelId, label = panelId) {
  ensureDevPanelState();
  const normalized = DEV_PANEL_ALIAS[String(panelId ?? '').toLowerCase()];
  if (!normalized) return { ok: false, message: `Unknown panel: ${label}` };
  const next = !state.devPanelVisibility[normalized];
  setDevPanelVisible(normalized, next);
  state.devToolkitEnabled = listHidableDevPanels().some((id) => state.devPanelVisibility[id]);
  if (normalized === 'deckViewer') state.playableDeckEnabled = next;
  if (next) {
    state.devModeEnabled = true;
    state.aiDebugEnabled = true;
  }
  return { ok: true, message: `${normalized} ${next ? 'shown' : 'hidden'}.` };
}

function handleConsoleCommand(raw) {
  const cmdRaw = raw.trim();
  if (!cmdRaw) return;
  const tokens = cmdRaw.split(/\s+/).filter(Boolean);
  const cmd = tokens[0];
  const args = tokens.slice(1);
  const key = cmd.toLowerCase();
  log(`> ${cmdRaw}`);

  const handlers = {
    './devabil': {
      help: 'Unlock developer-only panels.',
      run: () => {
        setDevUnlocked(true);
        toast('Developer panels unlocked.', 'info');
        log('Developer panels unlocked.');
      },
    },
    './dev': {
      help: 'Show dev suite. Usage: ./dev | ./dev -panelName',
      run: (commandArgs = []) => {
        if (commandArgs.some((entry) => String(entry).toLowerCase() === '-deckrater')) {
          const outcome = window.CardForgeDeckRater?.command('./dev -deckRater') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
          toast(outcome.message, outcome.ok ? 'info' : 'error');
          log(outcome.message);
          return;
        }
        const outcome = enableSpecificDevPanels(commandArgs);
        toast(outcome.ok ? 'Dev toolkit shown.' : outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPlayableDeckOverlay();
        renderPanels();
      },
    },
    './unlockall': {
      help: 'Unlock all cards, AI profiles, and progression rewards for this profile.',
      run: () => {
        const summary = applyUnlockAllProgress(state.profile);
        persistProfile();
        renderTitleStatsPanel();
        renderPanels();
        renderPlayableDeckOverlay();
        render();
        toast('Unlock all applied to this profile.', 'info');
        log(`UnlockAll complete: ${summary.cardsUpdated}/${summary.cardsTotal} cards now owned (>=4 copies), ${summary.aiUnlocked} AI unlocked, ${summary.dimensionsUnlocked} dimensions discovered.`);
      },
    },
    './hide': {
      help: 'Hide dev suite. Usage: ./hide | ./hide -panelName | ./hide -help',
      run: (commandArgs = []) => {
        if (commandArgs.some((entry) => String(entry).toLowerCase() === '-deckrater')) {
          const outcome = window.CardForgeDeckRater?.command('./hide -deckRater') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
          toast(outcome.message, outcome.ok ? 'info' : 'error');
          log(outcome.message);
          return;
        }
        const outcome = hideSpecificDevPanels(commandArgs);
        toast(outcome.ok ? 'Dev toolkit updated.' : outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPlayableDeckOverlay();
        renderPanels();
      },
    },
    './resetprogress': {
      help: 'Reset all progress data. Run ./resetprogress confirm to execute.',
      run: (commandArgs = []) => {
        const confirmArg = String(commandArgs[0] ?? '').toLowerCase();
        const now = Date.now();
        if (confirmArg !== 'confirm') {
          state.resetProgressConfirmUntil = now + 20000;
          toast('Reset staged. Run ./resetprogress confirm within 20s.', 'error');
          log('Reset staged. This clears profile, collection, decks, custom cards, map world, and creator cache keys. Type ./resetprogress confirm to continue.');
          return;
        }
        if (!state.resetProgressConfirmUntil || now > state.resetProgressConfirmUntil) {
          state.resetProgressConfirmUntil = now + 20000;
          toast('Confirmation window expired. Run ./resetprogress then ./resetprogress confirm.', 'error');
          log('Reset confirmation expired. Stage the reset again.');
          return;
        }
        state.resetProgressConfirmUntil = 0;
        const keysToClear = [];
        for (let i = 0; i < localStorage.length; i += 1) {
          const storageKey = localStorage.key(i);
          if (!storageKey) continue;
          if (/^cardforge\./i.test(storageKey)) keysToClear.push(storageKey);
        }
        keysToClear.push('cardforge.world.seed.v1', 'cardforge.match.opponent.v1', 'cardforge.match.context.v1', MATCH_RESULT_KEY);
        [...new Set(keysToClear)].forEach((storageKey) => localStorage.removeItem(storageKey));
        state.profile = resetProfile();
        state.matchResolved = false;
        state.deckTracker = { player: [], enemy: [] };
        state.hand = [];
        state.playerMinions = [];
        state.enemyMinions = [];
        state.playerFields = [];
        state.enemyFields = [];
        state.playerRelics = [];
        state.enemyRelics = [];
        state.playerBarricades = Array(ROW_SIZE).fill(null);
        state.enemyBarricades = Array(ROW_SIZE).fill(null);
        state.playerGraveyard = [];
        state.enemyGraveyard = [];
        state.playerExile = [];
        state.enemyExile = [];
        state.stack = [];
        state.phase = 'start';
        state.selectedCardId = null;
        state.selectedAttackerId = null;
        state.selectedSpellTargetMode = false;
        persistProfile();
        toast('All progression reset.', 'info');
        log(`Progress reset complete. Cleared ${keysToClear.length} storage keys and rebuilt clean defaults.`);
        renderPanels();
        renderPlayableDeckOverlay();
        render();
      },
    },
    './lobby': {
      help: 'Return to launcher lobby.',
      run: () => {
        window.location.assign('../index.html#lobby');
        log('Returning to lobby...');
      },
    },
    './devmode': {
      help: 'Alias for ./dev.',
      run: () => handlers['./dev'].run([]),
    },
    './aidebug': {
      help: 'Toggle AI planner panel.',
      run: () => {
        const outcome = toggleNamedDevPanel('aiPlanner', 'aidebug');
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPanels();
      },
    },
    './aiplanner': {
      help: 'Toggle AI planner panel.',
      run: () => handlers['./aidebug'].run(),
    },
    './aitrace': {
      help: 'Toggle action trace panel.',
      run: () => {
        const outcome = toggleNamedDevPanel('actionTrace', 'aitrace');
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPanels();
      },
    },
    './aigraphs': {
      help: 'Toggle AI graphs panel.',
      run: () => {
        const outcome = toggleNamedDevPanel('aiGraphs', 'aigraphs');
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPanels();
      },
    },
    './deckviewer': {
      help: 'Toggle deck viewer panel.',
      run: () => {
        const outcome = toggleNamedDevPanel('deckViewer', 'deckviewer');
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPlayableDeckOverlay();
        renderPanels();
      },
    },
    './raterdebug': {
      help: 'Toggle deck-rater debug mode.',
      run: () => {
        const outcome = window.CardForgeDeckRater?.command('./raterdebug') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
      },
    },
    './showeval': {
      help: 'Toggle live evaluator metric stream.',
      run: () => {
        const outcome = window.CardForgeDeckRater?.command('./showeval') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
      },
    },
    './showgauntlet': {
      help: 'Toggle gauntlet debug output for deck rater.',
      run: () => {
        const outcome = window.CardForgeDeckRater?.command('./showgauntlet') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
      },
    },
    './showcohesion': {
      help: 'Toggle cohesion graph debug output for deck rater.',
      run: () => {
        const outcome = window.CardForgeDeckRater?.command('./showcohesion') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
      },
    },
    './showdrawmath': {
      help: 'Toggle draw-math debug output for deck rater.',
      run: () => {
        const outcome = window.CardForgeDeckRater?.command('./showdrawmath') ?? { ok: false, message: 'Deck rater runtime unavailable.' };
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
      },
    },
    './deckgraph': {
      help: 'Toggle deck graphs panel.',
      run: () => {
        const outcome = toggleNamedDevPanel('deckGraphs', 'deckgraph');
        toast(outcome.message, outcome.ok ? 'info' : 'error');
        log(outcome.message);
        renderPanels();
      },
    },
    './deckgraphs': {
      help: 'Alias for ./deckgraph.',
      run: () => handlers['./deckgraph'].run(),
    },
    './playabledeck': {
      help: 'Legacy alias: toggle deck viewer + overlay.',
      run: () => handlers['./deckviewer'].run(),
    },
    './dm': {
      help: 'Legacy alias: toggle main hidden panels.',
      run: () => {
        state.dmPanelsVisible = !state.dmPanelsVisible;
        toast(`DM panels ${state.dmPanelsVisible ? 'shown' : 'hidden'}.`, 'info');
        log(state.dmPanelsVisible ? 'Main hidden panels shown.' : 'Main hidden panels hidden.');
        renderPanels();
      },
    },
    './forcephase': {
      help: 'Force phase. Usage: ./forcephase <phase>',
      run: (commandArgs = []) => {
        const phase = String(commandArgs[0] ?? '').toLowerCase();
        if (!PHASE_ORDER.includes(phase)) {
          toast(`Invalid phase: ${phase}`, 'error');
          log(`Valid phases: ${PHASE_ORDER.join(', ')}`);
          return;
        }
        setPhase(phase);
        pushDevActionTrace(`Phase forced -> ${phase}`, 'dev');
        render();
        renderPanels();
      },
    },
    './forceai': {
      help: 'Force immediate enemy AI turn.',
      run: async () => {
        if (state.currentTurn !== 'player') {
          log('AI already owns the turn.');
          return;
        }
        await runEnemyTurn();
      },
    },
    './skipai': {
      help: 'Skip enemy logic for the next action window.',
      run: () => {
        state.aiLogicEnabled = false;
        toast('AI logic disabled.', 'info');
        log('AI logic disabled. Use ./ailogic on to restore.');
      },
    },
    './setturn': {
      help: 'Set turn owner. Usage: ./setturn <player|enemy>',
      run: (commandArgs = []) => {
        const side = String(commandArgs[0] ?? '').toLowerCase();
        if (side !== 'player' && side !== 'enemy') {
          toast('Usage: ./setturn <player|enemy>', 'error');
          return;
        }
        state.currentTurn = side;
        pushDevActionTrace(`Turn owner forced -> ${side}`, 'dev');
        renderPanels();
      },
    },
    './giveaction': {
      help: 'Ready all player attacks this turn.',
      run: () => {
        state.usedAttacks = {};
        state.playerMinions.forEach((unit) => { unit.summoningSick = false; });
        pushDevActionTrace('Player actions refreshed.', 'dev');
        render();
      },
    },
    './exhaustall': {
      help: 'Mark all player units as exhausted.',
      run: () => {
        state.usedAttacks = Object.fromEntries(state.playerMinions.map((unit) => [unit.id, 1]));
        pushDevActionTrace('All player units exhausted.', 'dev');
        render();
      },
    },
    './readyall': {
      help: 'Ready all player units.',
      run: () => handlers['./giveaction'].run(),
    },
    './ailogic': {
      help: 'Toggle AI logic. Usage: ./ailogic <on|off>',
      run: (commandArgs = []) => {
        const mode = String(commandArgs[0] ?? '').toLowerCase();
        if (mode !== 'on' && mode !== 'off') {
          toast('Usage: ./ailogic <on|off>', 'error');
          return;
        }
        state.aiLogicEnabled = mode === 'on';
        toast(`AI logic ${state.aiLogicEnabled ? 'enabled' : 'disabled'}.`, 'info');
        log(`AI logic ${state.aiLogicEnabled ? 'enabled' : 'disabled'}.`);
      },
    },
    './aisetstar': {
      help: 'Set AI skill stars for this runtime. Usage: ./aisetstar <1-5>',
      run: (commandArgs = []) => {
        const stars = Math.max(1, Math.min(5, Math.floor(toNumber(commandArgs[0], 1))));
        state.matchContext = state.matchContext || {};
        state.matchContext.aiSkillStars = stars;
        toast(`AI stars set to ${stars}.`, 'info');
        log(`AI stars set to ${stars}.`);
      },
    },
    './aiarchetype': {
      help: 'Override current AI archetype. Usage: ./aiarchetype <id|auto>',
      run: (commandArgs = []) => {
        const value = String(commandArgs[0] ?? '').toLowerCase();
        const active = currentAiProfile();
        if (!active) {
          log('No active AI profile.');
          return;
        }
        if (!value) {
          toast('Usage: ./aiarchetype <id|auto>', 'error');
          return;
        }
        if (value === 'auto') {
          delete active.aiArchetype;
          state.selectedAiId = active.id;
          state.aiProfiles = state.aiProfiles.map((profile) => profile.id === active.id
            ? enrichAiProfile({ ...profile, threatMemory: state.aiThreatMemory[active.id] ?? profile.threatMemory }, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? []), ...(profile.deck ?? []), ...(profile.summons ?? [])])
            : profile);
          log(`AI archetype override cleared for ${active.name}.`);
          renderPanels();
          return;
        }
        const valid = [...VALID_AI_ARCHETYPES];
        if (!valid.includes(value)) {
          log(`Invalid archetype. Valid: ${valid.join(', ')}`);
          return;
        }
        active.aiArchetype = value;
        state.selectedAiId = active.id;
        state.aiProfiles = state.aiProfiles.map((profile) => profile.id === active.id
          ? enrichAiProfile({ ...profile, aiArchetype: value, threatMemory: state.aiThreatMemory[active.id] ?? profile.threatMemory }, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? []), ...(profile.deck ?? []), ...(profile.summons ?? [])])
          : profile);
        log(`AI archetype override -> ${value}`);
        renderPanels();
      },
    },
    './aidifficulty': {
      help: 'Override current AI difficulty. Usage: ./aidifficulty <easy|normal|hard|expert|mythic|auto>',
      run: (commandArgs = []) => {
        const value = String(commandArgs[0] ?? '').toLowerCase();
        const active = currentAiProfile();
        if (!active) {
          log('No active AI profile.');
          return;
        }
        if (!value) {
          toast('Usage: ./aidifficulty <easy|normal|hard|expert|mythic|auto>', 'error');
          return;
        }
        if (value === 'auto') {
          delete active.difficultyBand;
          syncAiProfileFromDeck(active.id, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? [])]);
          log(`AI difficulty override cleared for ${active.name}.`);
          renderPanels();
          return;
        }
        const labelMap = { easy: 'Easy', normal: 'Normal', hard: 'Hard', expert: 'Expert', mythic: 'Mythic' };
        if (!labelMap[value]) {
          log(`Invalid difficulty. Valid: ${Object.keys(labelMap).join(', ')}, auto`);
          return;
        }
        active.difficultyBand = labelMap[value];
        patchAiProfile(active.id, (profile) => enrichAiProfile({
          ...profile,
          difficultyBand: labelMap[value],
          threatMemory: state.aiThreatMemory[active.id] ?? profile.threatMemory,
        }, [...(state.enemyDeck ?? []), ...(state.enemyHand ?? []), ...(profile.deck ?? []), ...(profile.summons ?? [])]));
        log(`AI difficulty override -> ${labelMap[value]}`);
        renderPanels();
      },
    },
    './aiseed': {
      help: 'Set deterministic AI seed note. Usage: ./aiseed <value>',
      run: (commandArgs = []) => {
        const seed = String(commandArgs[0] ?? '').trim();
        if (!seed) {
          toast('Usage: ./aiseed <value>', 'error');
          return;
        }
        state.matchContext = state.matchContext || {};
        state.matchContext.aiSeed = seed;
        log(`AI seed note set: ${seed}`);
      },
    },
    './aipreset': {
      help: 'Set AI preset label. Usage: ./aipreset <style>',
      run: (commandArgs = []) => {
        const style = String(commandArgs.join(' ') ?? '').trim();
        if (!style) {
          toast('Usage: ./aipreset <style>', 'error');
          return;
        }
        state.matchContext = state.matchContext || {};
        state.matchContext.aiPreset = style;
        log(`AI preset label set: ${style}`);
      },
    },
    './showdrawodds': { help: 'Show deck graph panel.', run: () => handlers['./deckgraph'].run() },
    './showcurve': { help: 'Show deck graph panel.', run: () => handlers['./deckgraph'].run() },
    './showremaining': { help: 'Show deck viewer panel.', run: () => handlers['./deckviewer'].run() },
    './showplayed': { help: 'Show deck viewer panel.', run: () => handlers['./deckviewer'].run() },
    './showgrave': { help: 'Show deck viewer panel.', run: () => handlers['./deckviewer'].run() },
    './showdiscard': { help: 'Show deck viewer panel.', run: () => handlers['./deckviewer'].run() },
    './showfacilitydecks': { help: 'Toggle conquest decks panel.', run: () => log('Conquest panel command is available in Conquest mode.') },
    './showeconomy': { help: 'Toggle economy panel.', run: () => { const r = toggleNamedDevPanel('economy'); log(r.message); renderPanels(); } },
    './showresources': { help: 'Alias for ./showeconomy.', run: () => handlers['./showeconomy'].run() },
    './showcellcontrol': { help: 'Conquest-only panel.', run: () => log('Cell control panel is available in Conquest mode.') },
    './showlanepressure': { help: 'Conquest-only panel.', run: () => log('Lane pressure panel is available in Conquest mode.') },
    './showhomestead': { help: 'Conquest-only panel.', run: () => log('Homestead state panel is available in Conquest mode.') },
    './showstructures': { help: 'Conquest-only panel.', run: () => log('Structure state panel is available in Conquest mode.') },
    './showturretrange': { help: 'Conquest-only panel.', run: () => log('Turret range panel is available in Conquest mode.') },
    './showmovement': { help: 'Conquest-only panel.', run: () => log('Movement panel is available in Conquest mode.') },
    './showthreatmap': { help: 'Conquest-only panel.', run: () => log('Threat map panel is available in Conquest mode.') },
    './showvfx': { help: 'Toggle VFX panel.', run: () => { const r = toggleNamedDevPanel('vfx'); log(r.message); renderPanels(); } },
    './showhitboxes': { help: 'Reserved for hitbox overlays.', run: () => log('Hitbox overlay hook armed (reserved).') },
    './showranges': { help: 'Toggle ranges panel.', run: () => { const r = toggleNamedDevPanel('ranges'); log(r.message); renderPanels(); } },
    './showattackpreview': { help: 'Toggle targeting panel.', run: () => { const r = toggleNamedDevPanel('targeting'); log(r.message); renderPanels(); } },
    './showownership': { help: 'Conquest-only panel.', run: () => log('Ownership panel is available in Conquest mode.') },
    './showtags': { help: 'Toggle unit type panel.', run: () => { const r = toggleNamedDevPanel('unitTypes'); log(r.message); renderPanels(); } },
    './showtypes': { help: 'Toggle unit type panel.', run: () => handlers['./showtags'].run() },
    './cleardev': {
      help: 'Hide all panels and clear traces.',
      run: () => {
        hideAllDevPanels();
        state.devMetrics.actionTrace = [];
        state.devMetrics.aiTimeline = [];
        state.devMetrics.boardValueTimeline = [];
        state.devMetrics.deckSizeTimeline = [];
        state.devMetrics.lastAiCandidates = [];
        state.devMetrics.aiPhase = 'idle';
        renderPanels();
        renderPlayableDeckOverlay();
        log('Developer toolkit reset.');
      },
    },
    './resetpanels': { help: 'Show default dev panels.', run: () => { hideAllDevPanels(); setDevPanelsVisible(DEV_DEFAULT_PANELS, true); state.devToolkitEnabled = true; state.devModeEnabled = true; state.aiDebugEnabled = true; renderPanels(); log(`Default panels enabled: ${DEV_DEFAULT_PANELS.join(', ')}`); } },
    './resetgraphs': { help: 'Clear graph history.', run: () => { state.devMetrics.aiTimeline = []; state.devMetrics.boardValueTimeline = []; state.devMetrics.deckSizeTimeline = []; renderPanels(); log('Graph history cleared.'); } },
    './resetplanner': { help: 'Reset planner trace panels.', run: () => { state.devMetrics.lastAiCandidates = []; state.devMetrics.aiPhase = 'idle'; renderPanels(); log('Planner trace reset.'); } },
    './resetviewer': { help: 'Reset deck overlay.', run: () => { state.playableDeckSort = 'original'; state.playableDeckMinimized = false; renderPlayableDeckOverlay(); renderPanels(); log('Deck viewer reset.'); } },
    './help': {
      help: 'Show command list.',
      run: () => {
        const names = Object.keys(handlers).sort();
        toast(`Commands: ${names.join(', ')}`, 'info');
        log(`Available commands: ${names.join(' | ')}`);
        log(`Hidable panels: ${listHidableDevPanels().join(', ')}`);
      },
    },
  };

  const entry = handlers[key];
  if (!entry) {
    const suggestions = Object.keys(handlers).filter((name) => name.includes(key.replace('./', ''))).slice(0, 4);
    toast(`Unknown command: ${cmd}. Use ./help`, 'error');
    log(`Unknown command: ${cmd}${suggestions.length ? ` | maybe: ${suggestions.join(', ')}` : ''}`);
    return;
  }
  entry.run(args, cmdRaw);
}

document.querySelector('#chat-input').addEventListener('keydown', (event) => {
  if (event.key !== 'Enter') return;
  handleConsoleCommand(event.target.value);
  event.target.value = '';
});

document.querySelector('#chat-send').addEventListener('click', () => {
  const input = document.querySelector('#chat-input');
  handleConsoleCommand(input.value);
  input.value = '';
});

function renderTitleStatsPanel() {
  const host = document.querySelector('#title-stats-body');
  if (!host) return;
  const profile = loadProfile();
  ensureProgressFields(profile);
  const stats = profile.stats;
  const total = Math.max(0, Number(stats.battlesPlayed ?? 0));
  const wins = Math.max(0, Number(stats.wins ?? 0));
  const losses = Math.max(0, Number(stats.losses ?? 0));
  const rate = total ? ((wins / total) * 100).toFixed(1) : '0.0';
  host.innerHTML = `
    <div><strong>Total Battles:</strong> ${total}</div>
    <div><strong>Wins:</strong> ${wins}</div>
    <div><strong>Defeats:</strong> ${losses}</div>
    <div><strong>Win Rate:</strong> ${rate}%</div>
    <div><strong>Duel:</strong> ${stats.modes?.duel?.wins ?? 0}W / ${stats.modes?.duel?.losses ?? 0}L</div>
    <div><strong>Defense:</strong> ${stats.modes?.defense?.wins ?? 0}W / ${stats.modes?.defense?.losses ?? 0}L</div>
    <div><strong>Bosses Defeated:</strong> ${stats.bossesDefeated ?? 0}</div>
    <div><strong>Wielders Defeated:</strong> ${stats.namedWieldersDefeated ?? 0}</div>
    <div><strong>Packs Opened:</strong> ${stats.packsOpened ?? 0}</div>
    <div><strong>Unique Cards:</strong> ${stats.collectionProgress?.uniqueOwned ?? 0}</div>
  `;
}

function wipeAllProfileProgress() {
  const keysToClear = [];
  for (let i = 0; i < localStorage.length; i += 1) {
    const key = localStorage.key(i);
    if (!key) continue;
    if (/^cardforge\./i.test(key)) keysToClear.push(key);
  }
  keysToClear.push('cardforge.world.seed.v1', 'cardforge.match.opponent.v1', 'cardforge.match.context.v1', MATCH_RESULT_KEY);
  [...new Set(keysToClear)].forEach((key) => localStorage.removeItem(key));
  state.profile = resetProfile();
  ensureProgressFields(state.profile);
  persistProfile();
  toast('New Game profile initialized.', 'info');
}

document.querySelector('#menu-btn').addEventListener('click', () => {
  document.querySelector('#app')?.classList.add('hidden');
  document.querySelector('#title-screen')?.classList.remove('hidden');
  showHint('');
});
document.querySelector('#boot-retry-btn')?.addEventListener('click', () => {
  boot();
});
document.querySelector('#boot-clear-match-btn')?.addEventListener('click', () => {
  clearQueuedMatchKeys();
  appendBootLogLine('Cleared queued match context. Retrying boot...', 'info');
  boot();
});
document.querySelector('#boot-back-lobby-btn')?.addEventListener('click', () => {
  clearQueuedMatchKeys();
  window.location.assign('../index.html#lobby');
});
document.querySelector('#lobby-btn').addEventListener('click', () => { window.location.assign('../index.html#lobby'); });
document.querySelector('#card-ui-settings-btn')?.addEventListener('click', openCardUiSettingsModal);
document.querySelector('#local-player-card-ui-btn')?.addEventListener('click', openCardUiSettingsModal);
document.querySelector('#win-demo').addEventListener('click', claimDemoWin);
document.querySelector('#end-turn').addEventListener('click', endTurn);
document.querySelector('#start-runtime-btn')?.addEventListener('click', enterBattleRuntime);
document.querySelector('#title-local-player-btn')?.addEventListener('click', () => ensureLocalPlayerController().openSetup());
document.querySelector('#local-player-back-btn')?.addEventListener('click', () => ensureLocalPlayerController().showTitle());
document.querySelector('#title-open-lobby-btn')?.addEventListener('click', () => window.location.assign('../index.html#lobby'));
document.querySelector('#title-open-creator-btn')?.addEventListener('click', () => window.location.assign('../creator/index.html'));
document.querySelector('#title-stats-btn')?.addEventListener('click', () => {
  renderTitleStatsPanel();
  document.querySelector('#title-stats-panel')?.classList.remove('hidden');
});
document.querySelector('#title-stats-close-btn')?.addEventListener('click', () => {
  document.querySelector('#title-stats-panel')?.classList.add('hidden');
});
document.querySelector('#title-new-game-btn')?.addEventListener('click', () => {
  const confirmed = window.confirm('Start a New Game? This will wipe your current profile progress.');
  if (!confirmed) return;
  wipeAllProfileProgress();
  window.location.assign('../index.html#lobby');
});
bindCardUiSettingsControls(document);
document.querySelector('#inspect-close-btn')?.addEventListener('click', () => {
  document.querySelector('#inspect-panel')?.classList.add('hidden');
});
document.querySelector('#toggle-log').addEventListener('click', () => {
  state.logHidden = !state.logHidden;
  document.querySelector('#log').classList.toggle('hidden', state.logHidden);
  document.querySelector('#toggle-log').textContent = state.logHidden ? 'Show Log' : 'Hide Log';
});

document.querySelector('#deck-overlay-sort')?.addEventListener('change', (event) => {
  state.playableDeckSort = event.target.value;
  renderPlayableDeckOverlay();
});
document.querySelector('#deck-overlay-minimize')?.addEventListener('click', () => {
  state.playableDeckMinimized = !state.playableDeckMinimized;
  const button = document.querySelector('#deck-overlay-minimize');
  if (button) button.textContent = state.playableDeckMinimized ? 'Expand' : 'Minimize';
  renderPlayableDeckOverlay();
});
document.querySelector('#deck-overlay-close')?.addEventListener('click', () => {
  state.playableDeckEnabled = false;
  renderPlayableDeckOverlay();
});
document.querySelector('#topdeck-close-btn')?.addEventListener('click', () => {
  closeTopDeckPreview();
  render();
});
document.querySelector('#topdeck-bottom-btn')?.addEventListener('click', () => {
  const side = state.topDeckPreview?.side ?? 'player';
  moveTopDeckCardToBottom(side);
  closeTopDeckPreview();
  render();
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    cancelSelections();
    state.handPresentation.pinnedCardId = null;
    state.handPresentation.hoveredCardId = null;
    state.handPresentation.pointerTilt = { cardId: null, x: 0, y: 0 };
    if (state.localPlayer?.handPresentation) {
      state.localPlayer.handPresentation.pinnedCardId = null;
      state.localPlayer.handPresentation.hoveredCardId = null;
      state.localPlayer.handPresentation.pointerTilt = { cardId: null, x: 0, y: 0 };
    }
    document.querySelector('#inspect-panel')?.classList.add('hidden');
    closeTopDeckPreview();
    closeCardUiSettingsModal();
    render();
  }
});

document.addEventListener('pointerdown', (event) => {
  if (event.button === 0) setLeftPointerHeld(true);
  const target = event.target;
  if (!(target instanceof Element)) return;
  if (target.closest('#hand, #player-front-row, #player-back-row, #enemy-front-row, #enemy-back-row, .hero, #playable-deck-overlay, #inspect-panel, #dev-suite, #chat-input, #chat-send, #card-ui-settings-modal')) return;
  if (state.selectedAttackerId || state.selectedCardId) {
    cancelSelections();
    state.handPresentation.pinnedCardId = null;
    render();
  }
});

document.addEventListener('pointerup', (event) => {
  if (event.button === 0 || event.buttons === 0) {
    setLeftPointerHeld(false);
    if (event.buttons === 0) setDragInteractionActive(false);
  }
});

document.addEventListener('pointercancel', () => {
  setLeftPointerHeld(false);
  setDragInteractionActive(false);
});

window.addEventListener('blur', () => {
  setLeftPointerHeld(false);
  setDragInteractionActive(false);
});

window.addEventListener('error', (event) => {
  handleBootRuntimeError('Runtime script error interrupted startup.', event.error ?? event.message);
});

window.addEventListener('unhandledrejection', (event) => {
  handleBootRuntimeError('Runtime promise rejection interrupted startup.', event.reason);
});

document.addEventListener('contextmenu', (event) => {
  const target = event.target;
  if (!(target instanceof Element)) return;
  if (target.closest('#inspect-panel, #chat-input')) return;
  if (!target.closest('.card, .cf-hand-card, .minion, .deck-track-card, .hero')) {
    event.preventDefault();
    cancelSelections();
    render();
  }
});

window.render_game_to_text = () => {
  const localText = ensureLocalPlayerController().textState?.();
  if (localText) return localText;
  return JSON.stringify({
    mode: state.battleRuleset?.battleType ?? 'unknown',
    turn: state.currentTurn,
    phase: state.phase,
    mana: { current: state.mana, max: state.maxMana },
    player: {
      health: state.playerHealth,
      maxHealth: state.playerMaxHealth,
      deck: state.playerDeck.length,
      hand: state.hand.map((card) => ({ id: card.instanceId, name: card.name, cost: effectiveCardCost(card, 'player') })),
      board: state.playerMinions.map((unit) => ({ id: unit.id, name: unit.name, atk: currentAttackValue(unit, 'player'), hp: unit.health, slot: unit.slot })),
    },
      enemy: {
        health: state.enemyHealth,
        maxHealth: state.enemyMaxHealth,
        mana: state.enemyMana,
        handCount: state.enemyHand.length,
        board: state.enemyMinions.map((unit) => ({ id: unit.id, name: unit.name, atk: currentAttackValue(unit, 'enemy'), hp: unit.health, slot: unit.slot })),
      },
      ai: {
        profile: currentAiProfile()?.name ?? null,
        archetype: currentAiProfile()?.aiArchetypeName ?? null,
        difficulty: currentAiProfile()?.difficultyBand ?? null,
        deckIdentity: currentAiProfile()?.deckIdentity?.primary ?? null,
        phase: state.devMetrics.aiPhase,
        lastTrace: state.lastAiTrace,
        lastDialogue: state.aiDialogueState?._last ?? null,
        respectList: (state.aiThreatMemory?.[currentAiProfile()?.id ?? '']?.respectList ?? []).slice(0, 5),
        evaluation: getPlannerDebug(currentAiProfile()?.id ?? null)?.evaluation ?? null,
      },
      topDeckPreview: state.topDeckPreview
        ? {
          side: state.topDeckPreview.side,
        cards: state.topDeckPreview.cards.map((card) => ({ name: card.name, type: card.type, cost: card.cost })),
        allowBottom: state.topDeckPreview.allowBottom,
      }
      : null,
    unhandledAbilityActions: Object.entries(state.unhandledAbilityActions ?? {})
      .sort((a, b) => b[1] - a[1])
      .slice(0, 12),
  });
};

window.advanceTime = (ms = 16) => new Promise((resolve) => {
  const wait = Math.max(0, Number(ms) || 16);
  setTimeout(() => {
    ensureLocalPlayerController().advanceTime?.();
    render();
    resolve();
  }, wait);
});

function scanAbilityCoverage(collectionName = '') {
  const wanted = String(collectionName ?? '').trim().toLowerCase();
  const cards = getAllCards().filter((card) => {
    if (!wanted) return true;
    const coll = String(card.collectionName ?? '').toLowerCase();
    return coll.includes(wanted) || String(card.packSource ?? '').toLowerCase().includes(wanted);
  });
  const previousUnhandled = { ...(state.unhandledAbilityActions ?? {}) };
  state.unhandledAbilityActions = {};
  const enemyDummy = ensureCombatFields({
    id: uid('cov-en'),
    name: 'Coverage Enemy',
    type: 'minion',
    attack: 2,
    health: 6,
    maxHealth: 6,
    slot: 0,
    row: 'back',
    race: 'dummy',
    element: 'none',
    statuses: {},
  });
  state.enemyMinions = [enemyDummy];
  state.playerMinions = [];
  const result = {
    cardsChecked: 0,
    clausesChecked: 0,
    triggeredClauses: 0,
    unhandled: {},
  };
  cards.forEach((card) => {
    const clauses = getAbilityClauses(card);
    if (!clauses.length) return;
    result.cardsChecked += 1;
    clauses.forEach((clause) => {
      result.clausesChecked += 1;
      if (clause.trigger === 'passive') return;
      const self = ensureCombatFields({
        ...card,
        id: uid('cov-self'),
        type: normalizeCardType(card) === 'minion' ? 'minion' : 'relic',
        attack: Math.max(0, toNumber(card.attack, 2)),
        health: Math.max(1, toNumber(card.health, 4)),
        maxHealth: Math.max(1, toNumber(card.health, 4)),
        slot: 1,
        row: 'back',
        statuses: {},
      });
      const runtime = {
        side: 'player',
        eventKey: clause.trigger,
        card: self,
        self,
        target: enemyDummy,
        summoned: self,
        playedCard: self,
      };
      result.triggeredClauses += 1;
      executeAbilityBody(clause.body, runtime);
    });
  });
  result.unhandled = Object.entries(state.unhandledAbilityActions ?? {})
    .sort((a, b) => b[1] - a[1])
    .slice(0, 200)
    .reduce((acc, [key, count]) => ({ ...acc, [key]: count }), {});
  state.unhandledAbilityActions = previousUnhandled;
  return result;
}

window.__cardforgeDebug = {
  openTopDeckPreview: (side = 'player') => {
    openTopDeckPreview(side, { count: 1, allowBottom: true, sourceName: 'Debug Peek' });
    render();
  },
  closeTopDeckPreview: () => {
    closeTopDeckPreview();
    render();
  },
  triggerAbilityEvent: (side = 'player', eventKey = 'on_end_turn') => {
    triggerAbilityEvent(side, eventKey, { side });
    cleanupDead();
    render();
  },
  executeAbilityText: (text = '', eventKey = 'on_play', side = 'player') => {
    const foe = enemySide(side);
    const dummy = ensureCombatFields({
      id: uid('dbg-self'),
      name: 'Debug Unit',
      type: 'minion',
      attack: 3,
      health: 5,
      maxHealth: 5,
      slot: 1,
      row: 'back',
      race: 'debug',
      element: 'arcane',
      statuses: {},
      text,
    });
    if (side === 'player') state.playerMinions = [dummy];
    else state.enemyMinions = [dummy];
    const enemyTarget = ensureCombatFields({
      id: uid('dbg-target'),
      name: 'Debug Target',
      type: 'minion',
      attack: 2,
      health: 6,
      maxHealth: 6,
      slot: 0,
      row: 'back',
      race: 'dummy',
      element: 'none',
      statuses: {},
    });
    if (foe === 'player') state.playerMinions = [enemyTarget];
    else state.enemyMinions = [enemyTarget];
    executeAbilityBody(text, { side, eventKey, card: dummy, self: dummy, target: enemyTarget, playedCard: dummy, summoned: dummy });
    cleanupDead();
    render();
    return { unhandled: { ...(state.unhandledAbilityActions ?? {}) } };
  },
  scanAbilityCoverage: (collectionName = 'Gen 4') => scanAbilityCoverage(collectionName),
};

boot();


