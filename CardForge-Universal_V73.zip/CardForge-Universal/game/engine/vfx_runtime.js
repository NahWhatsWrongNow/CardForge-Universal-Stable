const DEFAULT_EVENT_SPECS = {
  attack: {
    projectileType: 'slash',
    color: '#ff7e9f',
    width: 4,
    length: 0.95,
    speed: 1.2,
    trailType: 'streak',
    spawnOffset: 0,
    arcAmount: 0,
    homing: false,
    splashRadiusVisual: 0,
    impactType: 'spark',
    lifetime: 320,
    glowIntensity: 0.8,
    particleDensity: 10,
    hitStopAmount: 55,
    screenShakeAmount: 0.65,
    numberOfProjectiles: 1,
    staggerTiming: 0,
    soundHookId: '',
    themePreset: 'default',
  },
  cast: {
    projectileType: 'orb',
    color: '#9fd4ff',
    width: 6,
    length: 0.8,
    speed: 1.0,
    trailType: 'embers',
    spawnOffset: 0,
    arcAmount: 24,
    homing: true,
    splashRadiusVisual: 14,
    impactType: 'arcane-burst',
    lifetime: 420,
    glowIntensity: 0.9,
    particleDensity: 14,
    hitStopAmount: 35,
    screenShakeAmount: 0.35,
    numberOfProjectiles: 1,
    staggerTiming: 0,
    soundHookId: '',
    themePreset: 'arcane',
  },
  summon: {
    projectileType: 'pulse',
    color: '#98ffe0',
    width: 3,
    length: 0.7,
    speed: 0.9,
    trailType: 'none',
    spawnOffset: 0,
    arcAmount: 0,
    homing: false,
    splashRadiusVisual: 20,
    impactType: 'summon-ring',
    lifetime: 360,
    glowIntensity: 0.75,
    particleDensity: 16,
    hitStopAmount: 0,
    screenShakeAmount: 0.15,
    numberOfProjectiles: 1,
    staggerTiming: 0,
    soundHookId: '',
    themePreset: 'summon',
  },
  'defense-enter': {
    projectileType: 'radial',
    color: '#7edbff',
    width: 3,
    length: 0.9,
    speed: 0.95,
    trailType: 'shield',
    spawnOffset: 0,
    arcAmount: 0,
    homing: false,
    splashRadiusVisual: 24,
    impactType: 'shield-ring',
    lifetime: 300,
    glowIntensity: 0.9,
    particleDensity: 12,
    hitStopAmount: 0,
    screenShakeAmount: 0.1,
    numberOfProjectiles: 1,
    staggerTiming: 0,
    soundHookId: '',
    themePreset: 'defense',
  },
  kill: {
    projectileType: 'shard',
    color: '#ffd2aa',
    width: 3,
    length: 0.75,
    speed: 1.1,
    trailType: 'ash',
    spawnOffset: 0,
    arcAmount: 8,
    homing: false,
    splashRadiusVisual: 28,
    impactType: 'shatter',
    lifetime: 420,
    glowIntensity: 1,
    particleDensity: 22,
    hitStopAmount: 70,
    screenShakeAmount: 0.9,
    numberOfProjectiles: 2,
    staggerTiming: 35,
    soundHookId: '',
    themePreset: 'lethal',
  },
};

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

function toNumber(v, fallback = 0) {
  const parsed = Number(v);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizeSpec(raw, fallbackEvent = 'attack') {
  const base = { ...(DEFAULT_EVENT_SPECS[fallbackEvent] ?? DEFAULT_EVENT_SPECS.attack) };
  const incoming = raw && typeof raw === 'object' ? raw : {};
  const spec = { ...base, ...incoming };
  spec.width = clamp(toNumber(spec.width, 3), 1, 24);
  spec.speed = clamp(toNumber(spec.speed, 1), 0.1, 3.4);
  spec.length = clamp(toNumber(spec.length, 1), 0.2, 2.5);
  spec.arcAmount = clamp(toNumber(spec.arcAmount, 0), -180, 180);
  spec.lifetime = clamp(toNumber(spec.lifetime, 320), 120, 2400);
  spec.glowIntensity = clamp(toNumber(spec.glowIntensity, 0.7), 0, 2);
  spec.particleDensity = clamp(toNumber(spec.particleDensity, 8), 0, 120);
  spec.hitStopAmount = clamp(toNumber(spec.hitStopAmount, 0), 0, 160);
  spec.screenShakeAmount = clamp(toNumber(spec.screenShakeAmount, 0), 0, 2);
  spec.numberOfProjectiles = clamp(Math.round(toNumber(spec.numberOfProjectiles, 1)), 1, 16);
  spec.staggerTiming = clamp(toNumber(spec.staggerTiming, 0), 0, 450);
  return spec;
}

function pointFromElement(el, boardRect) {
  if (!el) return null;
  const rect = el.getBoundingClientRect();
  return {
    x: rect.left + (rect.width / 2) - boardRect.left,
    y: rect.top + (rect.height / 2) - boardRect.top,
  };
}

function cubicOut(t) {
  return 1 - ((1 - t) ** 3);
}

function pickImpactColor(spec, eventName) {
  if (spec.impactType === 'heal-bloom') return '#9ef8b5';
  if (spec.impactType === 'shield-ring') return '#84dfff';
  if (spec.impactType === 'shatter') return '#ffd3ad';
  if (eventName === 'pierce') return '#ffe89c';
  return spec.color || '#c7dfff';
}

export function createVfxRuntime({ canvas, boardElement, prefersReducedMotion = () => false }) {
  const ctx = canvas?.getContext('2d');
  if (!canvas || !ctx || !boardElement) {
    return {
      resize() {},
      trigger() {},
      clear() {},
      previewSpec() {},
    };
  }

  let running = false;
  let raf = null;
  const projectiles = [];
  const impacts = [];
  const particles = [];

  function resize() {
    const rect = boardElement.getBoundingClientRect();
    const ratio = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, Math.round(rect.width * ratio));
    canvas.height = Math.max(1, Math.round(rect.height * ratio));
    canvas.style.width = `${Math.max(1, Math.round(rect.width))}px`;
    canvas.style.height = `${Math.max(1, Math.round(rect.height))}px`;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  }

  function triggerBoardFeedback(spec) {
    if (prefersReducedMotion()) return;
    if (spec.hitStopAmount > 0) {
      boardElement.classList.add('board-hit-stop');
      setTimeout(() => boardElement.classList.remove('board-hit-stop'), spec.hitStopAmount);
    }
    if (spec.screenShakeAmount > 0.05) {
      boardElement.classList.add('board-shake');
      setTimeout(() => boardElement.classList.remove('board-shake'), 200);
    }
  }

  function addImpact(point, spec, eventName) {
    impacts.push({
      x: point.x,
      y: point.y,
      bornAt: performance.now(),
      ttl: Math.max(120, spec.lifetime * 0.45),
      radius: Math.max(10, spec.splashRadiusVisual || spec.width * 2.4),
      color: pickImpactColor(spec, eventName),
      impactType: spec.impactType || 'spark',
      glow: spec.glowIntensity,
    });
    const count = clamp(Math.round(spec.particleDensity), 2, 120);
    for (let i = 0; i < count; i += 1) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() * 0.35);
      const speed = (0.3 + Math.random() * 1.35) * (1 + spec.glowIntensity * 0.28);
      particles.push({
        x: point.x,
        y: point.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 0.8 + Math.random() * 2.1,
        ttl: 200 + Math.random() * 500,
        bornAt: performance.now(),
        color: spec.color || '#d8e8ff',
      });
    }
    triggerBoardFeedback(spec);
  }

  function addProjectile(start, end, spec, eventName) {
    const bornAt = performance.now();
    const ttl = Math.max(100, spec.lifetime / Math.max(0.45, spec.speed));
    projectiles.push({
      start,
      end,
      bornAt,
      ttl,
      spec,
      eventName,
      done: false,
    });
  }

  function resolveEndpoints(payload = {}) {
    const rect = boardElement.getBoundingClientRect();
    const fromSelector = payload.fromSelector || (payload.attackerId ? `[data-id="${payload.attackerId}"]` : null);
    const toSelector = payload.toSelector || (payload.targetId ? `[data-target-id="${payload.targetId}"], [data-id="${payload.targetId}"]` : null);
    const startEl = payload.fromEl ?? (fromSelector ? document.querySelector(fromSelector) : null);
    const endEl = payload.toEl ?? (toSelector ? document.querySelector(toSelector) : null);
    const fallbackStart = { x: rect.width * 0.25, y: rect.height * 0.5 };
    const fallbackEnd = { x: rect.width * 0.75, y: rect.height * 0.5 };
    return {
      start: pointFromElement(startEl, rect) ?? payload.startPoint ?? fallbackStart,
      end: pointFromElement(endEl, rect) ?? payload.endPoint ?? fallbackEnd,
    };
  }

  function trigger(eventName, payload = {}) {
    resize();
    const spec = normalizeSpec(payload.vfxSpec ?? payload.vfx ?? DEFAULT_EVENT_SPECS[eventName], eventName);
    const endpoints = resolveEndpoints(payload);
    const count = Math.max(1, spec.numberOfProjectiles);
    for (let i = 0; i < count; i += 1) {
      setTimeout(() => addProjectile(endpoints.start, endpoints.end, spec, eventName), i * spec.staggerTiming);
    }
    if (eventName === 'summon' || eventName === 'defense-enter') addImpact(endpoints.end, spec, eventName);
    if (!running) {
      running = true;
      raf = requestAnimationFrame(step);
    }
  }

  function previewSpec(spec) {
    trigger('cast', { startPoint: { x: 48, y: 160 }, endPoint: { x: 280, y: 70 }, vfxSpec: spec });
  }

  function drawProjectile(p, now) {
    const t = clamp((now - p.bornAt) / p.ttl, 0, 1);
    const eased = cubicOut(t);
    const dx = p.end.x - p.start.x;
    const dy = p.end.y - p.start.y;
    const arcY = Math.sin(eased * Math.PI) * p.spec.arcAmount;
    const x = p.start.x + (dx * eased);
    const y = p.start.y + (dy * eased) - arcY;
    const color = p.spec.color || '#d5e8ff';
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.shadowColor = color;
    ctx.shadowBlur = 8 + (p.spec.glowIntensity * 10);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = p.spec.width;

    const type = String(p.spec.projectileType || 'bolt');
    if (type === 'beam' || type === 'lance' || type === 'tether' || type === 'slash') {
      const trailX = p.start.x + (dx * Math.max(0, eased - 0.2));
      const trailY = p.start.y + (dy * Math.max(0, eased - 0.2)) - (Math.sin(Math.max(0, eased - 0.2) * Math.PI) * p.spec.arcAmount);
      ctx.beginPath();
      ctx.moveTo(trailX, trailY);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (type === 'chain') {
      ctx.beginPath();
      ctx.moveTo(p.start.x, p.start.y);
      for (let i = 1; i <= 4; i += 1) {
        const ct = eased * (i / 4);
        const jx = p.start.x + (dx * ct) + ((i % 2 === 0 ? -1 : 1) * 6);
        const jy = p.start.y + (dy * ct) - (Math.sin(ct * Math.PI) * p.spec.arcAmount * 0.35);
        ctx.lineTo(jx, jy);
      }
      ctx.lineTo(x, y);
      ctx.stroke();
    } else {
      const radius = Math.max(1.5, p.spec.width * 0.6);
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();

    if (t >= 1 && !p.done) {
      p.done = true;
      addImpact({ x, y }, p.spec, p.eventName);
    }
    return t < 1;
  }

  function drawImpact(impact, now) {
    const t = clamp((now - impact.bornAt) / impact.ttl, 0, 1);
    const alpha = 1 - t;
    const radius = impact.radius * (0.3 + t);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = impact.color;
    ctx.lineWidth = Math.max(1.2, (1 - t) * 3.5);
    ctx.shadowColor = impact.color;
    ctx.shadowBlur = 8 + (impact.glow * 10);
    ctx.globalAlpha = alpha;
    ctx.beginPath();
    ctx.arc(impact.x, impact.y, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    return t < 1;
  }

  function drawParticle(p, now) {
    const t = clamp((now - p.bornAt) / p.ttl, 0, 1);
    if (t >= 1) return false;
    p.x += p.vx;
    p.y += p.vy;
    p.vx *= 0.985;
    p.vy *= 0.985;
    ctx.save();
    ctx.globalAlpha = 1 - t;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size * (1 - (t * 0.5)), 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    return true;
  }

  function step(now) {
    const rect = boardElement.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);
    for (let i = projectiles.length - 1; i >= 0; i -= 1) {
      if (!drawProjectile(projectiles[i], now)) projectiles.splice(i, 1);
    }
    for (let i = impacts.length - 1; i >= 0; i -= 1) {
      if (!drawImpact(impacts[i], now)) impacts.splice(i, 1);
    }
    for (let i = particles.length - 1; i >= 0; i -= 1) {
      if (!drawParticle(particles[i], now)) particles.splice(i, 1);
    }
    if (projectiles.length || impacts.length || particles.length) {
      raf = requestAnimationFrame(step);
    } else {
      running = false;
      raf = null;
      ctx.clearRect(0, 0, rect.width, rect.height);
    }
  }

  function clear() {
    projectiles.length = 0;
    impacts.length = 0;
    particles.length = 0;
    if (raf) cancelAnimationFrame(raf);
    running = false;
    raf = null;
    const rect = boardElement.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);
  }

  resize();
  window.addEventListener('resize', resize);

  return {
    resize,
    trigger,
    clear,
    previewSpec,
    normalizeSpec,
    defaults: DEFAULT_EVENT_SPECS,
  };
}

export const VFX_DEFAULTS = DEFAULT_EVENT_SPECS;
export { normalizeSpec as normalizeVfxSpec };
