export function explainInvalidAction(reason) {
  const hints = {
    defense: 'This unit is in defense mode. Toggle stance to attack.',
    taunt: 'An enemy with taunt must be attacked first.',
    mana: 'You need more mana crystals to play this card.',
    invalid: 'That action is not valid right now.',
    not_turn: 'It is not your turn.',
    exhausted: 'This unit is exhausted.',
    summoning_sickness: 'Summoning sickness: this unit cannot attack this turn.',
    already_attacked: 'This unit already attacked this turn.',
    target_invalid: 'That target is not legal for this action.',
    hidden: 'Target is hidden or untargetable right now.',
    stunned: 'This unit is stunned or time-locked and cannot act.',
    blocked_frontline: 'You must clear enemy units before attacking hero.',
  };
  return hints[reason] ?? hints.invalid;
}
