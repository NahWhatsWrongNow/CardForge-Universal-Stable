const WORD_NUMBERS = {
  a: 1,
  an: 1,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
};

export function normalizeAbilityText(text = '') {
  return String(text ?? '')
    .replace(/\u2019/g, "'")
    .replace(/\u2018/g, "'")
    .replace(/\u2013|\u2014|\u2212/g, '-')
    .replace(/\s+/g, ' ')
    .trim();
}

export function numberFromText(fragment = '', fallback = 1) {
  const source = normalizeAbilityText(fragment).toLowerCase();
  const numeric = source.match(/\d+/);
  if (numeric) return Math.max(0, Number(numeric[0]));
  for (const [word, value] of Object.entries(WORD_NUMBERS)) {
    if (new RegExp(`\\b${word}\\b`, 'i').test(source)) return value;
  }
  return fallback;
}

function inferTrigger(prefix = '', body = '') {
  const token = normalizeAbilityText(`${prefix} ${body}`).toLowerCase();
  if (prefix === 'battlecry') return 'on_play';
  if (prefix === 'death' || prefix === 'deathrattle') return 'on_death';
  if (prefix === 'end_of_turn') return 'on_end_turn';
  if (prefix === 'start_of_turn') return 'on_start_turn';
  if (prefix === 'cast') return 'on_cast';
  if (/^at (?:the )?end of your turn/.test(token) || /^at end of turn/.test(token)) return 'on_end_turn';
  if (/^at the end of each turn/.test(token)) return 'on_any_end_turn';
  if (/^at the start of your turn/.test(token)) return 'on_start_turn';

  if (/^whenever this survives damage/.test(token)) return 'on_survive_damage_self';
  if (/^whenever .* survives damage/.test(token)) return 'on_survive_damage_any';
  if (/^whenever this takes damage and survives/.test(token)) return 'on_survive_damage_self';
  if (/^whenever this takes damage/.test(token)) return 'on_damage_self';
  if (/^when(?:ever)? this is healed|^when healed/.test(token)) return 'on_heal_self';
  if (/^when(?:ever)? a character is healed|^whenever .* is healed|^whenever you restore health|^after you heal|^after you restore health|^after a character is healed/.test(token)) return 'on_heal_any';
  if (/^when(?:ever)? you cast a spell|^after you cast a spell|^whenever you play a spell/.test(token)) return 'on_spell_cast';
  if (/^when(?:ever)? you summon|^after you summon|^when(?:ever)? a friendly .* is summoned/.test(token)) return 'on_summon_friendly';
  if (/^whenever this attacks/.test(token)) return 'on_attack_self';
  if (/^after this attacks|^when this attacks/.test(token)) return 'on_attack_self';
  if (/^whenever .* attacks|^after .* attacks|^when .* attacks/.test(token)) return 'on_attack_any';
  if (/^whenever this attacks and kills|^whenever this kills a minion/.test(token)) return 'on_kill_self';
  if (/^whenever a friendly .* dies|^whenever one of your minions dies|^whenever any minion dies|^whenever a minion dies|^whenever .* dies/.test(token)) return 'on_minion_death';
  if (/^whenever .* is destroyed|^whenever .* is removed/.test(token)) return 'on_minion_death';
  if (/^whenever you draw|^whenever .* is drawn/.test(token)) return 'on_draw';
  if (/^when drawn/.test(token)) return 'on_drawn_self';
  if (/^whenever this is targeted by a spell/.test(token)) return 'on_targeted_by_spell';
  if (/^after you play a ship|^whenever you play a ship/.test(token)) return 'on_play_ship';
  if (/^after you play a relic|^whenever you play a relic|^if you played a relic/.test(token)) return 'on_play_relic';
  if (/^after you play a /.test(token) || /^whenever you play a /.test(token)) return 'on_play_card';
  if (/^whenever .* becomes stealthed|^after .* becomes stealthed|^whenever .* gains stealth|^after .* gains stealth/.test(token)) {
    return /this/.test(token) ? 'on_stealth_gain_self' : 'on_stealth_gain_friendly';
  }
  if (/^whenever .* loses stealth|^when .* loses stealth/.test(token)) return 'on_stealth_loss_friendly';
  if (/^whenever .* is frozen|^when .* is frozen/.test(token)) return 'on_freeze_any';
  if (/^whenever an enemy attacks your minion/.test(token)) return 'on_enemy_attack_friendly';
  if (/^whenever you play the top card of your deck|^after you play the top card of your deck/.test(token)) return 'on_play_top_deck';
  if (/^whenever you look at|^after you look at|^whenever you manipulate your deck/.test(token)) return 'on_deck_peek';
  if (/^after you return a friendly minion to your hand/.test(token)) return 'on_return_friendly';
  return 'passive';
}

export function parseAbilityClauses(text = '') {
  const normalized = normalizeAbilityText(text);
  if (!normalized) return [];

  const parts = normalized
    .split(/(?<=[.!?])\s+/)
    .map((entry) => normalizeAbilityText(entry))
    .filter(Boolean);

  const clauses = [];
  let previousTrigger = '';
  parts.forEach((part) => {
    let prefix = '';
    let body = part;
    const lower = part.toLowerCase();
    if (lower.startsWith('battlecry:')) {
      prefix = 'battlecry';
      body = normalizeAbilityText(part.slice('battlecry:'.length));
    } else if (lower.startsWith('deathrattle:')) {
      prefix = 'deathrattle';
      body = normalizeAbilityText(part.slice('deathrattle:'.length));
    } else if (lower.startsWith('death:')) {
      prefix = 'death';
      body = normalizeAbilityText(part.slice('death:'.length));
    } else if (lower.startsWith('end of turn:')) {
      prefix = 'end_of_turn';
      body = normalizeAbilityText(part.slice('end of turn:'.length));
    } else if (lower.startsWith('at the end of your turn:')) {
      prefix = 'end_of_turn';
      body = normalizeAbilityText(part.slice('at the end of your turn:'.length));
    } else if (lower.startsWith('at the start of your turn:')) {
      prefix = 'start_of_turn';
      body = normalizeAbilityText(part.slice('at the start of your turn:'.length));
    } else if (lower.startsWith('cast:')) {
      prefix = 'cast';
      body = normalizeAbilityText(part.slice('cast:'.length));
    }

    let trigger = inferTrigger(prefix, body);
    if (
      !prefix
      && trigger === 'passive'
      && (/^if\s+/i.test(body) || /^after this triggers/i.test(body) || /^otherwise/i.test(body))
      && previousTrigger
      && previousTrigger !== 'passive'
    ) {
      trigger = previousTrigger;
    }
    if (!prefix && trigger !== 'passive') {
      const directTimed = body.match(/^(at the end of each turn|at the end of your turn|at end of turn|at the start of your turn),\s*(.+)$/i);
      if (directTimed && (trigger === 'on_end_turn' || trigger === 'on_start_turn' || trigger === 'on_any_end_turn')) {
        body = normalizeAbilityText(directTimed[2]);
      }
      const triggeredBody = body.match(/^(whenever|when|after|at the end of each turn|at the end of your turn|at end of turn|at the start of your turn)\s+(.+?),\s*(.+)$/i);
      if (triggeredBody) {
        const lead = normalizeAbilityText(triggeredBody[2]);
        const action = normalizeAbilityText(triggeredBody[3]);
        if (trigger === 'on_end_turn' || trigger === 'on_start_turn' || trigger === 'on_any_end_turn') {
          body = action;
        } else {
          body = `If ${lead}, ${action}`;
        }
      }
    }
    clauses.push({
      raw: part,
      prefix,
      trigger,
      body,
    });
    previousTrigger = trigger;
  });

  return clauses;
}

export function clausesForEvent(text = '', eventKey = '') {
  const clauses = parseAbilityClauses(text);
  const wanted = String(eventKey ?? '').toLowerCase();
  if (!wanted) return clauses;
  return clauses.filter((clause) => clause.trigger === wanted);
}

export function extractIfCondition(body = '') {
  const source = normalizeAbilityText(body);
  const match = source.match(/^if\s+(.+?),(.+)$/i);
  if (!match) return null;
  const condition = normalizeAbilityText(match[1]);
  const thenText = normalizeAbilityText(match[2]);
  return { condition, thenText };
}

export function splitActions(body = '') {
  return normalizeAbilityText(body)
    .split(/\s*;\s*/)
    .flatMap((segment) => segment.split(/\s+then\s+/i))
    .map((entry) => normalizeAbilityText(entry))
    .filter(Boolean);
}

export function extractCostNumber(fragment = '', fallback = 1) {
  const source = normalizeAbilityText(fragment).toLowerCase();
  const bracketed = source.match(/\((\d+)\)/);
  if (bracketed) return Math.max(0, Number(bracketed[1]));
  return numberFromText(source, fallback);
}

export function looksLikeNoText(text = '') {
  const source = normalizeAbilityText(text).toLowerCase();
  return !source || source === 'no text' || source === 'no text.';
}
