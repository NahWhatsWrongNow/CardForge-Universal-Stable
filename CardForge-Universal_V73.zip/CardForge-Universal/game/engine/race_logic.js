const RAW_RACE_LIBRARY = [
  ['dragon', 'Dragon', 'DR'],
  ['dragonkin', 'Dragonkin', 'DK'],
  ['beast', 'Beast', 'BE'],
  ['spirit', 'Spirit', 'SP'],
  ['undead', 'Undead', 'UD'],
  ['human', 'Human', 'HU'],
  ['dwarf', 'Dwarf', 'DW'],
  ['warrior', 'Warrior', 'WA'],
  ['mage', 'Mage', 'MG'],
  ['construct', 'Construct', 'CT'],
  ['elemental', 'Elemental', 'EL'],
  ['demon', 'Demon', 'DM'],
  ['angel', 'Angel', 'AN'],
  ['serpent', 'Serpent', 'SE'],
  ['merfolk', 'Merfolk', 'MF'],
  ['giant', 'Giant', 'GI'],
  ['goblin', 'Goblin', 'GO'],
  ['orc', 'Orc', 'OR'],
  ['elf', 'Elf', 'EF'],
  ['vampire', 'Vampire', 'VP'],
  ['shifter', 'Shifter', 'SF'],
  ['insect', 'Insect', 'IS'],
  ['reptile', 'Reptile', 'RP'],
  ['avian', 'Avian', 'AV'],
  ['dryad', 'Dryad', 'DY'],
  ['troll', 'Troll', 'TR'],
  ['ooze', 'Ooze', 'OZ'],
  ['naga', 'Naga', 'NG'],
  ['djinn', 'Djinn', 'DJ'],
  ['golem', 'Golem', 'GL'],
  ['kitsune', 'Kitsune', 'KT'],
  ['minotaur', 'Minotaur', 'MN'],
  ['leviathan', 'Leviathan', 'LV'],
  ['myconid', 'Myconid', 'MY'],
  ['alchemist', 'Alchemist', 'AL'],
  ['witch', 'Witch', 'WI'],
  ['phoenix', 'Phoenix', 'PX'],
  ['lich', 'Lich', 'LI'],
  ['aldari', 'Aldari', 'AD'],
  ['chimera', 'Chimera', 'CH'],
  ['voidborn', 'Voidborn', 'VB'],
  ['machine', 'Machine', 'MC'],
  ['plant', 'Plant', 'PL'],
  ['aquatic', 'Aquatic', 'AQ'],
  ['insectoid', 'Insectoid', 'IN'],
  ['celestial', 'Celestial', 'CE'],
  ['mutant', 'Mutant', 'MU'],
  ['parasite', 'Parasite', 'PA'],
  ['ancient', 'Ancient', 'AC'],
  ['titan', 'Titan', 'TI'],
  ['knight', 'Knight', 'KN'],
  ['nomad', 'Nomad', 'NO'],
  ['wraith', 'Wraith', 'WR'],
  ['slime', 'Slime', 'SL'],
  ['ship', 'Ship', 'SH'],
  ['skeleton', 'Skeleton', 'SK'],
  ['handler', 'Handler', 'HD'],
  ['tamer', 'Tamer', 'TM'],
  ['token', 'Token', 'TK'],
];

export const RACE_LIBRARY = RAW_RACE_LIBRARY.map(([id, label, icon]) => ({ id, label, icon }));

const RACE_SET = new Set(RACE_LIBRARY.map((entry) => entry.id));
const FAMILY_ALIASES = {
  dragons: 'dragon',
  drake: 'dragon',
  drakes: 'dragon',
  wyrm: 'dragon',
  wyrms: 'dragon',
  dragonkins: 'dragonkin',
  beasts: 'beast',
  spirits: 'spirit',
  undeads: 'undead',
  humans: 'human',
  dwarves: 'dwarf',
  dwarfs: 'dwarf',
  warriors: 'warrior',
  mages: 'mage',
  constructs: 'construct',
  elementals: 'elemental',
  demons: 'demon',
  angels: 'angel',
  serpents: 'serpent',
  merfolk: 'merfolk',
  giants: 'giant',
  goblins: 'goblin',
  orcs: 'orc',
  elves: 'elf',
  vampires: 'vampire',
  shifters: 'shifter',
  insects: 'insect',
  insects: 'insect',
  reptiles: 'reptile',
  reptilians: 'reptile',
  avians: 'avian',
  birds: 'avian',
  dryads: 'dryad',
  trolls: 'troll',
  oozes: 'ooze',
  sludges: 'ooze',
  naga: 'naga',
  djinni: 'djinn',
  djin: 'djinn',
  golems: 'golem',
  kitsunes: 'kitsune',
  foxfolk: 'kitsune',
  minotaurs: 'minotaur',
  leviathans: 'leviathan',
  myconids: 'myconid',
  fungi: 'myconid',
  alchemists: 'alchemist',
  witches: 'witch',
  phoenixes: 'phoenix',
  liches: 'lich',
  aldari: 'aldari',
  chimeras: 'chimera',
  voidborn: 'voidborn',
  machines: 'machine',
  plants: 'plant',
  aquatics: 'aquatic',
  insectoids: 'insectoid',
  celestials: 'celestial',
  mutants: 'mutant',
  parasites: 'parasite',
  ancients: 'ancient',
  titans: 'titan',
  knights: 'knight',
  nomads: 'nomad',
  wraiths: 'wraith',
  slimes: 'slime',
  ships: 'ship',
  skeletons: 'skeleton',
  handlers: 'handler',
  tamers: 'tamer',
  followers: 'human',
};

function splitMixedList(value = '') {
  if (Array.isArray(value)) return value.flatMap((entry) => splitMixedList(entry));
  return String(value ?? '')
    .split(/[|,/]/)
    .flatMap((chunk) => String(chunk).split(/\s+&\s+|\s+and\s+/i))
    .map((token) => token.trim())
    .filter(Boolean);
}

export function normalizeFamilyToken(token = '') {
  const raw = String(token ?? '')
    .trim()
    .toLowerCase()
    .replace(/^race:/, '')
    .replace(/^type:/, '')
    .replace(/^tribe:/, '')
    .replace(/^species:/, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  if (!raw) return '';
  return FAMILY_ALIASES[raw] ?? raw;
}

export function raceMeta(token = '') {
  const id = normalizeFamilyToken(token);
  return RACE_LIBRARY.find((entry) => entry.id === id) ?? {
    id,
    label: id ? id.replace(/(^|-)([a-z])/g, (_, p1, p2) => `${p1}${p2.toUpperCase()}`) : 'Unknown',
    icon: (id || '?').slice(0, 2).toUpperCase(),
  };
}

export function raceIconGlyph(token = '') {
  return raceMeta(token).icon;
}

export function normalizeRaceList(value = []) {
  return [...new Set(splitMixedList(value).map(normalizeFamilyToken).filter(Boolean))];
}

export function extractCardRaces(card = {}) {
  const direct = normalizeRaceList(card.races ?? []);
  const legacy = normalizeRaceList(card.race ?? '');
  const tags = Array.isArray(card.tags)
    ? normalizeRaceList(card.tags
      .filter((tag) => /^race:/i.test(String(tag)) || /^type:/i.test(String(tag)) || RACE_SET.has(normalizeFamilyToken(tag))))
    : [];
  return [...new Set([...direct, ...legacy, ...tags])];
}

export function extractCardTypes(card = {}) {
  const types = normalizeRaceList(card.types ?? []);
  const subtypes = normalizeRaceList(card.subtypes ?? []);
  const keywords = normalizeRaceList(card.keywords ?? []);
  const typeName = normalizeFamilyToken(card.type ?? '');
  const tags = Array.isArray(card.tags)
    ? normalizeRaceList(card.tags.filter((tag) => /^type:/i.test(String(tag))))
    : [];
  return [...new Set([typeName, ...types, ...subtypes, ...keywords, ...tags].filter(Boolean))];
}

export function collectCardFamilies(card = {}) {
  return [...new Set([...extractCardRaces(card), ...extractCardTypes(card), ...normalizeRaceList(card.tags ?? [])])];
}

export function hasFamilyTag(card = {}, token = '') {
  const needle = normalizeFamilyToken(token);
  if (!needle) return false;
  return collectCardFamilies(card).includes(needle)
    || String(card?.name ?? '').toLowerCase().includes(needle);
}

export function countCardsByFamily(cards = [], token = '', matcher = null) {
  const needle = normalizeFamilyToken(token);
  if (!needle) return 0;
  return cards.filter((card) => {
    if (!card) return false;
    if (typeof matcher === 'function' && !matcher(card)) return false;
    return hasFamilyTag(card, needle);
  }).length;
}

export function countFamilyOccurrences(cards = [], matcher = null) {
  const counts = {};
  cards.forEach((card) => {
    if (!card) return;
    if (typeof matcher === 'function' && !matcher(card)) return;
    collectCardFamilies(card).forEach((family) => {
      counts[family] = (counts[family] ?? 0) + 1;
    });
  });
  return counts;
}

export function deckContainsOnlyFamily(cards = [], token = '') {
  const needle = normalizeFamilyToken(token);
  if (!needle || !Array.isArray(cards) || !cards.length) return false;
  return cards.every((card) => hasFamilyTag(card, needle));
}

export function deckContainsOnlyFamilies(cards = [], tokens = []) {
  const allowed = normalizeRaceList(tokens);
  if (!allowed.length || !Array.isArray(cards) || !cards.length) return false;
  return cards.every((card) => {
    const families = collectCardFamilies(card);
    return families.length > 0 && families.every((family) => allowed.includes(family));
  });
}

export function boardFamilyRatio(cards = [], token = '', matcher = null) {
  const filtered = cards.filter((card) => {
    if (!card) return false;
    if (typeof matcher === 'function' && !matcher(card)) return false;
    return true;
  });
  if (!filtered.length) return 0;
  return countCardsByFamily(filtered, token) / filtered.length;
}

export function ensureFamiliarityPool(pool = {}) {
  return pool && typeof pool === 'object' ? pool : {};
}

export function getFamiliarity(pool = {}, token = '') {
  const needle = normalizeFamilyToken(token);
  if (!needle) return 0;
  return Math.max(0, Number(ensureFamiliarityPool(pool)[needle] ?? 0));
}

export function addFamiliarity(pool = {}, token = '', amount = 1) {
  const needle = normalizeFamilyToken(token);
  if (!needle) return 0;
  const target = ensureFamiliarityPool(pool);
  target[needle] = Math.max(0, Number(target[needle] ?? 0) + Number(amount ?? 0));
  return target[needle];
}

export function spendFamiliarity(pool = {}, token = '', amount = 1) {
  const needle = normalizeFamilyToken(token);
  if (!needle) return 0;
  const target = ensureFamiliarityPool(pool);
  target[needle] = Math.max(0, Number(target[needle] ?? 0) - Math.max(0, Number(amount ?? 0)));
  return target[needle];
}
