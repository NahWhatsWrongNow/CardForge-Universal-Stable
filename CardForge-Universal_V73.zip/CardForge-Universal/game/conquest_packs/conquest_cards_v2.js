(() => {
  const asTagList = (value) => (Array.isArray(value) ? value : []).map((entry) => String(entry).trim().toLowerCase()).filter(Boolean);
  const rep = (cardId, count) => Array.from({ length: Math.max(0, Number(count) || 0) }, () => String(cardId));

  function card(def = {}) {
    const sourceBuilding = String(def.sourceBuilding ?? def.productionSource ?? 'utility').toLowerCase();
    const side = String(def.side ?? (sourceBuilding === 'attacker' ? 'attacker' : 'defender')).toLowerCase();
    const wheatCost = Math.max(0, Number(def.wheatCost ?? 0));
    const ironCost = Math.max(0, Number(def.ironCost ?? 0));
    const manaCost = Math.max(0, Number(def.manaCost ?? 0));
    const tags = new Set(asTagList(def.tags));
    tags.add('conquest');
    tags.add(sourceBuilding);
    tags.add(side);
    if (def.horde) tags.add('horde');
    if (def.flying) tags.add('flying');
    if (def.large) tags.add('large');
    if (def.structure) tags.add('structure');
    if (def.barricade) tags.add('barricade');
    if (def.facility) tags.add('facility');
    if (def.fortified) tags.add('fortified');
    if (def.equipment) tags.add('equipment');
    if (def.upgradeSchematic) tags.add('schematic');
    if (def.captureRelevant) tags.add('capture');
    if (def.repairRelevant) tags.add('repair');
    if (def.attackerPackage) tags.add(`pkg:${String(def.attackerPackage).toLowerCase()}`);
    if (def.range && Number(def.range) > 1) tags.add('ranged');
    if (def.siege && Number(def.siege) > 0) tags.add('siege');
    return {
      id: String(def.id),
      name: String(def.name),
      mode: 'conquest',
      side,
      cardType: String(def.cardType ?? 'Unit'),
      subtype: String(def.subtype ?? ''),
      techTier: String(def.techTier ?? 'Bronze 1'),
      faction: def.faction ? String(def.faction) : null,
      species: def.species ? String(def.species) : null,
      productionSource: sourceBuilding,
      sourceBuilding,
      type: String(def.type ?? (
        def.upgradeSchematic || def.equipment ? 'upgrade'
          : String(def.cardType ?? '').toLowerCase().includes('tactic') ? 'tactic'
            : String(def.cardType ?? '').toLowerCase().includes('spell') ? 'spell'
              : String(def.subtype ?? '').toLowerCase().includes('mana pylon') ? 'pylon'
                : String(def.cardType ?? '').toLowerCase().includes('structure') ? 'building' : 'unit'
      )),
      wheatCost,
      ironCost,
      manaCost,
      cost: { wheat: wheatCost, iron: ironCost, mana: manaCost },
      attack: Math.max(0, Number(def.attack ?? 0)),
      health: Math.max(0, Number(def.health ?? 0)),
      defense: Math.max(0, Number(def.defense ?? 0)),
      range: Math.max(1, Math.min(5, Number(def.range ?? 1))),
      siege: Math.max(0, Number(def.siege ?? 0)),
      flying: !!def.flying,
      horde: !!def.horde,
      large: !!def.large,
      fortified: !!def.fortified,
      structure: !!def.structure,
      barricade: !!def.barricade,
      facility: !!def.facility,
      equipment: !!def.equipment,
      upgradeSchematic: !!def.upgradeSchematic,
      repairRelevant: !!def.repairRelevant,
      captureRelevant: !!def.captureRelevant,
      attackerPackage: def.attackerPackage ? String(def.attackerPackage) : null,
      text: String(def.text ?? ''),
      tags: Array.from(tags),
      flavorText: String(def.flavorText ?? ''),
      production: def.production && typeof def.production === 'object' ? { ...def.production } : null,
      tactic: def.tactic && typeof def.tactic === 'object' ? { ...def.tactic } : null,
    };
  }

  const cards = [];
  const defenderUtility = [
    { id: 'cq-farm', name: 'Farm', sourceBuilding: 'utility', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, attack: 0, health: 5, defense: 1, text: 'Start of your turn, gain 3 Wheat.', production: { wheatPerTurn: 3 }, tags: ['farm', 'economy', 'starting-asset'] },
    { id: 'cq-mine', name: 'Mine', sourceBuilding: 'utility', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, attack: 0, health: 5, defense: 1, text: 'Start of your turn, gain 3 Iron.', production: { ironPerTurn: 3 }, tags: ['mine', 'economy', 'starting-asset'] },
    { id: 'cq-factory', name: 'Factory', sourceBuilding: 'utility', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, attack: 0, health: 6, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Factory Deck.', tags: ['factory', 'production', 'starting-asset'] },
    { id: 'cq-training-facility', name: 'Training Facility', sourceBuilding: 'utility', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, attack: 0, health: 6, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Training Deck.', tags: ['training', 'production', 'starting-asset'] },
    { id: 'cq-blacksmith', name: 'Blacksmith', sourceBuilding: 'utility', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 3, ironCost: 3, attack: 0, health: 5, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Blacksmith Deck. Can only be used once each turn.', tags: ['blacksmith', 'production'] },
    { id: 'cq-barricade', name: 'Barricade', sourceBuilding: 'factory', cardType: 'Structure', subtype: 'Barricade', structure: true, barricade: true, fortified: true, attack: 0, health: 8, defense: 2, text: 'Blocks attacks through this lane/cell. Units behind it cannot be targeted by normal ground attacks through this line while it stands.', tags: ['wall', 'starter-asset'] },
    { id: 'cq-turret', name: 'Turret', sourceBuilding: 'factory', cardType: 'Structure', subtype: 'Turret', structure: true, attack: 3, health: 6, defense: 1, range: 2, text: 'Ranged 2. Cannot move. Cannot fire through a friendly Barricade directly in front of it. Can target air or ground.', tags: ['turret', 'starter-asset'] },
    { id: 'cq-storage', name: 'Storage', sourceBuilding: 'utility', cardType: 'Structure', subtype: 'Logistics', structure: true, wheatCost: 2, ironCost: 2, attack: 0, health: 6, defense: 1, text: 'Your max stored Wheat increases by 5. Your max stored Iron increases by 5.', tags: ['storage', 'economy'] },
    { id: 'cq-field-hospital', name: 'Field Hospital', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Support', structure: true, wheatCost: 3, ironCost: 1, attack: 0, health: 5, defense: 1, text: 'Start of your turn, heal 2 damage split among adjacent allied units or structures.', tags: ['heal', 'support'] },
    { id: 'cq-watchtower', name: 'Watchtower', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Support', structure: true, wheatCost: 2, ironCost: 3, attack: 0, health: 5, defense: 1, text: 'Adjacent Turrets gain +1 Range. Adjacent infantry gain +1 targeting priority visibility if supported.', tags: ['turret-support', 'intel'] },
    { id: 'cq-command-relay', name: 'Command Relay', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Support', structure: true, wheatCost: 3, ironCost: 2, attack: 0, health: 5, defense: 1, text: 'Once each turn, one adjacent allied unit may move and still attack.', tags: ['command', 'mobility'] },
  ];
  cards.push(...defenderUtility.map(card));

  const trainingBaseline = [
    { id: 'cq-militia-recruit', name: 'Militia Recruit', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry', wheatCost: 1, attack: 1, health: 1, defense: 0, text: 'Basic recruit.', tags: ['starter', 'cheap'] },
    { id: 'cq-shieldbearer', name: 'Shieldbearer', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry', wheatCost: 2, ironCost: 1, attack: 1, health: 3, defense: 1, fortified: true, text: 'Fortified. Adjacent allies gain +1 HP while this stands.', tags: ['defense', 'support'] },
    { id: 'cq-archer-cadet', name: 'Archer Cadet', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry Ranged', wheatCost: 2, attack: 2, health: 1, defense: 0, range: 2, text: 'Ranged 2.', tags: ['anti-air'] },
    { id: 'cq-pike-recruit', name: 'Pike Recruit', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry', wheatCost: 2, ironCost: 1, attack: 2, health: 2, defense: 0, text: 'Deals +2 damage against Flying or charging Large units if supported.', tags: ['anti-large', 'anti-flying'] },
    { id: 'cq-scout-runner', name: 'Scout Runner', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry Scout', wheatCost: 1, attack: 1, health: 1, defense: 0, text: 'May move 1 extra cell instead of attacking.', tags: ['scout', 'mobility'] },
    { id: 'cq-combat-medic', name: 'Combat Medic', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry Support', wheatCost: 2, attack: 1, health: 2, defense: 0, text: 'End of your turn, heal adjacent ally 1.', tags: ['heal', 'support'] },
    { id: 'cq-sapper-team', name: 'Sapper Team', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry Siege', wheatCost: 2, ironCost: 2, attack: 1, health: 2, defense: 0, siege: 3, text: 'Siege 3. If this destroys a Barricade, draw 1 Factory card if supported.', tags: ['siege', 'breach'] },
    { id: 'cq-halberdier-file', name: 'Halberdier File', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry', wheatCost: 3, ironCost: 1, attack: 3, health: 2, defense: 0, text: 'The first time this attacks a Large unit each turn, deal +2 damage.', tags: ['anti-large'] },
    { id: 'cq-crossbow-cell', name: 'Crossbow Cell', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry Ranged', wheatCost: 3, ironCost: 2, attack: 3, health: 2, defense: 0, range: 3, text: 'Ranged 3. Cannot move and attack in the same turn unless another effect allows it.', tags: ['ranged', 'line-hold'] },
    { id: 'cq-banner-captain', name: 'Banner Captain', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Officer', wheatCost: 4, ironCost: 2, attack: 2, health: 4, defense: 1, text: 'Adjacent allied troops gain +1 ATK.', tags: ['morale', 'officer'] },
    { id: 'cq-veteran-wallguard', name: 'Veteran Wallguard', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry', wheatCost: 4, ironCost: 2, attack: 3, health: 5, defense: 1, fortified: true, text: 'Fortified. Adjacent Barricades gain +1 DEF.', tags: ['wall-support'] },
    { id: 'cq-stormline-marksman', name: 'Stormline Marksman', sourceBuilding: 'training', cardType: 'Unit', subtype: 'Infantry Ranged', wheatCost: 4, ironCost: 1, attack: 4, health: 2, defense: 0, range: 3, text: 'Ranged 3. Deals +2 damage to Flying enemies.', tags: ['anti-flying', 'ranged'] },
  ];
  cards.push(...trainingBaseline.map(card));
  const trainingExtras = [
    ['lancer-patrol', 'Lancer Patrol', 3, 3, 0, 3, 2, 'cavalry'],
    ['falcon-spotter', 'Falcon Spotter', 1, 2, 0, 2, 1, 'scout'],
    ['iron-pike-veteran', 'Iron Pike Veteran', 3, 3, 1, 3, 2, 'anti-large'],
    ['reserve-spear-cohort', 'Reserve Spear Cohort', 2, 2, 0, 2, 1, 'reserve'],
    ['trenchline-riflemen', 'Trenchline Riflemen', 2, 3, 0, 3, 1, 'ranged'],
    ['wardrum-sergeant', 'Wardrum Sergeant', 2, 3, 0, 1, 1, 'morale'],
    ['bulwark-chaplain', 'Bulwark Chaplain', 2, 4, 1, 1, 2, 'heal'],
    ['frontier-rider', 'Frontier Rider', 3, 2, 0, 3, 1, 'cavalry'],
    ['sapper-engineer', 'Sapper Engineer', 1, 3, 0, 1, 2, 'repair'],
    ['siege-spotter', 'Siege Spotter', 2, 2, 0, 2, 1, 'siege'],
    ['anti-horde-grenadier', 'Anti-Horde Grenadier', 3, 2, 0, 2, 2, 'anti-horde'],
    ['shieldline-marshal', 'Shieldline Marshal', 3, 5, 1, 1, 2, 'officer'],
    ['veteran-arbalest', 'Veteran Arbalest', 4, 3, 0, 3, 2, 'ranged'],
    ['pikewall-cohort', 'Pikewall Cohort', 3, 4, 1, 1, 2, 'anti-large'],
    ['rapid-courier', 'Rapid Courier', 1, 2, 0, 1, 1, 'scout'],
    ['hearthguard-lieutenant', 'Hearthguard Lieutenant', 4, 4, 1, 1, 2, 'officer'],
    ['reclaimer-squad', 'Reclaimer Squad', 2, 3, 0, 1, 2, 'repair'],
    ['ironhorn-cavalry', 'Ironhorn Cavalry', 5, 4, 1, 1, 3, 'elite'],
  ];
  trainingExtras.forEach(([id, name, atk, hp, def, range, ironCost, role]) => {
    cards.push(card({
      id: `cq-${id}`,
      name,
      sourceBuilding: 'training',
      cardType: 'Unit',
      subtype: role === 'officer' ? 'Officer' : role === 'cavalry' ? 'Infantry Cavalry' : 'Infantry',
      wheatCost: Math.max(1, atk - 1),
      ironCost,
      attack: atk,
      health: hp,
      defense: def,
      range,
      text: role === 'repair' ? 'Action: Repair 2 to an adjacent structure or barricade.' : `Specialist role: ${role}.`,
      tags: [role],
      repairRelevant: role === 'repair',
      captureRelevant: role === 'reserve' || role === 'scout',
    }));
  });

  const blacksmithBaseline = [
    { id: 'cq-iron-shortsword', name: 'Iron Shortsword', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Weapon', equipment: true, wheatCost: 1, ironCost: 1, attack: 1, text: 'Equip to Infantry. +1 ATK.', tags: ['weapon'] },
    { id: 'cq-steel-longsword', name: 'Steel Longsword', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Weapon', equipment: true, wheatCost: 2, ironCost: 2, attack: 2, text: 'Equip to Infantry. +2 ATK.', tags: ['weapon'] },
    { id: 'cq-spear-rack', name: 'Spear Rack', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Weapon', equipment: true, wheatCost: 2, ironCost: 1, attack: 1, text: 'Equip to Infantry. +1 ATK and +2 damage against Flying.', tags: ['weapon', 'anti-flying'] },
    { id: 'cq-longbow-set', name: 'Longbow Set', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Weapon', equipment: true, wheatCost: 2, ironCost: 2, attack: 1, range: 2, text: 'Equip to a Ranged unit. It gets +1 ATK and +1 Range.', tags: ['weapon', 'ranged'] },
    { id: 'cq-fire-arrow-bundle', name: 'Fire Arrow Bundle', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Ammunition', equipment: true, wheatCost: 1, ironCost: 2, attack: 1, text: 'Equip to a Ranged unit. Attacks deal explosive splash 2 to Hordes.', tags: ['ammo', 'explosive', 'anti-horde'] },
    { id: 'cq-leather-jerkin', name: 'Leather Jerkin', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Armour', equipment: true, wheatCost: 1, ironCost: 1, health: 1, text: 'Equip to Infantry. +1 HP.', tags: ['armour'] },
    { id: 'cq-iron-mail', name: 'Iron Mail', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Armour', equipment: true, wheatCost: 2, ironCost: 2, health: 2, defense: 1, text: 'Equip to Infantry. +2 HP and +1 DEF.', tags: ['armour'] },
    { id: 'cq-tower-shield-harness', name: 'Tower Shield Harness', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Armour', equipment: true, fortified: true, wheatCost: 2, ironCost: 2, health: 1, defense: 1, text: 'Equip to Infantry. +1 DEF and Fortified.', tags: ['armour', 'fortified'] },
    { id: 'cq-steel-helm', name: 'Steel Helm', sourceBuilding: 'blacksmith', cardType: 'Equipment', subtype: 'Armour', equipment: true, wheatCost: 1, ironCost: 1, health: 1, text: 'Equip to Infantry. +1 HP. The first explosive hit each battle cannot Shaken this unit.', tags: ['armour', 'anti-explosive'] },
    { id: 'cq-silver-turret-upgrade', name: 'Silver Turret Upgrade Schematic', sourceBuilding: 'blacksmith', cardType: 'Upgrade Schematic', subtype: 'Turret', upgradeSchematic: true, wheatCost: 3, ironCost: 4, attack: 1, health: 2, defense: 1, text: 'Upgrade a Turret. It gets +2 HP, +1 DEF, cannot attack this turn, and from next turn gains +1 ATK.', tags: ['upgrade', 'turret'] },
    { id: 'cq-silver-barricade-upgrade', name: 'Silver Barricade Upgrade Schematic', sourceBuilding: 'blacksmith', cardType: 'Upgrade Schematic', subtype: 'Barricade', upgradeSchematic: true, fortified: true, wheatCost: 2, ironCost: 4, health: 4, defense: 1, text: 'Upgrade a Barricade. It gets +4 HP, +1 DEF, and Fortified.', tags: ['upgrade', 'barricade'] },
    { id: 'cq-repair-blueprint', name: 'Repair Blueprint', sourceBuilding: 'blacksmith', cardType: 'Utility', subtype: 'Repair', type: 'tactic', wheatCost: 2, ironCost: 1, text: 'Repair 4 to a Structure or Barricade you control.', tags: ['repair', 'blueprint'], repairRelevant: true, tactic: { kind: 'repair', amount: 4 } },
  ];
  cards.push(...blacksmithBaseline.map(card));

  const blacksmithExtras = [
    ['tempered-greatblade', 'Tempered Greatblade', 3, 0, 0, 3, 3, 'weapon'],
    ['windhook-halberd', 'Windhook Halberd', 2, 0, 0, 2, 3, 'anti-flying'],
    ['skyhook-bolt-set', 'Skyhook Bolt Set', 1, 0, 0, 2, 3, 'ranged'],
    ['bombard-satchel', 'Bombard Satchel', 2, 0, 0, 1, 3, 'anti-horde'],
    ['composite-tower-shield', 'Composite Tower Shield', 0, 2, 2, 3, 3, 'fortified'],
    ['riveted-plate-harness', 'Riveted Plate Harness', 0, 3, 2, 3, 4, 'armour'],
    ['gold-turret-upgrade', 'Gold Turret Upgrade Schematic', 2, 4, 2, 5, 6, 'turret'],
    ['gold-barricade-upgrade', 'Gold Barricade Upgrade Schematic', 0, 6, 2, 4, 6, 'barricade'],
    ['engineer-toolbelt', 'Engineer Toolbelt', 0, 1, 1, 2, 2, 'repair'],
    ['wall-brace-kit', 'Wall Brace Kit', 0, 3, 1, 2, 2, 'barricade'],
    ['precision-sight-rig', 'Turret Precision Sights', 1, 1, 0, 2, 3, 'turret'],
    ['siege-hammer', 'Siege Hammer', 2, 0, 0, 3, 3, 'siege'],
    ['anti-giant-pikehead', 'Anti-Giant Pikehead', 1, 0, 0, 2, 3, 'anti-large'],
    ['morale-banner-loom', 'Morale Banner Loom', 1, 1, 0, 2, 2, 'morale'],
    ['blast-powder-cask', 'Blast Powder Cask', 0, 0, 0, 2, 3, 'explosive'],
    ['rapid-rivet-kit', 'Rapid Rivet Kit', 0, 0, 0, 1, 2, 'repair'],
  ];
  blacksmithExtras.forEach(([id, name, atk, hp, def, wheatCost, ironCost, role]) => {
    cards.push(card({
      id: `cq-${id}`,
      name,
      sourceBuilding: 'blacksmith',
      cardType: role === 'explosive' || role === 'repair' ? 'Utility' : role === 'turret' || role === 'barricade' ? 'Upgrade Schematic' : 'Equipment',
      subtype: role,
      type: role === 'explosive' || role === 'repair' ? 'tactic' : undefined,
      equipment: !['turret', 'barricade', 'explosive', 'repair'].includes(role),
      upgradeSchematic: ['turret', 'barricade'].includes(role),
      repairRelevant: role === 'repair',
      wheatCost,
      ironCost,
      attack: atk,
      health: hp,
      defense: def,
      text: role === 'repair' ? 'Repair nearby structures.' : `Specialized ${role} package.`,
      tags: [role],
      tactic: role === 'explosive' ? { kind: 'blast-cell', amount: 5 } : role === 'repair' ? { kind: 'repair', amount: 3 } : null,
    }));
  });

  const blacksmithArmourIds = [];
  const armourFamilies = [
    { key: 'padded', title: 'Padded', hp: 1, def: 0, wheat: 1, iron: 1, tier: 'Bronze 1', tags: ['armour', 'light'] },
    { key: 'brigandine', title: 'Brigandine', hp: 2, def: 1, wheat: 2, iron: 2, tier: 'Bronze 2', tags: ['armour', 'medium'] },
    { key: 'scaleguard', title: 'Scaleguard', hp: 2, def: 1, wheat: 2, iron: 3, tier: 'Silver 1', tags: ['armour', 'frontline'] },
    { key: 'plate', title: 'Plate', hp: 3, def: 2, wheat: 3, iron: 4, tier: 'Silver 2', tags: ['armour', 'heavy', 'fortified'] },
    { key: 'bastion', title: 'Bastion', hp: 4, def: 2, wheat: 4, iron: 5, tier: 'Gold 1', tags: ['armour', 'elite', 'fortified'] },
    { key: 'skywarden', title: 'Skywarden', hp: 2, def: 1, wheat: 2, iron: 3, tier: 'Silver 1', tags: ['armour', 'anti-flying', 'spotter'] },
    { key: 'blastshield', title: 'Blastshield', hp: 3, def: 1, wheat: 3, iron: 3, tier: 'Silver 1', tags: ['armour', 'anti-explosive'] },
    { key: 'wallguard', title: 'Wallguard', hp: 3, def: 2, wheat: 3, iron: 4, tier: 'Silver 2', tags: ['armour', 'barricade-support', 'fortified'] },
    { key: 'trailrunner', title: 'Trailrunner', hp: 1, def: 1, wheat: 2, iron: 2, tier: 'Bronze 2', tags: ['armour', 'mobility'] },
    { key: 'commandant', title: 'Commandant', hp: 2, def: 2, wheat: 3, iron: 4, tier: 'Gold 1', tags: ['armour', 'officer', 'morale'] },
  ];
  const armourSlots = ['Helm', 'Cuirass', 'Greaves', 'Mantle'];
  armourFamilies.forEach((family, famIdx) => {
    armourSlots.forEach((slot, slotIdx) => {
      const id = `cq-${family.key}-${slot.toLowerCase()}`;
      blacksmithArmourIds.push(id);
      cards.push(card({
        id,
        name: `${family.title} ${slot}`,
        sourceBuilding: 'blacksmith',
        cardType: 'Equipment',
        subtype: `Armour ${slot}`,
        equipment: true,
        techTier: family.tier,
        wheatCost: family.wheat + (slotIdx >= 2 ? 1 : 0),
        ironCost: family.iron + (slotIdx === 1 ? 1 : 0),
        attack: family.tags.includes('officer') ? 1 : 0,
        health: family.hp + (slotIdx === 1 ? 1 : 0),
        defense: family.def + (slot === 'Helm' ? 0 : 1),
        fortified: family.tags.includes('fortified'),
        text: family.tags.includes('anti-explosive')
          ? 'Equip to allied troop or structure. First explosive hit each battle cannot Shaken this target.'
          : family.tags.includes('anti-flying')
            ? 'Equip to allied troop. Gains anti-air targeting support and +1 range if already ranged.'
            : family.tags.includes('barricade-support')
              ? 'Equip to frontline troop. Adjacent barricades gain +1 DEF while this unit stands.'
              : family.tags.includes('mobility')
                ? 'Equip to allied troop. May move and still attack once per turn if command relay effects are active.'
                : family.tags.includes('officer')
                  ? 'Equip to Officer. Adjacent allies gain morale resistance and +1 ATK while this is equipped.'
                  : 'Equip to allied troop or structure. Durable armour package for lane holding.',
        tags: [...family.tags, 'equipment', 'armour', `armour-slot:${slot.toLowerCase()}`],
      }));
    });
  });

  const blacksmithWeaponIds = [];
  const weaponFamilies = [
    { key: 'iron-shortblade', title: 'Iron Shortblade', atk: 1, wheat: 1, iron: 1, range: 1, tier: 'Bronze 1', tags: ['weapon', 'melee'] },
    { key: 'steel-longsword', title: 'Steel Longsword', atk: 2, wheat: 2, iron: 2, range: 1, tier: 'Bronze 2', tags: ['weapon', 'melee'] },
    { key: 'warden-halberd', title: 'Warden Halberd', atk: 2, wheat: 2, iron: 3, range: 1, tier: 'Silver 1', tags: ['weapon', 'anti-large'] },
    { key: 'storm-pike', title: 'Storm Pike', atk: 2, wheat: 2, iron: 3, range: 1, tier: 'Silver 1', tags: ['weapon', 'anti-flying'] },
    { key: 'longbow-frame', title: 'Longbow Frame', atk: 1, wheat: 2, iron: 2, range: 2, tier: 'Bronze 2', tags: ['weapon', 'ranged'] },
    { key: 'arbalest-crank', title: 'Arbalest Crank', atk: 2, wheat: 3, iron: 3, range: 2, tier: 'Silver 1', tags: ['weapon', 'ranged', 'anti-armour'] },
    { key: 'flame-bolt-quiver', title: 'Flame-Bolt Quiver', atk: 1, wheat: 2, iron: 3, range: 2, tier: 'Silver 1', tags: ['weapon', 'ammo', 'explosive', 'anti-horde'] },
    { key: 'breaker-maul', title: 'Breaker Maul', atk: 3, wheat: 3, iron: 4, range: 1, tier: 'Silver 2', tags: ['weapon', 'siege', 'anti-structure'] },
    { key: 'shock-lance', title: 'Shock Lance', atk: 3, wheat: 3, iron: 4, range: 1, tier: 'Gold 1', tags: ['weapon', 'capture', 'charge'] },
    { key: 'command-bannerblade', title: 'Command Bannerblade', atk: 2, wheat: 3, iron: 4, range: 1, tier: 'Gold 1', tags: ['weapon', 'officer', 'morale'] },
  ];
  const weaponVariants = ['Pattern A', 'Pattern B', 'Pattern C', 'Pattern D'];
  weaponFamilies.forEach((family, famIdx) => {
    weaponVariants.forEach((variant, idx) => {
      const id = `cq-${family.key}-${String.fromCharCode(97 + idx)}`;
      blacksmithWeaponIds.push(id);
      cards.push(card({
        id,
        name: `${family.title} ${variant}`,
        sourceBuilding: 'blacksmith',
        cardType: 'Equipment',
        subtype: 'Weapon',
        equipment: true,
        techTier: family.tier,
        wheatCost: family.wheat + (idx >= 2 ? 1 : 0),
        ironCost: family.iron + (idx === 3 ? 1 : 0),
        attack: family.atk + (idx === 3 ? 1 : 0),
        health: family.tags.includes('officer') ? 1 : 0,
        defense: family.tags.includes('anti-armour') ? 1 : 0,
        range: family.range,
        siege: family.tags.includes('siege') ? 2 : 0,
        text: family.tags.includes('ranged')
          ? 'Equip to ranged-capable troop. Gains +ATK and improved lane pressure at range.'
          : family.tags.includes('anti-flying')
            ? 'Equip to infantry. Gains +2 damage against flying threats.'
            : family.tags.includes('anti-large')
              ? 'Equip to infantry. First strike against Large this turn deals +2 damage.'
              : family.tags.includes('explosive')
                ? 'Equip to ranged troop. Attacks splash horde targets in the struck cell.'
                : family.tags.includes('anti-structure')
                  ? 'Equip to troop. Gains +2 siege damage against barricades and structures.'
                  : family.tags.includes('capture')
                    ? 'Equip to mobile troop. Capturing a neutral/enemy cell grants +1 ATK until end of turn.'
                    : family.tags.includes('officer')
                      ? 'Equip to officer. Adjacent allies gain +1 attack while this officer survives.'
                      : 'Equip to allied troop. Reliable frontline weapon package.',
        tags: [...family.tags, 'weapon', 'equipment', `weapon-variant:${idx + 1}`],
      }));
    });
  });

  const trainingExpansionIds = [];
  const trainingRoles = [
    { key: 'lineholder', role: 'line-holder', atk: 2, hp: 3, def: 1, range: 1, wheat: 2, iron: 1, tags: ['infantry', 'frontline'] },
    { key: 'skirmisher', role: 'skirmisher', atk: 3, hp: 2, def: 0, range: 1, wheat: 2, iron: 1, tags: ['infantry', 'mobility'] },
    { key: 'marksman', role: 'marksman', atk: 3, hp: 2, def: 0, range: 2, wheat: 3, iron: 1, tags: ['infantry', 'ranged', 'anti-flying'] },
    { key: 'engineer', role: 'engineer', atk: 1, hp: 3, def: 0, range: 1, wheat: 2, iron: 2, tags: ['infantry', 'repair', 'support'] },
    { key: 'wallguard', role: 'wallguard', atk: 2, hp: 4, def: 1, range: 1, wheat: 3, iron: 2, tags: ['infantry', 'fortified', 'barricade-support'] },
    { key: 'officer', role: 'officer', atk: 2, hp: 4, def: 1, range: 1, wheat: 4, iron: 2, tags: ['officer', 'morale', 'command'] },
    { key: 'anti-horde', role: 'grenadier', atk: 3, hp: 3, def: 0, range: 2, wheat: 3, iron: 2, tags: ['infantry', 'anti-horde', 'explosive'] },
    { key: 'anti-large', role: 'giant-hunter', atk: 3, hp: 3, def: 1, range: 1, wheat: 3, iron: 2, tags: ['infantry', 'anti-large'] },
    { key: 'reserve', role: 'reserve', atk: 2, hp: 2, def: 0, range: 1, wheat: 1, iron: 1, tags: ['reserve', 'capture'] },
    { key: 'medic', role: 'medic', atk: 1, hp: 3, def: 0, range: 1, wheat: 2, iron: 1, tags: ['support', 'heal'] },
  ];
  const trainingTitles = ['Cadre', 'Detachment', 'File', 'Corps'];
  trainingRoles.forEach((role, rIdx) => {
    trainingTitles.forEach((title, tIdx) => {
      const id = `cq-${role.key}-${title.toLowerCase()}`;
      trainingExpansionIds.push(id);
      cards.push(card({
        id,
        name: `${role.role.replace(/(^|[-])/g, (m) => m === '-' ? ' ' : m.toUpperCase())} ${title}`,
        sourceBuilding: 'training',
        cardType: 'Unit',
        subtype: role.tags.includes('officer') ? 'Officer' : role.tags.includes('ranged') ? 'Infantry Ranged' : 'Infantry',
        wheatCost: role.wheat + (tIdx === 3 ? 1 : 0),
        ironCost: role.iron + (tIdx >= 2 ? 1 : 0),
        attack: role.atk + (tIdx === 3 ? 1 : 0),
        health: role.hp + (title === 'Corps' ? 1 : 0),
        defense: role.def,
        range: role.range,
        fortified: role.tags.includes('fortified'),
        siege: role.tags.includes('anti-large') ? 1 : 0,
        text: role.tags.includes('repair')
          ? 'Action: Repair 2 to adjacent structure or barricade. If this repairs, it cannot attack this turn.'
          : role.tags.includes('heal')
            ? 'End of your turn, heal 1 to up to two adjacent allies.'
            : role.tags.includes('capture')
              ? 'When this unit captures a cell, draw 1 training card if available.'
              : role.tags.includes('morale')
                ? 'Adjacent allies gain morale resistance and +1 attack while this unit stands.'
                : role.tags.includes('anti-horde')
                  ? 'Attacks against hordes are explosive.'
                  : role.tags.includes('anti-large')
                    ? 'First attack each turn against Large deals +2 damage.'
                    : role.tags.includes('mobility')
                      ? 'May move and still attack once each turn.'
                      : 'Reliable conquest troop for lane pressure and objective defense.',
        tags: [...role.tags, 'unit', 'training-expansion'],
        repairRelevant: role.tags.includes('repair'),
        captureRelevant: role.tags.includes('capture') || role.tags.includes('mobility'),
      }));
    });
  });

  const factoryExpansionIds = [];
  const factoryPatterns = [
    { key: 'flak-tower', type: 'Structure', subtype: 'Turret', atk: 3, hp: 6, def: 1, range: 3, siege: 0, wheat: 3, iron: 5, tags: ['turret', 'anti-flying', 'structure'] },
    { key: 'siege-crawler', type: 'Unit', subtype: 'Construct Siege', atk: 5, hp: 6, def: 1, range: 1, siege: 3, wheat: 4, iron: 5, tags: ['siege', 'construct'] },
    { key: 'repair-walker', type: 'Unit', subtype: 'Construct Utility', atk: 1, hp: 5, def: 1, range: 1, siege: 0, wheat: 3, iron: 4, tags: ['repair', 'construct', 'support'] },
    { key: 'mobile-bulwark', type: 'Structure', subtype: 'Mobile Barricade', atk: 0, hp: 7, def: 2, range: 1, siege: 0, wheat: 3, iron: 4, tags: ['barricade', 'mobile', 'structure'] },
    { key: 'railgun-platform', type: 'Unit', subtype: 'Siege Ranged', atk: 6, hp: 4, def: 0, range: 4, siege: 2, wheat: 5, iron: 6, tags: ['siege', 'ranged', 'anti-structure'] },
    { key: 'supply-hauler', type: 'Unit', subtype: 'Support', atk: 1, hp: 4, def: 1, range: 1, siege: 0, wheat: 2, iron: 3, tags: ['economy', 'support'] },
    { key: 'minefield-deployer', type: 'Unit', subtype: 'Utility', atk: 2, hp: 3, def: 0, range: 1, siege: 0, wheat: 3, iron: 4, tags: ['trap', 'explosive'] },
    { key: 'fortress-core', type: 'Structure', subtype: 'Fortress', atk: 0, hp: 10, def: 3, range: 1, siege: 0, wheat: 5, iron: 7, tags: ['fortress', 'structure', 'lane-buff'] },
    { key: 'drill-engine', type: 'Unit', subtype: 'Construct Breach', atk: 4, hp: 6, def: 1, range: 1, siege: 4, wheat: 5, iron: 6, tags: ['breach', 'siege', 'construct'] },
    { key: 'storm-mortar', type: 'Unit', subtype: 'Siege Ranged', atk: 5, hp: 4, def: 0, range: 4, siege: 2, wheat: 4, iron: 6, tags: ['explosive', 'ranged', 'siege'] },
  ];
  const factoryMarks = ['Mk I', 'Mk II', 'Mk III'];
  factoryPatterns.forEach((pattern, pIdx) => {
    factoryMarks.forEach((mark, mIdx) => {
      const id = `cq-${pattern.key}-${mIdx + 1}`;
      factoryExpansionIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.subtype} ${mark}`,
        sourceBuilding: 'factory',
        cardType: pattern.type,
        subtype: pattern.subtype,
        structure: pattern.tags.includes('structure') || pattern.subtype.toLowerCase().includes('fortress') || pattern.subtype.toLowerCase().includes('barricade'),
        barricade: pattern.tags.includes('barricade'),
        large: pattern.tags.includes('large'),
        wheatCost: pattern.wheat + mIdx,
        ironCost: pattern.iron + (mIdx >= 1 ? 1 : 0),
        attack: pattern.atk + (mIdx === 2 ? 1 : 0),
        health: pattern.hp + mIdx,
        defense: pattern.def + (pattern.tags.includes('fortress') ? 1 : 0),
        range: pattern.range,
        siege: pattern.siege + (pattern.tags.includes('siege') && mIdx === 2 ? 1 : 0),
        text: pattern.tags.includes('repair')
          ? 'Action: Repair 3 to adjacent structures. Gains +1 defense while near a facility.'
          : pattern.tags.includes('economy')
            ? 'On deploy, gain +1 iron and draw 1 factory card if your hand has fewer than 6 cards.'
            : pattern.tags.includes('trap')
              ? 'Action: place an explosive trap in an adjacent empty cell.'
              : pattern.tags.includes('fortress')
                ? 'Fortress core. Adjacent barricades gain +1 DEF and turrets gain +1 range.'
                : pattern.tags.includes('anti-flying')
                  ? 'Prioritizes flying targets and gains +2 damage against air units.'
                  : pattern.tags.includes('breach')
                    ? 'If this damages a barricade, may advance one cell.'
                    : 'Industrial war machine tuned for conquest lane pressure.',
        tags: [...pattern.tags, 'factory-expansion'],
        repairRelevant: pattern.tags.includes('repair'),
      }));
    });
  });
  const factoryBaseline = [
    { id: 'cq-ironclad-trooper', name: 'Ironclad Trooper', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Armoured', wheatCost: 2, ironCost: 2, attack: 2, health: 3, defense: 1, text: 'Armoured.', tags: ['armoured'] },
    { id: 'cq-shield-cart', name: 'Shield Cart', sourceBuilding: 'factory', cardType: 'Structure', subtype: 'Mobile Barricade', structure: true, barricade: true, wheatCost: 2, ironCost: 3, attack: 0, health: 6, defense: 2, text: 'Counts as a Barricade. Can spend its action to move 1 cell.', tags: ['mobile', 'barricade'] },
    { id: 'cq-bombard-crew', name: 'Bombard Crew', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Siege Ranged', wheatCost: 3, ironCost: 4, attack: 4, health: 2, defense: 0, range: 3, siege: 3, text: 'Ranged 3. Siege 3. Attacks against Hordes are explosive.', tags: ['siege', 'anti-horde', 'explosive'] },
    { id: 'cq-auto-ballista', name: 'Auto-Ballista', sourceBuilding: 'factory', cardType: 'Structure', subtype: 'Turret', structure: true, wheatCost: 2, ironCost: 4, attack: 2, health: 4, defense: 1, range: 4, text: 'Ranged 4. Gains +2 damage against Flying.', tags: ['turret', 'anti-flying'] },
    { id: 'cq-powder-keg', name: 'Powder Keg', sourceBuilding: 'factory', cardType: 'Tactic', subtype: 'Trap', type: 'tactic', wheatCost: 1, ironCost: 2, text: 'Place in an adjacent empty cell. When an enemy enters or remains there, deal explosive 5.', tags: ['trap', 'explosive'], tactic: { kind: 'blast-cell', amount: 5 } },
    { id: 'cq-repair-drone', name: 'Repair Drone', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Utility', wheatCost: 1, ironCost: 3, attack: 1, health: 3, defense: 0, text: 'Action: Repair 2 to an adjacent Structure, Barricade, or Facility.', tags: ['repair', 'utility'], repairRelevant: true },
    { id: 'cq-boiler-walker', name: 'Boiler Walker', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Construct', wheatCost: 4, ironCost: 4, attack: 4, health: 5, defense: 1, siege: 1, text: 'Siege 1. Large enemies deal -1 damage to this.', tags: ['siege', 'anti-large'] },
    { id: 'cq-mortar-team', name: 'Mortar Team', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Siege Ranged', wheatCost: 4, ironCost: 4, attack: 4, health: 3, defense: 0, range: 4, siege: 2, text: 'Ranged 4. Explosive attacks. Cannot target adjacent cells.', tags: ['siege', 'explosive'] },
    { id: 'cq-armoured-ram', name: 'Armoured Ram', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Siege', wheatCost: 3, ironCost: 5, attack: 5, health: 5, defense: 0, siege: 4, text: 'Siege 4. If this destroys a Barricade, it may move 1 cell forward.', tags: ['siege', 'breach'] },
    { id: 'cq-mine-layer', name: 'Mine Layer', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Utility', wheatCost: 2, ironCost: 3, attack: 1, health: 3, defense: 0, text: 'Action: place a Powder Keg if you have a valid adjacent empty cell. Once per battle.', tags: ['utility', 'trap'] },
    { id: 'cq-pylon-disruptor', name: 'Pylon Disruptor', sourceBuilding: 'factory', cardType: 'Unit', subtype: 'Specialist', wheatCost: 3, ironCost: 4, attack: 2, health: 4, defense: 0, text: 'Attacks against Mana Pylons deal +3 damage.', tags: ['anti-pylon', 'specialist'] },
    { id: 'cq-heavy-turret-frame', name: 'Heavy Turret Frame', sourceBuilding: 'factory', cardType: 'Upgrade Schematic', subtype: 'Turret', upgradeSchematic: true, wheatCost: 4, ironCost: 5, attack: 1, health: 2, defense: 1, range: 4, text: 'Upgrade a Turret. It becomes 4 / 8 / 2 and gains Ranged 4. Cannot attack until next turn.', tags: ['upgrade', 'turret'] },
  ];
  cards.push(...factoryBaseline.map(card));

  const factoryExtras = [
    ['supply-carrier', 'Supply Carrier', 1, 4, 1, 2, 3, 1, 'economy'],
    ['aegis-loader', 'Aegis Loader', 3, 5, 2, 3, 4, 1, 'armoured'],
    ['drill-tank', 'Drill Tank', 5, 6, 1, 5, 5, 4, 'siege'],
    ['reactor-assisted-turret', 'Reactor-Assisted Turret', 4, 7, 2, 4, 5, 0, 'turret'],
    ['shield-emitter-node', 'Shield Emitter Node', 0, 6, 2, 3, 4, 0, 'shield'],
    ['blast-furnace-rig', 'Blast Furnace Rig', 0, 7, 1, 4, 4, 0, 'economy'],
    ['minefield-seeder', 'Minefield Seeder', 2, 3, 0, 3, 4, 0, 'trap'],
    ['steel-giant-prototype', 'Steel Giant Prototype', 7, 9, 2, 6, 7, 2, 'large'],
    ['arc-flak-nest', 'Arc Flak Nest', 3, 6, 1, 3, 5, 0, 'anti-flying'],
    ['siege-walker-column', 'Siege Walker Column', 6, 6, 1, 5, 6, 3, 'siege'],
    ['rail-mortar-platform', 'Rail Mortar Platform', 5, 5, 1, 4, 6, 3, 'siege'],
    ['breach-dredger', 'Breach Dredger', 5, 5, 1, 4, 5, 4, 'breach'],
    ['fortifier-crane', 'Fortifier Crane', 1, 5, 1, 3, 5, 0, 'repair'],
    ['overpressure-cannon', 'Overpressure Cannon', 6, 3, 0, 5, 6, 3, 'explosive'],
    ['ironline-exosquad', 'Ironline Exosquad', 4, 6, 2, 4, 5, 1, 'armoured'],
    ['salvage-hauler', 'Salvage Hauler', 2, 5, 1, 3, 4, 0, 'economy'],
  ];
  factoryExtras.forEach(([id, name, atk, hp, def, wheatCost, ironCost, siege, role]) => {
    cards.push(card({
      id: `cq-${id}`,
      name,
      sourceBuilding: 'factory',
      cardType: role === 'turret' || role === 'shield' || role === 'economy' ? 'Structure' : 'Unit',
      subtype: role === 'turret' ? 'Turret' : role === 'shield' ? 'Support' : role === 'large' ? 'Construct Large' : 'Construct',
      structure: role === 'turret' || role === 'shield' || role === 'economy',
      large: role === 'large',
      repairRelevant: role === 'repair',
      wheatCost,
      ironCost,
      attack: atk,
      health: hp,
      defense: def,
      siege,
      range: role === 'turret' || role === 'siege' ? 4 : 1,
      text: role === 'repair' ? 'Action: Repair adjacent structure.' : `Factory role: ${role}.`,
      tags: [role],
      production: role === 'economy' ? { ironPerTurn: 1 } : null,
    }));
  });

  const commandBaseline = [
    { id: 'cq-emergency-reinforcement', name: 'Emergency Reinforcement', sourceBuilding: 'command', cardType: 'Tactic', subtype: 'Reinforcement', type: 'tactic', wheatCost: 2, text: 'Draw 1 Training card. It costs 1 less this turn.', tags: ['draw', 'reinforcement'], tactic: { kind: 'draw', deck: 'training', count: 1, wheatDiscount: 1 } },
    { id: 'cq-rush-ammunition', name: 'Rush Ammunition', sourceBuilding: 'command', cardType: 'Tactic', subtype: 'Buff', type: 'tactic', wheatCost: 1, ironCost: 1, attack: 2, text: 'A Turret or Ranged ally gets +2 ATK this turn.', tags: ['buff', 'ranged'], tactic: { kind: 'buff', attack: 2 } },
    { id: 'cq-rapid-repair-crew', name: 'Rapid Repair Crew', sourceBuilding: 'command', cardType: 'Tactic', subtype: 'Repair', type: 'tactic', wheatCost: 2, ironCost: 2, text: 'Repair 3 to up to two different Structures or Barricades.', tags: ['repair'], repairRelevant: true, tactic: { kind: 'repair', amount: 3, repeats: 2 } },
    { id: 'cq-silver-factory-upgrade', name: 'Silver Factory Upgrade Schematic', sourceBuilding: 'command', cardType: 'Upgrade Schematic', subtype: 'Factory', upgradeSchematic: true, wheatCost: 3, ironCost: 5, health: 2, defense: 1, text: 'Upgrade a Factory. It gains +2 HP and generates a bonus Factory draw every other turn.', tags: ['upgrade', 'factory'] },
    { id: 'cq-silver-training-upgrade', name: 'Silver Training Facility Upgrade Schematic', sourceBuilding: 'command', cardType: 'Upgrade Schematic', subtype: 'Training', upgradeSchematic: true, wheatCost: 3, ironCost: 4, health: 2, defense: 1, text: 'Upgrade a Training Facility. The first troop drawn from it each turn costs 1 less Wheat.', tags: ['upgrade', 'training'] },
    { id: 'cq-silver-farm-upgrade', name: 'Silver Farm Upgrade Schematic', sourceBuilding: 'command', cardType: 'Upgrade Schematic', subtype: 'Farm', upgradeSchematic: true, wheatCost: 2, ironCost: 3, health: 1, defense: 1, text: 'Upgrade a Farm. It produces 5 Wheat per turn instead of 3.', tags: ['upgrade', 'farm'] },
    { id: 'cq-silver-mine-upgrade', name: 'Silver Mine Upgrade Schematic', sourceBuilding: 'command', cardType: 'Upgrade Schematic', subtype: 'Mine', upgradeSchematic: true, wheatCost: 2, ironCost: 3, health: 1, defense: 1, text: 'Upgrade a Mine. It produces 5 Iron per turn instead of 3.', tags: ['upgrade', 'mine'] },
    { id: 'cq-fort-quavus-blueprint', name: 'Fort Quavus Blueprint', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Fortress', structure: true, fortified: true, wheatCost: 6, ironCost: 8, attack: 0, health: 12, defense: 3, text: 'Fortress. Adjacent Barricades gain +2 HP. Your Turrets in this lane gain +1 Range.', tags: ['fortress', 'lane-buff'] },
    { id: 'cq-weather-beacon', name: 'Weather Beacon', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Support', structure: true, wheatCost: 4, ironCost: 5, attack: 0, health: 6, defense: 1, text: 'Once each turn, choose Fog or Dust. Fog: enemy Ranged attacks lose 1 Range this turn. Dust: all Flying units lose 1 ATK this turn.', tags: ['weather', 'control'] },
    { id: 'cq-reserve-muster', name: 'Reserve Muster', sourceBuilding: 'command', cardType: 'Tactic', subtype: 'Reinforcement', type: 'tactic', wheatCost: 4, text: 'Add two Militia Recruits to your hand.', tags: ['reinforcement', 'reserve'], tactic: { kind: 'add-hand', cardId: 'cq-militia-recruit', count: 2 } },
  ];
  cards.push(...commandBaseline.map(card));
  const commandExtras = [
    ['lane-fortification-order', 'Lane Fortification Order', 2, 2, 'fortify'],
    ['rapid-redeployment', 'Rapid Redeployment', 2, 1, 'mobility'],
    ['morale-drums', 'Morale Drums', 3, 2, 'morale'],
    ['anti-siege-doctrine', 'Anti-Siege Doctrine', 2, 2, 'anti-siege'],
    ['emergency-rations', 'Emergency Rations', 1, 1, 'economy'],
    ['radar-scan-tower', 'Radar Scan Tower', 3, 3, 'intel'],
    ['wall-patch-team', 'Wall Patch Team', 1, 2, 'repair'],
    ['supply-optimization', 'Supply Optimization', 2, 1, 'economy'],
    ['objective-lockdown-beacon', 'Objective Lockdown Beacon', 4, 4, 'capture'],
    ['anti-air-command', 'Anti-Air Command', 2, 2, 'anti-flying'],
    ['ore-convoy', 'Ore Convoy', 1, 1, 'economy'],
    ['foundry-overdrive', 'Foundry Overdrive', 2, 3, 'economy'],
  ];
  commandExtras.forEach(([id, name, wheatCost, ironCost, role]) => {
    cards.push(card({
      id: `cq-${id}`,
      name,
      sourceBuilding: 'command',
      cardType: role === 'intel' || role === 'capture' ? 'Structure' : 'Tactic',
      subtype: role,
      type: role === 'intel' || role === 'capture' ? 'building' : 'tactic',
      structure: role === 'intel' || role === 'capture',
      wheatCost,
      ironCost,
      attack: role === 'morale' ? 1 : 0,
      health: role === 'intel' || role === 'capture' ? 6 : 0,
      defense: role === 'intel' || role === 'capture' ? 1 : 0,
      text: `Command doctrine: ${role}.`,
      tags: [role],
      repairRelevant: role === 'repair',
      captureRelevant: role === 'capture' || role === 'mobility',
      tactic: role === 'repair' ? { kind: 'repair', amount: 4 } : role === 'economy' ? { kind: 'resource', wheat: 2, iron: 2 } : role === 'morale' ? { kind: 'buff', attack: 1, health: 1 } : null,
    }));
  });

  const commandExpansionIds = [];
  const commandPattern = [
    ['doctrine-lane-hold', 'Doctrine: Lane Hold', 2, 2, 'fortify', { kind: 'buff', defense: 1, health: 1 }],
    ['doctrine-counter-air', 'Doctrine: Counter Air', 2, 2, 'anti-flying', { kind: 'buff', attack: 1 }],
    ['doctrine-counter-horde', 'Doctrine: Counter Horde', 2, 2, 'anti-horde', { kind: 'blast-cell', amount: 4 }],
    ['doctrine-repair-chain', 'Doctrine: Repair Chain', 2, 3, 'repair', { kind: 'repair', amount: 3, repeats: 2 }],
    ['doctrine-ore-convoy', 'Doctrine: Ore Convoy', 1, 2, 'economy', { kind: 'resource', iron: 3 }],
    ['doctrine-grain-convoy', 'Doctrine: Grain Convoy', 2, 1, 'economy', { kind: 'resource', wheat: 3 }],
    ['doctrine-rapid-muster', 'Doctrine: Rapid Muster', 3, 1, 'reinforcement', { kind: 'draw', deck: 'training', count: 2 }],
    ['doctrine-overclock', 'Doctrine: Overclock', 2, 3, 'factory', { kind: 'draw', deck: 'factory', count: 1, ironDiscount: 1 }],
    ['doctrine-smoke-screen', 'Doctrine: Smoke Screen', 2, 2, 'weather', { kind: 'buff', defense: 1 }],
    ['doctrine-lockdown', 'Doctrine: Lockdown', 3, 3, 'capture', { kind: 'buff', attack: 1 }],
  ];
  ['I', 'II', 'III'].forEach((mk, mkIdx) => {
    commandPattern.forEach(([id, name, wheat, iron, role, tactic]) => {
      const cardId = `cq-${id}-${mk.toLowerCase()}`;
      commandExpansionIds.push(cardId);
      cards.push(card({
        id: cardId,
        name: `${name} ${mk}`,
        sourceBuilding: 'command',
        cardType: role === 'capture' || role === 'weather' ? 'Structure' : 'Tactic',
        subtype: role,
        type: role === 'capture' || role === 'weather' ? 'building' : 'tactic',
        structure: role === 'capture' || role === 'weather',
        wheatCost: wheat + mkIdx,
        ironCost: iron + (mkIdx >= 1 ? 1 : 0),
        attack: role === 'capture' ? 1 : 0,
        health: role === 'capture' || role === 'weather' ? 5 + mkIdx : 0,
        defense: role === 'capture' || role === 'weather' ? 1 : 0,
        text: role === 'repair'
          ? 'Coordinate field repairs across nearby lanes.'
          : role === 'reinforcement'
            ? 'Call reserve squads and reduce tempo loss when lines break.'
            : role === 'economy'
              ? 'Logistics doctrine to stabilize resource flow under pressure.'
              : role === 'weather'
                ? 'Manipulate weather lanes to disrupt enemy range advantage.'
                : role === 'capture'
                  ? 'Objective lock beacon that amplifies local control.'
                  : 'Command doctrine for lane optimization.',
        tags: ['command-expansion', role, 'support'],
        captureRelevant: role === 'capture' || role === 'fortify',
        repairRelevant: role === 'repair',
        tactic: tactic ? { ...tactic } : null,
      }));
    });
  });

  const fortificationVariantIds = [];
  const fortificationVariants = [
    ['light-barricade', 'Light Barricade', 1, 1, 0, 6, 1, ['barricade', 'wall', 'light'], 'Cheap wall segment for emergency lane patching.'],
    ['reinforced-barricade', 'Reinforced Barricade', 2, 3, 0, 10, 3, ['barricade', 'wall', 'fortified'], 'Heavy wall section for sustained siege resistance.'],
    ['shield-wall', 'Shield Wall', 2, 3, 0, 9, 2, ['barricade', 'shield', 'wall'], 'Adjacent infantry gain +1 DEF while this holds.'],
    ['spike-wall', 'Spike Wall', 2, 2, 1, 7, 2, ['barricade', 'wall', 'counter'], 'Enemies that hit this wall take 1 return damage.'],
    ['fire-oil-barricade', 'Fire-Oil Barricade', 3, 3, 1, 8, 2, ['barricade', 'wall', 'explosive'], 'When destroyed, deals explosive 3 to that lane.'],
    ['repairable-bastion', 'Repairable Bastion', 2, 3, 0, 9, 2, ['barricade', 'wall', 'repair'], 'Repair effects on this card restore +1 extra HP.'],
    ['blast-wall', 'Blast Wall', 3, 4, 0, 11, 3, ['barricade', 'wall', 'anti-horde'], 'Explosive attacks against this wall deal reduced damage.'],
    ['reflective-wall', 'Reflective Wall', 3, 4, 0, 8, 3, ['barricade', 'wall', 'anti-ranged'], 'First ranged hit each turn is reduced by 2.'],
    ['anti-air-rampart', 'Anti-Air Rampart', 3, 4, 1, 8, 2, ['barricade', 'wall', 'anti-flying'], 'Flying attackers in this lane lose 1 ATK.'],
    ['tower-wall', 'Tower Wall', 4, 5, 1, 9, 2, ['barricade', 'wall', 'turret-support'], 'Turrets in this lane gain +1 range.'],
    ['gate-barricade', 'Gate Barricade', 2, 2, 0, 8, 2, ['barricade', 'wall', 'mobility'], 'Friendly infantry may pass through once per turn.'],
    ['mobile-barrier-cart', 'Mobile Barrier Cart', 3, 4, 0, 7, 2, ['barricade', 'wall', 'mobile'], 'May move 1 cell instead of attacking.'],
    ['trench-wall', 'Trench Wall', 2, 2, 0, 7, 2, ['barricade', 'wall', 'cover'], 'Adjacent defenders gain cover against ranged attacks.'],
    ['root-wall', 'Root Wall', 3, 3, 0, 8, 2, ['barricade', 'wall', 'regrowth'], 'At end of turn, if undamaged this turn, heal 1.'],
    ['rune-barrier', 'Rune Barrier', 4, 4, 0, 9, 2, ['barricade', 'wall', 'arcane'], 'The first enemy spell each round targeting this lane fizzles.'],
    ['electrified-barricade', 'Electrified Barricade', 4, 5, 1, 8, 2, ['barricade', 'wall', 'control'], 'Enemies that enter this cell become Shaken 1 turn.'],
    ['fortress-section', 'Heavy Fortress Section', 5, 6, 0, 12, 4, ['barricade', 'wall', 'fortified', 'fortress'], 'Massive wall section that anchors lane control.'],
    ['layered-bulwark', 'Layered Bulwark', 5, 5, 0, 11, 3, ['barricade', 'wall', 'layered'], 'If this survives an attack, gain +1 DEF (max +3).'],
    ['sacrificial-wall', 'Sacrificial Wall', 1, 1, 0, 5, 1, ['barricade', 'wall', 'sacrifice'], 'When destroyed, draw 1 command card.'],
    ['command-wall', 'Command Wall', 4, 4, 0, 9, 2, ['barricade', 'wall', 'command'], 'Adjacent officers gain +1 HP and +1 DEF.'],
    ['stormglass-barricade', 'Stormglass Barricade', 4, 5, 0, 8, 3, ['barricade', 'wall', 'anti-siege'], 'Siege attacks against this wall deal -2 damage.'],
    ['orebound-rampart', 'Orebound Rampart', 3, 4, 0, 10, 3, ['barricade', 'wall', 'economy'], 'Gain +1 iron when this survives an enemy attack.'],
  ];
  fortificationVariants.forEach(([id, name, wheatCost, ironCost, attack, health, defense, tags, text]) => {
    fortificationVariantIds.push(`cq-${id}`);
    cards.push(card({
      id: `cq-${id}`,
      name,
      sourceBuilding: 'factory',
      cardType: 'Structure',
      subtype: 'Barricade',
      structure: true,
      barricade: true,
      fortified: tags.includes('fortified'),
      wheatCost,
      ironCost,
      attack,
      health,
      defense,
      text,
      tags,
    }));
  });

  const blacksmithVarietyIds = [];
  const blacksmithVarietyPatterns = [
    { key: 'giantkiller-kit', name: 'Giantkiller Kit', role: 'equipment', atk: 2, hp: 0, def: 0, wheat: 3, iron: 4, tags: ['weapon', 'anti-large'], text: 'Equip troop. Deals +3 damage to Large enemies.' },
    { key: 'skyhook-bolts', name: 'Skyhook Bolts', role: 'equipment', atk: 1, hp: 0, def: 0, wheat: 2, iron: 3, tags: ['weapon', 'anti-flying'], text: 'Equip ranged troop. Gains +2 damage versus Flying.' },
    { key: 'horde-splitter-axe', name: 'Horde-Splitter Axe', role: 'equipment', atk: 2, hp: 0, def: 0, wheat: 3, iron: 3, tags: ['weapon', 'anti-horde'], text: 'Equip infantry. Attacks against hordes are explosive.' },
    { key: 'siege-breaker-hammer', name: 'Siege Breaker Hammer', role: 'equipment', atk: 2, hp: 1, def: 0, wheat: 3, iron: 4, tags: ['weapon', 'siege', 'anti-structure'], text: 'Equip troop. Gains +2 siege versus structures/barricades.' },
    { key: 'officer-command-blade', name: 'Officer Command Blade', role: 'equipment', atk: 1, hp: 1, def: 0, wheat: 3, iron: 3, tags: ['weapon', 'officer', 'morale'], text: 'Equip officer. Adjacent allies gain +1 ATK.' },
    { key: 'blastproof-mantle', name: 'Blastproof Mantle', role: 'equipment', atk: 0, hp: 2, def: 1, wheat: 2, iron: 3, tags: ['armour', 'anti-explosive'], text: 'Equip troop. First explosive hit each turn deals -2 damage.' },
    { key: 'wallguard-cuirass', name: 'Wallguard Cuirass', role: 'equipment', atk: 0, hp: 3, def: 1, wheat: 3, iron: 4, tags: ['armour', 'fortified', 'barricade-support'], text: 'Equip frontline troop. Adjacent barricades gain +1 DEF.' },
    { key: 'vanguard-boots', name: 'Vanguard Boots', role: 'equipment', atk: 1, hp: 1, def: 0, wheat: 2, iron: 2, tags: ['armour', 'mobility'], text: 'Equip troop. May move and still attack once each turn.' },
    { key: 'turret-overclock-schematic', name: 'Turret Overclock Schematic', role: 'upgrade', atk: 1, hp: 2, def: 1, wheat: 4, iron: 5, tags: ['upgrade', 'turret'], text: 'Upgrade turret: +1 ATK, +2 HP, +1 DEF. Skip this turn.' },
    { key: 'wall-reconstruction-schematic', name: 'Wall Reconstruction Schematic', role: 'upgrade', atk: 0, hp: 4, def: 1, wheat: 3, iron: 5, tags: ['upgrade', 'barricade'], text: 'Upgrade barricade: +4 HP, +1 DEF and Fortified.' },
    { key: 'forgefield-repair-kit', name: 'Forgefield Repair Kit', role: 'utility', atk: 0, hp: 0, def: 0, wheat: 2, iron: 2, tags: ['repair'], text: 'Repair 5 to a friendly structure or barricade.', tactic: { kind: 'repair', amount: 5 } },
    { key: 'rapid-rivet-team', name: 'Rapid Rivet Team', role: 'utility', atk: 0, hp: 0, def: 0, wheat: 2, iron: 3, tags: ['repair', 'draw'], text: 'Repair 3 and draw 1 blacksmith card.', tactic: { kind: 'repair', amount: 3, drawDeck: 'blacksmith', drawCount: 1 } },
  ];
  ['Mark I', 'Mark II'].forEach((mark, markIdx) => {
    blacksmithVarietyPatterns.forEach((pattern) => {
      const id = `cq-${pattern.key}-${mark.toLowerCase().replace(/\s+/g, '-')}`;
      blacksmithVarietyIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mark}`,
        sourceBuilding: 'blacksmith',
        cardType: pattern.role === 'upgrade' ? 'Upgrade Schematic' : pattern.role === 'utility' ? 'Utility' : 'Equipment',
        subtype: pattern.role === 'utility' ? 'Field Kit' : pattern.role === 'upgrade' ? 'Schematic' : 'Weapon/Armour',
        type: pattern.role === 'utility' ? 'tactic' : undefined,
        equipment: pattern.role === 'equipment',
        upgradeSchematic: pattern.role === 'upgrade',
        wheatCost: pattern.wheat + markIdx,
        ironCost: pattern.iron + (markIdx >= 1 ? 1 : 0),
        attack: pattern.atk + (pattern.role === 'equipment' && markIdx === 1 ? 1 : 0),
        health: pattern.hp + (pattern.role === 'equipment' && markIdx === 1 ? 1 : 0),
        defense: pattern.def + (pattern.role !== 'utility' && markIdx === 1 ? 1 : 0),
        text: pattern.text,
        tags: [...pattern.tags, 'blacksmith-variety'],
        repairRelevant: pattern.tags.includes('repair'),
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const swingTacticIds = [];
  const swingTactics = [
    ['emergency-reinforcement-column', 'Emergency Reinforcement Column', 4, 1, { kind: 'add-hand', cardId: 'cq-militia-recruit', count: 3 }, ['reinforcement', 'swing']],
    ['lane-fortify-order', 'Lane Fortify Order', 3, 2, { kind: 'fortify-lane', defense: 1, health: 2 }, ['fortify', 'lane']],
    ['explosive-volley', 'Explosive Volley', 3, 3, { kind: 'blast-cell', amount: 6 }, ['explosive', 'anti-horde']],
    ['morale-recovery', 'Morale Recovery', 2, 2, { kind: 'global-buff', attack: 1, health: 1 }, ['morale', 'support']],
    ['shield-field', 'Temporary Shield Field', 2, 3, { kind: 'global-buff', defense: 1 }, ['shield', 'support']],
    ['breach-charge', 'Breach Charge', 3, 3, { kind: 'strike-structure', amount: 5 }, ['breach', 'anti-structure']],
    ['capture-rush-order', 'Capture Rush Order', 3, 2, { kind: 'capture-boost' }, ['capture', 'tempo']],
    ['anti-air-barrage', 'Anti-Air Barrage', 2, 3, { kind: 'anti-air-barrage', amount: 5 }, ['anti-flying', 'control']],
    ['overclocked-turrets', 'Overclocked Turrets', 3, 4, { kind: 'overclock-turrets', attack: 2 }, ['turret', 'buff']],
    ['mass-repair', 'Mass Repair Protocol', 4, 4, { kind: 'global-repair', amount: 3 }, ['repair', 'swing']],
    ['barricade-reconstruction', 'Barricade Reconstruction', 3, 4, { kind: 'spawn-barricade' }, ['barricade', 'rebuild']],
    ['reserve-deployment', 'Reserve Deployment', 4, 2, { kind: 'draw', deck: 'training', count: 2 }, ['reinforcement', 'draw']],
    ['weather-fogfront', 'Weather Fogfront', 2, 3, { kind: 'disable-target', turns: 1 }, ['weather', 'control']],
    ['command-beacon-pulse', 'Command Beacon Pulse', 3, 3, { kind: 'global-buff', attack: 1, defense: 1 }, ['command', 'formation']],
    ['anti-horde-artillery', 'Anti-Horde Artillery', 3, 4, { kind: 'blast-cell', amount: 7 }, ['anti-horde', 'explosive']],
    ['giant-killer-kits', 'Giant-Killer Kits', 2, 3, { kind: 'buff', attack: 2 }, ['anti-large', 'buff']],
    ['linebreaker-drill-order', 'Linebreaker Drill Order', 3, 2, { kind: 'fortify-lane', attack: 1 }, ['linebreak', 'tempo']],
    ['ore-ration-surge', 'Ore & Ration Surge', 1, 2, { kind: 'resource', wheat: 3, iron: 3 }, ['economy', 'swing']],
    ['foundry-emergency-overdrive', 'Foundry Emergency Overdrive', 3, 4, { kind: 'draw', deck: 'factory', count: 2 }, ['factory', 'draw']],
    ['forge-command-relay', 'Forge Command Relay', 2, 2, { kind: 'discount', wheat: 2, iron: 2 }, ['discount', 'tempo']],
    ['bulwark-of-steel', 'Bulwark of Steel', 3, 3, { kind: 'spawn-barricade' }, ['barricade', 'fortify']],
    ['counterbattery-salvo', 'Counterbattery Salvo', 3, 4, { kind: 'strike-structure', amount: 6 }, ['siege', 'counter']],
  ];
  swingTactics.forEach(([id, name, wheatCost, ironCost, tactic, tags]) => {
    swingTacticIds.push(`cq-${id}`);
    cards.push(card({
      id: `cq-${id}`,
      name,
      sourceBuilding: 'command',
      cardType: 'Tactic',
      subtype: 'Command',
      type: 'tactic',
      wheatCost,
      ironCost,
      text: `Command action: ${name}.`,
      tags: [...tags, 'command-swing'],
      captureRelevant: tags.includes('capture'),
      repairRelevant: tags.includes('repair'),
      tactic: { ...tactic },
    }));
  });

  const attackerBaseline = [
    { id: 'cq-homestead', name: 'Invasion Homestead', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'command', cardType: 'Structure', subtype: 'Homestead', structure: true, manaCost: 1, attack: 0, health: 14, defense: 2, text: 'Attacker anchor. Must be deployed first. If destroyed, defenders win immediately.', tags: ['homestead', 'command', 'structure'] },
    { id: 'cq-mana-pylon', name: 'Mana Pylon', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'pylon', cardType: 'Structure', subtype: 'Mana Pylon', structure: true, manaCost: 1, attack: 0, health: 4, defense: 0, text: 'At the start of your turn, gain +1 mana for each Mana Pylon you control.', tags: ['resource', 'pylon'] },
    { id: 'cq-goblin-spearline', name: 'Goblin Spearline', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'ground', cardType: 'Unit', subtype: 'Ground', manaCost: 1, attack: 2, health: 1, defense: 0, text: 'Frontline raider.' },
    { id: 'cq-riot-goblin-tribe', name: 'Riot Goblin Tribe', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'horde', cardType: 'Unit', subtype: 'Horde Ground', manaCost: 3, attack: 10, health: 10, defense: 0, horde: true, text: 'Horde unit.' },
    { id: 'cq-bone-clad-raiders', name: 'Bone-Clad Raiders', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'ground', cardType: 'Unit', subtype: 'Ground', manaCost: 2, attack: 3, health: 2, defense: 0, text: 'Gains +1 ATK while attacking Structures.', tags: ['anti-structure'] },
    { id: 'cq-rift-boar-riders', name: 'Rift Boar Riders', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'ground', cardType: 'Unit', subtype: 'Ground', manaCost: 3, attack: 4, health: 3, defense: 0, text: 'When played, may advance 1 cell if the lane ahead is empty.', tags: ['mobility'] },
    { id: 'cq-siege-gnashers', name: 'Siege Gnashers', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'siege', cardType: 'Unit', subtype: 'Ground Siege', manaCost: 4, attack: 4, health: 4, defense: 0, siege: 2, text: 'Siege 2.' },
    { id: 'cq-brute-wallbreakers', name: 'Brute Wallbreakers', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'siege', cardType: 'Unit', subtype: 'Ground Siege', manaCost: 5, attack: 5, health: 6, defense: 0, siege: 3, text: 'Siege 3. If this destroys a Barricade, gain +1 ATK permanently.', tags: ['breach'] },
    { id: 'cq-skullbow-patrol', name: 'Skullbow Patrol', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'ranged', cardType: 'Unit', subtype: 'Ranged', manaCost: 2, attack: 2, health: 2, defense: 0, range: 2, text: 'Ranged 2.' },
    { id: 'cq-ashbow-regiment', name: 'Ashbow Regiment', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'horde', cardType: 'Unit', subtype: 'Horde Ranged', manaCost: 4, attack: 8, health: 8, defense: 0, horde: true, range: 2, text: 'Horde. Ranged 2. Each surviving model contributes 2 attack instead of 1.' },
    { id: 'cq-hex-drummer', name: 'Hex Drummer', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'support', cardType: 'Unit', subtype: 'Support', manaCost: 2, attack: 1, health: 3, defense: 0, text: 'Adjacent allied attackers gain +1 ATK.', tags: ['morale', 'support'] },
    { id: 'cq-siege-caller', name: 'Siege Caller', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'support', cardType: 'Unit', subtype: 'Support', manaCost: 4, attack: 2, health: 4, defense: 0, text: 'The first Siege unit you play each turn costs 1 less.', tags: ['siege', 'discount'] },
    { id: 'cq-carrion-bats', name: 'Carrion Bats', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'air', cardType: 'Unit', subtype: 'Air', manaCost: 2, attack: 2, health: 1, defense: 0, flying: true, text: 'Flying.' },
    { id: 'cq-rift-vulture-cloud', name: 'Rift Vulture Cloud', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'air-horde', cardType: 'Unit', subtype: 'Horde Air', manaCost: 4, attack: 6, health: 6, defense: 0, flying: true, horde: true, text: 'Horde. Flying. Takes +1 damage from anti-air attacks.', tags: ['fragile'] },
    { id: 'cq-skyrake-bomber', name: 'Skyrake Bomber', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'air', cardType: 'Unit', subtype: 'Air', manaCost: 5, attack: 4, health: 3, defense: 0, flying: true, text: 'Flying. On attack, deal explosive 3 to Hordes in target cell.', tags: ['explosive', 'anti-horde'] },
    { id: 'cq-rift-giant', name: 'Rift Giant', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'giant', cardType: 'Unit', subtype: 'Large Ground', manaCost: 7, attack: 8, health: 8, defense: 0, large: true, text: 'Large. Requires 2 free attacker cells to summon.' },
    { id: 'cq-gravelung-colossus', name: 'Gravelung Colossus', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'giant', cardType: 'Unit', subtype: 'Large Ground Siege', manaCost: 9, attack: 10, health: 12, defense: 1, large: true, siege: 4, text: 'Large. Siege 4. Cannot be played unless you control at least 3 Mana Pylons.' },
    { id: 'cq-forced-march', name: 'Forced March', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Tactic', type: 'spell', manaCost: 2, text: 'One allied attacker may move 1 extra cell this turn.', tags: ['mobility'], tactic: { kind: 'buff', attack: 1 } },
    { id: 'cq-breachfire', name: 'Breachfire', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Siege', type: 'spell', manaCost: 3, text: 'Deal 4 damage to a Barricade or Structure.', tags: ['anti-structure'], tactic: { kind: 'strike-structure', amount: 4 } },
    { id: 'cq-ruinburst-mortar', name: 'Ruinburst Mortar', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Explosive', type: 'spell', manaCost: 4, text: 'Deal explosive 5 to target cell.', tags: ['explosive', 'anti-horde'], tactic: { kind: 'blast-cell', amount: 5 } },
    { id: 'cq-bloodrush-signal', name: 'Bloodrush Signal', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Buff', type: 'spell', manaCost: 2, attack: 2, text: 'Up to two allied attackers gain +2 ATK this turn.', tags: ['buff'], tactic: { kind: 'buff', attack: 2, repeats: 2 } },
    { id: 'cq-pylon-surge', name: 'Pylon Surge', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'pylon', cardType: 'Spell', subtype: 'Resource', type: 'spell', manaCost: 2, text: 'Gain mana equal to the number of Mana Pylons you control, up to 3.', tags: ['resource'], tactic: { kind: 'gain-mana-from-pylons', max: 3 } },
    { id: 'cq-wing-screen', name: 'Wing Screen', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'air', cardType: 'Spell', subtype: 'Protection', type: 'spell', manaCost: 3, health: 2, text: 'Your Flying units gain +2 HP this turn and cannot be targeted by Turrets until your next turn.', tags: ['air', 'protection'], tactic: { kind: 'buff-air', health: 2 } },
    { id: 'cq-shock-banner', name: 'Shock Banner', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'horde', cardType: 'Spell', subtype: 'Buff', type: 'spell', manaCost: 5, attack: 3, text: 'All allied Hordes gain +3 ATK this turn. Non-Horde allies gain +1 ATK.', tags: ['horde', 'buff'], tactic: { kind: 'horde-buff', attack: 3, otherAttack: 1 } },
    { id: 'cq-fell-detonation', name: 'Fell Detonation', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Explosive', type: 'spell', manaCost: 4, text: 'Destroy one of your damaged units. Deal explosive 5 to all adjacent cells.', tags: ['explosive', 'sacrifice'], tactic: { kind: 'blast-cell', amount: 5 } },
    { id: 'cq-warp-incursion', name: 'Warp Incursion', side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Summon', type: 'spell', manaCost: 6, text: 'Summon two Goblin Spearlines and one Carrion Bats into empty attacker cells.', tags: ['summon'], tactic: { kind: 'summon-multi', cards: ['cq-goblin-spearline', 'cq-goblin-spearline', 'cq-carrion-bats'] } },
    { id: 'cq-predators-claim', name: "Predator's Claim", side: 'attacker', sourceBuilding: 'attacker', attackerPackage: 'spell', cardType: 'Spell', subtype: 'Capture', type: 'spell', manaCost: 3, captureRelevant: true, text: 'If an allied unit occupies an enemy-controlled cell, capture it immediately and draw 1.', tags: ['capture', 'draw'], tactic: { kind: 'capture-boost' } },
  ];
  cards.push(...attackerBaseline.map(card));
  const attackerGroundNames = ['Emberfang Raiders', 'Rotblade Scavengers', 'Ashen Breachpack', 'Sunder Jackals', 'Basilisk Runners', 'Chainhook Brigands', 'Void Mastiffs', 'Goremaw Lancers', 'Black Flare Scouts', 'Pylon Saboteur', 'Grim Ram Squad', 'Dread Flayers', 'Riftchain Raiders', 'Cinder Howl Pack', 'Breach Prophets', 'Skullplate Reavers', 'Ironjaw Marauders', 'Hollow Pike Cadre'];
  attackerGroundNames.forEach((name, idx) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    cards.push(card({
      id: `cq-${slug}`,
      side: 'attacker',
      sourceBuilding: 'attacker',
      attackerPackage: idx % 4 === 0 ? 'siege' : 'ground',
      name,
      cardType: 'Unit',
      subtype: idx % 4 === 0 ? 'Ground Siege' : 'Ground',
      manaCost: 2 + (idx % 4),
      attack: 3 + (idx % 3),
      health: 2 + (idx % 4),
      defense: idx % 5 === 0 ? 1 : 0,
      siege: idx % 4 === 0 ? 2 + (idx % 2) : 0,
      text: idx % 4 === 0 ? 'Specialist siege linebreaker.' : 'Aggressive ground assault unit.',
      tags: [idx % 4 === 0 ? 'siege' : 'ground', idx % 3 === 0 ? 'capture' : 'pressure'],
      captureRelevant: idx % 3 === 0,
    }));
  });

  const attackerAirNames = ['Grim Flak Riders', 'Bloodkite Harriers', 'Skychitter Cloud', 'Voidshriek Bombers', 'Harrier Transport', 'Shadow Vultures', 'Winged Skirmish Clan', 'Needlewing Scouts', 'Riftstorm Talons', 'Scorchwing Flock', 'Hollow Manta Wing', 'Carrion Harrow Flight'];
  attackerAirNames.forEach((name, idx) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    cards.push(card({
      id: `cq-${slug}`,
      side: 'attacker',
      sourceBuilding: 'attacker',
      attackerPackage: idx % 3 === 0 ? 'air-horde' : 'air',
      name,
      cardType: 'Unit',
      subtype: idx % 3 === 0 ? 'Horde Air' : 'Air',
      manaCost: 3 + (idx % 4),
      attack: 2 + (idx % 4),
      health: 2 + (idx % 3),
      defense: 0,
      range: idx % 2 === 0 ? 2 : 1,
      flying: true,
      horde: idx % 3 === 0,
      text: idx % 3 === 0 ? 'Air horde wing, vulnerable to anti-air fire.' : 'Fast flying strike unit.',
      tags: ['air', idx % 3 === 0 ? 'horde' : 'harrier'],
    }));
  });

  const attackerGiantNames = ['Gorewheel Giant', 'Thornhide Colossus', 'Voidtusk Behemoth', 'Rubblemire Titan', 'Boneplow Colossus', 'Marrow Engine', 'Ironjaw Dreadnaught', 'Locus Overmind'];
  attackerGiantNames.forEach((name, idx) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    cards.push(card({
      id: `cq-${slug}`,
      side: 'attacker',
      sourceBuilding: 'attacker',
      attackerPackage: 'giant',
      name,
      cardType: 'Unit',
      subtype: idx === 7 ? 'Large Air' : 'Large Ground Siege',
      manaCost: 8 + Math.floor(idx / 2),
      attack: 9 + idx,
      health: 10 + idx,
      defense: idx >= 5 ? 2 : 1,
      large: true,
      flying: idx === 7,
      siege: 2 + (idx % 4),
      text: 'Large invasion centerpiece. Requires strong pylon economy.',
      tags: ['giant', idx === 7 ? 'air' : 'siege'],
    }));
  });

  const attackerSpellNames = [
    ['Mana Fracture', 'sabotage'],
    ['Pylon Overcharge', 'resource'],
    ['Turret Jam', 'anti-turret'],
    ['Wall Breach Signal', 'breach'],
    ['Corrosive Rain', 'weather'],
    ['Dustfront Volley', 'weather'],
    ['Morale Breaker Chant', 'morale'],
    ['Raid Reserves', 'summon'],
    ['Frenzy Drums', 'buff'],
    ['Shrapnel Arc', 'explosive'],
    ['Lanebreak Protocol', 'capture'],
    ['Riftstorm Battery Order', 'siege'],
    ['Signal of Panic', 'morale'],
    ['Scorched Advance', 'lane-order'],
  ];
  attackerSpellNames.forEach(([name, role], idx) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    cards.push(card({
      id: `cq-${slug}`,
      side: 'attacker',
      sourceBuilding: 'attacker',
      attackerPackage: role === 'resource' ? 'pylon' : 'spell',
      name,
      cardType: 'Spell',
      subtype: role,
      type: 'spell',
      manaCost: 2 + (idx % 4),
      attack: role === 'buff' ? 2 : 0,
      text: `Attacker tactic: ${role}.`,
      tags: [role],
      tactic: role === 'resource'
        ? { kind: 'gain-mana', amount: 3 }
        : role === 'summon'
          ? { kind: 'summon-multi', cards: ['cq-goblin-spearline', 'cq-bone-clad-raiders'] }
          : role === 'explosive'
            ? { kind: 'blast-cell', amount: 4 }
            : role === 'buff'
              ? { kind: 'ground-buff', attack: 2 }
              : { kind: 'buff', attack: 1 },
      captureRelevant: role === 'capture' || role === 'lane-order',
    }));
  });

  const attackerExpansionIds = [];
  const attackerExpansions = [
    { key: 'war-pylon', name: 'War Pylon', pkg: 'pylon', type: 'pylon', cardType: 'Structure', subtype: 'Mana Pylon', mana: 2, atk: 0, hp: 6, def: 0, tags: ['pylon', 'resource', 'elite'], text: 'Advanced pylon. Counts as 2 pylons for surge effects.' },
    { key: 'spore-ram-horde', name: 'Spore Ram Horde', pkg: 'horde', type: 'unit', cardType: 'Unit', subtype: 'Horde Ground', mana: 5, atk: 11, hp: 11, def: 0, horde: true, siege: 2, tags: ['horde', 'siege'], text: 'Horde siege pack that pressures barricade lines.' },
    { key: 'flaykite-raiders', name: 'Flaykite Raiders', pkg: 'air', type: 'unit', cardType: 'Unit', subtype: 'Air', mana: 4, atk: 4, hp: 3, def: 0, flying: true, range: 2, tags: ['air', 'harrier'], text: 'Flying raiders with lane harassment pressure.' },
    { key: 'turret-jammer-cell', name: 'Turret Jammer Cell', pkg: 'specialist', type: 'spell', cardType: 'Spell', subtype: 'Sabotage', mana: 3, atk: 0, hp: 0, def: 0, tags: ['sabotage', 'anti-turret'], tactic: { kind: 'disable-target', turns: 1 }, text: 'Disable an enemy turret for 1 turn.' },
    { key: 'pylon-overcharge-surge', name: 'Pylon Overcharge Surge', pkg: 'pylon', type: 'spell', cardType: 'Spell', subtype: 'Resource', mana: 2, atk: 0, hp: 0, def: 0, tags: ['resource', 'pylon'], tactic: { kind: 'gain-mana-from-pylons', max: 4 }, text: 'Gain mana equal to your pylons, up to 4.' },
    { key: 'lanebreaker-vanguard', name: 'Lanebreaker Vanguard', pkg: 'ground', type: 'unit', cardType: 'Unit', subtype: 'Ground Siege', mana: 5, atk: 6, hp: 6, def: 1, siege: 3, tags: ['ground', 'siege', 'breach'], text: 'If this destroys a barricade it may advance one cell.' },
    { key: 'grave-cannon-battery', name: 'Grave Cannon Battery', pkg: 'spell', type: 'spell', cardType: 'Spell', subtype: 'Explosive', mana: 4, atk: 0, hp: 0, def: 0, tags: ['explosive', 'anti-horde'], tactic: { kind: 'blast-cell', amount: 6 }, text: 'Deal explosive 6 to a target cell.' },
    { key: 'void-hunt-captain', name: 'Void Hunt Captain', pkg: 'support', type: 'unit', cardType: 'Unit', subtype: 'Officer', mana: 5, atk: 3, hp: 6, def: 1, tags: ['officer', 'morale', 'support'], text: 'Adjacent attackers gain +1 ATK and capture pressure.' },
    { key: 'riftbreaker-colossus', name: 'Riftbreaker Colossus', pkg: 'giant', type: 'unit', cardType: 'Unit', subtype: 'Large Ground Siege', mana: 10, atk: 12, hp: 13, def: 2, large: true, siege: 5, tags: ['giant', 'siege'], text: 'Massive siege giant for final lane breaks.' },
    { key: 'harrowing-signal', name: 'Harrowing Signal', pkg: 'spell', type: 'spell', cardType: 'Spell', subtype: 'Morale', mana: 3, atk: 2, hp: 0, def: 0, tags: ['morale', 'buff'], tactic: { kind: 'buff', attack: 2, repeats: 2 }, text: 'Up to two allied attackers gain +2 ATK this turn.' },
  ];
  for (let wave = 1; wave <= 3; wave += 1) {
    attackerExpansions.forEach((base, idx) => {
      const id = `cq-${base.key}-${wave}`;
      attackerExpansionIds.push(id);
      cards.push(card({
        id,
        name: `${base.name} ${wave === 1 ? 'I' : wave === 2 ? 'II' : 'III'}`,
        side: 'attacker',
        sourceBuilding: 'attacker',
        attackerPackage: base.pkg,
        type: base.type,
        cardType: base.cardType,
        subtype: base.subtype,
        manaCost: base.mana + (wave === 3 ? 1 : 0),
        attack: base.atk + (wave === 3 && base.type === 'unit' ? 1 : 0),
        health: base.hp + (wave >= 2 && base.type === 'unit' ? 1 : 0),
        defense: base.def,
        range: Math.max(1, Number(base.range ?? 1)),
        siege: Math.max(0, Number(base.siege ?? 0)),
        flying: !!base.flying,
        horde: !!base.horde,
        large: !!base.large,
        structure: base.type === 'pylon' || base.cardType === 'Structure',
        captureRelevant: base.tags.includes('capture') || base.tags.includes('breach'),
        text: base.text,
        tags: [...base.tags, 'attacker-expansion', `wave:${wave}`],
        tactic: base.tactic ? { ...base.tactic } : null,
      }));
    });
  }

  const attackerSpecial = [
    { id: 'cq-pylon-bloom-engine', name: 'Pylon Bloom Engine', cardType: 'Structure', subtype: 'Mana Pylon', type: 'pylon', structure: true, manaCost: 3, attack: 0, health: 6, defense: 0, attackerPackage: 'pylon', text: 'Counts as two pylons for mana gains.', tags: ['resource', 'pylon', 'elite'] },
    { id: 'cq-huntmaster-of-ashes', name: 'Huntmaster of Ashes', cardType: 'Unit', subtype: 'Officer', manaCost: 6, attack: 4, health: 6, defense: 1, attackerPackage: 'support', text: 'Other allied attackers gain +1 ATK.', tags: ['officer', 'buff'] },
    { id: 'cq-saboteur-engineers', name: 'Saboteur Engineers', cardType: 'Unit', subtype: 'Specialist', manaCost: 4, attack: 3, health: 4, defense: 0, attackerPackage: 'specialist', text: 'On play, disable target turret for 1 turn.', tags: ['sabotage', 'anti-turret'] },
    { id: 'cq-void-drill-rig', name: 'Void Drill Rig', cardType: 'Structure', subtype: 'Siege Engine', structure: true, manaCost: 5, attack: 0, health: 7, defense: 1, attackerPackage: 'siege', text: 'Allied siege units in this lane gain +1 ATK.', tags: ['siege-support'] },
    { id: 'cq-corrosive-beast-horde', name: 'Corrosive Beast Horde', cardType: 'Unit', subtype: 'Horde Ground', manaCost: 6, attack: 12, health: 12, defense: 0, attackerPackage: 'horde', horde: true, text: 'Horde. Deals +2 damage to structures.', tags: ['horde', 'anti-structure'] },
    { id: 'cq-flying-harrier-column', name: 'Flying Harrier Column', cardType: 'Unit', subtype: 'Air Support', manaCost: 5, attack: 4, health: 5, defense: 0, attackerPackage: 'air', flying: true, text: 'Flying support wing that grants +1 range to allied air units.', tags: ['air', 'support'] },
  ];
  cards.push(...attackerSpecial.map((entry) => card({ ...entry, side: 'attacker', sourceBuilding: 'attacker' })));

  const facilityExpansionBuildingIds = [];
  const facilityExpansionBuildings = [
    { id: 'cq-motor-pool', name: 'Motor Pool', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 4, ironCost: 4, attack: 0, health: 7, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Vehicle Deck.', tags: ['facility', 'vehicle-hub', 'production', 'draw:vehicle'], production: { drawDeck: 'vehicle' } },
    { id: 'cq-ordnance-foundry', name: 'Ordnance Foundry', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 4, ironCost: 5, attack: 0, health: 7, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Ordnance Deck.', tags: ['facility', 'ordnance-hub', 'production', 'draw:ordnance'], production: { drawDeck: 'ordnance' } },
    { id: 'cq-air-pad', name: 'Air Pad / Skydock', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 5, ironCost: 4, attack: 0, health: 6, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Air Support Deck.', tags: ['facility', 'air-hub', 'production', 'draw:air'], production: { drawDeck: 'air' } },
    { id: 'cq-reactor-core', name: 'Reactor Core', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, fortified: true, wheatCost: 4, ironCost: 6, attack: 0, health: 8, defense: 2, text: 'Production — Spend 1 production draw to draw 1 card from your Power/Shield Deck.', tags: ['facility', 'power-hub', 'production', 'draw:power'], production: { drawDeck: 'power' } },
    { id: 'cq-medical-bay', name: 'Medical Bay', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 5, ironCost: 3, attack: 0, health: 6, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Recovery Deck.', tags: ['facility', 'recovery-hub', 'production', 'draw:recovery'], production: { drawDeck: 'recovery' } },
    { id: 'cq-war-lab', name: 'War Lab', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 6, ironCost: 6, attack: 0, health: 7, defense: 1, text: 'Production — Spend 1 production draw to draw 1 card from your Experimental Deck.', tags: ['facility', 'experimental-hub', 'production', 'draw:experimental'], production: { drawDeck: 'experimental' } },
    { id: 'cq-command-bunker', name: 'Command Bunker', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, fortified: true, wheatCost: 5, ironCost: 5, attack: 0, health: 9, defense: 2, text: 'Command citadel. Production — Spend 1 production draw to draw 1 card from your Command Deck.', tags: ['facility', 'command-hub', 'production', 'draw:command', 'fortified'], production: { drawDeck: 'command' } },
    { id: 'cq-ammo-depot', name: 'Ammo Depot', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 4, ironCost: 5, attack: 0, health: 7, defense: 1, text: 'Ammunition logistics node. Production — Spend 1 production draw to draw 1 card from your Ordnance Deck.', tags: ['facility', 'ordnance-hub', 'production', 'draw:ordnance', 'ammo'], production: { drawDeck: 'ordnance' } },
    { id: 'cq-signal-tower', name: 'Signal Tower', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 4, ironCost: 4, attack: 0, health: 6, defense: 1, text: 'Long-range comms uplink. Production — Spend 1 production draw to draw 1 card from your Air Support Deck.', tags: ['facility', 'air-hub', 'production', 'draw:air', 'intel'], production: { drawDeck: 'air' } },
    { id: 'cq-shield-generator', name: 'Shield Generator', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, fortified: true, wheatCost: 5, ironCost: 6, attack: 0, health: 8, defense: 2, text: 'Barrier projector complex. Production — Spend 1 production draw to draw 1 card from your Power/Shield Deck.', tags: ['facility', 'power-hub', 'production', 'draw:power', 'shield'], production: { drawDeck: 'power' } },
    { id: 'cq-forward-barracks', name: 'Forward Barracks', sourceBuilding: 'command', cardType: 'Structure', subtype: 'Facility', structure: true, facility: true, wheatCost: 4, ironCost: 3, attack: 0, health: 7, defense: 1, text: 'Forward troop mustering post. Production — Spend 1 production draw to draw 1 card from your Training Deck.', tags: ['facility', 'training-hub', 'production', 'draw:training'], production: { drawDeck: 'training' } },
  ];
  facilityExpansionBuildings.forEach((entry) => {
    facilityExpansionBuildingIds.push(entry.id);
    cards.push(card(entry));
  });

  const productionMk = ['I', 'II', 'III'];

  const trainingOverhaulIds = [];
  const trainingOverhaulPatterns = [
    { key: 'rifle-line', name: 'Rifle Line', subtype: 'Infantry Ranged', wheat: 3, iron: 1, atk: 3, hp: 2, def: 0, range: 2, tags: ['training-roster', 'ranged', 'line-holder'], text: 'Reliable ranged infantry for lane pressure.' },
    { key: 'shock-infantry', name: 'Shock Infantry', subtype: 'Infantry', wheat: 3, iron: 2, atk: 4, hp: 3, def: 0, range: 1, tags: ['training-roster', 'breach', 'aggressive'], text: 'On deploy may advance 1 cell if lane front is empty.' },
    { key: 'tower-guard', name: 'Tower Guard', subtype: 'Infantry', wheat: 4, iron: 2, atk: 3, hp: 5, def: 1, range: 1, tags: ['training-roster', 'fortified', 'structure-guard'], text: 'Adjacent structures gain +1 DEF while this unit stands.', fortified: true },
    { key: 'field-medic', name: 'Field Medic', subtype: 'Infantry Support', wheat: 2, iron: 1, atk: 1, hp: 3, def: 0, range: 1, tags: ['training-roster', 'heal', 'support'], text: 'End of turn: heal 1 to two adjacent allies.' },
    { key: 'combat-engineer', name: 'Combat Engineer', subtype: 'Infantry Utility', wheat: 3, iron: 2, atk: 1, hp: 3, def: 0, range: 1, tags: ['training-roster', 'repair', 'support'], text: 'Action: Repair 2 to adjacent structure or barricade.', repairRelevant: true },
    { key: 'banner-officer', name: 'Banner Officer', subtype: 'Officer', wheat: 4, iron: 2, atk: 2, hp: 4, def: 1, range: 1, tags: ['training-roster', 'officer', 'morale'], text: 'Adjacent allied troops gain +1 ATK.' },
    { key: 'forward-scout', name: 'Forward Scout', subtype: 'Infantry Scout', wheat: 2, iron: 0, atk: 1, hp: 2, def: 0, range: 1, tags: ['training-roster', 'scout', 'capture'], text: 'May move 1 extra cell instead of attacking.', captureRelevant: true },
    { key: 'anti-air-marksman', name: 'Anti-Air Marksman', subtype: 'Infantry Ranged', wheat: 3, iron: 2, atk: 3, hp: 2, def: 0, range: 3, tags: ['training-roster', 'ranged', 'anti-flying'], text: 'Ranged 3. +2 damage to Flying targets.' },
    { key: 'riot-suppressor', name: 'Riot Suppressor', subtype: 'Infantry', wheat: 3, iron: 2, atk: 3, hp: 4, def: 1, range: 1, tags: ['training-roster', 'anti-horde', 'frontline'], text: 'Attacks against Hordes are explosive.', siege: 1 },
    { key: 'heavy-infantry', name: 'Heavy Infantry', subtype: 'Infantry', wheat: 4, iron: 3, atk: 4, hp: 5, def: 2, range: 1, tags: ['training-roster', 'frontline', 'armoured'], text: 'Armoured line unit for contested lanes.' },
    { key: 'longbow-line', name: 'Longbow Line', subtype: 'Infantry Ranged', wheat: 4, iron: 1, atk: 4, hp: 2, def: 0, range: 3, tags: ['training-roster', 'ranged', 'anti-air'], text: 'Long-range marksmen that punish exposed air units.' },
    { key: 'crossbow-battery', name: 'Crossbow Battery', subtype: 'Infantry Ranged', wheat: 4, iron: 2, atk: 4, hp: 3, def: 0, range: 3, tags: ['training-roster', 'ranged', 'suppression'], text: 'Cannot move and attack in the same turn without command support.' },
    { key: 'sapper-breach-team', name: 'Sapper Breach Team', subtype: 'Infantry Utility', wheat: 3, iron: 3, atk: 2, hp: 3, def: 0, range: 1, tags: ['training-roster', 'breach', 'siege'], text: 'Siege 3. Gains +2 ATK against barricades and turrets.', siege: 3 },
    { key: 'mobile-response-squad', name: 'Mobile Response Squad', subtype: 'Infantry Scout', wheat: 3, iron: 1, atk: 2, hp: 3, def: 0, range: 1, tags: ['training-roster', 'mobility', 'capture'], text: 'May move 1 extra cell and still contest capture pressure.', captureRelevant: true },
    { key: 'marshal-commander', name: 'Marshal Commander', subtype: 'Officer', wheat: 5, iron: 3, atk: 3, hp: 5, def: 1, range: 1, tags: ['training-roster', 'officer', 'morale'], text: 'Adjacent allies gain +1 ATK and +1 HP while in your control zone.' },
    { key: 'trench-defender', name: 'Trench Defender', subtype: 'Infantry', wheat: 3, iron: 2, atk: 2, hp: 5, def: 2, range: 1, tags: ['training-roster', 'fortified', 'line-holder'], text: 'Fortified when occupying allied-owned cells.', fortified: true },
  ];
  trainingOverhaulPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-${pattern.key}-${idx + 1}`;
      trainingOverhaulIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'training',
        cardType: 'Unit',
        subtype: pattern.subtype,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: pattern.atk + (idx === 2 ? 1 : 0),
        health: pattern.hp + idx,
        defense: pattern.def + (idx === 2 ? 1 : 0),
        range: pattern.range,
        siege: pattern.siege ?? 0,
        fortified: !!pattern.fortified,
        text: pattern.text,
        tags: [...pattern.tags, 'training-overhaul'],
        repairRelevant: !!pattern.repairRelevant,
        captureRelevant: !!pattern.captureRelevant,
      }));
    });
  });

  const factoryWarMachineIds = [];
  const factoryWarMachinePatterns = [
    { key: 'light-tank', name: 'Light Tank', subtype: 'Vehicle', wheat: 4, iron: 5, atk: 5, hp: 6, def: 1, range: 1, siege: 1, tags: ['factory-war-machine', 'vehicle', 'pressure'], text: 'Fast armored opener that can reposition aggressively.' },
    { key: 'siege-tank', name: 'Siege Tank', subtype: 'Vehicle Siege', wheat: 5, iron: 7, atk: 6, hp: 7, def: 2, range: 2, siege: 4, tags: ['factory-war-machine', 'vehicle', 'siege'], text: 'Siege chassis built to crack structures.' },
    { key: 'breach-tank', name: 'Breach Tank', subtype: 'Vehicle Siege', wheat: 5, iron: 6, atk: 6, hp: 7, def: 1, range: 1, siege: 4, tags: ['factory-war-machine', 'vehicle', 'breach'], text: 'If this destroys a barricade, advance 1 cell.' },
    { key: 'flak-wagon', name: 'Flak Wagon', subtype: 'Vehicle Anti-Air', wheat: 4, iron: 6, atk: 4, hp: 6, def: 1, range: 3, siege: 0, tags: ['factory-war-machine', 'vehicle', 'anti-flying'], text: 'Ranged 3. +2 damage versus flying units.' },
    { key: 'assault-carrier', name: 'Assault Carrier', subtype: 'Vehicle Support', wheat: 5, iron: 6, atk: 3, hp: 8, def: 2, range: 1, siege: 0, tags: ['factory-war-machine', 'vehicle', 'support'], text: 'On deploy, draw 1 Training card if available.', tactic: { kind: 'draw', deck: 'training', count: 1 } },
    { key: 'ironclad-walker', name: 'Ironclad Walker', subtype: 'Mech', wheat: 5, iron: 7, atk: 6, hp: 8, def: 2, range: 1, siege: 1, tags: ['factory-war-machine', 'mech', 'armoured'], text: 'Heavy walker that anchors contested lanes.' },
    { key: 'war-mech', name: 'War Mech', subtype: 'Mech', wheat: 6, iron: 8, atk: 7, hp: 8, def: 2, range: 1, siege: 2, tags: ['factory-war-machine', 'mech', 'siege'], text: 'Dominant mid-late lane breaker.' },
    { key: 'heavy-war-mech', name: 'Heavy War Mech', subtype: 'Mech Heavy', wheat: 7, iron: 10, atk: 8, hp: 10, def: 3, range: 1, siege: 3, tags: ['factory-war-machine', 'mech', 'large'], text: 'Large. High durability and siege pressure.', large: true },
    { key: 'rail-cannon-carriage', name: 'Rail Cannon Carriage', subtype: 'Artillery', wheat: 7, iron: 10, atk: 9, hp: 7, def: 1, range: 4, siege: 5, tags: ['factory-war-machine', 'artillery', 'anti-large'], text: 'High-damage precision anti-large shots.' },
    { key: 'colossus-chassis', name: 'Colossus Chassis', subtype: 'Prototype Giant', wheat: 8, iron: 11, atk: 9, hp: 12, def: 3, range: 1, siege: 4, tags: ['factory-war-machine', 'giant', 'prototype'], text: 'Large prototype frame. Premium Blacksmith target.', large: true },
    { key: 'deepcore-drill-engine', name: 'Deepcore Drill Engine', subtype: 'Vehicle Siege', wheat: 6, iron: 8, atk: 7, hp: 8, def: 2, range: 1, siege: 5, tags: ['factory-war-machine', 'vehicle', 'breach', 'siege'], text: 'Specialized anti-fortification rig that tunnels through wall lines.' },
    { key: 'rocket-platform', name: 'Rocket Platform', subtype: 'Artillery', wheat: 6, iron: 9, atk: 8, hp: 6, def: 1, range: 4, siege: 3, tags: ['factory-war-machine', 'artillery', 'explosive', 'anti-horde'], text: 'Explosive saturation platform with lane-clearing barrages.' },
    { key: 'shield-carrier', name: 'Shield Carrier', subtype: 'Vehicle Support', wheat: 5, iron: 8, atk: 3, hp: 9, def: 3, range: 1, siege: 0, tags: ['factory-war-machine', 'vehicle', 'shield', 'support'], text: 'Adjacent allies gain +1 DEF and absorb first chip hit each turn.' },
    { key: 'breach-crawler', name: 'Breach Crawler', subtype: 'Vehicle Siege', wheat: 6, iron: 8, atk: 7, hp: 9, def: 2, range: 1, siege: 4, tags: ['factory-war-machine', 'vehicle', 'siege', 'capture'], text: 'After destroying a structure, may advance 1 cell and capture pressure.', captureRelevant: true },
    { key: 'industrial-walker', name: 'Industrial Walker', subtype: 'Mech Utility', wheat: 6, iron: 9, atk: 6, hp: 10, def: 2, range: 1, siege: 2, tags: ['factory-war-machine', 'mech', 'repair', 'support'], text: 'Action: Repair 3 to adjacent structure, turret, or vehicle.', repairRelevant: true },
    { key: 'flame-projector-wagon', name: 'Flame Projector Wagon', subtype: 'Vehicle Assault', wheat: 5, iron: 7, atk: 6, hp: 7, def: 1, range: 2, siege: 2, tags: ['factory-war-machine', 'vehicle', 'anti-horde', 'assault'], text: 'Explosive anti-horde sweeper with short-range flame arcs.' },
  ];
  factoryWarMachinePatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-${pattern.key}-${idx + 1}`;
      factoryWarMachineIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'factory',
        cardType: 'Unit',
        subtype: pattern.subtype,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: pattern.atk + (idx === 2 ? 1 : 0),
        health: pattern.hp + idx,
        defense: pattern.def + (idx === 2 ? 1 : 0),
        range: pattern.range,
        siege: pattern.siege,
        large: !!pattern.large,
        repairRelevant: !!pattern.repairRelevant,
        captureRelevant: !!pattern.captureRelevant,
        text: pattern.text,
        tags: [...pattern.tags, 'factory-overhaul'],
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const blacksmithOverhaulIds = [];
  const blacksmithOverhaulPatterns = [
    { key: 'tank-plating-kit', name: 'Tank Plating Kit', cardType: 'Upgrade Schematic', subtype: 'Vehicle Armour', wheat: 3, iron: 5, atk: 0, hp: 3, def: 2, tags: ['blacksmith-overhaul', 'vehicle-mod', 'armour'], text: 'Upgrade vehicle/mech: +3 HP and +2 DEF.', upgradeSchematic: true },
    { key: 'turret-optics-array', name: 'Turret Optics Array', cardType: 'Upgrade Schematic', subtype: 'Turret Optics', wheat: 2, iron: 4, atk: 1, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'turret-mod', 'ranged'], text: 'Upgrade turret: +1 range and +1 ATK.', upgradeSchematic: true },
    { key: 'siege-warhead-rack', name: 'Siege Warhead Rack', cardType: 'Upgrade Schematic', subtype: 'Siege Payload', wheat: 3, iron: 5, atk: 2, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'ordnance-mod', 'siege'], text: 'Upgrade siege unit: +2 siege damage.', upgradeSchematic: true },
    { key: 'anti-air-rigging', name: 'Anti-Air Rigging', cardType: 'Equipment', subtype: 'Weapon Module', wheat: 2, iron: 3, atk: 1, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'equipment', 'anti-flying'], text: 'Equip troop/vehicle: +1 ATK and +2 damage to Flying.', equipment: true },
    { key: 'anti-horde-canister', name: 'Anti-Horde Canister', cardType: 'Equipment', subtype: 'Ammunition', wheat: 2, iron: 3, atk: 1, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'equipment', 'anti-horde', 'explosive'], text: 'Equipped ranged attacks splash Horde units.', equipment: true },
    { key: 'giant-killer-harpoon', name: 'Giant-Killer Harpoon', cardType: 'Equipment', subtype: 'Weapon', wheat: 3, iron: 4, atk: 2, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'equipment', 'anti-large'], text: 'Equipped unit deals +3 damage versus Large.', equipment: true },
    { key: 'field-repair-braces', name: 'Field Repair Braces', cardType: 'Utility', subtype: 'Repair Kit', type: 'tactic', wheat: 2, iron: 2, atk: 0, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'repair', 'support'], text: 'Repair 5 to target structure or mech.', repairRelevant: true, tactic: { kind: 'repair', amount: 5 } },
    { key: 'officer-war-regalia', name: 'Officer War Regalia', cardType: 'Equipment', subtype: 'Officer Gear', wheat: 3, iron: 3, atk: 1, hp: 2, def: 1, tags: ['blacksmith-overhaul', 'equipment', 'officer', 'morale'], text: 'Equip Officer: adjacent allies gain +1 ATK and morale resistance.', equipment: true },
    { key: 'reactive-armour-laminate', name: 'Reactive Armour Laminate', cardType: 'Equipment', subtype: 'Armour', wheat: 3, iron: 4, atk: 0, hp: 3, def: 2, tags: ['blacksmith-overhaul', 'equipment', 'armour', 'anti-large'], text: 'Equip unit: +3 HP/+2 DEF and reduce Large damage by 1.', equipment: true },
    { key: 'golden-warforged-frame', name: 'Golden Warforged Frame', cardType: 'Upgrade Schematic', subtype: 'Elite Frame', wheat: 5, iron: 7, atk: 2, hp: 4, def: 2, tags: ['blacksmith-overhaul', 'elite', 'vehicle-mod'], text: 'Elite vehicle/mech upgrade line with large combat swing.', upgradeSchematic: true },
    { key: 'mech-servo-overdrive', name: 'Mech Servo Overdrive', cardType: 'Upgrade Schematic', subtype: 'Mech Module', wheat: 4, iron: 6, atk: 2, hp: 2, def: 1, tags: ['blacksmith-overhaul', 'mech-mod', 'tempo'], text: 'Upgrade mech: +2 ATK/+2 HP and it may move then attack once this turn.', upgradeSchematic: true },
    { key: 'turret-stabilizer-bundle', name: 'Turret Stabilizer Bundle', cardType: 'Upgrade Schematic', subtype: 'Turret Module', wheat: 3, iron: 5, atk: 2, hp: 1, def: 1, tags: ['blacksmith-overhaul', 'turret-mod', 'precision'], text: 'Upgrade turret: +2 ATK/+1 HP/+1 DEF and improved line stability.', upgradeSchematic: true },
    { key: 'breach-charge-lance', name: 'Breach Charge Lance', cardType: 'Equipment', subtype: 'Siege Weapon', wheat: 3, iron: 4, atk: 2, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'equipment', 'siege', 'breach'], text: 'Equip unit: +2 ATK and +2 siege against structures.', equipment: true },
    { key: 'ferro-seal-bracing', name: 'Ferro-Seal Bracing', cardType: 'Utility', subtype: 'Repair Kit', type: 'tactic', wheat: 2, iron: 3, atk: 0, hp: 0, def: 0, tags: ['blacksmith-overhaul', 'repair', 'structure'], text: 'Repair 4 to up to two different structures or barricades.', repairRelevant: true, tactic: { kind: 'repair', amount: 4 } },
    { key: 'command-signal-banner', name: 'Command Signal Banner', cardType: 'Equipment', subtype: 'Officer Gear', wheat: 3, iron: 3, atk: 1, hp: 1, def: 1, tags: ['blacksmith-overhaul', 'equipment', 'morale', 'command'], text: 'Equip officer/support unit: nearby allies gain capture pressure and morale.', equipment: true, captureRelevant: true },
    { key: 'fortress-rivet-array', name: 'Fortress Rivet Array', cardType: 'Upgrade Schematic', subtype: 'Fortification Module', wheat: 4, iron: 6, atk: 0, hp: 4, def: 2, tags: ['blacksmith-overhaul', 'fortification', 'barricade', 'turret-mod'], text: 'Upgrade barricade or turret with +4 HP and +2 DEF.', upgradeSchematic: true },
  ];
  blacksmithOverhaulPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-${pattern.key}-${idx + 1}`;
      blacksmithOverhaulIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'blacksmith',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        type: pattern.type ?? (pattern.cardType === 'Utility' ? 'tactic' : undefined),
        equipment: !!pattern.equipment,
        upgradeSchematic: !!pattern.upgradeSchematic,
        repairRelevant: !!pattern.repairRelevant,
        captureRelevant: !!pattern.captureRelevant,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: pattern.atk + (pattern.equipment && idx === 2 ? 1 : 0),
        health: pattern.hp + (pattern.cardType !== 'Utility' ? idx : 0),
        defense: pattern.def + (pattern.cardType !== 'Utility' && idx === 2 ? 1 : 0),
        text: pattern.text,
        tags: [...pattern.tags, 'blacksmith-overhaul-deck'],
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const vehicleDeckIds = [];
  const vehicleDeckPatterns = [
    { key: 'scout-car', name: 'Scout Car', cardType: 'Unit', subtype: 'Vehicle Recon', wheat: 3, iron: 3, atk: 3, hp: 4, def: 1, range: 1, tags: ['vehicle', 'capture'], text: 'Fast recon vehicle that can shift lanes quickly.', captureRelevant: true },
    { key: 'apc-column', name: 'APC Column', cardType: 'Unit', subtype: 'Vehicle Transport', wheat: 4, iron: 4, atk: 3, hp: 6, def: 1, range: 1, tags: ['vehicle', 'support'], text: 'On deploy, draw 1 Training card if available.', tactic: { kind: 'draw', deck: 'training', count: 1 } },
    { key: 'flak-buggy', name: 'Flak Buggy', cardType: 'Unit', subtype: 'Vehicle Anti-Air', wheat: 4, iron: 5, atk: 4, hp: 5, def: 1, range: 3, tags: ['vehicle', 'anti-flying'], text: 'Ranged 3 anti-air platform.' },
    { key: 'ramjeep', name: 'Ramjeep Breach Team', cardType: 'Unit', subtype: 'Vehicle Breach', wheat: 4, iron: 5, atk: 5, hp: 5, def: 1, range: 1, tags: ['vehicle', 'breach', 'siege'], text: 'Siege 2 and can advance after breaching barricades.', siege: 2 },
    { key: 'shield-coupe', name: 'Shield Coupe', cardType: 'Unit', subtype: 'Vehicle Support', wheat: 4, iron: 4, atk: 2, hp: 6, def: 2, range: 1, tags: ['vehicle', 'shield', 'support'], text: 'Adjacent allies gain +1 DEF.' },
    { key: 'support-hauler', name: 'Support Hauler', cardType: 'Unit', subtype: 'Vehicle Utility', wheat: 4, iron: 4, atk: 2, hp: 6, def: 1, range: 1, tags: ['vehicle', 'repair', 'support'], text: 'Action: Repair 2 to adjacent vehicle/structure.', repairRelevant: true },
  ];
  vehicleDeckPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-veh-${pattern.key}-${idx + 1}`;
      vehicleDeckIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'vehicle',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: pattern.atk + (idx === 2 ? 1 : 0),
        health: pattern.hp + idx,
        defense: pattern.def + (idx === 2 ? 1 : 0),
        range: pattern.range,
        siege: pattern.siege ?? 0,
        text: pattern.text,
        tags: [...pattern.tags, 'vehicle-deck'],
        captureRelevant: !!pattern.captureRelevant,
        repairRelevant: !!pattern.repairRelevant,
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const ordnanceDeckIds = [];
  const ordnanceDeckPatterns = [
    { key: 'breach-charge', name: 'Breach Charge', cardType: 'Tactic', subtype: 'Siege Payload', type: 'tactic', wheat: 2, iron: 3, tags: ['ordnance', 'breach', 'anti-structure'], text: 'Deal 5 damage to a structure or barricade.', tactic: { kind: 'strike-structure', amount: 5 } },
    { key: 'cluster-shell', name: 'Cluster Shell', cardType: 'Tactic', subtype: 'Explosive', type: 'tactic', wheat: 2, iron: 4, tags: ['ordnance', 'explosive', 'anti-horde'], text: 'Deal explosive 6 to a target cell.', tactic: { kind: 'blast-cell', amount: 6 } },
    { key: 'flak-burst', name: 'Anti-Air Flak Burst', cardType: 'Tactic', subtype: 'Anti-Air', type: 'tactic', wheat: 2, iron: 3, tags: ['ordnance', 'anti-flying'], text: 'Deal 5 damage to flying enemies in lane.', tactic: { kind: 'anti-air-barrage', amount: 5 } },
    { key: 'shell-feedline', name: 'Shell Feedline', cardType: 'Upgrade Schematic', subtype: 'Turret Ammo', wheat: 2, iron: 4, atk: 1, hp: 1, def: 0, tags: ['ordnance', 'turret-mod', 'upgrade'], text: 'Upgrade turret: +1 ATK and splash 1.', upgradeSchematic: true },
    { key: 'siege-canister', name: 'Siege Canister', cardType: 'Upgrade Schematic', subtype: 'Siege Ammo', wheat: 2, iron: 4, atk: 1, hp: 0, def: 0, siege: 2, tags: ['ordnance', 'siege', 'upgrade'], text: 'Upgrade siege units with +2 siege.', upgradeSchematic: true },
    { key: 'saturation-fire', name: 'Saturation Fire Order', cardType: 'Tactic', subtype: 'Siege Order', type: 'tactic', wheat: 3, iron: 4, atk: 2, tags: ['ordnance', 'siege', 'command'], text: 'Allied siege units gain +2 ATK this turn.', tactic: { kind: 'buff', attack: 2 } },
  ];
  ordnanceDeckPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-ord-${pattern.key}-${idx + 1}`;
      ordnanceDeckIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'ordnance',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        type: pattern.type,
        upgradeSchematic: !!pattern.upgradeSchematic,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: (pattern.atk ?? 0) + (idx === 2 ? 1 : 0),
        health: (pattern.hp ?? 0) + (pattern.upgradeSchematic && idx === 2 ? 1 : 0),
        defense: (pattern.def ?? 0) + (pattern.upgradeSchematic && idx >= 1 ? 1 : 0),
        siege: pattern.siege ?? 0,
        text: pattern.text,
        tags: [...pattern.tags, 'ordnance-deck'],
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const airSupportDeckIds = [];
  const airSupportDeckPatterns = [
    { key: 'interceptor-wing', name: 'Interceptor Wing', cardType: 'Unit', subtype: 'Air', wheat: 4, iron: 4, atk: 4, hp: 3, def: 0, range: 2, tags: ['air-support', 'air', 'anti-flying'], text: 'Flying ranged interceptor unit.', flying: true },
    { key: 'bombard-flight', name: 'Bombard Flight', cardType: 'Unit', subtype: 'Air Bomber', wheat: 5, iron: 5, atk: 5, hp: 4, def: 0, range: 2, tags: ['air-support', 'air', 'explosive'], text: 'On attack, deal explosive splash 3.', flying: true },
    { key: 'recon-drone', name: 'Recon Drone Cloud', cardType: 'Unit', subtype: 'Air Recon', wheat: 3, iron: 4, atk: 2, hp: 3, def: 0, range: 2, tags: ['air-support', 'air', 'intel', 'capture'], text: 'Capturing draws 1 command card.', flying: true, captureRelevant: true, tactic: { kind: 'draw', deck: 'command', count: 1 } },
    { key: 'airdrop', name: 'Airdrop Squad', cardType: 'Tactic', subtype: 'Deployment', type: 'tactic', wheat: 4, iron: 3, tags: ['air-support', 'summon', 'mobility'], text: 'Draw two Training cards.', tactic: { kind: 'draw', deck: 'training', count: 2 } },
    { key: 'flak-net', name: 'Flak Drone Net', cardType: 'Structure', subtype: 'Air Defense', wheat: 4, iron: 5, atk: 3, hp: 6, def: 1, range: 3, tags: ['air-support', 'turret', 'anti-flying'], text: 'Air-defense node with Ranged 3 fire.', structure: true },
    { key: 'wing-signal', name: 'Wing Command Signal', cardType: 'Tactic', subtype: 'Air Command', type: 'tactic', wheat: 3, iron: 3, atk: 2, tags: ['air-support', 'buff', 'command'], text: 'Air units gain +2 ATK this turn.', tactic: { kind: 'buff-air', attack: 2 } },
  ];
  airSupportDeckPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-air-${pattern.key}-${idx + 1}`;
      airSupportDeckIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'air',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        type: pattern.type,
        structure: !!pattern.structure,
        flying: !!pattern.flying,
        captureRelevant: !!pattern.captureRelevant,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: (pattern.atk ?? 0) + (pattern.cardType === 'Unit' && idx === 2 ? 1 : 0),
        health: (pattern.hp ?? 0) + (pattern.cardType !== 'Tactic' ? idx : 0),
        defense: (pattern.def ?? 0) + (pattern.cardType !== 'Tactic' && idx === 2 ? 1 : 0),
        range: pattern.range ?? 1,
        text: pattern.text,
        tags: [...pattern.tags, 'air-support-deck'],
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const powerShieldDeckIds = [];
  const powerShieldDeckPatterns = [
    { key: 'shield-array', name: 'Shield Array', cardType: 'Structure', subtype: 'Power Shield', wheat: 4, iron: 5, atk: 0, hp: 7, def: 2, tags: ['power-shield', 'structure', 'shield'], text: 'Adjacent allies gain +1 DEF.', structure: true, fortified: true },
    { key: 'reactor-overclock', name: 'Reactor Overclock', cardType: 'Tactic', subtype: 'Power Surge', type: 'tactic', wheat: 3, iron: 4, atk: 2, tags: ['power-shield', 'buff', 'turret'], text: 'Turrets gain +2 ATK this turn.', tactic: { kind: 'overclock-turrets', attack: 2 } },
    { key: 'energy-barrier', name: 'Energy Barrier', cardType: 'Structure', subtype: 'Barrier', wheat: 3, iron: 4, atk: 0, hp: 8, def: 2, tags: ['power-shield', 'barricade', 'structure'], text: 'Counts as barricade with energized plating.', structure: true, barricade: true, fortified: true },
    { key: 'capacitor-infusion', name: 'Capacitor Infusion', cardType: 'Upgrade Schematic', subtype: 'Power Module', wheat: 3, iron: 4, atk: 1, hp: 2, def: 1, tags: ['power-shield', 'upgrade', 'power-mod'], text: 'Upgrade structure/unit with +1/+2/+1.', upgradeSchematic: true },
    { key: 'power-conduit', name: 'Power Conduit Node', cardType: 'Structure', subtype: 'Power Node', wheat: 4, iron: 4, atk: 0, hp: 6, def: 1, tags: ['power-shield', 'structure', 'economy'], text: 'At start of turn gain +1 Iron.', structure: true, production: { ironPerTurn: 1 } },
    { key: 'reactor-harness', name: 'Reactor Shield Harness', cardType: 'Equipment', subtype: 'Power Armour', wheat: 3, iron: 4, atk: 0, hp: 2, def: 2, tags: ['power-shield', 'equipment', 'armour'], text: 'Equip troop: +2 HP and +2 DEF.', equipment: true },
  ];
  powerShieldDeckPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-pwr-${pattern.key}-${idx + 1}`;
      powerShieldDeckIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'power',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        type: pattern.type,
        structure: !!pattern.structure,
        barricade: !!pattern.barricade,
        fortified: !!pattern.fortified,
        equipment: !!pattern.equipment,
        upgradeSchematic: !!pattern.upgradeSchematic,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: (pattern.atk ?? 0) + (pattern.cardType === 'Unit' && idx === 2 ? 1 : 0),
        health: (pattern.hp ?? 0) + (pattern.cardType !== 'Tactic' ? idx : 0),
        defense: (pattern.def ?? 0) + (pattern.cardType !== 'Tactic' && idx === 2 ? 1 : 0),
        text: pattern.text,
        tags: [...pattern.tags, 'power-shield-deck'],
        production: pattern.production ? { ...pattern.production } : null,
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const recoveryDeckIds = [];
  const recoveryDeckPatterns = [
    { key: 'trauma-team', name: 'Trauma Team', cardType: 'Unit', subtype: 'Medic', wheat: 3, iron: 2, atk: 1, hp: 4, def: 0, tags: ['recovery', 'heal', 'support'], text: 'End of turn heal 2 split among adjacent allies.' },
    { key: 'stim-rush', name: 'Stim Pack Rush', cardType: 'Tactic', subtype: 'Stim', type: 'tactic', wheat: 3, iron: 2, atk: 2, tags: ['recovery', 'buff', 'tempo'], text: 'Target allied unit gains +2 ATK this turn.', tactic: { kind: 'buff', attack: 2 } },
    { key: 'morale-restoration', name: 'Morale Restoration', cardType: 'Tactic', subtype: 'Morale', type: 'tactic', wheat: 3, iron: 2, tags: ['recovery', 'morale', 'anti-shaken'], text: 'Remove Shaken and grant +1 HP to allies.', tactic: { kind: 'global-buff', health: 1 } },
    { key: 'triage-tent', name: 'Battlefield Triage Tent', cardType: 'Structure', subtype: 'Recovery Structure', wheat: 4, iron: 3, atk: 0, hp: 6, def: 1, tags: ['recovery', 'structure', 'heal'], text: 'Start of turn heal 2 to adjacent allies.', structure: true },
    { key: 'resilience-kit', name: 'Resilience Inoculation', cardType: 'Equipment', subtype: 'Medical Gear', wheat: 2, iron: 2, atk: 0, hp: 2, def: 1, tags: ['recovery', 'equipment', 'anti-explosive'], text: 'Equip unit: +2 HP/+1 DEF and explosive resilience.', equipment: true },
    { key: 'reserve-rations', name: 'Reserve Rations', cardType: 'Tactic', subtype: 'Supply', type: 'tactic', wheat: 2, iron: 1, tags: ['recovery', 'economy'], text: 'Gain +3 Wheat and draw 1 Training card.', tactic: { kind: 'resource', wheat: 3, drawDeck: 'training', drawCount: 1 } },
  ];
  recoveryDeckPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-rec-${pattern.key}-${idx + 1}`;
      recoveryDeckIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'recovery',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        type: pattern.type,
        structure: !!pattern.structure,
        equipment: !!pattern.equipment,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + (pattern.cardType === 'Unit' ? idx : 0),
        attack: (pattern.atk ?? 0) + (pattern.cardType === 'Unit' && idx === 2 ? 1 : 0),
        health: (pattern.hp ?? 0) + (pattern.cardType !== 'Tactic' ? idx : 0),
        defense: (pattern.def ?? 0) + (pattern.cardType !== 'Tactic' && idx === 2 ? 1 : 0),
        text: pattern.text,
        tags: [...pattern.tags, 'recovery-deck'],
        repairRelevant: true,
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const experimentalDeckIds = [];
  const experimentalDeckPatterns = [
    { key: 'prototype-mech', name: 'Prototype Mech', cardType: 'Unit', subtype: 'Prototype', wheat: 6, iron: 8, atk: 7, hp: 8, def: 2, range: 1, siege: 2, tags: ['experimental', 'prototype', 'mech'], text: 'High-impact prototype war machine.' },
    { key: 'phase-disruptor', name: 'Phase Disruptor', cardType: 'Tactic', subtype: 'Disruption', type: 'tactic', wheat: 4, iron: 5, tags: ['experimental', 'control', 'disrupt'], text: 'Disable target enemy for 1 turn.', tactic: { kind: 'disable-target', turns: 1 } },
    { key: 'quantum-barrier', name: 'Quantum Barrier', cardType: 'Structure', subtype: 'Barrier', wheat: 4, iron: 6, atk: 0, hp: 9, def: 3, tags: ['experimental', 'barricade', 'shield'], text: 'Fortified barrier that reflects 1 damage.', structure: true, barricade: true, fortified: true },
    { key: 'adaptive-warcore', name: 'Adaptive Warcore', cardType: 'Upgrade Schematic', subtype: 'Prototype Upgrade', wheat: 5, iron: 6, atk: 2, hp: 2, def: 2, siege: 1, tags: ['experimental', 'upgrade', 'prototype'], text: 'Upgrade unit/structure: +2/+2/+2 and +1 siege.', upgradeSchematic: true },
    { key: 'orbital-flare', name: 'Orbital Flare Call', cardType: 'Tactic', subtype: 'Orbital Strike', type: 'tactic', wheat: 5, iron: 6, tags: ['experimental', 'explosive', 'swing'], text: 'Deal explosive 8 to target cell.', tactic: { kind: 'blast-cell', amount: 8 } },
    { key: 'breach-tunnel', name: 'Breach Tunnel', cardType: 'Tactic', subtype: 'Mobility', type: 'tactic', wheat: 4, iron: 4, tags: ['experimental', 'mobility', 'capture'], text: 'Move up to two allied units 1 cell each.', captureRelevant: true, tactic: { kind: 'capture-boost' } },
  ];
  experimentalDeckPatterns.forEach((pattern) => {
    productionMk.forEach((mk, idx) => {
      const id = `cq-exp-${pattern.key}-${idx + 1}`;
      experimentalDeckIds.push(id);
      cards.push(card({
        id,
        name: `${pattern.name} ${mk}`,
        sourceBuilding: 'experimental',
        cardType: pattern.cardType,
        subtype: pattern.subtype,
        type: pattern.type,
        structure: !!pattern.structure,
        barricade: !!pattern.barricade,
        fortified: !!pattern.fortified,
        upgradeSchematic: !!pattern.upgradeSchematic,
        captureRelevant: !!pattern.captureRelevant,
        wheatCost: pattern.wheat + (idx >= 2 ? 1 : 0),
        ironCost: pattern.iron + idx,
        attack: (pattern.atk ?? 0) + (pattern.cardType === 'Unit' && idx === 2 ? 1 : 0),
        health: (pattern.hp ?? 0) + (pattern.cardType !== 'Tactic' ? idx : 0),
        defense: (pattern.def ?? 0) + (pattern.cardType !== 'Tactic' && idx === 2 ? 1 : 0),
        range: pattern.range ?? 1,
        siege: pattern.siege ?? 0,
        large: pattern.cardType === 'Unit' && idx === 2,
        text: pattern.text,
        tags: [...pattern.tags, 'experimental-deck'],
        tactic: pattern.tactic ? { ...pattern.tactic } : null,
      }));
    });
  });

  const attackerStarterDeck = [
    ...rep('cq-homestead', 1),
    ...rep('cq-mana-pylon', 10),
    ...rep('cq-goblin-spearline', 4),
    ...rep('cq-riot-goblin-tribe', 4),
    ...rep('cq-bone-clad-raiders', 4),
    ...rep('cq-rift-boar-riders', 3),
    ...rep('cq-siege-gnashers', 3),
    ...rep('cq-brute-wallbreakers', 2),
    ...rep('cq-skullbow-patrol', 2),
    ...rep('cq-ashbow-regiment', 2),
    ...rep('cq-hex-drummer', 2),
    ...rep('cq-siege-caller', 2),
    ...rep('cq-carrion-bats', 3),
    ...rep('cq-rift-vulture-cloud', 2),
    ...rep('cq-skyrake-bomber', 2),
    ...rep('cq-rift-giant', 2),
    ...rep('cq-gravelung-colossus', 1),
    ...rep('cq-forced-march', 2),
    ...rep('cq-breachfire', 2),
    ...rep('cq-ruinburst-mortar', 1),
    ...rep('cq-bloodrush-signal', 1),
    ...rep('cq-pylon-surge', 1),
    ...rep('cq-wing-screen', 1),
    ...rep('cq-shock-banner', 1),
    ...rep('cq-fell-detonation', 1),
    ...rep('cq-warp-incursion', 1),
    ...rep('cq-predators-claim', 1),
  ];

  window.CONQUEST_CARD_CONTENT_V2 = {
    version: 2,
    cards,
    deckGroups: {
      defender: ['training', 'blacksmith', 'factory', 'command', 'vehicle', 'ordnance', 'air', 'power', 'recovery', 'experimental', 'utility'],
      attacker: ['pylon', 'ground', 'air', 'horde', 'giant', 'spell'],
    },
    decks: {
      training: [
        ...rep('cq-militia-recruit', 1), ...rep('cq-shieldbearer', 2), ...rep('cq-archer-cadet', 2), ...rep('cq-pike-recruit', 2), ...rep('cq-scout-runner', 2),
        ...rep('cq-combat-medic', 2), ...rep('cq-sapper-team', 2), ...rep('cq-crossbow-cell', 2), ...rep('cq-banner-captain', 2), ...rep('cq-veteran-wallguard', 2),
        ...rep('cq-stormline-marksman', 2), ...rep('cq-anti-horde-grenadier', 2), ...rep('cq-reclaimer-squad', 2), ...rep('cq-ironhorn-cavalry', 2),
        ...trainingExpansionIds.slice(0, 34),
        ...trainingOverhaulIds,
      ],
      blacksmith: [
        ...rep('cq-iron-shortsword', 1), ...rep('cq-steel-longsword', 1), ...rep('cq-spear-rack', 1), ...rep('cq-longbow-set', 1), ...rep('cq-fire-arrow-bundle', 1),
        ...rep('cq-leather-jerkin', 1), ...rep('cq-iron-mail', 1), ...rep('cq-tower-shield-harness', 1), ...rep('cq-steel-helm', 1),
        ...rep('cq-silver-turret-upgrade', 1), ...rep('cq-silver-barricade-upgrade', 1), ...rep('cq-repair-blueprint', 2), ...rep('cq-wall-brace-kit', 2),
        ...rep('cq-precision-sight-rig', 2), ...rep('cq-anti-giant-pikehead', 2),
        ...blacksmithArmourIds.slice(0, 36),
        ...blacksmithWeaponIds.slice(0, 36),
        ...blacksmithVarietyIds,
        ...blacksmithOverhaulIds,
      ],
      factory: [
        ...rep('cq-barricade', 2), ...rep('cq-turret', 2), ...rep('cq-ironclad-trooper', 2), ...rep('cq-shield-cart', 2), ...rep('cq-bombard-crew', 2),
        ...rep('cq-auto-ballista', 2), ...rep('cq-repair-drone', 2), ...rep('cq-mortar-team', 2), ...rep('cq-armoured-ram', 2), ...rep('cq-pylon-disruptor', 2),
        ...rep('cq-heavy-turret-frame', 1), ...rep('cq-reactor-assisted-turret', 1), ...rep('cq-arc-flak-nest', 1),
        ...factoryExpansionIds.slice(0, 30),
        ...factoryWarMachineIds,
      ],
      command: [
        ...rep('cq-emergency-reinforcement', 2), ...rep('cq-rush-ammunition', 2), ...rep('cq-rapid-repair-crew', 2), ...rep('cq-silver-factory-upgrade', 1),
        ...rep('cq-silver-training-upgrade', 1), ...rep('cq-silver-farm-upgrade', 1), ...rep('cq-silver-mine-upgrade', 1), ...rep('cq-fort-quavus-blueprint', 1),
        ...rep('cq-weather-beacon', 1), ...rep('cq-reserve-muster', 2), ...rep('cq-lane-fortification-order', 2), ...rep('cq-anti-air-command', 1),
        ...rep('cq-wall-patch-team', 2), ...rep('cq-foundry-overdrive', 1),
        ...facilityExpansionBuildingIds,
        ...commandExpansionIds.slice(0, 26),
        ...swingTacticIds,
      ],
      vehicle: [...vehicleDeckIds],
      ordnance: [...ordnanceDeckIds],
      air: [...airSupportDeckIds],
      power: [...powerShieldDeckIds],
      recovery: [...recoveryDeckIds],
      experimental: [...experimentalDeckIds],
      utility: ['cq-farm', 'cq-mine', 'cq-factory', 'cq-training-facility', 'cq-blacksmith', 'cq-storage', 'cq-field-hospital', 'cq-watchtower', 'cq-command-relay', ...facilityExpansionBuildingIds],
      attacker: [...attackerStarterDeck, ...attackerExpansionIds.slice(0, 34)],
    },
  };
})();
