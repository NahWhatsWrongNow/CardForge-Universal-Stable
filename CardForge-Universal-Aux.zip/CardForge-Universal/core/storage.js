const STORAGE_KEY = 'cardforge.profile.v1';
const cloneValue = typeof globalThis.structuredClone === 'function'
  ? globalThis.structuredClone.bind(globalThis)
  : (value) => JSON.parse(JSON.stringify(value));
const DEFAULT_CARD_PRESENTATION = {
  cardCount: 8,
  cardScale: 1,
  overlap: 0.5,
  fanAngle: 12,
  curvature: 20,
  hoverLift: 68,
  hoverScale: 1.18,
  animationSpeed: 0.92,
  springiness: 0.58,
  damping: 0.76,
  anchor: 'bottom-center',
  hoverSpread: 70,
  orientation: 'inward',
  presetId: 'compact-fan',
  comparePresetId: 'presentation-fan',
  compareMode: false,
  qualityPreset: 'silk',
  showGuides: false,
  showShadows: true,
  showRarityEffects: true,
  showZOrder: false,
  pinMode: true,
  settingsVersion: 3,
  styleMode: 'v3',
  textSize: 'large',
  ribbonOpacityDuel: 0,
  ribbonOpacityLocal: 0,
  ribbonOpacityConquest: 0,
};

function emptyCampaignMarketState() {
  return {
    traderFactions: {},
    relations: {},
    activeTraders: [],
    tradeShips: [],
    marketIndices: {
      global: 1,
      collections: {},
      rarities: { common: 1, rare: 1, epic: 1, legendary: 1 },
      events: { global: 1 },
      history: [],
    },
    priceHistory: {},
    collectionIndices: {},
    collectionHistory: {},
    factionTradeHistory: {},
    playerProfitHistory: [],
    relationHistory: {},
    newsFeed: [],
    incidentFeed: [],
    activeDemands: [],
    routeHeat: {},
    lastMarketTickAt: 0,
    lastDemandRotationAt: 0,
    watchedCards: [],
  };
}

const CAMPAIGN_DEFAULTS = {
  ownedDimensions: [],
  ownedWorldIds: [],
  lostWorldIds: [],
  worldStates: {},
  speciesAccess: {},
  activeThreats: [],
  supernaturalEvents: [],
  reinforcementPool: {},
  totalIncome: 0,
  lastProductionTickAt: 0,
  market: emptyCampaignMarketState(),
  diplomacy: {
    relations: {},
    transactionCounters: {},
    embargoes: {},
    flags: {},
    factionRelations: {},
    meetingHistory: [],
    incidentLog: [],
    warState: {
      disabled: true,
      playerWars: {},
      factionWars: {},
      pendingDeclarations: [],
      notifications: [],
      eventLog: [],
      alliedJoinHooks: true,
    },
  },
  tradeShips: [],
};

const MAP_WORLD_DEFAULTS = {
  createdGalaxies: [],
  customAiProfiles: [],
  nodeAssignments: {},
  gatewayIndexBySeed: {},
  mapFilters: { search: '', status: 'all', style: 'all' },
  globalMapStyleId: 'astral-cartographer',
  selectedNodeId: null,
  dimensionalAttackers: {},
  campaign: { ...CAMPAIGN_DEFAULTS },
};

const defaultStats = {
  wins: 0,
  losses: 0,
  packsOpened: 0,
  favoriteTribe: 'none',
  streak: 0,
  bestStreak: 0,
  battlesPlayed: 0,
  modes: {
    duel: { wins: 0, losses: 0, battles: 0 },
    defense: { wins: 0, losses: 0, battles: 0 },
  },
  threats: {
    pirate: { wins: 0, losses: 0, battles: 0 },
    alien: { wins: 0, losses: 0, battles: 0 },
    boss: { wins: 0, losses: 0, battles: 0 },
    wielder: { wins: 0, losses: 0, battles: 0 },
  },
  factionsFought: {},
  bossesDefeated: 0,
  namedWieldersDefeated: 0,
  worlds: { conquered: 0, lost: 0 },
  planets: { conquered: 0, lost: 0 },
  invasions: { intercepted: 0, piratesEscaped: 0 },
  packs: {
    openedTotal: 0,
    byPack: {},
    cardsByPack: {},
    uniqueByPack: {},
    rarityPulls: { common: 0, rare: 0, epic: 0, legendary: 0 },
    legendaryPulls: 0,
  },
  collectionProgress: {
    totalCopiesOwned: 0,
    uniqueOwned: 0,
  },
  decks: {
    created: 0,
    edited: 0,
  },
  battleHistory: [],
};

const defaultProfile = {
  version: 1,
  devUnlocked: false,
  settings: {
    uiScale: 1,
    reduceMotion: false,
    highContrast: false,
    colorblindOutlines: true,
    selectedBackdrop: 'nebula-board',
    selectedCardBack: 'classic-onyx',
    selectedTheme: 'arcane-night',
    cardPresentation: cloneValue(DEFAULT_CARD_PRESENTATION),
  },
  stats: cloneValue(defaultStats),
  economy: {
    gold: 400,
    lifeforce: 0,
    pityByProduct: {},
    lastDailyGiftAt: null,
    marketLedger: [],
    wishlist: [],
    watchedCards: [],
    licenses: {},
  },
  collection: {
    'river-scout': 2,
    'iron-guard': 2,
    'ember-adept': 2,
    'pack-bolt': 2,
    'frost-weaver': 2,
    'arcane-scholar': 2,
    'dune-sentinel': 2,
    'mana-surge': 2,
    'primal-charge': 2,
    'totem-caller': 2,
    'pack-howl': 2,
    'soul-lantern': 2,
    'wildfang-alpha': 2,
    'void-silence': 2,
    'tangle-warden': 2,
    'grove-guardian': 2,
    'gen3-riftway-pathfinder': 2,
    'gen3-collapse-channeler': 2,
    'gen3-arc-skein-defender': 2,
    'gen3-thread-draw': 2,
    'gen3-fault-bolt': 2,
    'gen3-emergency-mend': 2,
    'gen3-war-chorus': 2,
    'gen3-time-snag': 2,
    'gen3-voidwell-sentinel': 2,
    'gen3-reinforce-line': 2,
    'gen3-frontier-barricade': 2,
    'gen3-turret-spire': 2,
    'gen3-mana-harbor-field': 2,
    'gen3-reactor-ramp': 2,
    'gen3-supply-relay': 2,
    'gen3-recovery-grove': 2,
    'gen3-collapse-drake': 2,
    'gen3-bastion-scribe': 2,
    'gen3-guardian-mandate': 2,
    'gen3-null-tax-order': 2,
  },
  customDecks: [],
  deckFolders: ['Ranked', 'Lore Decks', 'Experiments', 'AI Bosses', 'Tournament Builds', 'Meme Decks'],
  deckRulesets: {},
  deckSnapshots: {},
  deckSearchPresets: [],
  favoriteCards: [],
  cardLastUsed: {},
  archivedDeckIds: [],
  starterDeckId: 'starter-duel-collapsed-vanguard',
  starterDefenseDeckId: 'starter-defense-frontier-phalanx',
  questProgress: {
    cardsPlayed: 0,
    packsOpened: 0,
  },
  questClaims: {},
  discoveredDimensions: [],
  defeatedAiIds: [],
  lobbyResidents: [],
  carnexCodes: {},
  capturedCards: {},
  paywallMode: false,
  customPackDefs: [],
  mapWorld: { ...MAP_WORLD_DEFAULTS },
};

export function loadProfile() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return cloneValue(defaultProfile);
    const parsed = JSON.parse(stored);
    return {
      ...cloneValue(defaultProfile),
      ...parsed,
      settings: {
        ...defaultProfile.settings,
        ...(parsed.settings ?? {}),
        cardPresentation: {
          ...DEFAULT_CARD_PRESENTATION,
          ...(parsed.settings?.cardPresentation ?? {}),
        },
      },
      stats: {
        ...defaultProfile.stats,
        ...(parsed.stats ?? {}),
        modes: { ...defaultStats.modes, ...(parsed.stats?.modes ?? {}) },
        threats: { ...defaultStats.threats, ...(parsed.stats?.threats ?? {}) },
        factionsFought: { ...(parsed.stats?.factionsFought ?? {}) },
        worlds: { ...defaultStats.worlds, ...(parsed.stats?.worlds ?? {}) },
        planets: { ...defaultStats.planets, ...(parsed.stats?.planets ?? {}) },
        invasions: { ...defaultStats.invasions, ...(parsed.stats?.invasions ?? {}) },
        packs: {
          ...defaultStats.packs,
          ...(parsed.stats?.packs ?? {}),
          byPack: { ...(parsed.stats?.packs?.byPack ?? {}) },
          cardsByPack: { ...(parsed.stats?.packs?.cardsByPack ?? {}) },
          uniqueByPack: { ...(parsed.stats?.packs?.uniqueByPack ?? {}) },
          rarityPulls: {
            ...defaultStats.packs.rarityPulls,
            ...(parsed.stats?.packs?.rarityPulls ?? {}),
          },
        },
        collectionProgress: {
          ...defaultStats.collectionProgress,
          ...(parsed.stats?.collectionProgress ?? {}),
        },
        decks: { ...defaultStats.decks, ...(parsed.stats?.decks ?? {}) },
        battleHistory: Array.isArray(parsed.stats?.battleHistory) ? parsed.stats.battleHistory : [],
      },
      economy: {
        ...defaultProfile.economy,
        ...(parsed.economy ?? {}),
        marketLedger: Array.isArray(parsed.economy?.marketLedger) ? parsed.economy.marketLedger : [],
        wishlist: Array.isArray(parsed.economy?.wishlist) ? parsed.economy.wishlist : [],
        watchedCards: Array.isArray(parsed.economy?.watchedCards) ? parsed.economy.watchedCards : [],
        licenses: parsed.economy?.licenses && typeof parsed.economy.licenses === 'object' ? parsed.economy.licenses : {},
      },
      collection: { ...defaultProfile.collection, ...(parsed.collection ?? {}) },
      customDecks: Array.isArray(parsed.customDecks) ? parsed.customDecks : [],
      deckFolders: Array.isArray(parsed.deckFolders) ? parsed.deckFolders : [...defaultProfile.deckFolders],
      deckRulesets: { ...defaultProfile.deckRulesets, ...(parsed.deckRulesets ?? {}) },
      deckSnapshots: { ...defaultProfile.deckSnapshots, ...(parsed.deckSnapshots ?? {}) },
      deckSearchPresets: Array.isArray(parsed.deckSearchPresets) ? parsed.deckSearchPresets : [],
      favoriteCards: Array.isArray(parsed.favoriteCards) ? parsed.favoriteCards : [],
      cardLastUsed: { ...defaultProfile.cardLastUsed, ...(parsed.cardLastUsed ?? {}) },
      archivedDeckIds: Array.isArray(parsed.archivedDeckIds) ? parsed.archivedDeckIds : [],
      starterDeckId: parsed.starterDeckId || defaultProfile.starterDeckId,
      starterDefenseDeckId: parsed.starterDefenseDeckId || parsed.starterDeckId || defaultProfile.starterDefenseDeckId,
      questProgress: { ...defaultProfile.questProgress, ...(parsed.questProgress ?? {}) },
      questClaims: { ...defaultProfile.questClaims, ...(parsed.questClaims ?? {}) },
      discoveredDimensions: [...new Set([...(defaultProfile.discoveredDimensions ?? []), ...((parsed.discoveredDimensions) ?? [])])],
      defeatedAiIds: [...new Set([...(defaultProfile.defeatedAiIds ?? []), ...((parsed.defeatedAiIds) ?? [])])],
      lobbyResidents: [...new Set([...(defaultProfile.lobbyResidents ?? []), ...((parsed.lobbyResidents) ?? [])])],
      carnexCodes: { ...defaultProfile.carnexCodes, ...(parsed.carnexCodes ?? {}) },
      capturedCards: { ...defaultProfile.capturedCards, ...(parsed.capturedCards ?? {}) },
      paywallMode: !!parsed.paywallMode,
      customPackDefs: Array.isArray(parsed.customPackDefs) ? parsed.customPackDefs : [],
      mapWorld: {
        ...MAP_WORLD_DEFAULTS,
        ...(parsed.mapWorld ?? {}),
        mapFilters: {
          ...MAP_WORLD_DEFAULTS.mapFilters,
          ...(parsed.mapWorld?.mapFilters ?? {}),
        },
        campaign: {
          ...CAMPAIGN_DEFAULTS,
          ...(parsed.mapWorld?.campaign ?? {}),
          worldStates: { ...(parsed.mapWorld?.campaign?.worldStates ?? {}) },
          speciesAccess: { ...(parsed.mapWorld?.campaign?.speciesAccess ?? {}) },
          reinforcementPool: { ...(parsed.mapWorld?.campaign?.reinforcementPool ?? {}) },
          activeThreats: Array.isArray(parsed.mapWorld?.campaign?.activeThreats) ? parsed.mapWorld.campaign.activeThreats : [],
          supernaturalEvents: Array.isArray(parsed.mapWorld?.campaign?.supernaturalEvents) ? parsed.mapWorld.campaign.supernaturalEvents : [],
          ownedDimensions: Array.isArray(parsed.mapWorld?.campaign?.ownedDimensions) ? parsed.mapWorld.campaign.ownedDimensions : [],
          ownedWorldIds: Array.isArray(parsed.mapWorld?.campaign?.ownedWorldIds) ? parsed.mapWorld.campaign.ownedWorldIds : [],
          lostWorldIds: Array.isArray(parsed.mapWorld?.campaign?.lostWorldIds) ? parsed.mapWorld.campaign.lostWorldIds : [],
          market: {
            ...emptyCampaignMarketState(),
            ...(parsed.mapWorld?.campaign?.market ?? {}),
            marketIndices: {
              ...emptyCampaignMarketState().marketIndices,
              ...(parsed.mapWorld?.campaign?.market?.marketIndices ?? {}),
              rarities: {
                ...emptyCampaignMarketState().marketIndices.rarities,
                ...(parsed.mapWorld?.campaign?.market?.marketIndices?.rarities ?? {}),
              },
              events: {
                ...emptyCampaignMarketState().marketIndices.events,
                ...(parsed.mapWorld?.campaign?.market?.marketIndices?.events ?? {}),
              },
              history: Array.isArray(parsed.mapWorld?.campaign?.market?.marketIndices?.history) ? parsed.mapWorld.campaign.market.marketIndices.history : [],
            },
            priceHistory: { ...(parsed.mapWorld?.campaign?.market?.priceHistory ?? {}) },
            collectionIndices: { ...(parsed.mapWorld?.campaign?.market?.collectionIndices ?? {}) },
            collectionHistory: { ...(parsed.mapWorld?.campaign?.market?.collectionHistory ?? {}) },
            factionTradeHistory: { ...(parsed.mapWorld?.campaign?.market?.factionTradeHistory ?? {}) },
            playerProfitHistory: Array.isArray(parsed.mapWorld?.campaign?.market?.playerProfitHistory) ? parsed.mapWorld.campaign.market.playerProfitHistory : [],
            relationHistory: { ...(parsed.mapWorld?.campaign?.market?.relationHistory ?? {}) },
            newsFeed: Array.isArray(parsed.mapWorld?.campaign?.market?.newsFeed) ? parsed.mapWorld.campaign.market.newsFeed : [],
            incidentFeed: Array.isArray(parsed.mapWorld?.campaign?.market?.incidentFeed) ? parsed.mapWorld.campaign.market.incidentFeed : [],
            activeDemands: Array.isArray(parsed.mapWorld?.campaign?.market?.activeDemands) ? parsed.mapWorld.campaign.market.activeDemands : [],
            tradeShips: Array.isArray(parsed.mapWorld?.campaign?.market?.tradeShips) ? parsed.mapWorld.campaign.market.tradeShips : [],
          },
          diplomacy: {
            relations: { ...(parsed.mapWorld?.campaign?.diplomacy?.relations ?? {}) },
            transactionCounters: { ...(parsed.mapWorld?.campaign?.diplomacy?.transactionCounters ?? {}) },
            embargoes: { ...(parsed.mapWorld?.campaign?.diplomacy?.embargoes ?? {}) },
            flags: { ...(parsed.mapWorld?.campaign?.diplomacy?.flags ?? {}) },
            factionRelations: { ...(parsed.mapWorld?.campaign?.diplomacy?.factionRelations ?? {}) },
            meetingHistory: Array.isArray(parsed.mapWorld?.campaign?.diplomacy?.meetingHistory) ? parsed.mapWorld.campaign.diplomacy.meetingHistory : [],
            incidentLog: Array.isArray(parsed.mapWorld?.campaign?.diplomacy?.incidentLog) ? parsed.mapWorld.campaign.diplomacy.incidentLog : [],
            warState: {
              ...cloneValue(CAMPAIGN_DEFAULTS.diplomacy.warState),
              ...(parsed.mapWorld?.campaign?.diplomacy?.warState ?? {}),
              playerWars: { ...(parsed.mapWorld?.campaign?.diplomacy?.warState?.playerWars ?? {}) },
              factionWars: { ...(parsed.mapWorld?.campaign?.diplomacy?.warState?.factionWars ?? {}) },
              pendingDeclarations: Array.isArray(parsed.mapWorld?.campaign?.diplomacy?.warState?.pendingDeclarations) ? parsed.mapWorld.campaign.diplomacy.warState.pendingDeclarations : [],
              notifications: Array.isArray(parsed.mapWorld?.campaign?.diplomacy?.warState?.notifications) ? parsed.mapWorld.campaign.diplomacy.warState.notifications : [],
              eventLog: Array.isArray(parsed.mapWorld?.campaign?.diplomacy?.warState?.eventLog) ? parsed.mapWorld.campaign.diplomacy.warState.eventLog : [],
            },
          },
          tradeShips: Array.isArray(parsed.mapWorld?.campaign?.tradeShips) ? parsed.mapWorld.campaign.tradeShips : [],
        },
      },
    };
  } catch {
    return cloneValue(defaultProfile);
  }
}

export function saveProfile(profile) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
}

export function resetProfile() {
  localStorage.removeItem(STORAGE_KEY);
  return cloneValue(defaultProfile);
}

export function setDevUnlocked(unlocked) {
  const profile = loadProfile();
  profile.devUnlocked = unlocked;
  saveProfile(profile);
  return profile;
}
