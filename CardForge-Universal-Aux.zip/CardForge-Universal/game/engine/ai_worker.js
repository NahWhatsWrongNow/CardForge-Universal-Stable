import { chooseTurnPlan, getPlannerDebug, restorePlannerMemory } from './ai.js';
self.onmessage = ({ data }) => {
  const requestId = Number(data?.requestId ?? 0);
  if (data?.type === 'warmup') {
    self.postMessage({ requestId, ready: true });
    return;
  }
  try {
    restorePlannerMemory(data.profile?.id ?? data.profile?.name, data.memory);
    const plan = chooseTurnPlan(data.state, data.profile);
    self.postMessage({ requestId, plan, debug: getPlannerDebug(data.profile?.id ?? data.profile?.name) });
  } catch (error) {
    self.postMessage({ requestId, error: String(error?.message || error) });
  }
};
