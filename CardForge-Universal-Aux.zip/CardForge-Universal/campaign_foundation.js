(function bootstrapFoundationCampaign() {
  'use strict';

  const FOUNDATION_KEY = 'cardforge.foundation.campaign.v1';
  const PROFILE_KEY = 'cardforge.profile.v1';
  const MATCH_KEY = 'cardforge.match.opponent.v1';
  const MATCH_CONTEXT_KEY = 'cardforge.match.context.v1';
  const MATCH_RESULT_KEY = 'cardforge.match.result.v1';

  const VAULTS = [
    { id: 'lumen', name: 'LUMEN', shard: 'The Bastion of Sol', archiveId: 'lumen-bastion-sol', colors: ['#fff3b0', '#d6a53b'], complexity: 2, aggression: 2, defense: 5, style: ['Protection', 'Formation', 'Healing', 'Efficient units'], mechanics: ['Shield', 'Guard', 'Consecrate'] },
    { id: 'pyre', name: 'PYRE', shard: 'The Cinder Maw', archiveId: 'pyre-cinder-maw', colors: ['#ffb04a', '#c93120'], complexity: 2, aggression: 5, defense: 1, style: ['Aggression', 'Rush', 'Damage', 'Explosive turns'], mechanics: ['Rush', 'Burn', 'Bloodied'] },
    { id: 'umbra', name: 'UMBRA', shard: 'The Grave of Whispers', archiveId: 'umbra-grave-whispers', colors: ['#b984ff', '#35154f'], complexity: 4, aggression: 2, defense: 3, style: ['Sacrifice', 'Graveyard value', 'Control', 'Forbidden bargains'], mechanics: ['Ruin', 'Return', 'Corruption'] },
    { id: 'verdant', name: 'VERDANT', shard: 'The Worldroot Choir', archiveId: 'verdant-worldroot-choir', colors: ['#78e6a2', '#176b56'], complexity: 3, aggression: 3, defense: 4, style: ['Growth', 'Tokens', 'Healing', 'Living formations'], mechanics: ['Rooted', 'Bloom', 'Pack'] },
    { id: 'aether', name: 'AETHER', shard: 'The Glass Horizon', archiveId: 'aether-glass-horizon', colors: ['#8be8ff', '#2863bd'], complexity: 5, aggression: 3, defense: 2, style: ['Tempo', 'Repositioning', 'Prediction', 'Precision'], mechanics: ['Quick', 'Inspect', 'Phase'] },
  ];

  const STORY_OPERATIONS = {
    'glasswake-evacuation': {
      opponentId: 'glasswake-scavengers',
      rulesetName: 'Evacuation at Glasswake',
      aiSkillStars: 2,
      winNode: 'act1-glasswake-victory-1',
      lossNode: 'act1-glasswake-loss-1',
      rewardGold: 90,
      objective: 'Protect the evacuation route for 6 rounds or defeat the strip crew.',
      missionObjective: {
        type: 'survive-rounds',
        id: 'glasswake-evacuation-route',
        label: 'Evacuation Route',
        description: 'Keep the route open through 6 completed enemy turns.',
        targetRounds: 6,
      },
    },
    'veyr-formal-convergence': {
      opponentId: 'veyr',
      rulesetName: 'Accord Evidentiary Convergence',
      aiSkillStars: 3,
      winNode: 'act1-veyr-victory-1',
      lossNode: 'act1-veyr-loss-1',
      rewardGold: 45,
      objective: 'Establish standing before the Meridian surveyor.',
    },
    'relay-nine-recovery': {
      opponentId: 'relay-nine',
      rulesetName: 'Relay Nine Archive Breach',
      aiSkillStars: 3,
      winNode: 'act1-relay-victory-1',
      lossNode: 'act1-relay-loss-1',
      rewardGold: 70,
      objective: 'Disable the custodian array and recover Rook\'s erased record.',
    },
    'red-wake-anchorage-duel': {
      opponentId: 'agony',
      rulesetName: 'Red Wake Anchorage Convergence',
      aiSkillStars: 3,
      winNode: 'act1-anchorage-victory-1',
      lossNode: 'act1-anchorage-loss-1',
      rewardGold: 80,
      objective: 'Force Agony to release the remaining contract record.',
    },
  };

  const OPENING = [
    { kind: 'void', line: 'Before you had a name, something was already dying.', sub: 'Not a man. Not a world. Something much larger.' },
    { kind: 'fracture', line: 'And in the final moment of its failure...', sub: '...it reached for you.' },
    { kind: 'rook', speaker: 'ROOK', line: 'You actually answered.', sub: 'No. That is not right. You did not answer. You did not even exist.' },
  ];

  let contentPromise = null;
  let currentOpening = 0;
  let history = [];

  function loadState() {
    try {
      const parsed = JSON.parse(localStorage.getItem(FOUNDATION_KEY) || 'null');
      return parsed && typeof parsed === 'object' ? parsed : null;
    } catch {
      return null;
    }
  }

  function saveState(next) {
    localStorage.setItem(FOUNDATION_KEY, JSON.stringify({ version: 1, updatedAt: Date.now(), ...next }));
    return next;
  }

  function readProfile() {
    try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || '{}') || {}; } catch { return {}; }
  }

  function saveProfile(profile) {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  }

  function readResult() {
    try { return JSON.parse(localStorage.getItem(MATCH_RESULT_KEY) || 'null'); } catch { return null; }
  }

  function clearResult() {
    localStorage.removeItem(MATCH_RESULT_KEY);
  }

  async function loadContent() {
    if (!contentPromise) {
      contentPromise = Promise.all([
        fetch('./packs/concordant_foundations.json').then((response) => response.json()),
        fetch('./game/deck_packs/concordant_archives.json').then((response) => response.json()),
      ]).then(([pack, archives]) => ({ cards: pack.cards || [], archives: archives.decks || [] }));
    }
    return contentPromise;
  }

  function ensureHost() {
    let host = document.getElementById('foundation-campaign');
    if (host) return host;
    host = document.createElement('section');
    host.id = 'foundation-campaign';
    host.className = 'foundation-campaign hidden';
    host.innerHTML = '<div class="foundation-backdrop"></div><div class="foundation-stage"></div>';
    document.body.appendChild(host);
    return host;
  }

  function openHost(theme = 'void') {
    const host = ensureHost();
    if (window.location.hash.startsWith('#/command')) {
      window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}`);
    }
    window.CardForgeCommandCenter?.close?.({ setLobbyHash: false });
    host.className = `foundation-campaign theme-${theme}`;
    document.body.classList.add('foundation-active');
    document.getElementById('main-menu-screen')?.classList.add('hidden');
    return host.querySelector('.foundation-stage');
  }

  function closeHost() {
    ensureHost().classList.add('hidden');
    document.body.classList.remove('foundation-active');
  }

  function stars(value) {
    return `${'*'.repeat(value)}${'.'.repeat(5 - value)}`;
  }

  function portraitMarkup(character, side = 'left', label = '') {
    const id = String(character ?? '').toLowerCase();
    const url = window.CardForgeCardPresentation?.characterPortrait?.(id)
      || (id === 'agony' ? window.CardForgeConcordanceAssets?.agonyPortrait : window.CardForgeConcordanceAssets?.rookPortrait)
      || '';
    if (!url) return '';
    return `<figure class="foundation-portrait ${id} side-${side}"><img src="${url}" alt="${label || character}" /><span>${label || character}</span></figure>`;
  }

  function controls(primaryLabel = 'Continue') {
    return `<div class="foundation-controls"><button type="button" data-foundation-history>History</button><button type="button" data-foundation-skip>Skip</button><button type="button" class="primary" data-foundation-continue>${primaryLabel}</button></div>`;
  }

  function bindSceneControls(onContinue, onSkip = null) {
    const host = ensureHost();
    host.querySelector('[data-foundation-continue]')?.addEventListener('click', onContinue);
    host.querySelector('[data-foundation-skip]')?.addEventListener('click', onSkip || onContinue);
    host.querySelector('[data-foundation-history]')?.addEventListener('click', () => {
      const log = host.querySelector('.foundation-history');
      if (!log) return;
      log.classList.toggle('hidden');
    });
  }

  function renderOpening(index = 0) {
    currentOpening = Math.max(0, Math.min(OPENING.length - 1, index));
    const scene = OPENING[currentOpening];
    history.push(`${scene.speaker ? `${scene.speaker}: ` : ''}${scene.line} ${scene.sub || ''}`.trim());
    const stage = openHost(scene.kind);
    stage.innerHTML = `
      <div class="foundation-fracture" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
      ${scene.kind === 'rook' ? portraitMarkup('rook', 'left', 'Rook · Last Warden') : ''}
      <article class="foundation-dialogue ${scene.speaker ? 'has-speaker' : ''}">
        ${scene.speaker ? `<div class="foundation-speaker">${scene.speaker}<small>LAST WARDEN OF THE BASTION</small></div>` : ''}
        <p class="foundation-line">${scene.line}</p>
        <p class="foundation-subline">${scene.sub || ''}</p>
        ${controls(currentOpening === OPENING.length - 1 ? 'Answer Rook' : 'Continue')}
      </article>
      <aside class="foundation-history hidden"><strong>Scene History</strong>${history.map((line) => `<p>${line}</p>`).join('')}</aside>`;
    bindSceneControls(() => {
      if (currentOpening < OPENING.length - 1) renderOpening(currentOpening + 1);
      else renderFirstResponse();
    }, () => renderFirstResponse());
  }

  function renderFirstResponse() {
    const stage = openHost('rook');
    stage.innerHTML = `
      ${portraitMarkup('rook', 'left', 'Rook · Last Warden')}
      <article class="foundation-dialogue has-speaker">
        <div class="foundation-speaker">ROOK<small>LAST WARDEN OF THE BASTION</small></div>
        <p class="foundation-line">I reached beyond every surviving Shard I possessed. Past the dead ones. Past places even I was afraid to touch.</p>
        <p class="foundation-subline">And something reached back.</p>
        <div class="foundation-responses">
          ${['Where am I?', 'What are you?', 'What am I?', 'Remain silent.'].map((line, index) => `<button type="button" data-foundation-response="${index}">${line}</button>`).join('')}
        </div>
      </article>`;
    stage.querySelectorAll('[data-foundation-response]').forEach((button) => button.addEventListener('click', () => {
      const response = Number(button.dataset.foundationResponse || 0);
      const state = loadState() || {};
      saveState({ ...state, response, phase: 'rook_briefing' });
      renderRookBriefing(response);
    }));
  }

  function renderRookBriefing(response = 0) {
    const replies = [
      'Between realities. The place where their memories can touch.',
      'A Concordant. Or what remains of one.',
      'New. Unbound. That may be the only advantage we have left.',
      'Silence is useful. It leaves room to notice what wants you dead.',
    ];
    const stage = openHost('rook');
    stage.innerHTML = `
      ${portraitMarkup('rook', 'left', 'Rook · Last Warden')}
      <article class="foundation-dialogue has-speaker">
        <div class="foundation-speaker">ROOK<small>YOUR FIRST CONCORDANT</small></div>
        <p class="foundation-line">${replies[response] || replies[0]}</p>
        <p class="foundation-subline">A universe remembers everything that has ever existed inside it. We merely learned how to ask it to remember somewhere else. Those memories are Echoes. Their decks are Echo Archives. A duel between us is a Convergence.</p>
        <div class="foundation-card-memory"><span>FRONTIER ECHO</span><b>1</b><strong>Scout Cadet</strong><small>The Last Bastion remembers.</small></div>
        ${controls('Prepare the Convergence')}
      </article>`;
    bindSceneControls(renderRookBattlePreview, renderRookBattlePreview);
  }

  function renderRookBattlePreview() {
    saveState({ ...(loadState() || {}), phase: 'rook_tutorial' });
    const stage = openHost('rook');
    stage.innerHTML = `
      <article class="foundation-briefing">
        <span class="foundation-kicker">TEACHING CONVERGENCE</span>
        <h1>ROOK</h1><h2>THE LAST WARDEN</h2>
        <div class="foundation-briefing-grid">
          <div><strong>Difficulty</strong><span>*....</span></div>
          <div><strong>Echo Archive</strong><span>Rook's Last Lesson</span></div>
          <div><strong>Battlefield</strong><span>Broken Anchorage</span></div>
          <div><strong>Rules</strong><span>100 Echoes · 25 designs × 4</span></div>
        </div>
        <p>Rook uses the same mana, legal actions, hidden information, and Expanse rules as you. He will teach through contextual play rather than scripted cheats.</p>
        <div class="foundation-actions"><button type="button" data-foundation-back>Hear Rook Again</button><button type="button" class="primary" data-foundation-launch-rook>Begin Convergence</button></div>
      </article>`;
    stage.querySelector('[data-foundation-back]')?.addEventListener('click', () => renderRookBriefing(loadState()?.response || 0));
    stage.querySelector('[data-foundation-launch-rook]')?.addEventListener('click', launchRookTutorial);
  }

  function setQueuedMatch(opponentId, context) {
    localStorage.setItem(MATCH_KEY, opponentId);
    localStorage.setItem(MATCH_CONTEXT_KEY, JSON.stringify(context));
    clearResult();
  }

  function launchRookTutorial() {
    const profile = readProfile();
    // The bound Shard is the campaign's actual starting collection. Legacy
    // starter inventory must not leak into a new Concordance.
    profile.collection = {};
    profile.starterDeckId = 'rook-teaching-archive';
    saveProfile(profile);
    setQueuedMatch('rook', {
      aiProfileId: 'rook', modeModel: 'duel', battleType: 'wielder_duel', rulesetId: 'wielder-duel',
      rulesetName: 'Rook Teaching Convergence', deckSize: 100, threatDeckSize: 100, maxCopiesPerCard: 4,
      startingMana: 1, startingHand: 5, enableResponseWindows: true, aiSkillStars: 1, techLevel: 1,
      metadata: { foundationStage: 'rook_tutorial', shard: 'The Last Bastion' },
    });
    window.location.assign('./game/index.html');
  }

  async function renderVaultSelection(selectedId = null) {
    const content = await loadContent();
    saveState({ ...(loadState() || {}), phase: 'vault_selection' });
    const stage = openHost(selectedId || 'vaults');
    const selected = VAULTS.find((vault) => vault.id === selectedId) || null;
    stage.innerHTML = `
      <header class="foundation-vault-header"><span class="foundation-kicker">ROOK'S FINAL CONCORDANCE</span><h1>Choose Your First Shard</h1><p>The other four will become inaccessible until rediscovered during the campaign.</p></header>
      <div class="foundation-vault-ring ${selected ? 'has-selection' : ''}">
        ${VAULTS.map((vault) => `<button type="button" class="foundation-vault ${vault.id === selectedId ? 'selected' : ''}" style="--vault-a:${vault.colors[0]};--vault-b:${vault.colors[1]}" data-foundation-vault="${vault.id}"><i></i><strong>${vault.name}</strong><small>${vault.shard}</small><span>100 ECHOES</span></button>`).join('')}
      </div>
      ${selected ? `<article class="foundation-vault-inspect" style="--vault-a:${selected.colors[0]};--vault-b:${selected.colors[1]}">
        <button type="button" class="foundation-close-inspect" data-foundation-close-vault>Return</button>
        <span class="foundation-kicker">${selected.name}</span><h2>${selected.shard}</h2>
        <div class="foundation-vault-metrics"><div><strong>Complexity</strong>${stars(selected.complexity)}</div><div><strong>Aggression</strong>${stars(selected.aggression)}</div><div><strong>Defense</strong>${stars(selected.defense)}</div></div>
        <p><strong>Style:</strong> ${selected.style.join(' / ')}</p><p><strong>Signature mechanics:</strong> ${selected.mechanics.join(' / ')}</p>
        <div class="foundation-actions"><button type="button" data-foundation-inspect-cards>Inspect all 25 designs</button><button type="button" class="primary" data-foundation-bind="${selected.id}">Bind This Shard</button></div>
        <div class="foundation-card-list hidden" data-foundation-card-list></div>
      </article>` : ''}
      <div class="foundation-rook-final"><strong>ROOK</strong><p>Choose carefully. The first universe you call yours has a way of changing everything that follows.</p></div>`;
    stage.querySelectorAll('[data-foundation-vault]').forEach((button) => button.addEventListener('click', () => renderVaultSelection(button.dataset.foundationVault)));
    stage.querySelector('[data-foundation-close-vault]')?.addEventListener('click', () => renderVaultSelection());
    stage.querySelector('[data-foundation-inspect-cards]')?.addEventListener('click', () => {
      const list = stage.querySelector('[data-foundation-card-list]');
      const archive = content.archives.find((entry) => entry.id === selected.archiveId);
      const counts = Object.fromEntries((archive?.entries || []).map((entry) => [entry.cardId, entry.count]));
      const cards = content.cards.filter((card) => String(card.originShard).toLowerCase() === selected.shard.toLowerCase());
      list.innerHTML = cards.map((card) => `<article><b>${card.cost}</b><div><strong>${card.name}</strong><small>${card.type} ${card.attack != null ? `${card.attack}/${card.health}` : ''} / ${counts[card.id] || 0} copies</small><p>${card.text || 'No rules text.'}</p></div></article>`).join('');
      list.classList.toggle('hidden');
    });
    stage.querySelector('[data-foundation-bind]')?.addEventListener('click', () => renderBindConfirmation(selected));
  }

  function renderBindConfirmation(vault) {
    const stage = openHost(vault.id);
    stage.innerHTML = `<article class="foundation-confirm-bind" style="--vault-a:${vault.colors[0]};--vault-b:${vault.colors[1]}"><span class="foundation-kicker">FINAL STABILIZATION</span><h1>Bind yourself to ${vault.shard}?</h1><p>Rook's remaining Concordance can stabilize only one Shard. The other four will become inaccessible until rediscovered during the campaign.</p><div class="foundation-actions"><button type="button" data-foundation-return-vault>Return</button><button type="button" class="primary" data-foundation-confirm-bind>Bind</button></div></article>`;
    stage.querySelector('[data-foundation-return-vault]')?.addEventListener('click', () => renderVaultSelection(vault.id));
    stage.querySelector('[data-foundation-confirm-bind]')?.addEventListener('click', () => bindVault(vault));
  }

  async function bindVault(vault) {
    const content = await loadContent();
    const archive = content.archives.find((entry) => entry.id === vault.archiveId);
    const profile = readProfile();
    // A Concordance begins from the chosen Vault alone. Do not merge in the
    // launcher's legacy starter collection.
    profile.collection = {};
    (archive?.entries || []).forEach((entry) => { profile.collection[entry.cardId] = Math.max(Number(profile.collection[entry.cardId] || 0), Number(entry.count || 0)); });
    profile.starterDeckId = vault.archiveId;
    profile.starterDefenseDeckId = vault.archiveId;
    profile.discoveredDimensions = [...new Set([...(profile.discoveredDimensions || []), 'The Last Bastion', vault.shard])];
    profile.mapWorld = profile.mapWorld || {};
    profile.mapWorld.campaign = profile.mapWorld.campaign || {};
    profile.mapWorld.campaign.ownedDimensions = [...new Set([...(profile.mapWorld.campaign.ownedDimensions || []), 'The Last Bastion', vault.shard])];
    profile.mapWorld.campaign.foundation = { starterVaultId: vault.id, boundShard: vault.shard, playerTitle: 'The Unbound Concordant', rookInherited: true };
    saveProfile(profile);
    saveState({ ...(loadState() || {}), phase: 'bastion_inheritance', starterVaultId: vault.id, boundShard: vault.shard });
    renderBastionInheritance(vault);
  }

  function renderBastionInheritance(vault) {
    const stage = openHost(vault.id);
    stage.innerHTML = `<div class="foundation-bind-burst" style="--vault-a:${vault.colors[0]};--vault-b:${vault.colors[1]}">${Array.from({ length: 18 }, (_, index) => `<i style="--i:${index}"></i>`).join('')}</div><article class="foundation-dialogue has-speaker"><div class="foundation-speaker">ROOK<small>CONCORDANCE TRANSFER</small></div><p class="foundation-line">Good. Much better than I expected.</p><p class="foundation-subline">The Last Bastion is yours now. So is the attention it attracts. Do not spend everything simply because you can.</p>${controls('Inherit the Last Bastion')}</article>`;
    bindSceneControls(renderAgonyArrival, renderAgonyArrival);
  }

  function renderAgonyArrival() {
    saveState({ ...(loadState() || {}), phase: 'agony_briefing' });
    const stage = openHost('agony');
    stage.innerHTML = `<div class="foundation-agony-rift"><i></i></div>${portraitMarkup('agony', 'right', 'Agony · Red Raider')}<article class="foundation-dialogue has-speaker agony-dialogue"><div class="foundation-speaker">AGONY<small>THE RED RAIDER</small></div><p class="foundation-line">Let us see what he left me.</p><p class="foundation-subline">A hostile Concordance tears sideways through the Last Bastion. Rook is gone. Its defense belongs to you.</p>${controls('Review Threat')}</article>`;
    bindSceneControls(renderAgonyPreview, renderAgonyPreview);
  }

  function renderAgonyPreview() {
    const stage = openHost('agony');
    stage.innerHTML = `${portraitMarkup('agony', 'right', 'Agony · Red Raider')}<article class="foundation-briefing agony-briefing"><span class="foundation-kicker">HOSTILE CONVERGENCE</span><h1>AGONY</h1><h2>THE RED RAIDER</h2><div class="foundation-briefing-grid"><div><strong>Difficulty</strong><span>**...</span></div><div><strong>Echo Archive</strong><span>The Red Wake</span></div><div><strong>Known traits</strong><span>Aggressive / self-damage / Plunder</span></div><div><strong>Battlefield</strong><span>Fractured Anchorage</span></div></div><p>Agony sequences damaged-unit effects, accepts calculated self-harm, and takes risks. She receives no hidden information, free Echoes, or extra mana.</p><div class="foundation-actions"><button type="button" data-foundation-review-vault>Review Bound Archive</button><button type="button" class="primary" data-foundation-launch-agony>Begin Convergence</button></div></article>`;
    stage.querySelector('[data-foundation-review-vault]')?.addEventListener('click', () => renderVaultSelection(loadState()?.starterVaultId));
    stage.querySelector('[data-foundation-launch-agony]')?.addEventListener('click', launchAgonyBattle);
  }

  function launchAgonyBattle() {
    saveState({ ...(loadState() || {}), phase: 'agony_convergence' });
    setQueuedMatch('agony', {
      aiProfileId: 'agony', modeModel: 'duel', battleType: 'wielder_duel', rulesetId: 'wielder-duel',
      rulesetName: 'The Red Wake Assault', deckSize: 100, threatDeckSize: 100, maxCopiesPerCard: 4,
      startingMana: 1, startingHand: 5, enableResponseWindows: true, aiSkillStars: 2, techLevel: 1,
      metadata: { foundationStage: 'agony_convergence', shard: 'The Last Bastion', threatType: 'wielder' },
    });
    window.location.assign('./game/index.html');
  }

  function storyOperations(profile) {
    profile.mapWorld = profile.mapWorld || {};
    profile.mapWorld.campaign = profile.mapWorld.campaign || {};
    profile.mapWorld.campaign.operations = Array.isArray(profile.mapWorld.campaign.operations)
      ? profile.mapWorld.campaign.operations
      : [];
    return profile.mapWorld.campaign.operations;
  }

  function launchOperation(operationId) {
    const config = STORY_OPERATIONS[operationId];
    if (!config) return false;
    const profile = readProfile();
    const operations = storyOperations(profile);
    const operation = operations.find((entry) => entry.id === operationId);
    if (!operation || operation.status === 'completed') return false;
    operation.status = 'active';
    operation.startedAt = Date.now();
    saveProfile(profile);
    saveState({ ...(loadState() || {}), phase: `story_operation:${operationId}`, activeOperationId: operationId });
    setQueuedMatch(config.opponentId, {
      aiProfileId: config.opponentId,
      modeModel: 'duel',
      battleType: 'wielder_duel',
      rulesetId: 'wielder-duel',
      rulesetName: config.rulesetName,
      deckSize: 100,
      threatDeckSize: 100,
      maxCopiesPerCard: 4,
      startingMana: 1,
      startingHand: 5,
      enableResponseWindows: true,
      aiSkillStars: config.aiSkillStars,
      techLevel: Math.max(1, config.aiSkillStars - 1),
      metadata: {
        foundationStage: 'story_operation',
        operationId,
        objective: config.objective,
        threatType: operationId === 'relay-nine-recovery' ? 'automated-defense' : 'wielder',
        missionObjective: config.missionObjective ?? null,
      },
    });
    window.location.assign('./game/index.html');
    return true;
  }

  function renderStoryOperationResult(result) {
    const operationId = String(result?.metadata?.operationId || loadState()?.activeOperationId || '');
    const config = STORY_OPERATIONS[operationId];
    if (!config) return false;
    const won = String(result?.result).toLowerCase() === 'win';
    const profile = readProfile();
    const operations = storyOperations(profile);
    const operation = operations.find((entry) => entry.id === operationId);
    if (operation) {
      operation.status = won ? 'completed' : 'available';
      operation.lastResult = won ? 'win' : 'loss';
      operation.lastBattleAt = Date.now();
      if (won && !operation.rewardClaimed) {
        profile.economy = profile.economy || {};
        profile.economy.gold = Math.max(0, Number(profile.economy.gold || 0) + Number(config.rewardGold || 0));
        operation.rewardClaimed = true;
      }
    }
    profile.mapWorld.campaign.eventHistory = Array.isArray(profile.mapWorld.campaign.eventHistory)
      ? profile.mapWorld.campaign.eventHistory
      : [];
    profile.mapWorld.campaign.eventHistory.push({
      turn: profile.mapWorld.campaign.commandCenter?.turn || 1,
      severity: won ? 'completed' : 'warning',
      text: `${config.rulesetName}: ${won ? 'operation completed' : 'force repelled; operation remains available'}.`,
      operationId,
    });
    profile.mapWorld.campaign.eventHistory = profile.mapWorld.campaign.eventHistory.slice(-80);
    saveProfile(profile);
    saveState({ ...(loadState() || {}), phase: 'campaign', activeOperationId: null, lastOperationId: operationId, lastOperationResult: won ? 'win' : 'loss' });
    closeHost();
    window.CardForgeNarrativeEngine?.start?.(won ? config.winNode : config.lossNode);
    return true;
  }

  function renderAfterBattle(result, opponentId) {
    if (result?.metadata?.foundationStage === 'story_operation') return renderStoryOperationResult(result);
    const won = String(result?.result).toLowerCase() === 'win';
    const stage = openHost(opponentId === 'agony' ? 'agony' : 'rook');
    if (opponentId === 'rook') {
      if (!won) {
        stage.innerHTML = `<article class="foundation-briefing"><span class="foundation-kicker">TEACHING CONVERGENCE</span><h1>Regroup</h1><p>Rook ends the exercise before your Concordance collapses.</p><blockquote>"Again. This time, keep enough mana to answer me."</blockquote><div class="foundation-actions"><button type="button" data-foundation-retry-rook>Retry Convergence</button></div></article>`;
        stage.querySelector('[data-foundation-retry-rook]')?.addEventListener('click', launchRookTutorial);
        return;
      }
      saveState({ ...(loadState() || {}), phase: 'vault_selection', rookDefeated: true });
      renderVaultSelection();
      return;
    }
    const state = saveState({ ...(loadState() || {}), phase: 'campaign', agonyOutcome: won ? 'repelled' : 'bastion-scarred' });
    const profile = readProfile();
    profile.mapWorld = profile.mapWorld || {};
    profile.mapWorld.campaign = profile.mapWorld.campaign || {};
    profile.mapWorld.campaign.foundation = { ...(profile.mapWorld.campaign.foundation || {}), phase: 'campaign', agonyOutcome: state.agonyOutcome };
    saveProfile(profile);
    if (window.CardForgeNarrativeEngine?.start) {
      closeHost();
      window.CardForgeNarrativeEngine.start(won ? 'agony-defeat-1' : 'agony-loss-1');
      return;
    }
    stage.innerHTML = `<article class="foundation-consequence"><span class="foundation-kicker">${won ? 'CONVERGENCE WON' : 'CONVERGENCE SURVIVED'}</span><h1>${won ? 'The Last Bastion Holds' : 'The Last Bastion Is Scarred'}</h1><div class="foundation-consequence-grid"><div><strong>Shard</strong><span>Rook's Last Bastion</span></div><div><strong>Enemy</strong><span>Agony ${won ? 'retreated' : 'withdrew with spoils'}</span></div><div><strong>Recovered</strong><span>${won ? 'Rift fragments and Red Wake intelligence' : 'A damaged route and a second chance'}</span></div><div><strong>New identity</strong><span>The Unbound Concordant</span></div></div><p>Nearby space remains dark. Two unknown Shards and one hostile Concordance signal are now detectable.</p><div class="foundation-actions"><button type="button" class="primary" data-foundation-command>Enter Command Center</button></div></article>`;
    stage.querySelector('[data-foundation-command]')?.addEventListener('click', () => {
      closeHost();
      window.location.hash = '#/command';
    });
  }

  function start() {
    history = [];
    currentOpening = 0;
    window.CardForgeNarrativeEngine?.reset?.();
    saveState({ phase: 'opening', response: null, starterVaultId: null, playerTitle: 'Unbound Concordant' });
    renderOpening(0);
    return true;
  }

  function hasEstablishedCampaign() {
    const state = loadState();
    if (state?.phase === 'campaign' || String(state?.phase || '').startsWith('story_operation:')) return true;
    const profile = readProfile();
    const campaign = profile?.mapWorld?.campaign ?? {};
    const foundation = campaign.foundation ?? {};
    if (foundation.phase === 'campaign' || foundation.rookInherited || foundation.starterVaultId) return true;
    if (Array.isArray(campaign.ownedWorldIds) && campaign.ownedWorldIds.length) return true;
    if (Array.isArray(campaign.ownedDimensions) && campaign.ownedDimensions.length) return true;
    return Object.values(campaign.worldStates ?? {}).some((world) => world?.conquestUnlocked || world?.secured);
  }

  function resume() {
    const state = loadState();
    if (!state) return false;
    const result = readResult();
    if (result?.metadata?.foundationStage === 'story_operation' && String(state.phase || '').startsWith('story_operation:')) {
      clearResult();
      renderStoryOperationResult(result);
      return true;
    }
    if (result && result.metadata?.foundationStage && ['rook_tutorial', 'agony_convergence'].includes(state.phase)) {
      clearResult();
      renderAfterBattle(result, result.opponentId);
      return true;
    }
    if (state.phase === 'opening') renderOpening(0);
    else if (state.phase === 'rook_briefing') renderRookBriefing(state.response || 0);
    else if (state.phase === 'rook_tutorial') renderRookBattlePreview();
    else if (state.phase === 'vault_selection') renderVaultSelection(state.starterVaultId);
    else if (state.phase === 'bastion_inheritance') renderBastionInheritance(VAULTS.find((vault) => vault.id === state.starterVaultId) || VAULTS[0]);
    else if (state.phase === 'agony_briefing') renderAgonyPreview();
    else if (state.phase === 'agony_convergence') renderAgonyPreview();
    else return false;
    return true;
  }

  // Continue has three valid destinations: an interrupted prologue, an
  // established Command Center, or a clean prologue when no campaign exists.
  function continueCampaign() {
    if (resume()) return 'foundation';
    if (hasEstablishedCampaign()) return 'command';
    start();
    return 'foundation';
  }

  function autoResume() {
    const state = loadState();
    const result = readResult();
    if (state && result?.metadata?.foundationStage === 'story_operation' && String(state.phase || '').startsWith('story_operation:')) return resume();
    if (state && result?.metadata?.foundationStage && ['rook_tutorial', 'agony_convergence'].includes(state.phase)) return resume();
    return false;
  }

  window.addEventListener('cardforge:narrative-command', (event) => {
    if (event.detail?.action === 'launch-operation') launchOperation(event.detail.operationId);
  });

  window.CardForgeFoundationCampaign = {
    start,
    resume,
    continueCampaign,
    hasEstablishedCampaign,
    autoResume,
    launchOperation,
    state: loadState,
    vaults: VAULTS,
    storyOperations: STORY_OPERATIONS,
  };
  setTimeout(autoResume, 0);
})();
