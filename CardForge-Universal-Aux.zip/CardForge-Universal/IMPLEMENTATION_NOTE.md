# The Unbound Concordant: Runtime Audit

## Entry points

- `index.html` + `launcher.js` own the main menu, Command Center bridge, conquest map, Forge, Market, campaign navigation, and facility-war battles.
- `game/index.html` + `game/game.js` own Duel/Wielder battles, card loading, turn state, AI turns, targeting, combat, collection access, and `dev_WIP_UI` runtime labs.
- `card_presentation_shared.js` owns shared hand geometry and centralized pointer collision. `card_presentation_shared.css` owns the Premium/Legacy hand faces.
- `core/storage.js` and launcher profile helpers own persistent profile state. Foundation narrative progress uses its own versioned key and grants rewards through the profile API.

## Findings and corrections

- The Level 1 AI's cheap oversized summons came from the legacy fallback path in `drawEnemySummon`: when an authored AI Archive could not provide a usable card, `createSummon(profile)` generated a combat entity directly from profile summon ranges. That generated entity was registered as a card after creation, and its inferred cost was unrelated to the stat-generation budget. This was not a renderer problem or a single bad 10/10 definition. Authored AI Archives now use exact card instances and the same `effectiveCardCost` + `payCardCost` path as the player. The generated fallback remains identifiable in the fairness audit and is not used for Rook or Agony.
- Mana progression is centralized in `game/engine/convergence_rules.js`; permanent maximum mana is uncapped and temporary mana is tracked and spent separately.
- The hand already had centralized base-layout collision, but card presentation still duplicated markup in Duel and Conquest. The shared compositor now owns the dynamic ornate face and universal back while the existing hand controller continues to own hover, selection, and drag state.
- The tutorial manifest was an obsolete 40-card teaching subset. It is now the exact 100-card `Rook's Last Lesson` Archive: 25 canonical Frontier Doctrine designs with four copies each.
- Duel combat still contained a legacy `enemyFront` gate that made ordinary front-row units protect a commander. That rule conflicts with defender-controlled blocking and is removed in the combat update.
- The Dimensional Expanse used a hard 20-column ceiling. The capacity calculation is changed to grow by occupancy with no gameplay maximum; visual cards retain a readable floor and the board scrolls instead of shrinking indefinitely.

## Asset status

Imported unchanged under `assets/concordance/original/`:

- `rook_shattered_realms.png`
- `agony_crimson_raider.png`
- `card_back.png`
- `card_border1.png`

Web-optimized portrait, frame, and card-back derivatives are stored under `assets/concordance/derived/`. Runtime surfaces use these smaller files; the original-resolution sources remain untouched and are exposed by `CardForgeConcordanceAssets.originals`.

The filled dialogue mockup and blank dialogue template named in the master specification were not supplied and were not found in the workspace. The narrative interface therefore uses live HTML/CSS layers and the supplied portraits. No unavailable image is represented as imported.

## Compatibility boundaries

- Existing collections and saves are migrated in place; no profile reset is required.
- Local Multiplayer legality remains separate and does not gain EVO or conquest-generated cards.
- Heroes remain authored-only.
- No audio system or audio hook was added.

## Act I operation bridge

- Post-Agony campaign content is stored in `data/narrative/concordance_campaign.json` and rendered by `narrative_engine.js`. Narrative commands update the canonical profile campaign object and are idempotent, so revisiting a node cannot duplicate rewards or operations.
- Glasswake, Surveyor Veyr, Relay Nine, and the optional Red Wake Anchorage rematch are real War Council operations. `campaign_foundation.js` queues them into the existing Duel/Wielder runtime with declared 100-card Archives, AI profiles, ruleset labels, and result metadata; victory and defeat return to the appropriate narrative node.
- Glasswake and Veyr have dedicated legal 100-card Archives assembled from canonical definitions. Relay Nine uses the legal Aether Glass Horizon Archive. The shared fairness firewall remains active for all four operations.
- Glasswake adds a visible six-round Evacuation Route objective to the normal Duel runtime. Each completed enemy turn advances the stable mission counter; surviving six completes the operation, while defeating the opposing commander remains an alternate victory path. The result records the objective outcome without pretending the opposing commander was destroyed or unlocking the story AI as a normal lobby opponent.
- The bespoke Foundation prologue renderer remains in place for campaign creation, Rook's lesson, Vault selection, and Agony's first assault. NarrativeEngine owns the post-Agony Act I chain; the two paths share profile state and battle result handling rather than duplicating the battle engine.
