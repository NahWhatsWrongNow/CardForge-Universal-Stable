(function attachConcordanceAssets(global) {
  const scriptUrl = global.document?.currentScript?.src || global.location?.href || '';
  const originalRoot = new URL('./assets/concordance/original/', scriptUrl);
  const derivedRoot = new URL('./assets/concordance/derived/', scriptUrl);
  const original = (name) => new URL(name, originalRoot).href;
  const derived = (name) => new URL(name, derivedRoot).href;

  const assets = Object.freeze({
    rookPortrait: derived('rook_portrait.webp'),
    agonyPortrait: derived('agony_portrait.webp'),
    standardCardBack: derived('standard_card_back.webp'),
    universalCardFrame: derived('universal_card_frame.webp'),
    originals: Object.freeze({
      rookPortrait: original('rook_shattered_realms.png'),
      agonyPortrait: original('agony_crimson_raider.png'),
      standardCardBack: original('card_back.png'),
      universalCardFrame: original('card_border1.png'),
    }),
    dialogueMockup: null,
    dialogueTemplate: null,
  });

  const root = global.document?.documentElement;
  if (root) {
    root.style.setProperty('--cf-rook-portrait', `url("${assets.rookPortrait}")`);
    root.style.setProperty('--cf-agony-portrait', `url("${assets.agonyPortrait}")`);
    root.style.setProperty('--cf-standard-card-back', `url("${assets.standardCardBack}")`);
    root.style.setProperty('--cf-universal-card-frame', `url("${assets.universalCardFrame}")`);
  }

  global.CardForgeConcordanceAssets = assets;
})(window);
