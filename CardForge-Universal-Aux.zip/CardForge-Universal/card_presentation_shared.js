(function attachCardPresentationShared(global) {
  const deepClone = typeof global.structuredClone === 'function'
    ? global.structuredClone.bind(global)
    : (value) => JSON.parse(JSON.stringify(value));
  if (typeof global.structuredClone !== 'function') {
    global.structuredClone = deepClone;
  }

  const PRESETS = {
    'compact-fan': {
      label: 'Compact Fan',
      description: 'Balanced overlap with a centered lower grip.',
      values: { cardCount: 8, cardScale: 1, overlap: 0.5, fanAngle: 12, curvature: 20, hoverLift: 68, hoverScale: 1.18, animationSpeed: 0.92, springiness: 0.58, damping: 0.76, anchor: 'bottom-center', hoverSpread: 70, orientation: 'inward' },
    },
    'wide-fan': {
      label: 'Wide Fan',
      description: 'Opens the hand for fuller name bars and art reads.',
      values: { cardCount: 8, cardScale: 1.02, overlap: 0.34, fanAngle: 16, curvature: 24, hoverLift: 70, hoverScale: 1.2, animationSpeed: 0.96, springiness: 0.62, damping: 0.72, anchor: 'bottom-center', hoverSpread: 82, orientation: 'inward' },
    },
    'tight-stack': {
      label: 'Tight Stack',
      description: 'Dense overlap to stress hover reveal and z-order.',
      values: { cardCount: 9, cardScale: 0.98, overlap: 0.64, fanAngle: 8, curvature: 14, hoverLift: 64, hoverScale: 1.18, animationSpeed: 0.9, springiness: 0.54, damping: 0.82, anchor: 'bottom-center', hoverSpread: 62, orientation: 'inward' },
    },
    'arc-spread': {
      label: 'Arc Spread',
      description: 'More pronounced curved baseline with clean center focus.',
      values: { cardCount: 7, cardScale: 1.03, overlap: 0.41, fanAngle: 18, curvature: 30, hoverLift: 72, hoverScale: 1.2, animationSpeed: 0.94, springiness: 0.64, damping: 0.7, anchor: 'center-lower', hoverSpread: 88, orientation: 'inward' },
    },
    'deep-overlap': {
      label: 'Deep Overlap',
      description: 'Pushed close together to judge premium compression.',
      values: { cardCount: 10, cardScale: 0.96, overlap: 0.7, fanAngle: 10, curvature: 18, hoverLift: 68, hoverScale: 1.18, animationSpeed: 0.88, springiness: 0.56, damping: 0.8, anchor: 'bottom-center', hoverSpread: 76, orientation: 'inward' },
    },
    'presentation-fan': {
      label: 'Presentation Fan',
      description: 'Showcase spread with richer depth and stronger focus.',
      values: { cardCount: 6, cardScale: 1.08, overlap: 0.28, fanAngle: 14, curvature: 22, hoverLift: 78, hoverScale: 1.22, animationSpeed: 1, springiness: 0.68, damping: 0.66, anchor: 'center-lower', hoverSpread: 92, orientation: 'inward' },
    },
    'competitive-readability': {
      label: 'Competitive Readability',
      description: 'Calmer motion and wider gaps for text inspection.',
      values: { cardCount: 8, cardScale: 1, overlap: 0.25, fanAngle: 8, curvature: 12, hoverLift: 60, hoverScale: 1.22, animationSpeed: 1.06, springiness: 0.45, damping: 0.9, anchor: 'bottom-center', hoverSpread: 62, orientation: 'inward' },
    },
    'showcase-mode': {
      label: 'Showcase Mode',
      description: 'Larger cards, slower motion, more theatrical spread.',
      values: { cardCount: 5, cardScale: 1.16, overlap: 0.22, fanAngle: 11, curvature: 20, hoverLift: 84, hoverScale: 1.24, animationSpeed: 0.82, springiness: 0.74, damping: 0.62, anchor: 'center-lower', hoverSpread: 96, orientation: 'inward' },
    },
  };

  const MOTION_PRESETS = {
    silk: { label: 'Silk', animationSpeed: 0.9, springiness: 0.52, damping: 0.84 },
    spring: { label: 'Spring', animationSpeed: 1, springiness: 0.7, damping: 0.66 },
    snappy: { label: 'Snappy', animationSpeed: 1.18, springiness: 0.46, damping: 0.92 },
  };

  const ANCHORS = {
    'bottom-center': { label: 'Bottom Center', x: '50%', y: '96%' },
    'center-lower': { label: 'Center Lower', x: '50%', y: '88%' },
    left: { label: 'Left Anchor', x: '30%', y: '92%' },
    right: { label: 'Right Anchor', x: '70%', y: '92%' },
  };

  const STYLE_MODES = {
    v1: { label: 'V1 - Legacy', description: 'Original compact CSS card layout.' },
    v2: { label: 'V2 - Digital', description: 'Clean pre-image premium frame with stronger text hierarchy.' },
    v3: { label: 'V3 - Image Frame', description: 'Supplied image-frame compositor with card artwork.' },
  };

  const TEXT_SIZES = {
    compact: 'Compact',
    comfortable: 'Comfortable',
    large: 'Large',
  };

  const DEFAULTS = {
    ...deepClone(PRESETS['compact-fan'].values),
    presetId: 'compact-fan',
    comparePresetId: 'presentation-fan',
    compareMode: false,
    qualityPreset: 'silk',
    settingsVersion: 3,
    styleMode: 'v3',
    textSize: 'large',
    showGuides: false,
    showShadows: true,
    showRarityEffects: true,
    showZOrder: false,
    pinMode: true,
    ribbonOpacityDuel: 0,
    ribbonOpacityLocal: 0,
    ribbonOpacityConquest: 0,
  };

  const SAMPLE_CARDS = [
    { id: 'shared-ash-1', name: 'Ash Vow', cost: 1, rarity: 'common', frame: 'ember', type: 'Spell', role: 'Burn', chips: ['Ash', 'Tempo'], text: 'Deal 2 damage. If weather is Ash Storm, scorch again for 1.', attack: null, defense: null, health: null },
    { id: 'shared-tide-2', name: 'Tideguard Adept', cost: 3, rarity: 'rare', frame: 'tide', type: 'Unit', role: 'Guardian', chips: ['Water', 'Sentinel'], text: 'On deploy, ward the lane. Allied officers here gain +1 defense.', attack: 2, defense: 2, health: 5 },
    { id: 'shared-royal-3', name: 'Cathedral Archivist of the Last Static Choir', cost: 5, rarity: 'epic', frame: 'royal', type: 'Officer', role: 'Support', chips: ['Royal', 'Storm', 'Officer'], text: 'Attach to a backline unit. When you draw an Order, restore 2 morale to this lane.', attack: 1, defense: 3, health: 4 },
    { id: 'shared-void-4', name: 'Nullwake Diver', cost: 4, rarity: 'rare', frame: 'void', type: 'Unit', role: 'Skirmisher', chips: ['Void', 'Ambush'], text: 'Slip between lanes. Gains +2 attack the first time it becomes fully revealed.', attack: 4, defense: 1, health: 3 },
    { id: 'shared-fungal-5', name: 'Fungal Court Bloom', cost: 2, rarity: 'common', frame: 'fungal', type: 'Relic', role: 'Engine', chips: ['Fungal', 'Healing'], text: 'At turn end, heal the weakest ally for 1.', attack: null, defense: null, health: null },
    { id: 'shared-war-6', name: 'Banner Captain Helion', cost: 4, rarity: 'epic', frame: 'war', type: 'Officer', role: 'Banner', chips: ['War', 'Officer', 'Aura'], text: 'Anchor to a formation. Adjacent allies gain +1 attack.', attack: 2, defense: 2, health: 4 },
  ];

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function toNumber(value, fallback = 0) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : fallback;
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function slugify(value) {
    return String(value ?? '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'neutral';
  }

  function safeAssetUrl(value) {
    const raw = String(value ?? '').trim();
    if (!raw || /^javascript:/i.test(raw)) return '';
    try { return new URL(raw, global.location?.href ?? undefined).href; }
    catch (_) { return ''; }
  }

  function characterPortrait(characterId = '') {
    const assets = global.CardForgeConcordanceAssets ?? {};
    const id = String(characterId ?? '').toLowerCase();
    if (id.includes('agony')) return assets.agonyPortrait ?? '';
    if (id.includes('rook')) return assets.rookPortrait ?? '';
    return '';
  }

  function resolveCardArt(card = {}, options = {}) {
    const explicit = options.artUrl ?? card.artUrl ?? card.art ?? card.imageUrl ?? card.image ?? card.portrait;
    const direct = safeAssetUrl(explicit);
    if (direct) return direct;
    const type = String(card.type ?? '').toLowerCase();
    const id = `${card.id ?? ''} ${card.cardId ?? ''} ${card.name ?? ''}`.toLowerCase();
    if (/hero|commander|wielder/.test(type) || options.useCharacterArt) return characterPortrait(id);
    return '';
  }

  function normalizedChipList(value, fallback = []) {
    const source = Array.isArray(value) ? value : fallback;
    return source
      .map((entry) => typeof entry === 'string' ? { label: entry, met: true } : entry)
      .filter((entry) => String(entry?.label ?? '').trim())
      .slice(0, 5);
  }

  function cardFaceMarkup(card = {}, options = {}) {
    const shownCost = options.shownCost ?? card.cost ?? card.manaCost ?? 0;
    const canCast = options.canCast !== false;
    const rarity = String(options.rarity ?? card.rarity ?? 'common').toUpperCase();
    const typeLabel = String(options.typeLabel ?? card.type ?? 'Echo');
    const rulesText = String(options.rulesText ?? card.text ?? card.effectText ?? 'No additional rules text.');
    const artLabel = String(options.artLabel ?? card.faction ?? card.element ?? card.frame ?? 'Concordance');
    const artRole = String(options.artRole ?? card.role ?? card.subtype ?? typeLabel);
    const costNote = String(options.costNote ?? (shownCost !== (card.cost ?? shownCost) ? `Base ${card.cost ?? shownCost}` : 'Ready Cost'));
    const tags = normalizedChipList(options.tags ?? card.chips ?? card.keywords ?? card.tags, [{ label: typeLabel }]);
    const materials = normalizedChipList(options.materials, []);
    const statuses = normalizedChipList(options.statuses ?? card.statusesList ?? card.counters, []);
    const artUrl = resolveCardArt(card, options);
    const artStyle = artUrl ? ` style="background-image:url(&quot;${escapeHtml(artUrl)}&quot;)"` : '';
    const attack = options.attack ?? card.attack;
    const defense = options.defense ?? card.defense ?? card.def ?? card.baseDef;
    const health = options.health ?? card.health ?? card.hp;
    const stat = (value) => Number.isFinite(Number(value)) ? String(value) : '—';
    const tagMarkup = tags.map((chip) => `<span class="cf-hand-card-chip">${escapeHtml(chip.label)}</span>`).join('');
    const materialMarkup = materials.map((chip) => `<span class="cf-hand-card-material ${chip.met === false ? 'is-missing' : 'is-met'}">${escapeHtml(chip.label)}</span>`).join('');
    const statusMarkup = statuses.map((chip) => `<span class="cf-hand-card-status">${escapeHtml(chip.label)}</span>`).join('');
    return `
      <div class="cf-hand-card-face cf-ornate-card-face" data-frame="${escapeHtml(slugify(options.frame ?? card.frame ?? card.element ?? 'neutral'))}">
        <div class="cf-hand-card-art"${artStyle}>
          <span class="cf-hand-card-art-label">${escapeHtml(artLabel)}</span>
          <span class="cf-hand-card-art-role">${escapeHtml(artRole)}</span>
        </div>
        <div class="cf-hand-card-frame" aria-hidden="true"></div>
        <div class="cf-hand-card-header">
          <div class="cf-hand-card-title">
            <div class="cf-hand-card-name">${escapeHtml(card.name ?? 'Unnamed Echo')}</div>
          </div>
          <div class="cf-hand-card-cost ${canCast ? 'is-castable' : 'is-expensive'}">${escapeHtml(shownCost)}</div>
        </div>
        <div class="cf-hand-card-topline">
          <span class="cf-hand-card-type">${escapeHtml(typeLabel)} · ${escapeHtml(rarity)}</span>
          <span class="cf-hand-card-cost-note">${escapeHtml(costNote)}</span>
        </div>
        <div class="cf-hand-card-tags">${tagMarkup}</div>
        ${materials.length ? `<div class="cf-hand-card-materials">${materialMarkup}</div>` : ''}
        <div class="cf-hand-card-text">${escapeHtml(rulesText)}</div>
        ${statuses.length ? `<div class="cf-hand-card-statuses">${statusMarkup}</div>` : ''}
        <div class="cf-hand-card-stats">
          <span class="cf-stat cf-stat-attack"><strong>${escapeHtml(stat(attack))}</strong><small>ATK</small></span>
          <span class="cf-stat cf-stat-defense"><strong>${escapeHtml(stat(defense))}</strong><small>DEF</small></span>
          <span class="cf-stat cf-stat-health"><strong>${escapeHtml(stat(health))}</strong><small>HP</small></span>
        </div>
        <div class="cf-hand-card-footer">
          <span>${escapeHtml(options.footer ?? card.lineage ?? card.archive ?? card.collectionName ?? '')}</span>
          <span class="cf-hand-card-debug">${escapeHtml(options.debugLabel ?? '')}</span>
        </div>
      </div>`;
  }

  function cardBackMarkup(options = {}) {
    const assets = global.CardForgeConcordanceAssets ?? {};
    const image = safeAssetUrl(options.imageUrl ?? assets.standardCardBack);
    return `<div class="cf-standard-card-back"${image ? ` style="background-image:url(&quot;${escapeHtml(image)}&quot;)"` : ''} aria-label="Face-down card"></div>`;
  }

  function mergeSettings(raw) {
    const source = raw && typeof raw === 'object' ? raw : {};
    const next = { ...DEFAULTS, ...source };
    next.presetId = PRESETS[next.presetId] ? next.presetId : DEFAULTS.presetId;
    next.comparePresetId = PRESETS[next.comparePresetId] ? next.comparePresetId : DEFAULTS.comparePresetId;
    next.qualityPreset = MOTION_PRESETS[next.qualityPreset] ? next.qualityPreset : DEFAULTS.qualityPreset;
    next.anchor = ANCHORS[next.anchor] ? next.anchor : DEFAULTS.anchor;
    next.orientation = String(next.orientation ?? 'inward').toLowerCase() === 'outward' ? 'outward' : 'inward';
    const requestedStyle = String(next.styleMode ?? DEFAULTS.styleMode).toLowerCase();
    next.styleMode = requestedStyle === 'legacy'
      ? 'v1'
      : requestedStyle === 'premium'
        ? 'v3'
        : STYLE_MODES[requestedStyle]
          ? requestedStyle
          : DEFAULTS.styleMode;
    next.textSize = TEXT_SIZES[next.textSize] ? next.textSize : DEFAULTS.textSize;
    next.settingsVersion = DEFAULTS.settingsVersion;
    next.cardCount = clamp(Math.round(toNumber(next.cardCount, DEFAULTS.cardCount)), 3, 16);
    next.cardScale = clamp(toNumber(next.cardScale, DEFAULTS.cardScale), 0.82, 1.28);
    next.overlap = clamp(toNumber(next.overlap, DEFAULTS.overlap), 0.12, 0.78);
    next.fanAngle = clamp(toNumber(next.fanAngle, DEFAULTS.fanAngle), 0, 24);
    next.curvature = clamp(toNumber(next.curvature, DEFAULTS.curvature), 0, 40);
    next.hoverLift = clamp(toNumber(next.hoverLift, DEFAULTS.hoverLift), 20, 110);
    next.hoverScale = clamp(toNumber(next.hoverScale, DEFAULTS.hoverScale), 1, 1.4);
    next.animationSpeed = clamp(toNumber(next.animationSpeed, DEFAULTS.animationSpeed), 0.6, 1.35);
    next.springiness = clamp(toNumber(next.springiness, DEFAULTS.springiness), 0.1, 1);
    next.damping = clamp(toNumber(next.damping, DEFAULTS.damping), 0.3, 1);
    next.hoverSpread = clamp(toNumber(next.hoverSpread, DEFAULTS.hoverSpread), 20, 120);
    next.compareMode = !!next.compareMode;
    next.showGuides = !!next.showGuides;
    next.showShadows = next.showShadows !== false;
    next.showRarityEffects = next.showRarityEffects !== false;
    next.showZOrder = !!next.showZOrder;
    next.pinMode = next.pinMode !== false;
    next.ribbonOpacityDuel = clamp(toNumber(next.ribbonOpacityDuel, DEFAULTS.ribbonOpacityDuel), 0, 0.92);
    next.ribbonOpacityLocal = clamp(toNumber(next.ribbonOpacityLocal, DEFAULTS.ribbonOpacityLocal), 0, 0.92);
    next.ribbonOpacityConquest = clamp(toNumber(next.ribbonOpacityConquest, DEFAULTS.ribbonOpacityConquest), 0, 0.92);
    return next;
  }

  function applyPreset(settings, presetId) {
    const preset = PRESETS[presetId] ?? PRESETS[DEFAULTS.presetId];
    return mergeSettings({
      ...settings,
      ...deepClone(preset.values),
      presetId,
      orientation: settings?.orientation ?? preset.values.orientation ?? DEFAULTS.orientation,
    });
  }

  function applyMotionPreset(settings, qualityId) {
    const preset = MOTION_PRESETS[qualityId] ?? MOTION_PRESETS[DEFAULTS.qualityPreset];
    return mergeSettings({ ...settings, ...preset, qualityPreset: qualityId });
  }

  function presetOptionsMarkup(selectedId) {
    return Object.entries(PRESETS)
      .map(([id, preset]) => `<option value="${escapeHtml(id)}"${id === selectedId ? ' selected' : ''}>${escapeHtml(preset.label)}</option>`)
      .join('');
  }

  function motionButtonsMarkup(selectedId) {
    return Object.entries(MOTION_PRESETS)
      .map(([id, preset]) => `<button type="button" class="cf-card-ui-quality-btn${id === selectedId ? ' active' : ''}" data-card-ui-quality="${escapeHtml(id)}">${escapeHtml(preset.label)}</button>`)
      .join('');
  }

  function rangeControlMarkup(field, label, min, max, step, value, suffix = '') {
    return `<label class="cf-card-ui-control"><span>${escapeHtml(label)} <strong>${escapeHtml(`${value}${suffix}`)}</strong></span><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-card-ui-field="${escapeHtml(field)}" /></label>`;
  }

  function selectControlMarkup(field, label, options, selected) {
    return `<label class="cf-card-ui-control"><span>${escapeHtml(label)}</span><select data-card-ui-field="${escapeHtml(field)}">${options.map((option) => `<option value="${escapeHtml(option.value)}"${option.value === selected ? ' selected' : ''}>${escapeHtml(option.label)}</option>`).join('')}</select></label>`;
  }

  function toggleControlMarkup(field, label, checked) {
    return `<label class="cf-card-ui-toggle-row"><input type="checkbox" data-card-ui-field="${escapeHtml(field)}"${checked ? ' checked' : ''} /><span>${escapeHtml(label)}</span></label>`;
  }

  function settingsControlsMarkup(settings) {
    const safe = mergeSettings(settings);
    const anchorOptions = Object.entries(ANCHORS).map(([value, meta]) => ({ value, label: meta.label }));
    const comparePresetOptions = Object.entries(PRESETS).map(([value, preset]) => ({ value, label: preset.label }));
    const orientationOptions = [
      { value: 'inward', label: 'Arc Inward' },
      { value: 'outward', label: 'Arc Outward' },
    ];
    const styleModeOptions = Object.entries(STYLE_MODES).map(([value, meta]) => ({ value, label: meta.label }));
    const textSizeOptions = Object.entries(TEXT_SIZES).map(([value, label]) => ({ value, label }));
    return `
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>Layout</h4><p>Real hand shape, overlap, arc, and anchor tuning.</p></div>
        ${selectControlMarkup('presetId', 'Preset', comparePresetOptions, safe.presetId)}
        ${selectControlMarkup('styleMode', 'Card Face Version', styleModeOptions, safe.styleMode)}
        ${selectControlMarkup('textSize', 'Rules Text Size', textSizeOptions, safe.textSize)}
        ${selectControlMarkup('orientation', 'Arc Orientation', orientationOptions, safe.orientation)}
        ${rangeControlMarkup('cardCount', 'Preview Card Count', 3, 16, 1, Math.round(safe.cardCount))}
        ${rangeControlMarkup('cardScale', 'Card Size', 0.82, 1.28, 0.01, safe.cardScale.toFixed(2), 'x')}
        ${rangeControlMarkup('overlap', 'Overlap', 0.12, 0.78, 0.01, safe.overlap.toFixed(2))}
        ${rangeControlMarkup('fanAngle', 'Fan Angle', 0, 24, 0.5, safe.fanAngle.toFixed(1), '°')}
        ${rangeControlMarkup('curvature', 'Curvature', 0, 40, 0.5, safe.curvature.toFixed(1), 'px')}
        ${rangeControlMarkup('hoverSpread', 'Hover Spread', 20, 120, 1, Math.round(safe.hoverSpread), 'px')}
        ${selectControlMarkup('anchor', 'Anchor Position', anchorOptions, safe.anchor)}
      </section>
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>Motion</h4><p>Lift, scale, easing, and settle behavior.</p></div>
        ${rangeControlMarkup('hoverLift', 'Hover Lift', 20, 110, 1, Math.round(safe.hoverLift), 'px')}
        ${rangeControlMarkup('hoverScale', 'Hover Scale', 1, 1.4, 0.01, safe.hoverScale.toFixed(2), 'x')}
        ${rangeControlMarkup('animationSpeed', 'Animation Speed', 0.6, 1.35, 0.01, safe.animationSpeed.toFixed(2), 'x')}
        ${rangeControlMarkup('springiness', 'Springiness', 0.1, 1, 0.01, safe.springiness.toFixed(2))}
        ${rangeControlMarkup('damping', 'Damping', 0.3, 1, 0.01, safe.damping.toFixed(2))}
        <div class="cf-card-ui-quality-row"><span>Motion Feel</span><div class="cf-card-ui-quality-buttons">${motionButtonsMarkup(safe.qualityPreset)}</div></div>
      </section>
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>States & Preview</h4><p>Debug-oriented dev_WIP settings that stay available for experimentation.</p></div>
        ${toggleControlMarkup('pinMode', 'Enable pinned inspect mode', safe.pinMode)}
        ${toggleControlMarkup('showGuides', 'Show debug guides', safe.showGuides)}
        ${toggleControlMarkup('compareMode', 'Side-by-side compare mode', safe.compareMode)}
        ${toggleControlMarkup('showShadows', 'Use depth shadows', safe.showShadows)}
        ${toggleControlMarkup('showRarityEffects', 'Use rarity effects', safe.showRarityEffects)}
        ${toggleControlMarkup('showZOrder', 'Show z-order labels', safe.showZOrder)}
        ${selectControlMarkup('comparePresetId', 'Compare Preset', comparePresetOptions, safe.comparePresetId)}
      </section>
      <section class="cf-card-ui-group">
        <div class="cf-card-ui-group-head"><h4>Ribbon Transparency</h4><p>Separate hand-ribbon transparency per live mode. Zero keeps the ribbon fully transparent.</p></div>
        ${rangeControlMarkup('ribbonOpacityDuel', 'Duel / Wielder Ribbon', 0, 0.92, 0.01, safe.ribbonOpacityDuel.toFixed(2))}
        ${rangeControlMarkup('ribbonOpacityLocal', 'Local Multiplayer Ribbon', 0, 0.92, 0.01, safe.ribbonOpacityLocal.toFixed(2))}
        ${rangeControlMarkup('ribbonOpacityConquest', 'Conquest Ribbon', 0, 0.92, 0.01, safe.ribbonOpacityConquest.toFixed(2))}
      </section>`;
  }

  function parseFieldValue(field, target) {
    if (!target) return null;
    const checkboxFields = new Set(['pinMode', 'showGuides', 'compareMode', 'showShadows', 'showRarityEffects', 'showZOrder']);
    const integerFields = new Set(['cardCount', 'hoverSpread', 'hoverLift']);
    const floatFields = new Set(['cardScale', 'overlap', 'fanAngle', 'curvature', 'hoverScale', 'animationSpeed', 'springiness', 'damping', 'ribbonOpacityDuel', 'ribbonOpacityLocal', 'ribbonOpacityConquest']);
    if (checkboxFields.has(field)) return !!target.checked;
    if (integerFields.has(field)) return Math.round(toNumber(target.value, DEFAULTS[field]));
    if (floatFields.has(field)) return toNumber(target.value, DEFAULTS[field]);
    return String(target.value ?? '');
  }

  function ribbonOpacityForMode(settings, mode = 'duel') {
    const safe = mergeSettings(settings);
    const key = String(mode ?? 'duel').toLowerCase();
    if (key === 'local') return safe.ribbonOpacityLocal;
    if (key === 'conquest') return safe.ribbonOpacityConquest;
    return safe.ribbonOpacityDuel;
  }

  function motionDurationMs(settings, distanceFactor = 0) {
    const speed = clamp(toNumber(settings.animationSpeed, 1), 0.6, 1.35);
    const springiness = clamp(toNumber(settings.springiness, 0.58), 0.1, 1);
    const damping = clamp(toNumber(settings.damping, 0.76), 0.3, 1);
    return Math.round((520 - (speed * 180) + ((1 - damping) * 70) + (springiness * 36)) + (distanceFactor * 32));
  }

  function motionEasing(settings) {
    const springiness = clamp(toNumber(settings.springiness, 0.58), 0.1, 1);
    const damping = clamp(toNumber(settings.damping, 0.76), 0.3, 1);
    const p1 = (0.16 + (springiness * 0.08)).toFixed(2);
    const p2 = (0.86 + (springiness * 0.12)).toFixed(2);
    const p3 = (0.16 + (damping * 0.22)).toFixed(2);
    return `cubic-bezier(${p1}, ${p2}, ${p3}, 1.00)`;
  }

    function resolveCardId(card, getId) {
    if (typeof getId === 'function') return String(getId(card));
    return String(card?.runtimeId ?? card?.instanceId ?? card?.id ?? card?.cardId ?? card?.name ?? 'card');
  }

  function parseAnchorCoordinate(value, size, fallbackRatio = 0.5) {
    const raw = String(value ?? '').trim();
    if (raw.endsWith('%')) {
      const pct = Number.parseFloat(raw.slice(0, -1));
      if (Number.isFinite(pct)) return size * (pct / 100);
    }
    const numeric = Number.parseFloat(raw);
    if (Number.isFinite(numeric)) return numeric;
    return size * fallbackRatio;
  }

  function ensureHandControllerState(uiState) {
    if (!uiState || typeof uiState !== 'object') return { pendingHoverId: null, pendingHoverStart: 0 };
    if (!uiState.__handController || typeof uiState.__handController !== 'object') {
      uiState.__handController = {
        pendingHoverId: null,
        pendingHoverStart: 0,
      };
    }
    return uiState.__handController;
  }

  function buildBaseHandLayouts(root, cards, settings, options = {}) {
    if (!(root instanceof Element)) return [];
    const safe = mergeSettings(settings);
    const cardItems = Array.isArray(cards) ? cards : [];
    const getId = options.getId;
    const baseScale = clamp(toNumber(safe.cardScale, 1), 0.82, 1.28);
    const baseCardWidth = (toNumber(options.baseWidth, 210) * baseScale);
    const baseCardHeight = (toNumber(options.baseHeight, 304) * baseScale);
    const overlap = clamp(toNumber(safe.overlap, 0.5), 0.12, 0.78);
    let step = baseCardWidth * clamp(1 - overlap, 0.16, 0.88);
    const curvaturePx = clamp(toNumber(safe.curvature, 20), 0, 40) * 2.2;
    const fanAngle = clamp(toNumber(safe.fanAngle, 12), 0, 24);
    const maxOffset = Math.max((cardItems.length - 1) / 2, 1);
    const orientationSign = safe.orientation === 'outward' ? 1 : -1;
    const bounds = root.getBoundingClientRect();
    const rootWidth = Math.max(bounds.width, root.clientWidth, 1);
    const rootHeight = Math.max(bounds.height, root.clientHeight, 1);
    const anchorX = parseAnchorCoordinate(ANCHORS[safe.anchor]?.x ?? '50%', rootWidth, 0.5);
    const anchorY = parseAnchorCoordinate(ANCHORS[safe.anchor]?.y ?? '96%', rootHeight, 0.96);
    const horizontalRoom = Math.max(0, Math.min(anchorX, rootWidth-anchorX)*2 - baseCardWidth - 48);
    if (cardItems.length > 1) step = Math.min(step, horizontalRoom / (cardItems.length-1));
    return cardItems.map((card, index) => {
      const id = resolveCardId(card, getId);
      const delta = index - ((cardItems.length - 1) / 2);
      const distance = Math.abs(delta) / maxOffset;
      const x = delta * step;
      const y = Math.pow(distance, 1.55) * curvaturePx;
      const rotationDeg = orientationSign * ((delta / maxOffset) * fanAngle);
      const scale = 1 - (distance * 0.02) + ((1 - distance) * 0.028);
      const topLeftX = anchorX - (baseCardWidth / 2) + x;
      const topLeftY = anchorY - baseCardHeight - y;
      const originLocalX = baseCardWidth * 0.5;
      const originLocalY = baseCardHeight * 0.92;
      return {
        id,
        index,
        card,
        width: baseCardWidth,
        height: baseCardHeight,
        baseScale,
        scale,
        rotationDeg,
        translateX: x,
        translateY: y,
        anchorX,
        anchorY,
        topLeftX,
        topLeftY,
        originLocalX,
        originLocalY,
        originX: topLeftX + originLocalX,
        originY: topLeftY + originLocalY,
        centerX: topLeftX + (baseCardWidth / 2),
        centerY: topLeftY + (baseCardHeight / 2),
        zIndex: 100 + Math.round((1 - distance) * 40) + (index / 1000),
        distance,
        delta,
      };
    });
  }

  function buildVisualHandLayouts(root, cards, settings, uiState, options = {}) {
    const safe = mergeSettings(settings);
    const baseLayouts = buildBaseHandLayouts(root, cards, safe, options);
    const ids = baseLayouts.map((layout) => layout.id);
    const focusId = String(uiState?.pinnedCardId ?? uiState?.selectedCardId ?? uiState?.hoveredCardId ?? '');
    const focusIndex = focusId ? ids.findIndex((id) => id === focusId) : -1;
    const hoverLift = clamp(toNumber(safe.hoverLift, 62), 20, 110);
    const hoverScale = clamp(toNumber(safe.hoverScale, DEFAULTS.hoverScale), 1, 1.4);
    const hoverSpread = clamp(toNumber(safe.hoverSpread, 70), 20, 120);
    return baseLayouts.map((baseLayout) => {
      const { id: cardId, index } = baseLayout;
      const focusDelta = focusIndex >= 0 ? index - focusIndex : baseLayout.delta;
      const focusDistance = focusIndex >= 0 ? Math.abs(focusDelta) : Math.abs(baseLayout.delta);
      const proximity = focusIndex >= 0 ? Math.max(0, 1 - (focusDistance / 3.6)) : 0;
      const openOffset = focusIndex >= 0 && index !== focusIndex
        ? Math.sign(focusDelta) * hoverSpread * Math.pow(proximity, 1.25)
        : 0;
      const neighborLift = focusIndex >= 0 && index !== focusIndex ? hoverLift * 0.18 * proximity : 0;
      let x = baseLayout.translateX + openOffset;
      let y = baseLayout.translateY + neighborLift;
      let z = (1 - baseLayout.distance) * 40;
      let scale = baseLayout.scale;
      let rotate = baseLayout.rotationDeg;
      let opacity = focusIndex >= 0 && String(uiState?.pinnedCardId ?? '') && index !== focusIndex ? 0.78 : 1;
      let stateLabel = '';
      if (cardId === String(uiState?.hoveredCardId ?? '') && !uiState?.selectedCardId && !uiState?.pinnedCardId) {
        y += hoverLift * 0.82;
        z += 120;
        scale *= hoverScale;
        rotate *= 0.32;
        stateLabel = 'Hover';
      }
      if (cardId === String(uiState?.selectedCardId ?? '')) {
        y += hoverLift * 0.94;
        z += 160;
        scale *= 1 + ((hoverScale - 1) * 1.2);
        rotate *= 0.18;
        stateLabel = 'Selected';
      }
      if (cardId === String(uiState?.pinnedCardId ?? '')) {
        y += hoverLift * 1.16;
        z += 220;
        scale *= 1 + ((hoverScale - 1) * 1.45) + 0.02;
        rotate *= 0.08;
        opacity = 1;
        stateLabel = 'Pinned';
      }
      if (cardId === String(uiState?.draggedCardId ?? '')) {
        y += hoverLift * 1.08;
        z += 260;
        scale *= 1 + ((hoverScale - 1) * 1.5) + 0.04;
        rotate *= 0.05;
        opacity = 1;
        stateLabel = 'Dragging';
      }
      const tiltX = String(uiState?.pointerTilt?.cardId ?? '') === cardId ? clamp(toNumber(uiState?.pointerTilt?.x, 0), -7, 7) : 0;
      const tiltY = String(uiState?.pointerTilt?.cardId ?? '') === cardId ? clamp(toNumber(uiState?.pointerTilt?.y, 0), -10, 10) : 0;
      const topLeftX = baseLayout.anchorX - (baseLayout.width / 2) + x;
      const topLeftY = baseLayout.anchorY - baseLayout.height - y;
      return {
        ...baseLayout,
        translateX: x,
        translateY: y,
        zDepth: z,
        stateLabel,
        opacity,
        scale,
        rotationDeg: rotate,
        topLeftX,
        topLeftY,
        originX: topLeftX + baseLayout.originLocalX,
        originY: topLeftY + baseLayout.originLocalY,
        centerX: topLeftX + (baseLayout.width / 2),
        centerY: topLeftY + (baseLayout.height / 2),
        tiltX,
        tiltY,
        distanceFactor: focusIndex >= 0 ? Math.min(focusDistance, 3) / 3 : baseLayout.distance,
        transitionDistance: focusIndex >= 0 ? focusDistance : baseLayout.distance,
        cssZIndex: 100 + Math.round(z) + (stateLabel === 'Dragging' ? 140 : stateLabel === 'Pinned' ? 100 : stateLabel === 'Selected' ? 70 : stateLabel === 'Hover' ? 40 : 0),
      };
    });
  }

  function pointInsideRotatedCard(pointerX, pointerY, layout, padding = 0) {
    if (!layout) return false;
    const dx = pointerX - layout.originX;
    const dy = pointerY - layout.originY;
    const angle = -(toNumber(layout.rotationDeg, 0) * Math.PI / 180);
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const rotatedX = (dx * cos) - (dy * sin);
    const rotatedY = (dx * sin) + (dy * cos);
    const scale = Math.max(toNumber(layout.scale, 1), 0.01);
    const localX = (rotatedX / scale) + layout.originLocalX;
    const localY = (rotatedY / scale) + layout.originLocalY;
    return (
      localX >= -padding &&
      localX <= (layout.width + padding) &&
      localY >= -padding &&
      localY <= (layout.height + padding)
    );
  }

  function pointInsideDomRect(clientX, clientY, node, padding = 0) {
    if (!(node instanceof Element)) return false;
    const rect = node.getBoundingClientRect();
    return (
      clientX >= (rect.left - padding) &&
      clientX <= (rect.right + padding) &&
      clientY >= (rect.top - padding) &&
      clientY <= (rect.bottom + padding)
    );
  }

  function resolveHandCardAtPointFromDom(root, uiState, clientX, clientY, padding = 0) {
    if (!(root instanceof Element)) return null;
    const nodes = Array.from(root.querySelectorAll('.cf-hand-card'));
    if (!nodes.length) return null;
    const currentHoveredId = String(uiState?.hoveredCardId ?? '');
    const sticky = nodes.find((node) => String(node.dataset.cardId ?? node.dataset.id ?? '') === currentHoveredId);
    if (sticky && pointInsideDomRect(clientX, clientY, sticky, padding)) {
      return currentHoveredId;
    }
    const priority = (node) => {
      const nodeId = String(node.dataset.cardId ?? node.dataset.id ?? '');
      let value = toNumber(Number.parseInt(node.style.zIndex || '0', 10), 0);
      if (nodeId === String(uiState?.draggedCardId ?? '')) value += 40000;
      else if (nodeId === String(uiState?.pinnedCardId ?? '')) value += 30000;
      else if (nodeId === String(uiState?.selectedCardId ?? '')) value += 20000;
      else if (nodeId === currentHoveredId) value += 10000;
      return value;
    };
    const ordered = nodes.slice().sort((left, right) => priority(right) - priority(left));
    const hit = ordered.find((node) => pointInsideDomRect(clientX, clientY, node, 0));
    return hit ? String(hit.dataset.cardId ?? hit.dataset.id ?? '') : null;
  }

  function resolveHandCardAtPoint(root, cards, settings, uiState, clientX, clientY, options = {}) {
    if (!(root instanceof Element)) return null;
    const useDomRects = root.classList.contains('deck-focus-inspect') || String(root.dataset.handCollisionMode ?? '') === 'dom-rects';
    if (useDomRects) {
      return resolveHandCardAtPointFromDom(root, uiState, clientX, clientY, toNumber(options.stickyPadding, 8));
    }
    const bounds = root.getBoundingClientRect();
    const pointerX = clientX - bounds.left + root.scrollLeft;
    const pointerY = clientY - bounds.top + root.scrollTop;
    const layouts = buildBaseHandLayouts(root, cards, settings, options);
    const currentHoveredId = String(uiState?.hoveredCardId ?? '');
    const sticky = layouts.find((layout) => layout.id === currentHoveredId);
    if (sticky && pointInsideRotatedCard(pointerX, pointerY, sticky, toNumber(options.stickyPadding, 8))) {
      return sticky.id;
    }
    // Only the active card has an extended hit area. Never collide against
    // transitioning neighbours: animation must not change the hover candidate.
    const activeId = uiState?.pinnedCardId ?? uiState?.selectedCardId ?? currentHoveredId;
    const active = buildVisualHandLayouts(root, cards, settings, uiState, options).find((layout) => layout.id === activeId);
    if (active && pointInsideRotatedCard(pointerX, pointerY, active, 4)) return active.id;
    const selectedId = String(uiState?.selectedCardId ?? '');
    const pinnedId = String(uiState?.pinnedCardId ?? '');
    const draggedId = String(uiState?.draggedCardId ?? '');
    const prioritized = layouts.slice().sort((left, right) => {
      const score = (layout) => {
        let value = toNumber(layout.zIndex, 0);
        if (layout.id === draggedId) value += 40000;
        else if (layout.id === pinnedId) value += 30000;
        else if (layout.id === selectedId) value += 20000;
        else if (layout.id === currentHoveredId) value += 10000;
        return value;
      };
      return score(right) - score(left);
    });
    for (const layout of prioritized) {
      if (pointInsideRotatedCard(pointerX, pointerY, layout, 0)) return layout.id;
    }
    return null;
  }

  function findCardNode(root, cardId) {
    if (!(root instanceof Element) || cardId == null) return null;
    const targetId = String(cardId);
    return Array.from(root.querySelectorAll('.cf-hand-card')).find((node) => String(node.dataset.cardId ?? node.dataset.id ?? '') === targetId) ?? null;
  }

  function elementBelowHand(root, clientX, clientY) {
    if (!(root instanceof Element)) return null;
    root.classList.add('hand-pass-through');
    try { return document.elementFromPoint(clientX, clientY); }
    finally { root.classList.remove('hand-pass-through'); }
  }

  function setPointerTilt(uiState, cardId, x, y) {
    if (!uiState || typeof uiState !== 'object') return false;
    const current = uiState.pointerTilt ?? { cardId: null, x: 0, y: 0 };
    const nextId = cardId == null ? null : String(cardId);
    const nextX = clamp(toNumber(x, 0), -7, 7);
    const nextY = clamp(toNumber(y, 0), -10, 10);
    if (String(current.cardId ?? '') === String(nextId ?? '') && Math.abs(toNumber(current.x, 0) - nextX) < 0.02 && Math.abs(toNumber(current.y, 0) - nextY) < 0.02) {
      return false;
    }
    uiState.pointerTilt = { cardId: nextId, x: nextX, y: nextY };
    return true;
  }

  function clearPointerTilt(uiState) {
    if (!uiState || typeof uiState !== 'object') return false;
    const current = uiState.pointerTilt ?? { cardId: null, x: 0, y: 0 };
    if (!current.cardId && Math.abs(toNumber(current.x, 0)) < 0.02 && Math.abs(toNumber(current.y, 0)) < 0.02) return false;
    uiState.pointerTilt = { cardId: null, x: 0, y: 0 };
    return true;
  }

  function updatePointerTiltFromEvent(root, uiState, cardId, event) {
    const node = findCardNode(root, cardId);
    if (!(node instanceof Element) || !event) return clearPointerTilt(uiState);
    const rect = node.getBoundingClientRect();
    const px = ((event.clientX - rect.left) / Math.max(rect.width, 1)) - 0.5;
    const py = ((event.clientY - rect.top) / Math.max(rect.height, 1)) - 0.5;
    return setPointerTilt(uiState, cardId, px * 8, py * -10);
  }

  function updateHandHover(root, cards, settings, uiState, event, options = {}) {
    if (!(root instanceof Element) || !event || !uiState || typeof uiState !== 'object') {
      return { changed: false, candidateId: null, hoveredCardId: null };
    }
    if (uiState.draggedCardId) {
      const changed = clearPointerTilt(uiState);
      return { changed, candidateId: null, hoveredCardId: uiState.hoveredCardId ?? null };
    }
    const controller = ensureHandControllerState(uiState);
    const candidateId = resolveHandCardAtPoint(root, cards, settings, uiState, event.clientX, event.clientY, options);
    const currentHoveredId = uiState.hoveredCardId == null ? null : String(uiState.hoveredCardId);
    const nextCandidateId = candidateId == null ? null : String(candidateId);
    // Stable base geometry plus the sticky margin provide hysteresis without
    // requiring a second pointer event (a stationary cursor must still focus).
    let changed = nextCandidateId !== currentHoveredId;
    uiState.hoveredCardId = nextCandidateId;
    controller.pendingHoverId = null;
    const focusId = String(uiState.pinnedCardId ?? uiState.selectedCardId ?? uiState.hoveredCardId ?? nextCandidateId ?? '');
    const lockedId = String(uiState.pinnedCardId ?? uiState.selectedCardId ?? '');
    if (focusId && (!lockedId || lockedId === nextCandidateId || lockedId === focusId)) {
      // Tiny tilt uses stable collision geometry, not the animated DOM rect.
      const layout = buildBaseHandLayouts(root, cards, settings, options).find((entry) => entry.id === focusId);
      const bounds = root.getBoundingClientRect();
      if (layout) changed = setPointerTilt(uiState, focusId,
        ((event.clientX - bounds.left + root.scrollLeft - layout.centerX) / layout.width) * 3,
        ((event.clientY - bounds.top + root.scrollTop - layout.centerY) / layout.height) * -3) || changed;
    } else {
      changed = clearPointerTilt(uiState) || changed;
    }
    return {
      changed,
      candidateId: nextCandidateId,
      hoveredCardId: uiState.hoveredCardId ?? null,
    };
  }

  function clearHandHover(uiState, options = {}) {
    if (!uiState || typeof uiState !== 'object') return false;
    const controller = ensureHandControllerState(uiState);
    controller.pendingHoverId = null;
    controller.pendingHoverStart = 0;
    let changed = false;
    if (uiState.hoveredCardId != null) {
      uiState.hoveredCardId = null;
      changed = true;
    }
    return clearPointerTilt(uiState) || changed;
  }

  function syncHandLayout(root, cards, settings, uiState, options = {}) {
    if (!(root instanceof Element)) return;
    const safe = mergeSettings(settings);
    const nodes = Array.from(root.querySelectorAll('.cf-hand-card'));
    const hoverLift = clamp(toNumber(safe.hoverLift, 62), 20, 110);
    const stageHeight = Math.max(Math.round((toNumber(options.baseHeight, 304) * clamp(toNumber(safe.cardScale, 1), 0.82, 1.28)) + hoverLift + (clamp(toNumber(safe.curvature, 20), 0, 40) * 2.2) + 54), 220);
    root.classList.add('cf-hand-presenter');
    root.classList.toggle('show-shadows', !!safe.showShadows);
    root.classList.toggle('show-rarity-effects', !!safe.showRarityEffects);
    root.classList.toggle('show-guides', !!safe.showGuides);
    root.dataset.handCollisionMode = root.classList.contains('deck-focus-inspect') ? 'dom-rects' : 'rotated-base-layout';
    root.dataset.orientation = safe.orientation;
    root.dataset.styleMode = safe.styleMode;
    root.dataset.textSize = safe.textSize;
    root.style.setProperty('--cf-anchor-x', ANCHORS[safe.anchor]?.x ?? '50%');
    root.style.setProperty('--cf-anchor-y', ANCHORS[safe.anchor]?.y ?? '96%');
    root.style.setProperty('--cf-hand-height', `${stageHeight}px`);
    const visualLayouts = buildVisualHandLayouts(root, cards, safe, uiState, options);
    const focusId = String(uiState?.pinnedCardId ?? uiState?.selectedCardId ?? uiState?.hoveredCardId ?? '');
    const focusIndex = focusId ? visualLayouts.findIndex((layout) => layout.id === focusId) : -1;
    let focusKind = 'idle';
    nodes.forEach((node, index) => {
      const layout = visualLayouts[index];
      if (!layout) return;
      if (layout.stateLabel === 'Hover') focusKind = 'hover';
      if (layout.stateLabel === 'Selected') focusKind = 'selected';
      if (layout.stateLabel === 'Pinned') focusKind = 'pinned';
      if (layout.stateLabel === 'Dragging') focusKind = 'dragging';
      node.classList.toggle('is-hovered', layout.stateLabel === 'Hover');
      node.classList.toggle('is-selected', layout.stateLabel === 'Selected');
      node.classList.toggle('is-pinned', layout.stateLabel === 'Pinned');
      node.classList.toggle('is-dragging', layout.stateLabel === 'Dragging');
      node.classList.toggle('is-muted', focusIndex >= 0 && layout.id !== focusId);
      node.style.opacity = String(layout.opacity);
      node.style.zIndex = String(layout.cssZIndex);
      node.style.setProperty('--cf-card-width', `${Math.round(layout.width)}px`);
      node.style.setProperty('--cf-card-height', `${Math.round(layout.height)}px`);
      node.style.setProperty('--cf-card-x', `${layout.translateX.toFixed(1)}px`);
      node.style.setProperty('--cf-card-y', `${layout.translateY.toFixed(1)}px`);
      node.style.setProperty('--cf-card-rotate', `${layout.rotationDeg.toFixed(2)}deg`);
      node.style.setProperty('--cf-card-scale', layout.scale.toFixed(3));
      node.style.setProperty('--cf-card-tilt-x', `${layout.tiltX.toFixed(2)}deg`);
      node.style.setProperty('--cf-card-tilt-y', `${layout.tiltY.toFixed(2)}deg`);
      node.style.setProperty('--cf-card-duration', `${motionDurationMs(safe, layout.distanceFactor)}ms`);
      node.style.setProperty('--cf-card-delay', `${Math.round(layout.transitionDistance * 14)}ms`);
      node.style.setProperty('--cf-card-ease', motionEasing(safe));
      node.dataset.cardState = layout.stateLabel || 'Idle';
      const badge = node.querySelector('.cf-hand-card-debug');
      if (badge) badge.textContent = safe.showZOrder ? `${layout.stateLabel || 'Idle'} · z${node.style.zIndex}` : layout.stateLabel;
    });
    root.dataset.focusKind = focusKind;
  }

  function sampleCards(count) {
    const total = clamp(Math.round(toNumber(count, 8)), 3, 16);
    return Array.from({ length: total }, (_, index) => {
      const base = SAMPLE_CARDS[index % SAMPLE_CARDS.length];
      return { ...base, runtimeId: `${base.id}-${index}`, order: index, name: index >= SAMPLE_CARDS.length ? `${base.name} ${index + 1}` : base.name };
    });
  }

  global.CardForgeCardPresentation = {
    PRESETS,
    MOTION_PRESETS,
    ANCHORS,
    STYLE_MODES,
    TEXT_SIZES,
    DEFAULTS,
    SAMPLE_CARDS,
    mergeSettings,
    applyPreset,
    applyMotionPreset,
    settingsControlsMarkup,
    parseFieldValue,
    ribbonOpacityForMode,
    buildBaseHandLayouts,
    buildVisualHandLayouts,
    pointInsideRotatedCard,
    elementBelowHand,
    resolveHandCardAtPoint,
    updateHandHover,
    clearHandHover,
    updatePointerTiltFromEvent,
    clearPointerTilt,
    syncHandLayout,
    sampleCards,
    safeAssetUrl,
    characterPortrait,
    resolveCardArt,
    cardFaceMarkup,
    cardBackMarkup,
    escapeHtml,
    slugify,
  };
})(window);

