(function bootstrapNarrativeEngine() {
  'use strict';

  const STATE_KEY = 'cardforge.narrative.v1';
  const PROFILE_KEY = 'cardforge.profile.v1';
  const STORY_URL = './data/narrative/concordance_campaign.json';
  let storyPromise = null;
  let autoTimer = 0;

  const safeParse = (value, fallback) => {
    try { return JSON.parse(value); } catch { return fallback; }
  };

  function readState() {
    return safeParse(localStorage.getItem(STATE_KEY) || 'null', null) || {
      version: 1,
      currentNodeId: null,
      seen: [],
      history: [],
      executedCommands: [],
      auto: false,
      uiHidden: false,
    };
  }

  function saveState(patch = {}) {
    const next = { ...readState(), ...patch, version: 1, updatedAt: Date.now() };
    localStorage.setItem(STATE_KEY, JSON.stringify(next));
    return next;
  }

  function readProfile() {
    return safeParse(localStorage.getItem(PROFILE_KEY) || '{}', {}) || {};
  }

  function writeProfile(profile) {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  }

  function loadStory() {
    if (!storyPromise) {
      storyPromise = fetch(STORY_URL).then((response) => {
        if (!response.ok) throw new Error(`Narrative data failed: ${response.status}`);
        return response.json();
      });
    }
    return storyPromise;
  }

  function ensureHost() {
    let host = document.getElementById('narrative-engine');
    if (host) return host;
    host = document.createElement('section');
    host.id = 'narrative-engine';
    host.className = 'narrative-engine hidden';
    document.body.appendChild(host);
    return host;
  }

  function portraitUrl(id = '') {
    return window.CardForgeCardPresentation?.characterPortrait?.(id)
      || (String(id).toLowerCase() === 'agony'
        ? window.CardForgeConcordanceAssets?.agonyPortrait
        : window.CardForgeConcordanceAssets?.rookPortrait)
      || '';
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function setNested(target, path, value) {
    const keys = String(path || '').split('.').filter(Boolean);
    if (!keys.length) return;
    let cursor = target;
    keys.slice(0, -1).forEach((key) => {
      if (!cursor[key] || typeof cursor[key] !== 'object') cursor[key] = {};
      cursor = cursor[key];
    });
    cursor[keys.at(-1)] = value;
  }

  function ensureCampaign(profile) {
    profile.mapWorld = profile.mapWorld || {};
    profile.mapWorld.campaign = profile.mapWorld.campaign || {};
    profile.mapWorld.campaign.resources = profile.mapWorld.campaign.resources || {};
    profile.mapWorld.campaign.flags = profile.mapWorld.campaign.flags || {};
    profile.mapWorld.campaign.operations = Array.isArray(profile.mapWorld.campaign.operations)
      ? profile.mapWorld.campaign.operations
      : [];
    if (!Number.isFinite(Number(profile.mapWorld.campaign.resources.supplies))) profile.mapWorld.campaign.resources.supplies = 18;
    if (!Number.isFinite(Number(profile.mapWorld.campaign.resources.relicDust))) profile.mapWorld.campaign.resources.relicDust = 0;
    if (!Number.isFinite(Number(profile.mapWorld.campaign.resources.forgeCores))) profile.mapWorld.campaign.resources.forgeCores = 0;
    return profile.mapWorld.campaign;
  }

  function executeCommand(command, nodeId) {
    if (!command?.type) return;
    const state = readState();
    const commandId = command.id || `${nodeId}:${command.type}:${command.path || command.event || ''}`;
    if (state.executedCommands.includes(commandId)) return;
    const profile = readProfile();

    if (command.type === 'set-profile') {
      setNested(profile, command.path, command.value);
      writeProfile(profile);
    } else if (command.type === 'adjust-resource') {
      const campaign = ensureCampaign(profile);
      profile.resources = profile.resources || {};
      const key = command.resource || 'gold';
      const aliases = { gold: 'credits', credits: 'credits' };
      const campaignKey = aliases[key] || key;
      const fallback = campaignKey === 'credits' ? Number(profile.economy?.gold || 0) : Number(profile.resources[key] || 0);
      campaign.resources[campaignKey] = Math.max(0, Number(campaign.resources[campaignKey] ?? fallback) + Number(command.amount || 0));
      profile.resources[key] = campaign.resources[campaignKey];
      if (campaignKey === 'credits') {
        profile.economy = profile.economy || {};
        profile.economy.gold = campaign.resources.credits;
      }
      writeProfile(profile);
    } else if (command.type === 'add-operation') {
      const campaign = ensureCampaign(profile);
      const existing = campaign.operations.find((entry) => entry.id === command.operation?.id);
      if (!existing) campaign.operations.push(command.operation);
      else Object.assign(existing, command.operation, { status: existing.status === 'completed' ? 'completed' : (command.operation.status || existing.status) });
      writeProfile(profile);
    } else if (command.type === 'update-operation') {
      const campaign = ensureCampaign(profile);
      const operation = campaign.operations.find((entry) => entry.id === command.operationId);
      if (operation) Object.assign(operation, command.patch || {});
      writeProfile(profile);
    } else if (command.type === 'set-flag') {
      const campaign = ensureCampaign(profile);
      campaign.flags[command.flag] = command.value ?? true;
      writeProfile(profile);
    } else if (command.type === 'dispatch') {
      window.dispatchEvent(new CustomEvent(command.event || 'cardforge:narrative-command', { detail: command.detail || {} }));
    }

    saveState({ executedCommands: [...new Set([...state.executedCommands, commandId])] });
  }

  function close({ route = null } = {}) {
    clearTimeout(autoTimer);
    const host = ensureHost();
    host.classList.add('hidden');
    document.body.classList.remove('narrative-active');
    if (route === 'command-center') {
      document.getElementById('main-menu-screen')?.classList.add('hidden');
      window.location.hash = '#/command';
      window.CardForgeCommandCenter?.open?.('#/command');
    }
  }

  function lineHistory(state, node) {
    const entry = `${node.speaker ? `${node.speaker}: ` : ''}${node.text}`;
    if (state.history.at(-1)?.nodeId === node.id) return state.history;
    return [...state.history.slice(-79), { nodeId: node.id, text: entry }];
  }

  async function render(nodeId) {
    clearTimeout(autoTimer);
    const story = await loadStory();
    const node = story.nodes.find((entry) => entry.id === nodeId);
    if (!node) throw new Error(`Unknown narrative node: ${nodeId}`);
    const previous = readState();
    const nextState = saveState({
      currentNodeId: node.id,
      seen: [...new Set([...previous.seen, node.id])],
      history: lineHistory(previous, node),
    });
    (node.commands || []).forEach((command) => executeCommand(command, node.id));

    const host = ensureHost();
    const left = node.leftPortrait ? portraitUrl(node.leftPortrait) : '';
    const right = node.rightPortrait ? portraitUrl(node.rightPortrait) : '';
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    host.className = `narrative-engine theme-${escapeHtml(node.theme || 'concordance')}${nextState.uiHidden ? ' ui-hidden' : ''}${reduced ? ' reduced-motion' : ''}`;
    document.body.classList.add('narrative-active');
    document.getElementById('main-menu-screen')?.classList.add('hidden');
    window.CardForgeCommandCenter?.close?.({ setLobbyHash: false });

    host.innerHTML = `
      <div class="narrative-scene" style="--scene-accent:${escapeHtml(node.accent || '#d7b66b')}">
        <div class="narrative-space" aria-hidden="true"><i></i><i></i><i></i></div>
        <header class="narrative-chapter"><span>${escapeHtml(node.chapterLabel || story.title)}</span><strong>${escapeHtml(node.chapterTitle || '')}</strong></header>
        ${left ? `<figure class="narrative-portrait left ${node.speaker === 'Rook' ? 'speaking' : ''}"><img src="${left}" alt="Rook" /></figure>` : ''}
        ${right ? `<figure class="narrative-portrait right ${node.speaker === 'Agony' ? 'speaking' : ''}"><img src="${right}" alt="Agony" /></figure>` : ''}
        <article class="narrative-console ${node.animation ? `motion-${escapeHtml(node.animation)}` : ''}">
          <div class="narrative-speaker"><span>${escapeHtml(node.speaker || 'Record')}</span><small>${escapeHtml(node.speakerTitle || '')}</small></div>
          <p>${escapeHtml(node.text)}</p>
          ${node.subtext ? `<div class="narrative-subtext">${escapeHtml(node.subtext)}</div>` : ''}
          ${node.choices?.length ? `<div class="narrative-choices">${node.choices.map((choice, index) => `<button type="button" data-narrative-choice="${index}"><span>${String(index + 1).padStart(2, '0')}</span>${escapeHtml(choice.label)}</button>`).join('')}</div>` : ''}
          <div class="narrative-controls">
            <button type="button" data-narrative-history>History</button>
            <button type="button" data-narrative-auto class="${nextState.auto ? 'active' : ''}">Auto ${nextState.auto ? 'On' : 'Off'}</button>
            <button type="button" data-narrative-skip>Skip Seen</button>
            <button type="button" data-narrative-hide>Hide UI</button>
            ${!node.choices?.length ? `<button type="button" class="primary" data-narrative-continue>${node.next ? 'Continue' : (node.completeLabel || 'Enter Command Center')}</button>` : ''}
          </div>
        </article>
        <aside class="narrative-history hidden"><header><strong>Dialogue History</strong><button type="button" data-narrative-history-close>Close</button></header>${nextState.history.map((entry) => `<p>${escapeHtml(entry.text)}</p>`).join('')}</aside>
        <button type="button" class="narrative-show-ui ${nextState.uiHidden ? '' : 'hidden'}" data-narrative-show>Show Dialogue</button>
      </div>`;

    const advance = async (target = node.next) => {
      if (!target) {
        close({ route: node.completeRoute || 'command-center' });
        return;
      }
      await render(target);
    };
    host.querySelector('[data-narrative-continue]')?.addEventListener('click', () => advance());
    host.querySelectorAll('[data-narrative-choice]').forEach((button) => button.addEventListener('click', () => {
      const choice = node.choices[Number(button.dataset.narrativeChoice || 0)];
      (choice.commands || []).forEach((command) => executeCommand(command, `${node.id}:choice:${button.dataset.narrativeChoice}`));
      advance(choice.next);
    }));
    const historyPanel = host.querySelector('.narrative-history');
    host.querySelector('[data-narrative-history]')?.addEventListener('click', () => historyPanel?.classList.remove('hidden'));
    host.querySelector('[data-narrative-history-close]')?.addEventListener('click', () => historyPanel?.classList.add('hidden'));
    host.querySelector('[data-narrative-auto]')?.addEventListener('click', () => {
      saveState({ auto: !readState().auto });
      render(node.id);
    });
    host.querySelector('[data-narrative-hide]')?.addEventListener('click', () => { saveState({ uiHidden: true }); render(node.id); });
    host.querySelector('[data-narrative-show]')?.addEventListener('click', () => { saveState({ uiHidden: false }); render(node.id); });
    host.querySelector('[data-narrative-skip]')?.addEventListener('click', async () => {
      let cursor = node;
      const seen = new Set(readState().seen);
      while (cursor?.next && !cursor.choices?.length && seen.has(cursor.next)) cursor = story.nodes.find((entry) => entry.id === cursor.next);
      if (cursor?.next) await render(cursor.next);
    });
    if (nextState.auto && node.next && !node.choices?.length) autoTimer = window.setTimeout(() => advance(), Math.max(1600, Number(node.autoDelay || 3600)));
  }

  function keyHandler(event) {
    const host = ensureHost();
    if (host.classList.contains('hidden')) return;
    if ((event.key === 'Enter' || event.key === ' ') && !event.target.closest('button')) {
      event.preventDefault();
      host.querySelector('[data-narrative-continue]')?.click();
    } else if (event.key.toLowerCase() === 'h') {
      host.querySelector('[data-narrative-hide]')?.click();
    } else if (/^[1-9]$/.test(event.key)) {
      host.querySelector(`[data-narrative-choice="${Number(event.key) - 1}"]`)?.click();
    }
  }
  document.addEventListener('keydown', keyHandler);

  async function start(nodeId, { resetHistory = false } = {}) {
    if (resetHistory) saveState({ currentNodeId: null, seen: [], history: [], executedCommands: [], auto: false, uiHidden: false });
    await render(nodeId);
    return true;
  }

  async function resume() {
    const state = readState();
    if (!state.currentNodeId) return false;
    await render(state.currentNodeId);
    return true;
  }

  function reset() {
    localStorage.removeItem(STATE_KEY);
    close();
  }

  window.CardForgeNarrativeEngine = { start, resume, close, reset, state: readState, loadStory };
  const previewNode = new URLSearchParams(window.location.search).get('narrative-preview');
  if (previewNode) window.setTimeout(() => start(previewNode), 0);
})();
