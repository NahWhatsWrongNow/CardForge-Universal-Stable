const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('C:/Users/jadon/.codex/skills/develop-web-game/scripts/node_modules/playwright');

const ROOT_URL = 'http://127.0.0.1:8137';
const FOUNDATION_KEY = 'cardforge.foundation.campaign.v1';
const PROFILE_KEY = 'cardforge.profile.v1';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function setStorageAndReload(page, entries) {
  await page.evaluate(({ foundationKey, profileKey, values }) => {
    localStorage.clear();
    if (values.foundation) localStorage.setItem(foundationKey, JSON.stringify(values.foundation));
    if (values.profile) localStorage.setItem(profileKey, JSON.stringify(values.profile));
  }, { foundationKey: FOUNDATION_KEY, profileKey: PROFILE_KEY, values: entries });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(450);
}

(async () => {
  const output = path.resolve('output/web-game/campaign-ai-validation');
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1980, height: 1080 } });
  const errors = [];
  page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
  page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });

  await page.goto(`${ROOT_URL}/index.html`, { waitUntil: 'domcontentloaded' });
  await setStorageAndReload(page, {});
  await page.click('#continue-game-btn');
  await page.waitForTimeout(350);
  const fresh = await page.evaluate(() => ({
    hash: location.hash,
    phase: window.CardForgeFoundationCampaign?.state?.()?.phase,
    foundationOpen: document.body.classList.contains('foundation-active'),
    commandOpen: document.body.classList.contains('command-center-open'),
  }));
  assert(fresh.phase === 'opening' && fresh.foundationOpen && !fresh.commandOpen, 'Fresh Continue did not open the campaign prologue.');

  await setStorageAndReload(page, { foundation: { version: 1, phase: 'rook_briefing', response: 1 } });
  await page.click('#continue-game-btn');
  await page.waitForTimeout(350);
  const interrupted = await page.evaluate(() => ({
    phase: window.CardForgeFoundationCampaign?.state?.()?.phase,
    foundationOpen: document.body.classList.contains('foundation-active'),
    heading: document.querySelector('#foundation-campaign')?.innerText?.slice(0, 120),
  }));
  assert(interrupted.phase === 'rook_briefing' && interrupted.foundationOpen, 'Interrupted prologue did not resume.');

  await setStorageAndReload(page, {
    foundation: { version: 1, phase: 'campaign', starterVaultId: 'pyre' },
    profile: {
      economy: { gold: 650 },
      mapWorld: { campaign: { foundation: { phase: 'campaign', starterVaultId: 'pyre', rookInherited: true }, ownedDimensions: ['The Last Bastion'] } },
    },
  });
  await page.click('#continue-game-btn');
  await page.waitForTimeout(700);
  const established = await page.evaluate(() => ({
    hash: location.hash,
    commandOpen: document.body.classList.contains('command-center-open'),
    turn: window.CardForgeCampaignState?.buildCommandState?.('#/command')?.turn,
    deckName: window.CardForgeCampaignState?.buildCommandState?.('#/command')?.activeDeck?.name,
  }));
  assert(established.hash === '#/command' && established.commandOpen, 'Completed campaign did not enter Command Center.');
  assert(established.turn === 1, `Recovered campaign used an invalid default turn: ${established.turn}`);
  assert(established.deckName !== 'Starter Duel Collapsed Vanguard', 'Command Center leaked the duel starter deck into conquest.');
  await page.screenshot({ path: path.join(output, 'campaign-resume.png'), fullPage: false });

  await page.goto(`${ROOT_URL}/GameFeatures.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(250);
  const ai = await page.evaluate(async () => {
    const aiModule = await import(`/game/engine/ai.js?validation=${Date.now()}`);
    const asyncModule = await import(`/game/engine/ai_async.js?validation=${Date.now()}`);
    const profile = {
      id: 'validation-marshal',
      name: 'Validation Marshal',
      level: 20,
      difficultyBand: 'Expert',
      tacticProfile: 'neural-network',
      strategy: 'control',
      weights: { attackFace: 0.62, trade: 0.84, summon: 0.7 },
    };
    const base = {
      enemyHealth: 30,
      playerHealth: 30,
      enemyMinions: [],
      playerMinions: [],
      enemyDeck: [],
      enemyHand: [],
      enemyFields: [],
      enemyRelics: [],
      enemyBarricades: [null, null, null, null],
      enemyMana: 0,
      maxMana: 0,
      enemyUsedAttacks: {},
      playerUsedAttacks: {},
      turnFlags: { enemy: {}, player: {} },
      familiarity: { enemy: {}, player: {} },
      turn: 4,
      boardColumns: 4,
    };
    const lethalState = {
      ...base,
      playerHealth: 6,
      enemyMinions: [
        { id: 'blade-a', name: 'Blade A', attack: 3, health: 3, maxHealth: 3, slot: 2, summoningSick: false },
        { id: 'blade-b', name: 'Blade B', attack: 3, health: 3, maxHealth: 3, slot: 3, summoningSick: false },
      ],
    };
    const lethalPlan = aiModule.chooseTurnPlan(lethalState, profile);

    const targetState = {
      ...base,
      enemyMana: 2,
      maxMana: 2,
      enemyHand: [{ id: 'precision-bolt', name: 'Precision Bolt', type: 'spell', cost: 2, text: 'Deal 3 damage to an enemy.', effect: { action: 'dealDamage', amount: 3 } }],
      playerMinions: [
        { id: 'minor', name: 'Minor Guard', attack: 1, health: 3, maxHealth: 3, slot: 0 },
        { id: 'engine', name: 'War Engine', attack: 7, health: 3, maxHealth: 3, slot: 3, allowMultiAttack: true },
      ],
    };
    const targetPlan = aiModule.chooseTurnPlan(targetState, profile);
    const spellPlay = targetPlan.find((action) => action.type === 'play-card');

    const curveState = {
      ...base,
      enemyMana: 4,
      maxMana: 4,
      turn: 5,
      enemyHand: [
        { id: 'twin-a', name: 'Shield Twin A', type: 'minion', cost: 2, attack: 3, health: 3 },
        { id: 'twin-b', name: 'Shield Twin B', type: 'minion', cost: 2, attack: 3, health: 3 },
        { id: 'slow-anchor', name: 'Slow Anchor', type: 'minion', cost: 4, attack: 4, health: 5 },
        { id: 'future-engine', name: 'Future Engine', type: 'minion', cost: 6, attack: 7, health: 7 },
      ],
    };
    const curvePlan = aiModule.chooseTurnPlan(curveState, { ...profile, id: 'curve-marshal', difficultyBand: 'Hard' });

    let maxGap = 0;
    let previous = performance.now();
    const ticker = setInterval(() => {
      const now = performance.now();
      maxGap = Math.max(maxGap, now - previous);
      previous = now;
    }, 16);
    const workerResult = await asyncModule.planTurnAsync({ ...targetState, turn: 5 }, profile);
    clearInterval(ticker);
    return {
      lethalPlan,
      targetPlan,
      targetId: spellPlay?.targetId ?? null,
      curvePlan,
      workerFallback: workerResult.fallback,
      workerElapsedMs: workerResult.workerElapsedMs,
      maxGap,
    };
  });

  assert(ai.lethalPlan.length >= 2 && ai.lethalPlan.every((action) => action.type === 'attack-hero'), 'AI missed a forced two-attacker lethal.');
  assert(ai.targetId === 'engine', `AI selected the wrong removal target: ${ai.targetId}`);
  assert(ai.curvePlan.filter((action) => action.type === 'play-card').length >= 2, `Hard AI failed to sequence its stronger two-card curve: ${JSON.stringify(ai.curvePlan)}`);
  assert(!ai.workerFallback, 'AI worker fell back during strategic validation.');
  assert(ai.maxGap < 100, `AI planning blocked the UI thread for ${ai.maxGap.toFixed(1)}ms.`);
  assert(errors.length === 0, `Browser errors detected: ${errors.join(' | ')}`);

  const result = { fresh, interrupted, established, ai, errors };
  fs.writeFileSync(path.join(output, 'results.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result, null, 2));
  await browser.close();
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
