const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('C:/Users/jadon/.codex/skills/develop-web-game/scripts/node_modules/playwright');

const ROOT_URL = 'http://127.0.0.1:8137';

(async () => {
  const output = path.resolve('output/web-game/ai-card-versions');
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1980, height: 1080 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
  page.on('console', (message) => {
    if (message.type() === 'error') errors.push(`console: ${message.text()}`);
  });

  await page.goto(`${ROOT_URL}/index.html`, { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.click('#open-dev-wip-ui-main-btn');
  await page.waitForSelector('#dev-wip-ui-modal:not(.hidden)');
  await page.waitForTimeout(850);

  const styleResults = {};
  for (const style of ['v1', 'v2', 'v3']) {
    await page.selectOption('[data-dev-wip-field="styleMode"]', style);
    await page.waitForTimeout(450);
    const result = await page.evaluate(() => {
      const hand = document.querySelector('[data-hand-root="primary"]');
      const face = hand?.querySelector('.cf-ornate-card-face');
      const frame = face?.querySelector('.cf-hand-card-frame');
      const rules = face?.querySelector('.cf-hand-card-text');
      const profile = JSON.parse(localStorage.getItem('cardforge.profile.v1') || '{}');
      return {
        styleMode: hand?.dataset.styleMode,
        controlStyle: document.querySelector('[data-dev-wip-field="styleMode"]')?.value,
        persistedStyle: profile?.settings?.cardPresentation?.styleMode,
        textSize: hand?.dataset.textSize,
        frameDisplay: frame ? getComputedStyle(frame).display : null,
        rulesFontPx: rules ? Number.parseFloat(getComputedStyle(rules).fontSize) : 0,
        faceDisplay: face ? getComputedStyle(face).display : null,
      };
    });
    styleResults[style] = result;
    await page.screenshot({ path: path.join(output, `${style}.png`), fullPage: false });
  }

  await page.evaluate(() => {
    localStorage.setItem('cardforge.profile.v1', JSON.stringify({
      starterDeckId: 'rook-teaching-archive',
      starterDefenseDeckId: 'rook-teaching-archive',
      settings: { cardPresentation: { styleMode: 'v3', textSize: 'large', hoverScale: 1.18 } },
    }));
    localStorage.setItem('cardforge.match.opponent.v1', 'rook');
    localStorage.setItem('cardforge.match.context.v1', JSON.stringify({
      aiProfileId: 'rook',
      modeModel: 'duel',
      battleType: 'wielder_duel',
      rulesetId: 'wielder-duel',
      rulesetName: 'Rook Teaching Convergence',
      deckSize: 40,
      threatDeckSize: 40,
      maxCopiesPerCard: 4,
      startingMana: 5,
      startingHand: 5,
      enableResponseWindows: true,
      metadata: { foundationStage: 'rook_tutorial' },
    }));
  });
  await page.goto(`${ROOT_URL}/game/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('#app:not(.hidden)', { timeout: 20000 });
  await page.waitForTimeout(800);
  const focusTarget = page.locator('#hand .cf-hand-card').nth(2);
  const focusBox = await focusTarget.boundingBox();
  if (!focusBox) throw new Error('Could not measure a live hand card.');
  await page.mouse.move(focusBox.x + (focusBox.width / 2), focusBox.y + (focusBox.height / 2));
  await page.waitForFunction(() => document.querySelectorAll('#hand .cf-hand-card.is-hovered').length === 1);
  await page.waitForTimeout(420);
  const handFocus = await page.evaluate(() => {
    const hovered = document.querySelector('#hand .cf-hand-card.is-hovered');
    const text = hovered?.querySelector('.cf-hand-card-text');
    return {
      hoveredCount: document.querySelectorAll('#hand .cf-hand-card.is-hovered').length,
      hoveredName: hovered?.querySelector('.cf-hand-card-name')?.textContent?.trim() ?? null,
      rulesFontPx: text ? Number.parseFloat(getComputedStyle(text).fontSize) : 0,
      cardHeight: hovered?.getBoundingClientRect().height ?? 0,
      styleMode: document.querySelector('#hand')?.dataset.styleMode,
    };
  });
  await page.screenshot({ path: path.join(output, 'duel-v3-hover.png'), fullPage: false });
  await page.mouse.move(12, 12);
  await page.waitForTimeout(160);
  await page.evaluate(() => {
    window.__aiFrameProbe = { last: performance.now(), gaps: [], active: true };
    const tick = (now) => {
      const probe = window.__aiFrameProbe;
      if (!probe?.active) return;
      probe.gaps.push(now - probe.last);
      probe.last = now;
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
  await page.click('#end-turn');
  await page.waitForFunction(() => {
    const state = JSON.parse(window.render_game_to_text());
    return state.turn === 'player' && state.mana.max >= 6;
  }, null, { timeout: 15000 });
  await page.waitForTimeout(350);
  const aiResult = await page.evaluate(() => {
    window.__aiFrameProbe.active = false;
    const gaps = window.__aiFrameProbe.gaps.slice(2);
    const state = JSON.parse(window.render_game_to_text());
    return {
      maxFrameGapMs: Math.max(0, ...gaps),
      frameSamples: gaps.length,
      workerElapsedMs: state.ai.workerElapsedMs,
      workerFallback: state.ai.workerFallback,
      enemyBoardCount: state.enemy.board.length,
      enemyArchiveCount: state.enemy.archiveCount,
      turn: state.turn,
    };
  });
  await page.screenshot({ path: path.join(output, 'duel-after-ai.png'), fullPage: false });

  const summary = { styleResults, handFocus, aiResult, errors };
  fs.writeFileSync(path.join(output, 'summary.json'), JSON.stringify(summary, null, 2));
  await browser.close();

  for (const style of ['v1', 'v2', 'v3']) {
    if (styleResults[style].styleMode !== style) throw new Error(`${style} did not apply: ${JSON.stringify(styleResults[style])}`);
    if (styleResults[style].rulesFontPx < 11) throw new Error(`${style} rules text is too small: ${JSON.stringify(styleResults[style])}`);
  }
  if (styleResults.v3.frameDisplay === 'none') throw new Error('V3 image frame is hidden.');
  if (styleResults.v1.frameDisplay !== 'none' || styleResults.v2.frameDisplay !== 'none') throw new Error('V1/V2 must not use the image frame.');
  if (handFocus.hoveredCount !== 1 || handFocus.rulesFontPx < 11 || handFocus.cardHeight < 330) throw new Error(`Hand focus is not readable: ${JSON.stringify(handFocus)}`);
  if (aiResult.turn !== 'player' || aiResult.workerFallback) throw new Error(`AI turn did not complete in its worker: ${JSON.stringify(aiResult)}`);
  if (aiResult.maxFrameGapMs > 350) throw new Error(`AI blocked the UI thread for ${aiResult.maxFrameGapMs.toFixed(1)}ms.`);
  if (errors.length) throw new Error(errors.join('\n'));
  console.log(JSON.stringify(summary));
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
