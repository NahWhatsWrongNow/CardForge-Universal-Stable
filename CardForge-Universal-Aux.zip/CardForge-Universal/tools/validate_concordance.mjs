import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  buildAiPublicSnapshot,
  calculateEffectiveCost,
  canBlockAttacker,
  commanderAttackLegality,
  createConvergenceRulesEngine,
} from '../game/engine/convergence_rules.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const json = (name) => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));

function validateMana() {
  const state = {
    mana: 9,
    maxMana: 9,
    playerTemporaryMana: 0,
    enemyMana: 9,
    enemyMaxMana: 9,
    enemyTemporaryMana: 0,
    fairnessAudit: [],
  };
  const rules = createConvergenceRulesEngine(state);
  assert.equal(rules.beginManaStep('player').maximum, 10);
  assert.equal(rules.beginManaStep('player').maximum, 11);
  assert.equal(rules.beginManaStep('player').maximum, 12);
  rules.gainTemporaryMana('player', 3);
  const spend = rules.spendMana('player', 2);
  assert.equal(spend.temporarySpent, 2);
  assert.equal(rules.expireTemporaryMana('player').current, 12);
  assert.equal(calculateEffectiveCost({ cost: 7 }, 0), 7);
  state.enemyMana = 2;
  assert.equal(rules.validateCardPlay({ side: 'enemy', card: { cost: 7 }, phase: 'main1' }).ok, false);
}

function validateFairnessFirewall() {
  const state = {
    enemyHand: [{ id: 'enemy-known' }],
    enemyDeck: [{ id: 'enemy-top-secret' }],
    hand: [{ id: 'player-secret-hand' }],
    playerDeck: [{ id: 'player-secret-top' }],
    enemyMinions: [], playerMinions: [], enemyFields: [], playerFields: [], enemyRelics: [], playerRelics: [],
  };
  const snapshot = buildAiPublicSnapshot(state, 'enemy');
  assert.equal(snapshot.enemyHand[0].id, 'enemy-known');
  assert.equal(snapshot.hand[0].hidden, true);
  assert.equal(snapshot.hand[0].id.includes('player-secret'), false);
  assert.equal(snapshot.playerDeck[0].hidden, true);
  assert.equal(snapshot.playerDeck[0].id.includes('player-secret'), false);
}

function validateCombatRules() {
  const attacker = { id: 'a', health: 3 };
  assert.equal(commanderAttackLegality(attacker, [{ id: 'ordinary', health: 4 }]).ok, true);
  assert.equal(commanderAttackLegality(attacker, [{ id: 'guard', health: 4, guard: true }]).ok, false);
  assert.equal(canBlockAttacker(attacker, { id: 'ready', health: 2 }, { usedAttacks: 0 }), true);
  assert.equal(canBlockAttacker(attacker, { id: 'spent', health: 2 }, { usedAttacks: 1 }), false);
  assert.equal(canBlockAttacker({ flying: true }, { id: 'ground', health: 2 }, { usedAttacks: 0 }), false);
  assert.equal(canBlockAttacker({ flying: true }, { id: 'reach', health: 2, reach: true }, { usedAttacks: 0 }), true);
}

function validateArchives() {
  const cards = json('packs/concordant_foundations.json').cards;
  const decks = json('game/deck_packs/concordant_archives.json').decks;
  const byId = new Map(cards.map((card) => [card.id, card]));
  const total = (deck) => deck.entries.reduce((sum, entry) => sum + entry.count, 0);
  assert.equal(total(decks.find((deck) => deck.id === 'frontier-doctrine')), 100);
  assert.equal(total(decks.find((deck) => deck.id === 'agony-red-wake')), 100);
  const tutorial = decks.find((deck) => deck.id === 'rook-teaching-archive');
  assert.equal(tutorial.entries.length, 25);
  assert.equal(total(tutorial), 100);
  const totals = { minion: 0, action: 0, structure: 0, cost: 0 };
  tutorial.entries.forEach((entry) => {
    const card = byId.get(entry.cardId);
    assert.ok(card, `Missing canonical card ${entry.cardId}`);
    totals.cost += card.cost * entry.count;
    if (card.type === 'minion') totals.minion += entry.count;
    else if (card.type === 'structure') totals.structure += entry.count;
    else totals.action += entry.count;
  });
  assert.deepEqual({ minion: totals.minion, action: totals.action, structure: totals.structure }, { minion: 64, action: 32, structure: 4 });
  assert.equal(totals.cost / 100, 3.12);
  assert.equal(byId.get('rook-reinforcement-call').type, 'spell');
  assert.equal(byId.get('rook-clean-shot').text, 'Deal 2 damage to an enemy unit. Cannot target commanders.');

  for (const id of ['glasswake-salvage-line', 'veyr-surveyor-protocol']) {
    const deck = decks.find((entry) => entry.id === id);
    assert.ok(deck, `Missing story Archive ${id}`);
    assert.equal(total(deck), 100, `${id} must contain 100 cards`);
    assert.ok(deck.entries.every((entry) => entry.count <= 4), `${id} exceeds the four-copy limit`);
    deck.entries.forEach((entry) => assert.ok(byId.has(entry.cardId), `${id} references missing card ${entry.cardId}`));
  }
}

function validateNarrativeAndStoryBattles() {
  const story = json('data/narrative/concordance_campaign.json');
  const nodeIds = new Set(story.nodes.map((node) => node.id));
  assert.equal(nodeIds.size, story.nodes.length, 'Narrative node IDs must be unique');
  story.nodes.forEach((node) => {
    if (node.next) assert.ok(nodeIds.has(node.next), `${node.id} points to missing node ${node.next}`);
    (node.choices ?? []).forEach((choice) => {
      if (choice.next) assert.ok(nodeIds.has(choice.next), `${node.id} choice points to missing node ${choice.next}`);
    });
  });
  for (const id of [
    'agony-defeat-1',
    'agony-loss-1',
    'act1-glasswake-victory-1',
    'act1-veyr-choice',
    'act1-relay-victory-1',
    'act1-anchorage-choice',
    'act1-accord-decision',
    'act1-complete',
  ]) assert.ok(nodeIds.has(id), `Missing required narrative node ${id}`);

  const aiIndex = json('game/ai_packs/index.json').entries;
  const decks = json('game/deck_packs/concordant_archives.json').decks;
  const deckIds = new Set(decks.map((deck) => deck.id));
  for (const file of ['glasswake_scavengers.json', 'veyr.json', 'relay_nine.json']) {
    assert.ok(aiIndex.includes(file), `AI index omits ${file}`);
    const profile = json(`game/ai_packs/${file}`);
    assert.ok(deckIds.has(profile.deckId), `${profile.id} references missing Archive ${profile.deckId}`);
    assert.equal(profile.aiFairness.usesSharedRules, true);
    assert.equal(profile.aiFairness.seesOpponentHand, false);
    assert.equal(profile.aiFairness.seesOpponentDeckOrder, false);
    assert.equal(profile.aiFairness.manaModifier, 0);
    assert.equal(profile.aiFairness.statModifier, 0);
  }

  const campaignSource = fs.readFileSync(path.join(root, 'campaign_foundation.js'), 'utf8');
  const gameSource = fs.readFileSync(path.join(root, 'game/game.js'), 'utf8');
  assert.match(campaignSource, /id:\s*'glasswake-evacuation-route'/);
  assert.match(campaignSource, /targetRounds:\s*6/);
  assert.match(gameSource, /function advanceMissionObjectiveAfterEnemyTurn\(\)/);
  assert.match(gameSource, /victoryReason:\s*objectiveVictory \? 'mission-objective'/);
}

function validateAssetsAndRuntimeGuards() {
  [
    'assets/concordance/original/card_border1.png',
    'assets/concordance/original/agony_crimson_raider.png',
    'assets/concordance/original/card_back.png',
    'assets/concordance/original/rook_shattered_realms.png',
    'assets/concordance/derived/universal_card_frame.webp',
    'assets/concordance/derived/standard_card_back.webp',
    'assets/concordance/derived/rook_portrait.webp',
    'assets/concordance/derived/agony_portrait.webp',
  ].forEach((name) => assert.ok(fs.statSync(path.join(root, name)).size > 0, `${name} is empty`));
  const gameSource = fs.readFileSync(path.join(root, 'game/game.js'), 'utf8');
  assert.equal(gameSource.includes('MAX_EXPANSE_COLUMNS'), false);
  assert.equal(gameSource.includes('if (enemyFront.length > 0) return { ok: false, code: \'blocked_frontline\''), false);
  assert.equal(/new\s+Audio\s*\(/.test(gameSource), false);
}

validateMana();
validateFairnessFirewall();
validateCombatRules();
validateArchives();
validateNarrativeAndStoryBattles();
validateAssetsAndRuntimeGuards();
console.log('Concordance validation passed: mana, fairness, combat, Archives, story battles, assets, and runtime guards.');
