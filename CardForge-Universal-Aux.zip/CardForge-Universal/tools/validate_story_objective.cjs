const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('C:/Users/jadon/.codex/skills/develop-web-game/scripts/node_modules/playwright');

const baseUrl = process.env.CARDFORGE_URL || 'http://127.0.0.1:8138';
const outDir = path.resolve('output/web-game/glasswake-objective-validation');
fs.mkdirSync(outDir, { recursive: true });

(async () => {
  const consoleErrors = [];
  const pageErrors = [];
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
  page.on('console', (message) => {
    if (message.type() === 'error') consoleErrors.push(message.text());
  });
  page.on('pageerror', (error) => pageErrors.push(String(error)));

  try {
    await page.goto(`${baseUrl}/index.html`, { waitUntil: 'domcontentloaded' });
    await page.evaluate(() => {
      const profile = JSON.parse(localStorage.getItem('cardforge.profile.v1') || '{}');
      profile.starterDeckId = profile.starterDeckId || 'lumen-bastion-sol';
      profile.defeatedAiIds = (profile.defeatedAiIds || []).filter((id) => id !== 'glasswake-scavengers');
      profile.lobbyResidents = (profile.lobbyResidents || []).filter((id) => id !== 'glasswake-scavengers');
      localStorage.setItem('cardforge.profile.v1', JSON.stringify(profile));
      localStorage.setItem('cardforge.match.opponent.v1', 'glasswake-scavengers');
      localStorage.setItem('cardforge.match.context.v1', JSON.stringify({
        aiProfileId: 'glasswake-scavengers',
        modeModel: 'duel',
        battleType: 'wielder_duel',
        rulesetId: 'wielder-duel',
        rulesetName: 'Evacuation at Glasswake',
        deckSize: 100,
        threatDeckSize: 100,
        maxCopiesPerCard: 4,
        startingMana: 1,
        startingHand: 5,
        enableResponseWindows: true,
        aiSkillStars: 2,
        metadata: {
          foundationStage: 'story_operation',
          operationId: 'glasswake-evacuation',
          objective: 'Protect the evacuation route for 6 rounds or defeat the strip crew.',
          missionObjective: {
            id: 'glasswake-evacuation-route',
            type: 'survive-rounds',
            label: 'Evacuation Route',
            description: 'Keep the route open through 6 completed enemy turns.',
            targetRounds: 6,
          },
        },
      }));
    });

    await page.goto(`${baseUrl}/game/index.html?autostart=1`, { waitUntil: 'domcontentloaded' });
    try {
      await page.waitForFunction(() => typeof window.__cardforgeDebug?.advanceMissionObjective === 'function'
        && !document.querySelector('#app')?.classList.contains('hidden'), null, { timeout: 30000 });
    } catch (error) {
      const diagnostics = await page.evaluate(() => ({
        url: location.href,
        bootStatus: document.querySelector('#boot-status')?.textContent,
        bootFiles: document.querySelector('#boot-files')?.innerText,
        bootFailed: document.querySelector('#boot-loading')?.classList.contains('boot-failed'),
        appHidden: document.querySelector('#app')?.classList.contains('hidden'),
        titleHidden: document.querySelector('#title-screen')?.classList.contains('hidden'),
        hasDebug: typeof window.__cardforgeDebug?.advanceMissionObjective === 'function',
      }));
      await page.screenshot({ path: path.join(outDir, 'boot-timeout.png'), fullPage: false });
      console.error(JSON.stringify({ diagnostics, consoleErrors, pageErrors }, null, 2));
      throw error;
    }

    const initial = JSON.parse(await page.evaluate(() => window.render_game_to_text()));
    assert.equal(initial.missionObjective?.completedRounds, 0);
    assert.equal(initial.missionObjective?.targetRounds, 6);
    assert.match(await page.locator('#mission-objective-chip').innerText(), /Evacuation Route: 0\/6 rounds/);

    const roundFive = await page.evaluate(() => window.__cardforgeDebug.advanceMissionObjective(5));
    assert.equal(roundFive.completedRounds, 5);
    assert.equal(roundFive.matchResolved, false);
    await page.screenshot({ path: path.join(outDir, 'objective-five-rounds.png'), fullPage: false });

    const complete = await page.evaluate(() => window.__cardforgeDebug.advanceMissionObjective(1));
    assert.equal(complete.status, 'completed');
    assert.equal(complete.matchResolved, true);

    const resolved = await page.evaluate(() => ({
      result: JSON.parse(localStorage.getItem('cardforge.match.result.v1') || 'null'),
      profile: JSON.parse(localStorage.getItem('cardforge.profile.v1') || '{}'),
      game: JSON.parse(window.render_game_to_text()),
    }));
    assert.equal(resolved.result?.result, 'win');
    assert.equal(resolved.result?.metadata?.victoryReason, 'mission-objective');
    assert.equal(resolved.result?.metadata?.objectiveResult?.completedRounds, 6);
    assert.ok(resolved.game.enemy.health > 0, 'Objective victory must not fake commander defeat');
    assert.equal((resolved.profile.defeatedAiIds || []).includes('glasswake-scavengers'), false);
    assert.equal((resolved.profile.lobbyResidents || []).includes('glasswake-scavengers'), false);
    assert.deepEqual(consoleErrors, []);
    assert.deepEqual(pageErrors, []);

    fs.writeFileSync(path.join(outDir, 'result.json'), JSON.stringify({
      initialObjective: initial.missionObjective,
      roundFive,
      complete,
      victoryReason: resolved.result.metadata.victoryReason,
      enemyHealthAtCompletion: resolved.game.enemy.health,
      storyAiUnlocked: false,
      consoleErrors,
      pageErrors,
    }, null, 2));
    console.log('Glasswake objective validation passed.');
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
