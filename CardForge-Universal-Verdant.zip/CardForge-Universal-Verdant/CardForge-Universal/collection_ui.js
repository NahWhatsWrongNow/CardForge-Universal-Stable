(function(global) {
  'use strict';
  const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const colors = {fire:'#e59166',flame:'#e59166',water:'#60c3dd',earth:'#b4bf82',forest:'#80c29c',storm:'#94bfff',light:'#eddaa0',shadow:'#aa9fc7',dark:'#aa9fc7'};
  let adapter = null;
  let opening = null;
  const ownedCount = (profile,id) => Math.max(0, Number(profile.collection?.[id] || 0));
  const rarity = card => card.boosterRarity === 'mythic' ? 'mythic' : card.rarity || 'common';
  function cardMarkup(card, info = '') {
    const color = colors[String(card.element).toLowerCase()] || '#92b4c7';
    const cost = card.cost ?? card.manaCost ?? 0;
    return `<div class="archive-card" data-rarity="${esc(rarity(card))}" style="--card-accent:${color}">
      <header><strong>${esc(card.name || card.id)}</strong><b class="archive-cost">${esc(cost)}</b></header>
      <div class="archive-art" data-element="${esc(card.element)}"><i></i><span>${esc(String(card.element || 'neutral').toUpperCase())}</span></div>
      <div class="archive-type">${esc(card.type || 'Card')} <span>${esc(rarity(card))}</span></div>
      <p>${esc(card.text || (card.type === 'minion' ? 'A stalwart presence on the battlefield.' : 'Inspect this card for its full rules.'))}</p>
      <footer><span>${esc(card.attack ?? '-')} ATK</span><span>${esc(card.def ?? card.baseDef ?? '-')} DEF</span><span>${esc(card.health ?? '-')} HP</span></footer>
      <div class="archive-caption">${info}</div></div>`;
  }
  function modal(title, className) {
    const dialog = document.createElement('dialog');
    dialog.className = `collection-dialog ${className}`;
    dialog.setAttribute('aria-label',title);
    document.body.append(dialog);
    const previous = document.activeElement;
    dialog.addEventListener('close',()=>{dialog.remove(); previous?.focus?.();});
    dialog.showModal();
    return dialog;
  }
  function catalog(profile, input) {
    const byId = new Map(input.map(card => [card.id,card]));
    for(const pack of profile.customPackDefs || []) for(const card of pack.cards || []) byId.set(card.id,card);
    for(const id of Object.keys(profile.collection || {})) if(!byId.has(id)) byId.set(id,{id,name:id,type:'Archived card',text:'Definition unavailable in the loaded packs. Ownership is preserved.'});
    return [...byId.values()];
  }
  function inspect(card) {
    const dialog=modal(card.name,'card-detail-dialog');
    dialog.innerHTML = `<button class="collection-close" aria-label="Close inspect">Close</button>${cardMarkup(card)}<section><h2>${esc(card.name)}</h2><p>${esc(card.text || 'No additional rules.')}</p><p>${esc(card.collectionName || card.packSource || 'CardForge archive')}</p><p>${esc(card.campaignMeta?.generatedConquestOnly || card.mode === 'conquest' ? 'Conquest only. Not legal in Local Multiplayer.' : 'Card legality is checked by the selected game mode.')}</p></section>`;
    dialog.querySelector('button').onclick=()=>dialog.close();
  }
  async function inventory() {
    if(!adapter) return;
    const dialog = modal('Collected cards','inventory-dialog');
    dialog.innerHTML='<p>Loading your archive...</p>';
    try {
      const input = await adapter.getCatalog();
      if (!dialog.isConnected) return;
      let page=0;
      dialog.innerHTML = `<header class="collection-head"><div><small>YOUR COLLECTION / CARD ARCHIVE</small><h1>The Vault</h1><p data-inventory-total></p></div><button class="collection-close">Close</button></header>
        <div class="collection-filters"><input aria-label="Search collected cards" placeholder="Find a card, element, lineage..." type="search"><select aria-label="Filter rarity"><option value="">All rarities</option>${['common','uncommon','rare','epic','legendary','mythic'].map(r=>`<option>${r}</option>`).join('')}</select><select aria-label="Sort collection"><option value="recent">Recently acquired</option><option value="name">Name</option><option value="copies">Most copies</option><option value="cost">Mana cost</option></select><span data-inventory-page></span></div>
        <div class="vault-grid"></div><footer class="collection-pagination"><button data-prev>Previous</button><span data-range></span><button data-next>Next page</button></footer>`;
      const [search, filter, sort] = dialog.querySelectorAll('.collection-filters input, .collection-filters select');
      const render = () => {
        const profile=adapter.getProfile();
        const owned=catalog(profile,input).filter(c=>ownedCount(profile,c.id)>0);
        const copies=owned.reduce((n,c)=>n+ownedCount(profile,c.id),0);
        dialog.querySelector('[data-inventory-total]').textContent=`${copies.toLocaleString()} cards collected / ${owned.length.toLocaleString()} unique designs. Every unlock belongs here.`;
        const query=search.value.toLowerCase();
        const cards=owned.filter(c=>(!filter.value || rarity(c)===filter.value) && `${c.name} ${c.element} ${c.type} ${c.campaignMeta?.lineageId || ''}`.toLowerCase().includes(query));
        cards.sort((a,b)=> sort.value==='name' ? String(a.name).localeCompare(String(b.name)) : sort.value==='copies' ? ownedCount(profile,b.id)-ownedCount(profile,a.id) : sort.value==='cost' ? Number(a.cost||0)-Number(b.cost||0) : Number(profile.cardAcquiredAt?.[b.id]||0)-Number(profile.cardAcquiredAt?.[a.id]||0));
        const pages=Math.max(1,Math.ceil(cards.length/36)); page=Math.min(page,pages-1);
        const visible=cards.slice(page*36,page*36+36);
        dialog.querySelector('.vault-grid').innerHTML = visible.length ? visible.map((c,i)=>`<button class="vault-slot" data-index="${i}" aria-label="Inspect ${esc(c.name)}">${cardMarkup(c,`<b>${ownedCount(profile,c.id)} owned</b><span>${esc(c.packSource || c.collectionName || 'Archive')}</span>`)}</button>`).join('') : '<p class="collection-empty">Your archive is waiting.<br>Open a pack or unlock a card to begin this collection.</p>';
        dialog.querySelectorAll('[data-index]').forEach(node=>{node.onclick=()=>inspect(visible[Number(node.dataset.index)]);});
        dialog.querySelector('[data-inventory-page]').textContent=`${cards.length} matching designs`;
        dialog.querySelector('[data-range]').textContent=`Page ${page+1} / ${pages}`;
        dialog.querySelector('[data-prev]').disabled=page===0;
        dialog.querySelector('[data-next]').disabled=page===pages-1;
      };
      for(const control of [search,filter,sort]) control.addEventListener('input',()=>{page=0;render();});
      dialog.querySelector('[data-prev]').onclick=()=>{page--;render();dialog.scrollTop=0;};
      dialog.querySelector('[data-next]').onclick=()=>{page++;render();dialog.scrollTop=0;};
      dialog.querySelector('.collection-close').onclick=()=>dialog.close();
      render();
    } catch(error) { dialog.innerHTML=`<p>${esc(error.message)}</p><button>Close</button>`;dialog.querySelector('button').onclick=()=>dialog.close(); }
  }
  function openPack(payload, title = 'Booster acquired') {
    if(opening) return opening;
    const dialog=modal(title,'pack-dialog');
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
    let revealed=false;
    const reveal = () => {
      if(revealed) return;
      revealed=true;
      dialog.classList.add('is-revealed');
      dialog.querySelector('.pack-stage').hidden=true;
      const grid=dialog.querySelector('.pack-cards'); grid.hidden=false;
      grid.innerHTML=payload.map((entry,i)=>`<button class="pack-pull" style="--reveal-delay:${reduced?0:Math.min(i*65,650)}ms" data-index="${i}">${cardMarkup(entry.card,`${entry.isNew?'<b class="new-collection-badge">NEW</b>':'<b>COLLECTED</b>'}<span>${esc(entry.copies ? `${entry.copies} owned` : rarity(entry.card))}</span>`)}</button>`).join('');
      grid.querySelectorAll('button').forEach(node=>{node.onclick=()=>inspect(payload[Number(node.dataset.index)].card);});
      dialog.querySelector('[data-pack-state]').textContent=`${payload.length} cards secured / ${payload.filter(e=>e.isNew).length} new designs`;
      dialog.querySelector('[data-reveal]').hidden=true;
      dialog.querySelector('[data-vault]').hidden=false;
    };
    dialog.innerHTML=`<header class="collection-head"><div><small>CARDFORGE / UNSEAL THE UNKNOWN</small><h1>${esc(title)}</h1><p data-pack-state>Cards are already saved to your collection.</p></div><button class="collection-close">Close</button></header>
      <div class="pack-stage"><button class="sealed-pack" aria-label="Tear open pack"><span class="pack-tear">PULL TO OPEN / CARDFORGE</span><span class="pack-shell"><small>DIMENSIONAL ARCHIVE</small><i></i><strong>BEYOND<br>THE VEIL</strong><span>${payload.length} CARDS / SEALED BOOSTER</span></span></button><p>Pull across the seal, or click to tear it open.</p></div>
      <div class="pack-cards" hidden></div><footer class="pack-actions"><span>Saved before opening. Nothing can be lost by skipping.</span><button data-reveal>Reveal all</button><button data-vault hidden>View inventory</button></footer>`;
    let tearing=false, startX=null;
    const seal=dialog.querySelector('.sealed-pack');
    const tear=async()=>{
      if(tearing || revealed) return; tearing=true;
      seal.classList.add('is-torn');
      if(!reduced) await new Promise(resolve=>setTimeout(resolve,620));
      if(dialog.isConnected) reveal();
    };
    seal.onclick=tear;
    seal.onpointerdown=e=>{startX=e.clientX;seal.setPointerCapture(e.pointerId);};
    seal.onpointermove=e=>{if(startX!==null && e.buttons && Math.abs(e.clientX-startX)>65) tear();};
    seal.onpointerup=seal.onpointercancel=()=>{startX=null;};
    dialog.querySelector('[data-reveal]').onclick=reveal;
    dialog.querySelector('[data-vault]').onclick=()=>{dialog.close();inventory();};
    dialog.querySelector('.collection-close').onclick=()=>dialog.close();
    opening=new Promise(resolve=>dialog.addEventListener('close',()=>{opening=null;resolve();},{once:true}));
    return opening;
  }
  function mountShop(host, options) {
    adapter=options;
    host.classList.add('collection-shop');
    const old=[...host.children]; old.forEach(node=>node.classList.add('standard-stock'));
    const chrome=document.createElement('section');chrome.className='shop-chrome';
    const profile=adapter.getProfile();
    chrome.innerHTML=`<header class="collection-head"><div><small>THE EXCHANGE / BOOSTER ATELIER</small><h1>Choose your next discovery.</h1><p>Authored collections. Uncharted possibilities. Every card is yours to keep.</p></div><div class="shop-wallet"><b>${Number(profile.economy?.gold||0).toLocaleString()} GOLD</b><button data-inventory>Open inventory</button></div></header><nav class="shop-tabs"><button aria-pressed="true" data-stock="standard">Collection boosters</button><button aria-pressed="false" data-stock="random">Random Booster</button></nav><section class="random-stock" hidden><div class="random-pack-preview"><small>PROCEDURAL SERIES / 01</small><strong>RANDOM<br>BOOSTER</strong><span>Fifteen discoveries. One new direction.</span></div><div class="random-pack-detail"><small>ADAPTIVE, NOT OVERPOWERED</small><h2>Open the unexpected.</h2><p>Three common slots favor your least-collected element. Costs, stats and abilities stay inside fixed budgets. No procedural heroes or EVO cards.</p><ol><li>10 common cards</li><li>3 uncommon cards</li><li>1 rare (87.5%) or mythic (12.5%)</li><li>1 resource card: a CardForge Mana Field, not a conquest mana land</li></ol><p>Classic draft-style slot order. Mythic uses CardForge's Legendary tier. Adaptation changes variety, never power or rarity odds.</p><button class="purchase-random">Open Random Booster / 180 gold</button><p class="shop-notice" role="status"></p></div></section>`;
    host.prepend(chrome);
    chrome.querySelector('[data-inventory]').onclick=inventory;
    chrome.querySelectorAll('[data-stock]').forEach(button=>button.onclick=()=>{
      const random=button.dataset.stock==='random';
      old.forEach(node=>node.hidden=random);
      chrome.querySelector('.random-stock').hidden=!random;
      chrome.querySelectorAll('[data-stock]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
    });
    const buy=chrome.querySelector('.purchase-random');
    buy.disabled=Number(profile.economy?.gold||0)<180;
    buy.onclick=async()=>{
      if(buy.disabled) return; buy.disabled=true;
      try {
        const input=await adapter.getCatalog();
        const live=structuredClone(adapter.getProfile());
        const result=global.CardForgeBoosters.buy(live,catalog(live,input));
        // Commit cost, definitions, ownership and stats before presenting the reward.
        if (adapter.saveProfile(live) === false) throw new Error('Unable to save this purchase. Free browser storage and try again.');
        await openPack(result.reveal,'Random Booster');
        await adapter.refresh?.();
      } catch(error) {chrome.querySelector('.shop-notice').textContent=error.message;buy.disabled=false;}
    };
  }
  global.CardForgeCollection = {configure:options=>{adapter=options;}, inventory, inspect, openPack, mountShop, cardMarkup};
})(window);
