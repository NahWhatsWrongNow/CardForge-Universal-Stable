(function attachCommandCenter(global) {
  const campaignApi = global.CardForgeCampaignState;
  if (!campaignApi) return;

  const dom = {
    shell: document.getElementById('command-center-shell'),
    loading: document.getElementById('command-center-loading'),
    loadingSteps: document.getElementById('command-center-loading-steps'),
    topbar: document.getElementById('command-center-topbar'),
    leftNav: document.getElementById('command-center-left-nav'),
    main: document.getElementById('command-center-main-view'),
    right: document.getElementById('command-center-right-panel'),
    bottom: document.getElementById('command-center-bottom-bar'),
    toast: document.getElementById('command-center-toast'),
    turnModal: document.getElementById('command-center-turn-modal'),
    continueBtn: document.getElementById('continue-game-btn'),
    confirmNewBtn: document.getElementById('confirm-new-game-btn'),
    deckVaultBtn: document.getElementById('open-deck-vault-btn'),
    forgeBtn: document.getElementById('open-forge-main-btn'),
    codexBtn: document.getElementById('open-codex-main-btn'),
    settingsBtn: document.getElementById('open-settings-main-btn'),
    devWipBtn: document.getElementById('open-dev-wip-ui-main-btn'),
    exitBtn: document.getElementById('exit-game-btn'),
    commandCenterBtn: document.getElementById('open-command-center-btn'),
    devWipTrigger: document.getElementById('open-dev-wip-ui-btn'),
    cardUiTrigger: document.getElementById('open-card-ui-settings-btn'),
  };

  let launcherBootstrapPromise = null;

  const uiState = {
    open: false,
    activityTab: 'alerts',
    toastTimer: null,
    currentState: null,
  };

  function scriptUrl(pathname) {
    try {
      const url = new URL(pathname, global.location.href);
      url.searchParams.set('cc_retry', String(Date.now()));
      return url.toString();
    } catch {
      return `${pathname}?cc_retry=${Date.now()}`;
    }
  }

  async function loadRuntimeScript(pathname, readyCheck) {
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const url = scriptUrl(pathname);
      try {
        const response = await global.fetch(url, { cache: 'no-store' });
        if (!response.ok) throw new Error(`${pathname} fetch failed with ${response.status}`);
        const source = await response.text();
        if (!source.trim()) throw new Error(`${pathname} fetch returned empty source.`);
        global.eval(`${source}\n//# sourceURL=${url}`);
        await new Promise((resolve) => global.setTimeout(resolve, 60));
        if (readyCheck()) return true;
      } catch (error) {
        lastError = error;
      }
      await new Promise((resolve) => global.setTimeout(resolve, 120));
    }
    if (lastError) throw lastError;
    return false;
  }

  async function ensureLauncherRuntime(requiredFns = []) {
    const required = Array.isArray(requiredFns) ? requiredFns.filter(Boolean) : [];
    if (required.every((name) => typeof global?.[name] === 'function')) return true;
    if (launcherBootstrapPromise) {
      try {
        await launcherBootstrapPromise;
      } catch {}
      return required.every((name) => typeof global?.[name] === 'function');
    }
    launcherBootstrapPromise = (async () => {
      if (typeof global.CardForgeCardPresentation !== 'object') {
        await loadRuntimeScript('./card_presentation_shared.js', () => typeof global.CardForgeCardPresentation === 'object');
      }
      if (required.every((name) => typeof global?.[name] === 'function')) return true;
      await loadRuntimeScript('./launcher.js', () => required.every((name) => typeof global?.[name] === 'function'));
      return required.every((name) => typeof global?.[name] === 'function');
    })();
    try {
      await launcherBootstrapPromise;
    } catch (error) {
      console.warn('Command Center could not rehydrate launcher runtime.', error);
    } finally {
      launcherBootstrapPromise = null;
    }
    return required.every((name) => typeof global?.[name] === 'function');
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function toArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function pageMeta(pageId) {
    return campaignApi.PAGE_META?.[pageId] ?? campaignApi.PAGE_META?.home ?? { id: 'home', route: '#/command', label: 'Dashboard', icon: '⬢' };
  }

  function actionAttrs(action, extras = {}) {
    const attrs = [`data-command-action="${escapeHtml(action)}"`];
    Object.entries(extras).forEach(([key, value]) => {
      if (value === undefined || value === null || value === '') return;
      attrs.push(`data-${escapeHtml(key)}="${escapeHtml(value)}"`);
    });
    return attrs.join(' ');
  }

  function buttonMarkup(label, action, tone = 'command-button-secondary', extras = {}) {
    return `<button type="button" class="${tone}" ${actionAttrs(action, extras)}>${escapeHtml(label)}</button>`;
  }

  function navBadgeFor(pageId, state) {
    if (!state) return '';
    if (pageId === 'war-council') return String(toArray(state.warCouncil?.threatBoard).length || '');
    if (pageId === 'forge') return toArray(state.projects).some((entry) => entry.status === 'complete' || entry.status === 'ready') ? 'Ready' : '';
    if (pageId === 'market') return state.market?.newItems ? 'New' : '';
    if (pageId === 'diplomacy') return state.diplomacy?.pendingOffers ? '!' : '';
    if (pageId === 'intel') return String(toArray(state.rightPanel?.intel).length || '');
    if (pageId === 'relics') return String(Object.values(state.relics?.fragments ?? {}).reduce((sum, value) => sum + Number(value ?? 0), 0) || '');
    if (pageId === 'deck-vault') return toArray(state.activeDeck?.warnings).length ? String(toArray(state.activeDeck.warnings).length) : 'Active';
    return '';
  }

  function navWarningFor(pageId, state) {
    return (pageId === 'war-council' && state?.campaignStatus?.globalThreat >= 60)
      || (pageId === 'diplomacy' && Number(state?.diplomacy?.pendingOffers ?? 0) > 0)
      || (pageId === 'forge' && toArray(state?.projects).some((entry) => entry.status === 'complete' || entry.status === 'ready'));
  }

  function severityClass(severity = 'info') {
    return `severity-${String(severity || 'info').toLowerCase()}`;
  }

  function resourceChip(label, value, icon) {
    return `<span class="command-resource-chip"><span>${escapeHtml(icon)}</span><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></span>`;
  }

  function renderTopbar(state) {
    const threat = state.threatBand ?? { label: 'Calm', tone: 'good' };
    const threatPct = clamp(Number(state.campaignStatus?.globalThreat ?? 0), 0, 100);
    const pulseClass = threat.tone === 'danger' || threat.tone === 'warning' ? ' is-warning' : '';
    dom.topbar.innerHTML = `
      <div class="command-topbar-block">
        <div class="command-kicker">Faction Headquarters</div>
        <div class="command-topbar-line">
          <span class="command-faction-chip"><span>${escapeHtml(state.faction.icon)}</span><strong>${escapeHtml(state.faction.name)}</strong></span>
          <span class="command-faction-name">${escapeHtml(state.commander.name)}</span>
        </div>
        <div class="command-topbar-line command-small-copy">
          <span>Commander Title: <strong>${escapeHtml(state.commander.title)}</strong></span>
          <span>Campaign: <strong>${escapeHtml(state.campaignName)}</strong></span>
        </div>
      </div>
      <div class="command-topbar-block">
        <div class="command-topbar-line">
          ${resourceChip('Turn', state.turn, '⟳')}
          ${resourceChip('Credits', state.resources.credits, '◈')}
          ${resourceChip('Forge Cores', state.resources.forgeCores, '⛭')}
          ${resourceChip('Relic Dust', state.resources.relicDust, '◆')}
          ${resourceChip('Supplies', state.resources.supplies, '⬒')}
        </div>
        <div class="command-threat-meter${pulseClass}"><i style="width:${threatPct}%"></i></div>
      </div>
      <div class="command-topbar-block">
        <div class="command-topbar-line">
          <span class="command-threat-chip"><span>Threat</span><strong>${threatPct}%</strong></span>
          <span class="command-status-chip"><span>Reputation</span><strong>${escapeHtml(state.faction.reputationTitle)}</strong></span>
          <span class="command-status-chip"><span>Save</span><strong>${escapeHtml(state.saveState === 'synced' ? 'Synced' : state.saveState)}</strong></span>
        </div>
        <div class="command-topbar-line command-inline-actions">
          ${buttonMarkup('Settings', 'route', 'command-button-minor', { route: '#/command/settings' })}
          ${buttonMarkup('Return', 'close-command-center', 'command-button-minor')}
        </div>
      </div>
    `;
  }

  function renderLeftNav(state) {
    const navButtons = state.pages.map((page) => {
      const badge = navBadgeFor(page.id, state);
      const warning = navWarningFor(page.id, state);
      return `
        <button type="button" class="command-nav-btn ${page.id === state.currentPage ? 'is-active' : ''}" ${actionAttrs('route', { route: page.route })} title="${escapeHtml(page.label)}">
          <span class="command-nav-main">
            <span class="command-nav-icon">${escapeHtml(page.icon)}</span>
            <span class="command-nav-copy"><strong>${escapeHtml(page.label)}</strong><small>${escapeHtml(page.id === 'home' ? 'Faction overview and recommended actions' : page.id === 'war-council' ? 'Threats, missions, and response planning' : page.id === 'deck-vault' ? 'Attack shell, notes, and analysis' : page.id === 'forge' ? 'Projects, departments, and upgrades' : page.id === 'market' ? 'Traders, black market, and prices' : page.id === 'diplomacy' ? 'Relations, pacts, and warnings' : page.id === 'intel' ? 'Enemy movement and rivals' : page.id === 'relics' ? 'Fragments, relics, and anomalies' : page.id === 'commander' ? 'Commander identity and relics' : page.id === 'codex' ? 'Tactics library and documentation' : page.id === 'archives' ? 'History and campaign record' : page.id === 'settings' ? 'HUD, motion, and support tools' : 'Campaign tools')}</small></span>
          </span>
          ${badge ? `<span class="command-nav-badge"><strong>${escapeHtml(badge)}</strong></span>` : ''}
          ${warning ? '<span class="command-nav-warning-dot"></span>' : ''}
        </button>
      `;
    }).join('');
    dom.leftNav.innerHTML = `
      <div class="command-left-nav-head">
        <div class="command-kicker">Command Routes</div>
        <h2>Command Center</h2>
        <p>The faction war room stays loaded while we move between campaign systems.</p>
      </div>
      <div class="command-nav-list">${navButtons}<button class="command-nav-btn" data-command-action="open-inventory"><span class="command-nav-main"><span class="command-nav-icon">[]</span><span class="command-nav-copy"><strong>Inventory</strong><small>Every collected card, in one archive</small></span></span></button></div>
    `;
  }

  function commanderBannerMarkup(state) {
    const relics = toArray(state.commander.equippedRelics).length
      ? toArray(state.commander.equippedRelics).map((entry) => `<span class="command-mini-tag">${escapeHtml(entry)}</span>`).join('')
      : '<span class="command-mini-tag">No relics equipped</span>';
    const colors = toArray(state.commander.colorIdentity).map((entry) => `<span class="command-mini-tag">${escapeHtml(String(entry).toUpperCase())}</span>`).join('');
    return `
      <section class="command-banner">
        <div class="command-banner-portrait">
          <div class="command-portrait-glyph">${escapeHtml(state.faction.icon)}</div>
        </div>
        <div class="command-banner-copy">
          <div class="command-banner-meta">
            <div class="command-kicker">Commander Banner</div>
            <h2 class="command-banner-title">${escapeHtml(state.commander.name)}</h2>
            <div class="command-banner-subtitle">Commander of the ${escapeHtml(state.faction.name)}</div>
            <div class="command-small-copy">Title: <strong>${escapeHtml(state.commander.title)}</strong></div>
          </div>
          <div class="command-banner-grid">
            <div class="command-stat-grid">
              <div class="command-stat-box"><span class="command-kicker">Active Deck</span><strong>${escapeHtml(state.activeDeck.name)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Commander Level</span><strong>${escapeHtml(state.commander.level)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Colors</span><strong>${colors || 'Neutral'}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Campaign Turn</span><strong>${escapeHtml(state.turn)}</strong></div>
            </div>
            <div>
              <div class="command-kicker">Equipped Relics</div>
              <div class="command-hero-relics">${relics}</div>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  function actionButtonFromRoute(action = null, label = 'Open') {
    if (!action) return buttonMarkup(label, 'route', 'command-button-minor', { route: '#/command' });
    if (action.type === 'page') return buttonMarkup(label || 'Open', 'route', 'command-button-secondary', { route: action.route });
    if (action.type === 'planet') return buttonMarkup(label || 'Open Planet Command', 'open-planet-command', 'command-button-secondary', { world: action.worldId, planet: action.planetId });
    return buttonMarkup(label || 'Open', 'route', 'command-button-secondary', { route: '#/command' });
  }

  function actionButtonFromJump(jump, state) {
    if (!jump) return buttonMarkup('Open', 'route', 'command-button-minor', { route: '#/command' });
    if (jump.type === 'planet') return buttonMarkup('Open Planet', 'open-planet-command', 'command-button-secondary', { world: jump.worldId ?? state.selectedWorld?.worldId, planet: jump.planetId });
    if (jump.type === 'deck') return buttonMarkup('Open Deck', 'route', 'command-button-secondary', { route: '#/command/deck-vault' });
    if (jump.type === 'forge') return buttonMarkup('Open Forge', 'route', 'command-button-secondary', { route: '#/command/forge' });
    if (jump.type === 'war-council-op') return buttonMarkup('Open War Council', 'route', 'command-button-secondary', { route: '#/command/war-council' });
    return buttonMarkup('Open', 'route', 'command-button-secondary', { route: '#/command' });
  }

  function actionListMarkup(state) {
    const items = toArray(state.recommendedActions).map((entry) => `
      <article class="command-action-card">
        <div class="command-card-top">
          <div>
            <div class="command-action-title">${escapeHtml(entry.title)}</div>
            <div class="command-action-body">${escapeHtml(entry.summary)}</div>
          </div>
          <span class="command-action-pill"><strong>${escapeHtml(entry.reward)}</strong></span>
        </div>
        <div class="command-page-actions">
          ${actionButtonFromRoute(entry.action)}
        </div>
      </article>
    `).join('');
    return `
      <section class="command-page-card">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Recommended Actions</div>
            <h3>What needs attention next?</h3>
          </div>
        </div>
        <div class="command-action-list">${items || '<div class="command-empty-state">No urgent actions. The board is steady for now.</div>'}</div>
      </section>
    `;
  }

  function summaryWidgetsMarkup(state) {
    const warnings = toArray(state.activeDeck.warnings).map((entry) => `<span class="command-mini-tag">${escapeHtml(entry)}</span>`).join('') || '<span class="command-mini-tag">No active warnings</span>';
    return `
      <section class="command-dashboard-grid">
        <article class="command-widget">
          <div class="command-kicker">Active Campaign</div>
          <h3>${escapeHtml(state.campaignName)}</h3>
          <p>Turn ${escapeHtml(state.turn)} • Owned Territories ${escapeHtml(state.campaignStatus.ownedTerritories)} • Enemy Territories ${escapeHtml(state.campaignStatus.enemyTerritories)}</p>
          <div class="command-widget-metric">${escapeHtml(state.campaignStatus.currentObjective)}</div>
          <div class="command-widget-actions">
            ${buttonMarkup('Open Map', 'route', 'command-button', { route: '#/command/map' })}
            ${buttonMarkup('View Objective', 'route', 'command-button-secondary', { route: '#/command/war-council' })}
            ${buttonMarkup('End Turn', 'end-turn', 'command-button-minor')}
          </div>
        </article>
        <article class="command-widget">
          <div class="command-kicker">Active Deck</div>
          <h3>${escapeHtml(state.activeDeck.name)}</h3>
          <p>Cards ${escapeHtml(`${state.activeDeck.cardCount}/${state.activeDeck.maxCards}`)} • Average Cost ${escapeHtml(state.activeDeck.averageCost.toFixed(2))}</p>
          <div class="command-tag-row">${warnings}</div>
          <div class="command-widget-actions">
            ${buttonMarkup('Edit Deck', 'route', 'command-button', { route: '#/command/deck-vault' })}
            ${buttonMarkup('Analyze', 'open-deck-tab', 'command-button-secondary')}
            ${buttonMarkup('Test Battle', 'quick-battle', 'command-button-minor')}
          </div>
        </article>
        <article class="command-widget">
          <div class="command-kicker">Threat Level</div>
          <h3>${escapeHtml(state.threatBand.label)}</h3>
          <p>Global Threat ${escapeHtml(state.campaignStatus.globalThreat)}% • Next invasion ${escapeHtml(state.campaignStatus.nextInvasionTurns)} turns</p>
          <div class="command-widget-metric">${escapeHtml(state.campaignStatus.borderUnderPressure)}</div>
          <div class="command-widget-actions">
            ${buttonMarkup('View Threats', 'route', 'command-button', { route: '#/command/war-council' })}
            ${buttonMarkup('Prepare Defense', 'open-conquest-world', 'command-button-secondary', { world: state.selectedWorld?.worldId })}
            ${buttonMarkup('Scout Rival', 'route', 'command-button-minor', { route: '#/command/intel' })}
          </div>
        </article>
        <article class="command-widget">
          <div class="command-kicker">Forge Status</div>
          <h3>${escapeHtml(toArray(state.projects)[0]?.title ?? 'Forge Watch')}</h3>
          <p>Stored materials ${escapeHtml(state.resources.totalWarResources)} • Unlocks tracked through Conquest Forge</p>
          <div class="command-widget-metric">${escapeHtml(toArray(state.projects)[0]?.status === 'complete' || toArray(state.projects)[0]?.status === 'ready' ? 'Complete' : 'In Progress')}</div>
          <div class="command-widget-actions">
            ${buttonMarkup('Open Forge', 'route', 'command-button', { route: '#/command/forge' })}
            ${buttonMarkup('Collect Project', 'open-conquest-forge', 'command-button-secondary', { world: state.selectedWorld?.worldId })}
            ${buttonMarkup('Start New Project', 'open-research-modal', 'command-button-minor', { world: state.selectedWorld?.worldId })}
          </div>
        </article>
        <article class="command-widget">
          <div class="command-kicker">Market Status</div>
          <h3>${escapeHtml(state.market.state)}</h3>
          <p>New Items ${escapeHtml(state.market.newItems)} • Black Market ${escapeHtml(state.market.blackMarket)}</p>
          <div class="command-widget-metric">${escapeHtml(state.market.priceModifier)}%</div>
          <div class="command-widget-actions">
            ${buttonMarkup('Open Market', 'route', 'command-button', { route: '#/command/market' })}
            ${buttonMarkup('View Black Market', 'open-market-tab', 'command-button-secondary')}
            ${buttonMarkup('Sell Salvage', 'open-conquest-forge', 'command-button-minor', { world: state.selectedWorld?.worldId })}
          </div>
        </article>
        <article class="command-widget">
          <div class="command-kicker">Diplomacy</div>
          <h3>${escapeHtml(state.diplomacy.factions[0]?.label ?? 'Frontier contacts')}</h3>
          <p>${escapeHtml(state.diplomacy.factions.map((entry) => `${entry.label}: ${entry.status}`).join(' • '))}</p>
          <div class="command-widget-metric">Offers ${escapeHtml(state.diplomacy.pendingOffers)}</div>
          <div class="command-widget-actions">
            ${buttonMarkup('Open Diplomacy', 'route', 'command-button', { route: '#/command/diplomacy' })}
            ${buttonMarkup('Review Offers', 'route', 'command-button-secondary', { route: '#/command/diplomacy' })}
            ${buttonMarkup('Send Envoy', 'route', 'command-button-minor', { route: '#/command/diplomacy' })}
          </div>
        </article>
      </section>
    `;
  }

  function territorySummaryMarkup(state) {
    const rows = toArray(state.worlds).map((entry) => `
      <article class="command-world-row">
        <div class="command-world-top">
          <div>
            <div class="command-world-name">${escapeHtml(entry.name)}</div>
            <div class="command-world-meta">${escapeHtml(entry.systemName)} • ${escapeHtml(entry.stability)} • Readiness ${escapeHtml(entry.readiness)}</div>
          </div>
          <span class="command-world-chip"><strong>+${escapeHtml(entry.income)}</strong></span>
        </div>
        <div class="command-tag-row">${toArray(entry.elements).map((element) => `<span class="command-mini-tag">${escapeHtml(String(element).toUpperCase())}</span>`).join('')}</div>
        <div class="command-page-actions">
          ${buttonMarkup('Open Planet Command', 'open-planet-command', 'command-button-secondary', { world: entry.worldId })}
          ${buttonMarkup('Open Forge', 'open-conquest-forge', 'command-button-minor', { world: entry.worldId })}
        </div>
      </article>
    `).join('');
    return `
      <section class="command-page-card">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Territory Summary</div>
            <h3>Campaign holdings and world pressure</h3>
          </div>
          <span class="command-status-chip"><span>Average Stability</span><strong>${escapeHtml(state.stabilityAverage)}%</strong></span>
        </div>
        <div class="command-world-list">${rows || '<div class="command-empty-state">No owned capitals have been secured yet.</div>'}</div>
      </section>
    `;
  }

  function renderHomePage(state) {
    return `
      <div class="command-page-shell">
        ${commanderBannerMarkup(state)}
        ${summaryWidgetsMarkup(state)}
        ${actionListMarkup(state)}
        <section class="command-data-grid">
          ${territorySummaryMarkup(state)}
          <section class="command-page-card">
            <div class="command-page-head">
              <div>
                <div class="command-kicker">Mission Preview</div>
                <h3>Current operational frame</h3>
              </div>
            </div>
            <div class="command-stat-grid">
              <div class="command-stat-box"><span class="command-kicker">Current Objective</span><strong>${escapeHtml(state.campaignStatus.currentObjective)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Most Dangerous Rival</span><strong>${escapeHtml(state.campaignStatus.mostDangerousRival)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Attack Readiness</span><strong>${escapeHtml(state.readiness.attack)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Defense Readiness</span><strong>${escapeHtml(state.readiness.defense)}</strong></div>
            </div>
            <div class="command-page-actions">
              ${buttonMarkup('Start Mission', 'route', 'command-button', { route: '#/command/war-council' })}
              ${buttonMarkup('Open Map', 'route', 'command-button-secondary', { route: '#/command/map' })}
              ${buttonMarkup('Manage Deck', 'route', 'command-button-minor', { route: '#/command/deck-vault' })}
            </div>
          </section>
        </section>
      </div>
    `;
  }

  function renderMapPage(state) {
    const worlds = toArray(state.worlds).map((entry) => `
      <article class="command-world-row">
        <div class="command-world-top">
          <div>
            <div class="command-world-name">${escapeHtml(entry.name)}</div>
            <div class="command-world-meta">${escapeHtml(entry.systemName)} • Pressure ${escapeHtml(entry.pressure)}% • ${escapeHtml(entry.readiness)}</div>
          </div>
          <span class="command-page-badge"><strong>${escapeHtml(entry.stability)}</strong></span>
        </div>
        <div class="command-page-actions">
          ${buttonMarkup('Planet Command', 'open-planet-command', 'command-button-secondary', { world: entry.worldId })}
          ${buttonMarkup('Conquest Ops', 'open-conquest-world', 'command-button-minor', { world: entry.worldId })}
        </div>
      </article>
    `).join('');
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Campaign Map</div>
            <h2>Territory and route control</h2>
            <p>The live SVG battlemap stays available behind the Command Center. This page keeps the campaign readable and gives us a direct jump back to the map.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Live Battlemap', 'open-live-map', 'command-button')}
            ${buttonMarkup('Open War Council', 'route', 'command-button-secondary', { route: '#/command/war-council' })}
          </div>
        </div>
        <section class="command-data-grid">
          <section class="command-page-card">
            <h3>Selected Front</h3>
            <p>${escapeHtml(state.selectedWorld?.planetName ?? 'No capital selected')} • ${escapeHtml(state.selectedWorld?.specialization ?? 'No specialization')}</p>
            <div class="command-tag-row">
              <span class="command-mini-tag">Passive Income +${escapeHtml(state.selectedWorld?.passiveIncome ?? 0)}</span>
              <span class="command-mini-tag">Stability ${escapeHtml(state.selectedWorld?.stabilityState ?? 'stable')}</span>
              <span class="command-mini-tag">Black Market ${state.selectedWorld?.blackMarketAvailable ? 'Available' : 'Offline'}</span>
            </div>
            <div class="command-layout-note">Use the live battlemap for node selection, fleet hover, and direct engagements. Use this panel to stay oriented and jump back in.</div>
          </section>
          <section class="command-page-card">
            <h3>Owned Capitals</h3>
            <div class="command-world-list">${worlds || '<div class="command-empty-state">No capitals are secured yet.</div>'}</div>
          </section>
        </section>
      </div>
    `;
  }

  function renderWarCouncilPage(state) {
    const threats = toArray(state.warCouncil?.threatBoard).map((entry) => `
      <article class="command-alert-card ${severityClass(entry.dangerTone === 'bad' ? 'urgent' : entry.dangerTone === 'warn' ? 'warning' : 'info')}">
        <div class="command-alert-top">
          <div>
            <div class="command-alert-title">${escapeHtml(entry.name)}</div>
            <div class="command-alert-body">${escapeHtml(entry.faction)} • L${escapeHtml(entry.level)} • ${escapeHtml(entry.region)} • ETA ${escapeHtml(entry.eta)}</div>
          </div>
          <span class="command-page-badge"><strong>${escapeHtml(entry.reward)}</strong></span>
        </div>
        <p>${escapeHtml(entry.consequence)}</p>
      </article>
    `).join('');
    const advisors = toArray(state.warCouncil?.advisors).map((entry) => `
      <article class="command-advisor-card">
        <div class="command-advisor-title">${escapeHtml(entry.advisor)}</div>
        <div class="command-advisor-body">${escapeHtml(entry.text)}</div>
        <div class="command-advisor-actions">${actionButtonFromJump(entry.action, state)}</div>
      </article>
    `).join('');
    const operations = toArray(state.warCouncil?.operations).map((entry) => `
      <div class="command-operation-row">
        <div class="command-card-top">
          <div>
            <div class="command-action-title">${escapeHtml(entry.label)}</div>
            <div class="command-action-body">Queue a response without leaving the strategic shell.</div>
          </div>
          ${buttonMarkup(entry.label, 'open-war-council-modal', 'command-button-minor', { world: state.selectedWorld?.worldId })}
        </div>
      </div>
    `).join('');
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">War Council</div>
            <h2>Threat board and operational planning</h2>
            <p>Active pirate fleets, invasion fleets, anomalies, and pressured worlds roll up here into one readable board.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Full War Council', 'open-war-council-modal', 'command-button', { world: state.selectedWorld?.worldId })}
            ${buttonMarkup('Prepare Assault', 'open-conquest-world', 'command-button-secondary', { world: state.selectedWorld?.worldId })}
          </div>
        </div>
        <section class="command-war-grid">
          <section class="command-page-card">
            <h3>Threat Board</h3>
            <div class="command-war-list">${threats || '<div class="command-empty-state">No urgent fleets or anomalies are active.</div>'}</div>
          </section>
          <section class="command-page-card">
            <h3>Strategic Overview</h3>
            <div class="command-stat-grid">
              <div class="command-stat-box"><span class="command-kicker">Owned Capitals</span><strong>${escapeHtml(state.campaignStatus.ownedTerritories)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Passive Income</span><strong>+${escapeHtml(state.selectedWorld?.passiveIncome ?? 0)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Stability Average</span><strong>${escapeHtml(state.stabilityAverage)}%</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Total War Resources</span><strong>${escapeHtml(state.resources.totalWarResources)}</strong></div>
            </div>
            <div class="command-card-divider"></div>
            <h3>Advisory Board</h3>
            <div class="command-war-list">${advisors || '<div class="command-empty-state">The board has no urgent recommendation right now.</div>'}</div>
            <div class="command-card-divider"></div>
            <h3>Operations Queue</h3>
            <div class="command-war-list">${operations}</div>
          </section>
        </section>
      </div>
    `;
  }

  function renderDeckVaultPage(state) {
    const warnings = toArray(state.activeDeck.warnings).map((entry) => `<span class="command-mini-tag">${escapeHtml(entry)}</span>`).join('') || '<span class="command-mini-tag">No immediate deck warnings</span>';
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Deck Vault</div>
            <h2>${escapeHtml(state.activeDeck.name)}</h2>
            <p>Cards ${escapeHtml(`${state.activeDeck.cardCount}/${state.activeDeck.maxCards}`)} • Average Cost ${escapeHtml(state.activeDeck.averageCost.toFixed(2))} • ${escapeHtml(state.activeDeck.health)}</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Attack Deck Studio', 'open-attack-deck-modal', 'command-button', { world: state.selectedWorld?.worldId })}
            ${buttonMarkup('Open Full Deckbuilder', 'open-deck-tab', 'command-button-secondary')}
          </div>
        </div>
        <section class="command-deck-grid">
          <section class="command-page-card">
            <h3>Deck Health</h3>
            <div class="command-tag-row">${warnings}</div>
            <div class="command-stat-grid" style="margin-top:14px;">
              <div class="command-stat-box"><span class="command-kicker">Volatility</span><strong>${Math.round((state.activeDeck.volatility ?? 0) * 100)}%</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Supply Dependence</span><strong>${Math.round((state.activeDeck.supplyDependence ?? 0) * 100)}%</strong></div>
            </div>
          </section>
          <section class="command-page-card">
            <h3>Actionable Next Steps</h3>
            <p>Use the attack deck studio for conquest-specific shells, or jump to the full deckbuilder for broader edits and tests.</p>
            <div class="command-page-actions">
              ${buttonMarkup('Set Active', 'open-attack-deck-modal', 'command-button-secondary', { world: state.selectedWorld?.worldId })}
              ${buttonMarkup('Analyze', 'open-deck-tab', 'command-button-minor')}
              ${buttonMarkup('Test Battle', 'quick-battle', 'command-button-minor')}
            </div>
          </section>
        </section>
      </div>
    `;
  }

  function renderForgePage(state) {
    const projects = toArray(state.projects).map((entry) => `<article class="command-history-card"><h3>${escapeHtml(entry.title)}</h3><p>Status: ${escapeHtml(entry.status)}${entry.turnsRemaining ? ` • ${escapeHtml(entry.turnsRemaining)} turn(s)` : ''}</p></article>`).join('');
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Forge</div>
            <h2>Production suite and card engineering</h2>
            <p>Recruit, Train, Equip, Synthesize, Formation Hall, Hero Hall, Batch Train, Archive, Salvage, Doctrine Lab, and Catalyst Vault remain anchored in the conquest forge flow.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Conquest Forge', 'open-conquest-forge', 'command-button', { world: state.selectedWorld?.worldId })}
            ${buttonMarkup('Research', 'open-research-modal', 'command-button-secondary', { world: state.selectedWorld?.worldId })}
          </div>
        </div>
        <section class="command-data-grid">
          <section class="command-page-card">
            <h3>Project Status</h3>
            <div class="command-feed-list">${projects}</div>
          </section>
          <section class="command-page-card">
            <h3>Departments</h3>
            <div class="command-world-list">
              ${['Recruit', 'Train', 'Equip', 'Synthesize', 'Formation Hall', 'Hero Hall', 'Batch Train', 'Archive', 'Salvage', 'Doctrine Lab', 'Catalyst Vault'].map((entry) => `<div class="command-world-row"><div class="command-world-name">${escapeHtml(entry)}</div><div class="command-world-meta">Accessible through the conquest forge workspace.</div></div>`).join('')}
            </div>
          </section>
        </section>
      </div>
    `;
  }

  function renderMarketPage(state) {
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Market</div>
            <h2>${escapeHtml(state.market.state)}</h2>
            <p>Standard market and black market both stay on the existing conquest market runtime. This page keeps them legible and lets us jump in quickly.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Market', 'open-market-tab', 'command-button')}
            ${buttonMarkup('View Black Market', 'open-market-tab', 'command-button-secondary')}
          </div>
        </div>
        <section class="command-market-grid">
          <section class="command-page-card">
            <h3>Trading Conditions</h3>
            <div class="command-stat-grid">
              <div class="command-stat-box"><span class="command-kicker">New Items</span><strong>${escapeHtml(state.market.newItems)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Price Modifier</span><strong>${escapeHtml(state.market.priceModifier)}%</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Black Market</span><strong>${escapeHtml(state.market.blackMarket)}</strong></div>
              <div class="command-stat-box"><span class="command-kicker">Supplies</span><strong>${escapeHtml(state.resources.supplies)}</strong></div>
            </div>
          </section>
          <section class="command-page-card">
            <h3>Recent Market Intel</h3>
            <div class="command-feed-list">${toArray(state.market.recentNotes).map((note, index) => `<div class="command-feed-card severity-info"><div class="command-feed-title">Signal ${index + 1}</div><p>${escapeHtml(note)}</p></div>`).join('')}</div>
          </section>
        </section>
      </div>
    `;
  }

  function renderDiplomacyPage(state) {
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Diplomacy</div>
            <h2>Relations and pending envoys</h2>
            <p>Use this page to stay aware of faction mood, then jump into the diplomacy systems when you want to commit.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Market', 'route', 'command-button-secondary', { route: '#/command/market' })}
            ${buttonMarkup('Open Intel', 'route', 'command-button-minor', { route: '#/command/intel' })}
          </div>
        </div>
        <section class="command-data-grid">
          ${toArray(state.diplomacy.factions).map((entry) => `
            <article class="command-page-card">
              <h3>${escapeHtml(entry.label)}</h3>
              <p>Status: ${escapeHtml(entry.status)}</p>
              <div class="command-widget-metric">${escapeHtml(entry.score)}</div>
            </article>
          `).join('')}
          <article class="command-page-card">
            <h3>Pending Offers</h3>
            <p>${escapeHtml(state.diplomacy.pendingOffers)} offer(s) require a response.</p>
            <div class="command-page-actions">
              ${buttonMarkup('Review Offers', 'route', 'command-button-secondary', { route: '#/command/diplomacy' })}
            </div>
          </article>
        </section>
      </div>
    `;
  }

  function renderIntelPage(state) {
    const intelCards = toArray(state.rightPanel.intel).map((entry) => `<article class="command-feed-card severity-info"><div class="command-feed-title">${escapeHtml(entry.title)}</div><p>${escapeHtml(entry.body)}</p></article>`).join('');
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Intel</div>
            <h2>Enemy movement, rival posture, and border signals</h2>
            <p>The feed below pulls from live threat records and conquest event history.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open War Council', 'route', 'command-button', { route: '#/command/war-council' })}
            ${buttonMarkup('Open Archives', 'route', 'command-button-secondary', { route: '#/command/archives' })}
          </div>
        </div>
        <section class="command-page-card">
          <div class="command-feed-list">${intelCards || '<div class="command-empty-state">No fresh intel pulses are recorded right now.</div>'}</div>
        </section>
      </div>
    `;
  }

  function renderRelicsPage(state) {
    const fragments = Object.entries(state.relics?.fragments ?? {}).map(([id, amount]) => `<div class="command-stat-box"><span class="command-kicker">${escapeHtml(id)}</span><strong>${escapeHtml(amount)}</strong></div>`).join('');
    const assembled = toArray(state.relics?.assembled).map((entry) => `<article class="command-history-card"><h3>${escapeHtml(entry?.name ?? entry?.id ?? 'Relic')}</h3><p>${escapeHtml(entry?.family ?? 'Relic')} • ${escapeHtml(entry?.summary ?? 'No summary available.')}</p></article>`).join('');
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Relics</div>
            <h2>Fragments, relics, and anomaly pressure</h2>
            <p>Relic fragments are tracked by family and fed by excavation, anomalies, and black market operations.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open War Council', 'route', 'command-button', { route: '#/command/war-council' })}
          </div>
        </div>
        <section class="command-relics-grid">
          <section class="command-page-card">
            <h3>Fragment Stores</h3>
            <div class="command-stat-grid">${fragments || '<div class="command-empty-state">No fragment stock available.</div>'}</div>
          </section>
          <section class="command-page-card">
            <h3>Assembled Relics</h3>
            <div class="command-feed-list">${assembled || '<div class="command-empty-state">No relics assembled yet.</div>'}</div>
          </section>
        </section>
      </div>
    `;
  }

  function renderCommanderPage(state) {
    return `
      <div class="command-page-shell">
        ${commanderBannerMarkup(state)}
        <section class="command-data-grid">
          <section class="command-page-card">
            <h3>Commander Profile</h3>
            <p>${escapeHtml(state.commander.name)} leads the ${escapeHtml(state.faction.name)} and is currently level ${escapeHtml(state.commander.level)} with ${escapeHtml(state.commander.skillPoints)} unspent skill point(s).</p>
          </section>
          <section class="command-page-card">
            <h3>Current Orders</h3>
            <p>Use the conquest attack deck studio and war council to refine order loadouts and officer packages around this command profile.</p>
            <div class="command-page-actions">
              ${buttonMarkup('Open Deck Vault', 'route', 'command-button-secondary', { route: '#/command/deck-vault' })}
              ${buttonMarkup('Open Forge', 'route', 'command-button-minor', { route: '#/command/forge' })}
            </div>
          </section>
        </section>
      </div>
    `;
  }

  function renderCodexPage(state) {
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Codex</div>
            <h2>Tactics Library and feature documentation</h2>
            <p>Use the live tactics library for discovered formations and the broader feature reference for system documentation.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Open Tactics Library', 'open-tactics-library', 'command-button', { world: state.selectedWorld?.worldId })}
            ${buttonMarkup('Open Game Features', 'open-game-features', 'command-button-secondary')}
          </div>
        </div>
        <section class="command-page-card">
          <h3>Current Documentation Paths</h3>
          <div class="command-feed-list">
            <article class="command-feed-card severity-info"><div class="command-feed-title">Tactics Library</div><p>Weather notes, formation recipes, successful lineages, and faction weaknesses.</p></article>
            <article class="command-feed-card severity-info"><div class="command-feed-title">Game Features</div><p>System-wide reference page documenting the major game features in expandable sections.</p></article>
          </div>
        </section>
      </div>
    `;
  }

  function renderArchivesPage(state) {
    const events = toArray(state.archives.events).map((entry, index) => `<article class="command-history-card"><h3>${escapeHtml(entry?.severity ?? `Event ${index + 1}`)}</h3><p>${escapeHtml(entry?.text ?? entry?.label ?? 'No archive text.')}</p></article>`).join('');
    const commandLog = toArray(state.archives.commandLog).map((entry) => `<article class="command-history-card"><h3>Turn ${escapeHtml(entry.turn ?? '')}</h3><p>${escapeHtml(entry.text ?? '')}</p></article>`).join('');
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Archives</div>
            <h2>Campaign event history and turn summaries</h2>
            <p>The archive keeps conquest events, command center turn summaries, and recent campaign signals in one place.</p>
          </div>
        </div>
        <section class="command-archive-grid">
          <section class="command-page-card"><h3>Campaign Events</h3><div class="command-feed-list">${events || '<div class="command-empty-state">No campaign events logged yet.</div>'}</div></section>
          <section class="command-page-card"><h3>Command Log</h3><div class="command-feed-list">${commandLog || '<div class="command-empty-state">No command-center turn summaries recorded yet.</div>'}</div></section>
        </section>
      </div>
    `;
  }

  function renderSettingsPage(state) {
    const settings = state.settings ?? {};
    return `
      <div class="command-page-shell">
        <div class="command-page-head">
          <div>
            <div class="command-kicker">Settings</div>
            <h2>HUD, card presentation, motion, and support tools</h2>
            <p>We keep the command shell and battle runtime settings connected, but the shell itself stays separate from battle logic.</p>
          </div>
          <div class="command-page-actions">
            ${buttonMarkup('Card UI Settings', 'open-card-ui-settings', 'command-button')}
            ${buttonMarkup('dev_WIP_UI', 'open-dev-wip-ui', 'command-button-secondary')}
          </div>
        </div>
        <section class="command-settings-grid">
          <article class="command-settings-card"><h3>Interface</h3><p>UI Scale ${escapeHtml(settings.uiScale ?? 1)} • Theme ${escapeHtml(settings.selectedTheme ?? 'arcane-night')}</p></article>
          <article class="command-settings-card"><h3>Card Back</h3><p>${escapeHtml(settings.selectedCardBack ?? 'classic-onyx')}</p></article>
          <article class="command-settings-card"><h3>Accessibility</h3><p>${settings.reduceMotion ? 'Reduced motion enabled' : 'Full motion enabled'} • ${settings.highContrast ? 'High contrast enabled' : 'Standard contrast'}</p></article>
        </section>
      </div>
    `;
  }

  function renderFallbackPage(state) {
    return `
      <div class="command-page-shell">
        <div class="command-page-head"><div><div class="command-kicker">Command Center</div><h2>${escapeHtml(pageMeta(state.currentPage).label)}</h2></div></div>
        <section class="command-page-card">
          <div class="command-empty-state">This page is staged inside the new command shell and will keep gaining direct system embeds. For now, use the action bar and page buttons to jump to the live conquest tools.</div>
        </section>
      </div>
    `;
  }

  function renderPage(state) {
    if (!state) return '';
    switch (state.currentPage) {
      case 'home': return renderHomePage(state);
      case 'map': return renderMapPage(state);
      case 'war-council': return renderWarCouncilPage(state);
      case 'deck-vault': return renderDeckVaultPage(state);
      case 'forge': return renderForgePage(state);
      case 'market': return renderMarketPage(state);
      case 'diplomacy': return renderDiplomacyPage(state);
      case 'intel': return renderIntelPage(state);
      case 'relics': return renderRelicsPage(state);
      case 'commander': return renderCommanderPage(state);
      case 'codex': return renderCodexPage(state);
      case 'archives': return renderArchivesPage(state);
      case 'settings': return renderSettingsPage(state);
      default: return renderFallbackPage(state);
    }
  }

  function renderRightPanel(state) {
    const tabs = ['alerts', 'events', 'projects', 'intel'];
    const feedItems = toArray(state.rightPanel?.[uiState.activityTab] ?? []);
    const feedMarkup = feedItems.length
      ? feedItems.map((entry) => `
          <article class="command-feed-card ${severityClass(entry.severity)}">
            <div class="command-feed-top">
              <div class="command-feed-title">${escapeHtml(entry.title ?? entry.advisor ?? 'Update')}</div>
              ${entry.turnsRemaining !== undefined ? `<span class="command-page-badge"><strong>${escapeHtml(entry.turnsRemaining)}</strong></span>` : ''}
            </div>
            <p class="command-feed-body">${escapeHtml(entry.body ?? entry.text ?? entry.summary ?? '')}</p>
          </article>
        `).join('')
      : '<div class="command-empty-state">No recent updates in this feed.</div>';
    dom.right.innerHTML = `
      <div class="command-right-shell">
        <div>
          <div class="command-kicker">Activity Feed</div>
          <div class="command-right-tabs">
            ${tabs.map((tab) => `<button type="button" class="command-right-tab ${uiState.activityTab === tab ? 'active' : ''}" ${actionAttrs('activity-tab', { tab })}>${escapeHtml(tab.charAt(0).toUpperCase() + tab.slice(1))}</button>`).join('')}
          </div>
        </div>
        <div class="command-right-content">${feedMarkup}</div>
      </div>
    `;
  }

  function bottomActionsForPage(state) {
    switch (state.currentPage) {
      case 'map':
        return [
          { label: 'Attack', action: 'open-conquest-world', tone: 'command-button', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Scout', action: 'route', tone: 'command-button-secondary', extras: { route: '#/command/intel' } },
          { label: 'Manage Defense', action: 'open-planet-command', tone: 'command-button-minor', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Assign Deck', action: 'route', tone: 'command-button-minor', extras: { route: '#/command/deck-vault' } },
          { label: 'Open War Council', action: 'route', tone: 'command-button-secondary', extras: { route: '#/command/war-council' } },
          { label: 'Back', action: 'route', tone: 'command-button-minor', extras: { route: '#/command' } },
        ];
      case 'deck-vault':
        return [
          { label: 'Edit Deck', action: 'open-attack-deck-modal', tone: 'command-button', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Set Active', action: 'open-attack-deck-modal', tone: 'command-button-secondary', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Analyze', action: 'open-deck-tab', tone: 'command-button-minor', extras: {} },
          { label: 'Test Battle', action: 'quick-battle', tone: 'command-button-minor', extras: {} },
          { label: 'Clone Deck', action: 'open-deck-tab', tone: 'command-button-secondary', extras: {} },
          { label: 'Back', action: 'route', tone: 'command-button-minor', extras: { route: '#/command' } },
        ];
      case 'forge':
        return [
          { label: 'Create Card', action: 'open-conquest-forge', tone: 'command-button', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Modify Card', action: 'open-conquest-forge', tone: 'command-button-secondary', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Fuse', action: 'open-conquest-forge', tone: 'command-button-minor', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Salvage', action: 'open-conquest-forge', tone: 'command-button-minor', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Test Chamber', action: 'open-conquest-forge', tone: 'command-button-secondary', extras: { world: state.selectedWorld?.worldId } },
          { label: 'Back', action: 'route', tone: 'command-button-minor', extras: { route: '#/command' } },
        ];
      case 'diplomacy':
        return [
          { label: 'Offer Trade', action: 'route', tone: 'command-button', extras: { route: '#/command/market' } },
          { label: 'Request Pact', action: 'route', tone: 'command-button-secondary', extras: { route: '#/command/diplomacy' } },
          { label: 'Threaten', action: 'route', tone: 'command-button-minor', extras: { route: '#/command/intel' } },
          { label: 'Send Gift', action: 'route', tone: 'command-button-minor', extras: { route: '#/command/market' } },
          { label: 'View History', action: 'route', tone: 'command-button-secondary', extras: { route: '#/command/archives' } },
          { label: 'Back', action: 'route', tone: 'command-button-minor', extras: { route: '#/command' } },
        ];
      default:
        return [
          { label: 'Start Mission', action: 'route', tone: 'command-button', extras: { route: '#/command/war-council' } },
          { label: 'Open Map', action: 'route', tone: 'command-button-secondary', extras: { route: '#/command/map' } },
          { label: 'Manage Deck', action: 'route', tone: 'command-button-minor', extras: { route: '#/command/deck-vault' } },
          { label: 'Forge Upgrade', action: 'route', tone: 'command-button-secondary', extras: { route: '#/command/forge' } },
          { label: 'End Turn', action: 'end-turn', tone: 'command-button-minor', extras: {} },
          { label: 'Save', action: 'save-profile', tone: 'command-button-minor', extras: {} },
        ];
    }
  }

  function renderBottomBar(state) {
    const actions = bottomActionsForPage(state);
    dom.bottom.innerHTML = `
      <div class="command-bottom-meta">${escapeHtml(pageMeta(state.currentPage).label)} • ${escapeHtml(state.selectedWorld?.planetName ?? state.campaignName)} • Threat ${escapeHtml(state.campaignStatus.globalThreat)}%</div>
      <div class="command-bottom-actions">${actions.map((entry) => buttonMarkup(entry.label, entry.action, entry.tone, entry.extras)).join('')}</div>
    `;
  }

  function renderBootstrapFallback(route, reason = '') {
    const pageId = campaignApi.routeToPageId?.(route) ?? 'home';
    const page = pageMeta(pageId);
    dom.topbar.innerHTML = `
      <div class="command-topbar-block">
        <div class="command-kicker">Faction Headquarters</div>
        <div class="command-topbar-line">
          <span class="command-faction-chip"><span>⬢</span><strong>Command Center</strong></span>
          <span class="command-faction-name">Campaign Snapshot</span>
        </div>
        <div class="command-topbar-line command-small-copy">
          <span>Launcher systems are still warming up.</span>
          <span>${escapeHtml(reason || 'Using fallback campaign snapshot.')}</span>
        </div>
      </div>
      <div class="command-topbar-block">
        <div class="command-topbar-line">
          ${resourceChip('Turn', '—', '⟳')}
          ${resourceChip('Credits', '—', '◈')}
          ${resourceChip('Forge Cores', '—', '⛭')}
          ${resourceChip('Relic Dust', '—', '◆')}
          ${resourceChip('Supplies', '—', '⬒')}
        </div>
        <div class="command-threat-meter"><i style="width:18%"></i></div>
      </div>
      <div class="command-topbar-block">
        <div class="command-topbar-line">
          <span class="command-status-chip"><span>Status</span><strong>Snapshot</strong></span>
        </div>
        <div class="command-topbar-line command-inline-actions">
          ${buttonMarkup('Retry', 'route', 'command-button-minor', { route: page.route })}
          ${buttonMarkup('Return', 'close-command-center', 'command-button-minor')}
        </div>
      </div>
    `;
    dom.leftNav.innerHTML = `
      <div class="command-left-nav-head">
        <div class="command-kicker">Command Routes</div>
        <h2>Command Center</h2>
        <p>The shell is active. We are waiting on the live conquest helpers to finish booting.</p>
      </div>
      <div class="command-nav-list">
        ${Object.values(campaignApi.PAGE_META ?? {}).map((entry) => `
          <button type="button" class="command-nav-btn ${entry.id === pageId ? 'is-active' : ''}" ${actionAttrs('route', { route: entry.route })}>
            <span class="command-nav-main">
              <span class="command-nav-icon">${escapeHtml(entry.icon)}</span>
              <span class="command-nav-copy"><strong>${escapeHtml(entry.label)}</strong><small>Fallback navigation remains available.</small></span>
            </span>
          </button>
        `).join('')}
      </div>
    `;
    dom.main.innerHTML = `
      <div class="command-page-shell">
        <section class="command-page-card">
          <div class="command-page-head">
            <div>
              <div class="command-kicker">Bootstrapping</div>
              <h2>${escapeHtml(page.label)} is loading through the Command Center shell</h2>
              <p>We kept the shell visible instead of leaving a blank screen. Once the conquest runtime finishes warming up, the live widgets will repopulate automatically on refresh or route change.</p>
            </div>
          </div>
          <div class="command-empty-state">Use the navigation on the left or press Retry. The fallback view keeps the campaign hub accessible even if the live conquest helpers arrive late.</div>
        </section>
      </div>
    `;
    dom.right.innerHTML = `
      <div class="command-right-shell">
        <div>
          <div class="command-kicker">Activity Feed</div>
          <div class="command-right-tabs"><button type="button" class="command-right-tab active">Alerts</button></div>
        </div>
        <div class="command-right-content">
          <article class="command-feed-card severity-warning">
            <div class="command-feed-title">Shell Ready</div>
            <p class="command-feed-body">The Command Center shell is open. Live conquest data is still booting, so this view is using a safe snapshot.</p>
          </article>
        </div>
      </div>
    `;
    dom.bottom.innerHTML = `
      <div class="command-bottom-meta">${escapeHtml(page.label)} • Snapshot mode</div>
      <div class="command-bottom-actions">
        ${buttonMarkup('Retry', 'route', 'command-button', { route: page.route })}
        ${buttonMarkup('Open Map', 'route', 'command-button-secondary', { route: '#/command/map' })}
        ${buttonMarkup('Manage Deck', 'route', 'command-button-minor', { route: '#/command/deck-vault' })}
        ${buttonMarkup('Forge Upgrade', 'route', 'command-button-secondary', { route: '#/command/forge' })}
      </div>
    `;
  }

  function renderCommandCenter() {
    const route = global.location.hash.startsWith('#/command') ? global.location.hash : '#/command';
    try {
      const state = campaignApi.buildCommandState(route);
      uiState.currentState = state;
      if (!state) {
        renderBootstrapFallback(route, 'Campaign data returned empty state.');
        return;
      }
      renderTopbar(state);
      renderLeftNav(state);
      dom.main.innerHTML = renderPage(state);
      renderRightPanel(state);
      renderBottomBar(state);
      if (state.introMessage) showToast(state.introMessage, 5200);
    } catch (error) {
      console.warn('Command Center render fallback engaged.', error);
      uiState.currentState = null;
      renderBootstrapFallback(route, error?.message ?? 'Unknown command-center bootstrap error.');
    }
  }

  async function showLoadingSequence() {
    if (!dom.loading || !dom.loadingSteps) return;
    dom.loading.classList.remove('hidden');
    const steps = [
      'Opening Command Center...',
      'Loading campaign state...',
      'Loading deck data...',
      'Loading alerts...',
    ];
    dom.loadingSteps.innerHTML = '';
    for (const step of steps) {
      const row = document.createElement('div');
      row.className = 'command-loading-step';
      row.textContent = step;
      dom.loadingSteps.appendChild(row);
      await new Promise((resolve) => setTimeout(resolve, 60));
    }
  }

  function hideLoadingSequence() {
    dom.loading?.classList.add('hidden');
  }

  function showToast(message, duration = 3600) {
    if (!dom.toast || !message) return;
    dom.toast.innerHTML = `<strong>${escapeHtml(message)}</strong>`;
    dom.toast.classList.remove('hidden');
    if (uiState.toastTimer) clearTimeout(uiState.toastTimer);
    uiState.toastTimer = setTimeout(() => dom.toast.classList.add('hidden'), duration);
  }

  async function openCommandCenter(route = '#/command', { skipLoading = false } = {}) {
    if (!dom.shell) return;
    uiState.open = true;
    dom.shell.classList.remove('hidden');
    document.body.classList.add('command-center-open');
    if (!skipLoading) await showLoadingSequence();
    if (typeof global.ensureLobbyPanelOpen === 'function') {
      Promise.resolve()
        .then(() => global.ensureLobbyPanelOpen(false))
        .catch((error) => console.warn('Command Center background lobby warmup failed.', error));
    }
    if (route && global.location.hash !== route) {
      history.replaceState(null, '', route);
    }
    renderCommandCenter();
    hideLoadingSequence();
  }

  function closeCommandCenter({ setLobbyHash = true } = {}) {
    if (!dom.shell) return;
    uiState.open = false;
    dom.shell.classList.add('hidden');
    dom.turnModal?.classList.add('hidden');
    dom.toast?.classList.add('hidden');
    document.body.classList.remove('command-center-open');
    if (setLobbyHash) history.replaceState(null, '', '#lobby');
  }

  function renderTurnModal(mode = 'confirm', payload = null) {
    if (!dom.turnModal || !uiState.currentState) return;
    const state = uiState.currentState;
    if (mode === 'confirm') {
      const pending = [
        toArray(state.projects).some((entry) => entry.status === 'complete' || entry.status === 'ready') ? '1 forge project is complete' : null,
        state.campaignStatus.nextInvasionTurns <= 2 ? `${state.selectedWorld?.planetName ?? 'Border world'} invasion in ${state.campaignStatus.nextInvasionTurns} turn(s)` : null,
        Number(state.diplomacy.pendingOffers ?? 0) > 0 ? `${state.diplomacy.pendingOffers} diplomacy offer(s) unanswered` : null,
      ].filter(Boolean);
      dom.turnModal.innerHTML = `
        <div class="command-turn-card">
          <div class="command-kicker">Turn Confirmation</div>
          <h2>End Campaign Turn?</h2>
          <div class="command-turn-list">${pending.map((entry) => `<div class="command-turn-item">${escapeHtml(entry)}</div>`).join('') || '<div class="command-turn-item">No pending blockers. The board is ready to advance.</div>'}</div>
          <div class="command-bottom-actions">
            ${buttonMarkup('Cancel', 'close-turn-modal', 'command-button-secondary')}
            ${buttonMarkup('End Turn Anyway', 'confirm-end-turn', 'command-button')}
          </div>
        </div>
      `;
    } else {
      const summary = toArray(payload?.summary).map((entry) => `<div class="command-turn-item"><strong>${escapeHtml(entry.title)}</strong><div class="command-small-copy">${escapeHtml(entry.body)}</div></div>`).join('');
      dom.turnModal.innerHTML = `
        <div class="command-turn-card">
          <div class="command-kicker">Turn Summary</div>
          <h2>Turn ${escapeHtml(payload?.turn ?? state.turn)} Begins</h2>
          <div class="command-turn-list">${summary || '<div class="command-turn-item">No major changes were reported this turn.</div>'}</div>
          <div class="command-bottom-actions">
            ${buttonMarkup('Continue', 'close-turn-modal', 'command-button')}
          </div>
        </div>
      `;
    }
    dom.turnModal.classList.remove('hidden');
  }

  function ensureLiveMapVisible(tab = 'match') {
    closeCommandCenter();
    if (typeof global.ensureLobbyPanelOpen === 'function') {
      global.ensureLobbyPanelOpen(true).then(() => {
        if (typeof global.showTab === 'function') global.showTab(tab);
      });
    }
  }

  function actionWorldId(dataset) {
    return dataset.world || uiState.currentState?.selectedWorld?.worldId || null;
  }

  function actionPlanetId(dataset) {
    return dataset.planet || uiState.currentState?.selectedWorld?.planetId || null;
  }

  function invokeLiveBridge(fnName, args = [], fallbackRoute = '#/command', unavailableMessage = 'The live conquest tool is still warming up.') {
    const bridge = global?.[fnName];
    if (typeof bridge === 'function') {
      bridge(...args);
      return true;
    }
    showToast('Reinitializing live conquest tools...', 2200);
    ensureLauncherRuntime([fnName]).then((ready) => {
      const recovered = ready ? global?.[fnName] : null;
      if (typeof recovered === 'function') {
        recovered(...args);
        return;
      }
      showToast(unavailableMessage, 3200);
      if (fallbackRoute) {
        if (global.location.hash === fallbackRoute) renderCommandCenter();
        else global.location.hash = fallbackRoute;
      }
    });
    return false;
  }

  function handleAction(action, source) {
    if (!action) return;
    if (action === 'open-inventory') { global.CardForgeCollection?.inventory(); return; }
    const data = source?.dataset ?? {};
    if (action === 'route') {
      const route = data.route || '#/command';
      if (global.location.hash === route) renderCommandCenter();
      else global.location.hash = route;
      return;
    }
    if (action === 'activity-tab') {
      uiState.activityTab = data.tab || 'alerts';
      renderRightPanel(uiState.currentState);
      return;
    }
    if (action === 'close-command-center') {
      closeCommandCenter();
      return;
    }
    if (action === 'open-live-map') {
      ensureLiveMapVisible('match');
      return;
    }
    if (action === 'open-market-tab') {
      ensureLiveMapVisible('market');
      return;
    }
    if (action === 'open-deck-tab') {
      ensureLiveMapVisible('deck');
      return;
    }
    if (action === 'open-codex-tab') {
      ensureLiveMapVisible('carnifex');
      return;
    }
    if (action === 'open-stats-tab') {
      ensureLiveMapVisible('stats');
      return;
    }
    if (action === 'open-dev-wip-ui') {
      dom.devWipTrigger?.click();
      return;
    }
    if (action === 'open-card-ui-settings') {
      dom.cardUiTrigger?.click();
      return;
    }
    if (action === 'open-game-features') {
      try {
        global.open?.('./GameFeatures.html', '_blank', 'noopener');
      } catch {
        global.location.assign('./GameFeatures.html');
      }
      return;
    }
    if (action === 'quick-battle') {
      global.location.assign('./game/index.html');
      return;
    }
    if (action === 'save-profile') {
      try {
        global.saveProfile?.(global.loadProfile?.());
        showToast('Campaign profile saved and synced.', 2600);
      } catch (error) {
        showToast(`Save failed: ${error?.message ?? error}`, 3600);
      }
      return;
    }
    if (action === 'end-turn') {
      renderTurnModal('confirm');
      return;
    }
    if (action === 'close-turn-modal') {
      dom.turnModal?.classList.add('hidden');
      renderCommandCenter();
      return;
    }
    if (action === 'confirm-end-turn') {
      const summary = campaignApi.endTurnSummary();
      renderTurnModal('summary', summary);
      renderCommandCenter();
      return;
      }
      if (action === 'open-war-council-modal') {
        invokeLiveBridge('openWarCouncilModal', [actionWorldId(data)], '#/command/war-council', 'War Council detail tools are still warming up. Staying in the command shell.');
        return;
      }
      if (action === 'open-planet-command') {
        invokeLiveBridge('openPlanetCommandModal', [actionWorldId(data), actionPlanetId(data)], '#/command/map', 'Planet Command is still warming up. Staying in the command shell.');
        return;
      }
      if (action === 'open-conquest-forge') {
        invokeLiveBridge('openConquestForgeModal', [actionWorldId(data), actionPlanetId(data)], '#/command/forge', 'Forge tools are still warming up. Staying in the command shell.');
        return;
      }
      if (action === 'open-research-modal') {
        invokeLiveBridge('openConquestResearchModal', [actionWorldId(data), actionPlanetId(data)], '#/command/forge', 'Research tools are still warming up. Staying in the command shell.');
        return;
      }
      if (action === 'open-tactics-library') {
        invokeLiveBridge('openTacticsLibraryModal', [actionWorldId(data), actionPlanetId(data)], '#/command/codex', 'Tactics Library is still warming up. Staying in the command shell.');
        return;
      }
      if (action === 'open-attack-deck-modal') {
        invokeLiveBridge('openConquestAttackDeckModal', [actionWorldId(data), actionPlanetId(data)], '#/command/deck-vault', 'Attack deck tools are still warming up. Staying in the command shell.');
        return;
      }
      if (action === 'open-conquest-world') {
        const worldId = actionWorldId(data);
        invokeLiveBridge('openConquestModal', [worldId, global.allAiProfiles?.() ?? [], actionPlanetId(data)], '#/command/map', 'Campaign map tools are still warming up. Staying in the command shell.');
      }
    }

  function onHashChange() {
    if (global.location.hash.startsWith('#/command')) {
      openCommandCenter(global.location.hash, { skipLoading: uiState.open });
      return;
    }
    if (uiState.open) closeCommandCenter({ setLobbyHash: false });
  }

  function bindShellEvents() {
    if (!dom.shell) return;
    dom.shell.addEventListener('click', (event) => {
      const target = event.target instanceof Element ? event.target.closest('[data-command-action]') : null;
      if (!(target instanceof HTMLElement)) return;
      event.preventDefault();
      handleAction(target.dataset.commandAction, target);
    });
  }

  function bindEntryPoints() {
    if (dom.continueBtn) dom.continueBtn.onclick = () => {
      if (global.CardForgeFoundationCampaign?.resume?.()) return;
      global.location.hash = '#/command';
    };
    if (dom.confirmNewBtn) {
      dom.confirmNewBtn.addEventListener('click', () => {
        setTimeout(() => {
          if (document.body.classList.contains('foundation-active')) return;
          global.location.hash = '#/command';
        }, 0);
      });
    }
    if (dom.deckVaultBtn) dom.deckVaultBtn.onclick = () => { global.location.hash = '#/command/deck-vault'; };
    if (dom.forgeBtn) dom.forgeBtn.onclick = () => { global.location.hash = '#/command/forge'; };
    if (dom.codexBtn) dom.codexBtn.onclick = () => { global.location.hash = '#/command/codex'; };
    if (dom.settingsBtn) dom.settingsBtn.onclick = () => { global.location.hash = '#/command/settings'; };
    if (dom.devWipBtn) {
      dom.devWipBtn.onclick = async () => {
        if (typeof global.openDevWipUiModal === 'function' && typeof global.CardForgeCardPresentation === 'object') {
          global.openDevWipUiModal();
          return;
        }
        const ready = await ensureLauncherRuntime(['openDevWipUiModal']);
        if (ready && typeof global.openDevWipUiModal === 'function' && typeof global.CardForgeCardPresentation === 'object') {
          global.openDevWipUiModal();
          return;
        }
        if (dom.devWipTrigger instanceof HTMLElement) {
          dom.devWipTrigger.click();
          return;
        }
        showToast('dev_WIP_UI is still unavailable. Try again in a moment.', 3200);
      };
    }
    if (dom.exitBtn) dom.exitBtn.onclick = () => showToast('Close the browser tab or app window to exit CardForge.', 3200);
    if (dom.commandCenterBtn) dom.commandCenterBtn.onclick = () => { global.location.hash = '#/command'; };
  }

  bindShellEvents();
  bindEntryPoints();
  global.addEventListener('hashchange', onHashChange);
  if (global.location.hash.startsWith('#/command')) openCommandCenter(global.location.hash, { skipLoading: false });

  global.CardForgeCommandCenter = {
    open: openCommandCenter,
    close: closeCommandCenter,
    render: renderCommandCenter,
  };
  global.__commandCenterDebug = { dom, uiState, renderCommandCenter, renderTopbar };
}(window));
