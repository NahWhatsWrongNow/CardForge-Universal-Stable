
const lc = (value) => String(value ?? '').toLowerCase();
const arr = (value) => Array.isArray(value) ? value : [];

const textOf = (card = {}) => `${card?.name ?? ''} ${card?.text ?? ''} ${arr(card?.tags).join(' ')} ${arr(card?.keywords).join(' ')} ${card?.element ?? ''} ${card?.race ?? ''}`.toLowerCase();
const normalizeEntries = (entries = []) => arr(entries)
  .map((entry) => (typeof entry === 'string'
    ? { text: entry, weight: 1 }
    : { text: entry?.text ?? '', weight: Math.max(0.2, Number(entry?.weight ?? 1)) }))
  .filter((entry) => entry.text);
const finiteOrNull = (value) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};
const rarityBandWeight = (rarity = '') => {
  switch (lc(rarity)) {
    case 'legendary': return 1.3;
    case 'epic': return 0.8;
    case 'rare': return 0.4;
    case 'uncommon': return 0.18;
    default: return 0;
  }
};

function isIntentionalZeroCost(card = {}) {
  const type = lc(card?.type ?? 'minion');
  const text = textOf(card);
  const attack = Math.max(0, Number(card?.attack ?? 0));
  const health = Math.max(0, Number(card?.health ?? card?.maxHealth ?? 0));
  const def = Math.max(0, Number(card?.def ?? card?.baseDef ?? 0));
  const directDamage = Math.max(0, Number(card?.damage ?? 0));
  const healing = Math.max(0, Number(card?.heal ?? card?.restore ?? 0));
  if (card?.allowZeroCost || card?.zeroCost === true) return true;
  if (/costs? ?\(0\)|zero[- ]cost|free to cast|costs? 0/.test(text)) return true;
  if (type === 'token') return true;
  if (/token|generated token/.test(text) && (attack + health + def + directDamage + healing) <= 3) return true;
  if (['field', 'relic', 'artifact', 'aura', 'trap'].includes(type)) return false;
  if (attack === 0 && health <= 1 && def === 0 && directDamage === 0 && healing === 0) return true;
  return (attack + health + def + directDamage + healing) <= 2 && !text.trim();
}

export function readCardManaCost(card = {}, fallback = null) {
  const direct = finiteOrNull(card?.cost);
  if (direct != null) return Math.max(0, direct);
  const objectCost = card?.cost;
  if (objectCost && typeof objectCost === 'object') {
    const nested = finiteOrNull(
      objectCost.mana
      ?? objectCost.value
      ?? objectCost.base
      ?? objectCost.total
      ?? objectCost.amount
      ?? objectCost.cost,
    );
    if (nested != null) return Math.max(0, nested);
  }
  const alternates = [
    card?.manaCost,
    card?.castCost,
    card?.mana,
    card?.energyCost,
    card?.cmc,
  ];
  for (const candidate of alternates) {
    const parsed = finiteOrNull(candidate);
    if (parsed != null) return Math.max(0, parsed);
  }
  return fallback == null ? null : Math.max(0, Number(fallback) || 0);
}

export function inferAiCardManaCost(card = {}, profile = {}) {
  const explicit = readCardManaCost(card, null);
  if (explicit != null && (explicit > 0 || isIntentionalZeroCost(card))) return explicit;

  const type = lc(card?.type ?? 'minion');
  const text = textOf(card);
  const attack = Math.max(0, Number(card?.attack ?? 0));
  const health = Math.max(0, Number(card?.health ?? card?.maxHealth ?? 0));
  const def = Math.max(0, Number(card?.def ?? card?.baseDef ?? 0));
  const range = Math.max(0, Number(card?.range ?? 0));
  const heal = Math.max(0, Number(card?.heal ?? card?.restore ?? 0));
  const damage = Math.max(0, Number(card?.damage ?? 0));
  const strategy = lc(profile?.strategy ?? profile?.deckIdentity?.primary ?? '');
  let estimate = 0.18 + (attack * 0.5) + (health * 0.32) + (def * 0.38) + (range * 0.24);

  if (type === 'spell' || type === 'instant' || type === 'sorcery') {
    estimate = 0.9 + (damage * 0.28) + (heal * 0.22);
    if (/draw|discover|copy|reorder|look at the top/.test(text)) estimate += 1.15;
    if (/destroy|silence|counter|return .* hand|freeze/.test(text)) estimate += 1.5;
    if (/summon|token|echo|swarm/.test(text)) estimate += 0.95;
    if (/aoe|all enemies|all minions|split among/.test(text)) estimate += 0.8;
  } else if (['field', 'relic', 'artifact', 'aura', 'trap'].includes(type)) {
    estimate = 1.6 + (damage * 0.18) + (heal * 0.16);
    if (/draw|discover|copy|reduce|your .* have|\bwhenever\b/.test(text)) estimate += 1.25;
    if (/summon|token|echo|swarm/.test(text)) estimate += 0.9;
    if (/destroy|silence|counter|freeze/.test(text)) estimate += 0.75;
  } else if (['barricade', 'structure', 'fortress', 'turret', 'reactor'].includes(type)) {
    estimate = 1.1 + (attack * 0.26) + (health * 0.34) + (def * 0.45) + (range * 0.28);
    if (/draw|mana|supply|heal|shield|fortify/.test(text)) estimate += 0.8;
  }

  if (card?.taunt || card?.guard || /taunt|guard/.test(text)) estimate += 0.55;
  if (card?.charge || /charge|rush|haste|attack immediately/.test(text)) estimate += 0.8;
  if (card?.trueDamage || /true damage|ignores armor|pierce all/.test(text)) estimate += 1.05;
  if (card?.allowMultiAttack || /double attack|multi-attack|attack twice/.test(text)) estimate += 0.95;
  if (card?.stealth || card?.statuses?.stealth || /stealth|hidden/.test(text)) estimate += 0.6;
  estimate += Math.max(0, Number(card?.pierce ?? 0)) * 0.26;
  estimate += rarityBandWeight(card?.rarity);

  if (strategy === 'tempo' || strategy === 'aggro') estimate -= 0.08;
  if (strategy === 'control' || strategy === 'value') estimate += 0.18;

  return Math.max(1, Math.round(estimate));
}

export function normalizeAiCard(card = {}, profile = {}, index = 0) {
  const normalized = { ...card };
  const cost = inferAiCardManaCost(normalized, profile);
  normalized.cost = cost;
  if (readCardManaCost(normalized, null) == null || finiteOrNull(normalized.manaCost) == null) normalized.manaCost = cost;
  if (!normalized.type) normalized.type = 'minion';
  if (!normalized.id && normalized.name) normalized.id = `${lc(profile?.id ?? 'ai')}-${lc(normalized.name).replace(/[^a-z0-9]+/g, '-')}-${index + 1}`;
  return normalized;
}

export function normalizeAiCards(cards = [], profile = {}) {
  return arr(cards).map((card, index) => normalizeAiCard(card, profile, index));
}

export const AI_ARCHETYPES = {
  executioner: {
    name: 'The Executioner',
    biases: { aggression: 0.45, face: 0.45, trade: 1.38, removal: 1.45, survival: 1.12, combo: 0.62, risk: 0.32, wide: 0.72, clear: 1.35, engine: 1.22, lethal: 1.15, antiBait: 1.32, siege: 0.95 },
    seeds: ['remove the error', 'cut away the threat', 'solve the board cleanly'],
    thinking: ['Isolating the highest-value threat...', 'Cleaning the exchange tree...', 'Prioritizing the execution line...'],
  },
  stampede: {
    name: 'The Stampede',
    biases: { aggression: 1.42, face: 1.5, trade: 0.62, removal: 0.6, survival: 0.62, combo: 0.55, risk: 1.25, wide: 1.22, clear: 0.35, engine: 0.55, lethal: 1.5, antiBait: 0.62, siege: 0.9 },
    seeds: ['keep the pressure high', 'race the life total', 'hit before they settle'],
    thinking: ['Pushing damage windows...', 'Scanning for lethal pressure...', 'Tempo first. Regret later...'],
  },
  scholar: {
    name: 'The Scholar',
    biases: { aggression: 0.6, face: 0.56, trade: 0.95, removal: 1.02, survival: 0.9, combo: 1.45, risk: 0.58, wide: 0.62, clear: 0.94, engine: 1.35, lethal: 1.18, antiBait: 1.22, siege: 0.82 },
    seeds: ['sequence for value', 'prepare the next turn', 'hold until the line is real'],
    thinking: ['Sequencing for compound value...', 'Projecting the next two turns...', 'Evaluating setup versus release...'],
  },
  fortress: {
    name: 'The Fortress',
    biases: { aggression: 0.34, face: 0.28, trade: 1.12, removal: 1.08, survival: 1.5, combo: 0.52, risk: 0.25, wide: 0.55, clear: 1.18, engine: 1.18, lethal: 0.9, antiBait: 1.26, siege: 1.12 },
    seeds: ['stabilize first', 'anchor the line', 'let them break on the wall'],
    thinking: ['Reinforcing survival lines...', 'Evaluating stabilization thresholds...', 'Wall first. Counterattack second...'],
  },
  hunter: {
    name: 'The Hunter',
    biases: { aggression: 0.82, face: 0.66, trade: 1.22, removal: 1.34, survival: 0.9, combo: 0.8, risk: 0.72, wide: 0.58, clear: 0.8, engine: 0.92, lethal: 1.12, antiBait: 1.35, siege: 0.88 },
    seeds: ['kill the engine', 'mark the weak point', 'remove the support first'],
    thinking: ['Marking priority prey...', 'Scanning for support pieces...', 'Identifying the soft joint in the line...'],
  },
  tyrant: {
    name: 'The Tyrant',
    biases: { aggression: 1.02, face: 0.92, trade: 1.05, removal: 0.94, survival: 0.86, combo: 0.62, risk: 0.68, wide: 0.82, clear: 0.62, engine: 0.7, lethal: 1.22, antiBait: 1.08, siege: 1.02 },
    seeds: ['curve out hard', 'convert board into damage', 'force them to answer'],
    thinking: ['Pressing the curve advantage...', 'Converting board control into damage...', 'Choosing the highest-pressure lane...'],
  },
  gambler: {
    name: 'The Gambler',
    biases: { aggression: 0.92, face: 0.84, trade: 0.78, removal: 0.72, survival: 0.68, combo: 0.96, risk: 1.48, wide: 0.86, clear: 0.74, engine: 0.62, lethal: 1.18, antiBait: 0.7, siege: 0.9 },
    seeds: ['take the live line', 'accept the swing', 'bet on the higher ceiling'],
    thinking: ['Comparing safe line against spicy line...', 'Expected value still favors the swing...', 'Variance accepted. Proceeding...'],
  },
  oracle: {
    name: 'The Oracle',
    biases: { aggression: 0.52, face: 0.48, trade: 1.1, removal: 1.18, survival: 1.08, combo: 1.02, risk: 0.42, wide: 0.66, clear: 1.18, engine: 1.26, lethal: 1.1, antiBait: 1.45, siege: 0.98 },
    seeds: ['preserve the answer', 'respect the future turn', 'punish overcommitment'],
    thinking: ['Projecting counterfactual branches...', 'Estimating next-turn punishment...', 'Preserving the answer that matters...'],
  },
  'swarm-mind': {
    name: 'The Swarm Mind',
    biases: { aggression: 1.08, face: 0.94, trade: 0.74, removal: 0.58, survival: 0.78, combo: 0.88, risk: 1.02, wide: 1.5, clear: 0.34, engine: 0.72, lethal: 1.28, antiBait: 0.76, siege: 0.82 },
    seeds: ['count bodies not cards', 'time the mass buff', 'refill after the sweep'],
    thinking: ['Counting bodies and buff windows...', 'Flooding before the sweep threshold...', 'Evaluating wide-board conversion...'],
  },
  'war-engine': {
    name: 'The War Engine',
    biases: { aggression: 0.74, face: 0.62, trade: 1.08, removal: 1.12, survival: 1.18, combo: 0.7, risk: 0.42, wide: 0.66, clear: 1.04, engine: 1.25, lethal: 1.05, antiBait: 1.18, siege: 1.48 },
    seeds: ['fortify the lane', 'protect the structure line', 'grind through attrition'],
    thinking: ['Surveying fortified lanes...', 'Projecting siege value and structure loss...', 'Choosing the highest-pressure firing line...'],
  },
  revenant: {
    name: 'The Revenant',
    biases: { aggression: 0.78, face: 0.7, trade: 1.02, removal: 0.92, survival: 0.94, combo: 1.02, risk: 0.88, wide: 1.05, clear: 0.84, engine: 0.95, lethal: 1.08, antiBait: 0.96, siege: 0.86 },
    seeds: ['trade into recursion', 'value the death trigger', 'count what comes back'],
    thinking: ['Evaluating death value and return lines...', 'Converting bodies into recurrence...', 'Counting what returns after the trade...'],
  },
};

export const VALID_AI_ARCHETYPES = Object.freeze(Object.keys(AI_ARCHETYPES));

const PROFILE_ARCHETYPE_MAP = {
  easy: 'stampede',
  normal: 'tyrant',
  hard: 'executioner',
  insane: 'oracle',
  'boss-lich': 'revenant',
  tidemind: 'swarm-mind',
  'iron-warden': 'fortress',
  'star-oracle': 'oracle',
  nivinis: 'oracle',
  'neural-ai': 'scholar',
  'kael-veyrn': 'executioner',
  'saito-kurose': 'hunter',
  'mara-kest': 'hunter',
  'rhea-sol': 'tyrant',
  'lys-calder': 'scholar',
  'ivo-senn': 'gambler',
  emberqueen: 'stampede',
  riftmarshal: 'war-engine',
  moonveil: 'oracle',
  thorne: 'executioner',
};

const DIFFICULTY_BY_ID = {
  easy: 'Easy',
  normal: 'Normal',
  hard: 'Hard',
  insane: 'Expert',
  'neural-ai': 'Mythic',
  nivinis: 'Mythic',
};

const EVENT_ALIASES = {
  intro: ['intro', 'pre_match'],
  pre_match: ['pre_match', 'intro'],
  mulligan: ['mulligan', 'opening'],
  start_turn: ['start_turn', 'board_lead'],
  early_pressure: ['early_pressure', 'strong_play'],
  signature_play: ['signature_play', 'strong_play'],
  combo_assembled: ['combo_assembled', 'combo_ready'],
  removal_used: ['removal_used', 'strong_play'],
  board_clear: ['board_clear'],
  topdeck_answer: ['topdeck_answer'],
  respect_enemy: ['respect_enemy', 'big_enemy_seen', 'lethal_threatened'],
  under_pressure: ['under_pressure', 'low_health'],
  near_death: ['near_death', 'low_health'],
  stabilizing: ['stabilizing', 'low_health'],
  lethal_found: ['lethal_found', 'victory_near'],
  victory_near: ['victory_near', 'lethal_found'],
  whiff: ['whiff'],
  victory: ['victory', 'victory_near'],
  defeat: ['defeat'],
};
const ARCHETYPE_DIALOGUE = {
  executioner: {
    pre_match: ['Procedure begins now.', 'I only need one clean window.'],
    mulligan: ['Openers are for scalpels, not trophies.'],
    start_turn: ['Re-evaluating the kill order.', 'The board still has a solvable error.'],
    early_pressure: ['Pressure is just another form of leverage.'],
    signature_play: ['That piece was always meant to fall.'],
    combo_assembled: ['The sequence is now clinically complete.'],
    removal_used: ['Threat excised.', 'That card was living on borrowed time.'],
    board_clear: ['Sanitized.', 'We begin from a cleaner board.'],
    topdeck_answer: ['Timely. Efficient. Final.'],
    respect_enemy: ['I respect that threat enough to kill it first.'],
    under_pressure: ['Pressure acknowledged. Not accepted.'],
    near_death: ['Vitals unstable. Discipline remains.'],
    stabilizing: ['Line restored. Continue.'],
    lethal_found: ['Execution line located.'],
    victory_near: ['You are out of valid defenses.'],
    whiff: ['Imperfect. I dislike imperfect.'],
    victory: ['Case closed.'],
    defeat: ['You escaped the sentence. This time.'],
  },
  stampede: {
    pre_match: ['Good. Run at me.', 'Let us see who breaks first.'],
    mulligan: ['Low curve. Fast hands. No fear.'],
    start_turn: ['Keep running. Keep hitting.', 'The board is only a runway.'],
    early_pressure: ['There. Feel that tempo.', 'More bodies. More damage.'],
    signature_play: ['Now that is a proper charge.'],
    combo_assembled: ['All pressure. No brakes.'],
    removal_used: ['Out of the way.'],
    board_clear: ['Then I refill and do it again.'],
    topdeck_answer: ['Ha. Still live.'],
    respect_enemy: ['That one bites back. Kill it later. Maybe.'],
    under_pressure: ['If I am dying, you are racing me there.'],
    near_death: ['Good. Makes the turn sharper.'],
    stabilizing: ['Still moving. Still dangerous.'],
    lethal_found: ['I smell the finish.'],
    victory_near: ['You are one swing from trampled.'],
    whiff: ['Too slow. Hate that.'],
    victory: ['Momentum wins again.'],
    defeat: ['Fine. You stopped the charge.'],
  },
  scholar: {
    pre_match: ['Let us test whether your sequencing survives scrutiny.', 'I prefer lines that improve on the second reading.'],
    mulligan: ['Setup first. Payoff later.'],
    start_turn: ['The next branch is clearer now.', 'This turn depends on order, not force.'],
    early_pressure: ['A modest lead is sufficient if sequenced correctly.'],
    signature_play: ['Now the engine becomes visible.'],
    combo_assembled: ['All prerequisites satisfied.'],
    removal_used: ['That exchange was educational.'],
    board_clear: ['The clutter was obscuring the real game.'],
    topdeck_answer: ['The correct chapter arrived on time.'],
    respect_enemy: ['I respect that card enough to plan around it.'],
    under_pressure: ['Interesting. The exam just became timed.'],
    near_death: ['The margin is thin, not absent.'],
    stabilizing: ['The line holds after all.'],
    lethal_found: ['Proof complete.'],
    victory_near: ['Your options have collapsed elegantly.'],
    whiff: ['Incorrect ordering. Noted.'],
    victory: ['The thesis stands.'],
    defeat: ['Well reasoned. I concede the branch.'],
  },
  fortress: {
    pre_match: ['Stand firm and begin.', 'Break yourself against the wall if you must.'],
    mulligan: ['Anchor pieces first.'],
    start_turn: ['Reinforce. Recover. Advance only when safe.', 'The line still holds.'],
    early_pressure: ['A wall can lean forward too.'],
    signature_play: ['Another stone in the foundation.'],
    combo_assembled: ['Now the line is difficult to break.'],
    removal_used: ['One more crack sealed.'],
    board_clear: ['The field is empty. My defenses are not.'],
    topdeck_answer: ['The bastion provides.'],
    respect_enemy: ['That threat deserves a thicker gate.'],
    under_pressure: ['Pressure is expected. Collapse is not.'],
    near_death: ['Still standing.'],
    stabilizing: ['The wall is whole again.'],
    lethal_found: ['Enough defense. Time to close.'],
    victory_near: ['You cannot breach this and survive it.'],
    whiff: ['Poor mortar. I will correct it.'],
    victory: ['You broke before the line did.'],
    defeat: ['So. Even walls can fall.'],
  },
  hunter: {
    pre_match: ['Hold still. I only need the weak point.', 'Every board has exposed tissue somewhere.'],
    mulligan: ['Tools first. Prey later.'],
    start_turn: ['Marking targets.', 'The support piece dies first.'],
    early_pressure: ['I have the scent now.'],
    signature_play: ['There. Soft underbelly.'],
    combo_assembled: ['Trap set.'],
    removal_used: ['Target down.', 'The important one is gone now.'],
    board_clear: ['Nothing left worth tracking.'],
    topdeck_answer: ['Good. Fresh ammunition.'],
    respect_enemy: ['That engine lives too long if ignored.'],
    under_pressure: ['Cornered things still have teeth.'],
    near_death: ['Close. But I can still kill something important.'],
    stabilizing: ['The prey overstepped.'],
    lethal_found: ['The artery is open.'],
    victory_near: ['Run if you want. It changes nothing.'],
    whiff: ['Bad angle.'],
    victory: ['Clean hunt.'],
    defeat: ['You slipped the trap.'],
  },
  tyrant: {
    pre_match: ['Kneel or contest me properly.', 'I intend to own the curve and the board.'],
    mulligan: ['Strong curve. Stronger close.'],
    start_turn: ['The board answers to strength.', 'Continue the pressure.'],
    early_pressure: ['You are already reacting. Good.'],
    signature_play: ['Power looks better in my hands.'],
    combo_assembled: ['The board now belongs to me.'],
    removal_used: ['You were in the way.'],
    board_clear: ['Now rebuild under my shadow.'],
    topdeck_answer: ['Convenient.'],
    respect_enemy: ['A proper threat. I will take it personally.'],
    under_pressure: ['You confuse resistance with control.'],
    near_death: ['I have survived worse than desperation.'],
    stabilizing: ['The pressure shifts back to you.'],
    lethal_found: ['Enough posturing. End it.'],
    victory_near: ['You are outmatched and nearly out of time.'],
    whiff: ['A temporary indignity.'],
    victory: ['Authority restored.'],
    defeat: ['You earned that defiance.'],
  },
  gambler: {
    pre_match: ['Let us see which branch pays out.', 'I like lines with a little voltage in them.'],
    mulligan: ['Keep the live ones. Toss the dead ones.'],
    start_turn: ['Odds first. Nerves second.', 'Risk budget approved.'],
    early_pressure: ['That is a hot line.'],
    signature_play: ['Oh, that one sings.'],
    combo_assembled: ['Now we spin the wheel.'],
    removal_used: ['High roll enough for you?'],
    board_clear: ['Messy. Profitable.'],
    topdeck_answer: ['Ha. Dealer favors me today.'],
    respect_enemy: ['That card could ruin a good wager.'],
    under_pressure: ['Good. Fear sharpens the odds.'],
    near_death: ['One live draw is still a draw.'],
    stabilizing: ['Variance swings both ways.'],
    lethal_found: ['That line is worth the risk.'],
    victory_near: ['You can feel the table turning.'],
    whiff: ['Unlucky. Not unplayable.'],
    victory: ['Paid in full.'],
    defeat: ['Bad beat. Clean result.'],
  },
  oracle: {
    pre_match: ['I have seen enough of this game to begin.', 'The line you fear is already forming.'],
    mulligan: ['Keep the answers that matter later.'],
    start_turn: ['The future just narrowed.', 'A few bad branches have disappeared for you.'],
    early_pressure: ['Pressure is more useful when it arrives on schedule.'],
    signature_play: ['This was visible a turn ago.'],
    combo_assembled: ['Prediction and timing now agree.'],
    removal_used: ['I kept that answer for exactly this moment.'],
    board_clear: ['Your overcommitment was foretold.'],
    topdeck_answer: ['Call it foresight if you like.'],
    respect_enemy: ['Yes. That is the card that mattered.'],
    under_pressure: ['I accounted for this branch.'],
    near_death: ['Danger acknowledged. Panic declined.'],
    stabilizing: ['The storm passes where I allow it.'],
    lethal_found: ['One inevitable line remains.'],
    victory_near: ['You are standing in the future I preferred.'],
    whiff: ['That branch was noisier than expected.'],
    victory: ['The future settles in my favor.'],
    defeat: ['So. You stepped outside the forecast.'],
  },
  'swarm-mind': {
    pre_match: ['We arrive as many.', 'One body is a mistake. A hundred is a plan.'],
    mulligan: ['Bodies first. Anthem later.'],
    start_turn: ['Expand.', 'Another wave arrives.'],
    early_pressure: ['The line widens.', 'Count us now if you can.'],
    signature_play: ['The brood thickens.'],
    combo_assembled: ['Now the many become lethal.'],
    removal_used: ['One body spent. Many remain.'],
    board_clear: ['You swept the front edge only.'],
    topdeck_answer: ['Fresh biomass acquired.'],
    respect_enemy: ['That flame can thin the brood.'],
    under_pressure: ['We compress. Then surge.'],
    near_death: ['One nest remains enough.'],
    stabilizing: ['The colony reforms.'],
    lethal_found: ['Mass conversion threshold reached.'],
    victory_near: ['You are disappearing beneath volume.'],
    whiff: ['The wave broke early.'],
    victory: ['Consumed.'],
    defeat: ['The hive remembers this fire.'],
  },
  'war-engine': {
    pre_match: ['Siege protocol engaged.', 'Industrial pressure begins now.'],
    mulligan: ['Open with scaffolding and guns.'],
    start_turn: ['Advance the line. Feed the engine.', 'Recalculate range and fortification.'],
    early_pressure: ['Attrition now favors me.'],
    signature_play: ['Hardpoint established.'],
    combo_assembled: ['Production and firing line synchronized.'],
    removal_used: ['Obstacle processed.'],
    board_clear: ['The lane is open for machinery.'],
    topdeck_answer: ['Timely ordinance received.'],
    respect_enemy: ['That unit threatens the structure line.'],
    under_pressure: ['Armor holds. Output remains stable.'],
    near_death: ['Critical, not terminal.'],
    stabilizing: ['Pressure redistributed.'],
    lethal_found: ['Final bombardment authorized.'],
    victory_near: ['You are being reduced to salvage.'],
    whiff: ['Miscalibration detected. Correcting.'],
    victory: ['Opposition dismantled.'],
    defeat: ['Frame breach acknowledged.'],
  },
  revenant: {
    pre_match: ['Nothing here stays dead for long.', 'Begin. I am interested in what returns.'],
    mulligan: ['Keep the pieces that like the grave.'],
    start_turn: ['The dead still contribute.', 'Losses can be reinterpreted.'],
    early_pressure: ['Trade freely. I welcome aftermath.'],
    signature_play: ['Good. Another body worth burying.'],
    combo_assembled: ['Now every death is profitable.'],
    removal_used: ['You are more useful on the way out.'],
    board_clear: ['The graveyard just got louder.'],
    topdeck_answer: ['The crypt provides.'],
    respect_enemy: ['That card should die before it teaches others.'],
    under_pressure: ['Desperation and recursion pair well.'],
    near_death: ['The living are always so alarmed by numbers.'],
    stabilizing: ['Ash settles. Bones rise.'],
    lethal_found: ['The last rites are ready.'],
    victory_near: ['You will join the count shortly.'],
    whiff: ['A corpse spent too early.'],
    victory: ['The grave grows by one.'],
    defeat: ['Even the dead can miscount.'],
  },
};
export function inferDeckIdentity(profile = {}, cards = []) {
  const profileBasis = { ...profile, deck: normalizeAiCards(profile.deck ?? [], profile), summons: normalizeAiCards(profile.summons ?? [], profile) };
  const deck = cards.length ? normalizeAiCards(cards, profileBasis) : [...profileBasis.deck, ...profileBasis.summons];
  const summary = {
    spells: 0,
    permanents: 0,
    structures: 0,
    draw: 0,
    removal: 0,
    heal: 0,
    tokens: 0,
    dragons: 0,
    beasts: 0,
    undead: 0,
    constructs: 0,
    stealth: 0,
    siege: 0,
    avgCost: 0,
  };
  let totalCost = 0;
  deck.forEach((card) => {
    const type = lc(card?.type ?? 'minion');
    const text = textOf(card);
    totalCost += readCardManaCost(card, 0) ?? 0;
    if (type === 'spell' || type === 'instant' || type === 'sorcery') summary.spells += 1;
    else summary.permanents += 1;
    if (['field', 'relic', 'artifact', 'aura', 'trap'].includes(type)) summary.permanents += 1;
    if (['barricade', 'structure', 'fortress', 'turret', 'reactor'].includes(type)) summary.structures += 1;
    if (/draw|discover|look at the top|reorder/.test(text)) summary.draw += 1;
    if (/deal \d+ damage|destroy|silence|return .* hand|freeze/.test(text)) summary.removal += 1;
    if (/restore|heal|lifesteal/.test(text)) summary.heal += 1;
    if (/summon|token|echo|fishling|deckhand/.test(text)) summary.tokens += 1;
    if (/dragon/.test(text) || lc(card?.race).includes('dragon')) summary.dragons += 1;
    if (/beast/.test(text) || lc(card?.race).includes('beast')) summary.beasts += 1;
    if (/undead|wraith|skeleton/.test(text) || lc(card?.race).includes('undead')) summary.undead += 1;
    if (/construct|machine|walker|turret/.test(text) || /construct|machine/.test(lc(card?.race))) summary.constructs += 1;
    if (/stealth|hidden/.test(text)) summary.stealth += 1;
    if (/siege|turret|structure|homestead|barricade/.test(text) || card?.siege || Number(card?.range ?? 0) >= 3) summary.siege += 1;
  });
  summary.avgCost = deck.length ? totalCost / deck.length : 0;
  const scores = [
    { id: 'aggro', score: (summary.avgCost <= 2.8 ? 3 : 0) + (summary.permanents > summary.spells ? 1 : 0) },
    { id: 'control', score: (summary.removal * 0.6) + (summary.heal * 0.4) + (summary.structures * 0.4) },
    { id: 'combo', score: (summary.draw * 0.6) + (summary.spells * 0.3) },
    { id: 'swarm', score: (summary.tokens * 0.8) + (summary.avgCost < 3.2 ? 1.2 : 0) },
    { id: 'relic-engine', score: (summary.permanents * 0.2) + (summary.draw * 0.2) },
    { id: 'siege', score: (summary.structures * 0.7) + (summary.siege * 0.7) },
    { id: 'dragon-ramp', score: (summary.dragons * 0.9) + (summary.avgCost > 4 ? 1 : 0) },
    { id: 'beast-pack', score: summary.beasts * 0.9 },
    { id: 'graveyard', score: (summary.undead * 0.9) + (summary.tokens * 0.3) },
    { id: 'stealth-value', score: (summary.stealth * 1.0) + (summary.draw * 0.2) },
    { id: 'midrange', score: 1.2 + (Math.abs(summary.avgCost - 3.6) < 1 ? 1 : 0) },
  ].sort((a, b) => b.score - a.score);
  return {
    primary: scores[0]?.id ?? lc(profile.strategy ?? 'midrange'),
    secondary: scores[1]?.id ?? null,
    summary,
    scores,
  };
}

export function inferArchetypeId(profile = {}, deckIdentity = null) {
  const explicit = lc(profile.aiArchetype ?? profile.personality?.archetypeId ?? '');
  if (explicit && AI_ARCHETYPES[explicit]) return explicit;
  const mapped = PROFILE_ARCHETYPE_MAP[lc(profile.id)];
  if (mapped) return mapped;
  const text = `${profile.name ?? ''} ${profile.personality?.title ?? ''} ${profile.deckIdentity ?? ''} ${profile.archetype ?? ''} ${profile.strategy ?? ''}`.toLowerCase();
  if (/oracle|future|prophe|prediction/.test(text)) return 'oracle';
  if (/fortress|warden|bastion|shield|wall/.test(text)) return 'fortress';
  if (/hunter|predator|assassin|mark/.test(text)) return 'hunter';
  if (/swarm|hive|tide|choir/.test(text)) return 'swarm-mind';
  if (/war|engine|siege|iron|machine|convoy/.test(text)) return 'war-engine';
  if (/gambl|chaos|lucky|wild/.test(text)) return 'gambler';
  if (/lich|grave|death|revenant|undead/.test(text)) return 'revenant';
  if (/scholar|sage|archiv|copy|combo|value/.test(text)) return 'scholar';
  if (/aggro|rush|tempo|stampede/.test(text)) return 'stampede';
  if (/control|execution|attrition/.test(text)) return 'executioner';
  switch (deckIdentity?.primary) {
    case 'aggro': return 'stampede';
    case 'control': return 'executioner';
    case 'combo': return 'scholar';
    case 'swarm': return 'swarm-mind';
    case 'siege': return 'war-engine';
    case 'dragon-ramp': return 'tyrant';
    case 'beast-pack': return 'hunter';
    case 'graveyard': return 'revenant';
    case 'stealth-value': return 'oracle';
    default: return 'tyrant';
  }
}

export function inferDifficultyBand(profile = {}) {
  const explicit = String(profile.difficultyBand ?? '').trim();
  if (explicit) return explicit;
  const mapped = DIFFICULTY_BY_ID[lc(profile.id)];
  if (mapped) return mapped;
  const level = Math.max(1, Number(profile.level ?? 1));
  if (level <= 3) return 'Easy';
  if (level <= 7) return 'Normal';
  if (level <= 14) return 'Hard';
  if (level <= 21) return 'Expert';
  return 'Mythic';
}

export function difficultyConfig(band = 'Normal') {
  const table = {
    Easy: { maxDepth: 2, beamWidth: 6, attackBranchLimit: 5, summonBranchLimit: 3, cardBranchLimit: 4, counterDepth: 1, playerBranchLimit: 4, candidateShortlist: 8, randomness: 0.28, comboDiscipline: 0.45, lookahead: 0.4, speechChance: 0.42, speechMinGapMs: 1450, speechTurnCap: 2, maxNonAttackPlays: 1, maxSummonsPerTurn: 1 },
    Normal: { maxDepth: 3, beamWidth: 10, attackBranchLimit: 7, summonBranchLimit: 4, cardBranchLimit: 6, counterDepth: 1, playerBranchLimit: 5, candidateShortlist: 10, randomness: 0.18, comboDiscipline: 0.62, lookahead: 0.58, speechChance: 0.52, speechMinGapMs: 1350, speechTurnCap: 2, maxNonAttackPlays: 2, maxSummonsPerTurn: 1 },
    Hard: { maxDepth: 4, beamWidth: 14, attackBranchLimit: 9, summonBranchLimit: 5, cardBranchLimit: 7, counterDepth: 2, playerBranchLimit: 6, candidateShortlist: 12, randomness: 0.1, comboDiscipline: 0.78, lookahead: 0.74, speechChance: 0.6, speechMinGapMs: 1250, speechTurnCap: 3, maxNonAttackPlays: 2, maxSummonsPerTurn: 2 },
    Expert: { maxDepth: 5, beamWidth: 18, attackBranchLimit: 12, summonBranchLimit: 6, cardBranchLimit: 9, counterDepth: 2, playerBranchLimit: 8, candidateShortlist: 14, randomness: 0.05, comboDiscipline: 0.88, lookahead: 0.86, speechChance: 0.68, speechMinGapMs: 1180, speechTurnCap: 3, maxNonAttackPlays: 3, maxSummonsPerTurn: 2 },
    Mythic: { maxDepth: 6, beamWidth: 24, attackBranchLimit: 14, summonBranchLimit: 7, cardBranchLimit: 11, counterDepth: 3, playerBranchLimit: 10, candidateShortlist: 16, randomness: 0.02, comboDiscipline: 0.96, lookahead: 1, speechChance: 0.76, speechMinGapMs: 1100, speechTurnCap: 4, maxNonAttackPlays: 4, maxSummonsPerTurn: 3 },
  };
  return table[band] ?? table.Normal;
}

export function enrichAiProfile(profile = {}, cards = []) {
  const normalizedDeck = normalizeAiCards(profile.deck ?? [], profile);
  const normalizedSummons = normalizeAiCards(profile.summons ?? [], profile);
  const normalizedProfile = { ...profile, deck: normalizedDeck, summons: normalizedSummons };
  const normalizedCards = cards.length ? normalizeAiCards(cards, normalizedProfile) : [...normalizedDeck, ...normalizedSummons];
  const deckIdentity = inferDeckIdentity(normalizedProfile, normalizedCards);
  const aiArchetype = inferArchetypeId(profile, deckIdentity);
  const difficultyBand = inferDifficultyBand(profile);
  return {
    ...normalizedProfile,
    aiArchetype,
    difficultyBand,
    deckIdentity,
    aiBiases: { ...(AI_ARCHETYPES[aiArchetype]?.biases ?? {}), ...(profile.aiBiases ?? {}) },
    aiArchetypeName: AI_ARCHETYPES[aiArchetype]?.name ?? 'The Tyrant',
  };
}

export function thinkingLinesFor(profile = {}) {
  const enriched = profile.aiArchetype ? profile : enrichAiProfile(profile);
  const explicit = [
    ...normalizeEntries(profile.thinkingLines),
    ...normalizeEntries(profile.personality?.thinkingLines),
  ].map((entry) => entry.text);
  return explicit.length
    ? explicit
    : AI_ARCHETYPES[enriched.aiArchetype]?.thinking ?? ['Evaluating board graph...'];
}

function profileSpeechDescriptor(profile = {}) {
  const title = String(profile.personality?.title ?? profile.title ?? '').trim();
  const name = String(profile.name ?? profile.id ?? 'Strategist').trim();
  const label = title && !name.toLowerCase().includes(title.toLowerCase()) ? title : name;
  const rawDimension = String(profile.personality?.dimensionTag ?? profile.dimensionTag ?? '').trim();
  const dimension = rawDimension.replace(/^#+/, '').replace(/[-_]+/g, ' ').trim();
  const strategy = lc(profile.strategy ?? profile.deckIdentity?.primary ?? '');
  const style = String(profile.personality?.chatStyle ?? '').trim();
  const backstory = String(profile.personality?.backstory ?? '').trim();
  const behavior = arr(profile.behaviorNotes).map((entry) => String(entry ?? '').trim()).filter(Boolean);
  return { label, dimension, strategy, style, backstory, behavior };
}

function generatedVoiceEntries(profile = {}, eventKey = 'start_turn') {
  const { label, dimension, strategy, style, backstory, behavior } = profileSpeechDescriptor(profile);
  const realm = dimension || 'their home frontier';
  const openingTag = behavior[0] ?? backstory;
  const formalTone = /formal|restrained|controlled|measured/i.test(style);
  const aggressiveTone = /aggro|tempo|stampede|hunter|tyrant/.test(strategy);
  const controlTone = /control|value|oracle|executioner|fortress|scholar/.test(strategy);
  const entries = {
    pre_match: [
      formalTone ? `${label}. Let us begin cleanly.` : `${label}. Let us see whose line survives.`,
      dimension ? `${realm} taught me not to waste the opening.` : `${label} values the first mistake more than the first boast.`,
      openingTag ? `${openingTag.replace(/\.$/, '')}. Keep that in mind.` : null,
    ],
    mulligan: [
      aggressiveTone ? 'Keep the live hand. Pressure matters first.' : 'A useful opener is worth more than a dramatic one.',
      controlTone ? 'I would rather keep structure than chase noise.' : null,
    ],
    start_turn: [
      aggressiveTone ? 'Window open. Push it.' : 'The board has clarified enough.',
      formalTone ? 'We proceed.' : `${label} still sees the line.`,
      dimension ? `${realm} rewards clean timing.` : null,
    ],
    early_pressure: [
      aggressiveTone ? 'Stay on the pressure.' : 'That turn has weight now.',
      controlTone ? 'Incremental advantage is still advantage.' : null,
    ],
    signature_play: [
      formalTone ? 'This is the correct sequence.' : 'That is the piece I wanted.',
      openingTag ? `${label} was always steering toward this exchange.` : null,
    ],
    combo_assembled: [
      'The pieces line up now.',
      controlTone ? 'Preparation has matured into a real line.' : 'The turn finally connects.',
    ],
    removal_used: [
      formalTone ? 'Necessary correction applied.' : 'That threat had to go.',
      aggressiveTone ? 'Clear the obstruction and keep moving.' : null,
    ],
    respect_enemy: [
      formalTone ? 'That card deserves immediate attention.' : 'That piece is not background noise.',
      dimension ? `${realm} would punish me for ignoring that.` : null,
    ],
    under_pressure: [
      controlTone ? 'Pressure noted. Structure remains.' : 'This is still playable.',
      aggressiveTone ? 'If the board is hot, then move faster.' : null,
    ],
    near_death: [
      formalTone ? 'The margin is poor, not absent.' : 'Still alive. Still dangerous.',
      dimension ? `${realm} has seen narrower escapes than this.` : null,
    ],
    stabilizing: [
      controlTone ? 'The turn settles back into order.' : 'Better. Now the game resumes.',
      formalTone ? 'The line holds again.' : null,
    ],
    lethal_found: [
      'The close is visible now.',
      aggressiveTone ? 'No more staging. End it.' : 'One clean sequence remains.',
    ],
    victory_near: [
      aggressiveTone ? 'You are one push from collapse.' : 'Your space is disappearing.',
      formalTone ? 'You are running out of valid replies.' : null,
    ],
    whiff: [
      formalTone ? 'Imperfect.' : 'That was not the turn I wanted.',
      'Recover. Continue.',
    ],
    victory: [
      profile.personality?.victoryLine ?? null,
      formalTone ? 'Result accepted.' : `${label} takes the duel.`,
    ],
    defeat: [
      'You found the better turn.',
      formalTone ? 'I will remember the exact point of failure.' : 'That line was yours.',
    ],
  };
  return normalizeEntries((entries[eventKey] ?? []).filter(Boolean));
}

function voicePoolFromProfile(profile = {}, eventKey = 'start_turn') {
  const aliases = EVENT_ALIASES[eventKey] ?? [eventKey];
  const pools = [];
  aliases.forEach((alias) => {
    pools.push(...normalizeEntries(profile.voiceLines?.[alias]).map((entry) => ({ ...entry, weight: entry.weight * 4 })));
    pools.push(...normalizeEntries(profile.personality?.voiceLines?.[alias]).map((entry) => ({ ...entry, weight: entry.weight * 3.5 })));
    pools.push(...generatedVoiceEntries(profile, alias).map((entry) => ({ ...entry, weight: entry.weight * 2.2 })));
  });
  return pools;
}

function voicePoolFromArchetype(enriched = {}, eventKey = 'start_turn') {
  const aliases = EVENT_ALIASES[eventKey] ?? [eventKey];
  const pack = ARCHETYPE_DIALOGUE[enriched.aiArchetype] ?? ARCHETYPE_DIALOGUE.tyrant;
  const pools = [];
  aliases.forEach((alias) => pools.push(...normalizeEntries(pack?.[alias])));
  return pools;
}

export function buildDialogueLine(profile = {}, eventKey = 'under_pressure', memory = {}) {
  const enriched = profile.aiArchetype ? profile : enrichAiProfile(profile);
  const archetype = AI_ARCHETYPES[enriched.aiArchetype] ?? AI_ARCHETYPES.tyrant;
  const last = memory?.last ?? null;
  const combined = [...voicePoolFromProfile(profile, eventKey), ...voicePoolFromArchetype(enriched, eventKey)];
  const normalized = (combined.length ? combined : normalizeEntries([`${archetype.name}: ${archetype.seeds[0]}.`])).map((entry) => ({
    text: entry.text,
    weight: Math.max(0.2, Number(entry.weight ?? 1)) * (entry.text === last ? 0.35 : 1),
  }));
  const total = normalized.reduce((sum, entry) => sum + entry.weight, 0);
  let roll = Math.random() * Math.max(total, 0.01);
  for (const entry of normalized) {
    roll -= entry.weight;
    if (roll <= 0) return entry.text;
  }
  if (eventKey === 'lethal_found') return `${archetype.name}: The line closes.`;
  if (eventKey === 'board_clear') return `${archetype.name}: The board resets in my favor.`;
  if (eventKey === 'topdeck_answer') return `${archetype.name}: Timely.`;
  if (eventKey === 'defeat') return `${archetype.name}: You found the better line.`;
  return `${archetype.name}: ${archetype.seeds[Math.floor(Math.random() * archetype.seeds.length)]}.`;
}

export function deckAffinityScore(card = {}, profile = {}) {
  const enriched = profile.aiArchetype ? profile : enrichAiProfile(profile);
  const text = textOf(card);
  const type = lc(card.type ?? 'minion');
  const cost = readCardManaCost(card, 0) ?? 0;
  const attack = Math.max(0, Number(card.attack ?? 0));
  const health = Math.max(0, Number(card.health ?? 0));
  const races = `${arr(card.races).join(' ')} ${card.race ?? ''}`.toLowerCase();
  const primary = enriched.deckIdentity?.primary ?? 'midrange';
  let score = 1 + (attack * 0.18) + (health * 0.12) - (cost * 0.08);

  if (/draw|discover|look at the top|reorder|copy/.test(text)) score += 1.2;
  if (/destroy|deal \d+ damage|silence|return .* hand|freeze|counter/.test(text)) score += 1.35;
  if (/restore|heal|lifesteal/.test(text)) score += 0.8;
  if (/summon|token|echo|swarm/.test(text)) score += 0.9;
  if (/taunt|guard/.test(text) || card.taunt) score += 0.9;
  if (/legendary|sovereign|colossus|matriarch/.test(text) || lc(card.rarity) === 'legendary') score += 0.45;
  if (/relic|field|artifact|aura|trap/.test(type)) score += 0.4;

  switch (enriched.aiArchetype) {
    case 'executioner':
      score += /destroy|silence|freeze|return .* hand|deal \d+ damage/.test(text) ? 2.2 : 0;
      score += /draw|discover/.test(text) ? 0.6 : 0;
      score -= /summon|token/.test(text) && cost >= 5 ? 0.4 : 0;
      break;
    case 'stampede':
      score += cost <= 3 ? 1.8 : -0.35 * Math.max(0, cost - 4);
      score += attack * 0.22;
      score += /charge|rush|haste|summon|token/.test(text) ? 1.4 : 0;
      score -= /heal|restore|relic|field/.test(text) ? 0.6 : 0;
      break;
    case 'scholar':
      score += /draw|discover|look at the top|reorder|copy|reduce/.test(text) ? 2.4 : 0;
      score += type === 'spell' ? 1.2 : 0;
      score -= cost >= 7 && !/draw|discover|copy|legendary/.test(text) ? 0.8 : 0;
      break;
    case 'fortress':
      score += /taunt|guard|heal|restore|shield|def|armor/.test(text) || card.taunt ? 2.2 : 0;
      score += health * 0.18;
      score += ['field', 'relic', 'barricade', 'structure'].includes(type) ? 1.1 : 0;
      break;
    case 'hunter':
      score += /destroy|deal \d+ damage|mark|freeze|silence|return .* hand/.test(text) ? 2.1 : 0;
      score += /stealth|rush/.test(text) ? 0.9 : 0;
      score += attack * 0.12;
      break;
    case 'tyrant':
      score += cost >= 3 && cost <= 6 ? 1.5 : 0;
      score += (attack + health) * 0.08;
      score += lc(card.rarity) === 'legendary' ? 0.6 : 0;
      break;
    case 'gambler':
      score += /random|discover|copy|transform|roulette|chaos|unpredictable/.test(text) ? 2.1 : 0;
      score += /draw/.test(text) ? 0.7 : 0;
      break;
    case 'oracle':
      score += /draw|look at the top|reorder|counter|freeze|silence/.test(text) ? 2.2 : 0;
      score += /relic|field/.test(type) ? 0.7 : 0;
      break;
    case 'swarm-mind':
      score += /summon|token|for each|all friendly|minions have/.test(text) ? 2.4 : 0;
      score += cost <= 3 ? 1.1 : -0.5 * Math.max(0, cost - 5);
      break;
    case 'war-engine':
      score += /structure|barricade|turret|siege|range|fortify|relic|field/.test(text) ? 2.4 : 0;
      score += /construct|machine/.test(races) ? 1.2 : 0;
      break;
    case 'revenant':
      score += /death|died|revive|grave|undead|wraith|skeleton|return from/.test(text) ? 2.3 : 0;
      score += /undead|wraith|skeleton/.test(races) ? 1.1 : 0;
      break;
    default:
      break;
  }

  switch (primary) {
    case 'aggro':
      score += cost <= 3 ? 1.2 : -0.3 * Math.max(0, cost - 5);
      break;
    case 'control':
      score += /destroy|silence|freeze|heal|taunt/.test(text) ? 1.3 : 0;
      break;
    case 'combo':
      score += /draw|discover|copy|reduce|reorder/.test(text) ? 1.5 : 0;
      break;
    case 'swarm':
      score += /summon|token|all friendly/.test(text) ? 1.6 : 0;
      break;
    case 'relic-engine':
      score += ['field', 'relic', 'aura', 'trap'].includes(type) ? 1.7 : 0;
      break;
    case 'siege':
      score += /structure|barricade|siege|turret/.test(text) ? 1.7 : 0;
      break;
    case 'dragon-ramp':
      score += /dragon/.test(races) ? 1.8 : 0;
      score += cost >= 5 ? 0.8 : 0;
      break;
    case 'beast-pack':
      score += /beast|tamer|handler/.test(text) || /beast/.test(races) ? 1.7 : 0;
      break;
    case 'graveyard':
      score += /death|revive|grave/.test(text) ? 1.7 : 0;
      break;
    case 'stealth-value':
      score += /stealth|hidden|bounce|draw/.test(text) ? 1.6 : 0;
      break;
    default:
      break;
  }

  return score;
}

export function mulliganCardScore(card = {}, profile = {}) {
  const enriched = profile.aiArchetype ? profile : enrichAiProfile(profile);
  const text = textOf(card);
  const cost = readCardManaCost(card, 0) ?? 0;
  let score = deckAffinityScore(card, enriched);

  switch (enriched.aiArchetype) {
    case 'stampede':
    case 'swarm-mind':
      score += cost <= 3 ? 2.2 : -1.2 * Math.max(0, cost - 4);
      break;
    case 'executioner':
    case 'oracle':
    case 'fortress':
      score += /destroy|silence|freeze|heal|taunt/.test(text) ? 1.8 : 0;
      score += cost >= 7 ? -1.1 : 0;
      break;
    case 'scholar':
      score += /draw|discover|copy|look at the top|reduce/.test(text) ? 2 : 0;
      score += cost >= 7 ? -0.8 : 0;
      break;
    case 'war-engine':
      score += /structure|barricade|turret|relic|field/.test(text) ? 1.6 : 0;
      break;
    default:
      score += cost >= 6 ? -0.7 : 0;
      break;
  }

  return score;
}
