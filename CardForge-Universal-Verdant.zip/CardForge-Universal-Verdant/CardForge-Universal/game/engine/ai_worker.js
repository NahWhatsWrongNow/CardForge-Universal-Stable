import { chooseTurnPlan, getPlannerDebug, restorePlannerMemory } from './ai.js';
self.onmessage = ({data}) => {
  try {
    restorePlannerMemory(data.profile?.id ?? data.profile?.name, data.memory);
    const plan = chooseTurnPlan(data.state, data.profile);
    self.postMessage({plan, debug: getPlannerDebug(data.profile?.id ?? data.profile?.name)});
  } catch (error) {
    self.postMessage({error: String(error?.message || error)});
  }
};
