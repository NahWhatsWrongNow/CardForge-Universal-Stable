// One contract for highlights and cast validation; no silent retargeting.
export function spellTargetRule(card, effect) {
  const text = String(card.text || '').toLowerCase();
  const structured = card.effect && Object.keys(card.effect).length;
  if (!structured && text) {
    if (/all |random |split |draw |summon /.test(text) && !/target|an? enemy minion|a friendly minion/.test(text)) return 'none';
    if (/your hero|friendly hero/.test(text) && !/minion/.test(text)) return 'ally-hero';
    if (/enemy hero|opposing hero/.test(text) && !/minion/.test(text)) return 'enemy-hero';
    if (/heal|restore/.test(text)) return /minion/.test(text) ? 'ally-unit' : 'ally';
    if (/friendly|allied/.test(text)) return 'ally-unit';
    if (/enemy minion|freeze|silence|destroy|return.*hand/.test(text)) return 'enemy-unit';
    if (/deal.*damage/.test(text)) return 'enemy';
    return 'none';
  }
  return ({dealDamage:'enemy',heal:'ally',grantDefense:'ally-unit',buffAttack:'ally-unit',buffHealth:'ally-unit',
    timeLock:'enemy-unit',shatterFront:'enemy-unit',sentence:'enemy-unit',poisonHero:'enemy-hero',tax:'enemy-hero',grantArmor:'ally-hero'})[effect.action] || 'none';
}
export function spellTargetIds(card, effect, side, state) {
  const rule = spellTargetRule(card, effect);
  if (rule === 'none') return [];
  const owner = rule.startsWith('ally') ? side : (side === 'player' ? 'enemy' : 'player');
  const units = (owner === 'player' ? state.playerMinions : state.enemyMinions) || [];
  const ids = rule.endsWith('-hero') ? [] : units.filter(u => u.health > 0 && (owner === side || !(u.stealth || u.statuses?.stealth))).map(u => u.id);
  if (!rule.endsWith('-unit')) ids.push(`${owner}-hero`);
  return ids;
}
