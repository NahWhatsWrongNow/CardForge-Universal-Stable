import { EventBus } from '../../core/events.js';

export const CONVERGENCE_EVENTS = Object.freeze({
  ACTION_REJECTED: 'convergence:action-rejected',
  CARD_PLAYED: 'convergence:card-played',
  MANA_CHANGED: 'convergence:mana-changed',
  MANA_STEP: 'convergence:mana-step',
  PRIORITY_CHANGED: 'convergence:priority-changed',
  STACK_CHANGED: 'convergence:stack-changed',
});

const clone = (value) => {
  if (typeof globalThis.structuredClone === 'function') return globalThis.structuredClone(value);
  return JSON.parse(JSON.stringify(value));
};

const finite = (value, fallback = 0) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

function sideKeys(side = 'player') {
  return side === 'enemy'
    ? { current: 'enemyMana', maximum: 'enemyMaxMana', temporary: 'enemyTemporaryMana' }
    : { current: 'mana', maximum: 'maxMana', temporary: 'playerTemporaryMana' };
}

export function cardMayCostZero(card = {}) {
  if (finite(card.cost, 0) === 0 || card.allowZeroCost === true || card.freeCast === true) return true;
  return /(?:may|can)\s+cost\s+0|costs?\s+0\s+instead|play\s+(?:it|this)\s+for\s+free/i.test(String(card.text ?? ''));
}

export function calculateEffectiveCost(card = {}, reduction = 0) {
  const base = Math.max(0, finite(card.cost ?? card.manaCost, 0));
  const reduced = Math.max(0, base - Math.max(0, finite(reduction, 0)));
  return cardMayCostZero(card) ? reduced : Math.max(1, reduced);
}

function clonePublicUnit(unit) {
  return {
    ...clone(unit),
    hidden: false,
  };
}

function hiddenZone(count = 0, zone = 'hidden') {
  return Array.from({ length: Math.max(0, finite(count, 0)) }, (_, index) => ({
    id: `${zone}-${index + 1}`,
    hidden: true,
    zone,
  }));
}

/**
 * Produces the only state shape an AI planner may receive. The acting side keeps
 * its private zones; opposing hand contents and Archive order are replaced by
 * opaque count-preserving records.
 */
export function buildAiPublicSnapshot(state = {}, actor = 'enemy') {
  const aiIsEnemy = actor !== 'player';
  const ownPrefix = aiIsEnemy ? 'enemy' : 'player';
  const opponentPrefix = aiIsEnemy ? 'player' : 'enemy';
  const ownHand = aiIsEnemy ? state.enemyHand : state.hand;
  const ownDeck = aiIsEnemy ? state.enemyDeck : state.playerDeck;
  const opponentHand = aiIsEnemy ? state.hand : state.enemyHand;
  const opponentDeck = aiIsEnemy ? state.playerDeck : state.enemyDeck;

  const snapshot = {
    enemyHealth: finite(state.enemyHealth, 0),
    playerHealth: finite(state.playerHealth, 0),
    enemyMinions: (state.enemyMinions ?? []).map(clonePublicUnit),
    playerMinions: (state.playerMinions ?? []).map(clonePublicUnit),
    enemyFields: (state.enemyFields ?? []).map(clonePublicUnit),
    playerFields: (state.playerFields ?? []).map(clonePublicUnit),
    enemyRelics: (state.enemyRelics ?? []).map(clonePublicUnit),
    playerRelics: (state.playerRelics ?? []).map(clonePublicUnit),
    enemyBarricades: clone(state.enemyBarricades ?? []),
    playerBarricades: clone(state.playerBarricades ?? []),
    enemyUsedAttacks: { ...(state.enemyUsedAttacks ?? {}) },
    playerUsedAttacks: { ...(state.usedAttacks ?? state.playerUsedAttacks ?? {}) },
    familiarity: clone(state.familiarity ?? { enemy: {}, player: {} }),
    turnFlags: clone(state.turnFlags ?? { enemy: {}, player: {} }),
    boardColumns: Math.max(4, finite(state.boardColumns, 4)),
    maxMana: finite(aiIsEnemy ? (state.enemyMaxMana ?? state.maxMana) : state.maxMana, 0),
    enemyMana: finite(aiIsEnemy ? state.enemyMana : state.mana, 0),
    __aiActionStats: { ...(state.__aiActionStats ?? {}) },
    informationFirewall: {
      actor,
      ownPrivateZonesVisible: true,
      opponentHandVisible: false,
      opponentArchiveOrderVisible: false,
    },
  };

  // The current planner is enemy-oriented. Preserve those field names even
  // when the reusable firewall is asked to construct a player-side view.
  snapshot.enemyHand = (ownHand ?? []).map((card) => clone(card));
  snapshot.enemyDeck = (ownDeck ?? []).map((card) => clone(card));
  snapshot.hand = hiddenZone(opponentHand?.length ?? 0, `${opponentPrefix}-hand`);
  snapshot.playerDeck = hiddenZone(opponentDeck?.length ?? 0, `${opponentPrefix}-archive`);
  snapshot.publicZoneCounts = {
    [`${ownPrefix}Hand`]: ownHand?.length ?? 0,
    [`${ownPrefix}Archive`]: ownDeck?.length ?? 0,
    [`${opponentPrefix}Hand`]: opponentHand?.length ?? 0,
    [`${opponentPrefix}Archive`]: opponentDeck?.length ?? 0,
  };
  return snapshot;
}

export function createConvergenceRulesEngine(state, options = {}) {
  const events = options.events ?? new EventBus();
  const auditLimit = Math.max(40, finite(options.auditLimit, 240));
  state.fairnessAudit = Array.isArray(state.fairnessAudit) ? state.fairnessAudit : [];

  const audit = (kind, details = {}) => {
    const entry = { id: `${kind}-${Date.now()}-${state.fairnessAudit.length}`, at: Date.now(), kind, ...details };
    state.fairnessAudit.push(entry);
    if (state.fairnessAudit.length > auditLimit) state.fairnessAudit.splice(0, state.fairnessAudit.length - auditLimit);
    return entry;
  };

  const manaState = (side = 'player') => {
    const keys = sideKeys(side);
    return {
      current: Math.max(0, finite(state[keys.current], 0)),
      maximum: Math.max(0, finite(state[keys.maximum], 0)),
      temporary: Math.max(0, finite(state[keys.temporary], 0)),
    };
  };

  const writeMana = (side, next, reason) => {
    const keys = sideKeys(side);
    state[keys.current] = Math.max(0, finite(next.current, 0));
    state[keys.maximum] = Math.max(0, finite(next.maximum, 0));
    state[keys.temporary] = Math.max(0, finite(next.temporary, 0));
    const payload = { side, reason, ...manaState(side) };
    events.emit(CONVERGENCE_EVENTS.MANA_CHANGED, payload);
    audit('mana', payload);
    return payload;
  };

  const beginManaStep = (side = 'player', config = {}) => {
    const previous = manaState(side);
    const increase = config.increase === false ? 0 : Math.max(0, finite(config.increase, 1));
    const maximum = previous.maximum + increase;
    const tax = Math.max(0, finite(config.tax, 0));
    const payload = writeMana(side, { maximum, temporary: 0, current: Math.max(0, maximum - tax) }, 'mana-step');
    events.emit(CONVERGENCE_EVENTS.MANA_STEP, payload);
    return payload;
  };

  const gainTemporaryMana = (side = 'player', amount = 0, reason = 'temporary-gain') => {
    const current = manaState(side);
    const gain = Math.max(0, finite(amount, 0));
    return writeMana(side, {
      ...current,
      current: current.current + gain,
      temporary: current.temporary + gain,
    }, reason);
  };

  const expireTemporaryMana = (side = 'player') => {
    const current = manaState(side);
    return writeMana(side, {
      ...current,
      current: Math.max(0, current.current - current.temporary),
      temporary: 0,
    }, 'temporary-expired');
  };

  const spendMana = (side = 'player', amount = 0, reason = 'card-play') => {
    const current = manaState(side);
    const spend = Math.max(0, finite(amount, 0));
    if (spend > current.current) return { ok: false, reason: 'insufficient-mana', ...current };
    const temporarySpent = Math.min(current.temporary, spend);
    const payload = writeMana(side, {
      ...current,
      current: current.current - spend,
      temporary: current.temporary - temporarySpent,
    }, reason);
    return { ok: true, spent: spend, temporarySpent, ...payload };
  };

  const validateCardPlay = ({ side = 'player', card, reduction = 0, phase = state.phase } = {}) => {
    if (!card) return { ok: false, reason: 'missing-card' };
    const quick = !!card.quick || (card.tags ?? []).some((tag) => String(tag).toLowerCase() === 'quick');
    const legalPhase = quick || ['main1', 'main2', 'response'].includes(String(phase));
    const cost = calculateEffectiveCost(card, reduction);
    const available = manaState(side).current;
    const result = legalPhase
      ? (cost <= available ? { ok: true, cost, available } : { ok: false, reason: 'insufficient-mana', cost, available })
      : { ok: false, reason: 'illegal-phase', cost, available };
    if (!result.ok) {
      audit('rejected-card-play', { side, cardId: card.id ?? card.instanceId, ...result });
      events.emit(CONVERGENCE_EVENTS.ACTION_REJECTED, { side, card, ...result });
    }
    return result;
  };

  const priority = {
    open(activeSide = 'player') {
      state.priority = { activeSide, passed: [], open: true };
      events.emit(CONVERGENCE_EVENTS.PRIORITY_CHANGED, clone(state.priority));
      return state.priority;
    },
    pass(side) {
      state.priority = state.priority ?? { activeSide: side, passed: [], open: true };
      state.priority.passed = [...new Set([...(state.priority.passed ?? []), side])];
      state.priority.activeSide = side === 'player' ? 'enemy' : 'player';
      if (state.priority.passed.length >= 2) state.priority.open = false;
      events.emit(CONVERGENCE_EVENTS.PRIORITY_CHANGED, clone(state.priority));
      return state.priority;
    },
    respond(side) {
      state.priority = state.priority ?? { activeSide: side, passed: [], open: true };
      state.priority.activeSide = side === 'player' ? 'enemy' : 'player';
      state.priority.passed = [];
      state.priority.open = true;
      events.emit(CONVERGENCE_EVENTS.PRIORITY_CHANGED, clone(state.priority));
      return state.priority;
    },
  };

  return {
    events,
    audit,
    manaState,
    beginManaStep,
    gainTemporaryMana,
    expireTemporaryMana,
    spendMana,
    validateCardPlay,
    effectiveCost: calculateEffectiveCost,
    publicSnapshot: (actor = 'enemy') => buildAiPublicSnapshot(state, actor),
    priority,
  };
}
