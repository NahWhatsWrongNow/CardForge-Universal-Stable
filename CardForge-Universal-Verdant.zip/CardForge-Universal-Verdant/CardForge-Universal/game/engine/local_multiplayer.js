import {
  addFamiliarity,
  collectCardFamilies,
  extractCardRaces,
  getFamiliarity,
  hasFamilyTag,
  normalizeFamilyToken,
} from './race_logic.js';
import { isLocalMultiplayerPoolCard } from './card_pool_rules.js';
import {
  extractIfCondition,
  normalizeAbilityText,
  parseAbilityClauses,
  splitActions,
} from './ability_text.js';

export const LOCAL_PLAYER_COLORS = ['#4ca7ff', '#ff6363', '#ffd24c', '#5ddf84'];
export const LOCAL_PLAYER_AI_DIFFICULTIES = [
  { id: 'easy', label: 'Easy', thinkMs: 320, actionLimit: 4, risk: 0.5 },
  { id: 'normal', label: 'Normal', thinkMs: 520, actionLimit: 7, risk: 0.78 },
  { id: 'hard', label: 'Hard', thinkMs: 760, actionLimit: 10, risk: 0.92 },
];
export const LOCAL_PLAYER_FORMATS = [
  { id: '1v1', label: '1v1', seats: 2, teams: [1, 2], description: 'Classic local duel.' },
  { id: '2v2', label: '2v2', seats: 4, teams: [1, 2, 1, 2], description: 'Two teams, shared victory.' },
  { id: '1v1v1v1', label: '1v1v1v1', seats: 4, teams: [1, 2, 3, 4], description: 'Four-player free-for-all.' },
  { id: 'custom', label: 'Custom', seats: 4, teams: [1, 2, 3, 4], description: 'Editable teams and seat order.' },
];
export const LOCAL_PLAYER_ELEMENTS = ['fire', 'water', 'earth', 'air', 'light', 'shadow', 'nature', 'storm', 'frost', 'metal', 'arcane', 'toxic'];
export const LOCAL_PLAYER_WARBANDS = [
  { id: 'dragons', label: 'Dragon Flights', family: 'dragon', hints: ['flying', 'ancient', 'dragonkin'] },
  { id: 'spirits', label: 'Spirit Choir', family: 'spirit', hints: ['wraith', 'healing', 'draw'] },
  { id: 'beasts', label: 'Beast Pack', family: 'beast', hints: ['giant', 'rush', 'lifesteal'] },
  { id: 'constructs', label: 'Construct Engine', family: 'construct', hints: ['machine', 'relic', 'field'] },
  { id: 'undead', label: 'Undead Legion', family: 'undead', hints: ['skeleton', 'wraith', 'graveyard'] },
  { id: 'mages', label: 'Arcane Circle', family: 'mage', hints: ['spell', 'draw', 'arcane'] },
];
export const LOCAL_PLAYER_STORMS = [
  { id: 'vault', label: 'Vault Engines', description: 'Relics, fields, and scaling permanents.' },
  { id: 'ward', label: 'Wardline', description: 'Protective engines, healing, and control.' },
  { id: 'stormforge', label: 'Stormforge', description: 'Spell-relic chains with big finishers.' },
];
export const LOCAL_PLAYER_MODES = [
  { id: 'chaos', label: 'Chaos', description: 'Pick one of three schematics, then get a balanced random deck.' },
  { id: 'elemental', label: 'Elemental Battles', description: 'Choose two elements and build around them.' },
  { id: 'warbands', label: 'Warbands', description: 'Choose a tribal identity and get a synergy deck.' },
  { id: 'relic-storm', label: 'Relic Storm', description: 'Permanent-heavy engine decks with control shells.' },
];

const LOCAL_PLAYER_DECK_SIZE = 30;
const LOCAL_PLAYER_START_HAND = 5;
const LOCAL_PLAYER_ROW_WIDTH = 4;
export const LOCAL_PLAYER_DEFAULT_BOARD_RULES = {
  rowWidth: LOCAL_PLAYER_ROW_WIDTH,
  startingRows: 1,
  growthEnabled: true,
  growthTrigger: 'fill-visible-rows',
  maxRows: 24,
};
const CHAOS_SCHEMATICS = [
  { id: 'tempo-spells', label: 'Spell Tempo', description: 'High spells, medium minions, low relics.', minions: 14, spells: 12, permanents: 4, curve: [8, 10, 7, 5], tags: ['arcane', 'tempo'] },
  { id: 'beast-rush', label: 'Beast Rush', description: 'Beast-heavy, low curve, high tempo.', minions: 19, spells: 7, permanents: 4, curve: [11, 9, 6, 4], families: ['beast'], tags: ['rush', 'lifesteal'] },
  { id: 'control-shell', label: 'Control Shell', description: 'Removal, healing, and slower finishers.', minions: 13, spells: 11, permanents: 6, curve: [6, 10, 8, 6], tags: ['heal', 'control'] },
  { id: 'swarm-front', label: 'Swarm Front', description: 'Cheap units, token pressure, low top-end.', minions: 20, spells: 8, permanents: 2, curve: [12, 10, 5, 3], tags: ['token', 'swarm'] },
  { id: 'relic-weave', label: 'Relic Weave', description: 'Relic support, spell combo, thin frontline.', minions: 12, spells: 10, permanents: 8, curve: [7, 9, 8, 6], tags: ['relic', 'field', 'draw'] },
  { id: 'dragon-midrange', label: 'Dragon Midrange', description: 'Dragonkin start, flying pressure, elder finishers.', minions: 18, spells: 7, permanents: 5, curve: [7, 9, 8, 6], families: ['dragon', 'dragonkin'], tags: ['flying', 'dragon'] },
  { id: 'grave-pressure', label: 'Grave Pressure', description: 'Undead value, recursion, steady attrition.', minions: 17, spells: 8, permanents: 5, curve: [8, 9, 7, 6], families: ['undead', 'spirit'], tags: ['graveyard', 'death'] },
  { id: 'construct-ramp', label: 'Construct Ramp', description: 'Construct shell, support relics, heavy top end.', minions: 16, spells: 6, permanents: 8, curve: [6, 8, 8, 8], families: ['construct', 'machine'], tags: ['relic', 'field', 'armor'] },
];

function uid(prefix = 'local') {
  return `${prefix}-${Math.random().toString(16).slice(2, 10)}`;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function num(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function slug(value = '') {
  return String(value ?? '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function pickRandom(list = [], rng = Math.random) {
  if (!list.length) return null;
  return list[Math.floor(rng() * list.length)] ?? null;
}

function sampleMany(list = [], count = 1, rng = Math.random) {
  const pool = [...list];
  const picked = [];
  while (pool.length && picked.length < count) {
    const index = Math.floor(rng() * pool.length);
    picked.push(pool.splice(index, 1)[0]);
  }
  return picked;
}

function shuffle(list = [], rng = Math.random) {
  const copy = [...list];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function seededRng(seed = 'local-player') {
  let value = 0;
  for (let i = 0; i < String(seed).length; i += 1) {
    value = ((value << 5) - value) + String(seed).charCodeAt(i);
    value |= 0;
  }
  return () => {
    value = (value + 0x6D2B79F5) | 0;
    let t = Math.imul(value ^ (value >>> 15), 1 | value);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function normalizeCardType(card = {}) {
  const type = String(card?.type ?? 'minion').toLowerCase();
  if (['minion', 'creature', 'token'].includes(type)) return 'minion';
  if (['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(type)) return 'spell';
  if (type === 'field') return 'field';
  if (['relic', 'artifact'].includes(type)) return 'relic';
  return type;
}

function cloneCard(card = {}) {
  const text = normalizeAbilityText(card?.text ?? '');
  const keywords = Array.isArray(card?.keywords) ? card.keywords.map((entry) => String(entry)) : [];
  const tags = Array.isArray(card?.tags) ? card.tags.map((entry) => String(entry)) : [];
  const families = [...new Set([...collectCardFamilies(card), ...extractCardRaces(card)].map((entry) => normalizeFamilyToken(entry)).filter(Boolean))];
  return {
    ...card,
    instanceId: card.instanceId ?? uid('card'),
    type: normalizeCardType(card),
    name: String(card?.name ?? 'Unknown Card'),
    cost: Math.max(0, num(card?.cost ?? card?.mana ?? 0)),
    attack: Math.max(0, num(card?.attack ?? 0)),
    health: Math.max(1, num(card?.health ?? 1)),
    maxHealth: Math.max(1, num(card?.maxHealth ?? card?.health ?? 1)),
    rarity: String(card?.rarity ?? 'common').toLowerCase(),
    element: String(card?.element ?? '').toLowerCase(),
    text,
    keywords,
    tags,
    families,
    clauses: parseAbilityClauses(text),
  };
}

function structuredAbilityEntries(card = {}) {
  const list = [];
  if (Array.isArray(card?.abilities)) {
    card.abilities.forEach((entry) => {
      if (entry && typeof entry === 'object') list.push(entry);
    });
  }
  if (card?.ability && typeof card.ability === 'object' && !Array.isArray(card.ability) && Object.keys(card.ability).length > 0) list.unshift(card.ability);
  if (card?.effect && typeof card.effect === 'object' && !Array.isArray(card.effect) && Object.keys(card.effect).length > 0) list.unshift(card.effect);
  return list;
}

export function prepareLocalCardPool(allCards = []) {
  const seen = new Map();
  (Array.isArray(allCards) ? allCards : []).forEach((entry) => {
    if (!entry?.id) return;
    if (!isLocalMultiplayerPoolCard(entry)) return;
    if (String(entry?.id ?? '').includes('token') || entry?.collectible === false) return;
    const next = cloneCard(entry);
    if (['minion', 'spell', 'relic', 'field'].includes(next.type)) seen.set(next.id, next);
  });
  return [...seen.values()];
}

function localCardScore(card = {}) {
  const type = normalizeCardType(card);
  const stats = (num(card.attack, 0) * 1.2) + (num(card.health, 0) * 1.1);
  const spellBias = type === 'spell' ? 2.8 : 0;
  const relicBias = (type === 'relic' || type === 'field') ? 2.2 : 0;
  const rarityBias = ({ common: 0, rare: 0.8, epic: 1.6, legendary: 2.5 }[String(card.rarity ?? 'common').toLowerCase()] ?? 0);
  const keywordBias = ['taunt', 'flying', 'charge', 'rush', 'lifesteal', 'stealth', 'divine shield']
    .reduce((sum, key) => sum + (new RegExp(`\\b${key}\\b`, 'i').test(card.text) ? 0.6 : 0), 0);
  return stats + spellBias + relicBias + rarityBias + keywordBias + (num(card.cost, 0) * 0.4);
}

function curveBucket(cost = 0) {
  const value = Math.max(0, num(cost, 0));
  if (value <= 2) return 0;
  if (value <= 4) return 1;
  if (value <= 6) return 2;
  return 3;
}

function cardMatchesAnyElement(card = {}, elements = []) {
  const wanted = elements.map((entry) => slug(entry)).filter(Boolean);
  if (!wanted.length) return true;
  const cardElements = new Set([slug(card.element), ...((Array.isArray(card.tags) ? card.tags : []).map((entry) => slug(entry)))]);
  return wanted.some((entry) => cardElements.has(entry)) || !slug(card.element);
}

function cardMatchesFamilies(card = {}, families = []) {
  const wanted = families.map((entry) => normalizeFamilyToken(entry)).filter(Boolean);
  if (!wanted.length) return true;
  return wanted.some((entry) => hasFamilyTag(card, entry));
}

function countByType(deck = [], type = 'minion') {
  return deck.filter((card) => normalizeCardType(card) === type).length;
}

function countByCurve(deck = [], bucket = 0) {
  return deck.filter((card) => curveBucket(card.cost) === bucket).length;
}

function maxCopiesForCard(card = {}) {
  return String(card?.rarity ?? 'common').toLowerCase() === 'legendary' ? 1 : 2;
}

function deckValidationSummary(deck = []) {
  return {
    size: deck.length,
    minions: countByType(deck, 'minion'),
    spells: countByType(deck, 'spell'),
    permanents: countByType(deck, 'relic') + countByType(deck, 'field'),
    curve: [0, 1, 2, 3].map((bucket) => countByCurve(deck, bucket)),
  };
}

function fillDeckWithPlan(pool = [], {
  seed = 'deck',
  minions = 16,
  spells = 8,
  permanents = 6,
  curve = [8, 10, 7, 5],
  elements = [],
  families = [],
  tags = [],
} = {}) {
  const rng = seededRng(seed);
  const deck = [];
  const copyCounts = new Map();
  const typeTargets = { minion: minions, spell: spells, relic: Math.floor(permanents / 2), field: Math.ceil(permanents / 2) };
  const tagWanted = tags.map((entry) => slug(entry)).filter(Boolean);
  const filtered = pool.filter((card) => {
    if (!cardMatchesAnyElement(card, elements)) return false;
    if (!cardMatchesFamilies(card, families)) {
      if (families.length && !tagWanted.some((tag) => (card.tags ?? []).map((entry) => slug(entry)).includes(tag))) return false;
    }
    return true;
  });
  const fallbackPool = filtered.length ? filtered : pool;
  const sortedPool = [...fallbackPool].sort((a, b) => localCardScore(b) - localCardScore(a));

  function canTake(card) {
    const copies = copyCounts.get(card.id) ?? 0;
    return copies < maxCopiesForCard(card);
  }

  function addCard(card) {
    if (!card || !canTake(card)) return false;
    deck.push({ ...card, instanceId: uid('deck') });
    copyCounts.set(card.id, (copyCounts.get(card.id) ?? 0) + 1);
    return true;
  }

  function pickForType(type) {
    const candidates = sortedPool.filter((card) => normalizeCardType(card) === type && canTake(card));
    return pickRandom(candidates.slice(0, Math.max(8, candidates.length)), rng) ?? pickRandom(candidates, rng);
  }

  function pickForCurve(bucket) {
    const candidates = sortedPool.filter((card) => curveBucket(card.cost) === bucket && canTake(card));
    return pickRandom(candidates.slice(0, Math.max(10, candidates.length)), rng) ?? pickRandom(candidates, rng);
  }

  Object.entries(typeTargets).forEach(([type, target]) => {
    while (countByType(deck, type) < target) {
      const card = pickForType(type);
      if (!card) break;
      addCard(card);
      if (deck.length >= LOCAL_PLAYER_DECK_SIZE) break;
    }
  });

  curve.forEach((target, bucket) => {
    while (countByCurve(deck, bucket) < target && deck.length < LOCAL_PLAYER_DECK_SIZE) {
      const card = pickForCurve(bucket);
      if (!card) break;
      addCard(card);
    }
  });

  while (deck.length < LOCAL_PLAYER_DECK_SIZE) {
    const card = pickRandom(sortedPool.filter((entry) => canTake(entry)), rng);
    if (!card) break;
    addCard(card);
  }

  return shuffle(deck.slice(0, LOCAL_PLAYER_DECK_SIZE), rng);
}

function defaultSeat(index = 0, aiProfiles = []) {
  const color = LOCAL_PLAYER_COLORS[index] ?? '#9aa7ff';
  return {
    seatIndex: index,
    id: `seat-${index + 1}`,
    enabled: index < 2,
    controller: 'human',
    name: `Player ${index + 1}`,
    aiDifficulty: 'normal',
    team: index < 2 ? index + 1 : index + 1,
    color,
    seatOrder: index,
    chaosOptions: [],
    selectedChaosId: '',
    elements: index === 0 ? ['fire', 'arcane'] : index === 1 ? ['water', 'frost'] : ['nature', 'earth'],
    warband: LOCAL_PLAYER_WARBANDS[index % LOCAL_PLAYER_WARBANDS.length]?.id ?? LOCAL_PLAYER_WARBANDS[0].id,
    stormFocus: LOCAL_PLAYER_STORMS[index % LOCAL_PLAYER_STORMS.length]?.id ?? LOCAL_PLAYER_STORMS[0].id,
  };
}

export function defaultLocalPlayerSetup(aiProfiles = []) {
  return {
    version: 1,
    formatId: '1v1',
    modeId: 'chaos',
    allowCustomTeams: false,
    randomSeed: `${Date.now()}`,
    seatOrder: [0, 1, 2, 3],
    slots: Array.from({ length: 4 }, (_, index) => defaultSeat(index, aiProfiles)),
    presetName: '',
    boardRules: { ...LOCAL_PLAYER_DEFAULT_BOARD_RULES },
  };
}

export function normalizeLocalPlayerSetup(raw = {}, aiProfiles = []) {
  const base = defaultLocalPlayerSetup(aiProfiles);
  const validDifficulty = new Set(LOCAL_PLAYER_AI_DIFFICULTIES.map((entry) => entry.id));
  const setup = {
    ...base,
    ...raw,
    seatOrder: Array.isArray(raw?.seatOrder) ? raw.seatOrder.map((entry) => clamp(num(entry, 0), 0, 3)) : base.seatOrder,
    boardRules: {
      ...LOCAL_PLAYER_DEFAULT_BOARD_RULES,
      ...(raw?.boardRules && typeof raw.boardRules === 'object' ? raw.boardRules : {}),
    },
    slots: base.slots.map((slot, index) => ({
      ...slot,
      ...(raw?.slots?.[index] ?? {}),
      seatIndex: index,
      id: `seat-${index + 1}`,
      color: String(raw?.slots?.[index]?.color ?? slot.color),
      aiDifficulty: validDifficulty.has(String(raw?.slots?.[index]?.aiDifficulty ?? slot.aiDifficulty))
        ? String(raw?.slots?.[index]?.aiDifficulty ?? slot.aiDifficulty)
        : 'normal',
      elements: Array.isArray(raw?.slots?.[index]?.elements) ? raw.slots[index].elements.slice(0, 2).map(slug).filter(Boolean) : slot.elements,
    })),
  };
  const format = LOCAL_PLAYER_FORMATS.find((entry) => entry.id === setup.formatId) ?? LOCAL_PLAYER_FORMATS[0];
  setup.slots = setup.slots.map((slot, index) => ({
    ...slot,
    enabled: format.id === 'custom' ? !!slot.enabled : index < format.seats,
    team: format.id === 'custom' ? Math.max(1, num(slot.team, index + 1)) : (format.teams[index] ?? (index + 1)),
  }));
  setup.boardRules = {
    ...LOCAL_PLAYER_DEFAULT_BOARD_RULES,
    rowWidth: clamp(num(setup.boardRules?.rowWidth, LOCAL_PLAYER_DEFAULT_BOARD_RULES.rowWidth), 2, 6),
    startingRows: clamp(num(setup.boardRules?.startingRows, LOCAL_PLAYER_DEFAULT_BOARD_RULES.startingRows), 1, 3),
    growthEnabled: setup.boardRules?.growthEnabled !== false,
    growthTrigger: String(setup.boardRules?.growthTrigger ?? LOCAL_PLAYER_DEFAULT_BOARD_RULES.growthTrigger),
    maxRows: clamp(num(setup.boardRules?.maxRows, LOCAL_PLAYER_DEFAULT_BOARD_RULES.maxRows), 4, 48),
  };
  return setup;
}

export function localBoardRules(matchOrSetup = {}) {
  const raw = matchOrSetup?.boardRules ?? matchOrSetup?.config?.boardRules ?? matchOrSetup?.setup?.boardRules ?? matchOrSetup;
  return {
    ...LOCAL_PLAYER_DEFAULT_BOARD_RULES,
    rowWidth: clamp(num(raw?.rowWidth, LOCAL_PLAYER_DEFAULT_BOARD_RULES.rowWidth), 2, 6),
    startingRows: clamp(num(raw?.startingRows, LOCAL_PLAYER_DEFAULT_BOARD_RULES.startingRows), 1, 3),
    growthEnabled: raw?.growthEnabled !== false,
    growthTrigger: String(raw?.growthTrigger ?? LOCAL_PLAYER_DEFAULT_BOARD_RULES.growthTrigger),
    maxRows: clamp(num(raw?.maxRows, LOCAL_PLAYER_DEFAULT_BOARD_RULES.maxRows), 4, 48),
  };
}

function boardLinearSlot(row = 0, column = 0, rowWidth = LOCAL_PLAYER_ROW_WIDTH) {
  return (Math.max(0, row) * Math.max(1, rowWidth)) + Math.max(0, column);
}

function boardCoordinatesFromLinearSlot(slot = 0, rowWidth = LOCAL_PLAYER_ROW_WIDTH) {
  const safeWidth = Math.max(1, rowWidth);
  const index = Math.max(0, num(slot, 0));
  return {
    row: Math.floor(index / safeWidth),
    column: index % safeWidth,
  };
}

function ensureParticipantBoardState(match = {}, participant = {}) {
  if (!participant) return participant;
  const rules = localBoardRules(match);
  participant.boardState = participant.boardState && typeof participant.boardState === 'object' ? participant.boardState : {};
  participant.boardRowsUnlocked = clamp(num(participant.boardRowsUnlocked, rules.startingRows), rules.startingRows, rules.maxRows);
  participant.boardState.collapsedRows = !!participant.boardState.collapsedRows;
  participant.boardState.newestRow = clamp(num(participant.boardState.newestRow, participant.boardRowsUnlocked - 1), 0, rules.maxRows - 1);
  participant.boardState.autoFocusOnGrowth = participant.boardState.autoFocusOnGrowth !== false;
  const living = (participant.board ?? []).filter((entry) => num(entry.health, 0) > 0);
  let highestRow = rules.startingRows - 1;
  living.forEach((card, index) => {
    const coords = Number.isInteger(card?.row) && Number.isInteger(card?.column)
      ? { row: num(card.row, 0), column: num(card.column, 0) }
      : boardCoordinatesFromLinearSlot(num(card?.slot, index), rules.rowWidth);
    card.row = clamp(num(coords.row, 0), 0, rules.maxRows - 1);
    card.column = clamp(num(coords.column, 0), 0, rules.rowWidth - 1);
    card.slot = boardLinearSlot(card.row, card.column, rules.rowWidth);
    card.expansionDepth = card.row;
    highestRow = Math.max(highestRow, card.row);
  });
  participant.boardRowsUnlocked = clamp(Math.max(participant.boardRowsUnlocked, highestRow + 1), rules.startingRows, rules.maxRows);
  participant.board.sort((a, b) => num(a.slot, 0) - num(b.slot, 0));
  return participant;
}

function ensureAllParticipantBoardState(match = {}) {
  (match?.participants ?? []).forEach((participant) => ensureParticipantBoardState(match, participant));
}

function boardOccupantAt(match = {}, participant = {}, row = 0, column = 0) {
  ensureParticipantBoardState(match, participant);
  return aliveBoard(participant).find((entry) => num(entry.row, -1) === row && num(entry.column, -1) === column) ?? null;
}

function boardSlotsForRow(match = {}, participant = {}, row = 0) {
  const rules = localBoardRules(match);
  return Array.from({ length: rules.rowWidth }, (_, column) => ({
    row,
    column,
    card: boardOccupantAt(match, participant, row, column),
  }));
}

function boardRowsForParticipant(match = {}, participant = {}, { includeLocked = false } = {}) {
  ensureParticipantBoardState(match, participant);
  const rules = localBoardRules(match);
  const visibleCount = includeLocked ? rules.maxRows : participant.boardRowsUnlocked;
  return Array.from({ length: visibleCount }, (_, row) => ({
    row,
    slots: boardSlotsForRow(match, participant, row),
  }));
}

function firstOpenBoardCell(match = {}, participant = {}, preferredRows = null, options = {}) {
  ensureParticipantBoardState(match, participant);
  const rules = localBoardRules(match);
  const allowUnlock = options.allowUnlock !== false;
  const rowOrder = Array.isArray(preferredRows) && preferredRows.length
    ? [...new Set(preferredRows.map((entry) => clamp(num(entry, 0), 0, participant.boardRowsUnlocked - 1)))]
    : Array.from({ length: participant.boardRowsUnlocked }, (_, index) => index);
  for (const row of rowOrder) {
    const open = boardSlotsForRow(match, participant, row).find((entry) => !entry.card);
    if (open) return { row: open.row, column: open.column, unlocked: false };
  }
  if (allowUnlock && rules.growthEnabled && participant.boardRowsUnlocked < rules.maxRows) {
    const row = participant.boardRowsUnlocked;
    participant.boardRowsUnlocked += 1;
    participant.boardState.newestRow = row;
    match.lastRowUnlock = { seatId: participant.id, row, turn: match.turnNumber, at: Date.now() };
    pushLocalLog(match, `${participant.name} opens Reserve Row ${row + 1}.`);
    return { row, column: 0, unlocked: true };
  }
  return null;
}

function boardRowsUnlocked(match = {}, participant = {}) {
  ensureParticipantBoardState(match, participant);
  return participant.boardRowsUnlocked;
}

function boardFrontlineRow(match = {}, participant = {}) {
  ensureParticipantBoardState(match, participant);
  const rows = aliveBoard(participant).map((entry) => num(entry.row, 0)).sort((a, b) => a - b);
  return rows.length ? rows[0] : 0;
}

function boardDeepestRow(match = {}, participant = {}) {
  ensureParticipantBoardState(match, participant);
  const rows = aliveBoard(participant).map((entry) => num(entry.row, 0)).sort((a, b) => b - a);
  return rows.length ? rows[0] : Math.max(0, boardRowsUnlocked(match, participant) - 1);
}

function boardColumnFrontOccupant(match = {}, participant = {}, column = 0) {
  ensureParticipantBoardState(match, participant);
  const cards = aliveBoard(participant)
    .filter((entry) => num(entry.column, -1) === column)
    .sort((a, b) => num(a.row, 0) - num(b.row, 0));
  return cards[0] ?? null;
}

function boardExposedFrontline(match = {}, participant = {}) {
  const rules = localBoardRules(match);
  return Array.from({ length: rules.rowWidth }, (_, column) => boardColumnFrontOccupant(match, participant, column)).filter(Boolean);
}

function localCardRoleProfile(card = {}) {
  const text = normalizeAbilityText(card?.text ?? '').toLowerCase();
  const tags = new Set([...(Array.isArray(card?.keywords) ? card.keywords : []), ...(Array.isArray(card?.tags) ? card.tags : [])].map((entry) => String(entry).toLowerCase()));
  const support = /\bdraw\b|\brestore\b|\bheal\b|\baura\b|\bgive\b|\bother friendly\b|\bsummon\b|\bfield\b|\brelic\b/.test(text);
  const ranged = tags.has('ranged') || tags.has('artillery') || tags.has('siege') || tags.has('reach')
    || /\b(ranged|artillery|siege|reach|marksman|sniper|bolt|beam|cannon)\b/.test(text);
  const flying = tags.has('flying') || /\bflying\b/.test(text);
  const guard = tags.has('taunt') || tags.has('guard') || /\b(taunt|guard)\b/.test(text);
  const engine = /\bwhenever\b|\bafter\b|\bend of your turn\b|\bstart of your turn\b/.test(text);
  const tanky = num(card.health, 0) >= 6 || card.defense != null || /\barmor\b|\bshield\b/.test(text);
  return {
    support,
    ranged,
    flying,
    guard,
    engine,
    frontliner: guard || tanky || (!support && !ranged && !flying),
    backliner: support || ranged || flying || engine,
  };
}

function preferredOpenRowsForCard(match = {}, participant = {}, card = {}) {
  ensureParticipantBoardState(match, participant);
  const unlocked = boardRowsUnlocked(match, participant);
  const profile = localCardRoleProfile(card);
  const rows = Array.from({ length: unlocked }, (_, index) => index);
  if (profile.backliner && unlocked > 1) return [...rows].reverse();
  if (profile.frontliner) return rows;
  return rows;
}

function canAttackFromDepth(match = {}, owner = {}, attacker = {}) {
  ensureParticipantBoardState(match, owner);
  const profile = localCardRoleProfile(attacker);
  const row = num(attacker.row, 0);
  const column = num(attacker.column, 0);
  const blocking = aliveBoard(owner).some((entry) => entry.instanceId !== attacker.instanceId && num(entry.column, -1) === column && num(entry.row, 99) < row);
  if (!blocking) return true;
  return profile.ranged || profile.flying;
}

function canReachProtectedBackline(attacker = {}) {
  const profile = localCardRoleProfile(attacker);
  return profile.ranged || profile.flying;
}

export function randomizeSeatOrder(setup = {}) {
  const next = normalizeLocalPlayerSetup(setup);
  next.seatOrder = shuffle(next.seatOrder);
  return next;
}

function resolveChaosOptions(slot = {}, seed = '') {
  const rng = seededRng(`${seed}:${slot.id}:chaos`);
  return sampleMany(CHAOS_SCHEMATICS, 3, rng).map((entry) => ({ ...entry }));
}

export function hydrateModeChoices(setup = {}, pool = []) {
  const next = normalizeLocalPlayerSetup(setup);
  next.slots = next.slots.map((slot) => {
    if (!slot.enabled) return slot;
    if (next.modeId === 'chaos') {
      const options = resolveChaosOptions(slot, next.randomSeed);
      const selected = options.some((entry) => entry.id === slot.selectedChaosId) ? slot.selectedChaosId : (options[0]?.id ?? '');
      return { ...slot, chaosOptions: options, selectedChaosId: selected };
    }
    return { ...slot };
  });
  return next;
}

function buildDeckForSlot(slot = {}, setup = {}, pool = []) {
  const seedBase = `${setup.randomSeed}:${setup.modeId}:${slot.id}`;
  if (setup.modeId === 'elemental') {
    return fillDeckWithPlan(pool, {
      seed: `${seedBase}:elemental`,
      elements: slot.elements.slice(0, 2),
      minions: 16,
      spells: 9,
      permanents: 5,
      curve: [8, 10, 7, 5],
      tags: slot.elements,
    });
  }
  if (setup.modeId === 'warbands') {
    const warband = LOCAL_PLAYER_WARBANDS.find((entry) => entry.id === slot.warband) ?? LOCAL_PLAYER_WARBANDS[0];
    return fillDeckWithPlan(pool, {
      seed: `${seedBase}:warband`,
      families: [warband.family, ...(warband.hints ?? [])],
      minions: 18,
      spells: 7,
      permanents: 5,
      curve: [9, 10, 7, 4],
      tags: warband.hints,
    });
  }
  if (setup.modeId === 'relic-storm') {
    const storm = LOCAL_PLAYER_STORMS.find((entry) => entry.id === slot.stormFocus) ?? LOCAL_PLAYER_STORMS[0];
    return fillDeckWithPlan(pool, {
      seed: `${seedBase}:storm`,
      minions: 12,
      spells: 8,
      permanents: 10,
      curve: [7, 9, 8, 6],
      tags: [storm.id, 'relic', 'field', 'support'],
    });
  }
  const schematic = slot.chaosOptions?.find((entry) => entry.id === slot.selectedChaosId) ?? CHAOS_SCHEMATICS[0];
  return fillDeckWithPlan(pool, {
    seed: `${seedBase}:chaos:${schematic.id}`,
    minions: schematic.minions,
    spells: schematic.spells,
    permanents: schematic.permanents,
    curve: schematic.curve,
    families: schematic.families ?? [],
    tags: schematic.tags ?? [],
  });
}

function createParticipantFromSlot(slot = {}, setup = {}, pool = []) {
  const deck = buildDeckForSlot(slot, setup, pool);
  const hand = deck.splice(0, LOCAL_PLAYER_START_HAND);
  const boardRules = localBoardRules(setup);
  return {
    id: slot.id,
    name: slot.name || `Player ${slot.seatIndex + 1}`,
    seatIndex: slot.seatIndex,
    team: slot.team,
    controller: slot.controller,
    aiDifficulty: slot.aiDifficulty,
    color: slot.color,
    heroHealth: 30,
    heroMaxHealth: 30,
    mana: 1,
    maxMana: 1,
    fatigue: 0,
    board: [],
    relics: [],
    fields: [],
    graveyard: [],
    deck,
    hand,
    familiarity: {},
    turnFlags: {},
    boardRowsUnlocked: boardRules.startingRows,
    boardState: {
      collapsedRows: false,
      newestRow: Math.max(0, boardRules.startingRows - 1),
      autoFocusOnGrowth: true,
    },
    eliminated: false,
    victories: 0,
    scheme: slot.selectedChaosId || null,
    elements: slot.elements,
    warband: slot.warband,
    stormFocus: slot.stormFocus,
  };
}

export function createLocalMatch(setup = {}, allCards = [], aiProfiles = []) {
  const pool = prepareLocalCardPool(allCards);
  const normalized = hydrateModeChoices(normalizeLocalPlayerSetup(setup, aiProfiles), pool);
  const participants = normalized.seatOrder
    .map((seatIndex) => normalized.slots[seatIndex])
    .filter((slot) => slot?.enabled)
    .map((slot) => createParticipantFromSlot(slot, normalized, pool));
  const match = {
    version: 1,
    mode: 'local-player',
    cardPool: pool,
    allCards: Array.isArray(allCards) ? allCards.map((card) => cloneCard(card)) : [],
    formatId: normalized.formatId,
    modeId: normalized.modeId,
    config: normalized,
    boardRules: localBoardRules(normalized),
    participants,
    turnNumber: 1,
    activeSeatIndex: 0,
    boardScale: 1,
    boardOffset: { x: 0, y: 0 },
    attackPreview: null,
    lastSummary: '',
    handoff: {
      required: participants[0]?.controller === 'human',
      seatId: participants[0]?.id ?? null,
      turnNumber: 1,
    },
    winnerTeam: null,
    winnerSeatIds: [],
    matchOver: false,
    log: [],
    lastRowUnlock: null,
    deckSummaries: participants.map((participant) => ({
      seatId: participant.id,
      summary: deckValidationSummary([...participant.hand, ...participant.deck]),
    })),
  };
  ensureAllParticipantBoardState(match);
  pushLocalLog(match, `${participants[0]?.name ?? 'Player'} takes the first turn.`);
  return match;
}

function participantById(match, seatId) {
  return match?.participants?.find((entry) => entry.id === seatId) ?? null;
}

export function currentLocalParticipant(match = {}) {
  return match?.participants?.[match.activeSeatIndex] ?? null;
}

export function liveLocalParticipants(match = {}) {
  return (match?.participants ?? []).filter((entry) => !entry.eliminated);
}

export function alliesFor(match = {}, seatId = '') {
  const source = participantById(match, seatId);
  if (!source) return [];
  return (match.participants ?? []).filter((entry) => entry.id !== seatId && !entry.eliminated && entry.team === source.team);
}

export function enemiesFor(match = {}, seatId = '') {
  const source = participantById(match, seatId);
  if (!source) return [];
  return (match.participants ?? []).filter((entry) => !entry.eliminated && entry.team !== source.team);
}

export function rotatedPerspective(match = {}, perspectiveSeatId = '') {
  const participants = match?.participants ?? [];
  const idx = participants.findIndex((entry) => entry.id === perspectiveSeatId);
  if (idx < 0) return participants;
  return [...participants.slice(idx), ...participants.slice(0, idx)];
}

function pushLocalLog(match, text = '') {
  if (!text) return;
  match.log = [...(match.log ?? []), { id: uid('log'), ts: Date.now(), text }].slice(-24);
  match.lastSummary = text;
}

function topCardDraw(participant = {}) {
  let next = participant.deck.shift() ?? null;
  if (!next) {
    participant.fatigue = Math.max(0, num(participant.fatigue, 0)) + 1;
    participant.heroHealth -= participant.fatigue;
    return null;
  }
  participant.hand.push(next);
  return next;
}

function aliveBoard(participant = {}) {
  return (participant.board ?? []).filter((entry) => num(entry.health, 0) > 0);
}

function runtimeEntityForKey(runtime = {}, key = '') {
  const map = {
    playedCard: runtime.playedCard ?? runtime.sourceCard ?? null,
    summoned: runtime.summoned ?? null,
    attacker: runtime.attacker ?? null,
    target: runtime.target ?? runtime.deadCard ?? null,
    deadCard: runtime.deadCard ?? null,
    returned: runtime.returned ?? null,
    self: runtime.self ?? runtime.sourceCard ?? null,
  };
  if (key && map[key] != null) return map[key];
  return map.playedCard ?? map.summoned ?? map.attacker ?? map.deadCard ?? map.returned ?? map.target ?? map.self ?? null;
}

function localStructuredUseBucket(owner = {}) {
  owner.turnFlags = owner.turnFlags && typeof owner.turnFlags === 'object' ? owner.turnFlags : {};
  owner.turnFlags.structuredUses = owner.turnFlags.structuredUses && typeof owner.turnFlags.structuredUses === 'object' ? owner.turnFlags.structuredUses : {};
  return owner.turnFlags.structuredUses;
}

function localStructuredAbilityKey(ability = {}) {
  return String(ability?.id || ability?.name || ability?.effect?.action || ability?.text || ability?.trigger || 'structured-ability').trim().toLowerCase();
}

function addLocalNamedCardToHand(match = {}, owner = {}, cardName = '', fallback = {}) {
  const wanted = String(cardName ?? '').trim().toLowerCase();
  const found = (match.allCards ?? match.cardPool ?? []).find((card) => String(card?.name ?? '').trim().toLowerCase() === wanted);
  owner.hand.push(cloneCard(found ?? { name: cardName, type: fallback.type ?? 'spell', cost: fallback.cost ?? 1, text: fallback.text ?? '', race: fallback.race ?? '', races: fallback.races ?? [] }));
}

function spellMatchesLocalCategory(card = {}, category = '') {
  const source = normalizeAbilityText(card?.text ?? '').toLowerCase();
  const wanted = String(category ?? '').trim().toLowerCase();
  if (!wanted) return true;
  if (wanted === 'damage') return /deal\s+\d+\s+damage|destroy\s+a\s+damaged|minion/i.test(source);
  if (wanted === 'heal' || wanted === 'healing') return /restore\s+\d+\s+health|heal\s+\d+|full health/.test(source);
  return source.includes(wanted);
}

function countFamilyInZone(cards = [], family = '') {
  return cards.filter((entry) => hasFamilyTag(entry, family)).length;
}

function localPassiveAuraEntries(card = {}) {
  return structuredAbilityEntries(card).filter((entry) => {
    const trigger = String(entry?.trigger ?? entry?.timing ?? '').trim().toLowerCase();
    return trigger === 'aura' || trigger === 'passive';
  });
}

function localPassiveAuraEffect(entry = {}) {
  return entry?.effect && typeof entry.effect === 'object' ? entry.effect : entry;
}

function localPassiveAuraFamilies(entry = {}) {
  const effect = localPassiveAuraEffect(entry);
  return [...new Set([
    entry.family,
    effect.family,
    ...(Array.isArray(entry.families) ? entry.families : []),
    ...(Array.isArray(effect.families) ? effect.families : []),
  ].map((value) => normalizeFamilyToken(value)).filter(Boolean))];
}

function localPassiveAuraSources(owner = {}) {
  return [...aliveBoard(owner), ...(owner.relics ?? []), ...(owner.fields ?? [])];
}

function localUnitAtFullHealth(card = {}) {
  return num(card.health, 0) >= num(card.maxHealth ?? card.health, 0);
}

function localPassiveAuraMatchesUnit(match = {}, owner = {}, entry = {}, card = {}, source = null) {
  if (!card || num(card.health, 0) <= 0) return false;
  const effect = localPassiveAuraEffect(entry);
  const families = localPassiveAuraFamilies(entry);
  if (effect.excludeSelf && source?.instanceId && source.instanceId === card.instanceId) return false;
  if (families.length && !families.some((family) => hasFamilyTag(card, family))) return false;
  if (effect.stealthedOnly && !card.statuses?.stealth) return false;
  if (effect.fullHealthOnly && !localUnitAtFullHealth(card)) return false;
  if (effect.damagedOnly && localUnitAtFullHealth(card)) return false;
  if (effect.attackAtMost != null && num(card.attack, 0) > num(effect.attackAtMost, 0)) return false;
  if (effect.attackAtLeast != null && num(card.attack, 0) < num(effect.attackAtLeast, 0)) return false;
  if (effect.ownerTurnOnly && currentLocalParticipant(match)?.id !== owner.id) return false;
  return true;
}

function localPassiveAuraMatchesCard(match = {}, owner = {}, entry = {}, card = {}) {
  if (!card) return false;
  const effect = localPassiveAuraEffect(entry);
  const families = localPassiveAuraFamilies(entry);
  if (families.length && !families.some((family) => hasFamilyTag(card, family))) return false;
  if (effect.ifEnemyDiedThisTurn && !owner.turnFlags?.enemyMinionDied) return false;
  return true;
}

function refreshLocalAuraState(match = {}, owner = {}) {
  const sources = localPassiveAuraSources(owner);
  aliveBoard(owner).forEach((card) => {
    card.statuses = card.statuses ?? {};
    card.baseMaxHealth = num(card.baseMaxHealth ?? card.maxHealth ?? card.health, 1);
    card.baseTaunt = !!(card.baseTaunt ?? /\btaunt\b|\bguard\b/i.test(card.text ?? ''));
    card.baseLifesteal = !!(card.baseLifesteal ?? /\blifesteal\b/i.test(card.text ?? ''));
    card.baseFlying = !!(card.baseFlying ?? /\bflying\b/i.test(card.text ?? ''));
    card.baseRush = !!(card.baseRush ?? /\brush\b/i.test(card.text ?? ''));
    const bundles = [];
    sources.forEach((source) => {
      localPassiveAuraEntries(source).forEach((entry) => {
        if (!localPassiveAuraMatchesUnit(match, owner, entry, card, source)) return;
        bundles.push(localPassiveAuraEffect(entry));
      });
    });
    const attackBonus = bundles.reduce((sum, effect) => sum + Math.max(0, num(effect.attack, 0)), 0);
    const healthBonus = bundles.reduce((sum, effect) => sum + Math.max(0, num(effect.health, 0)), 0);
    const previousHealthBonus = Math.max(0, num(card.statuses.auraHealthBonusApplied, 0));
    const nextMaxHealth = Math.max(1, num(card.baseMaxHealth, 1) + healthBonus);
    const delta = healthBonus - previousHealthBonus;
    card.maxHealth = nextMaxHealth;
    if (delta > 0) card.health = Math.min(nextMaxHealth, num(card.health, 1) + delta);
    else card.health = Math.min(num(card.health, 1), nextMaxHealth);
    card.statuses.auraHealthBonusApplied = healthBonus;
    card.statuses.auraAttackBonus = attackBonus;
    const hasKeyword = (effect, wanted) => [...(Array.isArray(effect.keywords) ? effect.keywords : []), effect.keyword].filter(Boolean).some((entry) => String(entry).toLowerCase() === wanted);
    card.statuses.keepStealthAfterAttackAura = bundles.some((effect) => !!effect.keepStealthAfterAttack);
    card.statuses.immediateAttackAura = bundles.some((effect) => !!effect.grantImmediateAttack);
    card.statuses.taunt = bundles.some((effect) => hasKeyword(effect, 'taunt'));
    card.statuses.auraLifesteal = bundles.some((effect) => hasKeyword(effect, 'lifesteal'));
    card.statuses.auraFlying = bundles.some((effect) => hasKeyword(effect, 'flying'));
    card.statuses.auraRush = bundles.some((effect) => hasKeyword(effect, 'rush'));
    card.lifesteal = !!card.baseLifesteal || !!card.statuses.auraLifesteal;
    card.flying = !!card.baseFlying || !!card.statuses.auraFlying;
    card.rush = !!card.baseRush || !!card.statuses.auraRush;
    if (card.statuses.immediateAttackAura) card.canAttack = true;
  });
}

function refreshLocalAllAuraStates(match = {}) {
  (match.participants ?? []).forEach((participant) => refreshLocalAuraState(match, participant));
}

function localPassiveAuraCostReduction(match = {}, owner = {}, card = {}) {
  let reduction = 0;
  localPassiveAuraSources(owner).forEach((source) => {
    localPassiveAuraEntries(source).forEach((entry) => {
      const effect = localPassiveAuraEffect(entry);
      if (!localPassiveAuraMatchesCard(match, owner, entry, card)) return;
      reduction += Math.max(0, num(effect.costReduction, 0));
    });
  });
  return reduction;
}

function clearLocalTemporaryBuffs(participant = {}) {
  aliveBoard(participant).forEach((card) => {
    card.statuses = card.statuses ?? {};
    const tempAtk = Math.max(0, num(card.tempAttack, 0));
    if (tempAtk > 0) {
      card.attack = Math.max(0, num(card.attack, 0) - tempAtk);
      card.tempAttack = 0;
    }
    const tempHp = Math.max(0, num(card.statuses.tempHealthBonus, 0));
    if (tempHp > 0) {
      card.maxHealth = Math.max(1, num(card.maxHealth ?? card.health, 1) - tempHp);
      card.health = Math.min(num(card.health, 1), card.maxHealth);
      card.statuses.tempHealthBonus = 0;
    }
    if (card.statuses.tempTaunt) card.statuses.tempTaunt = 0;
    if (card.statuses.tempFlying) card.statuses.tempFlying = 0;
    if (card.statuses.tempLifesteal) card.statuses.tempLifesteal = 0;
    if (card.statuses.tempRush) card.statuses.tempRush = 0;
  });
}

function applyLocalStructuredBuff(match = {}, owner = {}, target = null, effect = {}, options = {}) {
  if (!target) return false;
  const tempOnly = !!options.tempOnly || !!effect.untilEndOfTurn;
  const attack = Math.max(0, num(effect.attack, 0));
  const health = Math.max(0, num(effect.health, 0));
  if (attack > 0) {
    target.attack += attack;
    if (tempOnly) target.tempAttack = num(target.tempAttack, 0) + attack;
  }
  if (health > 0) {
    target.maxHealth += health;
    target.health += health;
    if (tempOnly) {
      target.statuses = target.statuses ?? {};
      target.statuses.tempHealthBonus = num(target.statuses.tempHealthBonus, 0) + health;
    }
  }
  const keywords = [...(Array.isArray(effect.keywords) ? effect.keywords : []), effect.keyword].filter(Boolean);
  keywords.forEach((keyword) => {
    const lowered = String(keyword).toLowerCase();
    target.statuses = target.statuses ?? {};
    if (tempOnly && lowered === 'taunt') {
      target.statuses.tempTaunt = 1;
      target.statuses.taunt = true;
      return;
    }
    if (tempOnly && lowered === 'flying') {
      target.statuses.tempFlying = 1;
      target.flying = true;
      return;
    }
    if (tempOnly && lowered === 'lifesteal') {
      target.statuses.tempLifesteal = 1;
      target.lifesteal = true;
      return;
    }
    if (tempOnly && lowered === 'rush') {
      target.statuses.tempRush = 1;
      target.rush = true;
      target.canAttack = true;
      return;
    }
    if (lowered === 'divine shield') target.statuses.divineShield = true;
    if (lowered === 'stealth') {
      target.statuses.stealth = true;
      target.statuses.stealthTurns = Math.max(1, num(target.statuses.stealthTurns, 0) + (tempOnly ? 1 : 0));
    }
    if (lowered === 'taunt') target.statuses.taunt = true;
  });
  if (effect.stealthUntilNextTurn) {
    target.statuses = target.statuses ?? {};
    target.statuses.stealth = true;
    target.statuses.stealthTurns = Math.max(1, num(target.statuses.stealthTurns, 0) + 1);
  }
  if (effect.untargetableUntilNextTurn) {
    target.statuses = target.statuses ?? {};
    target.statuses.untargetableTurns = Math.max(1, num(target.statuses.untargetableTurns, 0) + 1);
  }
  if (effect.divineShieldIfFull && localUnitAtFullHealth(target)) {
    target.statuses = target.statuses ?? {};
    target.statuses.divineShield = true;
  }
  refreshLocalAllAuraStates(match);
  return true;
}

function chooseLocalFamilyFormOption(match = {}, owner = {}, effect = {}) {
  const forms = Array.isArray(effect.forms) ? effect.forms : [];
  if (!forms.length) return null;
  if (owner.controller === 'human') {
    owner.pendingChoice = {
      type: 'family-form',
      family: effect.family ?? null,
      families: Array.isArray(effect.families) ? effect.families : [],
      forms: forms.map((form, index) => ({ ...form, id: form.id ?? `form-${index + 1}` })),
      sourceName: effect.sourceName ?? effect.label ?? 'Form Shift',
    };
    return null;
  }
  const defensive = forms.find((form) => num(form.health, 0) > 0 || [form.keyword, ...(Array.isArray(form.keywords) ? form.keywords : [])].filter(Boolean).some((entry) => String(entry).toLowerCase() === 'taunt'));
  const aggressive = forms.find((form) => num(form.attack, 0) > 0);
  const evasive = forms.find((form) => !!form.stealthUntilNextTurn || [form.keyword, ...(Array.isArray(form.keywords) ? form.keywords : [])].filter(Boolean).some((entry) => ['flying', 'stealth'].includes(String(entry).toLowerCase())));
  if (owner.heroHealth <= 12) return defensive ?? aggressive ?? evasive ?? forms[0];
  if (aliveBoard(owner).length >= enemiesFor(match, owner.id).reduce((sum, participant) => sum + aliveBoard(participant).length, 0)) return aggressive ?? evasive ?? defensive ?? forms[0];
  return evasive ?? aggressive ?? defensive ?? forms[0];
}

function applyLocalFamilyFormChoice(match = {}, owner = {}, effect = {}, choice = null) {
  const picked = choice ?? chooseLocalFamilyFormOption(match, owner, effect);
  if (!picked) return false;
  const families = [...new Set([
    effect.family,
    picked.family,
    ...(Array.isArray(effect.families) ? effect.families : []),
    ...(Array.isArray(picked.families) ? picked.families : []),
  ].map((value) => normalizeFamilyToken(value)).filter(Boolean))];
  aliveBoard(owner).forEach((card) => {
    if (families.length && !families.some((family) => hasFamilyTag(card, family))) return;
    applyLocalStructuredBuff(match, owner, card, {
      attack: num(picked.attack, 0),
      health: num(picked.health, 0),
      keyword: picked.keyword ?? null,
      keywords: Array.isArray(picked.keywords) ? picked.keywords : [],
      stealthUntilNextTurn: !!picked.stealthUntilNextTurn,
      untilEndOfTurn: true,
    }, { tempOnly: true });
  });
  pushLocalLog(match, `${owner.name} chooses ${picked.label ?? 'a form'}.`);
  return true;
}

export function resolveLocalChoice(match = {}, seatId = '', choiceId = '') {
  const owner = participantById(match, seatId);
  const pending = owner?.pendingChoice;
  if (!owner || !pending) return { ok: false, reason: 'no_choice' };
  if (pending.type !== 'family-form') return { ok: false, reason: 'unsupported_choice' };
  const picked = (pending.forms ?? []).find((entry) => entry.id === choiceId) ?? pending.forms?.[0] ?? null;
  owner.pendingChoice = null;
  if (!picked) return { ok: false, reason: 'invalid_choice' };
  applyLocalFamilyFormChoice(match, owner, pending, picked);
  refreshLocalAllAuraStates(match);
  return { ok: true, label: picked.label ?? 'Form' };
}

function effectiveLocalCardCost(match, participant, card) {
  let reduction = Math.max(0, num(card.costOffset, 0));
  const text = normalizeAbilityText(card.text).toLowerCase();
  const handReduction = text.match(/costs\s+\((\d+)\)\s+less\s+for\s+each\s+([a-z-]+)\s+in\s+your\s+hand/i)
    || text.match(/costs\s+\((\d+)\)\s+less\s+for\s+each\s+([a-z-]+)\s+you\s+hold/i);
  if (handReduction) reduction += Number(handReduction[1] ?? 0) * countFamilyInZone(participant.hand, handReduction[2]);
  const boardReduction = text.match(/costs\s+\((\d+)\)\s+less\s+for\s+each\s+([a-z-]+)\s+you\s+control/i);
  if (boardReduction) reduction += Number(boardReduction[1] ?? 0) * countFamilyInZone(aliveBoard(participant), boardReduction[2]);
  const permanents = [...participant.relics, ...participant.fields, ...aliveBoard(participant)];
  permanents.forEach((perm) => {
    const aura = normalizeAbilityText(perm.text).toLowerCase();
    const direct = aura.match(/your\s+([a-z-]+)s?\s+cost\s+\((\d+)\)\s+less/i);
    if (direct && hasFamilyTag(card, direct[1])) reduction += Number(direct[2] ?? 0);
    const familiarityDirect = aura.match(/([a-z-]+)\s+familiarity\s+(\d+):\s*your\s+([a-z-]+)s?\s+cost\s+\((\d+)\)\s+less/i);
    if (familiarityDirect && hasFamilyTag(card, familiarityDirect[3]) && getFamiliarity(participant.familiarity, familiarityDirect[1]) >= Number(familiarityDirect[2] ?? 0)) {
      reduction += Number(familiarityDirect[4] ?? 0);
    }
  });
  reduction += localPassiveAuraCostReduction(match, participant, card);
  return Math.max(0, num(card.cost, 0) - reduction);
}

function auraAttackBonus(participant = {}, card = {}) {
  let bonus = 0;
  [...participant.relics, ...participant.fields, ...aliveBoard(participant)].forEach((perm) => {
    const text = normalizeAbilityText(perm.text).toLowerCase();
    const familyAtk = text.match(/your\s+([a-z-]+)s?\s+have\s+\+(\d+)\s+attack/i);
    if (familyAtk && hasFamilyTag(card, familyAtk[1])) bonus += Number(familyAtk[2] ?? 0);
  });
  return bonus;
}

function localAttackValue(participant = {}, card = {}) {
  refreshLocalAuraState({ participants: [participant], activeSeatIndex: 0 }, participant);
  return Math.max(0, num(card.attack, 0) + num(card.statuses?.auraAttackBonus, 0) + auraAttackBonus(participant, card) + num(card.tempAttack, 0));
}

function applyHeal(target, amount = 0) {
  const heal = Math.max(0, num(amount, 0));
  if (!heal || !target) return 0;
  const before = num(target.health ?? target.heroHealth, 0);
  const max = num(target.maxHealth ?? target.heroMaxHealth, before);
  const next = Math.min(max, before + heal);
  if (Object.prototype.hasOwnProperty.call(target, 'heroHealth')) target.heroHealth = next;
  else target.health = next;
  return Math.max(0, next - before);
}

function applyLocalHealing(match = {}, owner = {}, target = null, amount = 0, sourceCard = null) {
  const healed = applyHeal(target, amount);
  if (!healed || !owner) return healed;
  owner.turnFlags = owner.turnFlags ?? {};
  owner.turnFlags.healed = (owner.turnFlags.healed ?? 0) + healed;
  if (target?.instanceId) {
    resolveLocalEvent(match, owner.id, 'on_heal_self', { ownerId: owner.id, self: target, target, healed, healedTarget: target, sourceCard });
  }
  resolveLocalEvent(match, owner.id, 'on_heal_any', { ownerId: owner.id, self: target, target, healed, healedTarget: target, sourceCard });
  refreshLocalAllAuraStates(match);
  return healed;
}

function stripDivineShield(card = {}) {
  if (!card?.statuses?.divineShield) return false;
  delete card.statuses.divineShield;
  return true;
}

function killCard(match, owner, card) {
  if (!owner || !card) return;
  owner.board = owner.board.filter((entry) => entry.instanceId !== card.instanceId);
  owner.graveyard.push({ ...card });
  owner.turnFlags = owner.turnFlags ?? {};
  owner.turnFlags.minionDied = true;
  resolveLocalEvent(match, owner.id, 'on_death', { ownerId: owner.id, self: card, sourceCard: card, target: card });
  match.participants.forEach((participant) => {
    participant.turnFlags = participant.turnFlags ?? {};
    if (participant.id !== owner.id) participant.turnFlags.enemyMinionDied = true;
    resolveLocalEvent(match, participant.id, 'on_minion_death', { ownerId: owner.id, deadCard: card, sourceCard: card, target: card });
  });
  refreshLocalAllAuraStates(match);
}

function applyDamageToHero(match, seatId, amount = 0, source = null) {
  const target = participantById(match, seatId);
  if (!target) return 0;
  const damage = Math.max(0, num(amount, 0));
  target.heroHealth -= damage;
  pushLocalLog(match, `${source?.name ?? 'Effect'} hits ${target.name} for ${damage}.`);
  if (target.heroHealth <= 0) {
    target.eliminated = true;
    target.board = [];
    target.hand = [];
    target.relics = [];
    target.fields = [];
    pushLocalLog(match, `${target.name} has been eliminated.`);
  }
  return damage;
}

function applyDamageToBoardCard(match, owner, card, amount = 0, source = null, sourceOwnerId = null) {
  const damage = Math.max(0, num(amount, 0));
  if (!card || !owner || damage <= 0) return 0;
  if (stripDivineShield(card)) {
    pushLocalLog(match, `${card.name} shrugs off damage with Divine Shield.`);
    return 0;
  }
  const healthBefore = num(card.health, 0);
  card.statuses = card.statuses ?? {};
  card.statuses.damagedThisTurn = true;
  card.statuses.lastDamageAmount = damage;
  card.statuses.lastDamagedBySpell = ['spell', 'instant', 'sorcery', 'aura', 'trap'].includes(normalizeCardType(source ?? {}));
  card.statuses.lastDamagedByFamilies = collectCardFamilies(source ?? {}).map((entry) => normalizeFamilyToken(entry)).filter(Boolean);
  card.health -= damage;
  if (card.health <= 0) {
    killCard(match, owner, card);
    if (sourceOwnerId) {
      const overkillDamage = Math.max(0, damage - Math.max(0, healthBefore));
      resolveLocalEvent(match, sourceOwnerId, 'on_kill_any', { ownerId: sourceOwnerId, attacker: source, sourceCard: source, target: card, deadCard: card, damageDealt: damage, overkillDamage });
      if (overkillDamage > 0) resolveLocalEvent(match, sourceOwnerId, 'on_overkill_any', { ownerId: sourceOwnerId, attacker: source, sourceCard: source, target: card, deadCard: card, damageDealt: damage, overkillDamage });
    }
  } else {
    resolveLocalEvent(match, owner.id, 'on_survive_damage_self', { ownerId: owner.id, self: card, target: card, amount: damage, attacker: source, sourceCard: source });
    resolveLocalEvent(match, owner.id, 'on_survive_damage_any', { ownerId: owner.id, self: card, target: card, amount: damage, attacker: source, sourceCard: source });
    if (card.lifesteal || /\blifesteal\b/i.test(card.text)) applyLocalHealing(match, owner, owner, damage, source);
  }
  refreshLocalAllAuraStates(match);
  return damage;
}

function summonToken(match, owner, name = 'Token', stats = {}, source = null) {
  const cell = firstOpenBoardCell(match, owner, preferredOpenRowsForCard(match, owner, stats));
  if (!cell) return null;
  const wanted = String(name ?? '').trim().toLowerCase();
  const template = (match.allCards ?? []).find((card) => String(card?.name ?? '').trim().toLowerCase() === wanted);
  const token = cloneCard({
    ...(template ?? {}),
    id: uid('token'),
    name,
    type: template?.type ?? 'minion',
    cost: 0,
    attack: Math.max(0, num(stats.attack ?? template?.attack, 1)),
    health: Math.max(1, num(stats.health ?? template?.health ?? template?.maxHealth, 1)),
    maxHealth: Math.max(1, num(stats.health ?? template?.health ?? template?.maxHealth, 1)),
    text: stats.text ?? template?.text ?? '',
    element: stats.element ?? template?.element ?? source?.element ?? '',
    race: stats.race ?? template?.race ?? '',
    races: stats.races ?? template?.races ?? [],
    keywords: stats.keywords ?? template?.keywords ?? [],
    collectible: false,
  });
  token.row = cell.row;
  token.column = cell.column;
  token.slot = boardLinearSlot(cell.row, cell.column, localBoardRules(match).rowWidth);
  token.expansionDepth = cell.row;
  token.canAttack = !!(token.charge || token.rush);
  token.statuses = token.statuses ?? {};
  owner.board.push(token);
  refreshLocalAllAuraStates(match);
  resolveLocalEvent(match, owner.id, 'on_summon_friendly', { ownerId: owner.id, self: token, summoned: token, sourceCard: source ?? token });
  return token;
}

function targetPoolForEnemyMinion(match, ownerId) {
  return enemiesFor(match, ownerId).flatMap((participant) => aliveBoard(participant).map((card) => ({ participant, card })));
}

function targetPoolForFriendlyMinion(match, ownerId) {
  const owner = participantById(match, ownerId);
  const allies = [owner, ...alliesFor(match, ownerId)].filter(Boolean);
  return allies.flatMap((participant) => aliveBoard(participant).map((card) => ({ participant, card })));
}

function pickWeakestTarget(entries = []) {
  return [...entries].sort((a, b) => (num(a.card?.health, 0) + num(a.card?.attack, 0)) - (num(b.card?.health, 0) + num(b.card?.attack, 0)))[0] ?? null;
}

function pickStrongestTarget(entries = []) {
  return [...entries].sort((a, b) => (num(b.card?.attack, 0) + num(b.card?.health, 0)) - (num(a.card?.attack, 0) + num(a.card?.health, 0)))[0] ?? null;
}

function evaluateLocalCondition(match, ownerId, condition = '', runtime = {}) {
  const source = normalizeAbilityText(condition).toLowerCase();
  const owner = participantById(match, ownerId);
  if (!owner) return false;
  const familyControl = source.match(/^you control (\d+) or more ([a-z-]+)/i);
  if (familyControl) return countFamilyInZone(aliveBoard(owner), familyControl[2]) >= Number(familyControl[1] ?? 0);
  const controlOne = source.match(/^you control (?:a|an) ([a-z-]+)/i);
  if (controlOne) return countFamilyInZone(aliveBoard(owner), controlOne[1]) > 0;
  const famThreshold = source.match(/^([a-z-]+) familiarity (\d+)/i);
  if (famThreshold) return getFamiliarity(owner.familiarity, famThreshold[1]) >= Number(famThreshold[2] ?? 0);
  if (source === 'you restored health this turn') return num(owner.turnFlags?.healed, 0) > 0;
  if (source === 'you control a relic or field') return owner.relics.length > 0 || owner.fields.length > 0;
  if (/deck contains only/i.test(source)) {
    const parts = source.replace(/^your deck contains only\s+/i, '').split(/\s+and\s+/i).map((entry) => normalizeFamilyToken(entry)).filter(Boolean);
    if (!parts.length) return false;
    return [...owner.deck, ...owner.hand, ...owner.board].every((card) => parts.some((family) => hasFamilyTag(card, family)));
  }
  return false;
}

function localStructuredAbilityConditionMet(match = {}, owner = {}, ability = {}, runtime = {}) {
  const watch = runtimeEntityForKey(runtime, ability.watch || '');
  const target = runtimeEntityForKey(runtime, ability.targetWatch || 'target') ?? runtime.target ?? null;
  if (ability.excludeSelf && runtime.self && watch?.instanceId === runtime.self.instanceId) return false;
  if (ability.sourceFamily && (!watch || !hasFamilyTag(watch, ability.sourceFamily))) return false;
  if (ability.targetFamily && (!target || !hasFamilyTag(target, ability.targetFamily))) return false;
  if (ability.controllerFamily && countFamilyInZone(aliveBoard(owner), ability.controllerFamily) < Math.max(1, num(ability.controllerCount ?? 1, 1))) return false;
  if (ability.playedCountEq != null && num(owner.turnFlags?.cardsPlayed, 0) !== num(ability.playedCountEq, 0)) return false;
  if (ability.playedFieldThisTurn && !owner.turnFlags?.playedField) return false;
  if (ability.spellCostMax != null && num((runtime.sourceCard ?? runtime.playedCard)?.cost, 99) > num(ability.spellCostMax, 99)) return false;
  if (ability.spellCostMin != null && num((runtime.sourceCard ?? runtime.playedCard)?.cost, 0) < num(ability.spellCostMin, 0)) return false;
  if (ability.spellCategory && !spellMatchesLocalCategory(runtime.sourceCard ?? runtime.playedCard ?? {}, ability.spellCategory)) return false;
  if (ability.watchAttackAtMost != null && num(watch?.attack, 999) > num(ability.watchAttackAtMost, 999)) return false;
  if (ability.watchAttackAtLeast != null && num(watch?.attack, 0) < num(ability.watchAttackAtLeast, 0)) return false;
  if (ability.watchStealthed && !watch?.statuses?.stealth) return false;
  if (ability.watchFullHealth && !localUnitAtFullHealth(watch)) return false;
  if (ability.watchDamaged && localUnitAtFullHealth(watch)) return false;
  if (ability.healedThisTurn && num(owner.turnFlags?.healed, 0) <= 0) return false;
  if (ability.condition && !evaluateLocalCondition(match, owner.id, ability.condition, runtime)) return false;
  return true;
}

function executeLocalAction(match, ownerId, action = '', runtime = {}) {
  const source = normalizeAbilityText(action);
  const owner = participantById(match, ownerId);
  if (!owner) return false;
  const lowered = source.toLowerCase();

  const gainFam = lowered.match(/^gain (\d+) ([a-z-]+) familiarity/i);
  if (gainFam) {
    addFamiliarity(owner.familiarity, gainFam[2], Number(gainFam[1] ?? 0));
    return true;
  }
  const drawCards = lowered.match(/^draw (\d+)/i);
  if (drawCards) {
    const count = Number(drawCards[1] ?? 0);
    for (let i = 0; i < count; i += 1) topCardDraw(owner);
    return true;
  }
  const dealEnemyMinion = lowered.match(/^deal (\d+) damage to an enemy minion/i);
  if (dealEnemyMinion) {
    const target = pickWeakestTarget(targetPoolForEnemyMinion(match, ownerId));
    if (target) applyDamageToBoardCard(match, target.participant, target.card, Number(dealEnemyMinion[1] ?? 0), runtime.sourceCard);
    return true;
  }
  const dealAllEnemyMinions = lowered.match(/^deal (\d+) damage to all enemy minions/i);
  if (dealAllEnemyMinions) {
    targetPoolForEnemyMinion(match, ownerId).forEach((target) => applyDamageToBoardCard(match, target.participant, target.card, Number(dealAllEnemyMinions[1] ?? 0), runtime.sourceCard));
    return true;
  }
  const dealAllEnemies = lowered.match(/^deal (\d+) damage to all enemies/i);
  if (dealAllEnemies) {
    enemiesFor(match, ownerId).forEach((targetParticipant) => {
      applyDamageToHero(match, targetParticipant.id, Number(dealAllEnemies[1] ?? 0), runtime.sourceCard);
      aliveBoard(targetParticipant).forEach((card) => applyDamageToBoardCard(match, targetParticipant, card, Number(dealAllEnemies[1] ?? 0), runtime.sourceCard));
    });
    return true;
  }
  const restoreFriendlyMinion = lowered.match(/^restore (\d+) health to a friendly minion/i);
  if (restoreFriendlyMinion) {
    const target = pickStrongestTarget(targetPoolForFriendlyMinion(match, ownerId).filter((entry) => num(entry.card.health, 0) < num(entry.card.maxHealth, 0)));
    if (target) owner.turnFlags.healed = (owner.turnFlags.healed ?? 0) + applyHeal(target.card, Number(restoreFriendlyMinion[1] ?? 0));
    return true;
  }
  const restoreAllFriendly = lowered.match(/^restore (\d+) health to all friendly minions/i) || lowered.match(/^restore (\d+) health to all friendly characters/i);
  if (restoreAllFriendly) {
    const amount = Number(restoreAllFriendly[1] ?? 0);
    owner.turnFlags.healed = (owner.turnFlags.healed ?? 0) + applyHeal(owner, amount);
    [owner, ...alliesFor(match, ownerId)].forEach((participant) => aliveBoard(participant).forEach((card) => {
      owner.turnFlags.healed = (owner.turnFlags.healed ?? 0) + applyHeal(card, amount);
    }));
    return true;
  }
  const summonTokens = lowered.match(/^summon (\d+) .*token/i) || lowered.match(/^summon (\d+) 1\/1/i);
  if (summonTokens) {
    const count = Number(summonTokens[1] ?? 0);
    for (let i = 0; i < count; i += 1) summonToken(match, owner, `${runtime.sourceCard?.name ?? 'Token'} Token`, { attack: 1, health: 1 }, runtime.sourceCard);
    return true;
  }
  const summonNamed = lowered.match(/^summon (?:a|an) 1\/1 ([a-z0-9' -]+)/i);
  if (summonNamed) {
    summonToken(match, owner, summonNamed[1].trim(), { attack: 1, health: 1, race: normalizeFamilyToken(summonNamed[1]) }, runtime.sourceCard);
    return true;
  }
  const buffFriendly = lowered.match(/^give a friendly minion \+(\d+)\/\+(\d+)/i);
  if (buffFriendly) {
    const target = pickStrongestTarget(targetPoolForFriendlyMinion(match, ownerId));
    if (target) {
      target.card.attack += Number(buffFriendly[1] ?? 0);
      target.card.health += Number(buffFriendly[2] ?? 0);
      target.card.maxHealth += Number(buffFriendly[2] ?? 0);
    }
    return true;
  }
  const buffAllies = lowered.match(/^give your minions \+(\d+) attack/i);
  if (buffAllies) {
    aliveBoard(owner).forEach((card) => { card.tempAttack = num(card.tempAttack, 0) + Number(buffAllies[1] ?? 0); });
    return true;
  }
  const familyBuff = lowered.match(/^your ([a-z-]+)s? have \+(\d+) attack/i);
  if (familyBuff) {
    aliveBoard(owner).filter((card) => hasFamilyTag(card, familyBuff[1])).forEach((card) => { card.attack += Number(familyBuff[2] ?? 0); });
    return true;
  }
  const reduceFamilyHand = lowered.match(/^reduce the cost of a .*([a-z-]+).* in your hand by \((\d+)\)/i);
  if (reduceFamilyHand) {
    owner.hand.filter((card) => hasFamilyTag(card, reduceFamilyHand[1])).slice(0, 1).forEach((card) => { card.costOffset = Math.max(0, num(card.costOffset, 0) + Number(reduceFamilyHand[2] ?? 0)); });
    return true;
  }
  const destroyDamaged = lowered.match(/^destroy a damaged minion/i) || lowered.match(/^destroy a damaged enemy minion/i);
  if (destroyDamaged) {
    const pool = targetPoolForEnemyMinion(match, ownerId).filter((entry) => num(entry.card.health, 0) < num(entry.card.maxHealth, 0));
    const target = pickWeakestTarget(pool);
    if (target) killCard(match, target.participant, target.card);
    return true;
  }
  return false;
}

function executeLocalStructuredAbility(match = {}, owner = {}, ability = {}, runtime = {}) {
  const effect = ability?.effect && typeof ability.effect === 'object' ? ability.effect : ability;
  const scriptedText = normalizeAbilityText(effect.text ?? ability.text ?? '');
  if (!localStructuredAbilityConditionMet(match, owner, ability, runtime)) return false;
  if (ability.oncePerTurn) {
    const bucket = localStructuredUseBucket(owner);
    const key = localStructuredAbilityKey(ability);
    if (bucket[key]) return true;
    bucket[key] = true;
  }
  const actionId = String(effect.action ?? ability.action ?? '').trim();
  const amount = Math.max(0, num(effect.amount ?? effect.value ?? ability.amount ?? 1, 1));
  const watch = runtimeEntityForKey(runtime, ability.watch || '');
  if (actionId === 'drawCards') {
    for (let i = 0; i < amount; i += 1) topCardDraw(owner);
    return true;
  }
  if (actionId === 'summonNamedToken') {
    for (let i = 0; i < Math.max(1, amount); i += 1) {
      summonToken(match, owner, effect.name ?? 'Token', {
        attack: Math.max(0, num(effect.attack ?? 1, 1)),
        health: Math.max(1, num(effect.health ?? 1, 1)),
        text: effect.text ?? '',
        race: effect.race ?? '',
        races: effect.races ?? [],
      }, runtime.sourceCard ?? runtime.self ?? null);
    }
    return true;
  }
  if (actionId === 'addNamedCardToHand') {
    addLocalNamedCardToHand(match, owner, effect.name ?? 'Generated Card', effect);
    return true;
  }
  if (actionId === 'reduceCostInHandByFamily') {
    const family = effect.family ?? ability.family ?? ability.sourceFamily ?? '';
    const pool = owner.hand.filter((card) => hasFamilyTag(card, family));
    const chosen = effect.random ? pickRandom(pool) : pool[0];
    if (chosen) chosen.costOffset = Math.max(0, num(chosen.costOffset, 0) + amount);
    return true;
  }
  if (actionId === 'grantReturnedCostReduction') {
    if (runtime.returned) runtime.returned.costOffset = Math.max(0, num(runtime.returned.costOffset, 0) + amount);
    return true;
  }
  if (actionId === 'dealDamageRandomEnemy') {
    const target = pickWeakestTarget(targetPoolForEnemyMinion(match, owner.id));
    if (target) applyDamageToBoardCard(match, target.participant, target.card, amount, runtime.sourceCard, owner.id);
    else enemiesFor(match, owner.id).forEach((participant) => applyDamageToHero(match, participant.id, amount, runtime.sourceCard));
    return true;
  }
  if (actionId === 'dealDamageAnyEnemy') {
    const target = pickStrongestTarget(targetPoolForEnemyMinion(match, owner.id));
    if (target) applyDamageToBoardCard(match, target.participant, target.card, amount, runtime.sourceCard, owner.id);
    else enemiesFor(match, owner.id).forEach((participant) => applyDamageToHero(match, participant.id, amount, runtime.sourceCard));
    return true;
  }
  if (actionId === 'dealDamageFriendlyFamily') {
    const pool = aliveBoard(owner).filter((card) => hasFamilyTag(card, effect.family ?? ability.family ?? ability.sourceFamily ?? '') && (!effect.excludeSelf || card.instanceId !== runtime.self?.instanceId));
    const chosen = pickRandom(pool);
    if (chosen) applyDamageToBoardCard(match, owner, chosen, amount, runtime.sourceCard, owner.id);
    return true;
  }
  if (actionId === 'buffTarget') {
    const target = runtime.target ?? watch ?? runtime.self ?? null;
    if (!target) return true;
    applyLocalStructuredBuff(match, owner, target, effect, { tempOnly: !!effect.untilEndOfTurn });
    return true;
  }
  if (actionId === 'buffRandomFriendlyFamily') {
    const pool = aliveBoard(owner).filter((card) => {
      if (effect.family && !hasFamilyTag(card, effect.family)) return false;
      if (Array.isArray(effect.families) && effect.families.length && !effect.families.some((entry) => hasFamilyTag(card, entry))) return false;
      if (effect.excludeSelf && card.instanceId === runtime.self?.instanceId) return false;
      return true;
    });
    const chosen = pickRandom(pool);
    if (chosen) applyLocalStructuredBuff(match, owner, chosen, effect, { tempOnly: !!effect.untilEndOfTurn });
    return true;
  }
  if (actionId === 'buffAllFriendlyFamilyThisTurn') {
    aliveBoard(owner).forEach((card) => {
      if (effect.family && !hasFamilyTag(card, effect.family)) return;
      if (Array.isArray(effect.families) && effect.families.length && !effect.families.some((entry) => hasFamilyTag(card, entry))) return;
      applyLocalStructuredBuff(match, owner, card, effect, { tempOnly: true });
    });
    return true;
  }
  if (actionId === 'chooseFamilyForm') {
    return applyLocalFamilyFormChoice(match, owner, effect);
  }
  if (actionId === 'healHero') {
    applyLocalHealing(match, owner, owner, amount, runtime.sourceCard);
    return true;
  }
  if (actionId === 'freezeLowestHealthEnemyMinion') {
    const target = [...targetPoolForEnemyMinion(match, owner.id)].sort((a, b) => num(a.card.health, 0) - num(b.card.health, 0))[0];
    if (target) {
      target.card.statuses = target.card.statuses ?? {};
      target.card.statuses.frozen = 1;
      target.card.canAttack = false;
    }
    return true;
  }
  if (actionId === 'grantReturnedCostReduction') {
    if (runtime.returned) runtime.returned.costOffset = Math.max(0, num(runtime.returned.costOffset, 0) + amount);
    return true;
  }
  if (actionId === 'dealDamageAllOtherMinions') {
    match.participants.forEach((participant) => aliveBoard(participant).forEach((card) => {
      if (card.instanceId === runtime.self?.instanceId) return;
      applyDamageToBoardCard(match, participant, card, amount, runtime.sourceCard, owner.id);
    }));
    return true;
  }
  if (actionId === 'healHeroFromDamage') {
    const dealt = Math.max(0, num(runtime.damageDealt, 0));
    const healAmount = Math.min(num(effect.cap ?? amount, amount), dealt);
    const before = num(owner.heroHealth, 0);
    applyLocalHealing(match, owner, owner, healAmount, runtime.sourceCard);
    if (before + healAmount > num(owner.heroMaxHealth, before) && watch) {
      applyLocalStructuredBuff(match, owner, watch, { attack: num(effect.overhealAttack ?? 1, 1), health: num(effect.overhealHealth ?? 1, 1) });
    }
    return true;
  }
  if (actionId === 'curseTarget') {
    const target = runtime.target ?? watch ?? null;
    if (target) {
      target.statuses = target.statuses ?? {};
      target.statuses.cursed = 1;
      target.statuses.cursedTurns = Math.max(1, num(effect.duration ?? 1, 1));
      target.attack = Math.max(0, num(target.attack, 0) - num(effect.attackPenalty ?? 1, 1));
    }
    return true;
  }
  if (scriptedText) {
    splitActions(scriptedText).forEach((action) => executeLocalAction(match, owner.id, action, runtime));
    return true;
  }
  return false;
}

function resolveLocalClause(match, ownerId, clause = {}, runtime = {}) {
  let body = clause.body;
  const ifCond = extractIfCondition(body);
  if (ifCond) {
    if (!evaluateLocalCondition(match, ownerId, ifCond.condition, runtime)) return;
    body = ifCond.thenText;
  }
  splitActions(body).forEach((action) => executeLocalAction(match, ownerId, action, runtime));
}

function resolveLocalEvent(match, ownerId, eventKey = '', runtime = {}) {
  const owner = participantById(match, ownerId);
  if (!owner) return;
  const sources = [...aliveBoard(owner), ...owner.relics, ...owner.fields];
  sources.forEach((card) => {
    structuredAbilityEntries(card).forEach((ability) => {
      const trigger = String(ability?.trigger ?? '').toLowerCase();
      if (trigger && trigger !== eventKey) return;
      executeLocalStructuredAbility(match, owner, ability, { ...runtime, sourceCard: card, self: runtime.self ?? card, playedCard: runtime.playedCard ?? runtime.sourceCard ?? null });
    });
    (card.clauses ?? []).forEach((clause) => {
      if (clause.trigger !== eventKey) return;
      resolveLocalClause(match, ownerId, clause, { ...runtime, sourceCard: card, self: runtime.self ?? card });
    });
  });
}

export function localSeatBoardState(match = {}, seatId = '') {
  const participant = participantById(match, seatId);
  if (!participant) return null;
  ensureParticipantBoardState(match, participant);
  const unlockedRows = boardRowsUnlocked(match, participant);
  const frontlineRow = boardFrontlineRow(match, participant);
  const deepestRow = boardDeepestRow(match, participant);
  return {
    seatId,
    rowWidth: localBoardRules(match).rowWidth,
    unlockedRows,
    frontlineRow,
    deepestRow,
    newestRow: num(participant.boardState?.newestRow, unlockedRows - 1),
    rows: boardRowsForParticipant(match, participant).map((row) => ({
      index: row.row,
      isFrontline: row.row === frontlineRow,
      isNewest: row.row === num(participant.boardState?.newestRow, unlockedRows - 1),
      fill: row.slots.filter((entry) => !!entry.card).length,
      slots: row.slots.map((entry) => ({
        row: entry.row,
        column: entry.column,
        card: entry.card ?? null,
      })),
    })),
  };
}

export function localBoardPositionLabel(match = {}, seatId = '', cardId = '') {
  const boardState = localSeatBoardState(match, seatId);
  const found = boardState?.rows?.flatMap((row) => row.slots).find((entry) => entry.card?.instanceId === cardId);
  if (!found) return '';
  return `Row ${found.row + 1}, Column ${found.column + 1}`;
}

export function playLocalCard(match = {}, seatId = '', cardId = '', placementOverride = null) {
  if (match.matchOver) return { ok: false, reason: 'match_over' };
  const owner = participantById(match, seatId);
  const actor = currentLocalParticipant(match);
  if (!owner || !actor || owner.id !== actor.id) return { ok: false, reason: 'not_turn' };
  ensureParticipantBoardState(match, owner);
  const handIndex = owner.hand.findIndex((entry) => entry.instanceId === cardId);
  if (handIndex < 0) return { ok: false, reason: 'missing_card' };
  const card = owner.hand[handIndex];
  const cost = effectiveLocalCardCost(match, owner, card);
  if (cost > owner.mana) return { ok: false, reason: 'mana' };
  owner.mana -= cost;
  owner.hand.splice(handIndex, 1);
  owner.turnFlags = owner.turnFlags ?? {};
  owner.turnFlags.cardsPlayed = (owner.turnFlags.cardsPlayed ?? 0) + 1;
  const type = normalizeCardType(card);

  if (type === 'minion') {
    let cell = null;
    if (placementOverride && typeof placementOverride === 'object' && placementOverride.row != null && placementOverride.column != null) {
      const row = clamp(num(placementOverride.row, 0), 0, localBoardRules(match).maxRows - 1);
      const column = clamp(num(placementOverride.column, 0), 0, localBoardRules(match).rowWidth - 1);
      if (row < boardRowsUnlocked(match, owner) && !boardOccupantAt(match, owner, row, column)) cell = { row, column, unlocked: false };
    } else if (placementOverride != null) {
      const coords = boardCoordinatesFromLinearSlot(num(placementOverride, 0), localBoardRules(match).rowWidth);
      if (coords.row < boardRowsUnlocked(match, owner) && !boardOccupantAt(match, owner, coords.row, coords.column)) cell = { ...coords, unlocked: false };
    } else {
      cell = firstOpenBoardCell(match, owner, preferredOpenRowsForCard(match, owner, card));
    }
    if (!cell) {
      owner.hand.splice(handIndex, 0, card);
      owner.mana += cost;
      return { ok: false, reason: 'board_full' };
    }
    const summoned = {
      ...card,
      row: cell.row,
      column: cell.column,
      slot: boardLinearSlot(cell.row, cell.column, localBoardRules(match).rowWidth),
      expansionDepth: cell.row,
      canAttack: /\b(charge|rush)\b/i.test(card.text),
      statuses: { ...(card.statuses ?? {}) },
    };
    if (/\bdivine shield\b/i.test(card.text)) summoned.statuses.divineShield = true;
    owner.board.push(summoned);
    const famStart = num(card.familiarity?.start ?? 0, 0);
    if (card.familiarity?.race && famStart > 0) addFamiliarity(owner.familiarity, card.familiarity.race, famStart);
    resolveLocalEvent(match, owner.id, 'on_summon_friendly', { ownerId: owner.id, summoned, sourceCard: summoned });
    resolveLocalEvent(match, owner.id, 'on_play_card', { ownerId: owner.id, playedCard: summoned, sourceCard: summoned });
    structuredAbilityEntries(summoned).forEach((ability) => {
      if (String(ability?.trigger ?? '').toLowerCase() === 'on_play') executeLocalStructuredAbility(match, owner, ability, { ownerId: owner.id, sourceCard: summoned, playedCard: summoned, self: summoned });
    });
    (summoned.clauses ?? []).forEach((clause) => {
      if (clause.trigger === 'on_play') resolveLocalClause(match, owner.id, clause, { ownerId: owner.id, sourceCard: summoned, self: summoned });
    });
    pushLocalLog(match, `${owner.name} plays ${summoned.name}.`);
    checkMatchEnd(match);
    return { ok: true, type: 'summon', card: summoned, rowUnlocked: !!cell.unlocked };
  }

  if (type === 'relic') {
    owner.relics.push({ ...card });
    owner.turnFlags.playedRelic = true;
    resolveLocalEvent(match, owner.id, 'on_play_card', { ownerId: owner.id, playedCard: card, sourceCard: card });
    (card.clauses ?? []).forEach((clause) => {
      if (clause.trigger === 'on_play') resolveLocalClause(match, owner.id, clause, { ownerId: owner.id, sourceCard: card, self: card });
    });
    structuredAbilityEntries(card).forEach((ability) => {
      if (String(ability?.trigger ?? '').toLowerCase() === 'on_play') executeLocalStructuredAbility(match, owner, ability, { ownerId: owner.id, sourceCard: card, playedCard: card, self: card });
    });
    owner.graveyard.push({ ...card, spent: false });
    pushLocalLog(match, `${owner.name} deploys relic ${card.name}.`);
    checkMatchEnd(match);
    return { ok: true, type: 'relic', card };
  }

  if (type === 'field') {
    owner.fields.push({ ...card });
    owner.turnFlags.playedField = true;
    resolveLocalEvent(match, owner.id, 'on_play_card', { ownerId: owner.id, playedCard: card, sourceCard: card });
    (card.clauses ?? []).forEach((clause) => {
      if (clause.trigger === 'on_play') resolveLocalClause(match, owner.id, clause, { ownerId: owner.id, sourceCard: card, self: card });
    });
    structuredAbilityEntries(card).forEach((ability) => {
      if (String(ability?.trigger ?? '').toLowerCase() === 'on_play') executeLocalStructuredAbility(match, owner, ability, { ownerId: owner.id, sourceCard: card, playedCard: card, self: card });
    });
    owner.graveyard.push({ ...card, spent: false });
    pushLocalLog(match, `${owner.name} claims field ${card.name}.`);
    checkMatchEnd(match);
    return { ok: true, type: 'field', card };
  }

  (card.clauses ?? []).forEach((clause) => {
    if (clause.trigger === 'on_play' || clause.trigger === 'passive') resolveLocalClause(match, owner.id, clause, { ownerId: owner.id, sourceCard: card, self: card });
  });
  resolveLocalEvent(match, owner.id, 'on_spell_cast', { ownerId: owner.id, sourceCard: card, playedCard: card, target: null });
  resolveLocalEvent(match, owner.id, 'on_play_card', { ownerId: owner.id, sourceCard: card, playedCard: card, target: null });
  structuredAbilityEntries(card).forEach((ability) => {
    const trigger = String(ability?.trigger ?? '').toLowerCase();
    if (trigger === 'on_play' || trigger === 'passive') executeLocalStructuredAbility(match, owner, ability, { ownerId: owner.id, sourceCard: card, playedCard: card, self: card });
  });
  owner.graveyard.push({ ...card });
  pushLocalLog(match, `${owner.name} casts ${card.name}.`);
  checkMatchEnd(match);
  return { ok: true, type: 'spell', card };
}

function teamAliveMap(match = {}) {
  const map = new Map();
  (match.participants ?? []).forEach((participant) => {
    if (participant.eliminated) return;
    map.set(participant.team, (map.get(participant.team) ?? 0) + 1);
  });
  return map;
}

function checkMatchEnd(match = {}) {
  const aliveTeams = [...teamAliveMap(match).keys()];
  if (aliveTeams.length <= 1) {
    match.matchOver = true;
    match.winnerTeam = aliveTeams[0] ?? null;
    match.winnerSeatIds = (match.participants ?? []).filter((participant) => !participant.eliminated && participant.team === match.winnerTeam).map((participant) => participant.id);
    return true;
  }
  return false;
}

function legalAttackTargets(match = {}, ownerId = '', attacker = {}) {
  const owner = participantById(match, ownerId);
  if (!owner || !canAttackFromDepth(match, owner, attacker)) return [];
  const foes = enemiesFor(match, ownerId).filter((participant) => !participant.eliminated);
  const targets = [];
  const reachBackline = canReachProtectedBackline(attacker);
  foes.forEach((participant) => {
    const taunts = aliveBoard(participant).filter((card) => /\btaunt\b/i.test(card.text) || /\bguard\b/i.test(card.text) || card.statuses?.taunt);
    const exposed = boardExposedFrontline(match, participant);
    const boardTargets = taunts.length
      ? taunts
      : (reachBackline ? aliveBoard(participant) : (exposed.length ? exposed : aliveBoard(participant)));
    boardTargets.forEach((card) => targets.push({ type: 'unit', ownerId: participant.id, cardId: card.instanceId }));
    if (!taunts.length && !exposed.length) targets.push({ type: 'hero', ownerId: participant.id, cardId: null });
  });
  return targets;
}

export function localLegalAttackTargets(match = {}, ownerId = '', attacker = {}) {
  return legalAttackTargets(match, ownerId, attacker);
}

export function localAttack(match = {}, seatId = '', attackerId = '', target = null) {
  if (match.matchOver) return { ok: false, reason: 'match_over' };
  const owner = participantById(match, seatId);
  const attacker = aliveBoard(owner).find((entry) => entry.instanceId === attackerId);
  if (!owner || !attacker) return { ok: false, reason: 'missing_attacker' };
  if (currentLocalParticipant(match)?.id !== owner.id) return { ok: false, reason: 'not_turn' };
  if (!attacker.canAttack) return { ok: false, reason: 'exhausted' };
  const legal = legalAttackTargets(match, owner.id, attacker);
  const chosen = legal.find((entry) => entry.type === target?.type && entry.ownerId === target?.ownerId && entry.cardId === (target?.cardId ?? null));
  if (!chosen) return { ok: false, reason: 'invalid_target' };
  const attackValue = localAttackValue(owner, attacker);
  if (chosen.type === 'hero') {
    applyDamageToHero(match, chosen.ownerId, attackValue, attacker);
  } else {
    const defenderOwner = participantById(match, chosen.ownerId);
    const defender = aliveBoard(defenderOwner).find((entry) => entry.instanceId === chosen.cardId);
    if (!defender) return { ok: false, reason: 'missing_target' };
    const defenderAttack = localAttackValue(defenderOwner, defender);
    applyDamageToBoardCard(match, defenderOwner, defender, attackValue, attacker);
    if (aliveBoard(owner).find((entry) => entry.instanceId === attacker.instanceId)) applyDamageToBoardCard(match, owner, attacker, defenderAttack, defender);
    if ((attacker.lifesteal || /\blifesteal\b/i.test(attacker.text)) && attackValue > 0) applyHeal(owner, attackValue);
  }
  attacker.canAttack = false;
  pushLocalLog(match, `${owner.name}'s ${attacker.name} attacks.`);
  checkMatchEnd(match);
  return { ok: true };
}

function startLocalTurn(match = {}) {
  if (match.matchOver) return;
  const participant = currentLocalParticipant(match);
  if (!participant) return;
  participant.maxMana += match.turnNumber > 1 ? 1 : 0;
  participant.mana = participant.maxMana;
  participant.turnFlags = { healed: 0 };
  participant.board.forEach((card) => {
    card.canAttack = true;
    card.tempAttack = 0;
  });
  topCardDraw(participant);
  resolveLocalEvent(match, participant.id, 'on_start_turn', { ownerId: participant.id, sourceCard: null });
  match.handoff = { required: participant.controller === 'human', seatId: participant.id, turnNumber: match.turnNumber };
  pushLocalLog(match, `${participant.name}'s turn begins.`);
}

export function acknowledgeHandoff(match = {}) {
  if (!match?.handoff) return;
  match.handoff.required = false;
}

export function endLocalTurn(match = {}) {
  if (match.matchOver) return match;
  const participant = currentLocalParticipant(match);
  if (!participant) return match;
  resolveLocalEvent(match, participant.id, 'on_end_turn', { ownerId: participant.id, sourceCard: null });
  if (checkMatchEnd(match)) return match;
  let nextIndex = match.activeSeatIndex;
  for (let step = 0; step < match.participants.length; step += 1) {
    nextIndex = (nextIndex + 1) % match.participants.length;
    if (!match.participants[nextIndex].eliminated) break;
  }
  match.activeSeatIndex = nextIndex;
  match.turnNumber += 1;
  startLocalTurn(match);
  return match;
}

function aiTargetScore(match, seatId, target) {
  if (target.type === 'hero') {
    const hero = participantById(match, target.ownerId);
    const exposed = boardExposedFrontline(match, hero);
    return (100 - num(hero?.heroHealth, 30)) + (exposed.length ? -18 : 10);
  }
  const owner = participantById(match, target.ownerId);
  const card = aliveBoard(owner).find((entry) => entry.instanceId === target.cardId);
  if (!card) return -999;
  return (num(card.attack, 0) * 3)
    + num(card.health, 0)
    + (/\btaunt\b|\bguard\b/i.test(card.text) ? 8 : 0)
    + (num(card.row, 0) === boardFrontlineRow(match, owner) ? 4 : 0)
    + (localCardRoleProfile(card).support ? 6 : 0);
}

function aiCardScore(match, participant, card) {
  const type = normalizeCardType(card);
  let score = localCardScore(card) + num(card.cost, 0);
  if (type === 'minion' && !firstOpenBoardCell(match, participant, preferredOpenRowsForCard(match, participant, card), { allowUnlock: false })) score -= 20;
  if (type === 'spell') score += /deal \d+ damage/i.test(card.text) ? 4 : 0;
  if (/draw \d+/i.test(card.text)) score += 2.5;
  if (/\btaunt\b|\bguard\b/i.test(card.text) && participant.heroHealth <= 14) score += 6;
  if (/your [a-z-]+s? have/i.test(card.text)) score += aliveBoard(participant).length;
  if (localCardRoleProfile(card).backliner && boardRowsUnlocked(match, participant) > 1) score += 2.5;
  return score;
}

export function runLocalAiTurn(match = {}) {
  const participant = currentLocalParticipant(match);
  if (!participant || participant.controller !== 'ai' || match.matchOver) return match;
  ensureParticipantBoardState(match, participant);
  const difficulty = LOCAL_PLAYER_AI_DIFFICULTIES.find((entry) => entry.id === participant.aiDifficulty) ?? LOCAL_PLAYER_AI_DIFFICULTIES[1];
  acknowledgeHandoff(match);
  let safeguard = 0;
  while (safeguard < difficulty.actionLimit) {
    safeguard += 1;
    const affordable = participant.hand
      .map((card) => ({ card, cost: effectiveLocalCardCost(match, participant, card), score: aiCardScore(match, participant, card) }))
      .filter((entry) => entry.cost <= participant.mana)
      .sort((a, b) => b.score - a.score);
    if (!affordable.length) break;
    const best = difficulty.id === 'easy'
      ? pickRandom(affordable.slice(0, Math.min(3, affordable.length)))
      : affordable[0];
    const preferredCell = firstOpenBoardCell(match, participant, preferredOpenRowsForCard(match, participant, best.card), { allowUnlock: false });
    const played = playLocalCard(match, participant.id, best.card.instanceId, preferredCell ? { row: preferredCell.row, column: preferredCell.column } : null);
    if (!played.ok) break;
  }

  aliveBoard(participant)
    .filter((card) => card.canAttack)
    .sort((a, b) => localAttackValue(participant, b) - localAttackValue(participant, a))
    .forEach((attacker) => {
      const ranked = legalAttackTargets(match, participant.id, attacker)
        .sort((a, b) => aiTargetScore(match, participant.id, b) - aiTargetScore(match, participant.id, a));
      const targets = difficulty.id === 'easy' ? shuffle(ranked).slice(0, Math.max(1, Math.min(2, ranked.length))) : ranked;
      if (targets.length) localAttack(match, participant.id, attacker.instanceId, targets[0]);
    });

  endLocalTurn(match);
  return match;
}

export function localMatchToText(match = {}, perspectiveSeatId = '') {
  const current = currentLocalParticipant(match);
  const perspective = perspectiveSeatId ? participantById(match, perspectiveSeatId) : current;
  ensureAllParticipantBoardState(match);
  return JSON.stringify({
    mode: 'local-player',
    format: match.formatId,
    deckMode: match.modeId,
    turn: match.turnNumber,
    activeSeatId: current?.id ?? null,
    activePlayer: current?.name ?? null,
    perspectiveSeatId: perspective?.id ?? null,
    handoff: match.handoff,
    participants: (match.participants ?? []).map((participant) => ({
      id: participant.id,
      name: participant.name,
      team: participant.team,
      controller: participant.controller,
      seatIndex: participant.seatIndex,
      eliminated: participant.eliminated,
      health: participant.heroHealth,
      mana: `${participant.mana}/${participant.maxMana}`,
      handCount: participant.id === perspective?.id && !match.handoff?.required ? participant.hand.length : 'hidden',
      boardRowsUnlocked: participant.boardRowsUnlocked,
      frontlineRow: boardFrontlineRow(match, participant),
      board: aliveBoard(participant).map((card) => ({
        id: card.instanceId,
        name: card.name,
        atk: localAttackValue(participant, card),
        hp: card.health,
        row: card.row,
        column: card.column,
        slot: card.slot,
      })),
    })),
    winnerTeam: match.winnerTeam,
  });
}

export function localSeatSummary(match = {}, perspectiveSeatId = '') {
  const rotated = rotatedPerspective(match, perspectiveSeatId);
  const rolesByCount = {
    2: ['bottom', 'top'],
    3: ['bottom', 'left', 'top'],
    4: ['bottom', 'left', 'top', 'right'],
  };
  const roles = rolesByCount[rotated.length] ?? ['bottom', 'left', 'top', 'right'];
  return rotated.map((participant, index) => ({
    ...participant,
    perspectiveRole: roles[index] ?? 'bench',
  }));
}

export function debugSeedLocalBoard(match = {}, seatId = '', options = {}) {
  const participant = participantById(match, seatId);
  if (!participant) return null;
  const rules = localBoardRules(match);
  const requestedRows = clamp(num(options.rows, 1), 1, rules.maxRows);
  const fillCounts = Array.isArray(options.fillCounts) && options.fillCounts.length
    ? options.fillCounts.map((entry) => clamp(num(entry, 0), 0, rules.rowWidth)).slice(0, requestedRows)
    : Array.from({ length: requestedRows }, (_, index) => (index < requestedRows - 1 ? rules.rowWidth : clamp(num(options.lastRowCards, 1), 1, rules.rowWidth)));
  const template = cloneCard((match.cardPool ?? match.allCards ?? []).find((card) => normalizeCardType(card) === 'minion') ?? { name: 'Stress Test Unit', type: 'minion', cost: 1, attack: 2, health: 2, text: '' });
  participant.board = [];
  participant.boardRowsUnlocked = requestedRows;
  participant.boardState = participant.boardState && typeof participant.boardState === 'object' ? participant.boardState : {};
  participant.boardState.newestRow = requestedRows - 1;
  fillCounts.forEach((count, row) => {
    for (let column = 0; column < count; column += 1) {
      const card = cloneCard({
        ...template,
        id: `${template.id}-debug-${row}-${column}`,
        name: `${template.name} ${row + 1}-${column + 1}`,
        cost: 1,
        attack: Math.max(1, num(template.attack, 2) + row),
        health: Math.max(1, num(template.health ?? template.maxHealth, 2)),
        maxHealth: Math.max(1, num(template.maxHealth ?? template.health, 2)),
      });
      card.instanceId = uid('local-debug');
      card.row = row;
      card.column = column;
      card.slot = boardLinearSlot(row, column, rules.rowWidth);
      card.expansionDepth = row;
      card.canAttack = options.canAttack !== false;
      card.statuses = { ...(card.statuses ?? {}) };
      participant.board.push(card);
    }
  });
  ensureParticipantBoardState(match, participant);
  match.lastRowUnlock = { seatId: participant.id, row: requestedRows - 1, turn: match.turnNumber, at: Date.now() };
  pushLocalLog(match, `${participant.name} battlefield stress test seeded to ${requestedRows} rows.`);
  refreshLocalAllAuraStates(match);
  return localSeatBoardState(match, seatId);
}
