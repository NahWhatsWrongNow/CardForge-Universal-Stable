import { cloneState, chooseTurnPlan, getPlannerDebug } from './ai.js';
// Workers run the existing planner, never a second set of combat rules.
export async function planTurnAsync(state, profile) {
  const snapshot = cloneState(state);
  try {
    return await new Promise((resolve, reject) => {
      const worker = new Worker(new URL('./ai_worker.js', import.meta.url), {type:'module'});
      const finish = (error, value) => { clearTimeout(timer); worker.terminate(); error ? reject(error) : resolve(value); };
      const timer = setTimeout(() => finish(new Error('Planner exceeded time budget')), 2000);
      worker.onerror = event => { event.preventDefault(); finish(new Error(event.message)); };
      worker.onmessage = ({data}) => finish(data.error ? new Error(data.error) : null, data);
      try { worker.postMessage({state:snapshot,profile,memory:getPlannerDebug(profile?.id ?? profile?.name)}); } catch (error) { finish(error); }
    });
  } catch (error) {
    // A bounded lightweight profile retains legal attacks if workers are unavailable.
    console.warn('AI worker unavailable; using bounded planner.', error.message);
    return {plan:chooseTurnPlan(snapshot, {...profile, difficultyBand:'Easy', level:1}),debug:null};
  }
}
