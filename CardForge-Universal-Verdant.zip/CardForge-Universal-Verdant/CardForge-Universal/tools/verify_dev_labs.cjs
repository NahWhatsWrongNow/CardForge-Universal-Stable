const path = require('node:path');
const fs = require('node:fs');
const { chromium } = require('C:/Users/jadon/.codex/skills/develop-web-game/scripts/node_modules/playwright');

(async () => {
  const output = path.resolve('output/dev-runtime-labs');
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1980, height: 1080 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
  page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });

  await page.goto('http://127.0.0.1:8137/index.html', { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.click('#open-dev-wip-ui-main-btn');
  await page.waitForSelector('#dev-wip-ui-modal:not(.hidden)');
  await page.waitForSelector('[data-dev-wip-action="ai-debug-battle"]');
  await page.waitForTimeout(650);
  await page.screenshot({ path: path.join(output, '01-runtime-labs.png') });
  await Promise.all([
    page.waitForURL(/game\/index\.html/, { waitUntil: 'domcontentloaded' }),
    page.click('[data-dev-wip-action="ai-debug-battle"]'),
  ]);
  await page.waitForSelector('#app:not(.hidden)', { timeout: 20000 });
  await page.waitForTimeout(800);
  const opening = JSON.parse(await page.evaluate(() => window.render_game_to_text()));
  const foundation = JSON.parse(fs.readFileSync(path.resolve('packs/concordant_foundations.json'), 'utf8'));
  const rookNames = new Set(foundation.cards.filter((card) => card.echoArchive === 'Frontier Doctrine').map((card) => card.name));
  const playerArchiveLoaded = opening.player.hand.every((card) => rookNames.has(card.name));
  await page.click('#end-turn');
  await page.waitForFunction(() => {
    const state = JSON.parse(window.render_game_to_text());
    return state.turn === 'player' && state.mana.max >= 6;
  }, null, { timeout: 15000 });
  const audit = await page.evaluate(() => window.__cardforgeDebug.getFairnessAudit());
  const visiblePanels = await page.locator('#dev-suite .dev-panel').count();
  await page.screenshot({ path: path.join(output, '02-ai-fairness-battle.png') });
  const expansePage = await browser.newPage({ viewport: { width: 1980, height: 1080 }, deviceScaleFactor: 1 });
  expansePage.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
  expansePage.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
  await expansePage.goto('http://127.0.0.1:8137/index.html', { waitUntil: 'domcontentloaded' });
  await expansePage.click('#open-dev-wip-ui-main-btn');
  await expansePage.waitForSelector('#dev-wip-ui-modal:not(.hidden)');
  await Promise.all([
    expansePage.waitForURL(/game\/index\.html/, { waitUntil: 'domcontentloaded' }),
    expansePage.click('[data-dev-wip-action="expanse-debug-battle"]'),
  ]);
  await expansePage.waitForSelector('#app:not(.hidden)', { timeout: 20000 });
  await expansePage.waitForFunction(() => JSON.parse(window.render_game_to_text()).expanse.columns === 6);
  const expanseState = JSON.parse(await expansePage.evaluate(() => window.render_game_to_text()));
  await expansePage.screenshot({ path: path.join(output, '03-expanse-lab.png') });
  const summary = {
    opponent: opening.ai.profile,
    archiveSize: opening.enemy.archiveCount + opening.enemy.handCount,
    informationPolicy: opening.ai.informationPolicy,
    playerArchiveLoaded,
    auditEntries: audit.length,
    visiblePanels,
    expanseColumns: expanseState.expanse.columns,
    expanseUnits: expanseState.player.board.length,
    errors,
  };
  fs.writeFileSync(path.join(output, 'summary.json'), JSON.stringify(summary, null, 2));
  await browser.close();
  if (errors.length) throw new Error(errors.join('\n'));
  if (opening.ai.profile !== 'Agony' || summary.archiveSize !== 100) throw new Error(`Wrong debug opponent/archive: ${JSON.stringify(summary)}`);
  if (!playerArchiveLoaded) throw new Error(`Debug player Archive fallback detected: ${JSON.stringify(opening.player.hand)}`);
  if (opening.ai.informationPolicy.opponentHandVisible || opening.ai.informationPolicy.opponentArchiveOrderVisible) throw new Error('AI information firewall is open.');
  if (audit.length < 2 || visiblePanels < 3) throw new Error(`Fairness diagnostics missing: ${JSON.stringify(summary)}`);
  if (expanseState.expanse.columns !== 6 || expanseState.player.board.length !== 6) throw new Error(`Expanse lab failed: ${JSON.stringify(summary)}`);
  console.log(JSON.stringify(summary));
  process.exit(0);
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
