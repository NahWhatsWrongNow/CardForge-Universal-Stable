const path = require('node:path');
const fs = require('node:fs');
const { chromium } = require('C:/Users/jadon/.codex/skills/develop-web-game/scripts/node_modules/playwright');

(async () => {
  const output = path.resolve('output/convergence-runtime');
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
  page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
  await page.goto('http://127.0.0.1:8137/index.html', { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => {
    localStorage.clear();
    localStorage.setItem('cardforge.profile.v1', JSON.stringify({ starterDeckId: 'rook-teaching-archive', starterDefenseDeckId: 'rook-teaching-archive' }));
    localStorage.setItem('cardforge.match.opponent.v1', 'rook');
    localStorage.setItem('cardforge.match.context.v1', JSON.stringify({
      aiProfileId: 'rook', modeModel: 'duel', battleType: 'wielder_duel', rulesetId: 'wielder-duel',
      rulesetName: 'Rook Teaching Convergence', deckSize: 40, threatDeckSize: 40, maxCopiesPerCard: 4,
      startingMana: 1, startingHand: 5, enableResponseWindows: true, metadata: { foundationStage: 'rook_tutorial' },
    }));
  });
  await page.goto('http://127.0.0.1:8137/game/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('#app:not(.hidden)', { timeout: 20000 });
  await page.waitForTimeout(900);
  await page.screenshot({ path: path.join(output, '01-rook-runtime.png'), fullPage: false });
  const before = JSON.parse(await page.evaluate(() => window.render_game_to_text()));
  await page.click('#end-turn');
  await page.waitForFunction(() => {
    const state = JSON.parse(window.render_game_to_text());
    return state.turn === 'player' && state.mana.max >= 2;
  }, null, { timeout: 12000 });
  await page.waitForTimeout(500);
  const after = JSON.parse(await page.evaluate(() => window.render_game_to_text()));
  await page.screenshot({ path: path.join(output, '02-after-rook-turn.png'), fullPage: false });
  const expanse = await page.evaluate(() => ({
    label: document.querySelector('#expanse-size')?.textContent,
    columns: getComputedStyle(document.querySelector('#board')).getPropertyValue('--expanse-columns').trim(),
    slotCount: document.querySelectorAll('.lane .board-slot').length,
    loadingVisible: !document.querySelector('#boot-loading')?.classList.contains('hidden'),
  }));
  const seededIds = await page.evaluate(() => window.__cardforgeDebug.seedExpanse('player', 6).ids);
  await page.waitForFunction(() => JSON.parse(window.render_game_to_text()).expanse.columns === 6);
  const expanded = JSON.parse(await page.evaluate(() => window.render_game_to_text())).expanse;
  const stableIds = await page.evaluate(() => window.__cardforgeDebug.seedExpanse ? document.querySelectorAll('#player-front-row .minion, #player-back-row .minion').length : -1);
  const summary = { before, after, expanse, expanded, seededIds, stableIds, errors };
  fs.writeFileSync(path.join(output, 'summary.json'), JSON.stringify(summary, null, 2));
  await browser.close();
  if (errors.length) throw new Error(errors.join('\n'));
  if (before.player.deck !== 35 || before.ai.profile !== 'Rook') throw new Error(`Unexpected opening state: ${JSON.stringify(before)}`);
  if (after.mana.max !== 2 || after.turn !== 'player') throw new Error(`Mana/turn progression failed: ${JSON.stringify(after)}`);
  if (expanse.label.trim() !== '2 x 4' || expanse.slotCount !== 16 || expanse.loadingVisible) throw new Error(`Expanse/runtime failed: ${JSON.stringify(expanse)}`);
  if (expanded.columns !== 6 || expanded.slotsPerSide !== 12 || stableIds !== 6) throw new Error(`Expanse expansion failed: ${JSON.stringify({ expanded, stableIds })}`);
  console.log(JSON.stringify({ ai: before.ai.profile, openingDeck: before.player.deck + before.player.hand.length, manaAfterRound: after.mana, expanse, expanded }));
  process.exit(0);
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
