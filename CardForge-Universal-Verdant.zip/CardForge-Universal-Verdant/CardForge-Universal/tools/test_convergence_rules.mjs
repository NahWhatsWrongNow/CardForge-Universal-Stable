import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildAiPublicSnapshot, calculateEffectiveCost, createConvergenceRulesEngine } from '../game/engine/convergence_rules.js';

const state = {
  mana: 3,
  maxMana: 3,
  playerTemporaryMana: 0,
  enemyMana: 2,
  enemyMaxMana: 2,
  enemyTemporaryMana: 0,
  hand: [{ id: 'secret-player-card', cost: 9 }],
  playerDeck: [{ id: 'secret-top-card' }, { id: 'secret-second-card' }],
  enemyHand: [{ id: 'known-ai-card', cost: 2 }],
  enemyDeck: [{ id: 'known-ai-draw' }],
  playerMinions: [{ id: 'public-player-unit', attack: 3, health: 3 }],
  enemyMinions: [],
};

const rules = createConvergenceRulesEngine(state);
rules.beginManaStep('player');
assert.equal(state.maxMana, 4, 'permanent mana increases without a cap');
rules.gainTemporaryMana('player', 3);
assert.equal(state.mana, 7);
assert.equal(state.playerTemporaryMana, 3);
rules.spendMana('player', 2);
assert.equal(state.playerTemporaryMana, 1, 'temporary mana is spent first');
rules.expireTemporaryMana('player');
assert.equal(state.mana, 4);
assert.equal(state.playerTemporaryMana, 0);

assert.equal(calculateEffectiveCost({ cost: 7 }, 20), 1, 'normal reductions stop at one');
assert.equal(calculateEffectiveCost({ cost: 7, text: 'This may cost 0.' }, 20), 0, 'explicit free-cast text is honored');

const snapshot = buildAiPublicSnapshot(state, 'enemy');
assert.equal(snapshot.enemyHand[0].id, 'known-ai-card');
assert.equal(snapshot.enemyDeck[0].id, 'known-ai-draw');
assert.equal(snapshot.hand[0].hidden, true);
assert.equal(snapshot.playerDeck[0].hidden, true);
assert.equal(JSON.stringify(snapshot).includes('secret-player-card'), false, 'AI snapshot cannot leak opposing hand contents');
assert.equal(JSON.stringify(snapshot).includes('secret-top-card'), false, 'AI snapshot cannot leak opposing Archive order');

const cards = JSON.parse(fs.readFileSync(new URL('../packs/concordant_foundations.json', import.meta.url), 'utf8')).cards;
const archives = JSON.parse(fs.readFileSync(new URL('../game/deck_packs/concordant_archives.json', import.meta.url), 'utf8')).decks;
assert.equal(cards.length, 225);
for (const id of ['frontier-doctrine', 'lumen-bastion-sol', 'pyre-cinder-maw', 'umbra-grave-whispers', 'verdant-worldroot-choir', 'aether-glass-horizon', 'agony-red-wake']) {
  const archive = archives.find((entry) => entry.id === id);
  assert.ok(archive, `${id} exists`);
  assert.equal(archive.entries.reduce((sum, entry) => sum + entry.count, 0), 100, `${id} contains exactly 100 Echoes`);
}

console.log('Convergence rules and foundation content checks passed.');
