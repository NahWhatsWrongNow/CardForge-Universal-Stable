const path = require('node:path');
const fs = require('node:fs');
const { chromium } = require('C:/Users/jadon/.codex/skills/develop-web-game/scripts/node_modules/playwright');

(async () => {
  const output = path.resolve('output/foundation-ui');
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
  page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });

  await page.goto('http://127.0.0.1:8137/index.html', { waitUntil: 'networkidle' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.screenshot({ path: path.join(output, '01-main-menu.png'), fullPage: false });
  await page.click('#new-game-btn');
  await page.click('#confirm-new-game-btn');
  await page.waitForSelector('#foundation-campaign:not(.hidden)');
  await page.waitForTimeout(650);
  await page.screenshot({ path: path.join(output, '02-opening.png'), fullPage: false });

  for (let index = 0; index < 3; index += 1) await page.click('[data-foundation-continue]');
  await page.click('[data-foundation-response="2"]');
  await page.click('[data-foundation-continue]');
  await page.waitForTimeout(650);
  await page.screenshot({ path: path.join(output, '03-rook-briefing.png'), fullPage: false });

  await page.evaluate(() => {
    const foundation = JSON.parse(localStorage.getItem('cardforge.foundation.campaign.v1'));
    localStorage.setItem('cardforge.foundation.campaign.v1', JSON.stringify({ ...foundation, phase: 'rook_tutorial' }));
    localStorage.setItem('cardforge.match.result.v1', JSON.stringify({
      result: 'win', opponentId: 'rook', metadata: { foundationStage: 'rook_tutorial' },
    }));
  });
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForSelector('.foundation-vault-ring');
  await page.waitForTimeout(500);
  await page.screenshot({ path: path.join(output, '04-vaults.png'), fullPage: false });
  await page.click('[data-foundation-vault="lumen"]');
  await page.screenshot({ path: path.join(output, '05-vault-inspect.png'), fullPage: false });
  await page.click('[data-foundation-inspect-cards]');
  await page.screenshot({ path: path.join(output, '06-vault-cards.png'), fullPage: false });

  const summary = await page.evaluate(() => ({
    phase: JSON.parse(localStorage.getItem('cardforge.foundation.campaign.v1') || '{}').phase,
    vaultCount: document.querySelectorAll('[data-foundation-vault]').length,
    designCount: document.querySelectorAll('[data-foundation-card-list] article').length,
    title: document.querySelector('.foundation-vault-inspect h2')?.textContent,
  }));
  fs.writeFileSync(path.join(output, 'summary.json'), JSON.stringify({ summary, errors }, null, 2));
  await browser.close();
  if (errors.length) throw new Error(errors.join('\n'));
  if (summary.vaultCount !== 5 || summary.designCount !== 25) throw new Error(`Unexpected foundation UI counts: ${JSON.stringify(summary)}`);
  console.log(JSON.stringify(summary));
  process.exit(0);
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
