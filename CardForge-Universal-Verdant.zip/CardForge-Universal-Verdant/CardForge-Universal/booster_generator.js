(function(global) {
  'use strict';
  const ELEMENTS = ['fire','water','earth','storm','light','shadow'];
  const NAMES = {fire:'Ember',water:'Tide',earth:'Stone',storm:'Volt',light:'Dawn',shadow:'Dusk'};
  const ROLES = ['Vanguard','Sentinel','Runner','Adept'];
  const pick = (list, rng) => list[Math.min(list.length - 1, Math.floor(rng() * list.length))];
  const hash = text => { let h = 2166136261; for (const c of text) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return (h >>> 0).toString(36); };
  const PRODUCT = Object.freeze({id:'random-booster', name:'Random Booster', price:180, count:15});

  function generate(profile, catalog, rng = Math.random) {
    const owned = new Map(ELEMENTS.map(e => [e,0]));
    for (const card of catalog) if (owned.has(card.element)) owned.set(card.element, owned.get(card.element) + Number(profile.collection?.[card.id] || 0));
    const lowest = Math.min(...owned.values());
    const focus = pick(ELEMENTS.filter(e => owned.get(e) === lowest), rng);
    const pulls = [];
    const slots = [...Array(10).fill('common'), ...Array(3).fill('uncommon'), rng() < .125 ? 'mythic' : 'rare', 'resource'];
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      const rarity = slot === 'mythic' ? 'legendary' : slot === 'resource' ? 'common' : slot;
      const element = i < 3 ? focus : pick(ELEMENTS, rng);
      const role = pick(ROLES, rng);
      const cost = 1 + Math.floor(rng() * 6);
      const grade = slot === 'mythic' ? 2 : slot === 'rare' ? 1 : 0;
      const type = slot === 'resource' ? 'field' : i % 4 === 3 ? 'spell' : 'minion';
      let card = {name:`${NAMES[element]} ${role}`, type, rarity, cost, manaCost:cost, element,
        race:element === 'earth' ? 'beast' : 'human', tags:['random-booster',element],
        packSource:'random-booster', collectionName:'Random Booster', generated:true,
        generationMeta:{version:1, slot, budget:2*cost+1+grade, focus}, boosterRarity:slot};
      if (type === 'minion') {
        const budget = 2 * cost + 1 + grade;
        card.attack = Math.max(1, Math.min(cost + (role === 'Vanguard' ? 1 : -1), budget-1));
        card.health = budget - card.attack;
        card.def = 0;
        card.text = '';
        if (role === 'Sentinel' && cost >= 2) { card.taunt = true; card.health -= 1; card.text = 'Guard.'; }
        if (role === 'Runner' && cost >= 3) { card.charge = true; card.attack = Math.max(1,card.attack-1); card.health -= 1; card.text = 'Charge.'; }
      } else if (type === 'spell') {
        const action = pick(['dealDamage','heal','buffAttack','buffHealth'],rng);
        const amount = action === 'dealDamage' ? cost + grade : Math.max(1, Math.ceil(cost / 2) + grade);
        card.name = `${NAMES[element]} ${({dealDamage:'Lance',heal:'Restoration',buffAttack:'Battlecall',buffHealth:'Ward'})[action]}`;
        card.effect = {action,amount};
        card.text = ({dealDamage:`Deal ${amount} damage to an enemy.`,heal:`Restore ${amount} health to an ally.`,buffAttack:`Give an allied minion +${amount} attack.`,buffHealth:`Give an allied minion +${amount} health.`})[action];
      } else {
        card.name = `${NAMES[element]} Conduit`;
        card.cost = card.manaCost = 3;
        card.effect = {firstSpellDiscount:1};
        card.text = 'Mana Field: your first spell each turn costs 1 less.';
        card.generationMeta.budget = 7;
      }
      // Identical rules share identity, so duplicates stack instead of bloating saves.
      card.id = `rb1-${hash(JSON.stringify([card.name,card.type,card.rarity,card.element,card.cost,card.attack,card.health,card.text]))}`;
      pulls.push(card);
    }
    return {pulls, focus};
  }

  function grant(profile, cards, productId) {
    profile.collection ||= {};
    profile.cardAcquiredAt ||= {};
    const reveal = cards.map(card => {
      const isNew = Number(profile.collection[card.id] || 0) === 0;
      profile.collection[card.id] = Number(profile.collection[card.id] || 0) + 1;
      if (isNew) profile.cardAcquiredAt[card.id] = Date.now();
      return {card,isNew,copies:profile.collection[card.id]};
    });
    profile.stats ||= {};
    const packs = profile.stats.packs ||= {};
    profile.stats.packsOpened = Number(profile.stats.packsOpened || 0)+1;
    packs.openedTotal = Number(packs.openedTotal || 0)+1;
    for (const key of ['byPack','cardsByPack','rarityPulls','uniqueByPack']) packs[key] ||= {};
    packs.byPack[productId] = Number(packs.byPack[productId] || 0)+1;
    packs.cardsByPack[productId] = Number(packs.cardsByPack[productId] || 0)+cards.length;
    for(const card of cards) {
      packs.rarityPulls[card.rarity] = Number(packs.rarityPulls[card.rarity] || 0)+1;
      if(card.rarity === 'legendary') packs.legendaryPulls = Number(packs.legendaryPulls || 0)+1;
    }
    profile.questProgress ||= {};
    profile.questProgress.packsOpened = Number(profile.questProgress.packsOpened || 0)+1;
    return reveal;
  }

  function buy(profile, catalog, rng = Math.random) {
    if (Number(profile.economy?.gold || 0) < PRODUCT.price) throw new Error('Not enough gold.');
    const result = generate(profile,catalog,rng);
    profile.customPackDefs ||= [];
    let pack = profile.customPackDefs.find(p => p.id === PRODUCT.id);
    if (!pack) { pack = {id:PRODUCT.id,name:PRODUCT.name,cards:[]}; profile.customPackDefs.push(pack); }
    const known = new Map(pack.cards.map(c => [c.id,c]));
    result.pulls.forEach(c => known.set(c.id,c));
    pack.cards = [...known.values()];
    profile.economy.gold -= PRODUCT.price;
    result.reveal = grant(profile,result.pulls,PRODUCT.id);
    profile.stats.packs.uniqueByPack[PRODUCT.id] = pack.cards.filter(c => profile.collection[c.id] > 0).length;
    return result;
  }
  global.CardForgeBoosters = {PRODUCT, generate, grant, buy};
})(window);
