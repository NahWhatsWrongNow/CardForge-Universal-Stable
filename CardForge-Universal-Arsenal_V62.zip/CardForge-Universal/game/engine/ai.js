import { uid } from '../../core/utils.js';
import {
  collectCardFamilies,
  extractCardRaces,
  getFamiliarity,
  hasFamilyTag,
  normalizeFamilyToken,
  RACE_LIBRARY,
} from './race_logic.js';
import {
  AI_ARCHETYPES,
  VALID_AI_ARCHETYPES,
  deckAffinityScore,
  difficultyConfig,
  enrichAiProfile,
  thinkingLinesFor,
} from './ai_personalities.js';

const MAX_LANE_SIZE = 8;
const WIN_SCORE = 100000;
const ACTION_TRACE_PREFIX = 'neural';
const FORMATION_SWITCH_MARGIN = 1.35;
const ROLE_CACHE = new Map();
const NCk_CACHE = new Map();
const plannerState = new Map();

function pickRandom(list = []) {
  if (list.length === 0) return null;
  return list[Math.floor(Math.random() * list.length)];
}

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

function relu(v) {
  return Math.max(0, v);
}

function dot(a = [], b = []) {
  const n = Math.min(a.length, b.length);
  let sum = 0;
  for (let i = 0; i < n; i += 1) sum += (a[i] ?? 0) * (b[i] ?? 0);
  return sum;
}

function dense(input = [], matrix = [], bias = []) {
  return matrix.map((row, idx) => dot(input, row) + (bias[idx] ?? 0));
}

function nCk(n, k) {
  const nn = Math.max(0, Math.floor(n));
  const kk = Math.max(0, Math.floor(k));
  if (kk < 0 || kk > nn) return 0;
  if (kk === 0 || kk === nn) return 1;
  const key = `${nn}:${kk}`;
  if (NCk_CACHE.has(key)) return NCk_CACHE.get(key);
  const useK = Math.min(kk, nn - kk);
  let result = 1;
  for (let i = 1; i <= useK; i += 1) {
    result = (result * (nn - useK + i)) / i;
  }
  NCk_CACHE.set(key, result);
  return result;
}

function cardsSeenByTurn(turn, startHand = 5, drawRate = 1, goingFirst = true) {
  const t = Math.max(1, Math.floor(turn));
  const opening = Math.max(0, Math.floor(startHand));
  const rate = Math.max(0, Math.floor(drawRate));
  const bonus = goingFirst ? 0 : rate;
  return opening + bonus + Math.max(0, t - 1) * rate;
}

function pAtLeastOne(N, K, n) {
  const deck = Math.max(1, Math.floor(N));
  const copies = clamp(Math.floor(K), 0, deck);
  const seen = clamp(Math.floor(n), 0, deck);
  if (copies <= 0 || seen <= 0) return 0;
  const miss = nCk(deck - copies, seen) / Math.max(1, nCk(deck, seen));
  return clamp(1 - miss, 0, 1);
}

function pAtLeastK(N, K, n, k) {
  const deck = Math.max(1, Math.floor(N));
  const copies = clamp(Math.floor(K), 0, deck);
  const seen = clamp(Math.floor(n), 0, deck);
  const want = clamp(Math.floor(k), 0, seen);
  if (copies <= 0 || seen <= 0) return 0;
  let sum = 0;
  for (let x = want; x <= Math.min(copies, seen); x += 1) {
    const num = nCk(copies, x) * nCk(deck - copies, seen - x);
    const den = Math.max(1, nCk(deck, seen));
    sum += num / den;
  }
  return clamp(sum, 0, 1);
}

function pBothAtLeastOne(N, KA, KB, n, overlap = 0) {
  const deck = Math.max(1, Math.floor(N));
  const countA = clamp(Math.floor(KA), 0, deck);
  const countB = clamp(Math.floor(KB), 0, deck);
  const countOverlap = clamp(Math.floor(overlap), 0, Math.min(countA, countB));
  const seen = clamp(Math.floor(n), 0, deck);
  if (countA <= 0 || countB <= 0 || seen <= 0) return 0;
  const union = clamp(countA + countB - countOverlap, 0, deck);
  if (union <= 0) return 0;
  const p0A = nCk(deck - countA, seen) / Math.max(1, nCk(deck, seen));
  const p0B = nCk(deck - countB, seen) / Math.max(1, nCk(deck, seen));
  const p0AB = nCk(deck - union, seen) / Math.max(1, nCk(deck, seen));
  return clamp(1 - p0A - p0B + p0AB, 0, 1);
}

function normalizedAction(effect = {}) {
  return String(effect.action ?? '').toLowerCase();
}

function roleHintFromTags(card = {}) {
  const set = new Set((card.tags ?? []).map((tag) => String(tag).toLowerCase()));
  const text = `${card.name ?? ''} ${collectCardFamilies(card).join(' ')} ${card.element ?? ''} ${card.text ?? ''}`.toLowerCase();
  const action = normalizedAction(card.effect ?? card.ability ?? {});
  const addIf = (condition, tag) => { if (condition) set.add(tag); };

  addIf(card.taunt || card.guard || card.seamguard, 'taunt');
  addIf(card.type === 'spell' && (action.includes('draw') || action.includes('mana') || action.includes('tax')), 'engine');
  addIf(card.attack >= 5 || card.trueDamage || card.pierce >= 2, 'threat');
  addIf(card.type === 'spell' && (action.includes('shatter') || action.includes('silence') || action.includes('counter') || action.includes('interrupt') || card.damage >= 4), 'reactivespell');
  addIf(card.type === 'spell' && (action.includes('damage') || action.includes('remove') || action.includes('sentence')), 'removal');
  addIf(action.includes('summon') || action.includes('token') || text.includes('sapling') || text.includes('echo') || text.includes('swarm'), 'tokengenerator');
  addIf(action.includes('splice') || action.includes('compress') || action.includes('fuse') || action.includes('graft'), 'compressor');
  addIf(action.includes('heal') || action.includes('buff') || action.includes('shield') || action.includes('stitch'), 'support');
  addIf(action.includes('steal') || action.includes('drain') || action.includes('nullmark') || action.includes('timelock') || action.includes('tax'), 'utility');
  addIf(hasFamilyTag(card, 'dragon'), 'dragon');
  addIf(/familiarity/.test(text), 'familiarity');
  addIf(/for every|at least half your board|deck contains only|you control \d+ or more/.test(text), 'tribalpayoff');
  addIf(/whenever you summon a|your [a-z-]+s have|\bfriendly [a-z-]+s?\b/.test(text), 'triballord');

  return set;
}

function laneFor(stateLike, side = 'enemy') {
  return side === 'enemy' ? (stateLike?.enemyMinions ?? []) : (stateLike?.playerMinions ?? []);
}

function deckFor(stateLike, side = 'enemy', profile = null) {
  if (side === 'enemy') return stateLike?.enemyDeck ?? profile?.deck ?? profile?.summons ?? [];
  return stateLike?.playerDeck ?? [];
}

function familyCount(cards = [], family = '') {
  return cards.reduce((sum, card) => sum + (hasFamilyTag(card, family) ? 1 : 0), 0);
}

function familyRatio(cards = [], family = '') {
  if (!cards.length) return 0;
  return familyCount(cards, family) / Math.max(1, cards.length);
}

function familyState(side = 'enemy', stateLike = null, profile = null) {
  return {
    board: laneFor(stateLike, side),
    deck: deckFor(stateLike, side, profile),
    hand: side === 'enemy' ? (stateLike?.enemyHand ?? []) : (stateLike?.hand ?? []),
    opponentBoard: laneFor(stateLike, side === 'enemy' ? 'player' : 'enemy'),
    familiarity: stateLike?.familiarity?.[side] ?? {},
    playedFamilies: stateLike?.turnFlags?.[side]?.playedFamilies ?? {},
    diedFamilies: stateLike?.turnFlags?.[side]?.diedFamilies ?? {},
  };
}

function thresholdScore(count = 0, threshold = 1, weight = 1.5) {
  if (threshold <= 0) return weight;
  if (count >= threshold) return weight + ((count - threshold) * 0.45);
  if (count === threshold - 1) return weight * 0.55;
  return 0;
}

function tribalTextScore(card = {}, stateLike = null, profile = null, side = 'enemy') {
  const context = familyState(side, stateLike, profile);
  const text = `${card.name ?? ''} ${card.text ?? ''}`.toLowerCase();
  let score = 0;

  collectCardFamilies(card).forEach((family) => {
    score += familyCount(context.board, family) * 0.35;
    score += familyCount(context.deck, family) * 0.08;
    score += getFamiliarity(context.familiarity, family) * 0.5;
  });

  if (hasFamilyTag(card, 'dragon')) {
    score += familyCount(context.board, 'dragon') * 0.9;
    score += familyCount(context.deck, 'dragon') * 0.2;
    if (card.flying) score += 1.1;
    if (/breath|fire|ember|flame/.test(text)) score += 0.8;
  }

  RACE_LIBRARY.map((entry) => entry.id).forEach((family) => {
    const ownBoard = familyCount(context.board, family);
    const ownDeck = familyCount(context.deck, family);
    const ownHand = familyCount(context.hand, family);
    const enemyBoard = familyCount(context.opponentBoard, family);
    const fam = getFamiliarity(context.familiarity, family);

    if (new RegExp(`for every ${family}s? (you control|on your board)`).test(text)) score += ownBoard * 1.05;
    if (new RegExp(`for every ${family}s? in your hand`).test(text)) score += ownHand * 0.75;
    if (new RegExp(`for every ${family}s? in your deck`).test(text)) score += ownDeck * 0.45;

    const boardThreshold = text.match(new RegExp(`if you control (\\d+) or more ${family}s?`));
    if (boardThreshold) score += thresholdScore(ownBoard, Number(boardThreshold[1] ?? 0), 2.2);

    const handThreshold = text.match(new RegExp(`if you have (\\d+) or more ${family}s? in your hand`));
    if (handThreshold) score += thresholdScore(ownHand, Number(handThreshold[1] ?? 0), 1.75);

    const deckOnly = new RegExp(`deck contains only ${family}`).test(text);
    if (deckOnly && context.deck.length > 0 && familyRatio(context.deck, family) >= 0.92) score += 3.2;
    const pairedDeckOnly = new RegExp(`deck contains only ${family} and ([a-z-]+)`).exec(text);
    if (pairedDeckOnly && context.deck.length > 0) {
      const other = normalizeFamilyToken(pairedDeckOnly[1] ?? '');
      if (other) {
        const allowedRatio = context.deck.filter((entry) => hasFamilyTag(entry, family) || hasFamilyTag(entry, other)).length / Math.max(1, context.deck.length);
        if (allowedRatio >= 0.92) score += 3.5;
      }
    }

    if (new RegExp(`at least half your board is ${family}`).test(text) && familyRatio(context.board, family) >= 0.5) score += 2.8;
    if (new RegExp(`whenever you summon a ${family}|when you play a ${family}`).test(text)) score += ownDeck * 0.22 + ownBoard * 0.45;
    if (new RegExp(`your ${family}s? have|friendly ${family}s?`).test(text)) score += ownBoard * 0.7;
    if (new RegExp(`${family} familiarity (\\d+)`).test(text)) {
      const threshold = Number(text.match(new RegExp(`${family} familiarity (\\d+)`))?.[1] ?? 0);
      score += thresholdScore(fam, threshold, 2);
    }
    if (new RegExp(`gain \\d+ ${family} familiarity|whenever .*${family}`).test(text) && ownDeck > 0) score += 0.8 + ownBoard * 0.15;

    if (new RegExp(`enemy ${family}s?|destroy (an? )?${family}|against ${family}|all ${family}s?`).test(text)) score += enemyBoard * 0.9;
    if (new RegExp(`${family} died this turn`).test(text)) score += Math.max(0, Number(context.diedFamilies[family] ?? 0)) * 0.9;
    if (new RegExp(`${family} was played this turn|played a ${family} this turn`).test(text)) score += Math.max(0, Number(context.playedFamilies[family] ?? 0)) * 0.8;
  });

  return score;
}

function deriveRoleTags(card = {}) {
  const cacheKey = card.id ?? `${card.name ?? 'unknown'}|${card.type ?? 'none'}|${card.attack ?? 0}|${card.health ?? 0}`;
  if (ROLE_CACHE.has(cacheKey)) return ROLE_CACHE.get(cacheKey);

  const tags = roleHintFromTags(card);
  const isSpell = card.type === 'spell';
  const role = (() => {
    if (tags.has('taunt')) return 'T';
    if (tags.has('engine')) return 'E';
    if (tags.has('threat')) return 'D';
    if (tags.has('tokengenerator')) return 'X';
    if (tags.has('support') || tags.has('utility') || isSpell) return 'S';
    return card.attack >= 3 ? 'D' : 'S';
  })();

  const normalized = {
    role,
    normalizedTags: {
      taunt: tags.has('taunt'),
      engine: tags.has('engine'),
      threat: tags.has('threat'),
      support: tags.has('support'),
      tokenGenerator: tags.has('tokengenerator'),
      compressor: tags.has('compressor'),
      reactiveSpell: tags.has('reactivespell'),
      removal: tags.has('removal'),
      utility: tags.has('utility'),
    },
  };

  ROLE_CACHE.set(cacheKey, normalized);
  return normalized;
}

function normalizeCardType(card = {}) {
  const t = String(card.type ?? 'minion').toLowerCase();
  if (t === 'creature' || t === 'token') return 'minion';
  if (t === 'artifact') return 'relic';
  if (t === 'fortress' || t === 'turret' || t === 'reactor' || t === 'structure') return 'barricade';
  return t;
}

function isSpellLike(card = {}) {
  const type = normalizeCardType(card);
  return type === 'spell' || type === 'instant' || type === 'sorcery' || type === 'aura' || type === 'trap';
}

function availableMana(stateLike, side = 'enemy') {
  if (side === 'enemy') return Math.max(0, toNumber(stateLike?.enemyMana ?? stateLike?.maxMana ?? 0));
  return Math.max(0, toNumber(stateLike?.mana ?? 0));
}

function effectiveAiCost(card = {}, stateLike, side = 'enemy') {
  return Math.max(0, toNumber(card.cost ?? 0) - Math.max(0, toNumber(card.costOffset ?? 0)));
}

function threatScore(card = {}) {
  const attack = toNumber(card.attack ?? 0);
  const health = toNumber(card.health ?? card.maxHealth ?? 0);
  const def = toNumber(card.baseDef ?? card.def ?? 0);
  return attack * 1.45 + health * 1.2 + def * 0.9 + (card.taunt ? 1.2 : 0) + (card.trueDamage ? 2.4 : 0) + (card.charge ? 1.5 : 0);
}

function dangerScore(card = {}) {
  const text = `${card.name ?? ''} ${card.text ?? ''} ${(card.tags ?? []).join(' ')}`.toLowerCase();
  let score = threatScore(card);
  if (/draw|discover|costs \(\d+\) less|your .* have \+\d+/.test(text)) score += 2.1;
  if (/destroy|silence|return .* hand|freeze|counter/.test(text)) score += 2.5;
  if (/legendary|sovereign|matriarch|colossus/.test(text) || String(card.rarity ?? '').toLowerCase() === 'legendary') score += 1.8;
  if (card.stealth || card.statuses?.stealth) score += 1.4;
  return score;
}

const FORMATIONS = [
  {
    id: 'center-bastion',
    name: 'Center Bastion',
    description: 'Stable center wall protecting engines through controlled value.',
    pattern: ['D', 'S', 'T', 'T', 'E', 'E', 'S', 'D'],
    transitionRules: ['prefer-from-stagger', 'prefer-to-trap-funnel'],
  },
  {
    id: 'edge-pocket',
    name: 'Edge Pocket',
    description: 'Engines at edges with tank/support pockets guarding approach lines.',
    pattern: ['E', 'T', 'S', 'D', 'D', 'S', 'T', 'E'],
    transitionRules: ['prefer-from-center-bastion'],
  },
  {
    id: 'stagger-screen',
    name: 'Stagger Screen',
    description: 'Alternating occupancy to reduce adjacency punishment and overcommitment.',
    pattern: ['T', '.', 'D', '.', 'E', '.', 'D', '.'],
    transitionRules: ['prefer-from-spearhead'],
  },
  {
    id: 'spearhead',
    name: 'Spearhead',
    description: 'Aggressive center pressure with guard rails on both sides.',
    pattern: ['S', 'T', 'D', 'D', 'D', 'T', 'S', 'E'],
    transitionRules: ['prefer-from-center-bastion'],
  },
  {
    id: 'flood-to-fuse',
    name: 'Flood to Fuse',
    description: 'Flood tokens early, then compress into efficient threats.',
    pattern: ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
    compressionTarget: ['T', 'D', 'D', 'E', '.', '.', '.', '.'],
    transitionRules: ['prefer-to-center-bastion'],
  },
  {
    id: 'trap-funnel',
    name: 'Trap Funnel',
    description: 'Reactive lanes that bait attacks into punishable lines.',
    pattern: ['.', 'S', 'T', 'X', 'X', 'T', 'S', '.'],
    transitionRules: ['prefer-from-edge-pocket'],
  },
];

function formationById(id) {
  return FORMATIONS.find((formation) => formation.id === id) ?? FORMATIONS[0];
}

function roleCounts(cards = []) {
  const out = {
    taunt: 0,
    engine: 0,
    threat: 0,
    support: 0,
    tokenGenerator: 0,
    compressor: 0,
    reactiveSpell: 0,
    removal: 0,
    utility: 0,
  };
  cards.forEach((card) => {
    const roles = deriveRoleTags(card).normalizedTags;
    Object.keys(out).forEach((key) => { if (roles[key]) out[key] += 1; });
  });
  return out;
}

function roleOverlapCount(cards = [], roleA, roleB) {
  let overlap = 0;
  cards.forEach((card) => {
    const roles = deriveRoleTags(card).normalizedTags;
    if (roles[roleA] && roles[roleB]) overlap += 1;
  });
  return overlap;
}

function slotPatternFit(minions = [], formation) {
  if (!formation || !formation.pattern) return 0;
  const bySlot = new Map(minions.map((minion) => [minion.slot ?? -1, minion]));
  let score = 0;
  for (let slot = 0; slot < MAX_LANE_SIZE; slot += 1) {
    const expected = formation.pattern[slot] ?? '.';
    const minion = bySlot.get(slot);
    if (!minion) {
      if (expected === '.') score += 0.2;
      continue;
    }
    const role = deriveRoleTags(minion).role;
    if (expected === '.') score -= 0.8;
    else if (role === expected) score += 1.2;
    else score -= 0.25;
  }
  return score;
}

function formationContext(stateLike, profile) {
  const deck = stateLike.enemyDeck?.length ? stateLike.enemyDeck : (profile?.deck ?? []);
  const N = Math.max(1, deck.length || 30);
  const counts = roleCounts(deck);
  const tokenCompressorOverlap = roleOverlapCount(deck, 'tokenGenerator', 'compressor');
  const seen3 = cardsSeenByTurn(3, 5, 1, true);
  const seen4 = cardsSeenByTurn(4, 5, 1, true);
  const seen5 = cardsSeenByTurn(5, 5, 1, true);
  const probabilities = {
    tauntBy3: pAtLeastOne(N, counts.taunt, seen3),
    engineBy4: pAtLeastOne(N, counts.engine, seen4),
    tokenTwoBy3: pAtLeastK(N, counts.tokenGenerator, seen3, 2),
    compressorBy4: pAtLeastOne(N, counts.compressor, seen4),
    reactiveBy4: pAtLeastOne(N, counts.reactiveSpell, seen4),
    threatBy5: pAtLeastOne(N, counts.threat, seen5),
    tokenAndCompressor: pBothAtLeastOne(N, counts.tokenGenerator, counts.compressor, seen4, tokenCompressorOverlap),
  };

  const centerSlots = [2, 3, 4, 5];
  const opponentCenterPressure = stateLike.playerMinions.some((minion) => centerSlots.includes(minion.slot ?? -1));
  const opponentAdjacencyPunish = stateLike.playerMinions.length >= 5 || stateLike.playerMinions.some((minion) => (minion.allowMultiAttack ?? false));
  const aiUnitCount = stateLike.enemyMinions.length;
  const oppUnitCount = stateLike.playerMinions.length;
  const opponentSlow = oppUnitCount <= 2 && (stateLike.playerHealth ?? 30) >= 20;
  const needsStabilize = (stateLike.enemyHealth ?? 30) <= (stateLike.playerHealth ?? 30) - 6;

  return {
    deckSize: N,
    counts,
    probabilities,
    opponentCenterPressure,
    opponentAdjacencyPunish,
    aiUnitCount,
    oppUnitCount,
    opponentSlow,
    needsStabilize,
  };
}

function scoreFormation(formation, stateLike, profile, context) {
  const p = context.probabilities;
  let score = slotPatternFit(stateLike.enemyMinions, formation);
  let reason = 'baseline-fit';

  if (formation.id === 'center-bastion') {
    score += (p.tauntBy3 * 4.8) + (p.engineBy4 * 4.2) + (context.needsStabilize ? 1.1 : 0);
    reason = 'taunt+engine stabilization';
  } else if (formation.id === 'edge-pocket') {
    score += (p.engineBy4 * 4.4) + (context.opponentCenterPressure ? 2.2 : 0.4);
    reason = 'engine protection from center pressure';
  } else if (formation.id === 'stagger-screen') {
    score += (context.opponentAdjacencyPunish ? 3.5 : 0.2) + (context.aiUnitCount <= 4 ? 1.6 : 0.1);
    reason = 'anti-adjacency and low-commit board';
  } else if (formation.id === 'spearhead') {
    score += (p.threatBy5 * 4.9) + (context.opponentSlow ? 2.4 : 0.2);
    reason = 'high threat density pressure';
  } else if (formation.id === 'flood-to-fuse') {
    score += (p.tokenTwoBy3 * 4.5) + (p.compressorBy4 * 3.9) + (p.tokenAndCompressor * 2.7);
    reason = 'token flood into compression';
  } else if (formation.id === 'trap-funnel') {
    score += (p.reactiveBy4 * 4.3) + (p.tauntBy3 * 2.2) + (context.needsStabilize ? 0.6 : 0);
    reason = 'reactive punish lines';
  }

  if (profile?.strategy === 'control' && (formation.id === 'center-bastion' || formation.id === 'trap-funnel')) score += 1.0;
  if (profile?.strategy === 'aggro' && formation.id === 'spearhead') score += 1.1;
  if (profile?.strategy === 'value' && formation.id === 'edge-pocket') score += 0.8;
  if (profile?.formationBias && Number.isFinite(Number(profile.formationBias[formation.id]))) {
    score += Number(profile.formationBias[formation.id]);
  }

  return { id: formation.id, name: formation.name, score, reason };
}

function chooseFormation(profile, stateLike, persist = false) {
  const context = formationContext(stateLike, profile);
  const scored = FORMATIONS.map((formation) => scoreFormation(formation, stateLike, profile, context))
    .sort((a, b) => b.score - a.score);

  const id = profile?.id ?? profile?.name ?? 'unknown';
  const memory = plannerState.get(id) ?? {};
  let chosen = scored[0];
  if (memory.formationId && memory.formationId !== chosen.id) {
    const prev = scored.find((entry) => entry.id === memory.formationId);
    if (prev && (chosen.score - prev.score) < FORMATION_SWITCH_MARGIN) chosen = prev;
  }

  if (persist) {
    plannerState.set(id, {
      ...(plannerState.get(id) ?? {}),
      formationId: chosen.id,
      formationScores: scored,
      roleCounts: context.counts,
      probabilities: context.probabilities,
      context: {
        opponentCenterPressure: context.opponentCenterPressure,
        opponentAdjacencyPunish: context.opponentAdjacencyPunish,
        aiUnitCount: context.aiUnitCount,
        oppUnitCount: context.oppUnitCount,
        needsStabilize: context.needsStabilize,
      },
      formationReason: chosen.reason,
      slotDecisions: [],
    });
  }

  return { formation: formationById(chosen.id), context, scored };
}

function occupiedSlots(minions = []) {
  return new Set(minions.map((minion) => minion.slot).filter((slot) => Number.isInteger(slot)));
}

function adjacentOccupiedScore(slot, occupied) {
  let score = 0;
  if (occupied.has(slot - 1)) score += 1;
  if (occupied.has(slot + 1)) score += 1;
  return score;
}

function chooseSummonSlot(stateLike, card, formationChoice) {
  const occupied = occupiedSlots(stateLike.enemyMinions);
  const open = [];
  for (let i = 0; i < MAX_LANE_SIZE; i += 1) if (!occupied.has(i)) open.push(i);
  if (!open.length) return { slot: null, reason: 'no-open-slot', score: -999 };

  const role = deriveRoleTags(card).role;
  const pattern = formationChoice.formation.pattern ?? FORMATIONS[0].pattern;
  let best = { slot: open[0], score: -Infinity, reason: 'fallback' };

  for (const slot of open) {
    const expected = pattern[slot] ?? '.';
    let score = 0;
    const reasons = [];

    if (expected === '.') {
      score -= 1.8;
      reasons.push('preserve-empty');
    } else if (expected === role) {
      score += 4.4;
      reasons.push(`role-match:${role}`);
    } else {
      score -= 0.35;
      reasons.push(`role-mismatch:${expected}->${role}`);
    }

    const crowding = adjacentOccupiedScore(slot, occupied);
    if (formationChoice.context.opponentAdjacencyPunish && crowding >= 2) {
      score -= 1.4;
      reasons.push('anti-adjacency');
    } else if (crowding === 0 && role === 'E') {
      score -= 0.3;
      reasons.push('engine-needs-cover');
    }

    if (role === 'S' && (occupied.has(slot - 1) || occupied.has(slot + 1))) {
      score += 0.7;
      reasons.push('support-adjacent');
    }
    if (role === 'T' && (slot === 2 || slot === 3 || slot === 4 || slot === 5)) {
      score += 0.8;
      reasons.push('tank-center-anchor');
    }
    if (formationChoice.formation.id === 'stagger-screen' && crowding > 0) {
      score -= 0.8;
      reasons.push('stagger-spacing');
    }
    if (formationChoice.formation.id === 'edge-pocket' && role === 'E' && (slot === 0 || slot === 7)) {
      score += 1.1;
      reasons.push('edge-engine-pocket');
    }
    if (formationChoice.formation.id === 'spearhead' && role === 'D' && (slot === 3 || slot === 4)) {
      score += 1.2;
      reasons.push('spearhead-center-threat');
    }

    if (score > best.score) best = { slot, score, reason: reasons.join(', ') };
  }

  return best;
}

function cloneMinion(minion) {
  return {
    ...minion,
    statuses: { ...(minion?.statuses ?? {}) },
  };
}

function cloneState(state) {
  return {
    enemyHealth: state.enemyHealth,
    playerHealth: state.playerHealth,
    enemyMinions: (state.enemyMinions ?? []).map(cloneMinion),
    playerMinions: (state.playerMinions ?? []).map(cloneMinion),
    enemyDeck: (state.enemyDeck ?? []).map((card) => ({ ...card })),
    enemyHand: (state.enemyHand ?? []).map((card) => ({ ...card })),
    enemyFields: (state.enemyFields ?? []).map((card) => ({ ...card })),
    enemyRelics: (state.enemyRelics ?? []).map((card) => ({ ...card })),
    enemyBarricades: Array.isArray(state.enemyBarricades) ? state.enemyBarricades.map((entry) => (entry ? { ...entry } : null)) : [],
    enemyMana: toNumber(state.enemyMana ?? state.maxMana ?? 0),
    enemyUsedAttacks: { ...(state.enemyUsedAttacks ?? {}) },
    playerUsedAttacks: { ...(state.playerUsedAttacks ?? {}) },
    familiarity: JSON.parse(JSON.stringify(state.familiarity ?? { enemy: {}, player: {} })),
    turnFlags: JSON.parse(JSON.stringify(state.turnFlags ?? { enemy: {}, player: {} })),
    maxMana: toNumber(state.maxMana ?? 0),
  };
}

function hasTaunt(minions = []) {
  return minions.some((m) => !!m.taunt && (m.health ?? 0) > 0);
}

function attackCap(minion) {
  return minion?.allowMultiAttack ? 99 : 1;
}

function toNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function ensureCombatState(minion) {
  if (!minion) return minion;
  minion.races = extractCardRaces(minion);
  minion.race = minion.races[0] ?? normalizeFamilyToken(minion.race ?? minion.type ?? 'neutral') ?? 'neutral';
  minion.baseDef = Math.max(0, toNumber(minion.baseDef ?? minion.def ?? minion.defenseValue ?? 0));
  minion.pierce = Math.max(0, toNumber(minion.pierce ?? 0));
  minion.trueDamage = !!minion.trueDamage;
  minion.defense = !!minion.defense;
  minion.defenseDurability = Math.max(0, toNumber(minion.defenseDurability ?? (minion.defense ? 2 : 0)));
  minion.baseTaunt = !!(minion.baseTaunt ?? minion.taunt);
  minion.taunt = !!minion.baseTaunt || minion.defense;
  minion.statuses = minion.statuses ?? {};
  return minion;
}

function defenseValue(target, source = {}) {
  const shattered = (target?.statuses?.shatteredTurns ?? 0) > 0;
  const trueDamage = !!source.trueDamage || String(source.damageType ?? '').toLowerCase() === 'true';
  const pierce = Math.max(0, toNumber(source.pierce ?? 0));
  if (trueDamage || shattered) return 0;
  const raw = Math.max(0, toNumber(target?.baseDef ?? target?.def ?? 0) + (target?.defense ? 2 : 0));
  return Math.max(0, raw - pierce);
}

function mitigatedDamage(incoming, target, source = {}) {
  return Math.max(0, toNumber(incoming) - defenseValue(target, source));
}

function sideLane(stateLike, side) {
  return side === 'enemy' ? stateLike.enemyMinions : stateLike.playerMinions;
}

function oppositeLane(stateLike, side) {
  return side === 'enemy' ? stateLike.playerMinions : stateLike.enemyMinions;
}

function usedAttackMap(stateLike, side) {
  if (side === 'enemy') return stateLike.enemyUsedAttacks ?? {};
  return stateLike.playerUsedAttacks ?? {};
}

function canAttack(stateLike, side, minion) {
  if (!minion) return false;
  if ((minion.health ?? 0) <= 0) return false;
  if (minion.defense || minion.summoningSick) return false;
  const used = usedAttackMap(stateLike, side)[minion.id] ?? 0;
  return used < attackCap(minion);
}

function markAttackUsed(stateLike, side, minion) {
  if (!minion) return;
  if (side === 'enemy') stateLike.enemyUsedAttacks[minion.id] = (stateLike.enemyUsedAttacks[minion.id] ?? 0) + 1;
  else stateLike.playerUsedAttacks[minion.id] = (stateLike.playerUsedAttacks[minion.id] ?? 0) + 1;
}

function clearDeadMinions(stateLike) {
  stateLike.enemyMinions = stateLike.enemyMinions.filter((m) => (m.health ?? 0) > 0);
  stateLike.playerMinions = stateLike.playerMinions.filter((m) => (m.health ?? 0) > 0);
}

function availableAttackers(stateLike, side) {
  return sideLane(stateLike, side).filter((m) => canAttack(stateLike, side, m));
}

function rarityBonus(rarity = 'common') {
  const table = {
    common: 0,
    rare: 0.2,
    epic: 0.45,
    legendary: 0.75,
  };
  return table[String(rarity).toLowerCase()] ?? 0;
}

function cardPower(card = {}, stateLike = null, profile = null) {
  const attack = card.attack ?? 0;
  const health = card.health ?? 0;
  const def = toNumber(card.def ?? card.baseDef ?? 0);
  const oppAttack = stateLike?.playerMinions?.reduce((sum, m) => sum + (m.attack ?? 0), 0) ?? 0;
  const enemyPressure = oppAttack / Math.max(1, stateLike?.enemyHealth ?? 1);
  const roleTags = roleHintFromTags(card);

  let score = (attack * 1.45) + (health * 1.25) + (def * 1.7);
  if (card.taunt) score += 1.6 + (enemyPressure * 2.4);
  if (card.charge) score += 2.2;
  if (card.pierce) score += Math.min(3.5, card.pierce * 1.2);
  if (card.trueDamage) score += 3.6;
  if (card.allowMultiAttack) score += 1.8;
  score += rarityBonus(card.rarity) * 1.8;
  if (roleTags.has('dragon')) score += 1.2;
  if (roleTags.has('tribalpayoff')) score += 0.9;
  if (roleTags.has('triballord')) score += 0.8;
  if (roleTags.has('familiarity')) score += 0.7;
  score += tribalTextScore(card, stateLike, profile, 'enemy');

  const strategy = profile?.strategy ?? 'default';
  if (strategy === 'aggro') score += attack * 0.35;
  if (strategy === 'control') score += health * 0.25 + (card.taunt ? 0.8 : 0);
  if (strategy === 'value') score += (attack + health) * 0.1;

  return score;
}

function bestTargetByScore(cards = [], scorer = dangerScore) {
  if (!cards.length) return null;
  return [...cards].sort((a, b) => scorer(b) - scorer(a))[0] ?? null;
}

function bestFriendlySupportTarget(cards = []) {
  return bestTargetByScore(cards, (card) => threatScore(card) + (deriveRoleTags(card).normalizedTags.engine ? 2.8 : 0));
}

function spellActionProfile(card = {}) {
  const text = `${card.name ?? ''} ${card.text ?? ''}`.toLowerCase();
  return {
    damage: /deal \d+ damage|split among enemies|all enemy minions/.test(text),
    aoe: /all enemy minions|all minions|split among enemies|all enemies/.test(text),
    heal: /restore|heal|lifesteal/.test(text),
    draw: /draw|discover|look at the top|reorder/.test(text),
    summon: /summon|token/.test(text),
    bounce: /return .* hand/.test(text),
    destroy: /destroy/.test(text),
    silence: /silence/.test(text),
    freeze: /freeze/.test(text),
    buff: /\+\d+\/\+\d+|\+\d+ attack|\+\d+ health|divine shield|rush|taunt/.test(text),
    copy: /copy|replication/.test(text),
    transform: /transform|becomes/.test(text),
    revive: /resummon|revive|return .* died/.test(text),
    topdeck: /look at the top|reorder/.test(text),
    costReduce: /costs? \(\d+\) less|reduce .* cost/.test(text),
    counter: /counter|cancel the next enemy spell/.test(text),
    random: /random/.test(text),
    relic: normalizeCardType(card) === 'relic' || normalizeCardType(card) === 'field',
    structure: normalizeCardType(card) === 'barricade',
  };
}

function tacticalSnapshot(stateLike, profile) {
  const enemy = boardStats(stateLike, 'enemy');
  const player = boardStats(stateLike, 'player');
  const enemyMana = availableMana(stateLike, 'enemy');
  const playerThreat = bestTargetByScore(stateLike.playerMinions ?? []);
  const enemyThreat = bestFriendlySupportTarget(stateLike.enemyMinions ?? []);
  const threatenedNextTurn = player.readyAttack >= Math.max(1, (stateLike.enemyHealth ?? 1) - 2);
  const behindOnBoard = (player.attack + player.health) > (enemy.attack + enemy.health + 3);
  const aheadOnBoard = (enemy.attack + enemy.health) > (player.attack + player.health + 3);
  const lowHand = (stateLike.enemyHand?.length ?? 0) <= 2;
  const lowDeck = (stateLike.enemyDeck?.length ?? 0) <= 6;
  const controlDeck = ['executioner', 'oracle', 'fortress', 'war-engine'].includes(profile?.aiArchetype);
  const comboDeck = ['scholar', 'oracle', 'revenant'].includes(profile?.aiArchetype);
  const threatMemory = profile?.threatMemory ?? {};
  const respectList = Array.isArray(threatMemory.respectList) ? threatMemory.respectList : [];
  const fearedNames = new Set(respectList.map((entry) => String(entry?.name ?? '').toLowerCase()).filter(Boolean));
  return {
    enemy,
    player,
    enemyMana,
    playerThreat,
    enemyThreat,
    threatenedNextTurn,
    behindOnBoard,
    aheadOnBoard,
    lowHand,
    lowDeck,
    controlDeck,
    comboDeck,
    comboDiscipline: difficultyConfig(profile?.difficultyBand).comboDiscipline ?? 0.6,
    playerWide: player.count >= 3,
    enemyWide: enemy.count >= 4,
    playerHighThreat: player.highThreat >= 1 || dangerScore(playerThreat ?? {}) >= 7,
    enemyCloseToLethal: enemy.readyAttack >= Math.max(1, stateLike.playerHealth ?? 1),
    fatigueDanger: (stateLike.enemyDeck?.length ?? 0) <= 2,
    fearTargeted: fearedNames.has(String(playerThreat?.name ?? '').toLowerCase()),
    threatMemoryCount: respectList.length,
  };
}

function scoreCardPlayAction(card = {}, action = {}, stateLike, profile, flags) {
  const spell = spellActionProfile(card);
  const type = normalizeCardType(card);
  const target = (stateLike.playerMinions ?? []).find((entry) => entry.id === action.targetId)
    ?? (stateLike.enemyMinions ?? []).find((entry) => entry.id === action.targetId)
    ?? null;
  let score = cardPower(card, stateLike, profile) + (deckAffinityScore(card, profile) * 0.45);
  const reasons = [];

  if (type === 'minion') {
    if (card.taunt && (flags.threatenedNextTurn || flags.behindOnBoard)) {
      score += 2.4;
      reasons.push('stabilizer');
    }
    if ((card.attack ?? 0) >= 5 && flags.aheadOnBoard) {
      score += 1.4;
      reasons.push('convert-pressure');
    }
    if ((card.cost ?? 0) >= 7 && flags.threatenedNextTurn && !card.taunt) {
      score -= 1.2;
      reasons.push('too-slow');
    }
  }

  if (type === 'field' || type === 'relic' || type === 'aura' || type === 'trap') {
    if (flags.threatenedNextTurn && !spell.heal && !spell.counter) {
      score -= 1.5;
      reasons.push('board-first');
    } else {
      score += 1.1;
      reasons.push('engine-line');
    }
  }

  if (type === 'barricade') {
    score += flags.threatenedNextTurn || flags.playerHighThreat ? 2.1 : 0.8;
    reasons.push(flags.threatenedNextTurn ? 'lane-stop' : 'lane-anchor');
  }

  if (isSpellLike(card)) {
    if ((spell.destroy || spell.damage || spell.silence || spell.freeze || spell.bounce) && target) {
      const targetDanger = dangerScore(target);
      score += targetDanger * 0.28;
      if (flags.controlDeck && targetDanger >= 7) {
        score += 1.8;
        reasons.push('respect-target');
      }
      if ((spell.destroy || spell.damage) && targetDanger < 3 && flags.playerHighThreat) {
        score -= 1.6;
        reasons.push('anti-bait');
      }
    }
    if (spell.aoe) {
      if (flags.playerWide || flags.player.highThreat >= 2) {
        score += 3.1;
        reasons.push('aoe-window');
      } else {
        score -= 1.9;
        reasons.push('aoe-held');
      }
    }
    if (spell.draw) {
      if (flags.lowHand || flags.lowDeck) {
        score += 1.6;
        reasons.push('reload');
      } else if ((stateLike.enemyHand?.length ?? 0) >= 7) {
        score -= 1.2;
        reasons.push('avoid-overdraw');
      }
    }
    if (spell.heal) {
      if (flags.threatenedNextTurn || (stateLike.enemyHealth ?? 30) <= 14) {
        score += 2.1;
        reasons.push('survival');
      } else {
        score -= 0.7;
        reasons.push('heal-idle');
      }
    }
    if (spell.buff) {
      if ((stateLike.enemyMinions?.length ?? 0) === 0) {
        score -= 2.2;
        reasons.push('no-board');
      } else if (flags.enemyWide || (flags.enemyThreat && threatScore(flags.enemyThreat) >= 7)) {
        score += 1.8;
        reasons.push('buff-window');
      }
    }
    if ((spell.copy || spell.topdeck || spell.costReduce || spell.revive) && flags.comboDeck) {
      score += 1.1 + (flags.comboDiscipline * 1.1);
      reasons.push('combo-value');
    }
    if (spell.counter && flags.controlDeck) {
      score += 1.3;
      reasons.push('answer-bank');
    }
    if (spell.random && profile?.aiArchetype === 'gambler') {
      score += 1.1;
      reasons.push('variance-accepted');
    }
  }

  if (flags.enemyCloseToLethal && (card.attack ?? 0) >= 3) {
    score += 0.8;
    reasons.push('close-race');
  }
  if (flags.fatigueDanger && spell.draw) {
    score -= 1.35;
    reasons.push('fatigue-aware');
  }
  if (flags.fearTargeted && target && String(target.name ?? '').toLowerCase() === String(flags.playerThreat?.name ?? '').toLowerCase()) {
    score += 1.45;
    reasons.push('threat-memory');
  }

  return { score, reasons };
}

function makeCardPlayActions(stateLike, profile, maxOptions = 8) {
  const hand = stateLike.enemyHand ?? [];
  if (!hand.length) return [];
  const mana = availableMana(stateLike, 'enemy');
  const liveEnemy = (stateLike.enemyMinions ?? []).filter((entry) => (entry.health ?? 0) > 0);
  const livePlayer = (stateLike.playerMinions ?? []).filter((entry) => (entry.health ?? 0) > 0);
  const formationChoice = chooseFormation(profile, stateLike, false);
  const flags = tacticalSnapshot(stateLike, profile);
  const actions = [];

  hand.forEach((card, handIndex) => {
    const cost = effectiveAiCost(card, stateLike, 'enemy');
    if (cost > mana) return;
    const type = normalizeCardType(card);
    if (type === 'minion') {
      const slotPick = chooseSummonSlot(stateLike, card, formationChoice);
      if (slotPick.slot != null) actions.push({ type: 'play-card', handIndex, cardType: type, slot: slotPick.slot, trace: `${ACTION_TRACE_PREFIX}:enemy:play:${card.name}:slot-${slotPick.slot}` });
      return;
    }
    if (type === 'barricade') {
      const openLane = Array.from({ length: 4 }, (_, idx) => idx).find((idx) => !stateLike.enemyBarricades?.[idx] || (stateLike.enemyBarricades[idx].health ?? 0) <= 0);
      if (openLane != null) actions.push({ type: 'play-card', handIndex, cardType: type, lane: openLane, trace: `${ACTION_TRACE_PREFIX}:enemy:structure:${card.name}:lane-${openLane}` });
      return;
    }
    if (type === 'field' || type === 'relic' || type === 'aura' || type === 'trap') {
      actions.push({ type: 'play-card', handIndex, cardType: type, trace: `${ACTION_TRACE_PREFIX}:enemy:permanent:${card.name}` });
      return;
    }
    if (isSpellLike(card)) {
      const spell = spellActionProfile(card);
      const enemyTarget = spell.heal || spell.buff
        ? null
        : (spell.aoe ? bestTargetByScore(livePlayer, dangerScore) : bestTargetByScore(livePlayer));
      const allyTarget = bestFriendlySupportTarget(liveEnemy);
      let targetId = spell.heal || spell.buff ? allyTarget?.id ?? null : enemyTarget?.id ?? null;
      if ((spell.damage || spell.destroy) && !targetId && !hasTaunt(livePlayer) && flags.enemyCloseToLethal) targetId = 'player-hero';
      actions.push({ type: 'play-card', handIndex, cardType: type, targetId, trace: `${ACTION_TRACE_PREFIX}:enemy:spell:${card.name}:${targetId ?? 'none'}` });
    }
  });

  return actions
    .map((action) => {
      const card = hand[action.handIndex];
      const { score, reasons } = scoreCardPlayAction(card, action, stateLike, profile, flags);
      return {
        ...action,
        score,
        rationale: reasons,
        trace: reasons.length ? `${action.trace}:${reasons.slice(0, 2).join('+')}` : action.trace,
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, maxOptions);
}

function chooseDeckCard(stateLike, profile, explicitDeckIndex = null) {
  const deck = stateLike.enemyDeck ?? [];
  if (deck.length > 0) {
    if (Number.isInteger(explicitDeckIndex)) {
      const idx = clamp(explicitDeckIndex, 0, deck.length - 1);
      const [picked] = deck.splice(idx, 1);
      return picked ?? null;
    }

    let bestIdx = 0;
    let bestScore = -Infinity;
    for (let i = 0; i < deck.length; i += 1) {
      const score = cardPower(deck[i], stateLike, profile);
      if (score > bestScore) {
        bestScore = score;
        bestIdx = i;
      }
    }
    const [picked] = deck.splice(bestIdx, 1);
    return picked ?? null;
  }

  const templates = profile?.summons ?? [];
  if (!templates.length) return null;

  let bestTemplate = templates[0];
  let bestTemplateScore = cardPower(bestTemplate, stateLike, profile);
  for (let i = 1; i < templates.length; i += 1) {
    const score = cardPower(templates[i], stateLike, profile);
    if (score > bestTemplateScore) {
      bestTemplateScore = score;
      bestTemplate = templates[i];
    }
  }
  return { ...bestTemplate };
}

function makeSummon(card = {}, idPrefix = 'sim') {
  return ensureCombatState({
    id: `${idPrefix}-${Math.floor(Math.random() * 999999)}`,
    name: card.name ?? 'Construct Token',
    attack: card.attack ?? 2,
    health: card.health ?? 2,
    taunt: !!card.taunt,
    baseTaunt: !!card.taunt,
    baseDef: Math.max(0, toNumber(card.def ?? card.baseDef ?? 0)),
    defense: false,
    defenseDurability: 0,
    race: extractCardRaces(card)[0] ?? card.race ?? 'neutral',
    races: extractCardRaces(card),
    element: card.element ?? 'none',
    statuses: {},
    rarity: card.rarity ?? 'rare',
    pierce: Math.max(0, toNumber(card.pierce ?? 0)),
    trueDamage: !!card.trueDamage,
    allowMultiAttack: !!card.allowMultiAttack,
    allowFriendlyAttack: !!card.allowFriendlyAttack,
    charge: !!card.charge,
    text: card.text ?? '',
    tags: Array.isArray(card.tags) ? [...card.tags] : [],
    keywords: Array.isArray(card.keywords) ? [...card.keywords] : [],
    summoningSick: !card.charge,
  });
}

function applySideAction(stateLike, side, action, profile) {
  const next = cloneState(stateLike);
  const attackers = sideLane(next, side);
  const defenders = oppositeLane(next, side);
  attackers.forEach(ensureCombatState);
  defenders.forEach(ensureCombatState);

  if (action.type === 'attack-hero') {
    const attacker = attackers.find((m) => m.id === action.attackerId);
    if (!attacker || !canAttack(next, side, attacker)) return null;
    if (hasTaunt(defenders)) return null;
    const damage = mitigatedDamage(attacker.attack ?? 0, { baseDef: 2, defense: defenders.some((m) => m.defense) }, attacker);
    if (side === 'enemy') next.playerHealth -= damage;
    else next.enemyHealth -= damage;
    markAttackUsed(next, side, attacker);
    return next;
  }

  if (action.type === 'attack-minion') {
    const attacker = attackers.find((m) => m.id === action.attackerId);
    const defender = defenders.find((m) => m.id === action.targetId);
    if (!attacker || !defender || !canAttack(next, side, attacker)) return null;

    const tauntTargets = defenders.filter((m) => m.taunt);
    if (tauntTargets.length > 0 && !defender.taunt) return null;

    const attackDamage = mitigatedDamage(attacker.attack ?? 0, defender, attacker);
    const counterDamage = mitigatedDamage(defender.attack ?? 0, attacker, defender);

    defender.health -= attackDamage;
    attacker.health -= counterDamage;
    if (attacker.defense && counterDamage > 0) attacker.defenseDurability = Math.max(0, (attacker.defenseDurability || 2) - 1);
    if (defender.defense && attackDamage > 0) defender.defenseDurability = Math.max(0, (defender.defenseDurability || 2) - 1);
    if (attacker.defenseDurability === 0) {
      attacker.defense = false;
      attacker.taunt = !!attacker.baseTaunt;
    }
    if (defender.defenseDurability === 0) {
      defender.defense = false;
      defender.taunt = !!defender.baseTaunt;
    }
    markAttackUsed(next, side, attacker);
    clearDeadMinions(next);
    return next;
  }

  if (action.type === 'summon' && side === 'enemy') {
    if ((next.enemyMinions?.length ?? 0) >= MAX_LANE_SIZE) return null;

    const chosenCard = chooseDeckCard(next, profile, action.deckIndex ?? null);
    if (!chosenCard) return null;

    const usedSlots = occupiedSlots(next.enemyMinions);
    let slot = Number.isInteger(action.slot) ? action.slot : null;
    if (slot == null || slot < 0 || slot >= MAX_LANE_SIZE || usedSlots.has(slot)) {
      slot = Array.from({ length: MAX_LANE_SIZE }, (_, i) => i).find((i) => !usedSlots.has(i));
    }
    if (slot == null) return null;
    const summon = makeSummon(chosenCard);
    summon.slot = slot;
    next.enemyMinions.push(summon);
    return next;
  }

  if (action.type === 'play-card' && side === 'enemy') {
    const hand = next.enemyHand ?? [];
    const idx = clamp(toNumber(action.handIndex, -1), 0, Math.max(0, hand.length - 1));
    const card = hand[idx];
    if (!card) return null;
    const cost = effectiveAiCost(card, next, 'enemy');
    if (cost > availableMana(next, 'enemy')) return null;
    next.enemyMana = Math.max(0, availableMana(next, 'enemy') - cost);
    hand.splice(idx, 1);
    const type = normalizeCardType(card);

    if (type === 'minion') {
      const slot = Number.isInteger(action.slot) ? action.slot : chooseSummonSlot(next, card, chooseFormation(profile, next, false)).slot;
      if (slot == null || occupiedSlots(next.enemyMinions).has(slot)) return null;
      const summon = makeSummon(card);
      summon.slot = slot;
      next.enemyMinions.push(summon);
      return next;
    }

    if (type === 'barricade') {
      const lane = clamp(toNumber(action.lane, 0), 0, 3);
      next.enemyBarricades = Array.isArray(next.enemyBarricades) ? next.enemyBarricades : Array(4).fill(null);
      next.enemyBarricades[lane] = {
        id: `${card.id ?? card.name}-bar-${lane}`,
        name: card.name,
        lane,
        health: Math.max(1, toNumber(card.health ?? card.durability ?? 6, 6)),
        maxHealth: Math.max(1, toNumber(card.health ?? card.durability ?? 6, 6)),
        def: Math.max(0, toNumber(card.def ?? card.baseDef ?? 1, 1)),
        text: card.text ?? '',
      };
      return next;
    }

    if (type === 'field') {
      next.enemyFields = [...(next.enemyFields ?? []), { ...card, type: 'field' }];
      return next;
    }

    if (type === 'relic' || type === 'aura' || type === 'trap') {
      next.enemyRelics = [...(next.enemyRelics ?? []), { ...card, type: type === 'aura' ? 'relic' : type }];
      return next;
    }

    if (isSpellLike(card)) {
      const spell = spellActionProfile(card);
      const target = (next.playerMinions ?? []).find((entry) => entry.id === action.targetId)
        ?? (next.enemyMinions ?? []).find((entry) => entry.id === action.targetId)
        ?? null;
      if (spell.destroy && target) {
        target.health = 0;
      } else if ((spell.damage || spell.silence || spell.freeze || spell.bounce) && target) {
        if (spell.bounce) {
          next.playerMinions = next.playerMinions.filter((entry) => entry.id !== target.id);
        } else if (spell.silence) {
          target.taunt = false;
          target.defense = false;
          target.statuses = {};
        } else if (spell.freeze) {
          target.statuses = target.statuses ?? {};
          target.statuses.freezeTurns = Math.max(1, toNumber(target.statuses.freezeTurns ?? 0) + 1);
        }
        if (spell.damage) target.health = Math.max(0, toNumber(target.health ?? 0) - Math.max(2, Math.floor(cardPower(card, next, profile) / 4)));
      } else if (spell.heal) {
        const ally = (next.enemyMinions ?? []).find((entry) => entry.id === action.targetId) ?? bestFriendlySupportTarget(next.enemyMinions ?? []);
        if (ally) ally.health = Math.min(toNumber(ally.maxHealth ?? ally.health ?? 0), toNumber(ally.health ?? 0) + 4);
        else next.enemyHealth += 4;
      } else if (spell.draw) {
        const drawCount = /draw three/i.test(card.text ?? '') ? 3 : /draw two/i.test(card.text ?? '') ? 2 : 1;
        for (let drawStep = 0; drawStep < drawCount; drawStep += 1) {
          const drawn = next.enemyDeck?.shift?.();
          if (drawn) next.enemyHand.push({ ...drawn });
        }
      } else if (spell.summon) {
        const slot = Array.from({ length: MAX_LANE_SIZE }, (_, openIdx) => openIdx).find((openIdx) => !occupiedSlots(next.enemyMinions).has(openIdx));
        if (slot != null) {
          const token = makeSummon({ name: `${card.name} Token`, attack: 2, health: 2, race: 'token', text: card.text ?? '' });
          token.slot = slot;
          next.enemyMinions.push(token);
        }
      } else {
        next.playerHealth -= Math.max(2, Math.floor(cardPower(card, next, profile) / 4));
      }
      clearDeadMinions(next);
      return next;
    }
  }

  if (action.type === 'pass') {
    return next;
  }

  return null;
}

function boardStats(stateLike, side) {
  const lane = sideLane(stateLike, side);
  let attack = 0;
  let health = 0;
  let taunt = 0;
  let readyAttack = 0;
  let stickyCount = 0;
  let highThreat = 0;

  for (const minion of lane) {
    const minionAttack = minion.attack ?? 0;
    const minionHealth = minion.health ?? 0;
    attack += minionAttack;
    health += minionHealth;
    if (minion.taunt) taunt += 1;
    if (canAttack(stateLike, side, minion)) readyAttack += minionAttack;
    if (minionHealth >= 4) stickyCount += 1;
    if (minionAttack >= 5) highThreat += 1;
  }

  return {
    count: lane.length,
    attack,
    health,
    taunt,
    readyAttack,
    stickyCount,
    highThreat,
  };
}

function deckQuality(stateLike, profile) {
  const deck = stateLike.enemyDeck ?? [];
  if (!deck.length) return 0;

  const top = [...deck]
    .map((card) => cardPower(card, stateLike, profile))
    .sort((a, b) => b - a)
    .slice(0, 5);

  const avg = top.reduce((sum, value) => sum + value, 0) / Math.max(1, top.length);
  return clamp(avg / 12, -2, 2);
}

function archetypeProgressionScore(stateLike, profile, me, opp) {
  const primary = profile?.deckIdentity?.primary ?? 'midrange';
  switch (primary) {
    case 'aggro':
      return clamp(((me.readyAttack * 1.15) - opp.taunt - ((stateLike.playerHealth ?? 0) * 0.08)), -5, 5);
    case 'control':
      return clamp(((opp.highThreat * -1.1) + (me.taunt * 0.8) + ((stateLike.enemyHealth ?? 0) * 0.05)), -5, 5);
    case 'combo':
      return clamp((((stateLike.enemyHand ?? []).length * 0.75) + deckQuality(stateLike, profile) + (me.count * 0.35)), -5, 5);
    case 'swarm':
      return clamp((me.count * 0.85) + (me.stickyCount * 0.55) - (opp.readyAttack * 0.2), -5, 5);
    case 'relic-engine':
      return clamp((((stateLike.enemyFields ?? []).length + (stateLike.enemyRelics ?? []).length) * 1.2) - (opp.highThreat * 0.25), -5, 5);
    case 'siege':
      return clamp((((stateLike.enemyBarricades ?? []).filter(Boolean).length) * 1.3) + (((stateLike.enemyFields ?? []).length + (stateLike.enemyRelics ?? []).length) * 0.45), -5, 5);
    case 'dragon-ramp':
      return clamp((((stateLike.enemyHand ?? []).filter((card) => /dragon/.test(String(card?.race ?? '').toLowerCase()) || /dragon/.test(String(card?.text ?? '').toLowerCase())).length) * 0.9) + (me.highThreat * 0.6), -5, 5);
    case 'beast-pack':
      return clamp((((stateLike.enemyMinions ?? []).filter((card) => /beast/.test(String(card?.race ?? '').toLowerCase())).length) * 0.9) + (me.attack * 0.08), -5, 5);
    case 'graveyard':
      return clamp((((stateLike.turnFlags?.enemy?.diedFamilies?.undead ?? 0) + (stateLike.turnFlags?.enemy?.minionDied ?? 0) * 0.35) + ((stateLike.enemyHand ?? []).length * 0.18)), -5, 5);
    case 'stealth-value':
      return clamp((((stateLike.enemyMinions ?? []).filter((card) => card?.statuses?.stealth || /stealth/.test(String(card?.text ?? '').toLowerCase())).length) * 1.1) + ((stateLike.enemyHand ?? []).length * 0.2), -5, 5);
    default:
      return clamp(((me.attack + me.health) - (opp.attack + opp.health)) / 10, -5, 5);
  }
}

function stateEvaluationBreakdown(stateLike, profile) {
  const enriched = profile?.aiBiases ? profile : enrichAiProfile(profile, [...(stateLike?.enemyDeck ?? []), ...(stateLike?.enemyHand ?? []), ...(profile?.deck ?? []), ...(profile?.summons ?? [])]);
  const bias = enriched.aiBiases ?? AI_ARCHETYPES.tyrant.biases;
  const me = boardStats(stateLike, 'enemy');
  const opp = boardStats(stateLike, 'player');
  const topHand = (stateLike.enemyHand ?? []).slice(0, 5);
  const handPower = topHand.reduce((sum, card) => sum + cardPower(card, stateLike, enriched), 0) / Math.max(1, topHand.length || 1);
  const boardValueScore = (((me.attack + me.health + (me.taunt * 2) + (me.stickyCount * 1.5)) - (opp.attack + opp.health + (opp.taunt * 2) + (opp.stickyCount * 1.5))) / 8) * bias.trade;
  const tempoScore = (((me.readyAttack - opp.readyAttack) * 0.55) + ((me.count - opp.count) * 0.35) + (((stateLike.enemyMana ?? stateLike.maxMana ?? 0) - Math.max(0, stateLike.maxMana ?? 0)) * -0.12)) * bias.aggression;
  const handValueScore = (handPower / 2.5) * bias.combo;
  const survivabilityScore = clamp(((stateLike.enemyHealth ?? 0) - opp.readyAttack) / 5, -8, 8) * bias.survival;
  const lethalityEstimate = clamp((me.readyAttack - (stateLike.playerHealth ?? 0)) / 3.5, -8, 8) * bias.lethal;
  const damageRaceEstimate = clamp((((stateLike.enemyHealth ?? 0) - opp.readyAttack) - ((stateLike.playerHealth ?? 0) - me.readyAttack)) / 4, -8, 8);
  const removalEfficiencyScore = clamp(((opp.highThreat * 1.15) + (opp.taunt * 0.8) - (me.highThreat * 0.35)), -8, 8) * bias.removal;
  const manaEfficiencyScore = clamp((((stateLike.maxMana ?? 0) - (stateLike.enemyMana ?? 0)) / Math.max(1, stateLike.maxMana ?? 1)) * 6, -4, 4);
  const archetypeProgression = archetypeProgressionScore(stateLike, enriched, me, opp);
  const futureThreatScore = deckQuality(stateLike, enriched) * 3.2;
  const familiarityTotal = stateLike.familiarity?.enemy
    ? Object.values(stateLike.familiarity.enemy).reduce((sum, value) => sum + Number(value ?? 0), 0)
    : 0;
  const synergyActivationScore = clamp(
    ((stateLike.turnFlags?.enemy?.playedMinion ?? 0) * 0.35)
      + ((stateLike.turnFlags?.enemy?.playedSpell ?? 0) * 0.45)
      + (((stateLike.enemyFields ?? []).length + (stateLike.enemyRelics ?? []).length) * 0.4)
      + (familiarityTotal * 0.18),
    -6,
    6,
  );
  const randomDensity = (stateLike.enemyHand ?? []).filter((card) => /random|discover|roulette|chaos/.test(String(card?.text ?? '').toLowerCase())).length;
  const expectedValueScore = clamp((randomDensity * bias.risk * 0.8) + ((stateLike.enemyHand ?? []).length * 0.1), -4, 4);
  const fatiguePressureScore = clamp((((stateLike.enemyDeck?.length ?? 0) <= 4 ? -1.3 : 0.4) - ((stateLike.enemyDeck?.length ?? 0) === 0 ? 2.1 : 0)), -4, 4);
  const predictedLethal = me.readyAttack >= Math.max(1, stateLike.playerHealth ?? 1);
  const threatenedLethal = opp.readyAttack >= Math.max(1, (stateLike.enemyHealth ?? 0) - 1);
  const totalScore = boardValueScore
    + tempoScore
    + handValueScore
    + survivabilityScore
    + lethalityEstimate
    + damageRaceEstimate
    + removalEfficiencyScore
    + manaEfficiencyScore
    + archetypeProgression
    + futureThreatScore
    + synergyActivationScore
    + expectedValueScore
    + fatiguePressureScore;
  return {
    boardValueScore: Number(boardValueScore.toFixed(2)),
    tempoScore: Number(tempoScore.toFixed(2)),
    handValueScore: Number(handValueScore.toFixed(2)),
    survivabilityScore: Number(survivabilityScore.toFixed(2)),
    lethalityEstimate: Number(lethalityEstimate.toFixed(2)),
    damageRaceEstimate: Number(damageRaceEstimate.toFixed(2)),
    removalEfficiencyScore: Number(removalEfficiencyScore.toFixed(2)),
    manaEfficiencyScore: Number(manaEfficiencyScore.toFixed(2)),
    archetypeProgressionScore: Number(archetypeProgression.toFixed(2)),
    futureThreatScore: Number(futureThreatScore.toFixed(2)),
    synergyActivationScore: Number(synergyActivationScore.toFixed(2)),
    expectedValueScore: Number(expectedValueScore.toFixed(2)),
    fatiguePressureScore: Number(fatiguePressureScore.toFixed(2)),
    predictedLethal,
    threatenedLethal,
    totalScore: Number(totalScore.toFixed(2)),
  };
}

const L1_WEIGHTS = [
  [0.75, 1.18, 0.72, 1.12, 0.81, 0.68, -0.52, 0.94, -1.1, 0.58, 0.22, 0.4, 0.38, 0.86, 0.62, 0.2],
  [-0.34, 0.86, 1.05, 0.64, 0.62, 1.03, -0.24, 0.45, -0.72, 0.4, 0.18, 0.28, 0.11, 0.42, 0.67, 0.1],
  [0.4, 0.52, 0.74, 1.22, 1.16, 0.55, -0.62, 0.8, -0.9, 0.3, 0.14, 0.2, 0.3, 1.0, 0.78, 0.12],
  [0.2, 0.1, 0.38, 0.6, 0.7, 1.28, -0.16, 1.35, -1.22, 0.2, 0.12, 0.25, 0.18, 0.4, 0.52, 0.22],
  [0.62, 0.98, 0.26, 0.74, 0.84, 0.42, -0.42, 0.36, -0.5, 0.64, 0.34, 0.56, 0.42, 0.58, 0.36, 0.18],
  [-0.08, 0.3, 0.66, 1.08, 0.92, 0.46, -0.5, 0.74, -0.86, 0.08, 0.16, 0.2, 0.24, 0.88, 0.72, 0.1],
  [0.28, 0.44, 0.82, 0.92, 0.58, 0.7, -0.3, 1.04, -0.98, 0.18, 0.08, 0.22, 0.2, 0.54, 0.44, 0.3],
  [0.18, 0.64, 0.58, 0.72, 0.62, 0.9, -0.2, 0.7, -0.72, 0.36, 0.24, 0.34, 0.3, 0.62, 0.48, 0.14],
];

const L1_BIAS = [0.12, -0.08, 0.05, 0.18, -0.02, 0.08, 0.04, 0.06];

const L2_WEIGHTS = [
  [0.8, 0.62, 0.74, 0.72, 0.5, 0.78, 0.64, 0.7],
  [0.54, 0.88, 0.72, 0.44, 0.4, 0.68, 0.76, 0.6],
  [0.64, 0.56, 0.92, 0.36, 0.28, 0.84, 0.5, 0.46],
  [0.5, 0.4, 0.38, 1.04, 0.58, 0.52, 0.8, 0.72],
  [0.76, 0.44, 0.54, 0.58, 0.92, 0.46, 0.36, 0.62],
  [0.42, 0.72, 0.48, 0.84, 0.46, 0.64, 0.58, 0.7],
];

const L2_BIAS = [0.1, 0.05, 0.06, 0.14, 0.08, 0.09];
const OUT_WEIGHTS = [1.02, 0.88, 1.08, 0.94, 0.82, 0.9];
const OUT_BIAS = -1.2;

function neuralStateScore(stateLike, profile) {
  if ((stateLike.playerHealth ?? 0) <= 0) return WIN_SCORE;
  if ((stateLike.enemyHealth ?? 0) <= 0) return -WIN_SCORE;

  const enriched = profile?.aiBiases ? profile : enrichAiProfile(profile, [...(stateLike?.enemyDeck ?? []), ...(stateLike?.enemyHand ?? []), ...(profile?.deck ?? []), ...(profile?.summons ?? [])]);
  const bias = enriched.aiBiases ?? AI_ARCHETYPES.tyrant.biases;
  const me = boardStats(stateLike, 'enemy');
  const opp = boardStats(stateLike, 'player');
  const handValue = ((stateLike.enemyHand ?? []).slice(0, 4).reduce((sum, card) => sum + cardPower(card, stateLike, enriched), 0)) / 12;
  const survivability = clamp(((stateLike.enemyHealth ?? 0) - opp.readyAttack) / 12, -2, 2);
  const lethality = clamp((me.readyAttack - (stateLike.playerHealth ?? 0)) / 10, -2, 2);
  const structureDelta = clamp((((stateLike.enemyBarricades ?? []).filter(Boolean).length) - (((stateLike.playerBarricades ?? []).filter(Boolean).length))) / 3, -2, 2);
  const permanentDelta = clamp(
    ((((stateLike.enemyFields ?? []).length + (stateLike.enemyRelics ?? []).length)
      - ((stateLike.playerFields ?? []).length + (stateLike.playerRelics ?? []).length)) / 4),
    -2,
    2,
  );

  const features = [
    1,
    clamp((stateLike.enemyHealth - stateLike.playerHealth) / 30, -2, 2),
    clamp((me.count - opp.count) / 8, -2, 2),
    clamp((me.attack - opp.attack) / 24, -2, 2),
    clamp((me.health - opp.health) / 28, -2, 2),
    clamp((me.readyAttack - opp.readyAttack) / 22, -2, 2),
    clamp((me.taunt - opp.taunt) / 4, -2, 2),
    clamp((me.readyAttack - stateLike.playerHealth) / 10, -2, 2),
    clamp((opp.readyAttack - stateLike.enemyHealth) / 10, -2, 2),
    clamp(stateLike.enemyHealth / Math.max(1, stateLike.enemyHealth + opp.readyAttack), -2, 2),
    clamp((stateLike.enemyDeck?.length ?? 0) / 30, -2, 2),
    deckQuality(stateLike, profile),
    clamp((MAX_LANE_SIZE - me.count) / MAX_LANE_SIZE, -2, 2),
    clamp((me.highThreat - opp.highThreat) / 4, -2, 2),
    clamp((me.stickyCount - opp.stickyCount) / 6, -2, 2),
    enriched?.strategy === 'aggro' ? 0.9 : enriched?.strategy === 'control' ? -0.4 : 0.2,
  ];

  const l1 = dense(features, L1_WEIGHTS, L1_BIAS).map(relu);
  const l2 = dense(l1, L2_WEIGHTS, L2_BIAS).map(relu);
  const networkOutput = dot(l2, OUT_WEIGHTS) + OUT_BIAS;

  const aggression = clamp((enriched?.weights?.attackFace ?? 0.5) * bias.face, 0.1, 2.2);
  const tradeBias = clamp((enriched?.weights?.trade ?? 0.6) * bias.trade, 0.1, 2.2);
  const summonBias = clamp((enriched?.weights?.summon ?? 0.6) * bias.wide, 0.05, 2.2);

  const tactical = (features[7] * aggression * 2.6)
    + (features[3] * tradeBias * 1.8)
    + (features[11] * summonBias * 1.6)
    + (survivability * bias.survival * 2.4)
    + (lethality * bias.lethal * 2.8)
    + (handValue * bias.combo * 1.6)
    + (structureDelta * bias.siege * 1.4)
    + (permanentDelta * bias.engine * 1.4);
  const formation = chooseFormation(enriched, stateLike, false).formation;
  const formationFit = slotPatternFit(stateLike.enemyMinions, formation);
  return (networkOutput * 10) + tactical + (formationFit * 1.35);
}

function quickAttackBonus(before, after, action) {
  if (action.type === 'attack-hero') {
    const dealt = Math.max(0, (before.playerHealth ?? 0) - (after.playerHealth ?? 0));
    const lethal = (after.playerHealth ?? 0) <= 0 ? WIN_SCORE : 0;
    return (dealt * 3.6) + lethal;
  }

  if (action.type === 'attack-minion') {
    const killed = Math.max(0, (before.playerMinions?.length ?? 0) - (after.playerMinions?.length ?? 0));
    const lost = Math.max(0, (before.enemyMinions?.length ?? 0) - (after.enemyMinions?.length ?? 0));
    return (killed * 6) - (lost * 4.5);
  }

  if (action.type === 'summon') {
    const gained = Math.max(0, (after.enemyMinions?.length ?? 0) - (before.enemyMinions?.length ?? 0));
    return gained * 2.2;
  }

  return 0;
}

function makeAttackActions(stateLike, side) {
  const actions = [];
  const attackers = availableAttackers(stateLike, side);
  const defenders = oppositeLane(stateLike, side);
  const tauntTargets = defenders.filter((m) => m.taunt);

  for (const attacker of attackers) {
    if (tauntTargets.length === 0) {
      actions.push({
        type: 'attack-hero',
        attackerId: attacker.id,
        trace: `${ACTION_TRACE_PREFIX}:${side}:attack-hero`,
      });
    }

    const legalTargets = tauntTargets.length > 0 ? tauntTargets : defenders;
    for (const target of legalTargets) {
      actions.push({
        type: 'attack-minion',
        attackerId: attacker.id,
        targetId: target.id,
        trace: `${ACTION_TRACE_PREFIX}:${side}:attack-minion`,
      });
    }
  }

  return actions;
}

function makeSummonActions(stateLike, profile, maxOptions = 4) {
  if ((stateLike.enemyMinions?.length ?? 0) >= MAX_LANE_SIZE) return [];
  const formationChoice = chooseFormation(profile, stateLike, false);
  const planner = plannerState.get(profile?.id ?? profile?.name ?? 'unknown') ?? null;

  const deck = stateLike.enemyDeck ?? [];
  if (deck.length > 0) {
    const scored = deck
      .map((card, idx) => {
        const slotPick = chooseSummonSlot(stateLike, card, formationChoice);
        const role = deriveRoleTags(card).role;
        const expected = formationChoice.formation.pattern[slotPick.slot ?? 0] ?? '.';
        const roleFit = expected === role ? 1.8 : expected === '.' ? -0.8 : -0.2;
        const probabilityBias = (
          (formationChoice.context.probabilities.threatBy5 * (role === 'D' ? 1.3 : 0.5))
          + (formationChoice.context.probabilities.engineBy4 * (role === 'E' ? 1.2 : 0.2))
          + (formationChoice.context.probabilities.tauntBy3 * (role === 'T' ? 1.1 : 0.2))
        );

        const score = cardPower(card, stateLike, profile) + roleFit + probabilityBias + (slotPick.score * 0.55);
        return {
          idx,
          score,
          name: card.name ?? 'Unknown',
          slot: slotPick.slot,
          slotReason: slotPick.reason,
          formationId: formationChoice.formation.id,
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, maxOptions);

    if (planner) {
      planner.slotDecisions = scored.map((entry) => ({
        card: entry.name,
        slot: entry.slot,
        reason: entry.slotReason,
        formation: entry.formationId,
        score: Number(entry.score.toFixed(2)),
      }));
      plannerState.set(profile?.id ?? profile?.name ?? 'unknown', planner);
    }

    return scored.map((item) => ({
      type: 'summon',
      deckIndex: item.idx,
      slot: item.slot,
      trace: `${ACTION_TRACE_PREFIX}:enemy:summon:${item.name}:slot-${item.slot}:${item.formationId}`,
    }));
  }

  if ((profile?.summons?.length ?? 0) > 0) {
    const template = profile.summons[0];
    const slotPick = chooseSummonSlot(stateLike, template, formationChoice);
    return [{ type: 'summon', slot: slotPick.slot, trace: `${ACTION_TRACE_PREFIX}:enemy:summon-template:${formationChoice.formation.id}` }];
  }

  return [];
}

function pruneActionsByGain(stateLike, actions, side, profile, maxActions = 12) {
  if (!actions.length) return [];

  const base = neuralStateScore(stateLike, profile);
  const cfg = difficultyConfig(profile?.difficultyBand);
  const scored = [];

  for (const action of actions) {
    const after = applySideAction(stateLike, side, action, profile);
    if (!after) continue;
    const noise = (Math.random() - 0.5) * (cfg.randomness ?? 0) * 3.2;
    const gain = neuralStateScore(after, profile) - base + quickAttackBonus(stateLike, after, action) + noise;
    scored.push({ action, gain });
  }

  scored.sort((a, b) => b.gain - a.gain);
  return scored.slice(0, maxActions).map((entry) => entry.action);
}

function enumerateEnemyActions(stateLike, profile, config) {
  const attackActions = makeAttackActions(stateLike, 'enemy');
  const summons = (stateLike?.enemyHand?.length ?? 0) > 0 ? [] : makeSummonActions(stateLike, profile, config.summonBranchLimit);
  const plays = makeCardPlayActions(stateLike, profile, config.cardBranchLimit);

  const prunedAttacks = pruneActionsByGain(
    stateLike,
    attackActions,
    'enemy',
    profile,
    config.attackBranchLimit,
  );

  const actions = [...prunedAttacks, ...summons, ...plays];
  actions.push({ type: 'pass', trace: `${ACTION_TRACE_PREFIX}:enemy:pass` });
  return actions;
}

function enumeratePlayerActions(stateLike, profile, config) {
  const attackActions = makeAttackActions(stateLike, 'player');
  const pruned = pruneActionsByGain(stateLike, attackActions, 'player', profile, config.playerBranchLimit);
  pruned.push({ type: 'pass', trace: `${ACTION_TRACE_PREFIX}:player:pass` });
  return pruned;
}

function simulatePlayerCounterplay(stateLike, profile, config) {
  let current = cloneState(stateLike);

  for (let depth = 0; depth < config.counterDepth; depth += 1) {
    const actions = enumeratePlayerActions(current, profile, config);
    let bestAction = { type: 'pass', trace: `${ACTION_TRACE_PREFIX}:player:no-op` };
    let bestState = current;
    let bestScore = neuralStateScore(current, profile);

    for (const action of actions) {
      const after = applySideAction(current, 'player', action, profile);
      if (!after) continue;
      const score = neuralStateScore(after, profile);
      if (score < bestScore) {
        bestScore = score;
        bestAction = action;
        bestState = after;
      }
    }

    current = bestState;
    if (bestAction.type === 'pass') break;
    if ((current.enemyHealth ?? 0) <= 0 || (current.playerHealth ?? 0) <= 0) break;
  }

  return current;
}

function planActionScore(rootState, terminalState, afterCounter, actions, profile) {
  const enriched = profile?.aiBiases ? profile : enrichAiProfile(profile, [...(rootState?.enemyDeck ?? []), ...(rootState?.enemyHand ?? [])]);
  const bias = enriched.aiBiases ?? AI_ARCHETYPES.tyrant.biases;
  const cfg = difficultyConfig(enriched.difficultyBand);
  const preCounter = neuralStateScore(terminalState, profile);
  const postCounter = neuralStateScore(afterCounter, profile);
  const terminalEval = stateEvaluationBreakdown(terminalState, enriched);
  const counterEval = stateEvaluationBreakdown(afterCounter, enriched);

  const boardDiff = (terminalState.enemyMinions.length - rootState.enemyMinions.length) - (terminalState.playerMinions.length - rootState.playerMinions.length);
  const damageToHero = Math.max(0, rootState.playerHealth - terminalState.playerHealth);
  const selfDamage = Math.max(0, rootState.enemyHealth - terminalState.enemyHealth);
  const spellCount = actions.filter((entry) => entry.type === 'play-card' && entry.cardType !== 'minion').length;
  const summonCount = actions.filter((entry) => entry.type === 'summon' || (entry.type === 'play-card' && entry.cardType === 'minion')).length;

  const stepPenalty = actions.length * 0.35;
  const pressureBonus = damageToHero * bias.face;
  const durabilityBonus = boardDiff * bias.trade;
  const engineBonus = spellCount * bias.combo * 0.7;
  const wideBonus = summonCount * bias.wide * 0.55;
  const lookaheadWeight = clamp(cfg.lookahead ?? 0.6, 0.25, 1);
  const immediateWeight = 1 - (lookaheadWeight * 0.45);
  const evalBlend = (terminalEval.totalScore * immediateWeight) + (counterEval.totalScore * lookaheadWeight);

  return (preCounter * 0.35)
    + (postCounter * 0.65)
    + evalBlend
    + pressureBonus
    + durabilityBonus
    + engineBonus
    + wideBonus
    - (selfDamage * bias.survival)
    - stepPenalty;
}

function sanitizeAction(action) {
  if (action.type === 'attack-hero') {
    return { type: action.type, attackerId: action.attackerId, trace: action.trace };
  }
  if (action.type === 'attack-minion') {
    return {
      type: action.type,
      attackerId: action.attackerId,
      targetId: action.targetId,
      trace: action.trace,
    };
  }
  if (action.type === 'summon') {
    const sanitized = {
      type: action.type,
      deckIndex: action.deckIndex,
      trace: action.trace,
    };
    if (Number.isInteger(action.slot)) sanitized.slot = action.slot;
    return sanitized;
  }
  if (action.type === 'play-card') {
    const sanitized = {
      type: action.type,
      handIndex: action.handIndex,
      cardType: action.cardType,
      trace: action.trace,
    };
    if (action.rationale?.length) sanitized.rationale = [...action.rationale];
    if (Number.isInteger(action.slot)) sanitized.slot = action.slot;
    if (Number.isInteger(action.lane)) sanitized.lane = action.lane;
    if (action.targetId) sanitized.targetId = action.targetId;
    return sanitized;
  }
  return { type: 'pass', trace: action.trace ?? `${ACTION_TRACE_PREFIX}:pass` };
}

function inferHoldReason(stateLike, profile) {
  if ((stateLike.enemyMinions?.length ?? 0) >= MAX_LANE_SIZE) return 'hold:board-full';
  const attackers = availableAttackers(stateLike, 'enemy');
  if (!attackers.length) return 'hold:no-ready-attackers';
  if (hasTaunt(stateLike.playerMinions)) return 'hold:enemy-taunt-gate';
  if ((stateLike.enemyDeck?.length ?? 0) <= 3) return 'hold:deck-nearly-empty';
  const formation = chooseFormation(profile, stateLike, false).formation;
  if (formation?.id === 'stagger-screen' || formation?.id === 'trap-funnel') return `hold:formation-${formation.id}`;
  return 'hold:line-not-favorable';
}

function neuralConfig(profile) {
  const enriched = enrichAiProfile(profile, profile?.deck ?? profile?.summons ?? []);
  const cfg = difficultyConfig(enriched.difficultyBand);
  return {
    maxDepth: cfg.maxDepth,
    beamWidth: cfg.beamWidth,
    attackBranchLimit: cfg.attackBranchLimit,
    summonBranchLimit: cfg.summonBranchLimit,
    cardBranchLimit: cfg.cardBranchLimit,
    counterDepth: cfg.counterDepth,
    playerBranchLimit: cfg.playerBranchLimit,
    candidateShortlist: cfg.candidateShortlist,
    randomness: cfg.randomness,
    comboDiscipline: cfg.comboDiscipline,
    lookahead: cfg.lookahead,
  };
}

function neuralTurnPlan(state, profile) {
  const cfg = neuralConfig(profile);
  const root = cloneState(state);
  const key = profile?.id ?? profile?.name ?? 'unknown';
  const enriched = profile?.aiBiases ? profile : enrichAiProfile(profile, [...(state?.enemyDeck ?? []), ...(state?.enemyHand ?? []), ...(profile?.deck ?? []), ...(profile?.summons ?? [])]);

  let frontier = [{
    sim: root,
    actions: [],
    score: neuralStateScore(root, enriched),
  }];
  const terminals = [];

  for (let depth = 0; depth < cfg.maxDepth; depth += 1) {
    const expanded = [];

    for (const node of frontier) {
      if ((node.sim.playerHealth ?? 0) <= 0 || (node.sim.enemyHealth ?? 0) <= 0) {
        terminals.push(node);
        continue;
      }

      const options = enumerateEnemyActions(node.sim, profile, cfg);
      let madeChild = false;

      for (const action of options) {
        if (action.type === 'pass') {
          terminals.push(node);
          continue;
        }

        const after = applySideAction(node.sim, 'enemy', action, profile);
        if (!after) continue;

        madeChild = true;
        const actionGain = neuralStateScore(after, profile) - neuralStateScore(node.sim, profile) + quickAttackBonus(node.sim, after, action);
        expanded.push({
          sim: after,
          actions: [...node.actions, sanitizeAction(action)],
          score: node.score + actionGain,
        });
      }

      if (!madeChild) terminals.push(node);
    }

    if (!expanded.length) break;

    expanded.sort((a, b) => b.score - a.score);
    frontier = expanded.slice(0, cfg.beamWidth);

    const lethal = frontier.find((entry) => (entry.sim.playerHealth ?? 0) <= 0);
    if (lethal) {
      terminals.push(lethal);
      break;
    }
  }

  terminals.push(...frontier);

  let best = null;
  let bestScore = -Infinity;

  for (const candidate of terminals) {
    const afterCounter = simulatePlayerCounterplay(candidate.sim, enriched, cfg);
    const score = planActionScore(root, candidate.sim, afterCounter, candidate.actions, enriched);
    if (score > bestScore) {
      bestScore = score;
      best = candidate;
    }
  }

  const current = plannerState.get(key) ?? {};
  const candidateSummary = terminals
    .map((candidate) => {
      const afterCounter = simulatePlayerCounterplay(candidate.sim, enriched, cfg);
      const score = planActionScore(root, candidate.sim, afterCounter, candidate.actions, enriched);
      const evalBreakdown = stateEvaluationBreakdown(candidate.sim, enriched);
      return {
        actions: candidate.actions.map((entry) => entry.trace ?? entry.type).slice(0, 6),
        rationale: candidate.actions.flatMap((entry) => entry.rationale ?? []).slice(0, 6),
        score: Number(score.toFixed(2)),
        pressure: Math.max(0, root.playerHealth - candidate.sim.playerHealth),
        survival: Number((((candidate.sim.enemyHealth ?? 0) - boardStats(candidate.sim, 'player').readyAttack)).toFixed(2)),
        predictedLethal: !!evalBreakdown.predictedLethal,
        threatenedLethal: !!evalBreakdown.threatenedLethal,
        boardValue: evalBreakdown.boardValueScore,
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, cfg.candidateShortlist ?? 12);

  if (!best || best.actions.length === 0) {
    plannerState.set(key, {
      ...current,
      candidateSummary,
      selectedWhy: 'no-action-positive-ev',
      evaluation: {
        enemyHealth: root.enemyHealth,
        playerHealth: root.playerHealth,
        enemyMana: root.enemyMana ?? root.maxMana ?? 0,
        enemyHand: (root.enemyHand ?? []).length,
        ...stateEvaluationBreakdown(root, enriched),
      },
    });
    return [{ type: 'pass', trace: `${ACTION_TRACE_PREFIX}:enemy:no-plan` }];
  }

  plannerState.set(key, {
    ...current,
    candidateSummary,
    selectedWhy: candidateSummary[0]?.actions?.join(' -> ') ?? 'best-plan',
    selectedPlanScore: Number(bestScore.toFixed(2)),
    evaluation: {
      enemyHealth: root.enemyHealth,
      playerHealth: root.playerHealth,
      enemyMana: root.enemyMana ?? root.maxMana ?? 0,
      enemyHand: (root.enemyHand ?? []).length,
      boardValue: Number((neuralStateScore(root, enriched)).toFixed(2)),
      archetype: enriched.aiArchetype,
      difficulty: enriched.difficultyBand,
      deckIdentity: enriched.deckIdentity?.primary ?? 'unknown',
      ...stateEvaluationBreakdown(root, enriched),
    },
  });

  return best.actions;
}

function bestTradeTarget(state) {
  if (state.playerMinions.length === 0) return null;
  return [...state.playerMinions].sort((a, b) => (b.attack + b.health) - (a.attack + a.health))[0];
}

function bestFaceAttacker(state) {
  const attackers = availableAttackers(state, 'enemy');
  return attackers.sort((a, b) => (b.attack ?? 0) - (a.attack ?? 0))[0] ?? null;
}

function canLethalHero(state, attacker) {
  return !hasTaunt(state.playerMinions) && attacker && (attacker.attack ?? 0) >= state.playerHealth;
}

function legacyAction(state, profile) {
  const weights = profile?.weights ?? {};
  const strategy = profile?.strategy ?? 'default';
  const enemyAttacker = bestFaceAttacker(state);

  if (canLethalHero(state, enemyAttacker)) {
    return { type: 'attack-hero', attackerId: enemyAttacker.id, trace: 'legacy:lethal-check' };
  }

  if (profile?.boss && state.bossMode && (profile.script ?? []).includes('shadow-roar') && Math.random() < 0.4) {
    return { type: 'boss-roar', trace: 'legacy:script:shadow-roar' };
  }

  if (strategy === 'aggro' && enemyAttacker && !hasTaunt(state.playerMinions) && Math.random() < 0.75) {
    return { type: 'attack-hero', attackerId: enemyAttacker.id, trace: 'legacy:aggro:push-face' };
  }

  if (state.enemyMinions.length < MAX_LANE_SIZE && Math.random() < (weights.summon ?? 0.2)) {
    const summon = makeSummonActions(state, profile, 1)[0];
    if (summon) return { ...summon, trace: `${summon.trace}:legacy` };
  }

  if (enemyAttacker && state.playerMinions.length > 0 && Math.random() < (weights.trade ?? 0.5)) {
    const target = bestTradeTarget(state);
    if (target) {
      return {
        type: 'attack-minion',
        attackerId: enemyAttacker.id,
        targetId: target.id,
        trace: `legacy:weighted:trade:${strategy}`,
      };
    }
  }

  if (enemyAttacker && !hasTaunt(state.playerMinions) && Math.random() < (weights.attackFace ?? 0.2)) {
    return { type: 'attack-hero', attackerId: enemyAttacker.id, trace: `legacy:weighted:attack-face:${strategy}` };
  }

  return { type: 'pass', trace: `legacy:fallback:pass:${strategy}` };
}

function pickLegacyAttackAction(state, profile) {
  const attackers = availableAttackers(state, 'enemy');
  if (!attackers.length) return null;
  const tauntTargets = state.playerMinions.filter((m) => m.taunt);
  const lowLevel = clamp(profile?.level ?? 1, 1, 99) <= 5;
  const useRandom = lowLevel && Math.random() < 0.45;
  const attacker = useRandom
    ? pickRandom(attackers)
    : [...attackers].sort((a, b) => (b.attack ?? 0) - (a.attack ?? 0))[0];
  if (!attacker) return null;

  if (tauntTargets.length > 0) {
    const target = useRandom
      ? pickRandom(tauntTargets)
      : [...tauntTargets].sort((a, b) => ((b.attack ?? 0) + (b.health ?? 0)) - ((a.attack ?? 0) + (a.health ?? 0)))[0];
    if (!target) return null;
    return {
      type: 'attack-minion',
      attackerId: attacker.id,
      targetId: target.id,
      trace: `legacy:taunt-target:${profile?.strategy ?? 'default'}`,
    };
  }

  const faceBias = clamp((profile?.weights?.attackFace ?? 0.3) + (lowLevel ? 0.2 : 0), 0.12, 0.88);
  if (Math.random() < faceBias) {
    return { type: 'attack-hero', attackerId: attacker.id, trace: `legacy:attack-hero:${profile?.strategy ?? 'default'}` };
  }

  const targetPool = state.playerMinions;
  if (!targetPool.length) {
    return { type: 'attack-hero', attackerId: attacker.id, trace: `legacy:empty-lane-face:${profile?.strategy ?? 'default'}` };
  }
  const target = useRandom
    ? pickRandom(targetPool)
    : bestTradeTarget(state);
  if (!target) return null;
  return {
    type: 'attack-minion',
    attackerId: attacker.id,
    targetId: target.id,
    trace: `legacy:attack-minion:${profile?.strategy ?? 'default'}`,
  };
}

function legacyTurnPlan(state, profile) {
  let sim = cloneState(state);
  const plan = [];

  if (profile?.boss && state.bossMode && (profile.script ?? []).includes('shadow-roar') && Math.random() < 0.22) {
    plan.push({ type: 'boss-roar', trace: 'legacy:script:shadow-roar' });
  }

  const summonChance = clamp(profile?.weights?.summon ?? 0.35, 0.08, 0.96);
  if ((sim.enemyMinions?.length ?? 0) < MAX_LANE_SIZE && Math.random() < summonChance) {
    const summon = makeSummonActions(sim, profile, 1)[0];
    if (summon) {
      const afterSummon = applySideAction(sim, 'enemy', summon, profile);
      if (afterSummon) {
        plan.push({ ...summon, trace: `${summon.trace}:legacy-plan` });
        sim = afterSummon;
      }
    }
  }

  const maxAttacks = Math.max(1, Math.min(6, availableAttackers(sim, 'enemy').length + 1));
  for (let i = 0; i < maxAttacks; i += 1) {
    const attack = pickLegacyAttackAction(sim, profile);
    if (!attack) break;
    const afterAttack = applySideAction(sim, 'enemy', attack, profile);
    if (!afterAttack) break;
    plan.push(attack);
    sim = afterAttack;
    if ((profile?.level ?? 1) <= 5 && Math.random() < 0.2) break;
  }

  if (plan.length > 0) return plan;
  const fallback = legacyAction(state, profile);
  return [fallback ?? { type: 'pass', trace: 'legacy:empty-pass' }];
}

function usesNeuralPlanner(profile) {
  const profileName = String(profile?.name ?? '').toLowerCase();
  return profile?.tacticProfile === 'neural-network'
    || profile?.id === 'nivinis'
    || profile?.id === 'neural-ai'
    || profileName === 'neural ai';
}

export function chooseTurnPlan(state, profile) {
  if (!profile) return [{ type: 'pass', trace: 'no-profile' }];
  const enriched = enrichAiProfile(profile, [...(state?.enemyDeck ?? []), ...(state?.enemyHand ?? []), ...(profile?.deck ?? []), ...(profile?.summons ?? [])]);
  chooseFormation(enriched, state, true);

  const plan = neuralTurnPlan(state, enriched);
  const key = enriched?.id ?? enriched?.name ?? 'unknown';
  const current = plannerState.get(key) ?? {};
  plannerState.set(key, {
    ...current,
    archetypeId: enriched.aiArchetype,
    archetypeName: enriched.aiArchetypeName,
    difficultyBand: enriched.difficultyBand,
    deckIdentity: enriched.deckIdentity,
    currentFormation: current.formationId,
    planPreview: plan.map((entry) => entry.trace ?? entry.type).slice(0, 6),
    holdReason: plan.every((entry) => entry.type === 'pass') ? inferHoldReason(state, profile) : null,
  });
  return plan;
}

export function getThinkDelay(profile) {
  const [minMs, maxMs] = profile?.thinkMsRange ?? [350, 750];
  const clampedMin = Math.max(250, minMs);
  const clampedMax = Math.min(2200, Math.max(clampedMin + 50, maxMs));
  return Math.floor(Math.random() * (clampedMax - clampedMin + 1)) + clampedMin;
}

export function getThinkingLine(profile) {
  return pickRandom(thinkingLinesFor(profile));
}

export function chooseAction(state, profile) {
  if (!profile) return { type: 'pass', trace: 'no-profile' };
  const plan = chooseTurnPlan(state, profile);
  return plan[0] ?? { type: 'pass', trace: `${ACTION_TRACE_PREFIX}:fallback` };
}

export function createSummon(profile) {
  const template = pickRandom(profile?.summons ?? []);
  if (!template) return null;
  return {
    id: uid('enemy'),
    name: template.name,
    attack: template.attack,
    health: template.health,
    taunt: !!template.taunt,
    defense: false,
    race: extractCardRaces(template)[0] ?? template.race ?? 'neutral',
    races: extractCardRaces(template),
    element: template.element ?? 'none',
    statuses: {},
    rarity: template.rarity ?? 'rare',
    allowMultiAttack: !!template.allowMultiAttack,
    allowFriendlyAttack: !!template.allowFriendlyAttack,
    charge: !!template.charge,
    text: template.text ?? '',
    tags: Array.isArray(template.tags) ? [...template.tags] : [],
    keywords: Array.isArray(template.keywords) ? [...template.keywords] : [],
  };
}

export function getPlannerDebug(profileId) {
  if (!profileId) return null;
  const snapshot = plannerState.get(profileId);
  if (!snapshot) return null;
  return JSON.parse(JSON.stringify(snapshot));
}

export {
  nCk,
  cardsSeenByTurn,
  pAtLeastOne,
  pAtLeastK,
  pBothAtLeastOne,
  deriveRoleTags,
  VALID_AI_ARCHETYPES,
};

