@echo off
setlocal
cd /d "%~dp0"

set "CF_URL=http://localhost:8080/"
if /I "%~1"=="game" set "CF_URL=http://localhost:8080/game/"
if /I "%~1"=="launcher" set "CF_URL=http://localhost:8080/"

echo [update_cardex] rebuilding card index...
python tools\update_cardex.py
if errorlevel 1 (
  echo [update_cardex] warning: rebuild failed, continuing with existing cardex.
)

echo Starting CardForge on %CF_URL%
start "" python -c "import time,webbrowser; time.sleep(1.0); webbrowser.open(r'%CF_URL%')"
python -u -m http.server 8080
endlocal
