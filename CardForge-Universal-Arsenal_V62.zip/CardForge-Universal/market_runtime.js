(function initCardForgeMarketRuntime(global) {
  'use strict';

  const RELATION_BANDS = [
    { key: 'hostile', min: -100, max: -60, label: 'Hostile', buyModifier: 1.18, sellModifier: 0.82, slots: -2, rarityShift: -2, rejectionTolerance: 10 },
    { key: 'wary', min: -59, max: -20, label: 'Wary', buyModifier: 1.10, sellModifier: 0.90, slots: -1, rarityShift: -1, rejectionTolerance: 12 },
    { key: 'neutral', min: -19, max: 19, label: 'Neutral', buyModifier: 1.00, sellModifier: 1.00, slots: 0, rarityShift: 0, rejectionTolerance: 15 },
    { key: 'favorable', min: 20, max: 59, label: 'Favorable', buyModifier: 0.94, sellModifier: 1.06, slots: 1, rarityShift: 1, rejectionTolerance: 15 },
    { key: 'allied', min: 60, max: 89, label: 'Allied', buyModifier: 0.88, sellModifier: 1.12, slots: 2, rarityShift: 2, rejectionTolerance: 16 },
    { key: 'patron', min: 90, max: 100, label: 'Patron', buyModifier: 0.82, sellModifier: 1.18, slots: 3, rarityShift: 3, rejectionTolerance: 18 },
  ];

  const TRADER_ARCHETYPES = {
    port_trader: { id: 'port_trader', label: 'Port Trader', buySpread: 1.10, sellFactor: 0.67, tolerance: 0.15, routeClass: 'port', theme: 'port' },
    trade_ship: { id: 'trade_ship', label: 'Trade Ship', buySpread: 1.14, sellFactor: 0.63, tolerance: 0.12, routeClass: 'ship', theme: 'merchant' },
    collector_guild: { id: 'collector_guild', label: 'Collector Guild', buySpread: 1.18, sellFactor: 0.70, tolerance: 0.10, specialtyBonus: 0.15, routeClass: 'guild', theme: 'collector' },
    black_market: { id: 'black_market', label: 'Black Market', buySpread: 1.38, sellFactor: 0.52, tolerance: 0.20, routeClass: 'smuggler', theme: 'blackmarket' },
    relic_broker: { id: 'relic_broker', label: 'Relic Broker', buySpread: 1.14, sellFactor: 0.68, tolerance: 0.14, specialtyBonus: 0.12, routeClass: 'broker', theme: 'relic' },
    beast_wrangler: { id: 'beast_wrangler', label: 'Beast Wrangler', buySpread: 1.12, sellFactor: 0.69, tolerance: 0.14, specialtyBonus: 0.12, routeClass: 'caravan', theme: 'beast' },
    military_surplus: { id: 'military_surplus', label: 'Military Surplus', buySpread: 1.13, sellFactor: 0.66, tolerance: 0.14, specialtyBonus: 0.12, routeClass: 'convoy', theme: 'war' },
  };

  const PLAYER_STANCE_BANDS = [
    { key: 'hostile', min: -100, max: -60, label: 'Hostile' },
    { key: 'wary', min: -59, max: -20, label: 'Wary' },
    { key: 'neutral', min: -19, max: 19, label: 'Neutral' },
    { key: 'favorable', min: 20, max: 59, label: 'Favorable' },
    { key: 'allied', min: 60, max: 89, label: 'Allied' },
    { key: 'patron', min: 90, max: 100, label: 'Patron' },
  ];

  const FACTION_RELATION_BANDS = [
    { key: 'at_war', min: -100, max: -76, label: 'At War' },
    { key: 'hostile', min: -75, max: -41, label: 'Hostile' },
    { key: 'distrustful', min: -40, max: -11, label: 'Distrustful' },
    { key: 'neutral', min: -10, max: 24, label: 'Neutral' },
    { key: 'allied', min: 25, max: 69, label: 'Allied' },
    { key: 'sworn', min: 70, max: 100, label: 'Sworn Allies' },
  ];

  const LEADER_REQUESTS = {
    improved_trade: { id: 'improved_trade', label: 'Improved Trade Terms', threshold: -10, effect: 'trade-charter' },
    ceasefire: { id: 'ceasefire', label: 'Ceasefire Petition', threshold: -35, effect: 'ceasefire' },
    alliance_talks: { id: 'alliance_talks', label: 'Alliance Talks', threshold: 35, effect: 'alliance-talks' },
    tribute_terms: { id: 'tribute_terms', label: 'Tribute / Trade Terms', threshold: -20, effect: 'tribute-terms' },
    special_stock: { id: 'special_stock', label: 'Special Stock Access', threshold: 20, effect: 'premium-access' },
    forgiveness: { id: 'forgiveness', label: 'Forgiveness Petition', threshold: -55, effect: 'forgiveness' },
  };

  const FACTION_LEADERS = {
    'free-ports-consortium': { name: 'Admiral Seris Vale', title: 'Harbormaster Prime', icon: '⚓', demeanor: 'Measured', summary: 'Balances tariffs, access, and legal safe lanes.' },
    'crimson-ledger-guild': { name: 'Archivist Roen', title: 'Chief Ledgermaster', icon: '✦', demeanor: 'Exacting', summary: 'Tracks value leakage and remembers every unfair bargain.' },
    'azure-route-syndicate': { name: 'Captain Ilvara Kesh', title: 'Route Marshal', icon: '⬡', demeanor: 'Pragmatic', summary: 'Keeps long-haul routes open through calculated risk.' },
    'ashwake-smugglers': { name: 'Smokesaint Rhex', title: 'Shadow Broker', icon: '☄', demeanor: 'Predatory', summary: 'Rewards bold theft and punishes hesitation.' },
    'cathedral-exchange': { name: 'Prelate Ys', title: 'Exchange Canon', icon: '✧', demeanor: 'Ceremonial', summary: 'Frames commerce as sacred stewardship.' },
    'beastbone-caravan': { name: 'Kara Bonespur', title: 'Trail Matron', icon: '♞', demeanor: 'Wary', summary: 'Trades in living cargo, trophies, and instinct.' },
    'iron-convoy-union': { name: 'Marshal Dorn Vex', title: 'Convoy Superintendent', icon: '▣', demeanor: 'Martial', summary: 'Moves armored freight and remembers every raid.' },
    'mirrorglass-collectors': { name: 'Curator Sel-Mir', title: 'Glass Regent', icon: '◇', demeanor: 'Discerning', summary: 'Values rare curation and despises crude extraction.' },
    'tidal-coin-assembly': { name: 'Tide Comptroller Olyss', title: 'Wave Chancellor', icon: '◈', demeanor: 'Calm', summary: 'Keeps maritime exchanges stable across moving fronts.' },
    'eclipse-cartel': { name: 'Prince Noct Fane', title: 'Cartel Proxy', icon: '☾', demeanor: 'Silken', summary: 'Trades prestige, leverage, and deniable cargo.' },
  };

  const FACTION_RELATION_SEEDS = {
    'free-ports-consortium': { 'azure-route-syndicate': 52, 'tidal-coin-assembly': 46, 'crimson-ledger-guild': 18, 'iron-convoy-union': 14, 'ashwake-smugglers': -70, 'eclipse-cartel': -58 },
    'crimson-ledger-guild': { 'mirrorglass-collectors': 38, 'cathedral-exchange': 18, 'free-ports-consortium': 18, 'ashwake-smugglers': -36, 'eclipse-cartel': -28 },
    'azure-route-syndicate': { 'free-ports-consortium': 52, 'tidal-coin-assembly': 58, 'iron-convoy-union': 16, 'ashwake-smugglers': -48, 'eclipse-cartel': -34 },
    'ashwake-smugglers': { 'eclipse-cartel': 62, 'free-ports-consortium': -70, 'azure-route-syndicate': -48, 'cathedral-exchange': -44, 'iron-convoy-union': -38 },
    'cathedral-exchange': { 'crimson-ledger-guild': 18, 'mirrorglass-collectors': 20, 'ashwake-smugglers': -44, 'eclipse-cartel': -42, 'beastbone-caravan': 8 },
    'beastbone-caravan': { 'tidal-coin-assembly': 16, 'cathedral-exchange': 8, 'iron-convoy-union': -18, 'mirrorglass-collectors': -8 },
    'iron-convoy-union': { 'free-ports-consortium': 14, 'azure-route-syndicate': 16, 'ashwake-smugglers': -38, 'eclipse-cartel': -32, 'beastbone-caravan': -18 },
    'mirrorglass-collectors': { 'crimson-ledger-guild': 38, 'cathedral-exchange': 20, 'tidal-coin-assembly': 10, 'beastbone-caravan': -8, 'eclipse-cartel': -26 },
    'tidal-coin-assembly': { 'azure-route-syndicate': 58, 'free-ports-consortium': 46, 'beastbone-caravan': 16, 'mirrorglass-collectors': 10, 'ashwake-smugglers': -24 },
    'eclipse-cartel': { 'ashwake-smugglers': 62, 'free-ports-consortium': -58, 'cathedral-exchange': -42, 'iron-convoy-union': -32, 'mirrorglass-collectors': -26 },
  };

  const TRADER_FACTIONS = {
    'free-ports-consortium': {
      id: 'free-ports-consortium',
      name: 'Free Ports Consortium',
      archetype: 'port_trader',
      specialties: ['utility', 'starter', 'staple', 'trade_port', 'common', 'rare'],
      palette: { primary: '#5ec4ff', secondary: '#c6f3ff', glow: 'rgba(94,196,255,0.4)' },
      legal: true,
      emblem: '⚓',
      routeBias: 'civilian',
      stockBias: { common: 1.25, rare: 1.1, epic: 0.8, legendary: 0.55 },
    },
    'crimson-ledger-guild': {
      id: 'crimson-ledger-guild',
      name: 'Crimson Ledger Guild',
      archetype: 'collector_guild',
      specialties: ['epic', 'engine', 'control', 'tutor', 'draw'],
      palette: { primary: '#ff647a', secondary: '#ffd0d5', glow: 'rgba(255,100,122,0.35)' },
      legal: true,
      emblem: '✦',
      routeBias: 'brokerage',
      stockBias: { common: 0.75, rare: 1.0, epic: 1.2, legendary: 1.05 },
    },
    'azure-route-syndicate': {
      id: 'azure-route-syndicate',
      name: 'Azure Route Syndicate',
      archetype: 'trade_ship',
      specialties: ['import', 'collection', 'flying', 'tempo', 'utility'],
      palette: { primary: '#65a6ff', secondary: '#dfe9ff', glow: 'rgba(101,166,255,0.32)' },
      legal: true,
      emblem: '⬡',
      routeBias: 'longhaul',
      stockBias: { common: 1.0, rare: 1.05, epic: 1.0, legendary: 0.9 },
    },
    'ashwake-smugglers': {
      id: 'ashwake-smugglers',
      name: 'Ashwake Smugglers',
      archetype: 'black_market',
      specialties: ['hidden', 'volatile', 'legendary', 'stealth', 'shadow'],
      palette: { primary: '#ff9346', secondary: '#ffe7cc', glow: 'rgba(255,147,70,0.35)' },
      legal: false,
      emblem: '☄',
      routeBias: 'smuggler',
      stockBias: { common: 0.6, rare: 1.0, epic: 1.2, legendary: 1.25 },
    },
    'cathedral-exchange': {
      id: 'cathedral-exchange',
      name: 'Cathedral Exchange',
      archetype: 'relic_broker',
      specialties: ['relic', 'field', 'blessing', 'support', 'heal'],
      palette: { primary: '#ffe591', secondary: '#fff7de', glow: 'rgba(255,229,145,0.34)' },
      legal: true,
      emblem: '✧',
      routeBias: 'sanctified',
      stockBias: { common: 0.85, rare: 1.05, epic: 1.15, legendary: 0.95 },
    },
    'beastbone-caravan': {
      id: 'beastbone-caravan',
      name: 'Beastbone Caravan',
      archetype: 'beast_wrangler',
      specialties: ['beast', 'giant', 'wild', 'rush', 'food-chain'],
      palette: { primary: '#89d37c', secondary: '#e5f8df', glow: 'rgba(137,211,124,0.34)' },
      legal: true,
      emblem: '♞',
      routeBias: 'caravan',
      stockBias: { common: 1.0, rare: 1.0, epic: 1.05, legendary: 0.9 },
    },
    'iron-convoy-union': {
      id: 'iron-convoy-union',
      name: 'Iron Convoy Union',
      archetype: 'military_surplus',
      specialties: ['siege', 'armor', 'vehicle', 'war', 'structure', 'factory'],
      palette: { primary: '#b5c4d6', secondary: '#e7edf5', glow: 'rgba(181,196,214,0.3)' },
      legal: true,
      emblem: '▣',
      routeBias: 'convoy',
      stockBias: { common: 0.95, rare: 1.0, epic: 1.15, legendary: 1.0 },
    },
    'mirrorglass-collectors': {
      id: 'mirrorglass-collectors',
      name: 'Mirrorglass Collectors',
      archetype: 'collector_guild',
      specialties: ['illusion', 'spell', 'legendary', 'collection', 'topdeck'],
      palette: { primary: '#b494ff', secondary: '#efe6ff', glow: 'rgba(180,148,255,0.35)' },
      legal: true,
      emblem: '◇',
      routeBias: 'curator',
      stockBias: { common: 0.65, rare: 0.95, epic: 1.15, legendary: 1.2 },
    },
    'tidal-coin-assembly': {
      id: 'tidal-coin-assembly',
      name: 'Tidal Coin Assembly',
      archetype: 'trade_ship',
      specialties: ['beast', 'water', 'tempo', 'heal', 'flying'],
      palette: { primary: '#5ad7d5', secondary: '#d9fffd', glow: 'rgba(90,215,213,0.32)' },
      legal: true,
      emblem: '◈',
      routeBias: 'maritime',
      stockBias: { common: 1.05, rare: 1.0, epic: 0.95, legendary: 0.85 },
    },
    'eclipse-cartel': {
      id: 'eclipse-cartel',
      name: 'Eclipse Cartel',
      archetype: 'black_market',
      specialties: ['shadow', 'assassin', 'artifact', 'rare', 'legendary'],
      palette: { primary: '#a07cff', secondary: '#f0e8ff', glow: 'rgba(160,124,255,0.35)' },
      legal: false,
      emblem: '☾',
      routeBias: 'hidden',
      stockBias: { common: 0.5, rare: 0.95, epic: 1.2, legendary: 1.3 },
    },
  };

  const RARITY_MULTIPLIERS = { common: 1, rare: 1.22, epic: 1.55, legendary: 2.05 };
  const TYPE_BASE = {
    minion: 8,
    unit: 8,
    beast: 8,
    ship: 8,
    spell: 14,
    relic: 16,
    field: 18,
    structure: 14,
    building: 14,
    token: 0,
  };
  const DEFAULT_MARKET_REFRESH_MS = 60000;
  const DEFAULT_SHIP_SPEED = 0.07;
  const VALUE_CACHE = new Map();

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function toFiniteNumber(value, fallback) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function bandRound(value) {
    const numeric = Math.max(0, toFiniteNumber(value, 0));
    if (numeric < 100) return Math.round(numeric / 5) * 5;
    if (numeric < 300) return Math.round(numeric / 10) * 10;
    return Math.round(numeric / 25) * 25;
  }

  function bandRoundSigned(value) {
    const numeric = toFiniteNumber(value, 0);
    if (!numeric) return 0;
    return Math.sign(numeric) * bandRound(Math.abs(numeric));
  }

  function seededRandom(seed) {
    let t = 0;
    const src = String(seed ?? 'market');
    for (let i = 0; i < src.length; i += 1) t += src.charCodeAt(i) * (i + 1);
    return () => {
      t = (t * 9301 + 49297) % 233280;
      return t / 233280;
    };
  }

  function normalizeText(value) {
    return String(value ?? '')
      .toLowerCase()
      .replace(/[^a-z0-9+\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function uniq(values) {
    return [...new Set((values ?? []).filter(Boolean))];
  }

  function slugify(value) {
    return String(value ?? '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  function takeWords(value, count) {
    return String(value ?? '').split(/\s+/).filter(Boolean).slice(0, count).join(' ');
  }

  function getRarity(card) {
    return String(card?.rarity ?? 'common').toLowerCase();
  }

  function getCost(card) {
    const primary = toFiniteNumber(card?.cost ?? card?.mana ?? card?.manaCost, 0);
    if (primary > 0) return primary;
    const wheat = toFiniteNumber(card?.wheat, 0);
    const iron = toFiniteNumber(card?.iron, 0);
    const mana = toFiniteNumber(card?.mana, 0);
    return wheat + iron + mana;
  }

  function getAttack(card) {
    return Math.max(0, toFiniteNumber(card?.attack ?? card?.atk, 0));
  }

  function getHealth(card) {
    return Math.max(0, toFiniteNumber(card?.health ?? card?.hp, 0));
  }

  function getDefense(card) {
    return Math.max(0, toFiniteNumber(card?.def ?? card?.defense ?? card?.armor ?? card?.shield, 0));
  }

  function getType(card) {
    const explicitType = String(card?.type ?? card?.cardType ?? '').toLowerCase().trim();
    if (explicitType) return explicitType;
    if (card?.relic) return 'relic';
    if (card?.field) return 'field';
    if (card?.structure || card?.building) return 'structure';
    return 'unknown';
  }

  function getRulesText(card) {
    return [
      card?.text,
      card?.description,
      card?.abilityText,
      card?.rulesText,
      card?.effectText,
      card?.flavorText,
      card?.lore,
      typeof card?.ability === 'string' ? card.ability : '',
      typeof card?.effect === 'string' ? card.effect : '',
    ].filter(Boolean).join(' ');
  }

  function getCardTags(card) {
    const tags = [];
    const type = getType(card);
    tags.push(type);
    (Array.isArray(card?.tags) ? card.tags : []).forEach((tag) => tags.push(String(tag).toLowerCase()));
    (Array.isArray(card?.keywords) ? card.keywords : []).forEach((tag) => tags.push(String(tag).toLowerCase()));
    ['race', 'tribe', 'species', 'subtype', 'productionSource', 'collection', 'collectionName', 'faction', 'universe', 'element', 'world'].forEach((key) => {
      if (card?.[key]) tags.push(String(card[key]).toLowerCase());
    });
    ['packSource', 'userPackId'].forEach((key) => {
      if (card?.[key]) tags.push(String(card[key]).toLowerCase());
    });
    (Array.isArray(card?.merchantInclusion) ? card.merchantInclusion : []).forEach((tag) => tags.push(String(tag).toLowerCase()));
    (Array.isArray(card?.market?.merchantInclusion) ? card.market.merchantInclusion : []).forEach((tag) => tags.push(String(tag).toLowerCase()));
    ['taunt', 'rush', 'charge', 'stealth', 'flying', 'lifesteal', 'poisonous', 'divineShield', 'relic', 'field', 'structure', 'building'].forEach((flag) => {
      if (card?.[flag]) tags.push(flag.toLowerCase());
    });
    return uniq(tags);
  }

  function countRegex(text, regex) {
    const match = text.match(regex);
    return match ? match.length : 0;
  }

  function addBreakdown(parts, label, value, meta) {
    if (!Number.isFinite(value) || value === 0) return;
    parts.push({ label, value: Number(value.toFixed(2)), meta: meta || null });
  }

  function detectCollectionId(card) {
    if (card?.collectionId) return slugify(card.collectionId);
    if (card?.collectionName) return slugify(card.collectionName);
    if (card?.collection) return slugify(card.collection);
    if (Array.isArray(card?.associatedPacks) && card.associatedPacks[0]) return slugify(card.associatedPacks[0]);
    if (card?.packType) return slugify(card.packType);
    if (card?.genVersion) return `gen-${slugify(card.genVersion)}`;
    const text = normalizeText(`${card?.name ?? ''} ${card?.bibliography ?? ''}`);
    const collectionMatch = text.match(/([a-z]+\s+[a-z]+)\s+collection/);
    if (collectionMatch) return slugify(collectionMatch[1]);
    return String(card?.id ?? 'misc').split('-').slice(0, 2).join('-') || 'misc';
  }

  function detectSpecialties(card) {
    const tags = getCardTags(card);
    const text = normalizeText(getRulesText(card));
    const specialties = new Set(tags);
    if (/beast|hydra|wyrm|lion|stag|bull|wolf|hound|leviathan/.test(text)) specialties.add('beast');
    if (/relic|field|artifact|shrine|totem/.test(text)) specialties.add('relic');
    if (/vehicle|tank|mech|walker|armor|artillery|siege|turret|barricade/.test(text)) specialties.add('siege');
    if (/heal|restore|blessing|mercy/.test(text)) specialties.add('heal');
    if (/draw|discover|look at the top|reorder|shuffle/.test(text)) specialties.add('draw');
    if (/shadow|stealth|invisible/.test(text)) specialties.add('shadow');
    if (/flying|air|wing/.test(text)) specialties.add('flying');
    return [...specialties];
  }

  function computeCardUtilityBreakdown(card) {
    const parts = [];
    const text = normalizeText(getRulesText(card));
    const tags = getCardTags(card);
    const numbers = [...text.matchAll(/\b(\d+)\b/g)].map((match) => Number(match[1]));
    const biggestNumber = numbers.length ? Math.max(...numbers) : 0;
    const drawCount = countRegex(text, /\bdraw\b/g);
    if (drawCount) addBreakdown(parts, 'Draw', drawCount * 9, `${drawCount}x draw`);
    const discoverCount = countRegex(text, /\bdiscover\b/g);
    if (discoverCount) addBreakdown(parts, 'Discover', discoverCount * 10, `${discoverCount}x discover`);
    const tutorCount = countRegex(text, /search|from your deck|draw a [a-z]+ from your deck|summon a random .* from your deck/g);
    if (tutorCount) addBreakdown(parts, 'Tutor', tutorCount * 14, `${tutorCount}x tutor`);
    const topDeckCount = countRegex(text, /top card|top \d+ cards|look at the top|reorder/g);
    if (topDeckCount) addBreakdown(parts, 'Topdeck Manipulation', topDeckCount * 8, `${topDeckCount}x topdeck`);
    const summonCount = countRegex(text, /\bsummon\b/g);
    if (summonCount) addBreakdown(parts, 'Summon', Math.max(6, summonCount * (6 + clamp(biggestNumber, 0, 4))), `${summonCount}x summon`);
    if (/silence all|all enemy minions lose|all minions lose/.test(text)) addBreakdown(parts, 'Board Silence', 24, 'boardwide silence');
    else if (/\bsilence\b/.test(text)) addBreakdown(parts, 'Silence', 12, 'single target silence');
    if (/destroy|exile|remove from the game/.test(text)) addBreakdown(parts, 'Hard Removal', 18, 'destroy/exile');
    if (/return .* to .* hand|bounce/.test(text)) addBreakdown(parts, 'Bounce', 10, 'return to hand');
    if (/freeze all|freeze two|freeze the attacker/.test(text)) addBreakdown(parts, 'Freeze', /all/.test(text) ? 16 : 8, 'freeze/control');
    const healCount = countRegex(text, /restore|heal/g);
    const healAmount = healCount ? clamp(biggestNumber || 1, 1, 7) : 0;
    if (healCount) addBreakdown(parts, 'Healing', healCount * healAmount * 1.5, `${healCount}x heal`);
    if (/resummon|resurrect|return this to your hand with/.test(text)) addBreakdown(parts, 'Resurrection', 16, 'resurrection');
    const costReduceCount = countRegex(text, /costs?\s*\(\d+\)\s*less|reduce the cost/g);
    if (costReduceCount) addBreakdown(parts, 'Cost Reduction', 10 + Math.max(0, costReduceCount - 1) * 6, `${costReduceCount}x cost reduce`);
    if (/your .* have|friendly .* have|at the end of your turn|at the start of your turn|whenever /.test(text)) addBreakdown(parts, 'Engine / Aura', 10 + (/your .* have|friendly .* have/.test(text) ? 4 : 0), 'persistent engine');
    if (/gain .* gold|gain .* armor|gain .* mana|resource|income|production|draw a card once per turn/.test(text)) addBreakdown(parts, 'Resource Engine', 12, 'resource generation');
    if (/deal \d+ damage to all|all enemy minions|split randomly among enemies/.test(text)) {
      addBreakdown(parts, 'Board Damage', 20 + (clamp(biggestNumber, 1, 7) * 3), 'boardwide damage');
    }

    tags.forEach((tag) => {
      if (tag === 'taunt' || tag === 'guard') addBreakdown(parts, 'Taunt', 5, tag);
      if (tag === 'stealth') addBreakdown(parts, 'Stealth', 6, tag);
      if (tag === 'rush') addBreakdown(parts, 'Rush', 6, tag);
      if (tag === 'charge') addBreakdown(parts, 'Charge', 9, tag);
      if (tag === 'flying') addBreakdown(parts, 'Flying', 6, tag);
      if (tag === 'lifesteal') addBreakdown(parts, 'Lifesteal', 7, tag);
      if (tag === 'poisonous' || tag === 'poison') addBreakdown(parts, 'Poisonous', 10, tag);
    });

    if (/legendary|build around|for the rest of the game|once per turn/.test(text)) addBreakdown(parts, 'Role Modifier', 6, 'build-around');
    if (/copy|duplicate|echo|random .* to your hand/.test(text)) addBreakdown(parts, 'Copy / Echo', 8, 'copy effect');
    if (/adjacent|minions? on each side/.test(text)) addBreakdown(parts, 'Splash / Cleave', 6, 'multi-target');
    if (/counter|cancel the next enemy spell/.test(text)) addBreakdown(parts, 'Counterplay', 12, 'counter/cancel');

    const score = parts.reduce((sum, part) => sum + part.value, 0);
    return { score, parts };
  }

  function cardCacheKey(card) {
    return [
      card?.id ?? card?.name ?? 'anon',
      getType(card),
      getCost(card),
      getAttack(card),
      getHealth(card),
      getDefense(card),
      getRarity(card),
      normalizeText(getRulesText(card)),
      getCardTags(card).join('|'),
    ].join('::');
  }

  function computeCardBaseValue(card) {
    const explicitBaseValue = toFiniteNumber(card?.market?.baseValue ?? card?.baseValue, 0);
    if (explicitBaseValue > 0) {
      return {
        baseValue: bandRound(explicitBaseValue),
        cost: getCost(card),
        atk: getAttack(card),
        hp: getHealth(card),
        def: getDefense(card),
        rarity: getRarity(card),
        type: getType(card),
        statCore: 0,
        efficiencyMultiplier: 1,
        costScore: 0,
        typeBase: 0,
        utilityScore: 0,
        roleModifier: 0,
        rawBase: explicitBaseValue,
        rarityMultiplier: 1,
        breakdown: [
          { label: 'Explicit Base Value', value: bandRound(explicitBaseValue), meta: 'user pack override' },
        ],
      };
    }
    const key = cardCacheKey(card);
    if (VALUE_CACHE.has(key)) return VALUE_CACHE.get(key);
    const cost = Math.max(0, getCost(card));
    const atk = getAttack(card);
    const hp = getHealth(card);
    const def = getDefense(card);
    const rarity = getRarity(card);
    const type = getType(card);
    const statCore = (atk * 7) + (hp * 5) + (def * 4);
    const efficiencyMultiplier = 0.9 + (Math.min(cost, 10) * 0.08);
    const costScore = cost * 9;
    const typeBase = TYPE_BASE[type] ?? 10;
    const utility = computeCardUtilityBreakdown(card);
    const roleModifier = clamp(
      (detectSpecialties(card).filter((tag) => ['legendary', 'artifact', 'siege', 'heal', 'shadow', 'beast', 'flying'].includes(tag)).length * 1.5)
      + (/once per turn|for the rest of the game|whenever you cast/.test(normalizeText(getRulesText(card))) ? 4 : 0),
      0,
      18,
    );
    const rawBase = 18 + costScore + (statCore * efficiencyMultiplier) + typeBase + utility.score + roleModifier;
    const rarityMultiplier = RARITY_MULTIPLIERS[rarity] ?? 1;
    const baseValue = bandRound(rawBase * rarityMultiplier);
    const payload = {
      baseValue,
      cost,
      atk,
      hp,
      def,
      rarity,
      type,
      statCore,
      efficiencyMultiplier,
      costScore,
      typeBase,
      utilityScore: utility.score,
      roleModifier,
      rawBase,
      rarityMultiplier,
      breakdown: [
        { label: 'Cost Score', value: Number(costScore.toFixed(2)) },
        { label: 'Stat Core', value: Number((statCore * efficiencyMultiplier).toFixed(2)), meta: `${statCore} x ${efficiencyMultiplier.toFixed(2)}` },
        { label: 'Type Base', value: typeBase, meta: type },
        ...utility.parts,
        { label: 'Role Modifier', value: Number(roleModifier.toFixed(2)) },
        { label: 'Rarity Multiplier', value: Number(rarityMultiplier.toFixed(2)), meta: rarity },
      ],
    };
    VALUE_CACHE.set(key, payload);
    return payload;
  }

  function getRelationMeta(score) {
    const numeric = clamp(toFiniteNumber(score, 0), -100, 100);
    return RELATION_BANDS.find((band) => numeric >= band.min && numeric <= band.max) ?? RELATION_BANDS[2];
  }

  function buildMarketContext(card, marketState, faction, trader) {
    const collectionId = detectCollectionId(card);
    const rarity = getRarity(card);
    const collectionDemand = toFiniteNumber(marketState?.marketIndices?.collections?.[collectionId], 1);
    const rarityDemand = toFiniteNumber(marketState?.marketIndices?.rarities?.[rarity], 1);
    const eventModifier = toFiniteNumber(marketState?.marketIndices?.events?.global, 1);
    const regionModifier = toFiniteNumber(trader?.regionModifier ?? trader?.marketBias?.regionModifier, 1);
    const stockPressure = clamp(toFiniteNumber(trader?.stockPressure, 1), 0.8, 1.3);
    const relationScore = toFiniteNumber(marketState?.relations?.[faction?.id ?? trader?.factionId] ?? 0, 0);
    const relationMeta = getRelationMeta(relationScore);
    const diplomacyModifier = clamp((relationMeta.sellModifier + relationMeta.buyModifier) / 2, 0.82, 1.18);
    const specialties = detectSpecialties(card);
    const specialtyHits = specialties.filter((tag) => (faction?.specialties ?? []).includes(tag) || (trader?.specialties ?? []).includes(tag)).length;
    const specialtyModifier = 1 + Math.min(0.3, specialtyHits * toFiniteNumber(TRADER_ARCHETYPES[trader?.traderType ?? faction?.archetype]?.specialtyBonus, 0.05));
    const marketIndex = clamp(collectionDemand * rarityDemand * regionModifier * eventModifier * stockPressure * diplomacyModifier, 0.65, 1.85);
    return {
      collectionId,
      rarity,
      collectionDemand,
      rarityDemand,
      regionModifier,
      eventModifier,
      stockPressure,
      diplomacyModifier,
      specialtyModifier,
      marketIndex,
      relationMeta,
      relationScore,
    };
  }

  function computeMarketPrice(card, marketState, trader) {
    const faction = TRADER_FACTIONS[trader?.factionId] ?? null;
    const base = computeCardBaseValue(card);
    const ctx = buildMarketContext(card, marketState, faction, trader);
    const archetype = TRADER_ARCHETYPES[trader?.traderType ?? faction?.archetype ?? 'port_trader'] ?? TRADER_ARCHETYPES.port_trader;
    const tradeValue = bandRound(base.baseValue * ctx.marketIndex * ctx.specialtyModifier);
    const explicitBuyValue = toFiniteNumber(card?.market?.buyValue ?? card?.buyValue, 0);
    const explicitSellValue = toFiniteNumber(card?.market?.sellValue ?? card?.sellValue, 0);
    const buyValue = explicitBuyValue > 0
      ? bandRound(explicitBuyValue)
      : bandRound(tradeValue * archetype.buySpread * ctx.relationMeta.buyModifier);
    const sellValue = explicitSellValue > 0
      ? bandRound(explicitSellValue)
      : bandRound(tradeValue * archetype.sellFactor * ctx.relationMeta.sellModifier);
    return {
      ...base,
      ...ctx,
      traderType: archetype.id,
      traderLabel: archetype.label,
      tradeValue,
      buyValue,
      sellValue,
      prestige: clamp(Math.round((base.baseValue / 75) + (RARITY_MULTIPLIERS[getRarity(card)] ?? 1)), 1, 5),
    };
  }

  function sumOfferValues(entries, trader, marketState, cardIndex) {
    return (entries ?? []).reduce((totals, entry) => {
      const card = typeof entry.card === 'object' ? entry.card : cardIndex?.[entry.cardId];
      if (!card) return totals;
      const priced = computeMarketPrice(card, marketState, trader);
      const count = Math.max(1, toFiniteNumber(entry.count, 1));
      totals.baseValue += priced.baseValue * count;
      totals.tradeValue += priced.tradeValue * count;
      totals.buyValue += priced.buyValue * count;
      totals.sellValue += priced.sellValue * count;
      return totals;
    }, {
      baseValue: 0,
      tradeValue: 0,
      buyValue: 0,
      sellValue: 0,
    });
  }

  function evaluateTradeOffer(playerCards, traderCards, traderContext, marketState, cardIndex) {
    const trader = traderContext ?? {};
    const archetype = TRADER_ARCHETYPES[trader.traderType ?? 'port_trader'] ?? TRADER_ARCHETYPES.port_trader;
    const faction = TRADER_FACTIONS[trader.factionId] ?? null;
    const playerTotals = sumOfferValues(playerCards, trader, marketState, cardIndex);
    const traderTotals = sumOfferValues(traderCards, trader, marketState, cardIndex);
    const playerTradeValue = bandRound(playerTotals.tradeValue);
    const traderTradeValue = bandRound(traderTotals.tradeValue);
    const playerSellValue = bandRound(playerTotals.sellValue);
    const traderBuyValue = bandRound(traderTotals.buyValue);
    const denom = Math.max(1, traderTradeValue);
    const tradeDelta = playerTradeValue - traderTradeValue;
    const fairnessPct = denom ? (tradeDelta / denom) * 100 : 0;
    const specialtyDelta = (faction?.specialties ?? []).some((tag) => (trader.specialties ?? []).includes(tag))
      ? toFiniteNumber(archetype.specialtyBonus, 0)
      : 0;
    const tolerance = archetype.tolerance + specialtyDelta;
    let status = 'rejected';
    if (Math.abs(fairnessPct) <= 5) status = 'fair';
    else if (Math.abs(fairnessPct) <= 10) status = 'acceptable';
    else if (Math.abs(fairnessPct) <= (tolerance * 100)) status = 'unfavorable';
    const relationMeta = getRelationMeta(toFiniteNumber(marketState?.relations?.[trader.factionId] ?? 0, 0));
    const hardLimit = Math.max(5, relationMeta.rejectionTolerance);
    const accepted = Math.abs(fairnessPct) <= hardLimit || trader.traderType === 'black_market';
    return {
      playerValue: playerSellValue,
      traderValue: traderBuyValue,
      playerTradeValue,
      traderTradeValue,
      playerSellValue,
      traderBuyValue,
      fairnessPct: Number(fairnessPct.toFixed(2)),
      deltaValue: bandRoundSigned(tradeDelta),
      status,
      accepted,
      tolerancePct: hardLimit,
    };
  }

  function createDefaultMarketState() {
    return {
      traderFactions: {},
      relations: {},
      activeTraders: [],
      tradeShips: [],
      marketIndices: {
        global: 1,
        collections: {},
        rarities: { common: 1, rare: 1, epic: 1, legendary: 1 },
        events: { global: 1 },
        history: [],
      },
      priceHistory: {},
      collectionIndices: {},
      collectionHistory: {},
      factionTradeHistory: {},
      playerProfitHistory: [],
      relationHistory: {},
      newsFeed: [],
      incidentFeed: [],
      activeDemands: [],
      routeHeat: {},
      lastMarketTickAt: 0,
      lastDemandRotationAt: 0,
      watchedCards: [],
    };
  }

  function ensureRelationMaps(marketState) {
    Object.values(TRADER_FACTIONS).forEach((faction) => {
      if (!marketState.traderFactions[faction.id]) {
        marketState.traderFactions[faction.id] = {
          id: faction.id,
          name: faction.name,
          legal: faction.legal,
          specialties: [...faction.specialties],
          emblem: faction.emblem,
          palette: { ...faction.palette },
          archetype: faction.archetype,
          leader: { ...(FACTION_LEADERS[faction.id] ?? { name: 'Unknown Leader', title: 'Unknown Office', icon: faction.emblem ?? '◈', demeanor: 'Unknown', summary: 'No diplomatic dossier yet.' }) },
        };
      }
      if (!Number.isFinite(marketState.relations[faction.id])) marketState.relations[faction.id] = 0;
      if (!Array.isArray(marketState.relationHistory[faction.id])) marketState.relationHistory[faction.id] = [];
    });
    marketState.incidentFeed = Array.isArray(marketState.incidentFeed) ? marketState.incidentFeed : [];
  }

  function createDefaultWarState() {
    return {
      disabled: true,
      playerWars: {},
      factionWars: {},
      pendingDeclarations: [],
      notifications: [],
      eventLog: [],
      alliedJoinHooks: true,
    };
  }

  function getFactionDiplomacyMeta(score) {
    const numeric = clamp(toFiniteNumber(score, 0), -100, 100);
    return FACTION_RELATION_BANDS.find((entry) => numeric >= entry.min && numeric <= entry.max) ?? FACTION_RELATION_BANDS[3];
  }

  function ensureFactionRelationshipMatrix(diplomacy) {
    diplomacy.factionRelations = diplomacy.factionRelations && typeof diplomacy.factionRelations === 'object'
      ? diplomacy.factionRelations
      : {};
    const factionIds = Object.keys(TRADER_FACTIONS);
    factionIds.forEach((factionId) => {
      const row = diplomacy.factionRelations[factionId] && typeof diplomacy.factionRelations[factionId] === 'object'
        ? diplomacy.factionRelations[factionId]
        : {};
      factionIds.forEach((otherId) => {
        if (factionId === otherId) {
          row[otherId] = 100;
          return;
        }
        const seeded = Number(FACTION_RELATION_SEEDS[factionId]?.[otherId]);
        const mirrored = Number(FACTION_RELATION_SEEDS[otherId]?.[factionId]);
        const fallback = Number.isFinite(seeded) ? seeded : Number.isFinite(mirrored) ? mirrored : 0;
        if (!Number.isFinite(row[otherId])) row[otherId] = clamp(fallback, -100, 100);
      });
      diplomacy.factionRelations[factionId] = row;
    });
  }

  function ensureCampaignDiplomacyState(profile, marketState) {
    const campaign = profile.mapWorld.campaign;
    const diplomacy = campaign.diplomacy && typeof campaign.diplomacy === 'object'
      ? campaign.diplomacy
      : {};
    diplomacy.relations = diplomacy.relations && typeof diplomacy.relations === 'object' ? diplomacy.relations : {};
    diplomacy.transactionCounters = diplomacy.transactionCounters && typeof diplomacy.transactionCounters === 'object' ? diplomacy.transactionCounters : {};
    diplomacy.embargoes = diplomacy.embargoes && typeof diplomacy.embargoes === 'object' ? diplomacy.embargoes : {};
    diplomacy.flags = diplomacy.flags && typeof diplomacy.flags === 'object' ? diplomacy.flags : {};
    diplomacy.meetingHistory = Array.isArray(diplomacy.meetingHistory) ? diplomacy.meetingHistory : [];
    diplomacy.incidentLog = Array.isArray(diplomacy.incidentLog) ? diplomacy.incidentLog : [];
    diplomacy.warState = diplomacy.warState && typeof diplomacy.warState === 'object'
      ? { ...createDefaultWarState(), ...diplomacy.warState }
      : createDefaultWarState();
    ensureFactionRelationshipMatrix(diplomacy);
    Object.keys(TRADER_FACTIONS).forEach((factionId) => {
      if (!Number.isFinite(diplomacy.relations[factionId])) diplomacy.relations[factionId] = toFiniteNumber(marketState.relations[factionId], 0);
      if (!Number.isFinite(marketState.relations[factionId])) marketState.relations[factionId] = diplomacy.relations[factionId];
    });
    campaign.diplomacy = diplomacy;
    return diplomacy;
  }

  function pushFactionIncident(profile, factionId, entry) {
    const marketState = profile.mapWorld.campaign.market;
    const diplomacy = profile.mapWorld.campaign.diplomacy;
    const payload = {
      factionId,
      t: Date.now(),
      ...entry,
    };
    pushLimited(marketState.incidentFeed, payload, 24);
    pushLimited(diplomacy.incidentLog, payload, 90);
  }

  function pushRelationHistory(marketState, factionId, score) {
    pushLimited(marketState.relationHistory[factionId] ?? (marketState.relationHistory[factionId] = []), {
      t: Date.now(),
      score,
    }, 60);
  }

  function applyFavorabilityChange(profile, factionId, delta, reason, options) {
    const marketState = ensureMarketState(profile, [], [], Date.now());
    const diplomacy = ensureCampaignDiplomacyState(profile, marketState);
    const numericDelta = bandRoundSigned(delta);
    const directPrev = toFiniteNumber(marketState.relations[factionId], 0);
    const directNext = clamp(directPrev + numericDelta, -100, 100);
    marketState.relations[factionId] = directNext;
    diplomacy.relations[factionId] = directNext;
    pushRelationHistory(marketState, factionId, directNext);
    pushFactionIncident(profile, factionId, {
      type: options?.type ?? 'favorability',
      delta: numericDelta,
      text: reason,
      sourceFactionId: options?.sourceFactionId ?? factionId,
    });

    const ripple = [];
    const alliedFactor = clamp(toFiniteNumber(options?.alliedFactor, 0.35), 0, 1);
    const rivalFactor = clamp(toFiniteNumber(options?.rivalFactor, 0.18), 0, 1);
    if (options?.ripple) {
      Object.entries(diplomacy.factionRelations[factionId] ?? {}).forEach(([otherId, relationScore]) => {
        if (otherId === factionId) return;
        const relation = toFiniteNumber(relationScore, 0);
        let shift = 0;
        if (relation >= 45) shift = Math.round(numericDelta * alliedFactor);
        else if (relation <= -55 && numericDelta < 0) shift = Math.abs(Math.round(numericDelta * rivalFactor));
        if (!shift) return;
        const prev = toFiniteNumber(marketState.relations[otherId], 0);
        const next = clamp(prev + shift, -100, 100);
        marketState.relations[otherId] = next;
        diplomacy.relations[otherId] = next;
        pushRelationHistory(marketState, otherId, next);
        ripple.push({ factionId: otherId, delta: shift, score: next });
      });
    }
    return { factionId, score: directNext, delta: numericDelta, ripple };
  }

  function maybeQueueWarScaffold(profile, factionId, reason) {
    const diplomacy = ensureCampaignDiplomacyState(profile, profile.mapWorld.campaign.market);
    const warState = diplomacy.warState;
    if (!warState.disabled) return null;
    const score = toFiniteNumber(diplomacy.relations[factionId], 0);
    if (score > -65) return null;
    const existing = (warState.pendingDeclarations ?? []).find((entry) => entry?.factionId === factionId && entry?.status === 'dormant');
    if (existing) return existing;
    const allies = Object.entries(diplomacy.factionRelations[factionId] ?? {})
      .filter(([, relation]) => toFiniteNumber(relation, 0) >= 45)
      .map(([otherId]) => otherId);
    const pending = {
      id: `war-${factionId}-${Date.now()}`,
      factionId,
      against: 'player',
      status: 'dormant',
      disabled: true,
      reason,
      allies,
      createdAt: Date.now(),
    };
    pushLimited(warState.pendingDeclarations, pending, 18);
    pushLimited(warState.notifications, {
      id: `notice-${pending.id}`,
      type: 'war-scaffold',
      factionId,
      text: `${TRADER_FACTIONS[factionId]?.name ?? factionId} is approaching open war footing. Execution remains disabled in this build.`,
      createdAt: pending.createdAt,
    }, 18);
    pushLimited(warState.eventLog, pending, 36);
    return pending;
  }

  function pushLimited(array, entry, limit) {
    array.push(entry);
    while (array.length > limit) array.shift();
  }

  function incrementMapCount(target, key, amount) {
    target[key] = toFiniteNumber(target[key], 0) + amount;
  }

  function chooseFactionForNode(node, rand, legalOnly) {
    const pool = Object.values(TRADER_FACTIONS).filter((faction) => !legalOnly || faction.legal);
    if (!pool.length) return Object.values(TRADER_FACTIONS)[0];
    return pool[Math.floor(rand() * pool.length)];
  }

  function findBestPortNodes(nodes) {
    return (nodes ?? [])
      .filter((node) => node && node.id)
      .sort((a, b) => {
        const aScore = (a.playerHome ? 4 : 0) + (a.stateTag === 'playerOwned' ? 3 : 0) + (toFiniteNumber(a.level, 1) * 0.2);
        const bScore = (b.playerHome ? 4 : 0) + (b.stateTag === 'playerOwned' ? 3 : 0) + (toFiniteNumber(b.level, 1) * 0.2);
        return bScore - aScore;
      })
      .slice(0, 8);
  }

  function buildDemandSet(cards, marketState, now) {
    const allCards = Array.isArray(cards) ? cards : [];
    const seed = `${Math.floor(now / DEFAULT_MARKET_REFRESH_MS)}|${allCards.length}|demand`;
    const rand = seededRandom(seed);
    const demandPool = Object.values(TRADER_FACTIONS).map((faction) => {
      const specialty = faction.specialties[Math.floor(rand() * faction.specialties.length)] ?? 'utility';
      return {
        id: `${faction.id}-${slugify(specialty)}-${Math.floor(now / DEFAULT_MARKET_REFRESH_MS)}`,
        factionId: faction.id,
        factionName: faction.name,
        tag: specialty,
        bonus: Number((1.08 + (rand() * 0.18)).toFixed(2)),
        type: 'tag-demand',
        label: `${faction.name} pays premiums on ${specialty} cards.`,
        expiresAt: now + DEFAULT_MARKET_REFRESH_MS,
      };
    });
    const collectionCounts = {};
    allCards.forEach((card) => incrementMapCount(collectionCounts, detectCollectionId(card), 1));
    const topCollections = Object.entries(collectionCounts).sort((a, b) => b[1] - a[1]).slice(0, 4);
    topCollections.forEach(([collectionId], idx) => {
      demandPool.push({
        id: `collection-${collectionId}-${Math.floor(now / DEFAULT_MARKET_REFRESH_MS)}`,
        factionId: Object.values(TRADER_FACTIONS)[idx % Object.keys(TRADER_FACTIONS).length].id,
        factionName: Object.values(TRADER_FACTIONS)[idx % Object.keys(TRADER_FACTIONS).length].name,
        collectionId,
        bonus: Number((1.05 + (rand() * 0.12)).toFixed(2)),
        type: 'collection-demand',
        label: `${takeWords(collectionId.replace(/-/g, ' '), 3)} demand rises on the current routes.`,
        expiresAt: now + DEFAULT_MARKET_REFRESH_MS,
      });
    });
    marketState.activeDemands = demandPool.slice(0, 10);
    marketState.lastDemandRotationAt = now;
  }

  function buildCollectionIndices(cards, marketState) {
    const collections = {};
    (cards ?? []).forEach((card) => {
      const id = detectCollectionId(card);
      if (!collections[id]) collections[id] = { cards: 0, total: 0 };
      const base = computeCardBaseValue(card);
      collections[id].cards += 1;
      collections[id].total += base.baseValue;
    });
    const out = {};
    Object.entries(collections).forEach(([id, bucket]) => {
      const avg = bucket.cards ? bucket.total / bucket.cards : 0;
      out[id] = {
        index: bandRound(avg),
        avgBaseValue: Number(avg.toFixed(2)),
        cards: bucket.cards,
      };
    });
    marketState.collectionIndices = out;
    return out;
  }

  function buildMarketIndices(cards, marketState) {
    const rarityBuckets = { common: 0, rare: 0, epic: 0, legendary: 0 };
    (cards ?? []).forEach((card) => {
      incrementMapCount(rarityBuckets, getRarity(card), 1);
    });
    const total = Math.max(1, Object.values(rarityBuckets).reduce((sum, value) => sum + value, 0));
    Object.keys(rarityBuckets).forEach((rarity) => {
      const share = rarityBuckets[rarity] / total;
      marketState.marketIndices.rarities[rarity] = Number(clamp(1 + ((0.25 - share) * 0.9), 0.82, 1.28).toFixed(2));
    });
    const collectionIndices = buildCollectionIndices(cards, marketState);
    const collectionDemand = {};
    Object.entries(collectionIndices).forEach(([collectionId, bucket]) => {
      collectionDemand[collectionId] = Number(clamp(0.85 + (bucket.avgBaseValue / 320), 0.85, 1.45).toFixed(2));
    });
    (marketState.activeDemands ?? []).forEach((demand) => {
      if (demand.collectionId) {
        collectionDemand[demand.collectionId] = Number(clamp((collectionDemand[demand.collectionId] ?? 1) * demand.bonus, 0.9, 1.8).toFixed(2));
      }
    });
    marketState.marketIndices.collections = collectionDemand;
    const avgGlobal = Object.values(collectionDemand).length
      ? Object.values(collectionDemand).reduce((sum, value) => sum + value, 0) / Object.values(collectionDemand).length
      : 1;
    marketState.marketIndices.global = Number(avgGlobal.toFixed(2));
  }

  function cardMatchesFaction(card, faction, traderType) {
    const tags = detectSpecialties(card);
    const rarity = getRarity(card);
    const archetype = TRADER_ARCHETYPES[traderType] ?? TRADER_ARCHETYPES.port_trader;
    const include = uniq((Array.isArray(card?.merchantInclusion) ? card.merchantInclusion : []).concat(Array.isArray(card?.market?.merchantInclusion) ? card.market.merchantInclusion : [])).map((entry) => String(entry).toLowerCase());
    const exclude = uniq((Array.isArray(card?.merchantExclusion) ? card.merchantExclusion : []).concat(Array.isArray(card?.market?.merchantExclusion) ? card.market.merchantExclusion : [])).map((entry) => String(entry).toLowerCase());
    const factionId = String(faction?.id ?? '').toLowerCase();
    const lowerTraderType = String(traderType ?? '').toLowerCase();
    if (exclude.includes(factionId) || exclude.includes(lowerTraderType)) return 0;
    if (include.length && !(include.includes(factionId) || include.includes(lowerTraderType) || include.includes('all'))) return 0;
    let score = 1;
    tags.forEach((tag) => {
      if ((faction?.specialties ?? []).includes(tag)) score += 2.5;
    });
    score *= toFiniteNumber(faction?.stockBias?.[rarity], 1);
    if (traderType === 'black_market' && (rarity === 'epic' || rarity === 'legendary')) score += 3;
    if (traderType === 'port_trader' && rarity === 'common') score += 1.5;
    if (traderType === 'military_surplus' && tags.includes('siege')) score += 2;
    if (traderType === 'relic_broker' && (tags.includes('relic') || tags.includes('field'))) score += 2;
    if (traderType === 'beast_wrangler' && tags.includes('beast')) score += 2;
    return score * (1 + toFiniteNumber(archetype.specialtyBonus, 0));
  }

  function generateStock(cards, faction, trader, marketState, seed) {
    const allCards = Array.isArray(cards) ? cards.filter((card) => card && card.id) : [];
    const rand = seededRandom(seed);
    const relationMeta = getRelationMeta(toFiniteNumber(marketState.relations[faction.id], 0));
    const slotCount = clamp(
      Math.round(8 + relationMeta.slots + (trader.traderType === 'black_market' ? 1 : 0) + (trader.traderType === 'trade_ship' ? 1 : 0)),
      6,
      16,
    );
    const weighted = allCards
      .map((card) => ({ cardId: card.id, score: cardMatchesFaction(card, faction, trader.traderType) }))
      .filter((entry) => entry.score > 0.25)
      .sort((a, b) => b.score - a.score);
    const pool = [];
    weighted.forEach((entry, idx) => {
      const repeats = clamp(Math.round(entry.score * (idx < 40 ? 2 : 1)), 1, 7);
      for (let i = 0; i < repeats; i += 1) pool.push(entry.cardId);
    });
    const seen = new Set();
    const stock = [];
    while (stock.length < slotCount && pool.length) {
      const pickIndex = Math.floor(rand() * pool.length);
      const cardId = pool[pickIndex];
      pool.splice(pickIndex, 1);
      if (seen.has(cardId)) continue;
      seen.add(cardId);
      stock.push({
        cardId,
        copies: clamp(1 + Math.floor(rand() * (trader.traderType === 'port_trader' ? 3 : 2)), 1, 4),
      });
    }
    return stock;
  }

  function attachManifest(entity, cards) {
    const cardById = Object.fromEntries((cards ?? []).filter((card) => card?.id).map((card) => [card.id, card]));
    entity.manifestPreview = (entity.stock ?? []).slice(0, 4).map((entry) => {
      const card = cardById[entry.cardId];
      return {
        cardId: entry.cardId,
        name: card?.name ?? entry.cardId,
        rarity: getRarity(card),
        type: getType(card),
        copies: Math.max(0, toFiniteNumber(entry.copies, 0)),
      };
    });
    entity.manifestSummary = entity.manifestPreview.map((entry) => `${entry.name} x${entry.copies}`).join(' • ');
    entity.specialtyPreview = uniq((entity.manifestPreview ?? []).flatMap((entry) => [entry.rarity, entry.type])).slice(0, 4);
    return entity;
  }

  function buildPortTrader(node, cards, marketState, now, idx) {
    const rand = seededRandom(`${node.id}|${now}|port|${idx}`);
    const faction = chooseFactionForNode(node, rand, true);
    const trader = {
      id: `port-${node.id}-${faction.id}`,
      kind: 'stationary',
      nodeId: node.id,
      nodeName: node.name,
      factionId: faction.id,
      traderType: 'port_trader',
      name: `${node.name} Port Exchange`,
      subtitle: faction.name,
      stockSeed: `${node.id}|${faction.id}|${Math.floor(now / DEFAULT_MARKET_REFRESH_MS)}`,
      specialties: [...faction.specialties],
      regionModifier: node.playerHome ? 0.96 : 1,
      stockPressure: 1,
      visible: true,
      icon: faction.emblem,
      shipClass: 'Port Ledger',
    };
    trader.stock = generateStock(cards, faction, trader, marketState, trader.stockSeed);
    return attachManifest(trader, cards);
  }

  function buildShipTrader(nodes, cards, marketState, now, idx) {
    const rand = seededRandom(`ship|${idx}|${now}`);
    const factions = Object.values(TRADER_FACTIONS);
    const faction = factions[idx % factions.length];
    const traderType = faction.archetype === 'trade_ship' ? 'trade_ship' : faction.archetype;
    const eligibleNodes = (nodes ?? []).filter((node) => node && node.id);
    const origin = eligibleNodes[Math.floor(rand() * Math.max(1, eligibleNodes.length))] ?? null;
    const destination = eligibleNodes[Math.floor(rand() * Math.max(1, eligibleNodes.length))] ?? origin;
    const ship = {
      id: `ship-${faction.id}-${idx}`,
      kind: 'ship',
      name: `${takeWords(faction.name, 2)} ${['Courier', 'Caravel', 'Convoy', 'Barge', 'Ark', 'Clipper'][idx % 6]}`,
      factionId: faction.id,
      traderType,
      shipClass: ['Clipper', 'Convoy', 'Ark', 'Smuggler', 'Dredger', 'Courier'][idx % 6],
      routeNodeIds: uniq([origin?.id, destination?.id]).filter(Boolean),
      legIndex: 0,
      travelProgress: rand(),
      speed: DEFAULT_SHIP_SPEED + (rand() * 0.025),
      dockedNodeId: null,
      stockSeed: `${faction.id}|${idx}|${Math.floor(now / DEFAULT_MARKET_REFRESH_MS)}`,
      specialties: [...faction.specialties],
      rarityTier: idx % 5 >= 3 ? 'premium' : 'standard',
      visibilityRules: faction.legal ? 'public' : 'conditional',
      regionModifier: 1,
      stockPressure: 1,
      visible: faction.legal || rand() > 0.45,
      icon: faction.emblem,
      routePulse: 0,
      plunderable: traderType === 'trade_ship' || traderType === 'military_surplus' || traderType === 'black_market',
      riskRating: traderType === 'black_market' ? 'critical' : traderType === 'military_surplus' ? 'high' : 'elevated',
      plunderProfile: {
        boosterChance: Number((traderType === 'black_market' ? 0.34 : traderType === 'military_surplus' ? 0.29 : 0.22).toFixed(2)),
        goldMin: traderType === 'black_market' ? 85 : traderType === 'military_surplus' ? 70 : 48,
        goldMax: traderType === 'black_market' ? 170 : traderType === 'military_surplus' ? 150 : 110,
        lifeforceMin: traderType === 'black_market' ? 10 : 0,
        lifeforceMax: traderType === 'black_market' ? 26 : 8,
        favorLoss: traderType === 'black_market' ? -14 : traderType === 'military_surplus' ? -16 : -12,
      },
    };
    ship.stock = generateStock(cards, faction, ship, marketState, ship.stockSeed);
    return attachManifest(ship, cards);
  }

  function ensureActiveTraders(marketState, nodes, cards, now) {
    if (!Array.isArray(marketState.activeTraders) || !marketState.activeTraders.length) {
      const ports = findBestPortNodes(nodes);
      marketState.activeTraders = ports.map((node, idx) => buildPortTrader(node, cards, marketState, now, idx));
      ['collector_guild', 'relic_broker', 'beast_wrangler', 'military_surplus', 'black_market'].forEach((type, idx) => {
        const faction = Object.values(TRADER_FACTIONS).find((entry) => entry.archetype === type) ?? Object.values(TRADER_FACTIONS)[idx];
        const trader = {
          id: `${type}-${faction.id}`,
          kind: 'contact',
          name: `${faction.name}`,
          subtitle: TRADER_ARCHETYPES[type]?.label ?? type,
          factionId: faction.id,
          traderType: type,
          nodeId: ports[idx % Math.max(1, ports.length)]?.id ?? null,
          nodeName: ports[idx % Math.max(1, ports.length)]?.name ?? 'Deep Route',
          stockSeed: `${faction.id}|${type}|${Math.floor(now / DEFAULT_MARKET_REFRESH_MS)}`,
          specialties: [...faction.specialties],
          regionModifier: 1,
          stockPressure: type === 'black_market' ? 1.12 : 1,
          visible: type !== 'black_market' || toFiniteNumber(marketState.relations[faction.id], 0) >= -20,
          icon: faction.emblem,
          shipClass: TRADER_ARCHETYPES[type]?.label ?? type,
        };
        trader.stock = generateStock(cards, faction, trader, marketState, trader.stockSeed);
        marketState.activeTraders.push(attachManifest(trader, cards));
      });
    } else {
      marketState.activeTraders = marketState.activeTraders.map((trader) => attachManifest(trader, cards));
    }
  }

  function ensureTradeShips(marketState, nodes, cards, now) {
    if (!Array.isArray(marketState.tradeShips) || !marketState.tradeShips.length) {
      marketState.tradeShips = new Array(7).fill(null).map((_, idx) => buildShipTrader(nodes, cards, marketState, now, idx));
    } else {
      marketState.tradeShips = marketState.tradeShips.map((ship) => attachManifest(ship, cards));
    }
  }

  function updateTradeShips(marketState, nodes, cards, now, lastTickAt) {
    const nodeIds = new Set((nodes ?? []).map((node) => node.id));
    const dt = Math.max(0.1, (now - lastTickAt) / 1000);
    const routeHeat = {};
    (marketState.tradeShips ?? []).forEach((ship, idx) => {
      ship.routeNodeIds = uniq((ship.routeNodeIds ?? []).filter((nodeId) => nodeIds.has(nodeId)));
      if (ship.routeNodeIds.length < 2) {
        const replacement = buildShipTrader(nodes, cards, marketState, now, idx);
        Object.assign(ship, replacement);
      }
      ship.travelProgress = clamp(toFiniteNumber(ship.travelProgress, 0) + (toFiniteNumber(ship.speed, DEFAULT_SHIP_SPEED) * dt * 0.12), 0, 1);
      const fromNodeId = ship.routeNodeIds[ship.legIndex % ship.routeNodeIds.length];
      const toNodeId = ship.routeNodeIds[(ship.legIndex + 1) % ship.routeNodeIds.length];
      incrementMapCount(routeHeat, `${fromNodeId}|${toNodeId}`, 1);
      if (ship.travelProgress >= 1) {
        ship.legIndex = (ship.legIndex + 1) % ship.routeNodeIds.length;
        ship.travelProgress = 0;
        ship.dockedNodeId = fromNodeId;
        ship.stockPressure = Number(clamp(0.96 + (((idx % 4) + 1) * 0.04), 0.9, 1.2).toFixed(2));
        attachManifest(ship, cards);
      }
      ship.eta = Math.round((1 - ship.travelProgress) / Math.max(0.01, ship.speed));
    });
    marketState.routeHeat = routeHeat;
  }

  function pushHistoryForFeaturedCards(marketState, cardsById, traders, now) {
    const featuredCardIds = uniq([
      ...(traders ?? []).flatMap((trader) => (trader.stock ?? []).slice(0, 4).map((entry) => entry.cardId)),
      ...(marketState.watchedCards ?? []),
    ]);
    featuredCardIds.forEach((cardId) => {
      const card = cardsById[cardId];
      if (!card) return;
      const trader = (traders ?? []).find((entry) => (entry.stock ?? []).some((stock) => stock.cardId === cardId)) ?? traders?.[0];
      if (!marketState.priceHistory[cardId]) marketState.priceHistory[cardId] = [];
      const priced = computeMarketPrice(card, marketState, trader);
      pushLimited(marketState.priceHistory[cardId], {
        t: now,
        tradeValue: priced.tradeValue,
        buyValue: priced.buyValue,
        sellValue: priced.sellValue,
        marketIndex: priced.marketIndex,
      }, 42);
    });
    pushLimited(marketState.marketIndices.history, {
      t: now,
      global: marketState.marketIndices.global,
      rare: marketState.marketIndices.rarities.rare,
      epic: marketState.marketIndices.rarities.epic,
      legendary: marketState.marketIndices.rarities.legendary,
    }, 64);
    Object.entries(marketState.marketIndices?.collections ?? {})
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .forEach(([collectionId, value]) => {
        if (!Array.isArray(marketState.collectionHistory[collectionId])) marketState.collectionHistory[collectionId] = [];
        pushLimited(marketState.collectionHistory[collectionId], {
          t: now,
          value: Number(toFiniteNumber(value, 1).toFixed(3)),
        }, 48);
      });
  }

  function rebuildNews(marketState, now) {
    const news = [];
    (marketState.incidentFeed ?? [])
      .slice(-5)
      .reverse()
      .forEach((entry) => {
        news.push({
          id: entry.id ?? `incident-${entry.t ?? now}-${entry.factionId ?? 'market'}`,
          type: entry.type ?? 'incident',
          text: entry.text,
          t: entry.t ?? now,
        });
      });
    (marketState.activeDemands ?? []).slice(0, 6).forEach((demand) => {
      news.push({
        id: `news-${demand.id}`,
        type: 'demand',
        text: demand.label,
        t: now,
      });
    });
    Object.entries(marketState.routeHeat ?? {})
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .forEach(([routeKey, heat]) => {
        news.push({
          id: `route-${routeKey}`,
          type: 'route',
          text: `Trade traffic intensifies across ${routeKey.replace('|', ' → ')} (${heat} convoy pulses).`,
          t: now,
        });
      });
    marketState.newsFeed = news.slice(0, 12);
  }

  function ensureMarketState(profile, nodes, cards, now) {
    const targetProfile = profile && typeof profile === 'object' ? profile : {};
    targetProfile.economy = targetProfile.economy ?? {};
    targetProfile.economy.gold = toFiniteNumber(targetProfile.economy.gold, 0);
    targetProfile.economy.lifeforce = toFiniteNumber(targetProfile.economy.lifeforce, 0);
    targetProfile.economy.marketLedger = Array.isArray(targetProfile.economy.marketLedger) ? targetProfile.economy.marketLedger : [];
    targetProfile.economy.wishlist = Array.isArray(targetProfile.economy.wishlist) ? targetProfile.economy.wishlist : [];
    targetProfile.economy.watchedCards = Array.isArray(targetProfile.economy.watchedCards) ? targetProfile.economy.watchedCards : [];
    targetProfile.economy.licenses = targetProfile.economy.licenses && typeof targetProfile.economy.licenses === 'object' ? targetProfile.economy.licenses : {};
    targetProfile.mapWorld = targetProfile.mapWorld ?? {};
    targetProfile.mapWorld.campaign = targetProfile.mapWorld.campaign ?? {};
    targetProfile.mapWorld.campaign.market = targetProfile.mapWorld.campaign.market && typeof targetProfile.mapWorld.campaign.market === 'object'
      ? targetProfile.mapWorld.campaign.market
      : createDefaultMarketState();
    targetProfile.mapWorld.campaign.diplomacy = targetProfile.mapWorld.campaign.diplomacy && typeof targetProfile.mapWorld.campaign.diplomacy === 'object'
      ? targetProfile.mapWorld.campaign.diplomacy
      : { relations: {}, transactionCounters: {}, embargoes: {}, flags: {} };
    targetProfile.mapWorld.campaign.tradeShips = Array.isArray(targetProfile.mapWorld.campaign.tradeShips)
      ? targetProfile.mapWorld.campaign.tradeShips
      : targetProfile.mapWorld.campaign.market.tradeShips ?? [];
    const marketState = targetProfile.mapWorld.campaign.market;
    marketState.collectionHistory = marketState.collectionHistory && typeof marketState.collectionHistory === 'object' ? marketState.collectionHistory : {};
    marketState.factionTradeHistory = marketState.factionTradeHistory && typeof marketState.factionTradeHistory === 'object' ? marketState.factionTradeHistory : {};
    marketState.playerProfitHistory = Array.isArray(marketState.playerProfitHistory) ? marketState.playerProfitHistory : [];
    marketState.watchedCards = [...targetProfile.economy.watchedCards];
    ensureRelationMaps(marketState);
    ensureCampaignDiplomacyState(targetProfile, marketState);
    Object.keys(marketState.relations).forEach((factionId) => {
      targetProfile.mapWorld.campaign.diplomacy.relations[factionId] = marketState.relations[factionId];
    });
    if (targetProfile.traderOffer) delete targetProfile.traderOffer;
    const stamp = toFiniteNumber(now, Date.now());
    if (!marketState.lastDemandRotationAt || ((stamp - marketState.lastDemandRotationAt) >= DEFAULT_MARKET_REFRESH_MS)) {
      buildDemandSet(cards, marketState, stamp);
    }
    buildMarketIndices(cards, marketState);
    ensureActiveTraders(marketState, nodes, cards, stamp);
    ensureTradeShips(marketState, nodes, cards, stamp);
    targetProfile.mapWorld.campaign.tradeShips = marketState.tradeShips;
    return marketState;
  }

  function tickMarket(profile, nodes, cards, now) {
    const stamp = toFiniteNumber(now, Date.now());
    const marketState = ensureMarketState(profile, nodes, cards, stamp);
    const lastTickAt = toFiniteNumber(marketState.lastMarketTickAt, stamp);
    if (!marketState.lastDemandRotationAt || ((stamp - marketState.lastDemandRotationAt) >= DEFAULT_MARKET_REFRESH_MS)) {
      buildDemandSet(cards, marketState, stamp);
      marketState.activeTraders = [];
      marketState.tradeShips = [];
      ensureActiveTraders(marketState, nodes, cards, stamp);
      ensureTradeShips(marketState, nodes, cards, stamp);
    }
    updateTradeShips(marketState, nodes, cards, stamp, lastTickAt || stamp);
    pushHistoryForFeaturedCards(
      marketState,
      Object.fromEntries((cards ?? []).filter((card) => card?.id).map((card) => [card.id, card])),
      [...(marketState.activeTraders ?? []), ...(marketState.tradeShips ?? [])],
      stamp,
    );
    rebuildNews(marketState, stamp);
    marketState.lastMarketTickAt = stamp;
    profile.mapWorld.campaign.tradeShips = marketState.tradeShips;
    profile.mapWorld.campaign.diplomacy.relations = { ...(profile.mapWorld.campaign.diplomacy.relations ?? {}), ...marketState.relations };
    return marketState;
  }

  function recordTrade(profile, trader, result) {
    const marketState = ensureMarketState(profile, [], [], Date.now());
    const factionId = trader?.factionId ?? null;
    const diplomacy = ensureCampaignDiplomacyState(profile, marketState);
    diplomacy.transactionCounters = diplomacy.transactionCounters ?? {};
    if (!diplomacy.transactionCounters[factionId]) diplomacy.transactionCounters[factionId] = { fairTrades: 0, demandSales: 0, blackMarketDeals: 0, buyouts: 0 };
    const counters = diplomacy.transactionCounters[factionId];
    const fair = result?.fairness?.status === 'fair';
    if (fair) {
      applyFavorabilityChange(profile, factionId, 2, `${TRADER_FACTIONS[factionId]?.name ?? 'Trader'} logged a fair trade in your favor.`, {
        type: 'trade',
      });
      counters.fairTrades += 1;
    }
    const activeDemandHit = (marketState.activeDemands ?? []).some((demand) => {
      const ids = (result?.playerCards ?? []).map((entry) => entry.cardId);
      return ids.some((cardId) => {
        const card = result.cardsById?.[cardId];
        if (!card) return false;
        return demand.collectionId ? detectCollectionId(card) === demand.collectionId : detectSpecialties(card).includes(demand.tag);
      });
    });
    if (activeDemandHit) {
      applyFavorabilityChange(profile, factionId, 3, `${TRADER_FACTIONS[factionId]?.name ?? 'Trader'} appreciated a demand-aligned sale.`, {
        type: 'demand',
      });
      counters.demandSales += 1;
    }
    if (result?.buyout) {
      applyFavorabilityChange(profile, factionId, -2, `${TRADER_FACTIONS[factionId]?.name ?? 'Trader'} resented a full stock strip.`, {
        type: 'buyout',
      });
      counters.buyouts += 1;
    }
    if (trader?.traderType === 'black_market') {
      ['free-ports-consortium', 'crimson-ledger-guild', 'cathedral-exchange'].forEach((id) => {
        applyFavorabilityChange(profile, id, -2, 'Lawful houses noted your black-market dealings.', {
          type: 'black-market',
        });
      });
      ['ashwake-smugglers', 'eclipse-cartel'].forEach((id) => {
        applyFavorabilityChange(profile, id, 2, 'The underworld approved of your illicit transaction.', {
          type: 'black-market',
        });
      });
      counters.blackMarketDeals += 1;
    }
    pushRelationHistory(marketState, factionId, marketState.relations[factionId]);
    pushLimited(marketState.factionTradeHistory[factionId] ?? (marketState.factionTradeHistory[factionId] = []), {
      t: Date.now(),
      volume: bandRound(toFiniteNumber(result?.fairness?.playerTradeValue, 0) + toFiniteNumber(result?.fairness?.traderTradeValue, 0)),
      mode: result?.mode ?? 'trade',
    }, 60);
    pushLimited(marketState.playerProfitHistory, {
      t: Date.now(),
      delta: bandRoundSigned(toFiniteNumber(result?.currencyDelta, 0)),
      mode: result?.mode ?? 'trade',
      currencyKey: result?.currencyKey ?? 'gold',
    }, 90);
    profile.mapWorld.campaign.diplomacy = diplomacy;
    profile.mapWorld.campaign.market.relations = marketState.relations;
  }

  function requestLeaderMeeting(profile, factionId, requestType) {
    const marketState = ensureMarketState(profile, [], [], Date.now());
    const diplomacy = ensureCampaignDiplomacyState(profile, marketState);
    const leader = FACTION_LEADERS[factionId] ?? { name: 'Unknown Leader', title: 'Unknown Office', icon: '◈' };
    const request = LEADER_REQUESTS[requestType] ?? LEADER_REQUESTS.improved_trade;
    const score = toFiniteNumber(marketState.relations[factionId], 0);
    const accepted = score >= request.threshold;
    let summary = '';
    if (accepted) {
      diplomacy.flags[`${factionId}:${request.effect}`] = Date.now();
      if (requestType === 'special_stock') profile.economy.licenses[factionId] = 'premium-access';
      if (requestType === 'improved_trade') profile.economy.licenses[factionId] = 'trade-charter';
      if (requestType === 'forgiveness') applyFavorabilityChange(profile, factionId, 6, `${leader.name} accepted your request for forgiveness.`, { type: 'meeting' });
      summary = `${leader.name} accepted ${request.label.toLowerCase()}.`;
    } else {
      summary = `${leader.name} refused ${request.label.toLowerCase()} at the current standing.`;
    }
    const meeting = {
      id: `meeting-${factionId}-${Date.now()}`,
      factionId,
      leaderName: leader.name,
      leaderTitle: leader.title,
      requestType,
      accepted,
      score,
      summary,
      t: Date.now(),
    };
    pushLimited(diplomacy.meetingHistory, meeting, 40);
    pushFactionIncident(profile, factionId, {
      type: 'meeting',
      text: summary,
    });
    return meeting;
  }

  function recordPlunder(profile, trader, result) {
    const marketState = ensureMarketState(profile, [], [], Date.now());
    const diplomacy = ensureCampaignDiplomacyState(profile, marketState);
    const factionId = trader?.factionId ?? null;
    if (!factionId) return null;
    const favorLoss = toFiniteNumber(result?.favorLoss, trader?.plunderProfile?.favorLoss ?? -12);
    const relation = applyFavorabilityChange(profile, factionId, favorLoss, `${TRADER_FACTIONS[factionId]?.name ?? 'Faction'} registered a convoy plunder.`, {
      type: 'plunder',
      ripple: true,
      alliedFactor: 0.42,
      rivalFactor: 0.22,
    });
    diplomacy.transactionCounters[factionId] = diplomacy.transactionCounters[factionId] ?? { fairTrades: 0, demandSales: 0, blackMarketDeals: 0, buyouts: 0, plunders: 0 };
    diplomacy.transactionCounters[factionId].plunders = Math.max(0, Number(diplomacy.transactionCounters[factionId].plunders ?? 0)) + 1;
    const pendingWar = maybeQueueWarScaffold(profile, factionId, 'convoy-plunder');
    pushFactionIncident(profile, factionId, {
      type: 'plunder-reward',
      text: result?.summary ?? `${TRADER_FACTIONS[factionId]?.name ?? 'Faction'} convoy plunder resolved.`,
    });
    return {
      relation,
      pendingWar,
    };
  }

  function createSparklineSvg(points, options) {
    const values = Array.isArray(points) ? points.map((entry) => Number(entry)).filter(Number.isFinite) : [];
    const width = Math.max(60, toFiniteNumber(options?.width, 180));
    const height = Math.max(24, toFiniteNumber(options?.height, 48));
    const color = String(options?.color ?? '#7fd5ff');
    if (!values.length) {
      return `<svg viewBox="0 0 ${width} ${height}" class="market-sparkline"><rect width="${width}" height="${height}" rx="10" fill="rgba(255,255,255,0.02)"/><text x="${width / 2}" y="${height / 2}" text-anchor="middle" fill="rgba(255,255,255,0.42)" font-size="10">No data</text></svg>`;
    }
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = Math.max(1, max - min);
    const step = values.length === 1 ? width : width / Math.max(1, values.length - 1);
    const path = values.map((value, idx) => {
      const x = idx * step;
      const y = height - (((value - min) / range) * (height - 10)) - 5;
      return `${idx === 0 ? 'M' : 'L'}${x.toFixed(2)},${y.toFixed(2)}`;
    }).join(' ');
    const area = `${path} L${width},${height} L0,${height} Z`;
    return `<svg viewBox="0 0 ${width} ${height}" class="market-sparkline"><path d="${area}" fill="rgba(127,213,255,0.12)"></path><path d="${path}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
  }

  global.CardForgeMarket = {
    RELATION_BANDS,
    TRADER_ARCHETYPES,
    TRADER_FACTIONS,
    computeCardBaseValue,
    computeCardUtilityBreakdown,
    computeMarketPrice,
    evaluateTradeOffer,
    ensureMarketState,
    tickMarket,
    recordTrade,
    recordPlunder,
    requestLeaderMeeting,
    applyFavorabilityChange,
    getRelationMeta,
    getFactionDiplomacyMeta,
    getFactionLeader: (factionId) => FACTION_LEADERS[factionId] ?? null,
    PLAYER_STANCE_BANDS,
    FACTION_RELATION_BANDS,
    LEADER_REQUESTS,
    detectCollectionId,
    detectSpecialties,
    createSparklineSvg,
    bandRound,
    bandRoundSigned,
    clamp,
    DEFAULT_MARKET_REFRESH_MS,
  };
})(window);
