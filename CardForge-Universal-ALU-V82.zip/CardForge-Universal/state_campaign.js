(function attachCampaignState(global) {
  const clone = typeof global.structuredClone === 'function'
    ? global.structuredClone.bind(global)
    : (value) => JSON.parse(JSON.stringify(value));

  const PAGE_ORDER = [
    'home',
    'map',
    'war-council',
    'deck-vault',
    'forge',
    'market',
    'diplomacy',
    'intel',
    'relics',
    'commander',
    'codex',
    'archives',
    'settings',
  ];

  const PAGE_META = {
    home: { id: 'home', route: '#/command', label: 'Dashboard', icon: '⬢' },
    map: { id: 'map', route: '#/command/map', label: 'Campaign Map', icon: '🜁' },
    'war-council': { id: 'war-council', route: '#/command/war-council', label: 'War Council', icon: '⚔' },
    'deck-vault': { id: 'deck-vault', route: '#/command/deck-vault', label: 'Deck Vault', icon: '🗂' },
    forge: { id: 'forge', route: '#/command/forge', label: 'Forge', icon: '⛭' },
    market: { id: 'market', route: '#/command/market', label: 'Market', icon: '◈' },
    diplomacy: { id: 'diplomacy', route: '#/command/diplomacy', label: 'Diplomacy', icon: '✦' },
    intel: { id: 'intel', route: '#/command/intel', label: 'Intel', icon: '◎' },
    relics: { id: 'relics', route: '#/command/relics', label: 'Relics', icon: '◆' },
    commander: { id: 'commander', route: '#/command/commander', label: 'Commander', icon: '♜' },
    codex: { id: 'codex', route: '#/command/codex', label: 'Codex', icon: '☷' },
    archives: { id: 'archives', route: '#/command/archives', label: 'Archives', icon: '🗃' },
    settings: { id: 'settings', route: '#/command/settings', label: 'Settings', icon: '⚙' },
  };

  const PROFILE_STORAGE_KEY = 'cardforge.profile.v1';
  const CAMPAIGN_NAME_FALLBACK = 'Conquest of the Broken Orbit';
  const COMMANDER_NAME_BY_ELEMENT = {
    fire: 'Ashen Warden',
    flame: 'Ashen Warden',
    light: 'Radiant Marshal',
    shadow: 'Veil Regent',
    void: 'Hollow Princeps',
    water: 'Tidekeeper Voss',
    storm: 'Stormglass Prefect',
    earth: 'Bastion Thane',
    root: 'Rootward Sentinel',
    nature: 'Rootward Sentinel',
    metal: 'Iron Marshal',
    neutral: 'Frontier Strategist',
  };

  const FACTION_NAME_BY_ELEMENT = {
    fire: 'Ember Dominion',
    flame: 'Ember Dominion',
    light: 'Solar Concord',
    shadow: 'Veil Compact',
    void: 'Null Court',
    water: 'Tide Covenant',
    storm: 'Stormglass League',
    earth: 'Stonebound Compact',
    root: 'Rootwatch Enclave',
    metal: 'Iron Bastion',
    neutral: 'Frontier Commonwealth',
  };

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function toNumber(value, fallback = 0) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function toArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function titleCase(value) {
    return String(value ?? '')
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, (char) => char.toUpperCase());
  }

  function formatDeckName(value) {
    const clean = String(value ?? '').trim();
    if (!clean) return 'Unnamed Deck';
    return clean.includes('-') || clean.includes('_') ? titleCase(clean) : clean;
  }

  function routeToPageId(routeHash = '#/command') {
    const route = String(routeHash || '#/command').split('?')[0];
    const parts = route.replace(/^#\//, '').split('/').filter(Boolean);
    if (parts[0] !== 'command') return 'home';
    const page = parts[1] || 'home';
    return PAGE_META[page] ? page : 'home';
  }

  function stableDigest(items = []) {
    return JSON.stringify(items).slice(0, 240);
  }

  function createFallbackProfile() {
    return {
      version: 1,
      settings: {
        sfxVolume: 0.8,
        musicVolume: 0.5,
        reduceMotion: false,
      },
      economy: {
        gold: 1420,
      },
      starterDeckId: 'burning-root-siege',
      mapWorld: {
        createdGalaxies: [],
        dimensionalAttackers: {},
        campaign: {
          selectedWorldId: null,
          lostWorldIds: [],
          worldStates: {},
          eventHistory: [],
          market: {},
          diplomacy: {},
        },
      },
    };
  }

  function ensureProfileShape(profile) {
    const safe = profile && typeof profile === 'object' ? profile : createFallbackProfile();
    safe.settings = safe.settings && typeof safe.settings === 'object' ? safe.settings : {};
    safe.economy = safe.economy && typeof safe.economy === 'object' ? safe.economy : {};
    safe.mapWorld = safe.mapWorld && typeof safe.mapWorld === 'object' ? safe.mapWorld : {};
    safe.mapWorld.createdGalaxies = toArray(safe.mapWorld.createdGalaxies);
    safe.mapWorld.dimensionalAttackers = safe.mapWorld.dimensionalAttackers && typeof safe.mapWorld.dimensionalAttackers === 'object'
      ? safe.mapWorld.dimensionalAttackers
      : {};
    safe.mapWorld.campaign = safe.mapWorld.campaign && typeof safe.mapWorld.campaign === 'object'
      ? safe.mapWorld.campaign
      : {};
    safe.mapWorld.campaign.selectedWorldId = safe.mapWorld.campaign.selectedWorldId ?? null;
    safe.mapWorld.campaign.lostWorldIds = toArray(safe.mapWorld.campaign.lostWorldIds);
    safe.mapWorld.campaign.worldStates = safe.mapWorld.campaign.worldStates && typeof safe.mapWorld.campaign.worldStates === 'object'
      ? safe.mapWorld.campaign.worldStates
      : {};
    safe.mapWorld.campaign.eventHistory = toArray(safe.mapWorld.campaign.eventHistory);
    safe.mapWorld.campaign.market = safe.mapWorld.campaign.market && typeof safe.mapWorld.campaign.market === 'object'
      ? safe.mapWorld.campaign.market
      : {};
    safe.mapWorld.campaign.diplomacy = safe.mapWorld.campaign.diplomacy && typeof safe.mapWorld.campaign.diplomacy === 'object'
      ? safe.mapWorld.campaign.diplomacy
      : {};
    return safe;
  }

  function loadCampaignProfile() {
    if (typeof global.loadProfile === 'function') {
      try {
        const live = global.loadProfile();
        if (live) return ensureProfileShape(live);
      } catch {}
    }
    try {
      const raw = global.localStorage?.getItem(PROFILE_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') return ensureProfileShape(parsed);
      }
    } catch {}
    return ensureProfileShape(createFallbackProfile());
  }

  function worldStabilityWeight(state = '') {
    const key = String(state || 'stable').toLowerCase();
    if (key === 'calm' || key === 'stable') return 0.88;
    if (key === 'strained') return 0.62;
    if (key === 'troubled') return 0.36;
    if (key === 'crisis') return 0.14;
    return 0.72;
  }

  function threatBand(percent) {
    if (percent >= 76) return { label: 'Invasion Imminent', tone: 'danger' };
    if (percent >= 51) return { label: 'Dangerous', tone: 'warning' };
    if (percent >= 26) return { label: 'Unstable', tone: 'warning' };
    return { label: 'Calm', tone: 'good' };
  }

  function saveProfileIfPossible(profile) {
    try {
      if (typeof global.saveProfile === 'function') {
        global.saveProfile(profile);
        return true;
      }
      global.localStorage?.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
      return true;
    } catch {
      return false;
    }
  }

  function ensureCommandCenterMeta(profile) {
    const mapWorld = global.getMapWorldFast?.(profile) ?? profile?.mapWorld ?? {};
    const campaign = mapWorld.campaign ?? (mapWorld.campaign = {});
    const existing = campaign.commandCenter && typeof campaign.commandCenter === 'object' ? campaign.commandCenter : {};
    const next = {
      campaignId: String(existing.campaignId ?? 'campaign_001'),
      campaignName: String(existing.campaignName ?? CAMPAIGN_NAME_FALLBACK),
      turn: Math.max(1, Math.floor(toNumber(existing.turn, 12))),
      currentPage: PAGE_META[existing.currentPage]?.id ?? 'home',
      selectedWorldId: existing.selectedWorldId ?? campaign.selectedWorldId ?? null,
      introDigest: String(existing.introDigest ?? ''),
      introMessage: String(existing.introMessage ?? ''),
      lastSummary: Array.isArray(existing.lastSummary) ? existing.lastSummary.slice(-8) : [],
      saveState: String(existing.saveState ?? 'synced'),
      commandLog: Array.isArray(existing.commandLog) ? existing.commandLog.slice(-24) : [],
    };
    campaign.commandCenter = next;
    return next;
  }

  function currentWorldSummary(profile, preferredWorldId = null) {
    const owned = (global.conquestOwnedCapitalWorlds?.(profile) ?? []).filter(Boolean);
    const chosen = (preferredWorldId && global.findCampaignWorld?.(profile, preferredWorldId))
      || global.findCampaignWorld?.(profile, profile?.mapWorld?.campaign?.selectedWorldId)
      || owned[0]
      || Object.values(profile?.mapWorld?.campaign?.worldStates ?? {}).find(Boolean)
      || null;
    if (!chosen) return null;
    const capital = global.capitalPlanetFromWorldState?.(chosen) ?? null;
    if (typeof global.ensureConquestAttackWorldState === 'function') {
      try { global.ensureConquestAttackWorldState(chosen, null); } catch {}
    }
    if (typeof global.applyPlanetEconomy === 'function') {
      try { global.applyPlanetEconomy(chosen); } catch {}
    }
    const attackState = chosen.conquestAttack ?? (typeof global.defaultConquestAttackState === 'function' ? global.defaultConquestAttackState(chosen, capital, chosen.conquestAttack) : {});
    if (typeof global.conquestEnsureDepthState === 'function') {
      try { global.conquestEnsureDepthState(chosen, attackState, capital); } catch {}
    }
    const supply = typeof global.defaultConquestSupplyState === 'function'
      ? global.defaultConquestSupplyState(attackState?.supply)
      : { status: 'stable', score: 0.8, reinforcementReadiness: 0.8, healingFactor: 0.8 };
    const selectedDeck = toArray(attackState?.attackDecks).find((entry) => String(entry?.id) === String(attackState?.selectedAttackDeckId ?? ''))
      ?? toArray(attackState?.attackDecks)[0]
      ?? null;
    const deckSummary = typeof global.conquestAttackDeckSummary === 'function'
      ? global.conquestAttackDeckSummary(selectedDeck?.cards ?? [], profile)
      : { size: selectedDeck?.cards?.length ?? 0, avgCost: 0, warnings: [] };
    const commandBonuses = typeof global.conquestPlanetCommandBonuses === 'function'
      ? global.conquestPlanetCommandBonuses(capital)
      : {};
    const materials = attackState?.resources?.materials ?? {};
    const totalWarResources = Object.values(materials).reduce((sum, value) => sum + toNumber(value, 0), 0);
    const salvageTokens = Math.max(0, Number(attackState?.salvage?.tokens ?? 0));
    const relicFragments = Object.values(attackState?.relics?.fragments ?? {}).reduce((sum, value) => sum + toNumber(value, 0), 0);
    return {
      world: chosen,
      capital,
      attackState,
      supply,
      selectedDeck,
      deckSummary,
      commandBonuses,
      totalWarResources,
      salvageTokens,
      relicFragments,
      blackMarketAvailable: !!commandBonuses.smuggler || !!capital?.blackMarketAvailable,
    };
  }

  function deriveFaction(worldInfo, meta) {
    const capital = worldInfo?.capital;
    const world = worldInfo?.world;
    const primary = String(capital?.primaryElement ?? 'neutral').toLowerCase();
    const secondary = String(capital?.secondaryElement ?? 'colorless').toLowerCase();
    const seededName = titleCase(world?.factionId ?? world?.ownerName ?? '');
    const fallbackName = FACTION_NAME_BY_ELEMENT[primary] ?? FACTION_NAME_BY_ELEMENT.neutral;
    return {
      id: String(world?.factionId ?? primary ?? 'frontier-commonwealth'),
      name: seededName && seededName !== 'Neutral' ? seededName : fallbackName,
      colors: [primary, secondary].filter(Boolean),
      banner: `banner-${primary}`,
      reputationTitle: String(meta.reputationTitle ?? (toNumber(worldInfo?.supply?.score, 0.8) > 0.9 ? 'Resolute' : 'Feared')),
      icon: (global.conquestElementMeta?.(primary)?.glyph) ?? '⬢',
    };
  }

  function deriveCommander(worldInfo, faction, meta) {
    const capital = worldInfo?.capital;
    const primary = String(capital?.primaryElement ?? 'neutral').toLowerCase();
    return {
      id: String(meta.commanderId ?? `commander-${primary}`),
      name: String(meta.commanderName ?? COMMANDER_NAME_BY_ELEMENT[primary] ?? COMMANDER_NAME_BY_ELEMENT.neutral),
      level: Math.max(1, Math.round(toNumber(meta.commanderLevel, 8))),
      title: String(meta.commanderTitle ?? `Breaker of ${capital?.name ?? worldInfo?.world?.worldName ?? 'Pale Orbit'}`),
      portrait: String(meta.commanderPortrait ?? `commander-${primary}.png`),
      skillPoints: Math.max(0, Math.round(toNumber(meta.skillPoints, 2))),
      equippedRelics: toArray(meta.equippedRelics).length ? toArray(meta.equippedRelics) : toArray(worldInfo?.attackState?.relics?.assembled).slice(-2).map((entry) => entry?.name ?? entry?.id).filter(Boolean),
      factionName: faction.name,
      colorIdentity: faction.colors,
    };
  }

  function buildActiveDeck(worldInfo, profile) {
    const deck = worldInfo?.selectedDeck;
    const summary = worldInfo?.deckSummary ?? {};
    const warnings = toArray(summary.warnings).slice(0, 3).map((entry) => String(entry));
    const rules = deck?.rules ?? {};
    const targetSize = Math.max(1, Number(rules.targetSize ?? rules.maxSize ?? summary.size ?? deck?.cards?.length ?? 40));
    return {
      id: String(deck?.id ?? profile?.starterDeckId ?? 'starter-attack-deck'),
      name: formatDeckName(deck?.name ?? profile?.starterDeckId ?? 'Burning Root Siege'),
      cardCount: Math.max(0, Number(summary.size ?? deck?.cards?.length ?? 0)),
      maxCards: targetSize,
      averageCost: Number(summary.avgCost ?? 0),
      archetypes: toArray(deck?.branchNotes).slice(0, 2).length ? toArray(deck.branchNotes).slice(0, 2) : [deck?.subtitle ?? 'Counter Combat', 'Flame Pressure'].filter(Boolean),
      warnings,
      health: warnings.length ? 'Needs Attention' : 'Stable',
      volatility: clamp(toNumber(summary.avgCost, 0) / 5.5, 0, 1),
      supplyDependence: clamp((toNumber(summary.typeCounts?.relic, 0) + toNumber(summary.typeCounts?.support, 0)) / Math.max(1, toNumber(summary.size, 1)), 0, 1),
    };
  }

  function buildThreatMetrics(profile, worldInfo, threats) {
    const mapWorld = global.getMapWorldFast?.(profile) ?? profile?.mapWorld ?? {};
    const attackers = typeof global.getDimensionalAttackers === 'function'
      ? global.getDimensionalAttackers(mapWorld)
      : { invasionProgress: 0, pirateInfamy: 0, activePirates: [] };
    const highestWorldPressure = worldInfo
      ? clamp((toNumber(worldInfo.supply?.localThreatPressure, 0) + toNumber(worldInfo.supply?.globalThreatPressure, 0)) * 100, 0, 100)
      : 0;
    const activeThreatCount = toArray(threats).filter(Boolean).length;
    const threatPct = clamp(Math.round(Math.max(
      toNumber(attackers.invasionProgress, 0),
      toNumber(attackers.pirateInfamy, 0),
      highestWorldPressure,
      activeThreatCount * 9,
    )), 0, 100);
    const mostDangerous = toArray(threats)[0] ?? null;
    return {
      globalThreat: threatPct,
      nextInvasionTurns: Math.max(1, Math.round((100 - toNumber(attackers.invasionProgress, 0)) / 18)),
      mostDangerousRival: mostDangerous?.faction ?? 'No confirmed rival',
      borderUnderPressure: mostDangerous?.region ?? (worldInfo?.capital?.name ?? 'Outer border'),
      band: threatBand(threatPct),
    };
  }

  function buildMarketSummary(profile, worldInfo) {
    const market = profile?.mapWorld?.campaign?.market ?? {};
    const priceModifier = Math.round(((toNumber(market.priceModifier, 1.12) - 1) || 0.12) * 100);
    const hasSmuggler = !!worldInfo?.blackMarketAvailable;
    const stateLabel = hasSmuggler ? 'War Shortage' : 'Watching the routes';
    const newItems = Math.max(0, toArray(market.newsFeed).slice(0, 5).length || 5);
    return {
      state: stateLabel,
      newItems,
      blackMarket: hasSmuggler ? 'Available' : 'Unavailable',
      priceModifier,
      recentNotes: toArray(market.newsFeed).slice(0, 4).map((entry) => entry?.title ?? entry?.text ?? 'Routes quiet.'),
    };
  }

  function buildDiplomacySummary(profile) {
    const diplomacy = profile?.mapWorld?.campaign?.diplomacy ?? {};
    const relations = diplomacy.factionRelations && typeof diplomacy.factionRelations === 'object'
      ? diplomacy.factionRelations
      : {};
    const pairs = Object.entries(relations).map(([id, value]) => ({
      id,
      label: titleCase(id),
      score: toNumber(value?.score ?? value?.relation ?? value, 0),
      status: String(value?.status ?? (toNumber(value?.score ?? value?.relation ?? value, 0) > 30 ? 'Friendly' : toNumber(value?.score ?? value?.relation ?? value, 0) < -20 ? 'Hostile' : 'Suspicious')),
    }));
    const top = pairs.slice(0, 3);
    const pendingOffers = Math.max(0, toArray(diplomacy.meetingHistory).filter((entry) => /offer|pact|envoy/i.test(String(entry?.type ?? entry?.text ?? ''))).length);
    return {
      factions: top.length ? top : [
        { id: 'light-dominion', label: 'Light Dominion', status: 'Suspicious', score: -10 },
        { id: 'void-cartel', label: 'Void Cartel', status: 'Friendly', score: 18 },
        { id: 'iron-syndicate', label: 'Iron Syndicate', status: 'Hostile', score: -28 },
      ],
      pendingOffers,
    };
  }

  function buildProjects(worldInfo) {
    const attackState = worldInfo?.attackState ?? {};
    const researchState = typeof global.defaultConquestResearchState === 'function'
      ? global.defaultConquestResearchState(attackState.research)
      : { activeProjectId: null, completedIds: [], history: [] };
    const projects = [];
    if (researchState.activeProjectId && typeof global.conquestResearchMeta === 'function') {
      const meta = global.conquestResearchMeta(researchState.activeProjectId);
      projects.push({
        id: `research:${researchState.activeProjectId}`,
        type: 'research',
        title: meta?.name ?? titleCase(researchState.activeProjectId),
        status: 'active',
        turnsRemaining: 1,
      });
    }
    toArray(researchState.completedIds).slice(-2).forEach((id) => {
      if (typeof global.conquestResearchMeta !== 'function') return;
      const meta = global.conquestResearchMeta(id);
      projects.push({ id: `complete:${id}`, type: 'research', title: meta?.name ?? titleCase(id), status: 'complete', turnsRemaining: 0 });
    });
    if (!projects.length) {
      projects.push({
        id: 'forge-watch',
        type: 'forge',
        title: 'Forge Watch',
        status: worldInfo?.salvageTokens > 0 ? 'ready' : 'idle',
        turnsRemaining: worldInfo?.salvageTokens > 0 ? 0 : 2,
      });
    }
    return projects.slice(0, 4);
  }

  function buildAlerts(profile, worldInfo, threats, projects, marketSummary, diplomacySummary, threatMetrics) {
    const alerts = [];
    const urgentThreats = toArray(threats).slice(0, 3);
    urgentThreats.forEach((entry) => {
      const severity = entry.dangerTone === 'bad' ? 'urgent' : entry.dangerTone === 'warn' ? 'warning' : 'info';
      alerts.push({
        id: `threat:${entry.id}`,
        severity,
        type: entry.type,
        title: severity === 'urgent' ? 'Incoming Raid' : entry.type === 'anomaly' ? 'Anomaly Signal' : 'Threat Update',
        body: `${entry.name} is pressuring ${entry.region}. ETA ${entry.eta}.`,
        action: { type: 'page', route: '#/command/war-council' },
      });
    });
    const completeProject = toArray(projects).find((entry) => entry.status === 'complete' || entry.status === 'ready');
    if (completeProject) {
      alerts.push({
        id: `project:${completeProject.id}`,
        severity: 'complete',
        type: 'project',
        title: 'Forge Ready',
        body: `${completeProject.title} is ready for collection or redeployment.`,
        action: { type: 'page', route: '#/command/forge' },
      });
    }
    if (toNumber(diplomacySummary.pendingOffers, 0) > 0) {
      alerts.push({
        id: 'diplomacy:pending',
        severity: 'warning',
        type: 'diplomacy',
        title: 'Diplomacy Warning',
        body: `${diplomacySummary.pendingOffers} diplomatic offer(s) are waiting for review.`,
        action: { type: 'page', route: '#/command/diplomacy' },
      });
    }
    alerts.push({
      id: 'market:refresh',
      severity: marketSummary.blackMarket === 'Available' ? 'rare' : 'info',
      type: 'market',
      title: marketSummary.blackMarket === 'Available' ? 'Black Market Contact' : 'Market Update',
      body: `${marketSummary.newItems} fresh market movements. ${marketSummary.blackMarket}.`,
      action: { type: 'page', route: '#/command/market' },
    });
    if (threatMetrics.globalThreat >= 60) {
      alerts.push({
        id: 'threat:global',
        severity: 'urgent',
        type: 'threat',
        title: 'Threat Escalation',
        body: `Global threat has reached ${threatMetrics.globalThreat}%. Border response is recommended.`,
        action: { type: 'page', route: '#/command/war-council' },
      });
    }
    return alerts.slice(0, 8);
  }

  function buildWorldRows(profile) {
    return (global.conquestOwnedCapitalWorlds?.(profile) ?? []).map((world) => {
      const capital = global.capitalPlanetFromWorldState?.(world) ?? null;
      if (typeof global.applyPlanetEconomy === 'function') {
        try { global.applyPlanetEconomy(world); } catch {}
      }
      const supply = typeof global.defaultConquestSupplyState === 'function'
        ? global.defaultConquestSupplyState(world?.conquestAttack?.supply)
        : { status: 'stable', score: 0.8 };
      return {
        worldId: world.worldId,
        name: capital?.name ?? world.worldName,
        systemName: world.worldName,
        stability: String(capital?.stabilityState ?? 'stable'),
        stabilityScore: worldStabilityWeight(capital?.stabilityState),
        income: Math.round(toNumber(capital?.passiveIncomeEffective ?? capital?.passiveIncomeValue ?? world?.economy?.income, 0)),
        readiness: String(supply.status ?? 'stable'),
        pressure: Math.round((toNumber(supply.localThreatPressure, 0) + toNumber(supply.globalThreatPressure, 0)) * 100),
        elements: [capital?.primaryElement, capital?.secondaryElement].filter(Boolean),
      };
    });
  }

  function buildRecommendedActions(profile, worldInfo, activeDeck, threats, projects) {
    const attackState = worldInfo?.attackState ?? {};
    const advice = typeof global.conquestBuildAdvisoryRecommendations === 'function'
      ? global.conquestBuildAdvisoryRecommendations(worldInfo?.world, worldInfo?.capital, attackState, profile)
      : [];
    const mappedAdvice = toArray(advice).slice(0, 3).map((entry) => ({
      id: entry.id,
      title: entry.advisor,
      summary: entry.text,
      reward: 'Campaign momentum',
      action: entry.jump?.type === 'planet'
        ? { type: 'planet', worldId: entry.jump.worldId, planetId: entry.jump.planetId }
        : entry.jump?.type === 'deck'
          ? { type: 'page', route: '#/command/deck-vault' }
          : entry.jump?.type === 'forge'
            ? { type: 'page', route: '#/command/forge' }
            : { type: 'page', route: '#/command/war-council' },
    }));
    const deckWarnings = toArray(activeDeck.warnings).slice(0, 1).map((entry, index) => ({
      id: `deck-warning-${index}`,
      title: 'Edit Active Deck',
      summary: `Current deck warning: ${entry}. Review the attack shell before the next siege.`,
      reward: 'Steadier opening curve',
      action: { type: 'page', route: '#/command/deck-vault' },
    }));
    const projectAction = toArray(projects).find((entry) => entry.status === 'complete' || entry.status === 'ready')
      ? [{ id: 'collect-project', title: 'Collect Forge Project', summary: 'A forge-side project is complete and ready to convert into momentum.', reward: 'Immediate upgrade', action: { type: 'page', route: '#/command/forge' } }]
      : [];
    const threatAction = toArray(threats)[0]
      ? [{ id: 'defend-world', title: `Defend ${toArray(threats)[0].region}`, summary: `${toArray(threats)[0].name} is the sharpest pressure point on the board.`, reward: 'Prevent territory loss', action: { type: 'page', route: '#/command/war-council' } }]
      : [];
    return [...threatAction, ...projectAction, ...mappedAdvice, ...deckWarnings].slice(0, 5);
  }

  function buildWarCouncilState(profile, worldInfo, threats) {
    const attackState = worldInfo?.attackState ?? {};
    const advisors = typeof global.conquestBuildAdvisoryRecommendations === 'function'
      ? global.conquestBuildAdvisoryRecommendations(worldInfo?.world, worldInfo?.capital, attackState, profile).slice(0, 3)
      : [];
    return {
      threatBoard: toArray(threats).slice(0, 8),
      advisors: advisors.map((entry, index) => ({
        id: entry.id ?? `advisor-${index}`,
        advisor: entry.advisor ?? ['Military Advisor', 'Economic Advisor', 'Threat Analyst'][index] ?? 'Advisor',
        text: entry.text,
        action: entry.jump,
      })),
      operations: [
        { id: 'scout-threat', label: 'Scout Threat' },
        { id: 'prepare-assault', label: 'Prepare Assault' },
        { id: 'fortify-world', label: 'Fortify World' },
        { id: 'send-relief', label: 'Send Relief' },
        { id: 'track-convoy', label: 'Track Convoy' },
        { id: 'mark-priority-target', label: 'Mark Priority Target' },
      ],
    };
  }

  function buildRightPanelFeeds(profile, alerts, projects, threats) {
    const campaign = profile?.mapWorld?.campaign ?? {};
    const events = toArray(campaign.eventHistory).slice(-8).reverse().map((entry, index) => ({
      id: `event-${index}`,
      severity: entry?.severity ?? 'info',
      title: `Turn ${entry?.turn ?? ''}`.trim() || 'Campaign Event',
      body: String(entry?.text ?? entry?.label ?? 'No event details.').trim(),
    }));
    const intel = [
      ...toArray(threats).slice(0, 4).map((entry, index) => ({
        id: `intel-threat-${index}`,
        title: `${entry.faction}`,
        body: `${entry.name} targeting ${entry.region}. ${entry.consequence}.`,
      })),
      ...toArray(profile?.mapWorld?.dimensionalAttackers?.pirateDossier).slice(-3).reverse().map((entry, index) => ({
        id: `intel-pirate-${index}`,
        title: entry?.name ?? 'Pirate Dossier',
        body: entry?.notes ?? entry?.summary ?? 'Route behavior updated.',
      })),
    ].slice(0, 8);
    return { alerts, events, projects, intel };
  }

  function buildIntroMessage(state, meta) {
    const urgent = toArray(state.alerts).find((entry) => entry.severity === 'urgent');
    const project = toArray(state.projects).find((entry) => entry.status === 'complete' || entry.status === 'ready');
    const next = urgent
      ? `Commander, ${urgent.body}`
      : project
        ? `Commander, ${project.title} is ready. The forge is waiting on your order.`
        : `Commander, the ${state.commander.factionName} war room is stable. The board is yours.`;
    const digest = stableDigest([urgent?.id ?? '', project?.id ?? '', state.campaignStatus.globalThreat, state.campaignStatus.currentObjective]);
    return {
      message: digest !== meta.introDigest ? next : '',
      digest,
    };
  }

  function buildCommandState(routeHash = '#/command') {
    const profile = loadCampaignProfile();
    global.ensureProfileStats?.(profile);
    const meta = ensureCommandCenterMeta(profile);
    const pageId = routeToPageId(routeHash || PAGE_META[meta.currentPage]?.route || '#/command');
    meta.currentPage = pageId;
    const worldInfo = currentWorldSummary(profile, meta.selectedWorldId);
    if (worldInfo?.world?.worldId) meta.selectedWorldId = worldInfo.world.worldId;
    const faction = deriveFaction(worldInfo, meta);
    const commander = deriveCommander(worldInfo, faction, meta);
    const activeDeck = buildActiveDeck(worldInfo, profile);
    const threats = typeof global.conquestCollectThreatEntries === 'function'
      ? global.conquestCollectThreatEntries(profile, worldInfo?.world).slice(0, 14)
      : [];
    const threatMetrics = buildThreatMetrics(profile, worldInfo, threats);
    const marketSummary = buildMarketSummary(profile, worldInfo);
    const diplomacySummary = buildDiplomacySummary(profile);
    const projects = buildProjects(worldInfo);
    const alerts = buildAlerts(profile, worldInfo, threats, projects, marketSummary, diplomacySummary, threatMetrics);
    const recommendedActions = buildRecommendedActions(profile, worldInfo, activeDeck, threats, projects);
    const worldRows = buildWorldRows(profile);
    const stabilityAverage = worldRows.length
      ? Math.round((worldRows.reduce((sum, row) => sum + row.stabilityScore, 0) / worldRows.length) * 100)
      : 76;
    const topUnstable = [...worldRows].sort((a, b) => a.stabilityScore - b.stabilityScore).slice(0, 3);
    const rightPanel = buildRightPanelFeeds(profile, alerts, projects, threats);
    const intro = buildIntroMessage({ alerts, projects, commander, campaignStatus: { globalThreat: threatMetrics.globalThreat, currentObjective: worldInfo?.capital?.currentObjective ?? 'Capture Flame Rift' } }, meta);

    meta.introMessage = intro.message || meta.introMessage;
    meta.introDigest = intro.digest;
    saveProfileIfPossible(profile);

    return {
      route: PAGE_META[pageId]?.route ?? '#/command',
      currentPage: pageId,
      campaignId: meta.campaignId,
      campaignName: meta.campaignName,
      turn: meta.turn,
      faction,
      commander,
      resources: {
        credits: Math.max(0, Math.round(toNumber(profile.economy?.gold, 0))),
        forgeCores: Math.max(0, Math.round(toNumber(worldInfo?.salvageTokens, 0))),
        relicDust: Math.max(0, Math.round(toNumber(worldInfo?.relicFragments, 0))),
        supplies: Math.max(0, Math.round(toNumber(worldInfo?.supply?.reinforcementReadiness, 0.9) * 20)),
        totalWarResources: Math.max(0, Math.round(toNumber(worldInfo?.totalWarResources, 0))),
      },
      activeDeck,
      campaignStatus: {
        ownedTerritories: worldRows.length,
        enemyTerritories: Math.max(0, Math.round(toNumber(profile.mapWorld?.createdGalaxies?.length, 0) + toNumber(profile.mapWorld?.campaign?.lostWorldIds?.length, 0) + 6)),
        globalThreat: threatMetrics.globalThreat,
        nextInvasionTurns: threatMetrics.nextInvasionTurns,
        currentObjective: worldInfo?.capital?.name ? `Secure ${worldInfo.capital.name}` : 'Capture Flame Rift',
        mostDangerousRival: threatMetrics.mostDangerousRival,
        borderUnderPressure: threatMetrics.borderUnderPressure,
      },
      readiness: {
        attack: titleCase(worldInfo?.supply?.status ?? 'stable'),
        defense: worldRows.some((entry) => entry.readiness === 'broken') ? 'Broken Supply' : worldRows.some((entry) => entry.readiness === 'strained') ? 'Strained Supply' : 'Stable Supply',
      },
      stabilityAverage,
      topUnstable,
      worlds: worldRows,
      selectedWorld: worldInfo?.world ? {
        worldId: worldInfo.world.worldId,
        planetId: worldInfo.capital?.id ?? null,
        worldName: worldInfo.world.worldName,
        planetName: worldInfo.capital?.name ?? worldInfo.world.worldName,
        primaryElement: worldInfo.capital?.primaryElement ?? 'neutral',
        secondaryElement: worldInfo.capital?.secondaryElement ?? 'colorless',
        passiveIncome: Math.round(toNumber(worldInfo.capital?.passiveIncomeEffective ?? worldInfo.capital?.passiveIncomeValue ?? worldInfo.world?.economy?.income, 0)),
        stabilityState: String(worldInfo.capital?.stabilityState ?? 'stable'),
        populationIdentity: toArray(worldInfo.capital?.nativeSpeciesPools).slice(0, 3).map((id) => titleCase(global.conquestSpeciesMeta?.(id)?.name ?? id)).join(' • ') || 'Mixed frontier population',
        specialization: global.conquestPlanetSpecializationMeta?.(worldInfo.capital?.commandState?.specializationId)?.name ?? 'Recruitment World',
        blackMarketAvailable: !!worldInfo.blackMarketAvailable,
      } : null,
      alerts,
      projects,
      recommendedActions,
      rightPanel,
      warCouncil: buildWarCouncilState(profile, worldInfo, threats),
      market: marketSummary,
      diplomacy: diplomacySummary,
      relics: {
        fragments: clone(worldInfo?.attackState?.relics?.fragments ?? {}),
        assembled: toArray(worldInfo?.attackState?.relics?.assembled).slice(-6),
      },
      archives: {
        events: toArray(profile.mapWorld?.campaign?.eventHistory).slice(-12).reverse(),
        commandLog: toArray(meta.commandLog).slice(-8).reverse(),
      },
      settings: clone(profile.settings ?? {}),
      introMessage: intro.message,
      saveState: String(meta.saveState ?? (typeof global.loadProfile === 'function' ? 'synced' : 'snapshot')),
      threatBand: threatMetrics.band,
      pages: PAGE_ORDER.map((id) => ({ ...PAGE_META[id] })),
    };
  }

  function updateCommandCenterMeta(updater) {
    const profile = loadCampaignProfile();
    const meta = ensureCommandCenterMeta(profile);
    if (typeof updater === 'function') updater(meta, profile);
    saveProfileIfPossible(profile);
    return meta;
  }

  function endTurnSummary() {
    const profile = loadCampaignProfile();
    const meta = ensureCommandCenterMeta(profile);
    const beforeState = buildCommandState(PAGE_META[meta.currentPage]?.route ?? '#/command');
    meta.turn += 1;
    const summary = [];
    const topThreat = beforeState?.warCouncil?.threatBoard?.[0] ?? null;
    if (topThreat) {
      summary.push({ title: 'Enemy Actions', body: `${topThreat.faction} shifted pressure toward ${topThreat.region}.` });
    }
    const activeProject = beforeState?.projects?.[0] ?? null;
    if (activeProject) {
      summary.push({ title: 'Projects', body: activeProject.status === 'complete' || activeProject.status === 'ready' ? `${activeProject.title} remains ready for collection.` : `${activeProject.title} advanced toward completion.` });
    }
    summary.push({ title: 'Market', body: `${beforeState?.market?.state ?? 'Trade routes'} adjusted. Price modifier is now ${beforeState?.market?.priceModifier ?? 0}%.` });
    summary.push({ title: 'New Events', body: topThreat ? `Fresh chatter around ${topThreat.region} reached the command table.` : 'Patrol reports were filed from the border.' });
    meta.lastSummary = summary;
    meta.commandLog.unshift({ ts: Date.now(), turn: meta.turn, text: summary.map((entry) => `${entry.title}: ${entry.body}`).join(' ') });
    meta.commandLog = meta.commandLog.slice(0, 24);
    saveProfileIfPossible(profile);
    return {
      turn: meta.turn,
      summary,
    };
  }

  global.CardForgeCampaignState = {
    PAGE_META,
    buildCommandState,
    updateCommandCenterMeta,
    endTurnSummary,
    routeToPageId,
  };
}(window));
